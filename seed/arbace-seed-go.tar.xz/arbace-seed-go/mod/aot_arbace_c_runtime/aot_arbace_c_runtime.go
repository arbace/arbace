//line aot_arbace_c_runtime.ae:1
package aot_arbace_c_runtime

import (
	"arbace/aot_arbace_c_build"
	"arbace/aot_arbace_c_musl"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A_New() *A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_runtime_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_runtime_A_const_1); lang.IFn_Cast(A_arbace_c_runtime_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c_runtime_A_const_3, A_arbace_c_runtime_A_const_4, A_arbace_c_runtime_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_runtime_eval676000008_fn__676000009_A_New() *A_arbace_c_runtime_eval676000008_fn__676000009_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_eval676000008_fn__676000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_runtime_eval676000008_fn__676000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_runtime_eval676000008_fn__676000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_c_runtime_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_c_runtime_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_runtime_A_const_9.GetRawRoot__O(), A_arbace_c_runtime_A_const_10) }














func A_arbace_c_runtime_env_A_New() *A_arbace_c_runtime_env_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_env_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_c_runtime_env_A) Ctor() {}
//line :16:1
func (t *A_arbace_c_runtime_env_A) Invoke_O_O_O__O(self, k__0, d__1 any) any { var or__1927000174__auto____3 any = jrt.System_Getenv_String__String(jrt.String_Cast(k__0)).Ref(); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return d__1 } }

func A_arbace_c_runtime_check_unit_A_New() *A_arbace_c_runtime_check_unit_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_check_unit_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c_runtime_check_unit_A) Ctor() {}
//line :18:1
func (t *A_arbace_c_runtime_check_unit_A) Invoke_O_O_O__O(self, lib__0, src__1 any) any { var rd__3 any; var root_21 any = A_arbace_c_runtime_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_c_musl.A_arbace_c_musl_load_unit_A_fn_class); var ifn_23 lang.IFn; if


	linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = A_arbace_c_runtime_A_const_12.Invoke_O__O(lib__0); var arg_25 any = src__1; if linked_22 == nil { rd__3 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { rd__3 = linked_22.(*aot_arbace_c_musl.A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; var vec__676000015__4 any; var root_26 any = /*line :18:1*/A_arbace_c_runtime_A_const_13.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_c_musl.A_arbace_c_musl_config_A_fn_class); var ifn_28 lang.IFn; if



	linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = A_arbace_c_runtime_A_const_14.Invoke_O__O(lib__0); var arg_30 any = A_arbace_c_runtime_A_const_12.Invoke_O__O(lib__0); if linked_27 == nil { vec__676000015__4 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { vec__676000015__4 = linked_27.(*aot_arbace_c_musl.A_arbace_c_musl_config_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; var fc__5 any = /*line :18:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__676000015__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__676000015__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_31 any = A_arbace_c_runtime_A_const_15.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_33 lang.IFn; _ = ___6; if




	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var tmp1 any; var root_37 any = A_arbace_c_runtime_A_const_16.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = A_arbace_c_runtime_A_const_17; if linked_38 == nil { tmp1 = ifn_39.Invoke_O__O(arg_40) } else { tmp1 = linked_38.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_37, arg_40) }; arg_34 = lang.IFn_Cast(tmp1).Invoke_O_O_O__O(A_arbace_c_runtime_A_const_14.Invoke_O__O(lib__0), fc__5, rd__3); var arg_35 any = A_arbace_c_runtime_A_const_18; var arg_36 any = src__1; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36) } }


func A_arbace_c_runtime_sha256_hex_A_New() *A_arbace_c_runtime_sha256_hex_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_sha256_hex_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_c_runtime_sha256_hex_A) Ctor() {}
//line :26:1
func (t *A_arbace_c_runtime_sha256_hex_A) Invoke_O_O__O(self, b__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_56).Digest_B1__B1(jrt.ByteArray_Cast(b__0)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_676000019__4 any; var root_45 any = A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_47 lang.IFn; if


	linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = d__2; if linked_46 == nil { seq_676000019__4 = ifn_47.Invoke_O__O(arg_48) } else { seq_676000019__4 = linked_46.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_45, arg_48) }; var chunk_676000020__5 any; var count_676000021__6 int64 = 0; var i_676000022__7 int64 = 0; L1:
//line :26:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_676000022__7, count_676000021__6) { var x__8 any = lang.Indexed_Cast(chunk_676000020__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_676000022__7)); jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c_runtime_A_const_24.GetRawRoot__O()).Invoke_O_O__O(Lit_57, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(x__8))).Ref()))); seq_676000019__4, chunk_676000020__5, count_676000021__6, i_676000022__7 = seq_676000019__4, chunk_676000020__5, count_676000021__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_676000022__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_49 any = A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = seq_676000019__4; if linked_50 == nil { temp__1927000414__auto____8 = ifn_51.Invoke_O__O(arg_52) } else { temp__1927000414__auto____8 = linked_50.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_676000019__9 any = temp__1927000414__auto____8; var tmp1 any; var root_53 any = A_arbace_c_runtime_A_const_21.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = seq_676000019__9; if linked_54 == nil { tmp1 = ifn_55.Invoke_O__O(arg_56) } else { tmp1 = linked_54.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_57 any = A_arbace_c_runtime_A_const_22.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = seq_676000019__9; if linked_58 == nil { c__1927000678__auto____10 = ifn_59.Invoke_O__O(arg_60) } else { c__1927000678__auto____10 = linked_58.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_57, arg_60) }; var tmp2 any; var root_70 any = A_arbace_c_runtime_A_const_25.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = seq_676000019__9; if linked_71 == nil { tmp2 = ifn_72.Invoke_O__O(arg_73) } else { tmp2 = linked_71.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_70, arg_73) }; seq_676000019__4, chunk_676000020__5, count_676000021__6, i_676000022__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__10 any; var root_61 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = seq_676000019__9; if linked_62 == nil { x__10 = ifn_63.Invoke_O__O(arg_64) } else { x__10 = linked_62.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_61, arg_64) }; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c_runtime_A_const_24.GetRawRoot__O()).Invoke_O_O__O(Lit_57, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(x__10))).Ref()))); var tmp3 any; var root_79 any = A_arbace_c_runtime_A_const_26.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = seq_676000019__9; if linked_80 == nil { tmp3 = ifn_81.Invoke_O__O(arg_82) } else { tmp3 = linked_80.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_79, arg_82) }; seq_676000019__4, chunk_676000020__5, count_676000021__6, i_676000022__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :26:1
		break L1 }; var root_41 any =



	A_arbace_c_runtime_A_const_19.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = sb__3; if linked_42 == nil { return ifn_43.Invoke_O__O(arg_44) } else { return linked_42.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_41, arg_44) } }






func A_arbace_c_runtime_embedded_bytes_A_New() *A_arbace_c_runtime_embedded_bytes_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_embedded_bytes_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_c_runtime_embedded_bytes_A) Ctor() {}
//line :37:1
func (t *A_arbace_c_runtime_embedded_bytes_A) Invoke_O_O__O(self, f__0 any) any { var temp__1927000414__auto____2 any = lang.RT_ResourceAsStream_ClassLoader_String__InputStream_NoInit(nil, jrt.String_Cast(f__0)); if


	jrt.J2g_Truth(temp__1927000414__auto____2) { var ins__3 any = temp__1927000414__auto____2; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		tmp1 = jrt.InputStream_Cast(ins__3).ReadAllBytes__B1().Ref()
//line :40:1
		return nil }()
		jrt.InputStream_Cast(ins__3).Close__V()
//line :40:1
		if tmp2 != nil { panic(tmp2) }; return tmp1 } else { return nil } }


func A_arbace_c_runtime_source_bytes_A_New() *A_arbace_c_runtime_source_bytes_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_source_bytes_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_c_runtime_source_bytes_A) Ctor() {}
//line :43:1
func (t *A_arbace_c_runtime_source_bytes_A) Invoke_O_O_O__O(self, root__0, f__1 any) any { var cf__3 any = jrt.File_New_String_String(jrt.String_Cast(root__0), jrt.String_Cast(f__1)); var checkout__4 any; if







	jrt.File_Cast(cf__3).Exists__Z() { checkout__4 = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(cf__3).ToPath__Path()).Ref() } else { checkout__4 = nil }; var emb__5 any; var root_83 any = /*line :43:1*/A_arbace_c_runtime_A_const_27.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, A_arbace_c_runtime_embedded_bytes_A_fn_class); var ifn_85 lang.IFn; if








	linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = f__1; if linked_84 == nil { emb__5 = ifn_85.Invoke_O__O(arg_86) } else { emb__5 = linked_84.(*A_arbace_c_runtime_embedded_bytes_A).Invoke_O_O__O(root_83, arg_86) }; var tool_QMARK___6 any; var root_87 any = /*line :43:1*/A_arbace_c_runtime_A_const_28.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_89 lang.IFn; if









	linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = f__1; var arg_91 any = Lit_58; if linked_88 == nil { tool_QMARK___6 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { tool_QMARK___6 = linked_88.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }; var compiled_QMARK___7 any; var root_92 any = /*line :43:1*/A_arbace_c_runtime_A_const_29.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_94 lang.IFn; if










	linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var tmp1 any; var root_96 any = A_arbace_c_runtime_A_const_30.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = f__1; var arg_100 any = A_arbace_c_runtime_A_const_31; var arg_101 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(f__1)), 3)).Ref(); if linked_97 == nil { tmp1 = ifn_98.Invoke_O_O_O__O(arg_99, arg_100, arg_101) } else { tmp1 = linked_97.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_96, arg_99, arg_100, arg_101) }; arg_95 = lang.Compiler_AOT_Loader_String__Class_NoInit(jrt.String_Cast(tmp1)).Ref(); if linked_93 == nil { compiled_QMARK___7 = ifn_94.Invoke_O__O(arg_95) } else { compiled_QMARK___7 = linked_93.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_92, arg_95) }; var tmp2 any; var and__1927000168__auto____8 any = tool_QMARK___6; if

	jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = checkout__4; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_102 any = A_arbace_c_runtime_A_const_32.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Arrays_Equals_B1_B1__Z_NoInit(jrt.ByteArray_Cast(checkout__4), jrt.ByteArray_Cast(emb__5))).Ref(); if linked_103 == nil { tmp2 = ifn_104.Invoke_O__O(arg_105) } else { tmp2 = linked_103.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_102, arg_105) } } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = and__1927000168__auto____8 }; if /*line :55:1*/ jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O_O__IPersistentVector(Lit_59, checkout__4) } else { var tmp3 any
		var and__1927000168__auto____8_2 any = compiled_QMARK___7
		if jrt.J2g_Truth(and__1927000168__auto____8_2) { tmp3 = emb__5 } else { tmp3 = and__1927000168__auto____8_2 }
//line :55:1
		if jrt.J2g_Truth(tmp3) { return lang.Tuple_Create_O_O__IPersistentVector(Lit_60, emb__5) } else { var tmp4 any
			var and__1927000168__auto____8_3 any = checkout__4

			if jrt.J2g_Truth(and__1927000168__auto____8_3) { var or__1927000174__auto____9 any = jrt.System_Getenv_String__String(Lit_61).Ref(); if jrt.J2g_Truth(or__1927000174__auto____9) { tmp4 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any = tool_QMARK___6; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(emb__5, nil)).Ref() } } } else { tmp4 = and__1927000168__auto____8_3 }
//line :55:1
			if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(Lit_59, checkout__4) } else { if jrt.J2g_Truth(emb__5) { return lang.Tuple_Create_O_O__IPersistentVector(Lit_59, emb__5) } else { if A_arbace_c_runtime_A_const_33 != nil { return lang.Tuple_Create_O_O__IPersistentVector(Lit_62, jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1))).GetBytes_String__B1(Lit_51).Ref()) } else { return nil } } } } } }






func A_arbace_c_runtime_runtime_key_A_New() *A_arbace_c_runtime_runtime_key_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_runtime_key_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_c_runtime_runtime_key_A) Ctor() {}
//line :62:1
func (t *A_arbace_c_runtime_runtime_key_A) Invoke_O_O_O__O(self, root__0, lib_key__1 any) any {



	var root_106 any = A_arbace_c_runtime_A_const_34.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, A_arbace_c_runtime_sha256_hex_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,8,s11:ci-runtime ns1:\ns34:target linux-amd64 ldouble-size 8\ns8:library ns1:\nn", []*jrt.Class{jrt.String_class}); var tmp2 any = A_arbace_c_runtime_A_const_35.GetRawRoot__O(); var tmp3 any; var root_110 any = A_arbace_c_runtime_A_const_36.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_112 lang.IFn


	if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var iter__1927001039__auto____11 any; var fnbody__193 any = A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_New_O(root__0); var tmp4 *jrt.Class; var fncls__192 *jrt.Class = A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_fn_class; if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__193); A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_fn_class = fncls__192d; tmp4 = fncls__192d } else { tmp4 = fncls__192 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__193, tmp4, nil); arg_113 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_c_runtime_A_const_44.GetRawRoot__O()); if linked_111 == nil { tmp3 = ifn_112.Invoke_O__O(arg_113) } else { tmp3 = linked_111.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_110, arg_113) }
//line :66:1
	arg_109 = jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, nil, nil, lib_key__1, nil, tmp3))).GetBytes_String__B1(Lit_51).Ref(); if linked_107 == nil { return ifn_108.Invoke_O__O(arg_109) } else { return linked_107.(*A_arbace_c_runtime_sha256_hex_A).Invoke_O_O__O(root_106, arg_109)
	}
}
func A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_New_O(p0 any) *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :69:1
func (t *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A) Invoke_O_O__O(self, s__676000027__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__191 any = A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_New_O_O_O(t.F_root, self, s__676000027__1); var tmp2 *jrt.Class; var fncls__190 *jrt.Class = A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_fn_class; if fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__191); A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_fn_class = fncls__190d; tmp2 = fncls__190d } else { tmp2 = fncls__190 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__191, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :69:1
func A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :69:1
func (t *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A) Ctor_O_O_O(c__root, c__iter__676000026, c__s__676000027 any) { t.F_root = c__root; t.F_iter__676000026 = c__iter__676000026; t.F_s__676000027 = c__s__676000027 }
//line :69:1
func (t *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A) Invoke_O__O(self any) any { { var s__676000027__1 any; var t_ any = t.F_s__676000027; t.F_s__676000027 = nil; s__676000027__1 = t_; for { var temp__1927000414__auto____2 any; var root_114 any = A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = s__676000027__1; if linked_115 == nil { temp__1927000414__auto____2 = ifn_116.Invoke_O__O(arg_117) } else { temp__1927000414__auto____2 = linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__676000027__3 any = temp__1927000414__auto____2; var tmp1 any; var root_118 any = A_arbace_c_runtime_A_const_21.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = s__676000027__3; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_118, arg_121) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_122 any = A_arbace_c_runtime_A_const_22.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = s__676000027__3; if linked_123 == nil { c__1927001037__auto____4 = ifn_124.Invoke_O__O(arg_125) } else { c__1927001037__auto____4 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_122, arg_125) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__676000029__6 any; var root_126 any = A_arbace_c_runtime_A_const_37.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_127 == nil { b__676000029__6 = ifn_128.Invoke_O__O(arg_129) } else { b__676000029__6 = linked_127.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_126, arg_129) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__145 any = A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_New_O_O_I_O(t.F_root, b__676000029__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__145); A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_146 any = A_arbace_c_runtime_A_const_40.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_151 any = A_arbace_c_runtime_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = b__676000029__6; if linked_152 == nil { arg_149 = ifn_153.Invoke_O__O(arg_154) } else { arg_149 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_151, arg_154) }; var arg_150 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__676000026); var tmp5 any; var root_155 any = A_arbace_c_runtime_A_const_25.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__676000027__3; if linked_156 == nil { tmp5 = ifn_157.Invoke_O__O(arg_158) } else { tmp5 = linked_156.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_155, arg_158) }; arg_150 = tmp4.Invoke_O__O(tmp5); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else { var root_159 any = A_arbace_c_runtime_A_const_40.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_164 any = A_arbace_c_runtime_A_const_41.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = b__676000029__6; if linked_165 == nil { arg_162 = ifn_166.Invoke_O__O(arg_167) } else { arg_162 = linked_165.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_164, arg_167) }; var arg_163 any; if linked_160 == nil { return ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { return linked_160.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) } } } else { var f__4 any; var root_168 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = s__676000027__3; if linked_169 == nil { f__4 = ifn_170.Invoke_O__O(arg_171) } else { f__4 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) }; var vec__676000037__5 any; var root_172 any = A_arbace_c_runtime_A_const_38.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, A_arbace_c_runtime_source_bytes_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = t.F_root; var arg_176 any = f__4; if linked_173 == nil { vec__676000037__5 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { vec__676000037__5 = linked_173.(*A_arbace_c_runtime_source_bytes_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; var how__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__676000037__5, lang.RT_IntCast_J__I_NoInit(0), nil); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__676000037__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_177 any = A_arbace_c_runtime_A_const_42.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_54, nil, Lit_54, nil, Lit_55); var tmp7 any; var root_182 any = A_arbace_c_runtime_A_const_34.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_c_runtime_sha256_hex_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = b__7; if linked_183 == nil { tmp7 = ifn_184.Invoke_O__O(arg_185) } else { tmp7 = linked_183.(*A_arbace_c_runtime_sha256_hex_A).Invoke_O_O__O(root_182, arg_185) }; arg_180 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, f__4, nil, how__6, nil, tmp7, nil)).Ref(); var arg_181 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__676000026); var tmp9 any; var root_186 any = A_arbace_c_runtime_A_const_43.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__676000027__3; if linked_187 == nil { tmp9 = ifn_188.Invoke_O__O(arg_189) } else { tmp9 = linked_187.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_186, arg_189) }; arg_181 = tmp8.Invoke_O__O(tmp9); if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :69:1
func A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :69:1
func (t *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A) Ctor_O_O_I_O(c__root, c__b__676000029 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_b__676000029 = c__b__676000029; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :69:1
func (t *A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A) Invoke_O__O(self any) any { { var i__676000028__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__676000028__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__676000028__1)); var vec__676000033__3 any; var root_130 any = A_arbace_c_runtime_A_const_38.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_c_runtime_source_bytes_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t.F_root; var arg_134 any = f__2; if linked_131 == nil { vec__676000033__3 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { vec__676000033__3 = linked_131.(*A_arbace_c_runtime_source_bytes_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }; var how__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__676000033__3, lang.RT_IntCast_J__I_NoInit(0), nil); var b__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__676000033__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_135 any = A_arbace_c_runtime_A_const_39.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = t.F_b__676000029; var arg_139 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_54, nil, Lit_54, nil, Lit_55); var tmp3 any; var root_140 any = A_arbace_c_runtime_A_const_34.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, A_arbace_c_runtime_sha256_hex_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = b__5; if linked_141 == nil { tmp3 = ifn_142.Invoke_O__O(arg_143) } else { tmp3 = linked_141.(*A_arbace_c_runtime_sha256_hex_A).Invoke_O_O__O(root_140, arg_143) }; arg_139 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, f__2, nil, how__4, nil, tmp3, nil)).Ref(); if linked_136 == nil { ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { linked_136.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) }; i__676000028__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__676000028__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c_runtime_musl_key_A_New() *A_arbace_c_runtime_musl_key_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_musl_key_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c_runtime_musl_key_A) Ctor() {}
//line :72:1
func (t *A_arbace_c_runtime_musl_key_A) Invoke_O_O__O(self, root__0 any) any { var k__2 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_38); var tmp2 any; var root_194 any = A_arbace_c_runtime_A_const_45.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_c_musl.A_arbace_c_musl_forms_root_A_fn_class); var ifn_196 lang.IFn; if


	linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = root__0; if linked_195 == nil { tmp2 = ifn_196.Invoke_O__O(arg_197) } else { tmp2 = linked_195.(*aot_arbace_c_musl.A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_194, arg_197) }; k__2 = /*line :72:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil))); var ix__3 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_39); var tmp4 any; var root_198 any = A_arbace_c_runtime_A_const_45.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_c_musl.A_arbace_c_musl_forms_root_A_fn_class); var ifn_200 lang.IFn; if



	linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = root__0; if linked_199 == nil { tmp4 = ifn_200.Invoke_O__O(arg_201) } else { tmp4 = linked_199.(*aot_arbace_c_musl.A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_198, arg_201) }; ix__3 = /*line :72:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil))); if




	jrt.File_Cast(k__2).Exists__Z() {
		var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_40, nil); var tmp6 any; var root_202 any = A_arbace_c_runtime_A_const_46.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = lang.IFn_Cast(A_arbace_c_runtime_A_const_47.GetRawRoot__O()).Invoke_O__O(k__2); if linked_203 == nil { tmp6 = ifn_204.Invoke_O__O(arg_205) } else { tmp6 = linked_203.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_202, arg_205) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref() } else {
//line :77:1
			if jrt.File_Cast(ix__3).Exists__Z() {

				var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil); var tmp8 any; var root_210 any = A_arbace_c_runtime_A_const_34.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, A_arbace_c_runtime_sha256_hex_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(ix__3).ToPath__Path()).Ref(); if linked_211 == nil { tmp8 = ifn_212.Invoke_O__O(arg_213) } else { tmp8 = linked_211.(*A_arbace_c_runtime_sha256_hex_A).Invoke_O_O__O(root_210, arg_213) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref() } else {
//line :77:1
					if A_arbace_c_runtime_A_const_33 != nil { return Lit_42 } else { return nil } } } }




func A_arbace_c_runtime_cache_root_A_New() *A_arbace_c_runtime_cache_root_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_cache_root_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_c_runtime_cache_root_A) Ctor() {}
//line :82:1
func (t *A_arbace_c_runtime_cache_root_A) Invoke_O_O__O(self, root__0 any) any { var root_214 any = A_arbace_c_runtime_A_const_48.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_c_runtime_env_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = Lit_1; var arg_218 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, root__0, nil)).Ref(); if linked_215 == nil { return ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { return linked_215.(*A_arbace_c_runtime_env_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) } }

func A_arbace_c_runtime_prebuilt_A_New() *A_arbace_c_runtime_prebuilt_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuilt_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_c_runtime_prebuilt_A) Ctor() {}
//line :84:1
func (t *A_arbace_c_runtime_prebuilt_A) Invoke_O_O_O_O_O_O__O(self, lib__0, root__1, name__2, lib_key__3, check__4 any) any { var key__6 any; var root_219 any = A_arbace_c_runtime_A_const_49.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_c_runtime_runtime_key_A_fn_class); var ifn_221 lang.IFn; if



	linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = root__1; var arg_223 any = lib_key__3; if linked_220 == nil { key__6 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { key__6 = linked_220.(*A_arbace_c_runtime_runtime_key_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; var dir__7 any; var tmp1 /*line :84:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28, nil, Lit_49, nil); var tmp2 any; var root_224 any = A_arbace_c_runtime_A_const_50.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_c_runtime_cache_root_A_fn_class); var ifn_226 lang.IFn; if




	linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = root__1; if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*A_arbace_c_runtime_cache_root_A).Invoke_O_O__O(root_224, arg_227) }; dir__7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, name__2, nil, key__6)).Ref(); var d__8 any = /*line :84:1*/jrt.File_New_String(jrt.String_Cast(dir__7)); if







	jrt.File_Cast(d__8).IsDirectory__Z() { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(d__8).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J())) }; var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_c_runtime_A_const_15.GetRawRoot__O()); var tmp4 any = A_arbace_c_runtime_A_const_51; return tmp3.Invoke_O_O_O_O_O_O_O_O_O__O(lib__0, tmp4, jrt.ConcurrentHashMap_New(), A_arbace_c_runtime_A_const_52, check__4, A_arbace_c_runtime_A_const_53, key__6, A_arbace_c_runtime_A_const_54, dir__7) }


func A_arbace_c_runtime_write_atomic_A_New() *A_arbace_c_runtime_write_atomic_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_write_atomic_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_c_runtime_write_atomic_A) Ctor() {}
//line :96:1
func (t *A_arbace_c_runtime_write_atomic_A) Invoke_O_O_O__O(self, f__0, s__1 any) any {


	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__0).GetParentFile__File().Mkdirs__Z())
//line :96:1
	var tmp__3 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_64, nil, Lit_49, nil), jrt.RefArrayOf(jrt.Object_class, jrt.File_Cast(f__0).GetPath__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.Thread_CurrentThread__Thread().GetId__J()).Ref())))




	lang.IFn_Cast(A_arbace_c_runtime_A_const_55.GetRawRoot__O()).Invoke_O_O__O(tmp__3, s__1)
	if jrt.File_Cast(tmp__3).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(tmp__3).Delete__Z()).Ref()
	}
}

func A_arbace_c_runtime_make_fragment_A_New() *A_arbace_c_runtime_make_fragment_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_make_fragment_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_c_runtime_make_fragment_A) Ctor() {}
//line :106:1
func (t *A_arbace_c_runtime_make_fragment_A) Invoke_O_O_O__O(self, lib__0, src__1 any) any { var f__3 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, A_arbace_c_runtime_A_const_54.Invoke_O__O(lib__0), nil, src__1, nil))); var or__1927000174__auto____4 any; var tmp1 any; var and__1927000168__auto____4 any; var root_245 any = A_arbace_c_runtime_A_const_32.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_247 lang.IFn; if


	linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = A_arbace_c_runtime_A_const_56.Get__O(); if linked_246 == nil { and__1927000168__auto____4 = ifn_247.Invoke_O__O(arg_248) } else { and__1927000168__auto____4 = linked_246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__3).Exists__Z()).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *lang.Compiler_AOTFn; var fnbody__258 any = A_arbace_c_runtime_make_fragment_fn__676000047_A_New_O(f__3); var tmp3 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_c_runtime_make_fragment_fn__676000047_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__258); A_arbace_c_runtime_make_fragment_fn__676000047_A_fn_class = fncls__257d; tmp3 = fncls__257d } else { tmp3 = fncls__257 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__258, tmp3, nil); or__1927000174__auto____4 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O() } else {
//line :109:1
			or__1927000174__auto____4 = nil }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var u__5 any = lang.IFn_Cast(A_arbace_c_runtime_A_const_52.Invoke_O__O(lib__0)).Invoke_O__O(src__1); var fr__6 any; var G__676000049__6_ any; var root_259 any = A_arbace_c_runtime_A_const_58.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_c_build.A_arbace_c_build_unit_fragment_A_fn_class); var ifn_261 lang.IFn



				if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = u__5; if linked_260 == nil { G__676000049__6_ = ifn_261.Invoke_O__O(arg_262) } else { G__676000049__6_ = linked_260.(*aot_arbace_c_build.A_arbace_c_build_unit_fragment_A).Invoke_O_O__O(root_259, arg_262) }; var tmp4 any; var root_263 any = A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var tmp5 *lang.Keyword = A_arbace_c_runtime_A_const_59; var arg_266 any = tmp5.Invoke_O__O(A_arbace_c_runtime_A_const_60.Invoke_O__O(u__5)); if linked_264 == nil { tmp4 = ifn_265.Invoke_O__O(arg_266) } else { tmp4 = linked_264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_263, arg_266) }; if jrt.J2g_Truth(tmp4) { var root_267 any = A_arbace_c_runtime_A_const_15.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = G__676000049__6_; var arg_271 any = A_arbace_c_runtime_A_const_59; var tmp6 *lang.Keyword = A_arbace_c_runtime_A_const_59; var arg_272 any = tmp6.Invoke_O__O(A_arbace_c_runtime_A_const_60.Invoke_O__O(u__5)); if linked_268 == nil { fr__6 = ifn_269.Invoke_O_O_O__O(arg_270, arg_271, arg_272) } else { fr__6 = linked_268.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_267, arg_270, arg_271, arg_272) } } else { fr__6 = G__676000049__6_ }
				if jrt.J2g_Truth(A_arbace_c_runtime_A_const_56.Get__O()) { } else {


					var tmp7 *lang.Compiler_AOTFn; var fnbody__325 any = A_arbace_c_runtime_make_fragment_fn__676000050_A_New_O_O(f__3, fr__6); var tmp8 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_c_runtime_make_fragment_fn__676000050_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__325); A_arbace_c_runtime_make_fragment_fn__676000050_A_fn_class = fncls__324d; tmp8 = fncls__324d } else { tmp8 = fncls__324 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__325, tmp8, nil); Up_Compiler_AOTFn_IFn(tmp7).Invoke__O() }
//line :109:1
				return fr__6 } }
func A_arbace_c_runtime_make_fragment_fn__676000047_A_New_O(p0 any) *A_arbace_c_runtime_make_fragment_fn__676000047_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_make_fragment_fn__676000047_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000047_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :110:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000047_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_249 any = A_arbace_c_runtime_A_const_57.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_47.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; arg_252 = tmp2.Invoke_O__O(tmp3); if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_249, arg_252) } }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }






func A_arbace_c_runtime_make_fragment_fn__676000050_A_New_O_O(p0, p1 any) *A_arbace_c_runtime_make_fragment_fn__676000050_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_make_fragment_fn__676000050_A{}; t.Ctor_O_O(p0, p1); return t }
//line :117:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000050_A) Ctor_O_O(c__f, c__fr any) { t.F_f = c__f; t.F_fr = c__fr }
//line :117:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000050_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_273 any = A_arbace_c_runtime_A_const_61.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_c_runtime_write_atomic_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t.F_f; var arg_277 any; var root_287 any = A_arbace_c_runtime_A_const_64.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = lang.IFn_Cast(A_arbace_c_runtime_A_const_65.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c_runtime_A_const_66, nil, A_arbace_c_runtime_A_const_67, nil); if linked_288 == nil { ifn_289.Invoke_O__O(arg_290) } else { linked_288.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_287, arg_290) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__286 any = A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_New_O(t.F_fr); var tmp3 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_fn_class; if fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__286); A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_fn_class = fncls__285d; tmp3 = fncls__285d } else { tmp3 = fncls__285 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__286, tmp3, nil); arg_277 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O(); if linked_274 == nil { tmp1 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { tmp1 = linked_274.(*A_arbace_c_runtime_write_atomic_A).Invoke_O_O_O__O(root_273, arg_276, arg_277) } }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var x__3 jrt.Exception_I = jrt.Exception_Cast(tmp4); var root_315 any = A_arbace_c_runtime_A_const_64.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_317 lang.IFn

	if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_65.GetRawRoot__O()); var tmp6 any = A_arbace_c_runtime_A_const_70; var arg_318 any = tmp5.Invoke_O_O__O(tmp6, A_arbace_c_runtime_A_const_71.Get__O()); if linked_316 == nil { ifn_317.Invoke_O__O(arg_318) } else { linked_316.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_315, arg_318) }; var tmp7 *lang.Compiler_AOTFn; var fnbody__314 any = A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_New_O_O(t.F_f, x__3); var tmp8 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__314); A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_fn_class = fncls__313d; tmp8 = fncls__313d } else { tmp8 = fncls__313 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__314, tmp8, nil); tmp1 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O() } else {
//line :117:1
		panic(tmp4) } }; return tmp1 }
//line :117:1
func A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_New_O(p0 any) *A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A) Ctor_O(c__fr any) { t.F_fr = c__fr }
//line :117:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_62.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_fr; t.F_fr = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_282 any = A_arbace_c_runtime_A_const_63.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; if linked_283 == nil { ifn_284.Invoke__O() } else { linked_283.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_282) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_New_O_O(p0, p1 any) *A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :119:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A) Ctor_O_O(c__f, c__x any) { t.F_f = c__f; t.F_x = c__x }
//line :119:1
func (t *A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_68.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; var tmp4 any = jrt.File_Cast(tmp3).GetPath__String().Ref(); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_36, nil); var tmp6 any; var root_306 any = A_arbace_c_runtime_A_const_69.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = t.F_x; if linked_307 == nil { tmp6 = ifn_308.Invoke_O__O(arg_309) } else { tmp6 = linked_307.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_306, arg_309) }; var tmp7 any = jrt.NN(jrt.Class_Cast(tmp6)).GetName__String().Ref(); var tmp8 any; var t__2 any = t.F_x; t.F_x = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O_O_O_O__O(Lit_34, tmp4, Lit_35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, jrt.Throwable_Cast(tmp8).GetMessage__String().Ref())).Ref(), Lit_37) }
//line :119:1
	return nil }(); var root_310 any = A_arbace_c_runtime_A_const_63.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; if linked_311 == nil { ifn_312.Invoke__O() } else { linked_311.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_310) }; if tmp9 != nil { panic(tmp9) }; return tmp1 }




func A_arbace_c_runtime_lib_fragment_A_New() *A_arbace_c_runtime_lib_fragment_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_lib_fragment_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_c_runtime_lib_fragment_A) Ctor() {}
//line :124:1
func (t *A_arbace_c_runtime_lib_fragment_A) Invoke_O_O_O__O(self, lib__0, src__1 any) any { var m__3 any = A_arbace_c_runtime_A_const_51.Invoke_O__O(lib__0); var d__4 any; var or__1927000174__auto____4 any = jrt.NN(jrt.ConcurrentHashMap_Cast(m__3)).Get_O__O(src__1); if



	jrt.J2g_Truth(or__1927000174__auto____4) { d__4 = or__1927000174__auto____4 } else { var d__5 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__332 any = A_arbace_c_runtime_lib_fragment_fn__676000057_A_New_O_O(src__1, lib__0); var tmp2 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_c_runtime_lib_fragment_fn__676000057_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__332); A_arbace_c_runtime_lib_fragment_fn__676000057_A_fn_class = fncls__331d; tmp2 = fncls__331d } else { tmp2 = fncls__331 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__332, tmp2, nil); d__5 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)); var or__1927000174__auto____6 any = jrt.NN(jrt.ConcurrentHashMap_Cast(m__3)).PutIfAbsent_O_O__O(src__1, d__5); if jrt.J2g_Truth(or__1927000174__auto____6) { d__4 = or__1927000174__auto____6 } else { d__4 = d__5 } }; var root_333 any = /*line :127:1*/A_arbace_c_runtime_A_const_7.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = d__4; if linked_334 == nil { return ifn_335.Invoke_O__O(arg_336) } else { return linked_334.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_333, arg_336) } }
func A_arbace_c_runtime_lib_fragment_fn__676000057_A_New_O_O(p0, p1 any) *A_arbace_c_runtime_lib_fragment_fn__676000057_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_lib_fragment_fn__676000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :128:1
func (t *A_arbace_c_runtime_lib_fragment_fn__676000057_A) Ctor_O_O(c__src, c__lib any) { t.F_src = c__src; t.F_lib = c__lib }
//line :128:1
func (t *A_arbace_c_runtime_lib_fragment_fn__676000057_A) Invoke_O__O(self any) any { var root_326 any = A_arbace_c_runtime_A_const_72.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, A_arbace_c_runtime_make_fragment_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var t_ any = t.F_lib; t.F_lib = nil; arg_329 = t_; var arg_330 any; var t__2 any = t.F_src; t.F_src = nil; arg_330 = t__2; if linked_327 == nil { return ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { return linked_327.(*A_arbace_c_runtime_make_fragment_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) } }


func A_arbace_c_runtime_library_A_New() *A_arbace_c_runtime_library_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_library_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_c_runtime_library_A) Ctor() {}
//line :131:1
func (t *A_arbace_c_runtime_library_A) Invoke_O_O_O__O(self, h__0, root__1 any) any { var lib__3 any; var root_337 any = A_arbace_c_runtime_A_const_73.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_c_musl.A_arbace_c_musl_library_A_fn_class); var ifn_339 lang.IFn; if


	linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = h__0; var arg_341 any = root__1; if linked_338 == nil { lib__3 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { lib__3 = linked_338.(*aot_arbace_c_musl.A_arbace_c_musl_library_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; var root_342 any =
	A_arbace_c_runtime_A_const_74.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_c_runtime_prebuilt_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = lib__3; var arg_346 any = root__1; var arg_347 any = Lit_5; var arg_348 any; var root_350 any = A_arbace_c_runtime_A_const_75.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_c_runtime_musl_key_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = root__1; if linked_351 == nil { arg_348 = ifn_352.Invoke_O__O(arg_353) } else { arg_348 = linked_351.(*A_arbace_c_runtime_musl_key_A).Invoke_O_O__O(root_350, arg_353) }; var arg_349 any; var fnbody__360 any = A_arbace_c_runtime_library_fn__676000061_A_New_O(lib__3); var tmp1 *jrt.Class; var fncls__359 *jrt.Class = A_arbace_c_runtime_library_fn__676000061_A_fn_class; if fncls__359 == nil { var fncls__359d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__360); A_arbace_c_runtime_library_fn__676000061_A_fn_class = fncls__359d; tmp1 = fncls__359d } else { tmp1 = fncls__359 }; arg_349 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__360, tmp1, nil); if linked_343 == nil { return ifn_344.Invoke_O_O_O_O_O__O(arg_345, arg_346, arg_347, arg_348, arg_349) } else { return linked_343.(*A_arbace_c_runtime_prebuilt_A).Invoke_O_O_O_O_O_O__O(root_342, arg_345, arg_346, arg_347, arg_348, arg_349) } }
//line :135:1
func A_arbace_c_runtime_library_fn__676000061_A_New_O(p0 any) *A_arbace_c_runtime_library_fn__676000061_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_library_fn__676000061_A{}; t.Ctor_O(p0); return t }
//line :135:1
func (t *A_arbace_c_runtime_library_fn__676000061_A) Ctor_O(c__lib any) { t.F_lib = c__lib }
//line :135:1
func (t *A_arbace_c_runtime_library_fn__676000061_A) Invoke_O_O__O(self, p1__676000060_SHARP___1 any) any { var root_354 any = A_arbace_c_runtime_A_const_76.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_c_runtime_check_unit_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = t.F_lib; var arg_358 any = p1__676000060_SHARP___1; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*A_arbace_c_runtime_check_unit_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } }

func A_arbace_c_runtime_normalize_A_New() *A_arbace_c_runtime_normalize_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_normalize_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_c_runtime_normalize_A) Ctor() {}
//line :137:1
func (t *A_arbace_c_runtime_normalize_A) Invoke_O_O__O(self, s__0 any) any {


	var root_361 any = A_arbace_c_runtime_A_const_77.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = s__0; var arg_365 any = A_arbace_c_runtime_A_const_78; var arg_366 any = Lit_43; if linked_362 == nil { return ifn_363.Invoke_O_O_O__O(arg_364, arg_365, arg_366) } else { return linked_362.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_361, arg_364, arg_365, arg_366)
	} }
func A_arbace_c_runtime_link_text_A_New() *A_arbace_c_runtime_link_text_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_c_runtime_link_text_A) Ctor() {}
//line :142:1
func (t *A_arbace_c_runtime_link_text_A) Invoke_O_O_O__O(self, lib__0, units__1 any) any { var pdefs__3 any; var root_367 any = A_arbace_c_runtime_A_const_79.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_369 lang.IFn; if




	linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_80.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__385 any = A_arbace_c_runtime_link_text_fn__676000070_A_New(); var tmp3 *jrt.Class; var fncls__384 *jrt.Class = A_arbace_c_runtime_link_text_fn__676000070_A_fn_class; if fncls__384 == nil { var fncls__384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); A_arbace_c_runtime_link_text_fn__676000070_A_fn_class = fncls__384d; tmp3 = fncls__384d } else { tmp3 = fncls__384 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__385, tmp3, nil); arg_370 = tmp1.Invoke_O_O__O(tmp2.Ref(), units__1); if linked_368 == nil { pdefs__3 = ifn_369.Invoke_O__O(arg_370) } else { pdefs__3 = linked_368.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_367, arg_370) }; var prefs__4 any; var root_386 any = /*line :142:1*/A_arbace_c_runtime_A_const_79.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_388 lang.IFn; if





	linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_80.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__414 any = A_arbace_c_runtime_link_text_fn__676000072_A_New(); var tmp6 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_c_runtime_link_text_fn__676000072_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); A_arbace_c_runtime_link_text_fn__676000072_A_fn_class = fncls__413d; tmp6 = fncls__413d } else { tmp6 = fncls__413 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__414, tmp6, nil); arg_389 = tmp4.Invoke_O_O__O(tmp5.Ref(), units__1); if linked_387 == nil { prefs__4 = ifn_388.Invoke_O__O(arg_389) } else { prefs__4 = linked_387.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_386, arg_389) }; var prefs__5 any; var root_415 any = /*line :142:1*/A_arbace_c_runtime_A_const_88.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_417 lang.IFn; if







	linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = prefs__4; var arg_419 any; var root_420 any = A_arbace_c_runtime_A_const_89.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any; var fnbody__436 any = A_arbace_c_runtime_link_text_fn__676000074_A_New(); var tmp7 *jrt.Class; var fncls__435 *jrt.Class = A_arbace_c_runtime_link_text_fn__676000074_A_fn_class; if fncls__435 == nil { var fncls__435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_c_runtime_link_text_fn__676000074_A_fn_class = fncls__435d; tmp7 = fncls__435d } else { tmp7 = fncls__435 }; arg_423 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__436, tmp7, nil); var arg_424 any = prefs__4; if linked_421 == nil { arg_419 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { arg_419 = linked_421.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; if linked_416 == nil { prefs__5 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { prefs__5 = linked_416.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; var srcs__6 any; var root_437 any = /*line :142:1*/A_arbace_c_runtime_A_const_91.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_c_musl.A_arbace_c_musl_closure_A_fn_class); var ifn_439 lang.IFn; if








	linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = lib__0; var arg_441 any = pdefs__3; var arg_442 any = prefs__5; if linked_438 == nil { srcs__6 = ifn_439.Invoke_O_O_O__O(arg_440, arg_441, arg_442) } else { srcs__6 = linked_438.(*aot_arbace_c_musl.A_arbace_c_musl_closure_A).Invoke_O_O_O_O__O(root_437, arg_440, arg_441, arg_442) }; var ___7 any; _ = ___7; if
	jrt.System_Getenv_String__String(Lit_10) != nil { var root_546 any = A_arbace_c_runtime_A_const_64.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_65.GetRawRoot__O()); var tmp9 any = A_arbace_c_runtime_A_const_70; var arg_549 any = tmp8.Invoke_O_O__O(tmp9, A_arbace_c_runtime_A_const_71.Get__O()); if linked_547 == nil { ifn_548.Invoke_O__O(arg_549) } else { linked_547.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_546, arg_549) }; var tmp10 *lang.Compiler_AOTFn; var fnbody__453 any = A_arbace_c_runtime_link_text_fn__676000076_A_New_O(srcs__6); var tmp11 *jrt.Class; var fncls__452 *jrt.Class = A_arbace_c_runtime_link_text_fn__676000076_A_fn_class; if fncls__452 == nil { var fncls__452d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__453); A_arbace_c_runtime_link_text_fn__676000076_A_fn_class = fncls__452d; tmp11 = fncls__452d } else { tmp11 = fncls__452 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__453, tmp11, nil); ___7 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O() } else { ___7 = nil }; var direct__8 any; var fnbody__486 any = /*line :142:1*/A_arbace_c_runtime_link_text_direct__676000078_A_New_O_O_O(lib__0, srcs__6, units__1); var tmp12 *jrt.Class; var fncls__485 *jrt.Class = A_arbace_c_runtime_link_text_direct__676000078_A_fn_class; if




	fncls__485 == nil { var fncls__485d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__486); A_arbace_c_runtime_link_text_direct__676000078_A_fn_class = fncls__485d; tmp12 = fncls__485d } else { tmp12 = fncls__485 }; direct__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__486, tmp12, nil); var linked__9 any; var fnbody__516 any = /*line :142:1*/A_arbace_c_runtime_link_text_linked__676000082_A_New_O_O_O(lib__0, srcs__6, units__1); var tmp13 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_c_runtime_link_text_linked__676000082_A_fn_class; if




	fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__516); A_arbace_c_runtime_link_text_linked__676000082_A_fn_class = fncls__515d; tmp13 = fncls__515d } else { tmp13 = fncls__515 }; linked__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__516, tmp13, nil); if









	lang.Util_Equiv_O_O__Z_NoInit(Lit_14, jrt.System_Getenv_String__String(Lit_15).Ref()) {
		return lang.IFn_Cast(direct__8).Invoke__O() } else {
//line :157:1
			if jrt.System_Getenv_String__String(Lit_16) != nil { var a__10 any; var tmp14 *lang.Compiler_AOTFn; var fnbody__522 any = A_arbace_c_runtime_link_text_fn__676000086_A_New_O(direct__8); var tmp15 *jrt.Class
				var fncls__521 /*line :157:1*/*jrt.Class = A_arbace_c_runtime_link_text_fn__676000086_A_fn_class


				if fncls__521 == nil { var fncls__521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__522); A_arbace_c_runtime_link_text_fn__676000086_A_fn_class = fncls__521d; tmp15 = fncls__521d } else { tmp15 = fncls__521 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__522, tmp15, nil); a__10 = Up_Compiler_AOTFn_IFn(tmp14).Invoke__O()
//line :157:1
				var b__11 any; var tmp16 *lang.Compiler_AOTFn; var fnbody__528 any = A_arbace_c_runtime_link_text_fn__676000088_A_New_O(linked__9); var tmp17 *jrt.Class
				var fncls__527 /*line :157:1*/*jrt.Class = A_arbace_c_runtime_link_text_fn__676000088_A_fn_class



				if fncls__527 == nil { var fncls__527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__528); A_arbace_c_runtime_link_text_fn__676000088_A_fn_class = fncls__527d; tmp17 = fncls__527d } else { tmp17 = fncls__527 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__528, tmp17, nil); b__11 = Up_Compiler_AOTFn_IFn(tmp16).Invoke__O()
				var tmp18 any; var root_555 any = A_arbace_c_runtime_A_const_95.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any; var fnbody__569 any = A_arbace_c_runtime_link_text_fn__676000090_A_New(); var tmp19 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_c_runtime_link_text_fn__676000090_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_c_runtime_link_text_fn__676000090_A_fn_class = fncls__568d; tmp19 = fncls__568d } else { tmp19 = fncls__568 }; arg_558 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__569, tmp19, nil); var arg_559 any = a__10; if linked_556 == nil { tmp18 = ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { tmp18 = linked_556.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }; var tmp20 any = tmp18; var tmp21 any; var root_570 any = A_arbace_c_runtime_A_const_95.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any; var fnbody__584 any = A_arbace_c_runtime_link_text_fn__676000092_A_New(); var tmp22 *jrt.Class; var fncls__583 *jrt.Class = A_arbace_c_runtime_link_text_fn__676000092_A_fn_class; if fncls__583 == nil { var fncls__583d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_c_runtime_link_text_fn__676000092_A_fn_class = fncls__583d; tmp22 = fncls__583d } else { tmp22 = fncls__583 }; arg_573 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__584, tmp22, nil); var arg_574 any = b__11; if linked_571 == nil { tmp21 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { tmp21 = linked_571.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, tmp21) { } else { var tmp23 any; var root_585 any = A_arbace_c_runtime_A_const_106.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_587 lang.IFn
					if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any; var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil, Lit_23); var tmp25 any; var tmp26 any = A_arbace_c_runtime_A_const_101; var tmp27 any; var root_590 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_592 lang.IFn
					if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = a__10; if linked_591 == nil { tmp27 = ifn_592.Invoke_O__O(arg_593) } else { tmp27 = linked_591.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_590, arg_593) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp26, tmp27) { var tmp28 any; var root_594 any = A_arbace_c_runtime_A_const_105.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = a__10; if linked_595 == nil { tmp28 = ifn_596.Invoke_O__O(arg_597) } else { tmp28 = linked_595.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_594, arg_597) }; tmp25 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp28)).Ref() } else { var root_598 any = A_arbace_c_runtime_A_const_105.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = a__10; if linked_599 == nil { tmp25 = ifn_600.Invoke_O__O(arg_601) } else { tmp25 = linked_599.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_598, arg_601) } }
//line :163:1
					var tmp29 any = tmp25; var tmp30 any; var tmp31 any = A_arbace_c_runtime_A_const_101; var tmp32 any; var root_602 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_604 lang.IFn

					if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = b__11; if linked_603 == nil { tmp32 = ifn_604.Invoke_O__O(arg_605) } else { tmp32 = linked_603.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_602, arg_605) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp31, tmp32) { var tmp33 any; var root_606 any = A_arbace_c_runtime_A_const_105.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = b__11; if linked_607 == nil { tmp33 = ifn_608.Invoke_O__O(arg_609) } else { tmp33 = linked_607.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_606, arg_609) }; tmp30 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp33)).Ref() } else { var root_610 any = A_arbace_c_runtime_A_const_105.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = b__11; if linked_611 == nil { tmp30 = ifn_612.Invoke_O__O(arg_613) } else { tmp30 = linked_611.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_610, arg_613) } }
//line :163:1
					arg_588 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp29, nil, tmp30, nil)).Ref(); var arg_589 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_586 == nil { tmp23 = ifn_587.Invoke_O_O__O(arg_588, arg_589) } else { tmp23 = linked_586.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_585, arg_588, arg_589) }
//line :162:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp23)))
				}



				var tmp34 any = A_arbace_c_runtime_A_const_101; var tmp35 any; var root_529 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = b__11; if linked_530 == nil { tmp35 = ifn_531.Invoke_O__O(arg_532) } else { tmp35 = linked_530.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_529, arg_532) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp34, tmp35) { var root_533 any = A_arbace_c_runtime_A_const_105.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = b__11; if linked_534 == nil { return ifn_535.Invoke_O__O(arg_536) } else { return linked_534.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_533, arg_536) } } else { var tmp36 any; var root_537 any = A_arbace_c_runtime_A_const_106.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var root_542 any = A_arbace_c_runtime_A_const_105.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = b__11; if linked_543 == nil { arg_540 = ifn_544.Invoke_O__O(arg_545) } else { arg_540 = linked_543.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_542, arg_545) }; var arg_541 any; if jrt.J2g_Truth(lang.RT_Nth_O_I__O_NoInit(b__11, lang.RT_IntCast_J__I_NoInit(2))) { var tmp37 any = A_arbace_c_runtime_A_const_103; arg_541 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, lang.RT_Nth_O_I__O_NoInit(b__11, lang.RT_IntCast_J__I_NoInit(2)))) } else { arg_541 = lang.PersistentArrayMap_EMPTY.Ref() }; if linked_538 == nil { tmp36 = ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { tmp36 = linked_538.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp36))) } } else {
//line :157:1
					if A_arbace_c_runtime_A_const_33 != nil {










						return lang.IFn_Cast(linked__9).Invoke__O() } else {
//line :157:1
							return nil } } } }
//line :147:1
func A_arbace_c_runtime_link_text_direct__676000078_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_runtime_link_text_direct__676000078_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_direct__676000078_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :147:1
func (t *A_arbace_c_runtime_link_text_direct__676000078_A) Ctor_O_O_O(c__lib, c__srcs, c__units any) { t.F_lib = c__lib; t.F_srcs = c__srcs; t.F_units = c__units }
//line :147:1
func (t *A_arbace_c_runtime_link_text_direct__676000078_A) Invoke_O__O(self any) any {





	var root_454 any = A_arbace_c_runtime_A_const_92.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_c_build.A_arbace_c_build_program_text_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_93.GetRawRoot__O()); var tmp2 any; var root_464 any = A_arbace_c_runtime_A_const_88.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var root_469 any = A_arbace_c_runtime_A_const_94.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = t.F_units; if linked_470 == nil { arg_467 = ifn_471.Invoke_O__O(arg_472) } else { arg_467 = linked_470.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_469, arg_472) }; var arg_468 any; var root_473 any = A_arbace_c_runtime_A_const_95.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any; var fnbody__484 any = A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_New_O(t.F_lib); var tmp3 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__484); A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_fn_class = fncls__483d; tmp3 = fncls__483d } else { tmp3 = fncls__483 }; arg_476 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__484, tmp3, nil); var arg_477 any = t.F_srcs; if linked_474 == nil { arg_468 = ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { arg_468 = linked_474.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_473, arg_476, arg_477) }; if linked_465 == nil { tmp2 = ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { tmp2 = linked_465.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; arg_457 = tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_runtime_A_const_97, jrt.Boolean_TRUE.Ref()); if linked_455 == nil { return ifn_456.Invoke_O__O(arg_457) } else { return linked_455.(*aot_arbace_c_build.A_arbace_c_build_program_text_A).Invoke_O_O__O(root_454, arg_457) } }
//line :147:1
func A_arbace_c_runtime_link_text_fn__676000070_A_New() *A_arbace_c_runtime_link_text_fn__676000070_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000070_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_c_runtime_link_text_fn__676000070_A) Ctor() {}
//line :147:1
func (t *A_arbace_c_runtime_link_text_fn__676000070_A) Invoke_O_O__O(self, p1__676000065_SHARP___1 any) any { var root_376 any = A_arbace_c_runtime_A_const_81.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any; var root_380 any = A_arbace_c_runtime_A_const_82.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var tmp1 *lang.Keyword = A_arbace_c_runtime_A_const_83; var arg_383 any = tmp1.Invoke_O__O(A_arbace_c_runtime_A_const_60.Invoke_O__O(p1__676000065_SHARP___1)); if linked_381 == nil { arg_379 = ifn_382.Invoke_O__O(arg_383) } else { arg_379 = linked_381.(*aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_380, arg_383) }; if linked_377 == nil { return ifn_378.Invoke_O__O(arg_379) } else { return linked_377.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_376, arg_379) } }
//line :147:1
func A_arbace_c_runtime_link_text_linked__676000082_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_runtime_link_text_linked__676000082_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_linked__676000082_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :147:1
func (t *A_arbace_c_runtime_link_text_linked__676000082_A) Ctor_O_O_O(c__lib, c__srcs, c__units any) { t.F_lib = c__lib; t.F_srcs = c__srcs; t.F_units = c__units }
//line :147:1
func (t *A_arbace_c_runtime_link_text_linked__676000082_A) Invoke_O__O(self any) any {







	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_98.GetRawRoot__O()); var tmp2 any; var root_493 any = A_arbace_c_runtime_A_const_88.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any; var root_498 any = A_arbace_c_runtime_A_const_99.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = A_arbace_c_runtime_A_const_58.GetRawRoot__O(); var arg_502 any = t.F_units; if linked_499 == nil { arg_496 = ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { arg_496 = linked_499.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) }; var arg_497 any; var root_503 any = A_arbace_c_runtime_A_const_95.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var fnbody__514 any = A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_New_O(t.F_lib); var tmp3 *jrt.Class; var fncls__513 *jrt.Class = A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_fn_class; if fncls__513 == nil { var fncls__513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__514); A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_fn_class = fncls__513d; tmp3 = fncls__513d } else { tmp3 = fncls__513 }; arg_506 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__514, tmp3, nil); var arg_507 any = t.F_srcs; if linked_504 == nil { arg_497 = ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { arg_497 = linked_504.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }; if linked_494 == nil { tmp2 = ifn_495.Invoke_O_O__O(arg_496, arg_497) } else { tmp2 = linked_494.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_493, arg_496, arg_497) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_runtime_A_const_97, jrt.Boolean_TRUE.Ref()) }
//line :148:1
func A_arbace_c_runtime_link_text_fn__676000072_A_New() *A_arbace_c_runtime_link_text_fn__676000072_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000072_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_c_runtime_link_text_fn__676000072_A) Ctor() {}
//line :148:1
func (t *A_arbace_c_runtime_link_text_fn__676000072_A) Invoke_O_O__O(self, p1__676000066_SHARP___1 any) any { var root_395 any = A_arbace_c_runtime_A_const_84.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var root_399 any = A_arbace_c_runtime_A_const_85.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var tmp1 *lang.Keyword = A_arbace_c_runtime_A_const_83; var arg_402 any = tmp1.Invoke_O__O(A_arbace_c_runtime_A_const_60.Invoke_O__O(p1__676000066_SHARP___1)); var arg_403 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_80.GetRawRoot__O()); var tmp3 any = A_arbace_c_runtime_A_const_83; var tmp4 any; var root_409 any = A_arbace_c_runtime_A_const_86.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var tmp5 *lang.Keyword = A_arbace_c_runtime_A_const_87; var arg_412 any = tmp5.Invoke_O__O(A_arbace_c_runtime_A_const_60.Invoke_O__O(p1__676000066_SHARP___1)); if linked_410 == nil { tmp4 = ifn_411.Invoke_O__O(arg_412) } else { tmp4 = linked_410.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_409, arg_412) }; arg_403 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_400 == nil { arg_398 = ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { arg_398 = linked_400.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_399, arg_402, arg_403) }; if linked_396 == nil { return ifn_397.Invoke_O__O(arg_398) } else { return linked_396.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_395, arg_398) } }

func A_arbace_c_runtime_link_text_fn__676000074_A_New() *A_arbace_c_runtime_link_text_fn__676000074_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000074_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_c_runtime_link_text_fn__676000074_A) Ctor() {}
//line :150:1
func (t *A_arbace_c_runtime_link_text_fn__676000074_A) Invoke_O_O__O(self, p1__676000067_SHARP___1 any) any { var tmp1 any; var root_425 any = A_arbace_c_runtime_A_const_28.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = p1__676000067_SHARP___1; var arg_429 any = Lit_25; if linked_426 == nil { tmp1 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp1 = linked_426.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; if jrt.J2g_Truth(tmp1) { var root_430 any = A_arbace_c_runtime_A_const_30.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = p1__676000067_SHARP___1; var arg_434 any = A_arbace_c_runtime_A_const_90; if linked_431 == nil { return ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { return linked_431.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) } } else { return nil } }

func A_arbace_c_runtime_link_text_fn__676000076_A_New_O(p0 any) *A_arbace_c_runtime_link_text_fn__676000076_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000076_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_c_runtime_link_text_fn__676000076_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :152:1
func (t *A_arbace_c_runtime_link_text_fn__676000076_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_runtime_A_const_68.GetRawRoot__O()); var tmp3 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(t.F_srcs)).Ref(); var tmp4 any; var t_ any = t.F_srcs; t.F_srcs = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O_O__O(Lit_26, tmp3, tmp4) }; return nil }(); var root_449 any = A_arbace_c_runtime_A_const_63.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; if linked_450 == nil { ifn_451.Invoke__O() } else { linked_450.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_449) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_New_O(p0 any) *A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A) Ctor_O(c__lib any) { t.F_lib = c__lib }
//line :153:1
func (t *A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A) Invoke_O_O__O(self, s__1 any) any { var root_478 any = A_arbace_c_runtime_A_const_96.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_c_musl.A_arbace_c_musl_checked_unit_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = t.F_lib; var arg_482 any = s__1; if linked_479 == nil { return ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { return linked_479.(*aot_arbace_c_musl.A_arbace_c_musl_checked_unit_A).Invoke_O_O_O__O(root_478, arg_481, arg_482) } }

func A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_New_O(p0 any) *A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A{}; t.Ctor_O(p0); return t }
//line :155:1
func (t *A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A) Ctor_O(c__lib any) { t.F_lib = c__lib }
//line :155:1
func (t *A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A) Invoke_O_O__O(self, s__1 any) any { var root_508 any = A_arbace_c_runtime_A_const_100.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_c_runtime_lib_fragment_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = t.F_lib; var arg_512 any = s__1; if linked_509 == nil { return ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { return linked_509.(*A_arbace_c_runtime_lib_fragment_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) } }




func A_arbace_c_runtime_link_text_fn__676000086_A_New_O(p0 any) *A_arbace_c_runtime_link_text_fn__676000086_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000086_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_c_runtime_link_text_fn__676000086_A) Ctor_O(c__direct any) { t.F_direct = c__direct }
//line :160:1
func (t *A_arbace_c_runtime_link_text_fn__676000086_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any = A_arbace_c_runtime_A_const_101; var tmp3 any; var t_ any = t.F_direct; t.F_direct = nil; tmp3 = t_; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(tmp3).Invoke__O()) }; return nil }(); if tmp4 != nil { if lang.ExceptionInfo_InstanceOf(tmp4) { var x__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp4); var tmp5 any = A_arbace_c_runtime_A_const_102; var tmp6 any = x__3.GetMessage__String().Ref(); var tmp7 *lang.Keyword = A_arbace_c_runtime_A_const_103; var tmp8 any; var root_517 any = A_arbace_c_runtime_A_const_104.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = x__3; if linked_518 == nil { tmp8 = ifn_519.Invoke_O__O(arg_520) } else { tmp8 = linked_518.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_517, arg_520) }; tmp1 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7.Invoke_O__O(tmp8)) } else { panic(tmp4) } }; return tmp1 }
func A_arbace_c_runtime_link_text_fn__676000088_A_New_O(p0 any) *A_arbace_c_runtime_link_text_fn__676000088_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000088_A{}; t.Ctor_O(p0); return t }
//line :161:1
func (t *A_arbace_c_runtime_link_text_fn__676000088_A) Ctor_O(c__linked any) { t.F_linked = c__linked }
//line :161:1
func (t *A_arbace_c_runtime_link_text_fn__676000088_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any = A_arbace_c_runtime_A_const_101; var tmp3 any; var t_ any = t.F_linked; t.F_linked = nil; tmp3 = t_; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(tmp3).Invoke__O()) }; return nil }(); if tmp4 != nil { if lang.ExceptionInfo_InstanceOf(tmp4) { var x__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp4); var tmp5 any = A_arbace_c_runtime_A_const_102; var tmp6 any = x__3.GetMessage__String().Ref(); var tmp7 *lang.Keyword = A_arbace_c_runtime_A_const_103; var tmp8 any; var root_523 any = A_arbace_c_runtime_A_const_104.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = x__3; if linked_524 == nil { tmp8 = ifn_525.Invoke_O__O(arg_526) } else { tmp8 = linked_524.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_523, arg_526) }; tmp1 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7.Invoke_O__O(tmp8)) } else { panic(tmp4) } }; return tmp1 }
func A_arbace_c_runtime_link_text_fn__676000090_A_New() *A_arbace_c_runtime_link_text_fn__676000090_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000090_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_c_runtime_link_text_fn__676000090_A) Ctor() {}
//line :162:1
func (t *A_arbace_c_runtime_link_text_fn__676000090_A) Invoke_O_O__O(self, p1__676000068_SHARP___1 any) any { var tmp1 any; var root_560 any = A_arbace_c_runtime_A_const_107.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = p1__676000068_SHARP___1; if linked_561 == nil { tmp1 = ifn_562.Invoke_O__O(arg_563) } else { tmp1 = linked_561.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_560, arg_563) }; if jrt.J2g_Truth(tmp1) { var root_564 any = A_arbace_c_runtime_A_const_108.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, A_arbace_c_runtime_normalize_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = p1__676000068_SHARP___1; if linked_565 == nil { return ifn_566.Invoke_O__O(arg_567) } else { return linked_565.(*A_arbace_c_runtime_normalize_A).Invoke_O_O__O(root_564, arg_567) } } else { return p1__676000068_SHARP___1 } }
//line :162:1
func A_arbace_c_runtime_link_text_fn__676000092_A_New() *A_arbace_c_runtime_link_text_fn__676000092_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_link_text_fn__676000092_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_c_runtime_link_text_fn__676000092_A) Ctor() {}
//line :162:1
func (t *A_arbace_c_runtime_link_text_fn__676000092_A) Invoke_O_O__O(self, p1__676000069_SHARP___1 any) any { var tmp1 any; var root_575 any = A_arbace_c_runtime_A_const_107.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = p1__676000069_SHARP___1; if linked_576 == nil { tmp1 = ifn_577.Invoke_O__O(arg_578) } else { tmp1 = linked_576.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_575, arg_578) }; if jrt.J2g_Truth(tmp1) { var root_579 any = A_arbace_c_runtime_A_const_108.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, A_arbace_c_runtime_normalize_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = p1__676000069_SHARP___1; if linked_580 == nil { return ifn_581.Invoke_O__O(arg_582) } else { return linked_580.(*A_arbace_c_runtime_normalize_A).Invoke_O_O__O(root_579, arg_582) } } else { return p1__676000069_SHARP___1 } }







func A_arbace_c_runtime_build_linked_A_New() *A_arbace_c_runtime_build_linked_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_build_linked_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_c_runtime_build_linked_A) Ctor() {}
//line :170:1
func (t *A_arbace_c_runtime_build_linked_A) Invoke_O_O_O__O(self, lib__0, units__1 any) any {


	var root_614 any = A_arbace_c_runtime_A_const_109.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_c_build.A_arbace_c_build_read_program_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any; var root_618 any = A_arbace_c_runtime_A_const_110.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_c_runtime_link_text_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = lib__0; var arg_622 any = units__1; if linked_619 == nil { arg_617 = ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { arg_617 = linked_619.(*A_arbace_c_runtime_link_text_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) }; if linked_615 == nil { return ifn_616.Invoke_O__O(arg_617) } else { return linked_615.(*aot_arbace_c_build.A_arbace_c_build_read_program_A).Invoke_O_O__O(root_614, arg_617)
	} }
func A_arbace_c_runtime_prebuild_A_New() *A_arbace_c_runtime_prebuild_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuild_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_c_runtime_prebuild_A) Ctor() {}
//line :175:1
func (t *A_arbace_c_runtime_prebuild_A) Invoke_O_O_O__O(self, lib__0, threads__1 any) any { var srcs__3 any; var root_623 any = A_arbace_c_runtime_A_const_94.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_625 lang.IFn; if



	linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any; var root_627 any = A_arbace_c_runtime_A_const_81.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = A_arbace_c_runtime_A_const_111.Invoke_O__O(lib__0); if linked_628 == nil { arg_626 = ifn_629.Invoke_O__O(arg_630) } else { arg_626 = linked_628.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_627, arg_630) }; if linked_624 == nil { srcs__3 = ifn_625.Invoke_O__O(arg_626) } else { srcs__3 = linked_624.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_623, arg_626) }; var q__4 any = /*line :175:1*/jrt.ConcurrentLinkedQueue_New_Collection(jrt.Collection_Cast(srcs__3)); var refused__5 any; var root_631 any = A_arbace_c_runtime_A_const_112.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_633 lang.IFn; if





	linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = A_arbace_c_runtime_A_const_31; if linked_632 == nil { refused__5 = ifn_633.Invoke_O__O(arg_634) } else { refused__5 = linked_632.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_631, arg_634) }; var made__6 any; var root_635 any = /*line :175:1*/A_arbace_c_runtime_A_const_112.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_637 lang.IFn; if






	linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = A_arbace_c_runtime_A_const_31; if linked_636 == nil { made__6 = ifn_637.Invoke_O__O(arg_638) } else { made__6 = linked_636.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_635, arg_638) }; var workers__7 any; var root_639 any = /*line :175:1*/A_arbace_c_runtime_A_const_113.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_641 lang.IFn; if







	linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any; var iter__1927001039__auto____7 any; var fnbody__788 any = A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_New_O_O_O_O(lib__0, refused__5, q__4, made__6); var tmp1 *jrt.Class; var fncls__787 *jrt.Class = A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_fn_class; if fncls__787 == nil { var fncls__787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__788); A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_fn_class = fncls__787d; tmp1 = fncls__787d } else { tmp1 = fncls__787 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__788, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp3 any; var root_789 any = A_arbace_c_runtime_A_const_122.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = threads__1; if linked_790 == nil { tmp3 = ifn_791.Invoke_O__O(arg_792) } else { tmp3 = linked_790.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_789, arg_792) }; arg_642 = tmp2.Invoke_O__O(tmp3); if linked_640 == nil { workers__7 = ifn_641.Invoke_O__O(arg_642) } else { workers__7 = linked_640.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_639, arg_642) }; var seq_676000110__8 any; var root_801 any = /*line :175:1*/A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_803 lang.IFn; if

















	linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = workers__7; if linked_802 == nil { seq_676000110__8 = ifn_803.Invoke_O__O(arg_804) } else { seq_676000110__8 = linked_802.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_801, arg_804) }; var chunk_676000111__9 any; var count_676000112__10 int64 = 0; var i_676000113__11 int64 = 0; L1:
//line :175:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_676000113__11, count_676000112__10) { var w__12 any = lang.Indexed_Cast(chunk_676000111__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_676000113__11)); var root_821 any = A_arbace_c_runtime_A_const_7.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = w__12; if linked_822 == nil { ifn_823.Invoke_O__O(arg_824) } else { linked_822.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_821, arg_824) }; seq_676000110__8, chunk_676000111__9, count_676000112__10, i_676000113__11 = seq_676000110__8, chunk_676000111__9, count_676000112__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_676000113__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_805 any = A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = seq_676000110__8; if linked_806 == nil { temp__1927000414__auto____12 = ifn_807.Invoke_O__O(arg_808) } else { temp__1927000414__auto____12 = linked_806.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_805, arg_808) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_676000110__13 any = temp__1927000414__auto____12; var tmp4 any; var root_809 any = A_arbace_c_runtime_A_const_21.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = seq_676000110__13; if linked_810 == nil { tmp4 = ifn_811.Invoke_O__O(arg_812) } else { tmp4 = linked_810.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_809, arg_812) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_813 any = A_arbace_c_runtime_A_const_22.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = seq_676000110__13; if linked_814 == nil { c__1927000678__auto____14 = ifn_815.Invoke_O__O(arg_816) } else { c__1927000678__auto____14 = linked_814.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_813, arg_816) }; var tmp5 any; var root_825 any = A_arbace_c_runtime_A_const_25.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = seq_676000110__13; if linked_826 == nil { tmp5 = ifn_827.Invoke_O__O(arg_828) } else { tmp5 = linked_826.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_825, arg_828) }; seq_676000110__8, chunk_676000111__9, count_676000112__10, i_676000113__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_817 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = seq_676000110__13; if linked_818 == nil { w__14 = ifn_819.Invoke_O__O(arg_820) } else { w__14 = linked_818.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_817, arg_820) }; var root_829 any = A_arbace_c_runtime_A_const_7.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = w__14; if linked_830 == nil { ifn_831.Invoke_O__O(arg_832) } else { linked_830.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_829, arg_832) }; var tmp6 any; var root_833 any = A_arbace_c_runtime_A_const_26.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = seq_676000110__13; if linked_834 == nil { tmp6 = ifn_835.Invoke_O__O(arg_836) } else { tmp6 = linked_834.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_833, arg_836) }; seq_676000110__8, chunk_676000111__9, count_676000112__10, i_676000113__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :175:1
		break L1 }; var tmp7 any = A_arbace_c_runtime_A_const_87; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(srcs__3)).Ref(); var tmp9 any = A_arbace_c_runtime_A_const_123; var tmp10 any; var root_793 any = A_arbace_c_runtime_A_const_7.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_795 lang.IFn; if



	linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = made__6; if linked_794 == nil { tmp10 = ifn_795.Invoke_O__O(arg_796) } else { tmp10 = linked_794.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_793, arg_796) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_c_runtime_A_const_124; var tmp13 any; var root_797 any = /*line :175:1*/A_arbace_c_runtime_A_const_7.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_799 lang.IFn; if



	linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = refused__5; if linked_798 == nil { tmp13 = ifn_799.Invoke_O__O(arg_800) } else { tmp13 = linked_798.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_797, arg_800) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_c_runtime_A_const_125; return /*line :175:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, A_arbace_c_runtime_A_const_54.Invoke_O__O(lib__0))) }







func A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_runtime_prebuild_iter__676000096__676000100_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuild_iter__676000096__676000100_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :183:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_A) Ctor_O_O_O_O(c__lib, c__refused, c__q, c__made any) { t.F_lib = c__lib; t.F_refused = c__refused; t.F_q = c__q; t.F_made = c__made }
//line :183:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_A) Invoke_O_O__O(self, s__676000097__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__786 any = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_New_O_O_O_O_O_O(t.F_lib, t.F_refused, t.F_q, t.F_made, self, s__676000097__1); var tmp2 *jrt.Class; var fncls__785 *jrt.Class = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_fn_class; if fncls__785 == nil { var fncls__785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__786); A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_fn_class = fncls__785d; tmp2 = fncls__785d } else { tmp2 = fncls__785 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__786, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :183:1
func A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :183:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A) Ctor_O_O_O_O_O_O(c__lib, c__refused, c__q, c__made, c__iter__676000096, c__s__676000097 any) { t.F_lib = c__lib; t.F_refused = c__refused; t.F_q = c__q; t.F_made = c__made; t.F_iter__676000096 = c__iter__676000096; t.F_s__676000097 = c__s__676000097 }
//line :183:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A) Invoke_O__O(self any) any { { var s__676000097__1 any; var t_ any = t.F_s__676000097; t.F_s__676000097 = nil; s__676000097__1 = t_; for { var temp__1927000414__auto____2 any; var root_643 any = A_arbace_c_runtime_A_const_20.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__676000097__1; if linked_644 == nil { temp__1927000414__auto____2 = ifn_645.Invoke_O__O(arg_646) } else { temp__1927000414__auto____2 = linked_644.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_643, arg_646) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__676000097__3 any = temp__1927000414__auto____2; var tmp1 any; var root_647 any = A_arbace_c_runtime_A_const_21.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = s__676000097__3; if linked_648 == nil { tmp1 = ifn_649.Invoke_O__O(arg_650) } else { tmp1 = linked_648.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_647, arg_650) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_651 any = A_arbace_c_runtime_A_const_22.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = s__676000097__3; if linked_652 == nil { c__1927001037__auto____4 = ifn_653.Invoke_O__O(arg_654) } else { c__1927001037__auto____4 = linked_652.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_651, arg_654) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__676000099__6 any; var root_655 any = A_arbace_c_runtime_A_const_37.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_656 == nil { b__676000099__6 = ifn_657.Invoke_O__O(arg_658) } else { b__676000099__6 = linked_656.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_655, arg_658) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__707 any = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_New_O_O_O_O_O_I_O(t.F_lib, t.F_refused, b__676000099__6, t.F_q, t.F_made, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_fn_class; if fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__707); A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_fn_class = fncls__706d; tmp3 = fncls__706d } else { tmp3 = fncls__706 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__707, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_708 any = A_arbace_c_runtime_A_const_40.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any; var root_713 any = A_arbace_c_runtime_A_const_41.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = b__676000099__6; if linked_714 == nil { arg_711 = ifn_715.Invoke_O__O(arg_716) } else { arg_711 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_713, arg_716) }; var arg_712 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__676000096); var tmp5 any; var root_717 any = A_arbace_c_runtime_A_const_25.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = s__676000097__3; if linked_718 == nil { tmp5 = ifn_719.Invoke_O__O(arg_720) } else { tmp5 = linked_718.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_717, arg_720) }; arg_712 = tmp4.Invoke_O__O(tmp5); if linked_709 == nil { return ifn_710.Invoke_O_O__O(arg_711, arg_712) } else { return linked_709.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_708, arg_711, arg_712) } } else { var root_721 any = A_arbace_c_runtime_A_const_40.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var root_726 any = A_arbace_c_runtime_A_const_41.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = b__676000099__6; if linked_727 == nil { arg_724 = ifn_728.Invoke_O__O(arg_729) } else { arg_724 = linked_727.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_726, arg_729) }; var arg_725 any; if linked_722 == nil { return ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { return linked_722.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) } } } else { var ___4 any; var root_730 any = A_arbace_c_runtime_A_const_23.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_732 lang.IFn; _ = ___4; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__676000097__3; if linked_731 == nil { ___4 = ifn_732.Invoke_O__O(arg_733) } else { ___4 = linked_731.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_730, arg_733) }; var root_734 any = A_arbace_c_runtime_A_const_42.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var root_739 any = A_arbace_c_runtime_A_const_114.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_741 lang.IFn
														if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any; var fnbody__780 any = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_New_O_O_O_O(t.F_lib, t.F_refused, t.F_q, t.F_made); var tmp6 *jrt.Class; var fncls__779 *jrt.Class = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_fn_class; if fncls__779 == nil { var fncls__779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__780); A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_fn_class = fncls__779d; tmp6 = fncls__779d } else { tmp6 = fncls__779 }; arg_742 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__780, tmp6, nil); if linked_740 == nil { arg_737 = ifn_741.Invoke_O__O(arg_742) } else { arg_737 = linked_740.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_739, arg_742) }
//line :183:1
	var arg_738 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__676000096); var tmp8 any; var root_781 any = A_arbace_c_runtime_A_const_43.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = s__676000097__3; if linked_782 == nil { tmp8 = ifn_783.Invoke_O__O(arg_784) } else { tmp8 = linked_782.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_781, arg_784) }; arg_738 = tmp7.Invoke_O__O(tmp8); if linked_735 == nil { return ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { return linked_735.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :183:1
func A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :183:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A) Ctor_O_O_O_O_O_I_O(c__lib, c__refused, c__b__676000099, c__q, c__made any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_lib = c__lib; t.F_refused = c__refused; t.F_b__676000099 = c__b__676000099; t.F_q = c__q; t.F_made = c__made; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :183:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A) Invoke_O__O(self any) any { { var i__676000098__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__676000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__676000098__1)); var root_659 any = A_arbace_c_runtime_A_const_39.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_661 lang.IFn; _ = ___2; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = t.F_b__676000099; var arg_663 any; var root_664 any = A_arbace_c_runtime_A_const_114.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_666 lang.IFn
																if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any; var fnbody__705 any = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_New_O_O_O_O(t.F_lib, t.F_refused, t.F_q, t.F_made); var tmp2 *jrt.Class; var fncls__704 *jrt.Class = A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_fn_class; if fncls__704 == nil { var fncls__704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__705); A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_fn_class = fncls__704d; tmp2 = fncls__704d } else { tmp2 = fncls__704 }; arg_667 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__705, tmp2, nil); if linked_665 == nil { arg_663 = ifn_666.Invoke_O__O(arg_667) } else { arg_663 = linked_665.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_664, arg_667) }
//line :183:1
	if linked_660 == nil { ifn_661.Invoke_O_O__O(arg_662, arg_663) } else { linked_660.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_659, arg_662, arg_663) }; i__676000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__676000098__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :184:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A) Ctor_O_O_O_O(c__lib, c__refused, c__q, c__made any) { t.F_lib = c__lib; t.F_refused = c__refused; t.F_q = c__q; t.F_made = c__made }
//line :184:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var had__3 bool = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, A_arbace_c_runtime_A_const_54.Invoke_O__O(t.F_lib), nil, s__2, nil))).Exists__Z(); var fr__4 any; var root_668 any = A_arbace_c_runtime_A_const_100.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, A_arbace_c_runtime_lib_fragment_A_fn_class); var ifn_670 lang.IFn

		if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = t.F_lib; var arg_672 any = s__2; if linked_669 == nil { fr__4 = ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { fr__4 = linked_669.(*A_arbace_c_runtime_lib_fragment_A).Invoke_O_O_O__O(root_668, arg_671, arg_672) }
		if had__3 { } else { var root_673 any = A_arbace_c_runtime_A_const_115.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = t.F_made; var arg_677 any = A_arbace_c_runtime_A_const_116.GetRawRoot__O(); if linked_674 == nil { ifn_675.Invoke_O_O__O(arg_676, arg_677) } else { linked_674.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_673, arg_676, arg_677) } }
		var root_678 any = A_arbace_c_runtime_A_const_115.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = t.F_refused; var arg_682 any = A_arbace_c_runtime_A_const_117.GetRawRoot__O(); var arg_683 any; var tmp1 any; var root_684 any = A_arbace_c_runtime_A_const_118.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = A_arbace_c_runtime_A_const_102; var arg_688 any; var root_689 any = A_arbace_c_runtime_A_const_85.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any; var root_694 any = A_arbace_c_runtime_A_const_95.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = A_arbace_c_runtime_A_const_119; var arg_698 any = A_arbace_c_runtime_A_const_120.Invoke_O__O(fr__4); if linked_695 == nil { arg_692 = ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { arg_692 = linked_695.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_694, arg_697, arg_698) }; var arg_693 any; var root_699 any = A_arbace_c_runtime_A_const_89.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = A_arbace_c_runtime_A_const_119; var arg_703 any = A_arbace_c_runtime_A_const_121.Invoke_O__O(fr__4); if linked_700 == nil { arg_693 = ifn_701.Invoke_O_O__O(arg_702, arg_703) } else { arg_693 = linked_700.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_699, arg_702, arg_703) }; if linked_690 == nil { arg_688 = ifn_691.Invoke_O_O__O(arg_692, arg_693) } else { arg_688 = linked_690.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_689, arg_692, arg_693) }; if linked_685 == nil { tmp1 = ifn_686.Invoke_O_O__O(arg_687, arg_688) } else { tmp1 = linked_685.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_684, arg_687, arg_688) }; arg_683 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref(); if linked_679 == nil { ifn_680.Invoke_O_O_O__O(arg_681, arg_682, arg_683) } else { linked_679.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_678, arg_681, arg_682, arg_683) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_c_runtime_A_const_51.Invoke_O__O(t.F_lib))).Remove_O__O(s__2)
		continue L2 } else {
//line :186:1
			return nil } } }; /*line :184:1*/panic("j2g: unreachable") }
//line :184:1
func A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :184:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A) Ctor_O_O_O_O(c__lib, c__refused, c__q, c__made any) { t.F_lib = c__lib; t.F_refused = c__refused; t.F_q = c__q; t.F_made = c__made }
//line :184:1
func (t *A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var had__3 bool = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, A_arbace_c_runtime_A_const_54.Invoke_O__O(t.F_lib), nil, s__2, nil))).Exists__Z(); var fr__4 any; var root_743 any = A_arbace_c_runtime_A_const_100.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, A_arbace_c_runtime_lib_fragment_A_fn_class); var ifn_745 lang.IFn

		if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = t.F_lib; var arg_747 any = s__2; if linked_744 == nil { fr__4 = ifn_745.Invoke_O_O__O(arg_746, arg_747) } else { fr__4 = linked_744.(*A_arbace_c_runtime_lib_fragment_A).Invoke_O_O_O__O(root_743, arg_746, arg_747) }
		if had__3 { } else { var root_748 any = A_arbace_c_runtime_A_const_115.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = t.F_made; var arg_752 any = A_arbace_c_runtime_A_const_116.GetRawRoot__O(); if linked_749 == nil { ifn_750.Invoke_O_O__O(arg_751, arg_752) } else { linked_749.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_748, arg_751, arg_752) } }
		var root_753 any = A_arbace_c_runtime_A_const_115.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = t.F_refused; var arg_757 any = A_arbace_c_runtime_A_const_117.GetRawRoot__O(); var arg_758 any; var tmp1 any; var root_759 any = A_arbace_c_runtime_A_const_118.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = A_arbace_c_runtime_A_const_102; var arg_763 any; var root_764 any = A_arbace_c_runtime_A_const_85.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any; var root_769 any = A_arbace_c_runtime_A_const_95.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = A_arbace_c_runtime_A_const_119; var arg_773 any = A_arbace_c_runtime_A_const_120.Invoke_O__O(fr__4); if linked_770 == nil { arg_767 = ifn_771.Invoke_O_O__O(arg_772, arg_773) } else { arg_767 = linked_770.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_769, arg_772, arg_773) }; var arg_768 any; var root_774 any = A_arbace_c_runtime_A_const_89.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = A_arbace_c_runtime_A_const_119; var arg_778 any = A_arbace_c_runtime_A_const_121.Invoke_O__O(fr__4); if linked_775 == nil { arg_768 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { arg_768 = linked_775.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; if linked_765 == nil { arg_763 = ifn_766.Invoke_O_O__O(arg_767, arg_768) } else { arg_763 = linked_765.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_764, arg_767, arg_768) }; if linked_760 == nil { tmp1 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { tmp1 = linked_760.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; arg_758 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref(); if linked_754 == nil { ifn_755.Invoke_O_O_O__O(arg_756, arg_757, arg_758) } else { linked_754.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_753, arg_756, arg_757, arg_758) }
		jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_c_runtime_A_const_51.Invoke_O__O(t.F_lib))).Remove_O__O(s__2)
		continue L2 } else {
//line :186:1
			return nil } } }; /*line :184:1*/panic("j2g: unreachable") }












































































































type A_arbace_c_runtime_A struct{ jrt.Object }

var A_arbace_c_runtime_A_const_pool *jrt.RefArray

var A_arbace_c_runtime_A_const_0 *lang.Var

var A_arbace_c_runtime_A_const_1 any

var A_arbace_c_runtime_A_const_2 *lang.Var

var A_arbace_c_runtime_A_const_3 any

var A_arbace_c_runtime_A_const_4 any

var A_arbace_c_runtime_A_const_5 any

var A_arbace_c_runtime_A_const_6 *lang.Var

var A_arbace_c_runtime_A_const_7 *lang.Var

var A_arbace_c_runtime_A_const_8 *lang.Var

var A_arbace_c_runtime_A_const_9 *lang.Var

var A_arbace_c_runtime_A_const_10 any

var A_arbace_c_runtime_A_const_11 *lang.Var

var A_arbace_c_runtime_A_const_12 *lang.Keyword

var A_arbace_c_runtime_A_const_13 *lang.Var

var A_arbace_c_runtime_A_const_14 *lang.Keyword

var A_arbace_c_runtime_A_const_15 *lang.Var

var A_arbace_c_runtime_A_const_16 *lang.Var

var A_arbace_c_runtime_A_const_17 any

var A_arbace_c_runtime_A_const_18 *lang.Keyword

var A_arbace_c_runtime_A_const_19 *lang.Var

var A_arbace_c_runtime_A_const_20 *lang.Var

var A_arbace_c_runtime_A_const_21 *lang.Var

var A_arbace_c_runtime_A_const_22 *lang.Var

var A_arbace_c_runtime_A_const_23 *lang.Var

var A_arbace_c_runtime_A_const_24 *lang.Var

var A_arbace_c_runtime_A_const_25 *lang.Var

var A_arbace_c_runtime_A_const_26 *lang.Var

var A_arbace_c_runtime_A_const_27 *lang.Var

var A_arbace_c_runtime_A_const_28 *lang.Var

var A_arbace_c_runtime_A_const_29 *lang.Var

var A_arbace_c_runtime_A_const_30 *lang.Var

var A_arbace_c_runtime_A_const_31 any

var A_arbace_c_runtime_A_const_32 *lang.Var

var A_arbace_c_runtime_A_const_33 *lang.Keyword

var A_arbace_c_runtime_A_const_34 *lang.Var

var A_arbace_c_runtime_A_const_35 *lang.Var

var A_arbace_c_runtime_A_const_36 *lang.Var

var A_arbace_c_runtime_A_const_37 *lang.Var

var A_arbace_c_runtime_A_const_38 *lang.Var

var A_arbace_c_runtime_A_const_39 *lang.Var

var A_arbace_c_runtime_A_const_40 *lang.Var

var A_arbace_c_runtime_A_const_41 *lang.Var

var A_arbace_c_runtime_A_const_42 *lang.Var

var A_arbace_c_runtime_A_const_43 *lang.Var

var A_arbace_c_runtime_A_const_44 *lang.Var

var A_arbace_c_runtime_A_const_45 *lang.Var

var A_arbace_c_runtime_A_const_46 *lang.Var

var A_arbace_c_runtime_A_const_47 *lang.Var

var A_arbace_c_runtime_A_const_48 *lang.Var

var A_arbace_c_runtime_A_const_49 *lang.Var

var A_arbace_c_runtime_A_const_50 *lang.Var

var A_arbace_c_runtime_A_const_51 *lang.Keyword

var A_arbace_c_runtime_A_const_52 *lang.Keyword

var A_arbace_c_runtime_A_const_53 *lang.Keyword

var A_arbace_c_runtime_A_const_54 *lang.Keyword

var A_arbace_c_runtime_A_const_55 *lang.Var

var A_arbace_c_runtime_A_const_56 *lang.Var

var A_arbace_c_runtime_A_const_57 *lang.Var

var A_arbace_c_runtime_A_const_58 *lang.Var

var A_arbace_c_runtime_A_const_59 *lang.Keyword

var A_arbace_c_runtime_A_const_60 *lang.Keyword

var A_arbace_c_runtime_A_const_61 *lang.Var

var A_arbace_c_runtime_A_const_62 *lang.Var

var A_arbace_c_runtime_A_const_63 *lang.Var

var A_arbace_c_runtime_A_const_64 *lang.Var

var A_arbace_c_runtime_A_const_65 *lang.Var

var A_arbace_c_runtime_A_const_66 *lang.Var

var A_arbace_c_runtime_A_const_67 *lang.Var

var A_arbace_c_runtime_A_const_68 *lang.Var

var A_arbace_c_runtime_A_const_69 *lang.Var

var A_arbace_c_runtime_A_const_70 *lang.Var

var A_arbace_c_runtime_A_const_71 *lang.Var

var A_arbace_c_runtime_A_const_72 *lang.Var

var A_arbace_c_runtime_A_const_73 *lang.Var

var A_arbace_c_runtime_A_const_74 *lang.Var

var A_arbace_c_runtime_A_const_75 *lang.Var

var A_arbace_c_runtime_A_const_76 *lang.Var

var A_arbace_c_runtime_A_const_77 *lang.Var

var A_arbace_c_runtime_A_const_78 any

var A_arbace_c_runtime_A_const_79 *lang.Var

var A_arbace_c_runtime_A_const_80 *lang.Var

var A_arbace_c_runtime_A_const_81 *lang.Var

var A_arbace_c_runtime_A_const_82 *lang.Var

var A_arbace_c_runtime_A_const_83 *lang.Keyword

var A_arbace_c_runtime_A_const_84 *lang.Var

var A_arbace_c_runtime_A_const_85 *lang.Var

var A_arbace_c_runtime_A_const_86 *lang.Var

var A_arbace_c_runtime_A_const_87 *lang.Keyword

var A_arbace_c_runtime_A_const_88 *lang.Var

var A_arbace_c_runtime_A_const_89 *lang.Var

var A_arbace_c_runtime_A_const_90 any

var A_arbace_c_runtime_A_const_91 *lang.Var

var A_arbace_c_runtime_A_const_92 *lang.Var

var A_arbace_c_runtime_A_const_93 *lang.Var

var A_arbace_c_runtime_A_const_94 *lang.Var

var A_arbace_c_runtime_A_const_95 *lang.Var

var A_arbace_c_runtime_A_const_96 *lang.Var

var A_arbace_c_runtime_A_const_97 *lang.Keyword

var A_arbace_c_runtime_A_const_98 *lang.Var

var A_arbace_c_runtime_A_const_99 *lang.Var

var A_arbace_c_runtime_A_const_100 *lang.Var

var A_arbace_c_runtime_A_const_101 *lang.Keyword

var A_arbace_c_runtime_A_const_102 *lang.Keyword

var A_arbace_c_runtime_A_const_103 *lang.Keyword

var A_arbace_c_runtime_A_const_104 *lang.Var

var A_arbace_c_runtime_A_const_105 *lang.Var

var A_arbace_c_runtime_A_const_106 *lang.Var

var A_arbace_c_runtime_A_const_107 *lang.Var

var A_arbace_c_runtime_A_const_108 *lang.Var

var A_arbace_c_runtime_A_const_109 *lang.Var

var A_arbace_c_runtime_A_const_110 *lang.Var

var A_arbace_c_runtime_A_const_111 *lang.Keyword

var A_arbace_c_runtime_A_const_112 *lang.Var

var A_arbace_c_runtime_A_const_113 *lang.Var

var A_arbace_c_runtime_A_const_114 *lang.Var

var A_arbace_c_runtime_A_const_115 *lang.Var

var A_arbace_c_runtime_A_const_116 *lang.Var

var A_arbace_c_runtime_A_const_117 *lang.Var

var A_arbace_c_runtime_A_const_118 *lang.Var

var A_arbace_c_runtime_A_const_119 *lang.Keyword

var A_arbace_c_runtime_A_const_120 *lang.Keyword

var A_arbace_c_runtime_A_const_121 *lang.Keyword

var A_arbace_c_runtime_A_const_122 *lang.Var

var A_arbace_c_runtime_A_const_123 *lang.Keyword

var A_arbace_c_runtime_A_const_124 *lang.Keyword

var A_arbace_c_runtime_A_const_125 *lang.Keyword

var A_arbace_c_runtime_A_init jrt.ClassInit

func A_arbace_c_runtime_A_Init() { if !A_arbace_c_runtime_A_init.Done() { A_arbace_c_runtime_A_init.Run(A_arbace_c_runtime_A_clinit) } }

func A_arbace_c_runtime_A_clinit() { A_arbace_c_runtime_A_clinit_p0(); A_arbace_c_runtime_A_clinit_p1(); A_arbace_c_runtime_A_clinit_p2(); A_arbace_c_runtime_A_clinit_p3(); A_arbace_c_runtime_A_clinit_p4(); A_arbace_c_runtime_A_clinit_p5(); A_arbace_c_runtime_A_clinit_p6(); A_arbace_c_runtime_A_clinit_p7(); A_arbace_c_runtime_A_clinit_p8(); A_arbace_c_runtime_A_clinit_p9(); A_arbace_c_runtime_A_clinit_p10() }

func A_arbace_c_runtime_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_runtime_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 159); A_arbace_c_runtime_A_const_0 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[33]); A_arbace_c_runtime_A_const_1 = A_arbace_c_runtime_A_const_pool.A[34]; A_arbace_c_runtime_A_const_2 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[35]); A_arbace_c_runtime_A_const_3 = A_arbace_c_runtime_A_const_pool.A[36]; A_arbace_c_runtime_A_const_4 = A_arbace_c_runtime_A_const_pool.A[37]; A_arbace_c_runtime_A_const_5 = A_arbace_c_runtime_A_const_pool.A[38]; A_arbace_c_runtime_A_const_6 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[39]); A_arbace_c_runtime_A_const_7 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[40]); A_arbace_c_runtime_A_const_8 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[41]); A_arbace_c_runtime_A_const_9 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[42]); A_arbace_c_runtime_A_const_10 = A_arbace_c_runtime_A_const_pool.A[43]; A_arbace_c_runtime_A_const_11 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[44]) }

func A_arbace_c_runtime_A_clinit_p1() { A_arbace_c_runtime_A_const_12 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[45]); A_arbace_c_runtime_A_const_13 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[46]); A_arbace_c_runtime_A_const_14 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[47]); A_arbace_c_runtime_A_const_15 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[48]); A_arbace_c_runtime_A_const_16 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[49]); A_arbace_c_runtime_A_const_17 = A_arbace_c_runtime_A_const_pool.A[50]; A_arbace_c_runtime_A_const_18 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[51]); A_arbace_c_runtime_A_const_19 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[52]); A_arbace_c_runtime_A_const_20 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[53]); A_arbace_c_runtime_A_const_21 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[54]); A_arbace_c_runtime_A_const_22 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[55]); A_arbace_c_runtime_A_const_23 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[56]) }

func A_arbace_c_runtime_A_clinit_p2() { A_arbace_c_runtime_A_const_24 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[57]); A_arbace_c_runtime_A_const_25 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[58]); A_arbace_c_runtime_A_const_26 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[59]); A_arbace_c_runtime_A_const_27 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[60]); A_arbace_c_runtime_A_const_28 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[61]); A_arbace_c_runtime_A_const_29 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[62]); A_arbace_c_runtime_A_const_30 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[63]); A_arbace_c_runtime_A_const_31 = A_arbace_c_runtime_A_const_pool.A[64]; A_arbace_c_runtime_A_const_32 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[65]); A_arbace_c_runtime_A_const_33 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[66]); A_arbace_c_runtime_A_const_34 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[67]); A_arbace_c_runtime_A_const_35 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[68]) }

func A_arbace_c_runtime_A_clinit_p3() { A_arbace_c_runtime_A_const_36 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[69]); A_arbace_c_runtime_A_const_37 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[70]); A_arbace_c_runtime_A_const_38 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[71]); A_arbace_c_runtime_A_const_39 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[72]); A_arbace_c_runtime_A_const_40 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[73]); A_arbace_c_runtime_A_const_41 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[74]); A_arbace_c_runtime_A_const_42 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[75]); A_arbace_c_runtime_A_const_43 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[76]); A_arbace_c_runtime_A_const_44 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[77]); A_arbace_c_runtime_A_const_45 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[78]); A_arbace_c_runtime_A_const_46 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[79]); A_arbace_c_runtime_A_const_47 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[80]) }

func A_arbace_c_runtime_A_clinit_p4() { A_arbace_c_runtime_A_const_48 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[81]); A_arbace_c_runtime_A_const_49 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[82]); A_arbace_c_runtime_A_const_50 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[83]); A_arbace_c_runtime_A_const_51 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[84]); A_arbace_c_runtime_A_const_52 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[85]); A_arbace_c_runtime_A_const_53 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[86]); A_arbace_c_runtime_A_const_54 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[87]); A_arbace_c_runtime_A_const_55 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[88]); A_arbace_c_runtime_A_const_56 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[89]); A_arbace_c_runtime_A_const_57 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[90]); A_arbace_c_runtime_A_const_58 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[91]); A_arbace_c_runtime_A_const_59 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[92]) }

func A_arbace_c_runtime_A_clinit_p5() { A_arbace_c_runtime_A_const_60 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[93]); A_arbace_c_runtime_A_const_61 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[94]); A_arbace_c_runtime_A_const_62 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[95]); A_arbace_c_runtime_A_const_63 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[96]); A_arbace_c_runtime_A_const_64 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[97]); A_arbace_c_runtime_A_const_65 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[98]); A_arbace_c_runtime_A_const_66 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[99]); A_arbace_c_runtime_A_const_67 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[100]); A_arbace_c_runtime_A_const_68 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[101]); A_arbace_c_runtime_A_const_69 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[102]); A_arbace_c_runtime_A_const_70 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[103]); A_arbace_c_runtime_A_const_71 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[104]) }

func A_arbace_c_runtime_A_clinit_p6() { A_arbace_c_runtime_A_const_72 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[105]); A_arbace_c_runtime_A_const_73 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[106]); A_arbace_c_runtime_A_const_74 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[107]); A_arbace_c_runtime_A_const_75 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[108]); A_arbace_c_runtime_A_const_76 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[109]); A_arbace_c_runtime_A_const_77 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[110]); A_arbace_c_runtime_A_const_78 = A_arbace_c_runtime_A_const_pool.A[111]; A_arbace_c_runtime_A_const_79 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[112]); A_arbace_c_runtime_A_const_80 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[113]); A_arbace_c_runtime_A_const_81 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[114]); A_arbace_c_runtime_A_const_82 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[115]); A_arbace_c_runtime_A_const_83 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[116]) }

func A_arbace_c_runtime_A_clinit_p7() { A_arbace_c_runtime_A_const_84 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[117]); A_arbace_c_runtime_A_const_85 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[118]); A_arbace_c_runtime_A_const_86 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[119]); A_arbace_c_runtime_A_const_87 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[120]); A_arbace_c_runtime_A_const_88 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[121]); A_arbace_c_runtime_A_const_89 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[122]); A_arbace_c_runtime_A_const_90 = A_arbace_c_runtime_A_const_pool.A[123]; A_arbace_c_runtime_A_const_91 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[124]); A_arbace_c_runtime_A_const_92 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[125]); A_arbace_c_runtime_A_const_93 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[126]); A_arbace_c_runtime_A_const_94 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[127]); A_arbace_c_runtime_A_const_95 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[128]) }

func A_arbace_c_runtime_A_clinit_p8() { A_arbace_c_runtime_A_const_96 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[129]); A_arbace_c_runtime_A_const_97 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[130]); A_arbace_c_runtime_A_const_98 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[131]); A_arbace_c_runtime_A_const_99 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[132]); A_arbace_c_runtime_A_const_100 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[133]); A_arbace_c_runtime_A_const_101 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[134]); A_arbace_c_runtime_A_const_102 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[135]); A_arbace_c_runtime_A_const_103 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[136]); A_arbace_c_runtime_A_const_104 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[137]); A_arbace_c_runtime_A_const_105 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[138]); A_arbace_c_runtime_A_const_106 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[139]); A_arbace_c_runtime_A_const_107 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[140]) }

func A_arbace_c_runtime_A_clinit_p9() { A_arbace_c_runtime_A_const_108 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[141]); A_arbace_c_runtime_A_const_109 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[142]); A_arbace_c_runtime_A_const_110 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[143]); A_arbace_c_runtime_A_const_111 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[144]); A_arbace_c_runtime_A_const_112 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[145]); A_arbace_c_runtime_A_const_113 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[146]); A_arbace_c_runtime_A_const_114 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[147]); A_arbace_c_runtime_A_const_115 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[148]); A_arbace_c_runtime_A_const_116 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[149]); A_arbace_c_runtime_A_const_117 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[150]); A_arbace_c_runtime_A_const_118 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[151]); A_arbace_c_runtime_A_const_119 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[152]) }

func A_arbace_c_runtime_A_clinit_p10() { A_arbace_c_runtime_A_const_120 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[153]); A_arbace_c_runtime_A_const_121 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[154]); A_arbace_c_runtime_A_const_122 = lang.Var_Cast(A_arbace_c_runtime_A_const_pool.A[155]); A_arbace_c_runtime_A_const_123 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[156]); A_arbace_c_runtime_A_const_124 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[157]); A_arbace_c_runtime_A_const_125 = lang.Keyword_Cast(A_arbace_c_runtime_A_const_pool.A[158]) }

func A_arbace_c_runtime_A_New() *A_arbace_c_runtime_A { A_arbace_c_runtime_A_Init(); t := &A_arbace_c_runtime_A{}; t.Ctor(); return t }

func (t *A_arbace_c_runtime_A) Ctor() {}

func (t *A_arbace_c_runtime_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_runtime_A) GetClass__Class() *jrt.Class { return A_arbace_c_runtime_A_class }

func (t *A_arbace_c_runtime_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_runtime_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_runtime_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_runtime_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_runtime_A); return ok }

func A_arbace_c_runtime_A_Cast(x any) *A_arbace_c_runtime_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_runtime_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_runtime_A_class)) }; return v }



type A_arbace_c_runtime_build_linked_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_build_linked_A_fn_class *jrt.Class



type A_arbace_c_runtime_cache_root_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_cache_root_A_fn_class *jrt.Class



type A_arbace_c_runtime_check_unit_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_check_unit_A_fn_class *jrt.Class



type A_arbace_c_runtime_embedded_bytes_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_embedded_bytes_A_fn_class *jrt.Class



type A_arbace_c_runtime_env_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_env_A_fn_class *jrt.Class



type A_arbace_c_runtime_eval676000004_A struct{ jrt.Object }

func A_arbace_c_runtime_eval676000004_A_New() *A_arbace_c_runtime_eval676000004_A { t := &A_arbace_c_runtime_eval676000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_runtime_eval676000004_A) Ctor() {}

func (t *A_arbace_c_runtime_eval676000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_runtime_eval676000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_runtime_eval676000004_A_class }

func (t *A_arbace_c_runtime_eval676000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_runtime_eval676000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_runtime_eval676000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_runtime_eval676000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_runtime_eval676000004_A); return ok }

func A_arbace_c_runtime_eval676000004_A_Cast(x any) *A_arbace_c_runtime_eval676000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_runtime_eval676000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_runtime_eval676000004_A_class)) }; return v }



type A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A_fn_class *jrt.Class



type A_arbace_c_runtime_eval676000008_A struct{ jrt.Object }

func A_arbace_c_runtime_eval676000008_A_New() *A_arbace_c_runtime_eval676000008_A { t := &A_arbace_c_runtime_eval676000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_runtime_eval676000008_A) Ctor() {}

func (t *A_arbace_c_runtime_eval676000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_runtime_eval676000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_runtime_eval676000008_A_class }

func (t *A_arbace_c_runtime_eval676000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_runtime_eval676000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_runtime_eval676000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_runtime_eval676000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_runtime_eval676000008_A); return ok }

func A_arbace_c_runtime_eval676000008_A_Cast(x any) *A_arbace_c_runtime_eval676000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_runtime_eval676000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_runtime_eval676000008_A_class)) }; return v }



type A_arbace_c_runtime_eval676000008_fn__676000009_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_eval676000008_fn__676000009_A_fn_class *jrt.Class



type A_arbace_c_runtime_lib_fragment_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_lib_fragment_A_fn_class *jrt.Class



type A_arbace_c_runtime_lib_fragment_fn__676000057_A struct{ j2g_header uint64; F_src, F_lib any }

var A_arbace_c_runtime_lib_fragment_fn__676000057_A_fn_class *jrt.Class



type A_arbace_c_runtime_library_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_library_A_fn_class *jrt.Class



type A_arbace_c_runtime_library_fn__676000061_A struct{ j2g_header uint64; F_lib any }

var A_arbace_c_runtime_library_fn__676000061_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_link_text_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_direct__676000078_A struct{ j2g_header uint64; F_lib, F_srcs, F_units any }

var A_arbace_c_runtime_link_text_direct__676000078_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A struct{ j2g_header uint64; F_lib any }

var A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000070_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_link_text_fn__676000070_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000072_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_link_text_fn__676000072_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000074_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_link_text_fn__676000074_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000076_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_c_runtime_link_text_fn__676000076_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000086_A struct{ j2g_header uint64; F_direct any }

var A_arbace_c_runtime_link_text_fn__676000086_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000088_A struct{ j2g_header uint64; F_linked any }

var A_arbace_c_runtime_link_text_fn__676000088_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000090_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_link_text_fn__676000090_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_fn__676000092_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_link_text_fn__676000092_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_linked__676000082_A struct{ j2g_header uint64; F_lib, F_srcs, F_units any }

var A_arbace_c_runtime_link_text_linked__676000082_A_fn_class *jrt.Class



type A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A struct{ j2g_header uint64; F_lib any }

var A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_fn_class *jrt.Class



type A_arbace_c_runtime_make_fragment_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_make_fragment_A_fn_class *jrt.Class



type A_arbace_c_runtime_make_fragment_fn__676000047_A struct{ j2g_header uint64; F_f any }

var A_arbace_c_runtime_make_fragment_fn__676000047_A_fn_class *jrt.Class



type A_arbace_c_runtime_make_fragment_fn__676000050_A struct{ j2g_header uint64; F_f, F_fr any }

var A_arbace_c_runtime_make_fragment_fn__676000050_A_fn_class *jrt.Class



type A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A struct{ j2g_header uint64; F_fr any }

var A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_fn_class *jrt.Class



type A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A struct{ j2g_header uint64; F_f, F_x any }

var A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_fn_class *jrt.Class



type A_arbace_c_runtime_musl_key_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_musl_key_A_fn_class *jrt.Class



type A_arbace_c_runtime_normalize_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_normalize_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuild_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_prebuild_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuild_iter__676000096__676000100_A struct{ j2g_header uint64; F_lib, F_refused, F_q, F_made any }

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A struct{ j2g_header uint64; F_lib, F_refused, F_q, F_made, F_iter__676000096, F_s__676000097 any }

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A struct{ j2g_header uint64; F_lib, F_refused, F_b__676000099, F_q, F_made any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A struct{ j2g_header uint64; F_lib, F_refused, F_q, F_made any }

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A struct{ j2g_header uint64; F_lib, F_refused, F_q, F_made any }

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_fn_class *jrt.Class



type A_arbace_c_runtime_prebuilt_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_prebuilt_A_fn_class *jrt.Class



type A_arbace_c_runtime_runtime_key_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_runtime_key_A_fn_class *jrt.Class



type A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A struct{ j2g_header uint64; F_root any }

var A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_fn_class *jrt.Class



type A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A struct{ j2g_header uint64; F_root, F_iter__676000026, F_s__676000027 any }

var A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_fn_class *jrt.Class



type A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A struct{ j2g_header uint64; F_root, F_b__676000029 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_fn_class *jrt.Class



type A_arbace_c_runtime_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_sha256_hex_A_fn_class *jrt.Class



type A_arbace_c_runtime_source_bytes_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_source_bytes_A_fn_class *jrt.Class



type A_arbace_c_runtime_write_atomic_A struct{ j2g_header uint64 }

var A_arbace_c_runtime_write_atomic_A_fn_class *jrt.Class
