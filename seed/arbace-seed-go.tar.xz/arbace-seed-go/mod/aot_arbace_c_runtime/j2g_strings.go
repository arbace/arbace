//line j2g_strings.ae:1
package aot_arbace_c_runtime

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.c.buildkn2,asyn5,buildyn13,arbace.c.muslyn4,muslyn13,arbace.stringyn3,strkn3,dockn4,rootkn1,hys12,arbace.c.run10,check-readkn3,srckn4,elsekn5,fragskn5,checkkn11,runtime-keykn8,frag-dirkn5,ctorskn2,rdkn5,formskn5,unitskn10,libc-startkn2,okkn2,exks2,ci7,refusedkn5,indexkn4,itemkn6,fcandskn4,objskn4,madekn13,items-refusedkn3,dirv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.c.runtimem2,R8,s818,ci's prebuilt runtime (doc/C23-SURVEY.md, \"As built: ci's prebuilt runtime\"; the user, 2026-11-03): a library's units (musl's,\n  arbace.c.musl; a lowered C++ runtime's, any library of read units with an index) each checked and built once into its\n  fragment (arbace.c.build/unit-fragment), cached on disk by the runtime's key (the fragments' format, the target, the\n  library's own key, ci's checker and builder as this process loaded them) under .tmp/ci-runtime/NAME-KEY/ (CI_RUNTIME), so\n  that a program checks and builds only its own units and links the library's fragments by symbol\n  (arbace.c.build/link-text) into the node program both back ends take (go/arbace/ci's Loader, arbace.c.cf2g). Apart from\n  arbace.c.musl so that the libc's forms cache, keyed by musl.ae, is not read again when the linker changes.v13,arbace.c.musl9,load-unitR9,v13,arbace.c.musl6,configR10,v11,arbace.core5,assocv11,arbace.core7,resolveR11,R12,v11,arbace.core3,strv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core6,formatv11,arbace.core10,chunk-restv11,arbace.core4,nextv16,arbace.c.runtime14,embedded-bytesv13,arbace.string12,starts-with?v11,arbace.core5,some?v11,arbace.core4,subsl0,v11,arbace.core3,notR13,v16,arbace.c.runtime10,sha256-hexv14,arbace.c.build16,fragment-versionv13,arbace.string4,joinv11,arbace.core12,chunk-bufferv16,arbace.c.runtime12,source-bytesv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core4,restv16,arbace.c.runtime15,runtime-sourcesv13,arbace.c.musl10,forms-rootv13,arbace.string4,trimv11,arbace.core5,slurpv16,arbace.c.runtime3,envv16,arbace.c.runtime11,runtime-keyv16,arbace.c.runtime10,cache-rootR14,R15,R16,R17,v11,arbace.core4,spitv16,arbace.c.runtime10,*no-cache*v11,arbace.core11,read-stringv14,arbace.c.build13,unit-fragmentR18,R19,v16,arbace.c.runtime12,write-atomicv11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core7,printlnv11,arbace.core5,classv11,arbace.core5,*out*v11,arbace.core5,*err*v16,arbace.c.runtime13,make-fragmentv13,arbace.c.musl7,libraryv16,arbace.c.runtime8,prebuiltv16,arbace.c.runtime8,musl-keyv16,arbace.c.runtime10,check-unitv13,arbace.string7,replacep16,Object@[0-9a-f]+v11,arbace.core3,setv11,arbace.core6,mapcatv11,arbace.core4,keysv13,arbace.c.musl9,unit-defsR20,v13,arbace.c.musl4,refsv11,arbace.core6,concatv11,arbace.core4,valsR21,v11,arbace.core4,intov11,arbace.core4,keepl10,v13,arbace.c.musl7,closurev14,arbace.c.build12,program-textv14,arbace.c.build20,build-program-directv11,arbace.core3,vecv11,arbace.core3,mapv13,arbace.c.musl12,checked-unitR22,v14,arbace.c.build9,link-textv11,arbace.core4,mapvv16,arbace.c.runtime12,lib-fragmentR23,R24,R25,v11,arbace.core7,ex-datav11,arbace.core6,secondv11,arbace.core7,ex-infov11,arbace.core7,string?v16,arbace.c.runtime9,normalizev14,arbace.c.build12,read-programv16,arbace.c.runtime9,link-textR26,v11,arbace.core4,atomv11,arbace.core5,doallv11,arbace.core11,future-callv11,arbace.core5,swap!v11,arbace.core3,incv11,arbace.core1,+v11,arbace.core6,filterR27,R28,R29,v11,arbace.core5,rangeR30,R31,R32,")

var Lit_1 *jrt.String = jrt.Intern("CI_RUNTIME")

var Lit_2 *jrt.String = jrt.Intern("/.tmp/ci-runtime")

var Lit_3 *jrt.String = jrt.Intern("java.io.File")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.runtime$lib_fragment$fn__676000057")

var Lit_5 *jrt.String = jrt.Intern("musl")

var Lit_6 *jrt.String = jrt.Intern("arbace.c.runtime$library$fn__676000061")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000070")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000072")

var Lit_9 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000074")

var Lit_10 *jrt.String = jrt.Intern("CI_TRACE")

var Lit_11 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000076")

var Lit_12 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$direct__676000078")

var Lit_13 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$linked__676000082")

var Lit_14 *jrt.String = jrt.Intern("0")

var Lit_15 *jrt.String = jrt.Intern("CI_PREBUILT")

var Lit_16 *jrt.String = jrt.Intern("CI_LINK_CHECK")

var Lit_17 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000086")

var Lit_18 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000088")

var Lit_19 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000090")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$fn__676000092")

var Lit_21 *jrt.String = jrt.Intern("ci link check: the linked program differs from the direct build (")

var Lit_22 *jrt.String = jrt.Intern(" / ")

var Lit_23 *jrt.String = jrt.Intern(")")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$direct__676000078$fn__676000079")

var Lit_25 *jrt.String = jrt.Intern("__builtin_")

var Lit_26 *jrt.String = jrt.Intern("musl: linked")

var Lit_27 *jrt.String = jrt.Intern("arbace.c.runtime$link_text$linked__676000082$fn__676000083")

var Lit_28 *jrt.String = jrt.Intern("/")

var Lit_29 *jrt.String = jrt.Intern(".frag")

var Lit_30 *jrt.String = jrt.Intern("arbace.c.runtime$make_fragment$fn__676000047")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.runtime$make_fragment$fn__676000050")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.runtime$make_fragment$fn__676000050$fn__676000051")

var Lit_33 *jrt.String = jrt.Intern("arbace.c.runtime$make_fragment$fn__676000050$fn__676000053")

var Lit_34 *jrt.String = jrt.Intern("ci runtime: the fragment")

var Lit_35 *jrt.String = jrt.Intern("not written (")

var Lit_36 *jrt.String = jrt.Intern(": ")

var Lit_37 *jrt.String = jrt.Intern("): built in memory")

var Lit_38 *jrt.String = jrt.Intern("/key")

var Lit_39 *jrt.String = jrt.Intern("/index.edn")

var Lit_40 *jrt.String = jrt.Intern("musl ")

var Lit_41 *jrt.String = jrt.Intern("musl-index ")

var Lit_42 *jrt.String = jrt.Intern("musl none")

var Lit_43 *jrt.String = jrt.Intern("Object@")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.runtime$prebuild$iter__676000096__676000100")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101$fn__676000102")

var Lit_47 *jrt.String = jrt.Intern("arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101$fn__676000106")

var Lit_48 *jrt.String = jrt.Intern("arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101$fn__676000102$fn__676000103")

var Lit_49 *jrt.String = jrt.Intern("-")

var Lit_50 *jrt.String = jrt.Intern("arbace.c.runtime$runtime_key$iter__676000026__676000030")

var Lit_51 *jrt.String = jrt.Intern("UTF-8")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.runtime$runtime_key$iter__676000026__676000030$fn__676000031")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.runtime$runtime_key$iter__676000026__676000030$fn__676000031$fn__676000032")

var Lit_54 *jrt.String = jrt.Intern(" ")

var Lit_55 *jrt.String = jrt.Intern("\n")

var Lit_56 *jrt.String = jrt.Intern("SHA-256")

var Lit_57 *jrt.String = jrt.Intern("%02x")

var Lit_58 *jrt.String = jrt.Intern("arbace/repr/")

var Lit_59 *jrt.String = jrt.Intern("evaluated")

var Lit_60 *jrt.String = jrt.Intern("compiled")

var Lit_61 *jrt.String = jrt.Intern("ARBACE_PATH_FIRST")

var Lit_62 *jrt.String = jrt.Intern("absent")

var Lit_63 *jrt.String = jrt.Intern("absent ")

var Lit_64 *jrt.String = jrt.Intern(".tmp")

var Lit_65 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn3,libyn5,bytesyn16,java.lang.Stringyn5,checkyn4,Filekn7,dynamicyn1,hyn5,unitsyn7,threadsv11,arbace.core5,in-nsMyn16,arbace.c.runtimem2,R0,s818,ci's prebuilt runtime (doc/C23-SURVEY.md, \"As built: ci's prebuilt runtime\"; the user, 2026-11-03): a library's units (musl's,\n  arbace.c.musl; a lowered C++ runtime's, any library of read units with an index) each checked and built once into its\n  fragment (arbace.c.build/unit-fragment), cached on disk by the runtime's key (the fragments' format, the target, the\n  library's own key, ci's checker and builder as this process loaded them) under .tmp/ci-runtime/NAME-KEY/ (CI_RUNTIME), so\n  that a program checks and builds only its own units and links the library's fragments by symbol\n  (arbace.c.build/link-text) into the node program both back ends take (go/arbace/ci's Loader, arbace.c.cf2g). Apart from\n  arbace.c.musl so that the libc's forms cache, keyed by musl.ae, is not read again when the linker changes.m2,R0,s818,ci's prebuilt runtime (doc/C23-SURVEY.md, \"As built: ci's prebuilt runtime\"; the user, 2026-11-03): a library's units (musl's,\n  arbace.c.musl; a lowered C++ runtime's, any library of read units with an index) each checked and built once into its\n  fragment (arbace.c.build/unit-fragment), cached on disk by the runtime's key (the fragments' format, the target, the\n  library's own key, ci's checker and builder as this process loaded them) under .tmp/ci-runtime/NAME-KEY/ (CI_RUNTIME), so\n  that a program checks and builds only its own units and links the library's fragments by symbol\n  (arbace.c.build/link-text) into the node program both back ends take (go/arbace/ci's Loader, arbace.c.cf2g). Apart from\n  arbace.c.musl so that the libc's forms cache, keyed by musl.ae, is not read again when the linker changes.R1,v11,arbace.core20,*warn-on-reflection*v16,arbace.c.runtime3,envm10,R2,TR3,L1,V2,Myn1,km2,R4,R5,Myn1,dm2,R4,R5,R6,i16,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime10,check-unitm10,R3,L1,V2,R9,Myn3,srcm2,R4,R5,R0,s52,A musl source read from the forms cache and checked.R6,i18,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime10,sha256-hexm10,R2,TR3,L1,MV1,Myn1,bm2,R4,R10,m2,R4,R11,R6,i26,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime15,runtime-sourcesV6,s17,arbace/c/check.aes17,arbace/c/build.aes15,arbace/c/run.aes16,arbace/c/musl.aes19,arbace/c/runtime.aes22,arbace/repr/c/annot.aem8,R6,i32,R7,i1,R8,s19,arbace/c/runtime.aeR0,s207,The sources a library unit's fragment is made by: the checker, its builtins' declarations, the builder, check-read and\n  the libc's reader (with the forms cache's key: repr/c, the host, configure's headers).v16,arbace.c.runtime14,embedded-bytesm12,R2,TR3,L1,MV1,Myn1,fm2,R4,R5,m2,R4,R10,R0,s61,The embedded copy of the source f (the executable's), or nil.R6,i37,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime12,source-bytesm12,R2,TR3,L1,V2,Myn4,rootm2,R4,R5,Myn1,fm2,R4,R5,R0,s596,What the source `f` ran as in this process, as RT.load chose (review 187: ARBACE_PATH_FIRST alone does not say it):\n  [how bytes]. A namespace with a compiled loader in the executable (Compiler$AOT/loader, unless ARBACE_NO_AOT) ran\n  compiled from its embedded copy, whatever ARBACE_PATH_FIRST says (RT.load takes the loader for a source read as embedded\n  or first on ARBACE_PATH), unless it is a tool's source under arbace/repr/ whose checkout copy differs, evaluated instead;\n  else it was evaluated from the checkout's copy (ARBACE_PATH_FIRST, or a tool's source), else from the embedded one.R6,i43,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime11,runtime-keym10,R3,L1,MV2,Myn4,rootm2,R4,R5,Myn7,lib-keym2,R4,R5,m2,R4,R11,R0,s159,The prebuilt runtime's key: the fragments' format, the target, the library's own key (`lib-key`: its sources' digest)\n  and runtime-sources' digests as loaded.R6,i62,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime8,musl-keym12,R2,TR3,L1,MV1,Myn4,rootm2,R4,R5,m2,R4,R11,R0,s77,The forms cache's key (bin/lib/ci/musl's forms/key), else its index's digest.R6,i72,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime10,cache-rootm8,R3,L1,MV1,Myn4,rootm2,R4,R5,m2,R4,R11,R6,i82,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime8,prebuiltm10,R3,L1,V5,R9,Myn4,rootm2,R4,R5,Myn4,namem2,R4,R5,Myn7,lib-keym2,R4,R5,R12,R0,s237,A library made prebuilt: `lib` with :frags (the fragments made or read, by unit), :frag-dir (the cache's directory for\n  its key) and :check (fn [unit-name] checked unit). `lib-key` names the library's sources (musl's forms cache's key).R6,i84,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime12,write-atomicm12,R2,TR3,L1,V2,Myn1,fm2,R4,R13,Myn1,sm2,R4,R5,R0,s86,s written to f through a temporary name (another process may write the same fragment).R6,i96,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime10,*no-cache*v11,arbace.core5,some?m8,R14,TR6,i104,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime13,make-fragmentm10,R2,TR3,L1,V2,R9,Myn3,srcm2,R4,R5,R6,i106,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime12,lib-fragmentm10,R3,L1,V2,R9,Myn3,srcm2,R4,R5,R0,s100,A library unit's fragment: made once per process, read from the cache, or checked, built and cached.R6,i124,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime7,librarym10,R3,L1,V2,R15,Myn4,rootm2,R4,R5,R0,s106,musl as a prebuilt library: arbace.c.musl/library's {:root :index :by-name :checked} with prebuilt's keys.R6,i131,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime9,normalizem12,R2,TR3,L1,V1,Myn1,sm2,R4,R5,R0,s92,A node program's text with the names of statics of no name (an identity's print) made equal.R6,i137,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime9,link-textm10,R3,L1,MV2,R9,R16,m2,R4,R11,R0,s314,The node program's text of the program's units linked with what they need of musl: the program's units built into\n  fragments, musl's prebuilt (lib-fragment). CI_PREBUILT=0: every unit checked and built together, as before\n  (arbace.c.build/build-program-direct); CI_LINK_CHECK=1: both, their texts required equal.R6,i142,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime12,build-linkedm10,R3,L1,V2,R9,R16,R0,s90,The node program of the program's units linked with what they need of musl (its commands).R6,i170,R7,i1,R8,s19,arbace/c/runtime.aev16,arbace.c.runtime8,prebuildm10,R3,L1,V2,R9,R17,R0,s200,Every musl source's fragment made (read from the cache or checked, built and cached), in `threads` threads (bin/ci runtime\n  build): {:units N :made M :items-refused R}, the cache's directory printed.R6,i175,R7,i1,R8,s19,arbace/c/runtime.ae")

var Lit_66 *jrt.String = jrt.Intern("arbace.c.runtime$eval676000004$loading__1927001464__auto____676000005")

var Lit_67 *jrt.String = jrt.Intern("arbace.c.runtime$eval676000008$fn__676000009")

var Lit_68 *jrt.String = jrt.Intern("arbace.c.runtime$env")

var Lit_69 *jrt.String = jrt.Intern("arbace.c.runtime$check_unit")

var Lit_70 *jrt.String = jrt.Intern("arbace.c.runtime$sha256_hex")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.runtime$embedded_bytes")

var Lit_72 *jrt.String = jrt.Intern("arbace.c.runtime$source_bytes")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.runtime$runtime_key")

var Lit_74 *jrt.String = jrt.Intern("arbace.c.runtime$musl_key")

var Lit_75 *jrt.String = jrt.Intern("arbace.c.runtime$cache_root")

var Lit_76 *jrt.String = jrt.Intern("arbace.c.runtime$prebuilt")

var Lit_77 *jrt.String = jrt.Intern("arbace.c.runtime$write_atomic")

var Lit_78 *jrt.String = jrt.Intern("CI_RUNTIME_NO_DISK")

var Lit_79 *jrt.String = jrt.Intern("arbace.c.runtime$make_fragment")

var Lit_80 *jrt.String = jrt.Intern("arbace.c.runtime$lib_fragment")

var Lit_81 *jrt.String = jrt.Intern("arbace.c.runtime$library")

var Lit_82 *jrt.String = jrt.Intern("arbace.c.runtime$normalize")

var Lit_83 *jrt.String = jrt.Intern("arbace.c.runtime$link_text")

var Lit_84 *jrt.String = jrt.Intern("arbace.c.runtime$build_linked")

var Lit_85 *jrt.String = jrt.Intern("arbace.c.runtime$prebuild")
