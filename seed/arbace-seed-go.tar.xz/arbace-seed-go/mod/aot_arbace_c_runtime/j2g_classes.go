//line j2g_classes.ae:1
package aot_arbace_c_runtime

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_runtime_build_linked_A_class, Name: "arbace.c.runtime$build_linked", Modifiers: 25, Simple: "build_linked", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_build_linked_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_cache_root_A_class, Name: "arbace.c.runtime$cache_root", Modifiers: 25, Simple: "cache_root", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_cache_root_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_check_unit_A_class, Name: "arbace.c.runtime$check_unit", Modifiers: 25, Simple: "check_unit", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_check_unit_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_embedded_bytes_A_class, Name: "arbace.c.runtime$embedded_bytes", Modifiers: 25, Simple: "embedded_bytes", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_embedded_bytes_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_env_A_class, Name: "arbace.c.runtime$env", Modifiers: 25, Simple: "env", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_env_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A_class, Name: "arbace.c.runtime$eval676000004$loading__1927001464__auto____676000005", Modifiers: 25, Simple: "loading__1927001464__auto____676000005", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_eval676000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_eval676000008_fn__676000009_A_class, Name: "arbace.c.runtime$eval676000008$fn__676000009", Modifiers: 25, Simple: "fn__676000009", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_eval676000008_fn__676000009_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_eval676000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_lib_fragment_A_class, Name: "arbace.c.runtime$lib_fragment", Modifiers: 25, Simple: "lib_fragment", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_lib_fragment_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_lib_fragment_fn__676000057_A_class, Name: "arbace.c.runtime$lib_fragment$fn__676000057", Modifiers: 25, Simple: "fn__676000057", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_lib_fragment_fn__676000057_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_lib_fragment_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_library_A_class, Name: "arbace.c.runtime$library", Modifiers: 25, Simple: "library", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_library_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_library_fn__676000061_A_class, Name: "arbace.c.runtime$library$fn__676000061", Modifiers: 25, Simple: "fn__676000061", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_library_fn__676000061_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_library_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_A_class, Name: "arbace.c.runtime$link_text", Modifiers: 25, Simple: "link_text", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_direct__676000078_A_class, Name: "arbace.c.runtime$link_text$direct__676000078", Modifiers: 25, Simple: "direct__676000078", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_direct__676000078_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_class, Name: "arbace.c.runtime$link_text$direct__676000078$fn__676000079", Modifiers: 25, Simple: "fn__676000079", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_direct__676000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000070_A_class, Name: "arbace.c.runtime$link_text$fn__676000070", Modifiers: 25, Simple: "fn__676000070", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000070_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000072_A_class, Name: "arbace.c.runtime$link_text$fn__676000072", Modifiers: 25, Simple: "fn__676000072", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000072_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000074_A_class, Name: "arbace.c.runtime$link_text$fn__676000074", Modifiers: 25, Simple: "fn__676000074", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000074_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000076_A_class, Name: "arbace.c.runtime$link_text$fn__676000076", Modifiers: 25, Simple: "fn__676000076", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000076_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000086_A_class, Name: "arbace.c.runtime$link_text$fn__676000086", Modifiers: 25, Simple: "fn__676000086", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000086_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000088_A_class, Name: "arbace.c.runtime$link_text$fn__676000088", Modifiers: 25, Simple: "fn__676000088", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000088_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000090_A_class, Name: "arbace.c.runtime$link_text$fn__676000090", Modifiers: 25, Simple: "fn__676000090", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000090_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_fn__676000092_A_class, Name: "arbace.c.runtime$link_text$fn__676000092", Modifiers: 25, Simple: "fn__676000092", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_fn__676000092_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_linked__676000082_A_class, Name: "arbace.c.runtime$link_text$linked__676000082", Modifiers: 25, Simple: "linked__676000082", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_linked__676000082_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_class, Name: "arbace.c.runtime$link_text$linked__676000082$fn__676000083", Modifiers: 25, Simple: "fn__676000083", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_link_text_linked__676000082_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_make_fragment_A_class, Name: "arbace.c.runtime$make_fragment", Modifiers: 25, Simple: "make_fragment", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_make_fragment_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_make_fragment_fn__676000047_A_class, Name: "arbace.c.runtime$make_fragment$fn__676000047", Modifiers: 25, Simple: "fn__676000047", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_make_fragment_fn__676000047_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_make_fragment_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_make_fragment_fn__676000050_A_class, Name: "arbace.c.runtime$make_fragment$fn__676000050", Modifiers: 25, Simple: "fn__676000050", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_make_fragment_fn__676000050_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_make_fragment_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_class, Name: "arbace.c.runtime$make_fragment$fn__676000050$fn__676000051", Modifiers: 25, Simple: "fn__676000051", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_make_fragment_fn__676000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_class, Name: "arbace.c.runtime$make_fragment$fn__676000050$fn__676000053", Modifiers: 25, Simple: "fn__676000053", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_make_fragment_fn__676000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_musl_key_A_class, Name: "arbace.c.runtime$musl_key", Modifiers: 25, Simple: "musl_key", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_musl_key_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_normalize_A_class, Name: "arbace.c.runtime$normalize", Modifiers: 25, Simple: "normalize", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_normalize_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuild_A_class, Name: "arbace.c.runtime$prebuild", Modifiers: 25, Simple: "prebuild", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuild_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_class, Name: "arbace.c.runtime$prebuild$iter__676000096__676000100", Modifiers: 25, Simple: "iter__676000096__676000100", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuild_iter__676000096__676000100_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_prebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_class, Name: "arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101", Modifiers: 25, Simple: "fn__676000101", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_class, Name: "arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101$fn__676000102", Modifiers: 25, Simple: "fn__676000102", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_class, Name: "arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101$fn__676000102$fn__676000103", Modifiers: 25, Simple: "fn__676000103", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_class, Name: "arbace.c.runtime$prebuild$iter__676000096__676000100$fn__676000101$fn__676000106", Modifiers: 25, Simple: "fn__676000106", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_prebuilt_A_class, Name: "arbace.c.runtime$prebuilt", Modifiers: 25, Simple: "prebuilt", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_prebuilt_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_runtime_key_A_class, Name: "arbace.c.runtime$runtime_key", Modifiers: 25, Simple: "runtime_key", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_runtime_key_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_class, Name: "arbace.c.runtime$runtime_key$iter__676000026__676000030", Modifiers: 25, Simple: "iter__676000026__676000030", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_runtime_key_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_class, Name: "arbace.c.runtime$runtime_key$iter__676000026__676000030$fn__676000031", Modifiers: 25, Simple: "fn__676000031", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_class, Name: "arbace.c.runtime$runtime_key$iter__676000026__676000030$fn__676000031$fn__676000032", Modifiers: 25, Simple: "fn__676000032", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_sha256_hex_A_class, Name: "arbace.c.runtime$sha256_hex", Modifiers: 25, Simple: "sha256_hex", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_sha256_hex_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_source_bytes_A_class, Name: "arbace.c.runtime$source_bytes", Modifiers: 25, Simple: "source_bytes", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_source_bytes_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_runtime_write_atomic_A_class, Name: "arbace.c.runtime$write_atomic", Modifiers: 25, Simple: "write_atomic", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_write_atomic_A", Source: "runtime.ae", Declaring: &A_arbace_c_runtime_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_runtime_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_runtime_A_New()}; return nil }

var A_arbace_c_runtime_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_runtime_A_new}

var A_arbace_c_runtime_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.runtime", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_A"})

func init() { i := A_arbace_c_runtime_A_class.Info(); i.IsInstance = A_arbace_c_runtime_A_InstanceOf; i.Init = A_arbace_c_runtime_A_Init; i.Table = A_arbace_c_runtime_A_members }

var A_arbace_c_runtime_build_linked_A_class *jrt.Class

var A_arbace_c_runtime_cache_root_A_class *jrt.Class

var A_arbace_c_runtime_check_unit_A_class *jrt.Class

var A_arbace_c_runtime_embedded_bytes_A_class *jrt.Class

var A_arbace_c_runtime_env_A_class *jrt.Class

func A_arbace_c_runtime_eval676000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_runtime_eval676000004_A_New()}; return nil }

var A_arbace_c_runtime_eval676000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_runtime_eval676000004_A_new}

var A_arbace_c_runtime_eval676000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.runtime$eval676000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_runtime_A_class, Simple: "eval676000004", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_eval676000004_A"})

func init() { i := A_arbace_c_runtime_eval676000004_A_class.Info(); i.IsInstance = A_arbace_c_runtime_eval676000004_A_InstanceOf; i.Table = A_arbace_c_runtime_eval676000004_A_members }

var A_arbace_c_runtime_eval676000004_loading__1927001464__auto____676000005_A_class *jrt.Class

func A_arbace_c_runtime_eval676000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_runtime_eval676000008_A_New()}; return nil }

var A_arbace_c_runtime_eval676000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_runtime_eval676000008_A_new}

var A_arbace_c_runtime_eval676000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.runtime$eval676000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_runtime_A_class, Simple: "eval676000008", Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime_eval676000008_A"})

func init() { i := A_arbace_c_runtime_eval676000008_A_class.Info(); i.IsInstance = A_arbace_c_runtime_eval676000008_A_InstanceOf; i.Table = A_arbace_c_runtime_eval676000008_A_members }

var A_arbace_c_runtime_eval676000008_fn__676000009_A_class *jrt.Class

var A_arbace_c_runtime_lib_fragment_A_class *jrt.Class

var A_arbace_c_runtime_lib_fragment_fn__676000057_A_class *jrt.Class

var A_arbace_c_runtime_library_A_class *jrt.Class

var A_arbace_c_runtime_library_fn__676000061_A_class *jrt.Class

var A_arbace_c_runtime_link_text_A_class *jrt.Class

var A_arbace_c_runtime_link_text_direct__676000078_A_class *jrt.Class

var A_arbace_c_runtime_link_text_direct__676000078_fn__676000079_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000070_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000072_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000074_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000076_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000086_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000088_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000090_A_class *jrt.Class

var A_arbace_c_runtime_link_text_fn__676000092_A_class *jrt.Class

var A_arbace_c_runtime_link_text_linked__676000082_A_class *jrt.Class

var A_arbace_c_runtime_link_text_linked__676000082_fn__676000083_A_class *jrt.Class

var A_arbace_c_runtime_make_fragment_A_class *jrt.Class

var A_arbace_c_runtime_make_fragment_fn__676000047_A_class *jrt.Class

var A_arbace_c_runtime_make_fragment_fn__676000050_A_class *jrt.Class

var A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000051_A_class *jrt.Class

var A_arbace_c_runtime_make_fragment_fn__676000050_fn__676000053_A_class *jrt.Class

var A_arbace_c_runtime_musl_key_A_class *jrt.Class

var A_arbace_c_runtime_normalize_A_class *jrt.Class

var A_arbace_c_runtime_prebuild_A_class *jrt.Class

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_A_class *jrt.Class

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_A_class *jrt.Class

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_A_class *jrt.Class

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000102_fn__676000103_A_class *jrt.Class

var A_arbace_c_runtime_prebuild_iter__676000096__676000100_fn__676000101_fn__676000106_A_class *jrt.Class

var A_arbace_c_runtime_prebuilt_A_class *jrt.Class

var A_arbace_c_runtime_runtime_key_A_class *jrt.Class

var A_arbace_c_runtime_runtime_key_iter__676000026__676000030_A_class *jrt.Class

var A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_A_class *jrt.Class

var A_arbace_c_runtime_runtime_key_iter__676000026__676000030_fn__676000031_fn__676000032_A_class *jrt.Class

var A_arbace_c_runtime_sha256_hex_A_class *jrt.Class

var A_arbace_c_runtime_source_bytes_A_class *jrt.Class

var A_arbace_c_runtime_write_atomic_A_class *jrt.Class

func A_arbace_c_runtime__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c_runtime__init_A_Load__O()}; return nil }

func A_arbace_c_runtime__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_runtime__init_A_New()}; return nil }

var A_arbace_c_runtime__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c_runtime__init_A_invoke, New: A_arbace_c_runtime__init_A_new}

var A_arbace_c_runtime__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.runtime__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_runtime.A_arbace_c_runtime__init_A", Source: "runtime.ae"})

func init() { i := A_arbace_c_runtime__init_A_class.Info(); i.IsInstance = A_arbace_c_runtime__init_A_InstanceOf; i.Init = A_arbace_c_runtime__init_A_Init; i.Table = A_arbace_c_runtime__init_A_members }
