//line aot_arbace_j2g_start.ae:1
package aot_arbace_j2g_start

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A_New() *A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A { A_arbace_j2g_start_A_Init(); t := &A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_j2g_start_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_start_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_start_eval1358000008_fn__1358000009_A_New() *A_arbace_j2g_start_eval1358000008_fn__1358000009_A { A_arbace_j2g_start_A_Init(); t := &A_arbace_j2g_start_eval1358000008_fn__1358000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_start_eval1358000008_fn__1358000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_start_eval1358000008_fn__1358000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_start_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_start_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_start_A_const_6), A_arbace_j2g_start_A_const_4.GetRawRoot__O(), A_arbace_j2g_start_A_const_5) }


















type A_arbace_j2g_start_A struct{ jrt.Object }

var A_arbace_j2g_start_A_const_pool *jrt.RefArray

var A_arbace_j2g_start_A_const_0 *lang.Var

var A_arbace_j2g_start_A_const_1 any

var A_arbace_j2g_start_A_const_2 *lang.Var

var A_arbace_j2g_start_A_const_3 *lang.Var

var A_arbace_j2g_start_A_const_4 *lang.Var

var A_arbace_j2g_start_A_const_5 any

var A_arbace_j2g_start_A_const_6 *lang.Var

var A_arbace_j2g_start_A_init jrt.ClassInit

func A_arbace_j2g_start_A_Init() { if !A_arbace_j2g_start_A_init.Done() { A_arbace_j2g_start_A_init.Run(A_arbace_j2g_start_A_clinit) } }

func A_arbace_j2g_start_A_clinit() { jrt.StartCheck(); A_arbace_j2g_start_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 9); A_arbace_j2g_start_A_const_0 = lang.Var_Cast(A_arbace_j2g_start_A_const_pool.A[2]); A_arbace_j2g_start_A_const_1 = A_arbace_j2g_start_A_const_pool.A[3]; A_arbace_j2g_start_A_const_2 = lang.Var_Cast(A_arbace_j2g_start_A_const_pool.A[4]); A_arbace_j2g_start_A_const_3 = lang.Var_Cast(A_arbace_j2g_start_A_const_pool.A[5]); A_arbace_j2g_start_A_const_4 = lang.Var_Cast(A_arbace_j2g_start_A_const_pool.A[6]); A_arbace_j2g_start_A_const_5 = A_arbace_j2g_start_A_const_pool.A[7]; A_arbace_j2g_start_A_const_6 = lang.Var_Cast(A_arbace_j2g_start_A_const_pool.A[8]) }

func A_arbace_j2g_start_A_New() *A_arbace_j2g_start_A { A_arbace_j2g_start_A_Init(); t := &A_arbace_j2g_start_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_start_A) Ctor() {}

func (t *A_arbace_j2g_start_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_start_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_start_A_class }

func (t *A_arbace_j2g_start_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_start_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_start_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_start_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_start_A); return ok }

func A_arbace_j2g_start_A_Cast(x any) *A_arbace_j2g_start_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_start_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_start_A_class)) }; return v }



type A_arbace_j2g_start_eval1358000004_A struct{ jrt.Object }

func A_arbace_j2g_start_eval1358000004_A_New() *A_arbace_j2g_start_eval1358000004_A { t := &A_arbace_j2g_start_eval1358000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_start_eval1358000004_A) Ctor() {}

func (t *A_arbace_j2g_start_eval1358000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_start_eval1358000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_start_eval1358000004_A_class }

func (t *A_arbace_j2g_start_eval1358000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_start_eval1358000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_start_eval1358000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_start_eval1358000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_start_eval1358000004_A); return ok }

func A_arbace_j2g_start_eval1358000004_A_Cast(x any) *A_arbace_j2g_start_eval1358000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_start_eval1358000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_start_eval1358000004_A_class)) }; return v }



type A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A_fn_class *jrt.Class



type A_arbace_j2g_start_eval1358000008_A struct{ jrt.Object }

func A_arbace_j2g_start_eval1358000008_A_New() *A_arbace_j2g_start_eval1358000008_A { t := &A_arbace_j2g_start_eval1358000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_start_eval1358000008_A) Ctor() {}

func (t *A_arbace_j2g_start_eval1358000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_start_eval1358000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_start_eval1358000008_A_class }

func (t *A_arbace_j2g_start_eval1358000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_start_eval1358000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_start_eval1358000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_start_eval1358000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_start_eval1358000008_A); return ok }

func A_arbace_j2g_start_eval1358000008_A_Cast(x any) *A_arbace_j2g_start_eval1358000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_start_eval1358000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_start_eval1358000008_A_class)) }; return v }



type A_arbace_j2g_start_eval1358000008_fn__1358000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_start_eval1358000008_fn__1358000009_A_fn_class *jrt.Class
