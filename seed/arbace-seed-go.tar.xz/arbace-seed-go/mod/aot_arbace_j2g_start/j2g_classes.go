//line j2g_classes.ae:1
package aot_arbace_j2g_start

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A_class, Name: "arbace.j2g.start$eval1358000004$loading__1927001464__auto____1358000005", Modifiers: 25, Simple: "loading__1927001464__auto____1358000005", Go: "arbace/aot_arbace_j2g_start.A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A", Source: "start.ae", Declaring: &A_arbace_j2g_start_eval1358000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_start_eval1358000008_fn__1358000009_A_class, Name: "arbace.j2g.start$eval1358000008$fn__1358000009", Modifiers: 25, Simple: "fn__1358000009", Go: "arbace/aot_arbace_j2g_start.A_arbace_j2g_start_eval1358000008_fn__1358000009_A", Source: "start.ae", Declaring: &A_arbace_j2g_start_eval1358000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_start_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_start_A_New()}; return nil }

var A_arbace_j2g_start_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_start_A_new}

var A_arbace_j2g_start_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.start", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_start.A_arbace_j2g_start_A"})

func init() { i := A_arbace_j2g_start_A_class.Info(); i.IsInstance = A_arbace_j2g_start_A_InstanceOf; i.Init = A_arbace_j2g_start_A_Init; i.Table = A_arbace_j2g_start_A_members }

func A_arbace_j2g_start_eval1358000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_start_eval1358000004_A_New()}; return nil }

var A_arbace_j2g_start_eval1358000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_start_eval1358000004_A_new}

var A_arbace_j2g_start_eval1358000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.start$eval1358000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_start_A_class, Simple: "eval1358000004", Go: "arbace/aot_arbace_j2g_start.A_arbace_j2g_start_eval1358000004_A"})

func init() { i := A_arbace_j2g_start_eval1358000004_A_class.Info(); i.IsInstance = A_arbace_j2g_start_eval1358000004_A_InstanceOf; i.Table = A_arbace_j2g_start_eval1358000004_A_members }

var A_arbace_j2g_start_eval1358000004_loading__1927001464__auto____1358000005_A_class *jrt.Class

func A_arbace_j2g_start_eval1358000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_start_eval1358000008_A_New()}; return nil }

var A_arbace_j2g_start_eval1358000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_start_eval1358000008_A_new}

var A_arbace_j2g_start_eval1358000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.start$eval1358000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_start_A_class, Simple: "eval1358000008", Go: "arbace/aot_arbace_j2g_start.A_arbace_j2g_start_eval1358000008_A"})

func init() { i := A_arbace_j2g_start_eval1358000008_A_class.Info(); i.IsInstance = A_arbace_j2g_start_eval1358000008_A_InstanceOf; i.Table = A_arbace_j2g_start_eval1358000008_A_members }

var A_arbace_j2g_start_eval1358000008_fn__1358000009_A_class *jrt.Class

func A_arbace_j2g_start__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_start__init_A_Load__O()}; return nil }

func A_arbace_j2g_start__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_start__init_A_New()}; return nil }

var A_arbace_j2g_start__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_start__init_A_invoke, New: A_arbace_j2g_start__init_A_new}

var A_arbace_j2g_start__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.start__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_start.A_arbace_j2g_start__init_A", Source: "start.ae"})

func init() { i := A_arbace_j2g_start__init_A_class.Info(); i.IsInstance = A_arbace_j2g_start__init_A_InstanceOf; i.Init = A_arbace_j2g_start__init_A_Init; i.Table = A_arbace_j2g_start__init_A_members }
