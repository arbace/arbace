//line aot_arbace_g2a_build.ae:1
package aot_arbace_g2a_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_New() *A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_build_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_2); lang.IFn_Cast(A_arbace_g2a_build_A_const_1.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_3, A_arbace_g2a_build_A_const_4); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_51)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_52)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_53)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_54)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_55)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_56)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :1:1
func A_arbace_g2a_build_eval715000008_fn__715000009_A_New() *A_arbace_g2a_build_eval715000008_fn__715000009_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_eval715000008_fn__715000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_build_eval715000008_fn__715000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_build_eval715000008_fn__715000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_9), A_arbace_g2a_build_A_const_7.GetRawRoot__O(), A_arbace_g2a_build_A_const_8) }




























































func A_arbace_g2a_build_fail_A_New() *A_arbace_g2a_build_fail_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_fail_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_g2a_build_fail_A) Ctor() {}
//line :62:1
func (t *A_arbace_g2a_build_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__715000012__1 any) any { var vec__715000013__3 any = p__715000012__1; var data__4 any = lang.RT_Nth_O_I_O__O(vec__715000013__3, lang.RT_IntCast_J__I(0), nil); panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_10.GetRawRoot__O()).Invoke_O_O__O(msg__0, lang.IFn_Cast(A_arbace_g2a_build_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_12, data__4))))) }





func A_arbace_g2a_build_data_dir_QMARK__A_New() *A_arbace_g2a_build_data_dir_QMARK__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_g2a_build_data_dir_QMARK__A) Ctor() {}
//line :68:1
func (t *A_arbace_g2a_build_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.NN(jrt.File_Cast(f__1)).GetParentFile__File().Ref(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z(jrt.NN(jrt.File_Cast(d__3)).GetAbsoluteFile__File().Ref(), jrt.NN(jrt.File_Cast(dir__0)).GetAbsoluteFile__File().Ref()) }; if tmp1 { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_50).IsFile__Z() { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if A_arbace_g2a_build_A_const_13 != nil {

		d__3 = jrt.NN(jrt.File_Cast(d__3)).GetParentFile__File().Ref(); continue L1 } else {
//line :73:1
			return nil } } } } }; /*line :68:1*/panic("a2g: unreachable") }








func A_arbace_g2a_build_clj_files_A_New() *A_arbace_g2a_build_clj_files_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_clj_files_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_g2a_build_clj_files_A) Ctor() {}
//line :77:1
func (t *A_arbace_g2a_build_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_clj_files_fn__715000020_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_clj_files_fn__715000022_A_New_O(dir__0); var tmp7 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class
//line :79:1
	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class = fncls__2d; tmp7 = fncls__2d } else { tmp7 = fncls__2
	}
	return tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_g2a_build_A_const_19.GetRawRoot__O()).Invoke_O__O(dir__0))) }
//line :79:1
func A_arbace_g2a_build_clj_files_fn__715000022_A_New_O(p0 any) *A_arbace_g2a_build_clj_files_fn__715000022_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_clj_files_fn__715000022_A{}; t.Ctor_O(p0); return t }
//line :79:1
func (t *A_arbace_g2a_build_clj_files_fn__715000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :79:1
func (t *A_arbace_g2a_build_clj_files_fn__715000022_A) Invoke_O_O__O(self, p1__715000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__715000018_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_16.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__715000018_SHARP___1)).GetName__String().Ref(), Lit_49); if jrt.A2g_Truth(and__1927000168__auto____3) {
														return lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, p1__715000018_SHARP___1)) } else {
//line :79:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

func A_arbace_g2a_build_clj_files_fn__715000020_A_New() *A_arbace_g2a_build_clj_files_fn__715000020_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_clj_files_fn__715000020_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_g2a_build_clj_files_fn__715000020_A) Ctor() {}
//line :81:1
func (t *A_arbace_g2a_build_clj_files_fn__715000020_A) Invoke_O_O__O(self, p1__715000019_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__715000019_SHARP___1)).GetPath__String().Ref() }

func A_arbace_g2a_build_package_file_QMARK__A_New() *A_arbace_g2a_build_package_file_QMARK__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_package_file_QMARK__A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_g2a_build_package_file_QMARK__A) Ctor() {}
//line :83:1
func (t *A_arbace_g2a_build_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class; if




	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; ns_form__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__3)); var aliases__5 any; if
	jrt.A2g_Truth(ns_form__4) { aliases__5 = A_arbace_g2a_build_A_const_21.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp5 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.A2g_Truth(and__1927000168__auto____6) {
		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_22.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_New_O(aliases__5); var tmp8 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class = fncls__4d; tmp8 = fncls__4d } else { tmp8 = fncls__4 }; tmp5 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), forms__3) } else {
//line :91:1
			tmp5 = and__1927000168__auto____6 }; return /*line :90:1*/ jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp5)).Ref() }
//line :88:1
func A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_New() *A_arbace_g2a_build_package_file_QMARK__fn__715000027_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_package_file_QMARK__fn__715000027_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000027_A) Ctor() {}
//line :88:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000027_A) Invoke_O_O__O(self, p1__715000025_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_23.GetRawRoot__O()).Invoke_O__O(p1__715000025_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_g2a_build_A_const_24; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000025_SHARP___1))).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_New_O(p0 any) *A_arbace_g2a_build_package_file_QMARK__fn__715000029_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_package_file_QMARK__fn__715000029_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :92:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000029_A) Invoke_O_O__O(self, p1__715000026_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_23.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(Lit_77, lang.IFn_Cast(A_arbace_g2a_build_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1))); if and__1927000168__auto____4 {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp2 any = t.F_aliases; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_build_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1))) } else {
//line :92:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_g2a_build_rel_path_A_New() *A_arbace_g2a_build_rel_path_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_rel_path_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_g2a_build_rel_path_A) Ctor() {}
//line :99:1
func (t *A_arbace_g2a_build_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	return lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.NN(jrt.File_Cast(base__0)).GetAbsoluteFile__File()).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).ToPath__Path()))
}
func A_arbace_g2a_build_packages_A_New() *A_arbace_g2a_build_packages_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Ctor() {}
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any { var own__3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_30.GetRawRoot__O()).Invoke_O__O(dir__0); var more__4 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_A_New(); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class; if






	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); more__4 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(roots__1); var pkgs__5 any = /*line :102:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O__O(own__3, more__4)); var seq_715000050__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46, pkgs__5)); var chunk_715000051__7 any; var count_715000052__8 int64 = 0; var i_715000053__9 int64 = 0; L1: for {











		if lang.Numbers_Lt_J_J__Z(i_715000053__9, count_715000052__8) { var vec__715000054__10 any = lang.Indexed_Cast(chunk_715000051__7).Nth_I__O(lang.RT_IntCast_J__I(i_715000053__9)); var path__11 any = lang.RT_Nth_O_I_O__O(vec__715000054__10, lang.RT_IntCast_J__I(0), nil); var ps__12 any = lang.RT_Nth_O_I_O__O(vec__715000054__10, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__12)), 1) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_79, nil, Lit_80, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_packages_fn__715000057_A_New(); var tmp8 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_build_packages_fn__715000057_A_fn_class
			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_g2a_build_packages_fn__715000057_A_fn_class = fncls__10d; tmp8 = fncls__10d } else { tmp8 = fncls__10 }
//line :115:1
			tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__11, nil, tmp5.Invoke_O_O__O(Lit_81, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), ps__12)))).Ref())
//line :114:1
			seq_715000050__6, chunk_715000051__7, count_715000052__8, i_715000053__9 = seq_715000050__6, chunk_715000051__7, count_715000052__8, lang.Numbers_Unchecked_inc_J__J(i_715000053__9); continue L1 } else { seq_715000050__6, chunk_715000051__7, count_715000052__8, i_715000053__9 = seq_715000050__6, chunk_715000051__7, count_715000052__8, lang.Numbers_Unchecked_inc_J__J(i_715000053__9); continue L1 } } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000050__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_715000050__11 any = temp__1927000414__auto____10; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000050__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000050__11); seq_715000050__6, chunk_715000051__7, count_715000052__8, i_715000053__9 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000050__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000059__12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000050__11); var path__13 any = lang.RT_Nth_O_I_O__O(vec__715000059__12, lang.RT_IntCast_J__I(0), nil); var ps__14 any = lang.RT_Nth_O_I_O__O(vec__715000059__12, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__14)), 1) {
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_79, nil, Lit_80, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_build_packages_fn__715000062_A_New(); var tmp14 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_build_packages_fn__715000062_A_fn_class
				if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_g2a_build_packages_fn__715000062_A_fn_class = fncls__11d; tmp14 = fncls__11d } else { tmp14 = fncls__11 }
//line :115:1
				tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, path__13, nil, tmp11.Invoke_O_O__O(Lit_81, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__14)))).Ref())
//line :114:1
				seq_715000050__6, chunk_715000051__7, count_715000052__8, i_715000053__9 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000050__11), nil, 0, 0; continue L1 } else { seq_715000050__6, chunk_715000051__7, count_715000052__8, i_715000053__9 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000050__11), nil, 0, 0; continue L1 } } } }
//line :102:1
		break L1 }; return pkgs__5 }
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Invoke_O_O__O(self, dir__0 any) any {



	return lang.IFn_Cast(A_arbace_g2a_build_A_const_52.GetRawRoot__O()).Invoke_O_O__O(dir__0, nil)
}

func A_arbace_g2a_build_packages_iter__715000034__715000040_A_New() *A_arbace_g2a_build_packages_iter__715000034__715000040_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_A) Invoke_O_O__O(self, s__715000035__1 any) any { var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_New_O_O(self, s__715000035__1); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A) Ctor_O_O(c__iter__715000034, c__s__715000035 any) { t.F_iter__715000034 = c__iter__715000034; t.F_s__715000035 = c__s__715000035 }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A) Invoke_O__O(self any) any { { var s__715000035__1 any; var t_ any = t.F_s__715000035; t.F_s__715000035 = nil; s__715000035__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000035__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_30.GetRawRoot__O()).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(r__4)))))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000034); return lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000035__1))) } else { s__715000035__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000035__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :109:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_New() *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A) Invoke_O_O__O(self, s__715000037__1 any) any { var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_New_O_O(self, s__715000037__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A) Ctor_O_O(c__iter__715000036, c__s__715000037 any) { t.F_iter__715000036 = c__iter__715000036; t.F_s__715000037 = c__s__715000037 }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A) Invoke_O__O(self any) any { { var s__715000037__1 any; var t_ any = t.F_s__715000037; t.F_s__715000037 = nil; s__715000037__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000037__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000037__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000037__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000037__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000039__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_New_O_I_O(b__715000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000036); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000039__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000037__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000039__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000037__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_88, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(pkg__4)))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__715000036); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(pkg__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000037__3))) } else { s__715000037__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000037__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :109:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A) Ctor_O_I_O(c__b__715000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__715000039 = c__b__715000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A) Invoke_O__O(self any) any { { var i__715000038__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000038__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_88, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(pkg__2)))) { lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__715000039, pkg__2); i__715000038__1 = lang.Numbers_Unchecked_inc_J__J(i__715000038__1); continue L1 } else { i__715000038__1 = lang.Numbers_Unchecked_inc_J__J(i__715000038__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_g2a_build_packages_fn__715000057_A_New() *A_arbace_g2a_build_packages_fn__715000057_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_fn__715000057_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_g2a_build_packages_fn__715000057_A) Ctor() {}
//line :116:1
func (t *A_arbace_g2a_build_packages_fn__715000057_A) Invoke_O_O__O(self, p1__715000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000033_SHARP___1))).GetPath__String().Ref() }
//line :116:1
func A_arbace_g2a_build_packages_fn__715000062_A_New() *A_arbace_g2a_build_packages_fn__715000062_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_fn__715000062_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_g2a_build_packages_fn__715000062_A) Ctor() {}
//line :116:1
func (t *A_arbace_g2a_build_packages_fn__715000062_A) Invoke_O_O__O(self, p1__715000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000033_SHARP___1))).GetPath__String().Ref() }


func A_arbace_g2a_build_read_all_A_New() *A_arbace_g2a_build_read_all_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_all_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_g2a_build_read_all_A) Ctor() {}
//line :119:1
func (t *A_arbace_g2a_build_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_53.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_build_read_all_fn__715000066_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_build_read_all_fn__715000066_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_g2a_build_read_all_fn__715000066_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; cache__2 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), files__0), lang.IFn_Cast(A_arbace_g2a_build_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_54.GetRawRoot__O(), files__0)); var tmp5 any =

	A_arbace_g2a_build_read_all_fn__715000068_A_New_O(cache__2); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_build_read_all_fn__715000068_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_g2a_build_read_all_fn__715000068_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil) }
//line :124:1
func A_arbace_g2a_build_read_all_fn__715000066_A_New() *A_arbace_g2a_build_read_all_fn__715000066_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_all_fn__715000066_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_g2a_build_read_all_fn__715000066_A) Ctor() {}
//line :124:1
func (t *A_arbace_g2a_build_read_all_fn__715000066_A) Invoke_O_O__O(self, p1__715000065_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__715000065_SHARP___1)).GetAbsolutePath__String().Ref() }

func A_arbace_g2a_build_read_all_fn__715000068_A_New_O(p0 any) *A_arbace_g2a_build_read_all_fn__715000068_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_all_fn__715000068_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_g2a_build_read_all_fn__715000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :126:1
func (t *A_arbace_g2a_build_read_all_fn__715000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__1)).GetAbsolutePath__String().Ref(); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()).Invoke_O_O__O(t.F_cache, k__2)) { return lang.RT_Get_O_O__O(t.F_cache, k__2) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_54.GetRawRoot__O()).Invoke_O__O(f__1) } }

func A_arbace_g2a_build_root_packages_A_New() *A_arbace_g2a_build_root_packages_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_g2a_build_root_packages_A) Ctor() {}
//line :130:1
func (t *A_arbace_g2a_build_root_packages_A) Invoke_O_O__O(self, dir__0 any) any { var root__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_124); if



	jrt.NN(jrt.File_Cast(root__2)).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_125, nil, Lit_126), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__2)).GetPath__String().Ref(), nil)).Ref()) }; var files__3 any = /*line :130:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_56.GetRawRoot__O()).Invoke_O__O(root__2); var read_fn__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_57.GetRawRoot__O()).Invoke_O__O(files__3); var pkgs__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_New_O_O(dir__0, read_fn__4); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_fn_class; if







	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); pkgs__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(files__3); if







	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_67.GetRawRoot__O()).Invoke_O__O(pkgs__5)) {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_128, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__2)).GetPath__String().Ref())).Ref()) }; var seq_715000086__6 any = /*line :130:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46, pkgs__5)); var chunk_715000087__7 any; var count_715000088__8 int64 = 0; var i_715000089__9 int64 = 0; L1: for {

















			if lang.Numbers_Lt_J_J__Z(i_715000089__9, count_715000088__8) { var vec__715000090__10 any = lang.Indexed_Cast(chunk_715000087__7).Nth_I__O(lang.RT_IntCast_J__I(i_715000089__9)); var path__11 any = lang.RT_Nth_O_I_O__O(vec__715000090__10, lang.RT_IntCast_J__I(0), nil); var ps__12 any = lang.RT_Nth_O_I_O__O(vec__715000090__10, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__12)), 1) {
				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_79, nil, Lit_80, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_root_packages_fn__715000093_A_New_O(dir__0); var tmp8 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000093_A_fn_class
				if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_g2a_build_root_packages_fn__715000093_A_fn_class = fncls__19d; tmp8 = fncls__19d } else { tmp8 = fncls__19 }
//line :149:1
				tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__11, nil, tmp5.Invoke_O_O__O(Lit_81, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), ps__12)))).Ref())
//line :148:1
				seq_715000086__6, chunk_715000087__7, count_715000088__8, i_715000089__9 = seq_715000086__6, chunk_715000087__7, count_715000088__8, lang.Numbers_Unchecked_inc_J__J(i_715000089__9); continue L1 } else { seq_715000086__6, chunk_715000087__7, count_715000088__8, i_715000089__9 = seq_715000086__6, chunk_715000087__7, count_715000088__8, lang.Numbers_Unchecked_inc_J__J(i_715000089__9); continue L1 } } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000086__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_715000086__11 any = temp__1927000414__auto____10; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000086__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000086__11); seq_715000086__6, chunk_715000087__7, count_715000088__8, i_715000089__9 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000086__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000095__12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000086__11); var path__13 any = lang.RT_Nth_O_I_O__O(vec__715000095__12, lang.RT_IntCast_J__I(0), nil); var ps__14 any = lang.RT_Nth_O_I_O__O(vec__715000095__12, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__14)), 1) {
					var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_79, nil, Lit_80, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_build_root_packages_fn__715000098_A_New_O(dir__0); var tmp14 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000098_A_fn_class
					if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_g2a_build_root_packages_fn__715000098_A_fn_class = fncls__20d; tmp14 = fncls__20d } else { tmp14 = fncls__20 }
//line :149:1
					tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, path__13, nil, tmp11.Invoke_O_O__O(Lit_81, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__14)))).Ref())
//line :148:1
					seq_715000086__6, chunk_715000087__7, count_715000088__8, i_715000089__9 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000086__11), nil, 0, 0; continue L1 } else { seq_715000086__6, chunk_715000087__7, count_715000088__8, i_715000089__9 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000086__11), nil, 0, 0; continue L1 } } } }
//line :130:1
			break L1 }; return /*line :151:1*/ lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()).Invoke_O__O(pkgs__5) }
//line :138:1
func A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000072__715000076_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000072__715000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_A) Ctor_O_O(c__dir, c__read_fn any) { t.F_dir = c__dir; t.F_read_fn = c__read_fn }
//line :138:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_A) Invoke_O_O__O(self, s__715000073__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_New_O_O_O_O(s__715000073__1, t.F_dir, t.F_read_fn, self); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :138:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A) Ctor_O_O_O_O(c__s__715000073, c__dir, c__read_fn, c__iter__715000072 any) { t.F_s__715000073 = c__s__715000073; t.F_dir = c__dir; t.F_read_fn = c__read_fn; t.F_iter__715000072 = c__iter__715000072 }
//line :138:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A) Invoke_O__O(self any) any { { var s__715000073__1 any; var t_ any = t.F_s__715000073; t.F_s__715000073 = nil; s__715000073__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000073__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000073__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000073__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000073__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000075__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_New_O_O_O_I_O(t.F_dir, t.F_read_fn, b__715000075__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000072); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000075__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000073__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000075__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000073__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_58.GetRawRoot__O()).Invoke_O_O__O(f__4, t.F_read_fn)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()); var tmp5 any; var read__5 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_59.GetRawRoot__O()); var tmp7 *lang.PersistentVector
														lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; read__5 = tmp6.Invoke_O__O(tmp7.Ref())
//line :138:1
	var pkg__6 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_60.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_New_O_O(t.F_read_fn, read__5); var tmp10 *jrt.Class
	var fncls__16 /*line :138:1*/*jrt.Class = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_fn_class

	if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_fn_class = fncls__16d; tmp10 = fncls__16d } else { tmp10 = fncls__16 }; pkg__6 = tmp8.Invoke_O_O__O(f__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil))
//line :138:1
	var tmp11 *lang.Keyword = A_arbace_g2a_build_A_const_46; var path__7 any = tmp11.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__6))



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_64.GetRawRoot__O()).Invoke_O__O(path__7)) { } else {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_134), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, f__4), nil)).Ref())
	}
	var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_build_A_const_50; var tmp14 any = A_arbace_g2a_build_A_const_46; var tmp15 any = A_arbace_g2a_build_A_const_66; tmp5 = tmp12.Invoke_O_O_O_O_O_O_O__O(pkg__6, tmp13, f__4, tmp14, path__7, tmp15, lang.IFn_Cast(A_arbace_g2a_build_A_const_6.GetRawRoot__O()).Invoke_O__O(read__5))
//line :138:1
	var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__715000072); return tmp4.Invoke_O_O__O(tmp5, tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000073__3))) } else { s__715000073__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000073__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :138:1
func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :138:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A) Ctor_O_O_O_I_O(c__dir, c__read_fn, c__b__715000075 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_read_fn = c__read_fn; t.F_b__715000075 = c__b__715000075; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :138:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A) Invoke_O__O(self any) any { { var i__715000074__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000074__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000074__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_58.GetRawRoot__O()).Invoke_O_O__O(f__2, t.F_read_fn)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000075; var tmp4 any; var read__3 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_59.GetRawRoot__O()); var tmp6 *lang.PersistentVector
																lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; read__3 = tmp5.Invoke_O__O(tmp6.Ref())
//line :138:1
	var pkg__4 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_60.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_New_O_O(t.F_read_fn, read__3); var tmp9 *jrt.Class
	var fncls__14 /*line :138:1*/*jrt.Class = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_fn_class

	if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_fn_class = fncls__14d; tmp9 = fncls__14d } else { tmp9 = fncls__14 }; pkg__4 = tmp7.Invoke_O_O__O(f__2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil))
//line :138:1
	var tmp10 *lang.Keyword = A_arbace_g2a_build_A_const_46; var path__5 any = tmp10.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__4))



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_64.GetRawRoot__O()).Invoke_O__O(path__5)) { } else {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_134), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, f__2), nil)).Ref())
	}
	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_build_A_const_50; var tmp13 any = A_arbace_g2a_build_A_const_46; var tmp14 any = A_arbace_g2a_build_A_const_66; tmp4 = tmp11.Invoke_O_O_O_O_O_O_O__O(pkg__4, tmp12, f__2, tmp13, path__5, tmp14, lang.IFn_Cast(A_arbace_g2a_build_A_const_6.GetRawRoot__O()).Invoke_O__O(read__3))
//line :138:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__715000074__1 = lang.Numbers_Unchecked_inc_J__J(i__715000074__1); continue L1 } else { i__715000074__1 = lang.Numbers_Unchecked_inc_J__J(i__715000074__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :140:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A) Invoke_O_O__O(self, file__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_63.GetRawRoot__O()); var tmp2 any = t.F_read; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_g2a_build_A_const_7.GetRawRoot__O(), file__1); return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }
//line :140:1
func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :140:1
func (t *A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A) Invoke_O_O__O(self, file__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_63.GetRawRoot__O()); var tmp2 any = t.F_read; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_g2a_build_A_const_7.GetRawRoot__O(), file__1); return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }









func A_arbace_g2a_build_root_packages_fn__715000093_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_fn__715000093_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000093_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_g2a_build_root_packages_fn__715000093_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :150:1
func (t *A_arbace_g2a_build_root_packages_fn__715000093_A) Invoke_O_O__O(self, p1__715000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_dir; return tmp1.Invoke_O_O__O(tmp2, A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000071_SHARP___1)) }
//line :150:1
func A_arbace_g2a_build_root_packages_fn__715000098_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_fn__715000098_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000098_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_g2a_build_root_packages_fn__715000098_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :150:1
func (t *A_arbace_g2a_build_root_packages_fn__715000098_A) Invoke_O_O__O(self, p1__715000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_dir; return tmp1.Invoke_O_O__O(tmp2, A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000071_SHARP___1)) }


func A_arbace_g2a_build_read_program_edn_A_New() *A_arbace_g2a_build_read_program_edn_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_program_edn_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_g2a_build_read_program_edn_A) Ctor() {}
//line :153:1
func (t *A_arbace_g2a_build_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_122); if

	jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var forms__3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_54.GetRawRoot__O()).Invoke_O__O(f__2); var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(forms__3)))

		if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(forms__3)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() }; if jrt.A2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_123) }
		return lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(forms__3) } else {
//line :155:1
			lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_g2a_build_run_A_New() *A_arbace_g2a_build_run_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_run_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_g2a_build_run_A) Ctor() {}
//line :162:1
func (t *A_arbace_g2a_build_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any = jrt.ProcessBuilder_New_List(jrt.List_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), cmd__0)));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :162:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_715000102__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(env__2); var chunk_715000103__8 any; var count_715000104__9 int64 = 0; var i_715000105__10 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i_715000105__10, count_715000104__9) { var vec__715000106__11 any = lang.Indexed_Cast(chunk_715000103__8).Nth_I__O(lang.RT_IntCast_J__I(i_715000105__10)); var k__12 any = lang.RT_Nth_O_I_O__O(vec__715000106__11, lang.RT_IntCast_J__I(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O(vec__715000106__11, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_715000102__7, chunk_715000103__8, count_715000104__9, i_715000105__10 = seq_715000102__7, chunk_715000103__8, count_715000104__9, lang.Numbers_Unchecked_inc_J__J(i_715000105__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000102__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_715000102__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000102__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000102__12); seq_715000102__7, chunk_715000103__8, count_715000104__9, i_715000105__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000102__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000109__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000102__12); var k__14 any = lang.RT_Nth_O_I_O__O(vec__715000109__13, lang.RT_IntCast_J__I(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O(vec__715000109__13, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); seq_715000102__7, chunk_715000103__8, count_715000104__9, i_715000105__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000102__12), nil, 0, 0; continue L1 } } }
//line :162:1
		break L1 }; if







	jrt.A2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :170:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			var tmp1 *jrt.ProcessBuilder = jrt.ProcessBuilder_Cast(pb__5); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(tmp2).BooleanValue__Z())
//line :170:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_g2a_build_go_env_A_New() *A_arbace_g2a_build_go_env_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_go_env_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_g2a_build_go_env_A) Ctor() {}
//line :180:1
func (t *A_arbace_g2a_build_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z(goos__2, Lit_27) { var tmp4 *lang.Keyword = A_arbace_g2a_build_A_const_46; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_57, tmp4.Invoke_O__O(A_arbace_g2a_build_A_const_70.GetRawRoot__O()))) } else { tmp3 = nil }
//line :186:1
	var tmp5 any = tmp3; var tmp6 any
	var G__715000113__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I(G__715000113__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__715000113__4_, Lit_58) { tmp6 = A_arbace_g2a_build_A_const_71; break L1 }; case 1: if lang.Util_Equiv_O_O__Z(G__715000113__4_, Lit_5) { tmp6 = A_arbace_g2a_build_A_const_72; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__715000113__4_)))))}
//line :186:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :180:1
func (t *A_arbace_g2a_build_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	return lang.IFn_Cast(A_arbace_g2a_build_A_const_73.GetRawRoot__O()).Invoke_O_O_O__O(goroot__0, arch__1, Lit_37)
}

























func A_arbace_g2a_build_go_mod_cache_A_New() *A_arbace_g2a_build_go_mod_cache_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_go_mod_cache_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_g2a_build_go_mod_cache_A) Ctor() {}
//line :211:1
func (t *A_arbace_g2a_build_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__715000115__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_74.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_60, Lit_61); var tmp3 any = jrt.File_New_String(Lit_62); var tmp4 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_63, goroot__0, Lit_64, Lit_65)); var tmp5 *jrt.Boolean;
											jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; vec__715000115__2 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()); var status__3 any = /*line :211:1*/lang.RT_Nth_O_I_O__O(vec__715000115__2, lang.RT_IntCast_J__I(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O(vec__715000115__2, lang.RT_IntCast_J__I(1), nil); if


	lang.Numbers_IsZero_O__Z(status__3) { } else { lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; return /*line :215:1*/ lang.IFn_Cast(A_arbace_g2a_build_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(out__4)) }

func A_arbace_g2a_build_h1_of_file_A_New() *A_arbace_g2a_build_h1_of_file_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_g2a_build_h1_of_file_A) Ctor() {}
//line :217:1
func (t *A_arbace_g2a_build_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var tmp1 any = A_arbace_g2a_build_h1_of_file_hex__715000120_A_New(); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_g2a_build_h1_of_file_hex__715000120_A_fn_class; if


	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_g2a_build_h1_of_file_hex__715000120_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var sha__4 any; var tmp3 any = /*line :217:1*/A_arbace_g2a_build_h1_of_file_sha__715000124_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_build_h1_of_file_sha__715000124_A_fn_class; if



	fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_g2a_build_h1_of_file_sha__715000124_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var summary__5 any = /*line :217:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :223:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_70, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_71).Ref()), jrt.Prim_byte.ArrayClass())).Ref())).Ref() }
//line :220:1
func A_arbace_g2a_build_h1_of_file_hex__715000120_A_New() *A_arbace_g2a_build_h1_of_file_hex__715000120_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_hex__715000120_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000120_A) Ctor() {}
//line :220:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000120_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_76.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_New(); var tmp5 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_fn_class = fncls__22d; tmp5 = fncls__22d } else { tmp5 = fncls__22 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), b__1)) }
//line :220:1
func A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_New() *A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A) Ctor() {}
//line :220:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A) Invoke_O_O__O(self, p1__715000119_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_73, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000119_SHARP___1, 255)).Ref()) }
func A_arbace_g2a_build_h1_of_file_sha__715000124_A_New() *A_arbace_g2a_build_h1_of_file_sha__715000124_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_sha__715000124_A{}; t.Ctor(); return t }
//line :221:1
func (t *A_arbace_g2a_build_h1_of_file_sha__715000124_A) Ctor() {}
//line :221:1
func (t *A_arbace_g2a_build_h1_of_file_sha__715000124_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_74).Digest_B1__B1(jrt.A2g_CastArray[*jrt.ByteArray](b__1, jrt.Prim_byte.ArrayClass())).Ref() }



func A_arbace_g2a_build_tamago_go_sum_A_New() *A_arbace_g2a_build_tamago_go_sum_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_tamago_go_sum_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_g2a_build_tamago_go_sum_A) Ctor() {}
//line :225:1
func (t *A_arbace_g2a_build_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__715000127__2 any = A_arbace_g2a_build_A_const_70.GetRawRoot__O(); var map__715000127__3 any; if



	lang.ISeq_InstanceOf(map__715000127__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000127__2)) { map__715000127__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_78.GetRawRoot__O()).Invoke_O__O(map__715000127__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000127__2)) { map__715000127__3 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000127__2) } else { lang.PersistentArrayMap_Init(); map__715000127__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000127__3 = map__715000127__2 }; var path__4 any = /*line :225:1*/lang.RT_Get_O_O__O(map__715000127__3, A_arbace_g2a_build_A_const_46); var version__5 any = lang.RT_Get_O_O__O(map__715000127__3, A_arbace_g2a_build_A_const_79); var zip__6 any = lang.RT_Get_O_O__O(map__715000127__3, A_arbace_g2a_build_A_const_80); var mod__7 any = lang.RT_Get_O_O__O(map__715000127__3, A_arbace_g2a_build_A_const_81); var dir__8 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_137, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_build_A_const_82.GetRawRoot__O()).Invoke_O__O(goroot__0), nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_139), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_140), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp1 bool; var and__1927000168__auto____11 bool = jrt.NN(jrt.File_Cast(zf__9)).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(mf__10)).IsFile__Z(); if and__1927000168__auto____12 { tmp1 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_141), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp1 = and__1927000168__auto____12 } } else { tmp1 = and__1927000168__auto____11 }; if tmp1 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_142, nil, Lit_143, nil, Lit_144), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.NN(jrt.File_Cast(dir__8)).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any = /*line :225:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(zf__9)); var mh__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_83.GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(mf__10)).ToPath__Path()).Ref(), Lit_93); var tmp2 bool; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z(zh__12, zip__6); if and__1927000168__auto____14 {











				tmp2 = lang.Util_Equiv_O_O__Z(mh__13, mod__7) } else { tmp2 = and__1927000168__auto____14 }; if tmp2 { } else {
					lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :239:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_g2a_build_toolchain_lang_A_New() *A_arbace_g2a_build_toolchain_lang_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_toolchain_lang_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_g2a_build_toolchain_lang_A) Ctor() {}
//line :241:1
func (t *A_arbace_g2a_build_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__715000130__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_74.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_60, Lit_145); var tmp3 any = jrt.File_New_String(Lit_62); var tmp4 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_63, goroot__0, Lit_64, Lit_65)); var tmp5 *jrt.Boolean;


	jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; vec__715000130__2 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()); var status__3 any = /*line :241:1*/lang.RT_Nth_O_I_O__O(vec__715000130__2, lang.RT_IntCast_J__I(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O(vec__715000130__2, lang.RT_IntCast_J__I(1), nil); var v__5 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(out__4)); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool = lang.Numbers_IsZero_O__Z(status__3); if and__1927000168__auto____6 {





		temp__1927000408__auto____6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_85, v__5) } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }; if jrt.A2g_Truth(temp__1927000408__auto____6) { var vec__715000133__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O(vec__715000133__7, lang.RT_IntCast_J__I(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O(vec__715000133__7, lang.RT_IntCast_J__I(1), nil); _ = ___8; return l__9 } else {

			return lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_146, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_g2a_build_program_A_New() *A_arbace_g2a_build_program_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_g2a_build_program_A) Ctor() {}
//line :251:1
func (t *A_arbace_g2a_build_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__715000139__2 any) any { var map__715000140__4 any = p__715000139__2; var map__715000140__5 any; if lang.ISeq_InstanceOf(map__715000140__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000140__4)) { map__715000140__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_78.GetRawRoot__O()).Invoke_O__O(map__715000140__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000140__4)) { map__715000140__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000140__4) } else { lang.PersistentArrayMap_Init(); map__715000140__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000140__5 = map__715000140__4 }; var opts__6 any = map__715000140__5; var library_QMARK___7 any = lang.RT_Get_O_O__O(map__715000140__5, A_arbace_g2a_build_A_const_86); var roots__8 any = lang.RT_Get_O_O__O(map__715000140__5, A_arbace_g2a_build_A_const_87); var pkgs__9 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_52.GetRawRoot__O()).Invoke_O_O__O(dir__0, roots__8); var mains__10 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_program_fn__715000142_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_build_program_fn__715000142_A_fn_class; if







	fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_g2a_build_program_fn__715000142_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; mains__10 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), pkgs__9); var ___11 any; var tmp4 any; var or__1927000174__auto____11 bool = /*line :251:1*/lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(mains__10))); _ = ___11; if or__1927000174__auto____11 {








		tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.A2g_Truth(and__1927000168__auto____12) { tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_67.GetRawRoot__O()).Invoke_O__O(mains__10) } else { tmp4 = and__1927000168__auto____12 } }; if jrt.A2g_Truth(tmp4) { ___11 = nil } else {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_112, nil, nil); var tmp7 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(mains__10)).Ref(); var tmp8 *jrt.String
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(mains__10)) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_80, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()).Invoke_O_O__O(Lit_81, lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46, mains__10)))) } else { tmp8 = nil }
//line :261:1
			___11 = tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, tmp8.Ref())).Ref()) }; var main__12 any = /*line :251:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(mains__10); var edn__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_88.GetRawRoot__O()).Invoke_O__O(dir__0); var module__14 any; var or__1927000174__auto____14 any = A_arbace_g2a_build_A_const_89.Invoke_O__O(edn__13); if













	jrt.A2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_g2a_build_A_const_89.Invoke_O__O(opts__6); if jrt.A2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_g2a_build_A_const_46.Invoke_O__O(main__12); if jrt.A2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_113) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :251:1*/A_arbace_g2a_build_A_const_90.Invoke_O__O(edn__13); if

















	jrt.A2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_g2a_build_A_const_90.Invoke_O__O(opts__6); if jrt.A2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z(module__14, Lit_92) { golang__15 = nil } else { golang__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_91.GetRawRoot__O()).Invoke_O__O(goroot__1) } } }; var pkgs__16 any; var tmp9 lang.IFn = /*line :251:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____16 any; var tmp11 any = A_arbace_g2a_build_program_iter__715000144__715000148_A_New_O(module__14); var tmp12 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_g2a_build_program_iter__715000144__715000148_A_fn_class; if


















	fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_g2a_build_program_iter__715000144__715000148_A_fn_class = fncls__28d; tmp12 = fncls__28d } else { tmp12 = fncls__28 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); pkgs__16 = tmp9.Invoke_O__O(tmp10); var tmp13 any = A_arbace_g2a_build_A_const_89; var tmp14 any = A_arbace_g2a_build_A_const_90; var tmp15 any = /*line :251:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(golang__15); var tmp16 any = A_arbace_g2a_build_A_const_92; var tmp17 any = A_arbace_g2a_build_A_const_93; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_build_program_fn__715000154_A_New(); var tmp21 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_g2a_build_program_fn__715000154_A_fn_class; if





























	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_g2a_build_program_fn__715000154_A_fn_class = fncls__29d; tmp21 = fncls__29d } else { tmp21 = fncls__29 }; return /*line :251:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, module__14, tmp14, tmp15, tmp16, pkgs__16, tmp17, tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), pkgs__16)))) }
//line :251:1
func (t *A_arbace_g2a_build_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_97.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O__O(dir__0, goroot__1, tmp2.Ref())
}

func A_arbace_g2a_build_program_fn__715000142_A_New() *A_arbace_g2a_build_program_fn__715000142_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_fn__715000142_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_g2a_build_program_fn__715000142_A) Ctor() {}
//line :259:1
func (t *A_arbace_g2a_build_program_fn__715000142_A) Invoke_O_O__O(self, p1__715000137_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_88, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(p1__715000137_SHARP___1)))).Ref() }










func A_arbace_g2a_build_program_iter__715000144__715000148_A_New_O(p0 any) *A_arbace_g2a_build_program_iter__715000144__715000148_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_iter__715000144__715000148_A{}; t.Ctor_O(p0); return t }
//line :270:1
func (t *A_arbace_g2a_build_program_iter__715000144__715000148_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :270:1
func (t *A_arbace_g2a_build_program_iter__715000144__715000148_A) Invoke_O_O__O(self, s__715000145__1 any) any { var tmp1 any = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_New_O_O_O(self, s__715000145__1, t.F_module); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :270:1
func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :270:1
func (t *A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A) Ctor_O_O_O(c__iter__715000144, c__s__715000145, c__module any) { t.F_iter__715000144 = c__iter__715000144; t.F_s__715000145 = c__s__715000145; t.F_module = c__module }
//line :270:1
func (t *A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A) Invoke_O__O(self any) any { { var s__715000145__1 any; var t_ any = t.F_s__715000145; t.F_s__715000145 = nil; s__715000145__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000145__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000145__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000145__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000145__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000147__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_New_O_I_O_O(b__715000147__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000144); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000147__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000145__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000147__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000145__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()); var tmp5 any; var path__5 any = A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z(t.F_module, Lit_92) {


		tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__4, A_arbace_g2a_build_A_const_95, path__5) } else {
//line :272:1
			if lang.Util_Equiv_O_O__Z(path__5, t.F_module) {



				tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__4, A_arbace_g2a_build_A_const_95, Lit_90) } else {
//line :272:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()).Invoke_O_O__O(path__5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_110), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref())) {





						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_A_const_95; tmp5 = tmp6.Invoke_O_O_O__O(pkg__4, tmp7, lang.IFn_Cast(A_arbace_g2a_build_A_const_96.GetRawRoot__O()).Invoke_O_O__O(path__5, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(t.F_module)))).Ref())) } else {
//line :272:1
							if A_arbace_g2a_build_A_const_13 != nil {






								tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_118, nil, Lit_119, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :272:1
									tmp5 = nil } } } }
//line :270:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__715000144); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000145__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :270:1
func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :270:1
func (t *A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A) Ctor_O_I_O_O(c__b__715000147 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__715000147 = c__b__715000147; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :270:1
func (t *A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A) Invoke_O__O(self any) any { { var i__715000146__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000146__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000146__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000147; var tmp4 any; var path__3 any = A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z(t.F_module, Lit_92) {


		tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__2, A_arbace_g2a_build_A_const_95, path__3) } else {
//line :272:1
			if lang.Util_Equiv_O_O__Z(path__3, t.F_module) {



				tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__2, A_arbace_g2a_build_A_const_95, Lit_90) } else {
//line :272:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()).Invoke_O_O__O(path__3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_110), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref())) {





						var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_A_const_95; tmp4 = tmp5.Invoke_O_O_O__O(pkg__2, tmp6, lang.IFn_Cast(A_arbace_g2a_build_A_const_96.GetRawRoot__O()).Invoke_O_O__O(path__3, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(t.F_module)))).Ref())) } else {
//line :272:1
							if A_arbace_g2a_build_A_const_13 != nil {






								tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_118, nil, Lit_119, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :272:1
									tmp4 = nil } } } }
//line :270:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__715000146__1 = lang.Numbers_Unchecked_inc_J__J(i__715000146__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_g2a_build_program_fn__715000154_A_New() *A_arbace_g2a_build_program_fn__715000154_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_fn__715000154_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_g2a_build_program_fn__715000154_A) Ctor() {}
//line :281:1
func (t *A_arbace_g2a_build_program_fn__715000154_A) Invoke_O_O__O(self, p1__715000138_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_88, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(p1__715000138_SHARP___1)))).Ref() }




func A_arbace_g2a_build_sha256_A_New() *A_arbace_g2a_build_sha256_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_sha256_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_g2a_build_sha256_A) Ctor() {}
//line :286:1
func (t *A_arbace_g2a_build_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_74); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_76.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_sha256_fn__715000158_A_New(); var tmp5 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_g2a_build_sha256_fn__715000158_A_fn_class; if

	fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_g2a_build_sha256_fn__715000158_A_fn_class = fncls__30d; tmp5 = fncls__30d } else { tmp5 = fncls__30 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref())) }
//line :288:1
func A_arbace_g2a_build_sha256_fn__715000158_A_New() *A_arbace_g2a_build_sha256_fn__715000158_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_sha256_fn__715000158_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_g2a_build_sha256_fn__715000158_A) Ctor() {}
//line :288:1
func (t *A_arbace_g2a_build_sha256_fn__715000158_A) Invoke_O_O__O(self, p1__715000157_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_73, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000157_SHARP___1, 255)).Ref()) }

func A_arbace_g2a_build_copy_file_A_New() *A_arbace_g2a_build_copy_file_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_copy_file_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_g2a_build_copy_file_A) Ctor() {}
//line :290:1
func (t *A_arbace_g2a_build_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_98.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_A_const_99; var tmp5 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp5 = jrt.StandardCopyOption_REPLACE_EXISTING; return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.A2g_CastArray[*jrt.RefArray](tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5.Ref())), jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_g2a_build_forms_dir_A_New() *A_arbace_g2a_build_forms_dir_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_forms_dir_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_g2a_build_forms_dir_A) Ctor() {}
//line :295:1
func (t *A_arbace_g2a_build_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_g2a_build_A_const_50.Invoke_O__O(pkg__0); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_100; return jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__2)).GetParentFile__File(), jrt.String_Cast(tmp1.Invoke_O_O_O__O(n__3, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(n__3)), 3)).Ref()))) }







func A_arbace_g2a_build_with_line_files_A_New() *A_arbace_g2a_build_with_line_files_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_g2a_build_with_line_files_A) Ctor() {}
//line :303:1
func (t *A_arbace_g2a_build_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_101.GetRawRoot__O()).Invoke_O__O(pkg__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_102.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_103; var tmp3 any = A_arbace_g2a_build_with_line_files_fn__715000164_A_New_O(fdir__2); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_g2a_build_with_line_files_fn__715000164_A_fn_class; if






	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_g2a_build_with_line_files_fn__715000164_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; return tmp1.Invoke_O_O_O__O(pkg__0, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :310:1
func A_arbace_g2a_build_with_line_files_fn__715000164_A_New_O(p0 any) *A_arbace_g2a_build_with_line_files_fn__715000164_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_fn__715000164_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000164_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :310:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000164_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_104.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_New_O(t.F_fdir); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_148, false); A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :310:1
func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_New_O(p0 any) *A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :310:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A) Invoke_O_O__O(self, p1__715000163_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_102.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_105; var tmp3 any = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_New_O(t.F_fdir); var tmp4 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, false); A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_fn_class = fncls__31d; tmp4 = fncls__31d } else { tmp4 = fncls__31 }; return tmp1.Invoke_O_O_O__O(p1__715000163_SHARP___1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :310:1
func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_New_O(p0 any) *A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :310:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_fdir; return tmp1.Invoke_O_O__O(tmp2, jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1)))) }



func A_arbace_g2a_build_print_cache_key_A_New() *A_arbace_g2a_build_print_cache_key_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_cache_key_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_g2a_build_print_cache_key_A) Ctor() {}
//line :314:1
func (t *A_arbace_g2a_build_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_74); var add__7 any; var tmp1 any = A_arbace_g2a_build_print_cache_key_add__715000172_A_New_O(md__6); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_g2a_build_print_cache_key_add__715000172_A_fn_class; if





	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_g2a_build_print_cache_key_add__715000172_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0);
	lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(A_arbace_g2a_build_A_const_107.Invoke_O__O(opts__3), jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_g2a_build_A_const_108.Invoke_O__O(opts__3))).Ref(), jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tests__4)).Ref(), A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(pkg__1))))); var seq_715000174__8 any = /*line :314:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_66.Invoke_O__O(pkg__1)); var chunk_715000175__9 any; var count_715000176__10 int64 = 0; var i_715000177__11 int64 = 0; L1: for {








		if lang.Numbers_Lt_J_J__Z(i_715000177__11, count_715000176__10) { var f__12 any = lang.Indexed_Cast(chunk_715000175__9).Nth_I__O(lang.RT_IntCast_J__I(i_715000177__11))
			lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__2, f__12))
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__12)).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_90)
//line :323:1
			seq_715000174__8, chunk_715000175__9, count_715000176__10, i_715000177__11 = seq_715000174__8, chunk_715000175__9, count_715000176__10, lang.Numbers_Unchecked_inc_J__J(i_715000177__11); continue L1 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000174__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_715000174__13 any = temp__1927000414__auto____12; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000174__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000174__13); seq_715000174__8, chunk_715000175__9, count_715000176__10, i_715000177__11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000174__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__14 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000174__13)
				lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__2, f__14))
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__14)).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_90)
//line :323:1
				seq_715000174__8, chunk_715000175__9, count_715000176__10, i_715000177__11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000174__13), nil, 0, 0; continue L1 } } }
//line :314:1
		break L1 }; var tmp3 lang.IFn =












	lang.IFn_Cast(A_arbace_g2a_build_A_const_76.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_print_cache_key_fn__715000178_A_New(); var tmp7 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_g2a_build_print_cache_key_fn__715000178_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_g2a_build_print_cache_key_fn__715000178_A_fn_class = fncls__35d; tmp7 = fncls__35d } else { tmp7 = fncls__35 }; return tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.MessageDigest_Cast(md__6).Digest__B1().Ref())) }
//line :320:1
func A_arbace_g2a_build_print_cache_key_add__715000172_A_New_O(p0 any) *A_arbace_g2a_build_print_cache_key_add__715000172_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_cache_key_add__715000172_A{}; t.Ctor_O(p0); return t }
//line :320:1
func (t *A_arbace_g2a_build_print_cache_key_add__715000172_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :320:1
func (t *A_arbace_g2a_build_print_cache_key_add__715000172_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_71)); return nil }






func A_arbace_g2a_build_print_cache_key_fn__715000178_A_New() *A_arbace_g2a_build_print_cache_key_fn__715000178_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_cache_key_fn__715000178_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_g2a_build_print_cache_key_fn__715000178_A) Ctor() {}
//line :327:1
func (t *A_arbace_g2a_build_print_cache_key_fn__715000178_A) Invoke_O_O__O(self, p1__715000171_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_73, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000171_SHARP___1, 255)).Ref()) }

func A_arbace_g2a_build_cached_texts_A_New() *A_arbace_g2a_build_cached_texts_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_g2a_build_cached_texts_A) Ctor() {}
//line :329:1
func (t *A_arbace_g2a_build_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_41); if




	jrt.NN(jrt.File_Cast(names__2)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(entry__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_109.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_110.GetRawRoot__O()).Invoke__O(); var tmp3 any; var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_New_O(entry__0); var tmp5 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_fn_class
		if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_fn_class = fncls__38d; tmp5 = fncls__38d } else { tmp5 = fncls__38 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(names__2)))
//line :336:1
		return tmp1.Invoke_O_O__O(tmp2, tmp3) } else {
//line :334:1
			return nil } }


func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_New_O(p0 any) *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A{}; t.Ctor_O(p0); return t }
//line :337:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :337:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A) Invoke_O_O__O(self, s__715000182__1 any) any { var tmp1 any = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_New_O_O_O(s__715000182__1, t.F_entry, self); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A) Ctor_O_O_O(c__s__715000182, c__entry, c__iter__715000181 any) { t.F_s__715000182 = c__s__715000182; t.F_entry = c__entry; t.F_iter__715000181 = c__iter__715000181 }
//line :337:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A) Invoke_O__O(self any) any { { var s__715000182__1 any; var t_ any = t.F_s__715000182; t.F_s__715000182 = nil; s__715000182__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000182__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000182__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000182__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000182__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000184__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_New_O_O_I_O(b__715000184__6, t.F_entry, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000181); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000184__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000182__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000184__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000182__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(n__4)) { var tmp4 *jrt.File = jrt.File_Cast(t.F_entry); var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__715000181); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.File_New_File_String(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4))))), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000182__3))) } else { s__715000182__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000182__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :337:1
func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :337:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A) Ctor_O_O_I_O(c__b__715000184, c__entry any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__715000184 = c__b__715000184; t.F_entry = c__entry; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A) Invoke_O__O(self any) any { { var i__715000183__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000183__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000183__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(n__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000184; var tmp4 *jrt.File = jrt.File_Cast(t.F_entry); tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.File_New_File_String(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2)))))); i__715000183__1 = lang.Numbers_Unchecked_inc_J__J(i__715000183__1); continue L1 } else { i__715000183__1 = lang.Numbers_Unchecked_inc_J__J(i__715000183__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_g2a_build_cache_texts_BANG__A_New() *A_arbace_g2a_build_cache_texts_BANG__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_g2a_build_cache_texts_BANG__A) Ctor() {}
//line :340:1
func (t *A_arbace_g2a_build_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.NN(jrt.File_Cast(entry__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_39, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(entry__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(tmp__3)).Mkdirs__Z()); var seq_715000193__4 any = /*line :340:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(texts__1); var chunk_715000194__5 any; var count_715000195__6 int64 = 0; var i_715000196__7 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z(i_715000196__7, count_715000195__6) { var vec__715000197__8 any = lang.Indexed_Cast(chunk_715000194__5).Nth_I__O(lang.RT_IntCast_J__I(i_715000196__7)); var n__9 any = lang.RT_Nth_O_I_O__O(vec__715000197__8, lang.RT_IntCast_J__I(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O(vec__715000197__8, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_715000193__4, chunk_715000194__5, count_715000195__6, i_715000196__7 = seq_715000193__4, chunk_715000194__5, count_715000195__6, lang.Numbers_Unchecked_inc_J__J(i_715000196__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000193__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_715000193__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000193__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000193__9); seq_715000193__4, chunk_715000194__5, count_715000195__6, i_715000196__7 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000193__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000200__10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000193__9); var n__11 any = lang.RT_Nth_O_I_O__O(vec__715000200__10, lang.RT_IntCast_J__I(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O(vec__715000200__10, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); seq_715000193__4, chunk_715000194__5, count_715000195__6, i_715000196__7 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000193__9), nil, 0, 0; continue L1 } } }
//line :340:1
		break L1 }; var tmp1 lang.IFn =





	lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()); var tmp2 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_41); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_New(); var tmp6 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_fn_class = fncls__39d; tmp6 = fncls__39d } else { tmp6 = fncls__39 }; tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_g2a_build_A_const_114.GetRawRoot__O()).Invoke_O__O(texts__1)))); if
	jrt.NN(jrt.File_Cast(tmp__3)).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_112.GetRawRoot__O()).Invoke_O__O(tmp__3) } }
//line :346:1
func A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_New() *A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A) Ctor() {}
//line :346:1
func (t *A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A) Invoke_O_O__O(self, p1__715000192_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, p1__715000192_SHARP___1, nil)).Ref() }


func A_arbace_g2a_build_print_module_A_New() *A_arbace_g2a_build_print_module_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_g2a_build_print_module_A) Ctor() {}
//line :349:1
func (t *A_arbace_g2a_build_print_module_A) Invoke_O_O_O_O_O__O(self, p__715000208__0, dir__1, out__2, p__715000209__3 any) any { var map__715000210__5 any = p__715000208__0; var map__715000210__6 any; if lang.ISeq_InstanceOf(map__715000210__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000210__5)) { map__715000210__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_78.GetRawRoot__O()).Invoke_O__O(map__715000210__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000210__5)) { map__715000210__6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000210__5) } else { lang.PersistentArrayMap_Init(); map__715000210__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000210__6 = map__715000210__5 }; var module__7 any = lang.RT_Get_O_O__O(map__715000210__6, A_arbace_g2a_build_A_const_89); var packages__8 any = lang.RT_Get_O_O__O(map__715000210__6, A_arbace_g2a_build_A_const_92); var golang__9 any = lang.RT_Get_O_O__O(map__715000210__6, A_arbace_g2a_build_A_const_90); var map__715000212__10 any = p__715000209__3; var map__715000212__11 any; if lang.ISeq_InstanceOf(map__715000212__10) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000212__10)) { map__715000212__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_78.GetRawRoot__O()).Invoke_O__O(map__715000212__10), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000212__10)) { map__715000212__11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000212__10) } else { lang.PersistentArrayMap_Init(); map__715000212__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000212__11 = map__715000212__10 }; var layout__12 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_107); var line_file__13 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_108); var tests__14 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_115); var goos__15 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_116); var goroot__16 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_117); var goos_dir__17 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_118); var print_cache__18 any = lang.RT_Get_O_O__O(map__715000212__11, A_arbace_g2a_build_A_const_119);









	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(out__2)).Mkdirs__Z()); if
	lang.Util_Equiv_O_O__Z(module__7, Lit_92) { } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()); var tmp2 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_93); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil, Lit_95, nil, Lit_43, nil); var tmp4 *jrt.String
		if lang.Util_Equiv_O_O__Z(goos__15, Lit_27) {
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil, Lit_97, nil, Lit_43, nil); var tmp6 *lang.Keyword = A_arbace_g2a_build_A_const_46; var tmp7 any = tmp6.Invoke_O__O(A_arbace_g2a_build_A_const_70.GetRawRoot__O()); var tmp8 *lang.Keyword = A_arbace_g2a_build_A_const_79; var tmp9 any = tmp8.Invoke_O__O(A_arbace_g2a_build_A_const_70.GetRawRoot__O()); var tmp10 *jrt.String

			if jrt.A2g_Truth(goos_dir__17) {
				var tmp11 *lang.Keyword = A_arbace_g2a_build_A_const_46; var tmp12 *lang.Keyword = A_arbace_g2a_build_A_const_79; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, tmp11.Invoke_O__O(A_arbace_g2a_build_A_const_70.GetRawRoot__O()), nil, tmp12.Invoke_O__O(A_arbace_g2a_build_A_const_70.GetRawRoot__O()), nil, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(goos_dir__17))).GetAbsoluteFile__File()).GetPath__String().Ref(), nil)) } else {
//line :365:1
					tmp10 = nil }
//line :363:1
			tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp9, nil, tmp10.Ref())) } else {
//line :362:1
				tmp4 = nil }
//line :361:1
		tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__9, nil, tmp4.Ref())).Ref()) }; var tmp13 any; var and__1927000168__auto____19 bool =







	lang.Util_Equiv_O_O__Z(goos__15, Lit_27); if and__1927000168__auto____19 { tmp13 = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(goos_dir__17) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____19).Ref() }; if jrt.A2g_Truth(tmp13) {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_98), lang.IFn_Cast(A_arbace_g2a_build_A_const_120.GetRawRoot__O()).Invoke_O__O(goroot__16)) }; var tmp14 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()); var tmp16 any; if
	lang.Util_Equiv_O_O__Z(module__7, Lit_92) { tmp16 = nil } else { tmp16 = A_arbace_g2a_build_A_const_121 }; var tmp17 any = tmp16; var tmp18 lang.IFn = /*line :371:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_76.GetRawRoot__O()); var tmp19 any = A_arbace_g2a_build_A_const_43.GetRawRoot__O(); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_55.GetRawRoot__O()); var tmp21 any = A_arbace_g2a_build_print_module_fn__715000214_A_New_O_O_O_O_O_O(dir__1, out__2, tests__14, line_file__13, layout__12, print_cache__18); var tmp22 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000214_A_fn_class; if


	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_g2a_build_print_module_fn__715000214_A_fn_class = fncls__43d; tmp22 = fncls__43d } else { tmp22 = fncls__43 }; return /*line :371:1*/ tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), packages__8)))) }


func A_arbace_g2a_build_print_module_fn__715000214_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_g2a_build_print_module_fn__715000214_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000214_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :374:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :374:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z(Lit_90, A_arbace_g2a_build_A_const_95.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_g2a_build_A_const_95.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__715000215__3_ any; var tmp2 any = A_arbace_g2a_build_A_const_107; var tmp3 any; var or__1927000174__auto____3 any = /*line :374:1*/t.F_layout; if

	jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.A2g_Truth(t.F_line_file) { tmp3 = A_arbace_g2a_build_A_const_122 } else { tmp3 = A_arbace_g2a_build_A_const_123 } }; G__715000215__3_ = /*line :374:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.A2g_Truth(t.F_line_file) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_A_const_108; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; opts__3 = tmp4.Invoke_O_O_O__O(G__715000215__3_, tmp5, tmp6.Ref()) } else {
//line :376:1
			opts__3 = G__715000215__3_ }; var tmp7 /*line :374:1*/*lang.Keyword = A_arbace_g2a_build_A_const_129; var test_files__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_124.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), tmp7.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1)))); var pkg__5 any; if




	jrt.A2g_Truth(t.F_tests) { pkg__5 = pkg__1 } else {

		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_102.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_build_A_const_103; var tmp10 any = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_New_O(test_files__4); var tmp11 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_fn_class = fncls__42d; tmp11 = fncls__42d } else { tmp11 = fncls__42 }; pkg__5 = tmp8.Invoke_O_O_O__O(pkg__1, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)) }; var host_id__6 any = /*line :374:1*/jrt.System_Getenv_String__String(Lit_101).Ref(); var entry__7 any; var tmp12 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.A2g_Truth(and__1927000168__auto____7) { tmp12 = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(host_id__6) } else { tmp12 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp12) { var k__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_125.GetRawRoot__O()).Invoke_O_O_O_O_O__O(host_id__6, pkg__5, t.F_dir, opts__3, t.F_tests); var tmp13 *jrt.Class = A_arbace_g2a_build_A_const_126; entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp13, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(t.F_print_cache)), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_96.GetRawRoot__O()).Invoke_O_O_O__O(k__7, A_arbace_g2a_build_A_const_100, A_arbace_g2a_build_A_const_131))), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.A2g_Truth(entry__7) { or__1927000174__auto____8 = lang.IFn_Cast(A_arbace_g2a_build_A_const_127.GetRawRoot__O()).Invoke_O__O(entry__7) } else { or__1927000174__auto____8 = nil }; if jrt.A2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_128.GetRawRoot__O()); var tmp15 any; var G__715000220__9_ any = pkg__5
		if jrt.A2g_Truth(t.F_line_file) { tmp15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_132.GetRawRoot__O()).Invoke_O__O(G__715000220__9_) } else { tmp15 = G__715000220__9_ }; t__9 = tmp14.Invoke_O_O__O(tmp15, opts__3)
		if jrt.A2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(entry__7)).GetParentFile__File()).Mkdirs__Z())
			lang.IFn_Cast(A_arbace_g2a_build_A_const_133.GetRawRoot__O()).Invoke_O_O__O(entry__7, t__9) }
//line :386:1
		texts__8 = t__9 }; var declared__9 any; var tmp16 /*line :374:1*/*lang.Keyword = A_arbace_g2a_build_A_const_103; var temp__1927000414__auto____9 any = tmp16.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5)); if

















	jrt.A2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()); var tmp18 any
		if jrt.A2g_Truth(t.F_tests) { var tmp19 *lang.Keyword = A_arbace_g2a_build_A_const_129; tmp18 = tmp19.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5)) } else { tmp18 = nil }; declared__9 = tmp17.Invoke_O_O__O(fs__10, tmp18) } else {
//line :392:1
			declared__9 = nil }; var rel__10 any; var tmp20 any = /*line :374:1*/A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_New_O(pkg__5); var tmp21 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_fn_class; if
	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_fn_class = fncls__40d; tmp21 = fncls__40d } else { tmp21 = fncls__40 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var src__11 any = /*line :374:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_101.GetRawRoot__O()).Invoke_O__O(pkg__5); var tmp22 any; var and__1927000168__auto____12 any = declared__9; if





















	jrt.A2g_Truth(and__1927000168__auto____12) { tmp22 = lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_124.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), declared__9)), lang.IFn_Cast(A_arbace_g2a_build_A_const_124.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_114.GetRawRoot__O()).Invoke_O__O(texts__8))) } else { tmp22 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp22) {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_104, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__5), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_106.GetRawRoot__O()).Invoke_O__O(declared__9), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_114.GetRawRoot__O()).Invoke_O__O(texts__8))))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(pdir__2)).Mkdirs__Z()); var seq_715000223__12 any = /*line :374:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(texts__8); var chunk_715000224__13 any; var count_715000225__14 int64 = 0; var i_715000226__15 int64 = 0; L1: for {

























		if lang.Numbers_Lt_J_J__Z(i_715000226__15, count_715000225__14) { var vec__715000227__16 any = lang.Indexed_Cast(chunk_715000224__13).Nth_I__O(lang.RT_IntCast_J__I(i_715000226__15)); var n__17 any = lang.RT_Nth_O_I_O__O(vec__715000227__16, lang.RT_IntCast_J__I(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O(vec__715000227__16, lang.RT_IntCast_J__I(1), nil)
			lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18)
//line :400:1
			seq_715000223__12, chunk_715000224__13, count_715000225__14, i_715000226__15 = seq_715000223__12, chunk_715000224__13, count_715000225__14, lang.Numbers_Unchecked_inc_J__J(i_715000226__15); continue L1 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000223__12); if jrt.A2g_Truth(temp__1927000414__auto____16) { var seq_715000223__17 any = temp__1927000414__auto____16; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000223__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000223__17); seq_715000223__12, chunk_715000224__13, count_715000225__14, i_715000226__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000223__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000230__18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000223__17); var n__19 any = lang.RT_Nth_O_I_O__O(vec__715000230__18, lang.RT_IntCast_J__I(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O(vec__715000230__18, lang.RT_IntCast_J__I(1), nil)
				lang.IFn_Cast(A_arbace_g2a_build_A_const_113.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20)
//line :400:1
				seq_715000223__12, chunk_715000224__13, count_715000225__14, i_715000226__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000223__17), nil, 0, 0; continue L1 } } }
//line :374:1
		break L1 }; var tmp23 *lang.Keyword = A_arbace_g2a_build_A_const_134; var seq_715000233__12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5))); var chunk_715000234__13 any; var count_715000235__14 int64 = 0; var i_715000236__15 int64 = 0; L2: for {



























			if lang.Numbers_Lt_J_J__Z(i_715000236__15, count_715000235__14) { var f__16 any = lang.Indexed_Cast(chunk_715000234__13).Nth_I__O(lang.RT_IntCast_J__I(i_715000236__15))
				lang.IFn_Cast(A_arbace_g2a_build_A_const_135.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__16))), jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__16))))
//line :402:1
				seq_715000233__12, chunk_715000234__13, count_715000235__14, i_715000236__15 = seq_715000233__12, chunk_715000234__13, count_715000235__14, lang.Numbers_Unchecked_inc_J__J(i_715000236__15); continue L2 } else { var temp__1927000414__auto____16_2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000233__12); if jrt.A2g_Truth(temp__1927000414__auto____16_2) { var seq_715000233__17 any = temp__1927000414__auto____16_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000233__17)) { var c__1927000678__auto____18_2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000233__17); seq_715000233__12, chunk_715000234__13, count_715000235__14, i_715000236__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000233__17), c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var f__18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000233__17)
					lang.IFn_Cast(A_arbace_g2a_build_A_const_135.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__18))), jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__18))))
//line :402:1
					seq_715000233__12, chunk_715000234__13, count_715000235__14, i_715000236__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000233__17), nil, 0, 0; continue L2 } } }
//line :374:1
			break L2 }; var tmp24 *lang.Keyword = A_arbace_g2a_build_A_const_136; var seq_715000237__12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(tmp24.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5))); var chunk_715000238__13 any; var count_715000239__14 int64 = 0; var i_715000240__15 int64 = 0; L3: for {





























				if lang.Numbers_Lt_J_J__Z(i_715000240__15, count_715000239__14) { var vec__715000241__16 any = lang.Indexed_Cast(chunk_715000238__13).Nth_I__O(lang.RT_IntCast_J__I(i_715000240__15)); var f__17 any = lang.RT_Nth_O_I_O__O(vec__715000241__16, lang.RT_IntCast_J__I(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O(vec__715000241__16, lang.RT_IntCast_J__I(1), nil); var from__19 any = jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__17)))

					if jrt.NN(jrt.File_Cast(from__19)).IsFile__Z() { } else {
						lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__5), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, from__19))).Ref()) }
					var tmp25 any; var and__1927000168__auto____20 any = h__18; if jrt.A2g_Truth(and__1927000168__auto____20) { tmp25 = lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_137.GetRawRoot__O()).Invoke_O__O(from__19), lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(h__18)) } else { tmp25 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp25) {
						lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_106, nil, Lit_107, nil, Lit_108, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__5), nil, f__17, nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_137.GetRawRoot__O()).Invoke_O__O(from__19), nil, h__18)).Ref())
					}
					lang.IFn_Cast(A_arbace_g2a_build_A_const_135.GetRawRoot__O()).Invoke_O_O__O(from__19, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__17))))
//line :404:1
					seq_715000237__12, chunk_715000238__13, count_715000239__14, i_715000240__15 = seq_715000237__12, chunk_715000238__13, count_715000239__14, lang.Numbers_Unchecked_inc_J__J(i_715000240__15); continue L3 } else { var temp__1927000414__auto____16_3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000237__12); if jrt.A2g_Truth(temp__1927000414__auto____16_3) { var seq_715000237__17 any = temp__1927000414__auto____16_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000237__17)) { var c__1927000678__auto____18_3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000237__17); seq_715000237__12, chunk_715000238__13, count_715000239__14, i_715000240__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000237__17), c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__715000244__18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000237__17); var f__19 any = lang.RT_Nth_O_I_O__O(vec__715000244__18, lang.RT_IntCast_J__I(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O(vec__715000244__18, lang.RT_IntCast_J__I(1), nil); var from__21 any = jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__19)))

						if jrt.NN(jrt.File_Cast(from__21)).IsFile__Z() { } else {
							lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__5), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, from__21))).Ref()) }
						var tmp26 any; var and__1927000168__auto____22 any = h__20; if jrt.A2g_Truth(and__1927000168__auto____22) { tmp26 = lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_137.GetRawRoot__O()).Invoke_O__O(from__21), lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(h__20)) } else { tmp26 = and__1927000168__auto____22 }; if jrt.A2g_Truth(tmp26) {
							lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_106, nil, Lit_107, nil, Lit_108, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__5), nil, f__19, nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_137.GetRawRoot__O()).Invoke_O__O(from__21), nil, h__20)).Ref())
						}
						lang.IFn_Cast(A_arbace_g2a_build_A_const_135.GetRawRoot__O()).Invoke_O_O__O(from__21, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__19))))
//line :404:1
						seq_715000237__12, chunk_715000238__13, count_715000239__14, i_715000240__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000237__17), nil, 0, 0; continue L3 } } }
//line :374:1
				break L3 }; var tmp27 /*line :412:1*/*lang.Keyword = A_arbace_g2a_build_A_const_134; var tmp28 *lang.Keyword = A_arbace_g2a_build_A_const_136; return lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(rel__10, lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_114.GetRawRoot__O()).Invoke_O__O(texts__8), lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), tmp27.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5))), lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_138.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), A_arbace_g2a_build_A_const_20.GetRawRoot__O()), tmp28.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5))))) }
//line :375:1
func A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_New_O(p0 any) *A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A{}; t.Ctor_O(p0); return t }
//line :375:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :375:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A) Invoke_O_O__O(self, p1__715000207_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z(Lit_90, A_arbace_g2a_build_A_const_95.Invoke_O__O(t.F_pkg)) { return p1__715000207_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_95.Invoke_O__O(t.F_pkg), nil, p1__715000207_SHARP___1)).Ref() } }
//line :381:1
func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_New_O(p0 any) *A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A{}; t.Ctor_O(p0); return t }
//line :381:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :381:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_130.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_New_O(t.F_test_files); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :381:1
func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_New_O(p0 any) *A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A{}; t.Ctor_O(p0); return t }
//line :381:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :381:1
func (t *A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A) Invoke_O_O__O(self, p1__715000206_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); return lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(p1__715000206_SHARP___1)))) }





































func A_arbace_g2a_build_delete_tree_A_New() *A_arbace_g2a_build_delete_tree_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_delete_tree_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_g2a_build_delete_tree_A) Ctor() {}
//line :419:1
func (t *A_arbace_g2a_build_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.NN(jrt.File_Cast(f__0)).IsDirectory__Z() { var seq_715000249__2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(f__0)).ListFiles__File1().Ref()); var chunk_715000250__3 any; var count_715000251__4 int64 = 0; var i_715000252__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_715000252__5, count_715000251__4) { var c__6 any = lang.Indexed_Cast(chunk_715000250__3).Nth_I__O(lang.RT_IntCast_J__I(i_715000252__5)); lang.IFn_Cast(A_arbace_g2a_build_A_const_112.GetRawRoot__O()).Invoke_O__O(c__6); seq_715000249__2, chunk_715000250__3, count_715000251__4, i_715000252__5 = seq_715000249__2, chunk_715000250__3, count_715000251__4, lang.Numbers_Unchecked_inc_J__J(i_715000252__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000249__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_715000249__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000249__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000249__7); seq_715000249__2, chunk_715000250__3, count_715000251__4, i_715000252__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000249__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000249__7); lang.IFn_Cast(A_arbace_g2a_build_A_const_112.GetRawRoot__O()).Invoke_O__O(c__8); seq_715000249__2, chunk_715000250__3, count_715000251__4, i_715000252__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000249__7), nil, 0, 0; continue L1 } } }
//line :420:1
		break L1
	} }
	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__0)).Delete__Z()).Ref()
}
func A_arbace_g2a_build_build_A_New() *A_arbace_g2a_build_build_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_build_A{}; t.Ctor(); return t }
//line :424:1
func (t *A_arbace_g2a_build_build_A) Ctor() {}
//line :424:1
func (t *A_arbace_g2a_build_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__715000254__3 any) any { var map__715000255__5 any = p__715000254__3; var map__715000255__6 any; if lang.ISeq_InstanceOf(map__715000255__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000255__5)) { map__715000255__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_78.GetRawRoot__O()).Invoke_O__O(map__715000255__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000255__5)) { map__715000255__6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000255__5) } else { lang.PersistentArrayMap_Init(); map__715000255__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000255__6 = map__715000255__5 }; var opts__7 any = map__715000255__6; var work__8 any = lang.RT_Get_O_O__O(map__715000255__6, A_arbace_g2a_build_A_const_139); var goroot__9 any = lang.RT_Get_O_O__O(map__715000255__6, A_arbace_g2a_build_A_const_117); var prog__10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, goroot__9, opts__7); var main__11 any = A_arbace_g2a_build_A_const_93.Invoke_O__O(prog__10); var tmp1 *lang.Keyword = A_arbace_g2a_build_A_const_140; var config__12 any = tmp1.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z(work__8, nil); var work__14 any; if







	jrt.A2g_Truth(work__8) { work__14 = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(work__8))) } else {

		work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(Lit_26, jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_141.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_143, A_arbace_g2a_build_A_const_100), jrt.FileAttribute_class.ArrayClass())).ToFile__File().Ref() }; var tmp2 any; tmp16 := /*line :424:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_23)












			if jrt.NN(jrt.File_Cast(mod__17)).Exists__Z() { lang.IFn_Cast(A_arbace_g2a_build_A_const_112.GetRawRoot__O()).Invoke_O__O(mod__17) }
			lang.IFn_Cast(A_arbace_g2a_build_A_const_144.GetRawRoot__O()).Invoke_O_O_O_O__O(prog__10, dir__0, mod__17, opts__7)
//line :424:1
			var tags__18 any = A_arbace_g2a_build_A_const_142.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z(A_arbace_g2a_build_A_const_116.Invoke_O__O(opts__7), Lit_27); var cmd__20 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()); var tmp4 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_29, Lit_30, Lit_31); var tmp5 lang.IPersistentVector

















			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(tags__18)) { tmp5 = lang.Tuple_Create_O_O__IPersistentVector(Lit_32, lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()).Invoke_O_O__O(Lit_33, tags__18)) } else { tmp5 = nil }
//line :441:1
			var tmp6 any = tmp5; var tmp7 lang.IPersistentVector

			if tamago_QMARK___19 { tmp7 = lang.Tuple_Create_O_O__IPersistentVector(Lit_34, A_arbace_g2a_build_A_const_147.GetRawRoot__O()) } else { tmp7 = nil }
//line :441:1
			var tmp8 any = tmp7; var tmp9 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_g2a_build_A_const_145.Invoke_O__O(opts__7)


			if jrt.A2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; tmp9 = lang.Tuple_Create_O_O__IPersistentVector(Lit_35, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(o__21))).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp9 = nil }
//line :441:1
			var tmp10 any = tmp9; var tmp11 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_g2a_build_A_const_146.Invoke_O__O(opts__7)




			if jrt.A2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__21))).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp11 = nil }
//line :441:1
			cmd__20 = tmp3.Invoke_O_O_O_O_O_O__O(tmp4, tmp6, tmp8, tmp10, tmp11, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.NN(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File()).GetPath__String().Ref(), A_arbace_g2a_build_A_const_46.Invoke_O__O(main__11)))
//line :424:1
			var env__21 any; var G__715000260__21_ any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_73.GetRawRoot__O()); var tmp13 any; var or__1927000174__auto____21 any = A_arbace_g2a_build_A_const_116.Invoke_O__O(opts__7)
























			if jrt.A2g_Truth(or__1927000174__auto____21) { tmp13 = or__1927000174__auto____21 } else { tmp13 = Lit_37 }; G__715000260__21_ = tmp12.Invoke_O_O_O__O(goroot__9, arch__1, tmp13); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_148.Invoke_O__O(config__12))) {
				env__21 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(G__715000260__21_, Lit_38, A_arbace_g2a_build_A_const_148.Invoke_O__O(config__12)) } else {
//line :449:1
					env__21 = G__715000260__21_ }
//line :424:1
			var vec__715000257__22 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_74.GetRawRoot__O()); var tmp15 *jrt.Boolean


























			jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; vec__715000257__22 = tmp14.Invoke_O_O_O_O__O(cmd__20, mod__17, env__21, tmp15.Ref())
//line :424:1
			var status__23 any = lang.RT_Nth_O_I_O__O(vec__715000257__22, lang.RT_IntCast_J__I(0), nil); tmp2 = status__23 }; return nil }(); if tmp_QMARK___13 {





























				lang.IFn_Cast(A_arbace_g2a_build_A_const_112.GetRawRoot__O()).Invoke_O__O(work__14) }; if /*line :424:1*/ tmp16 != nil { panic(tmp16) }; return tmp2 }































func A_arbace_g2a_build__main_A_New() *A_arbace_g2a_build__main_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_A{}; t.Ctor(); return t }
//line :456:1
func (t *A_arbace_g2a_build__main_A) Ctor() {}
//line :456:1
func (t *A_arbace_g2a_build__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.A2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :456:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_149, Lit_5, A_arbace_g2a_build_A_const_117, goroot__2)); L1: for { var G__715000262__6_ any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4)




		switch lang.Util_Hash_O__I(G__715000262__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_6) {











			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_89; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp1.Invoke_O_O_O__O(opts__5, tmp2, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 6: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_7) {









			var tmp3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_A_const_150; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; as__4, opts__5 = tmp3, tmp4.Invoke_O_O_O__O(opts__5, tmp5, tmp6.Ref()); continue L1 }
//line :461:1
		case 8: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_8) {










			var tmp7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_build_A_const_115; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; as__4, opts__5 = tmp7, tmp8.Invoke_O_O_O__O(opts__5, tmp9, tmp10.Ref()); continue L1 }
//line :461:1
		case 11: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_9) {






			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_build_A_const_139; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp11.Invoke_O_O_O__O(opts__5, tmp12, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 12: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_10) {




			var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_build_A_const_107; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp13.Invoke_O_O_O__O(opts__5, tmp14, lang.IFn_Cast(A_arbace_g2a_build_A_const_167.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4))); continue L1 }
//line :461:1
		case 26: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_11) {












			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp16 any = A_arbace_g2a_build_A_const_118; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp15.Invoke_O_O_O__O(opts__5, tmp16, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 30: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_12) {



			var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp18 any = A_arbace_g2a_build_A_const_151; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp17.Invoke_O_O_O__O(opts__5, tmp18, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 31: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_13) {
			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_build_A_const_149; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp19.Invoke_O_O_O__O(opts__5, tmp20, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 33: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_14) {





			var tmp21 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp23 any = A_arbace_g2a_build_A_const_108; var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; as__4, opts__5 = tmp21, tmp22.Invoke_O_O_O__O(opts__5, tmp23, tmp24.Ref()); continue L1 }
//line :461:1
		case 38: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_15) {

			var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp26 any = A_arbace_g2a_build_A_const_116; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp25.Invoke_O_O_O__O(opts__5, tmp26, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 40: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_16) {


			var tmp27 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_102.GetRawRoot__O()); var tmp29 any = A_arbace_g2a_build_A_const_87; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_168.GetRawRoot__O()); var tmp31 any = A_arbace_g2a_build_A_const_7.GetRawRoot__O(); var tmp32 *lang.PersistentVector; lang.PersistentVector_Init(); tmp32 = lang.PersistentVector_EMPTY; as__4, opts__5 = tmp27, tmp28.Invoke_O_O_O_O__O(opts__5, tmp29, tmp30.Invoke_O_O__O(tmp31, tmp32.Ref()), lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 43: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_17) {







			var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_build_A_const_145; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp33.Invoke_O_O_O__O(opts__5, tmp34, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 44: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_18) {













			var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp36 any = A_arbace_g2a_build_A_const_119; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp35.Invoke_O_O_O__O(opts__5, tmp36, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		case 59: if lang.Util_Equiv_O_O__Z(G__715000262__6_, Lit_19) {








			var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp38 any = A_arbace_g2a_build_A_const_146; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O__O(as__4), tmp37.Invoke_O_O_O__O(opts__5, tmp38, lang.IFn_Cast(A_arbace_g2a_build_A_const_166.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :461:1
		default:
		}














		var tmp39 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4), Lit_20)); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_169); var and__1927000168__auto____9 any = tmp40.Invoke_O__O(A_arbace_g2a_build_A_const_149.Invoke_O__O(opts__5)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp42 any = A_arbace_g2a_build_A_const_170; var and__1927000168__auto____10 any = tmp41.Invoke_O_O__O(tmp42, A_arbace_g2a_build_A_const_116.Invoke_O__O(opts__5)); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp44 any = A_arbace_g2a_build_A_const_171; var and__1927000168__auto____11 any = tmp43.Invoke_O_O__O(tmp44, A_arbace_g2a_build_A_const_107.Invoke_O__O(opts__5)); if jrt.A2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_150.Invoke_O__O(opts__5))



			if jrt.A2g_Truth(or__1927000174__auto____12) { tmp39 = or__1927000174__auto____12 } else { tmp39 = A_arbace_g2a_build_A_const_139.Invoke_O__O(opts__5) } } else {
//line :477:1
				tmp39 = and__1927000168__auto____11 } } else { tmp39 = and__1927000168__auto____10 } } else { tmp39 = and__1927000168__auto____9 } } else { tmp39 = and__1927000168__auto____8 } } else { tmp39 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(tmp39) { } else {




					var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_162.GetRawRoot__O()); var tmp46 any = A_arbace_g2a_build_A_const_163; lang.IFn_Cast(A_arbace_g2a_build_A_const_161.GetRawRoot__O()).Invoke_O__O(tmp45.Invoke_O_O__O(tmp46, A_arbace_g2a_build_A_const_164.Get__O())); var tmp47 any = A_arbace_g2a_build__main_fn__715000263_A_New_O(usage__3); var tmp48 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_g2a_build__main_fn__715000263_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_g2a_build__main_fn__715000263_A_fn_class = fncls__47d; tmp48 = fncls__47d } else { tmp48 = fncls__47 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil).Invoke__O()
					jrt.System_Exit_I__V(lang.RT_IntCast_J__I(2)) }
//line :461:1
		var dir__7 any = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4))); var status__8 any; var tmp49 any = A_arbace_g2a_build__main_fn__715000265_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp50 *jrt.Class
		var fncls__46 /*line :461:1*/*jrt.Class = A_arbace_g2a_build__main_fn__715000265_A_fn_class























		if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_g2a_build__main_fn__715000265_A_fn_class = fncls__46d; tmp50 = fncls__46d } else { tmp50 = fncls__46 }; status__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil).Invoke__O()















		lang.IFn_Cast(A_arbace_g2a_build_A_const_172.GetRawRoot__O()).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I(status__8)); return nil } }; /*line :456:1*/panic("a2g: unreachable") }

























func A_arbace_g2a_build__main_fn__715000263_A_New_O(p0 any) *A_arbace_g2a_build__main_fn__715000263_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_fn__715000263_A{}; t.Ctor_O(p0); return t }
//line :482:1
func (t *A_arbace_g2a_build__main_fn__715000263_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :482:1
func (t *A_arbace_g2a_build__main_fn__715000263_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_build_A_const_160.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_g2a_build__main_fn__715000265_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build__main_fn__715000265_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_fn__715000265_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :485:1
func (t *A_arbace_g2a_build__main_fn__715000265_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :485:1
func (t *A_arbace_g2a_build__main_fn__715000265_A) Invoke_O__O(self any) any { var tmp1 any; tmp27 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.A2g_Truth(A_arbace_g2a_build_A_const_150.Invoke_O__O(t.F_opts)) { var prog__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_97.GetRawRoot__O()); var tmp3 any = t.F_dir; var tmp4 any; var t_ any = t.F_goroot
											t.F_goroot = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_g2a_build_A_const_86; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; var tmp8 any = tmp7.Ref(); var tmp9 any = A_arbace_g2a_build_A_const_89; var tmp10 any = A_arbace_g2a_build_A_const_89.Invoke_O__O(t.F_opts); var tmp11 any = A_arbace_g2a_build_A_const_87; prog__3 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp10, tmp11, A_arbace_g2a_build_A_const_87.Invoke_O__O(t.F_opts))))
//line :486:1
		var mod__4 any = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_139.Invoke_O__O(t.F_opts)))), Lit_23)


		if jrt.NN(jrt.File_Cast(mod__4)).Exists__Z() { lang.IFn_Cast(A_arbace_g2a_build_A_const_112.GetRawRoot__O()).Invoke_O__O(mod__4) }
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_144.GetRawRoot__O()); var tmp13 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp13 = t__2; var tmp14 any = tmp13; var tmp15 any; var t__3 any = t.F_opts; t.F_opts = nil; tmp15 = t__3; tmp12.Invoke_O_O_O_O__O(prog__3, tmp14, mod__4, tmp15)
//line :486:1
		tmp1 = A_arbace_g2a_build_A_const_100 } else { var prog_main__3 any





			if jrt.A2g_Truth(A_arbace_g2a_build_A_const_151.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp16 *lang.Keyword = A_arbace_g2a_build_A_const_93; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_97.GetRawRoot__O()); var tmp18 any = t.F_dir; var tmp19 any; var t__4 any = t.F_goroot; t.F_goroot = nil; tmp19 = t__4; prog_main__3 = tmp16.Invoke_O__O(tmp17.Invoke_O_O_O__O(tmp18, tmp19, t.F_opts)) }
//line :486:1
			var out__4 any; var tmp20 *jrt.Class = A_arbace_g2a_build_A_const_126; var tmp21 any; var or__1927000174__auto____4 any = A_arbace_g2a_build_A_const_151.Invoke_O__O(t.F_opts)






			if jrt.A2g_Truth(or__1927000174__auto____4) { tmp21 = or__1927000174__auto____4 } else {
				tmp21 = lang.IFn_Cast(A_arbace_g2a_build_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_154.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46.Invoke_O__O(prog_main__3), A_arbace_g2a_build_A_const_155)) }
//line :486:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp21))








			var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_153.GetRawRoot__O()); var tmp23 any; var t__5 any = t.F_dir; t.F_dir = nil; tmp23 = t__5; var tmp24 any = tmp23; var tmp25 any = A_arbace_g2a_build_A_const_149.Invoke_O__O(t.F_opts); var tmp26 any; var t__6 any = t.F_opts; t.F_opts = nil; tmp26 = t__6; tmp1 = tmp22.Invoke_O_O_O_O__O(tmp24, tmp25, out__4, tmp26) }
//line :485:1
	return nil }(); if tmp27 != nil { if lang.ExceptionInfo_InstanceOf(tmp27) { var e__3 *lang.ExceptionInfo = lang.ExceptionInfo_Cast(tmp27)
		var tmp28 /*line :485:1*/*lang.Keyword = A_arbace_g2a_build_A_const_156











		if jrt.A2g_Truth(tmp28.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_157.GetRawRoot__O()).Invoke_O__O(e__3.Ref()))) {
			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_162.GetRawRoot__O()); var tmp30 any = A_arbace_g2a_build_A_const_163; lang.IFn_Cast(A_arbace_g2a_build_A_const_161.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O_O__O(tmp30, A_arbace_g2a_build_A_const_164.Get__O())); var tmp31 any = A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_New_O(e__3.Ref()); var tmp32 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_fn_class = fncls__45d; tmp32 = fncls__45d } else { tmp32 = fncls__45 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :497:1
			tmp1 = A_arbace_g2a_build_A_const_158 } else { panic(jrt.Thrown(Up_ExceptionInfo_Throwable(e__3))) } } else {
//line :485:1
				panic(tmp27) } }; return tmp1 }












func A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_New_O(p0 any) *A_arbace_g2a_build__main_fn__715000265_fn__715000266_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_fn__715000265_fn__715000266_A{}; t.Ctor_O(p0); return t }
//line :498:1
func (t *A_arbace_g2a_build__main_fn__715000265_fn__715000266_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :498:1
func (t *A_arbace_g2a_build__main_fn__715000265_fn__715000266_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_build_A_const_160.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }







type A_arbace_g2a_build_A struct{ jrt.Object }

var A_arbace_g2a_build_A_const_pool *jrt.RefArray

var A_arbace_g2a_build_A_const_0 *lang.Var

var A_arbace_g2a_build_A_const_1 *lang.Var

var A_arbace_g2a_build_A_const_2 any

var A_arbace_g2a_build_A_const_3 any

var A_arbace_g2a_build_A_const_4 any

var A_arbace_g2a_build_A_const_5 *lang.Var

var A_arbace_g2a_build_A_const_6 *lang.Var

var A_arbace_g2a_build_A_const_7 *lang.Var

var A_arbace_g2a_build_A_const_8 any

var A_arbace_g2a_build_A_const_9 *lang.Var

var A_arbace_g2a_build_A_const_10 *lang.Var

var A_arbace_g2a_build_A_const_11 *lang.Var

var A_arbace_g2a_build_A_const_12 any

var A_arbace_g2a_build_A_const_13 *lang.Keyword

var A_arbace_g2a_build_A_const_14 *lang.Var

var A_arbace_g2a_build_A_const_15 *lang.Var

var A_arbace_g2a_build_A_const_16 *lang.Var

var A_arbace_g2a_build_A_const_17 *lang.Var

var A_arbace_g2a_build_A_const_18 *lang.Var

var A_arbace_g2a_build_A_const_19 *lang.Var

var A_arbace_g2a_build_A_const_20 *lang.Var

var A_arbace_g2a_build_A_const_21 *lang.Var

var A_arbace_g2a_build_A_const_22 *lang.Var

var A_arbace_g2a_build_A_const_23 *lang.Var

var A_arbace_g2a_build_A_const_24 any

var A_arbace_g2a_build_A_const_25 *lang.Var

var A_arbace_g2a_build_A_const_26 *lang.Var

var A_arbace_g2a_build_A_const_27 *lang.Var

var A_arbace_g2a_build_A_const_28 *lang.Var

var A_arbace_g2a_build_A_const_29 *lang.Var

var A_arbace_g2a_build_A_const_30 *lang.Var

var A_arbace_g2a_build_A_const_31 *lang.Var

var A_arbace_g2a_build_A_const_32 *lang.Var

var A_arbace_g2a_build_A_const_33 *lang.Var

var A_arbace_g2a_build_A_const_34 *lang.Var

var A_arbace_g2a_build_A_const_35 *lang.Var

var A_arbace_g2a_build_A_const_36 *lang.Keyword

var A_arbace_g2a_build_A_const_37 *lang.Var

var A_arbace_g2a_build_A_const_38 *lang.Var

var A_arbace_g2a_build_A_const_39 *lang.Var

var A_arbace_g2a_build_A_const_40 *lang.Var

var A_arbace_g2a_build_A_const_41 *lang.Var

var A_arbace_g2a_build_A_const_42 *lang.Var

var A_arbace_g2a_build_A_const_43 *lang.Var

var A_arbace_g2a_build_A_const_44 *lang.Var

var A_arbace_g2a_build_A_const_45 *lang.Var

var A_arbace_g2a_build_A_const_46 *lang.Keyword

var A_arbace_g2a_build_A_const_47 *lang.Var

var A_arbace_g2a_build_A_const_48 *lang.Var

var A_arbace_g2a_build_A_const_49 *lang.Var

var A_arbace_g2a_build_A_const_50 *lang.Keyword

var A_arbace_g2a_build_A_const_51 *lang.Var

var A_arbace_g2a_build_A_const_52 *lang.Var

var A_arbace_g2a_build_A_const_53 *lang.Var

var A_arbace_g2a_build_A_const_54 *lang.Var

var A_arbace_g2a_build_A_const_55 *lang.Var

var A_arbace_g2a_build_A_const_56 *lang.Var

var A_arbace_g2a_build_A_const_57 *lang.Var

var A_arbace_g2a_build_A_const_58 *lang.Var

var A_arbace_g2a_build_A_const_59 *lang.Var

var A_arbace_g2a_build_A_const_60 *lang.Var

var A_arbace_g2a_build_A_const_61 *lang.Keyword

var A_arbace_g2a_build_A_const_62 *lang.Var

var A_arbace_g2a_build_A_const_63 *lang.Var

var A_arbace_g2a_build_A_const_64 *lang.Var

var A_arbace_g2a_build_A_const_65 *lang.Var

var A_arbace_g2a_build_A_const_66 *lang.Keyword

var A_arbace_g2a_build_A_const_67 *lang.Var

var A_arbace_g2a_build_A_const_68 *lang.Var

var A_arbace_g2a_build_A_const_69 *lang.Var

var A_arbace_g2a_build_A_const_70 *lang.Var

var A_arbace_g2a_build_A_const_71 any

var A_arbace_g2a_build_A_const_72 any

var A_arbace_g2a_build_A_const_73 *lang.Var

var A_arbace_g2a_build_A_const_74 *lang.Var

var A_arbace_g2a_build_A_const_75 *lang.Var

var A_arbace_g2a_build_A_const_76 *lang.Var

var A_arbace_g2a_build_A_const_77 *lang.Var

var A_arbace_g2a_build_A_const_78 *lang.Var

var A_arbace_g2a_build_A_const_79 *lang.Keyword

var A_arbace_g2a_build_A_const_80 *lang.Keyword

var A_arbace_g2a_build_A_const_81 *lang.Keyword

var A_arbace_g2a_build_A_const_82 *lang.Var

var A_arbace_g2a_build_A_const_83 *lang.Var

var A_arbace_g2a_build_A_const_84 *lang.Var

var A_arbace_g2a_build_A_const_85 any

var A_arbace_g2a_build_A_const_86 *lang.Keyword

var A_arbace_g2a_build_A_const_87 *lang.Keyword

var A_arbace_g2a_build_A_const_88 *lang.Var

var A_arbace_g2a_build_A_const_89 *lang.Keyword

var A_arbace_g2a_build_A_const_90 *lang.Keyword

var A_arbace_g2a_build_A_const_91 *lang.Var

var A_arbace_g2a_build_A_const_92 *lang.Keyword

var A_arbace_g2a_build_A_const_93 *lang.Keyword

var A_arbace_g2a_build_A_const_94 *lang.Var

var A_arbace_g2a_build_A_const_95 *lang.Keyword

var A_arbace_g2a_build_A_const_96 *lang.Var

var A_arbace_g2a_build_A_const_97 *lang.Var

var A_arbace_g2a_build_A_const_98 *lang.Var

var A_arbace_g2a_build_A_const_99 *jrt.Class

var A_arbace_g2a_build_A_const_100 any

var A_arbace_g2a_build_A_const_101 *lang.Var

var A_arbace_g2a_build_A_const_102 *lang.Var

var A_arbace_g2a_build_A_const_103 *lang.Keyword

var A_arbace_g2a_build_A_const_104 *lang.Var

var A_arbace_g2a_build_A_const_105 *lang.Keyword

var A_arbace_g2a_build_A_const_106 *lang.Var

var A_arbace_g2a_build_A_const_107 *lang.Keyword

var A_arbace_g2a_build_A_const_108 *lang.Keyword

var A_arbace_g2a_build_A_const_109 *lang.Var

var A_arbace_g2a_build_A_const_110 *lang.Var

var A_arbace_g2a_build_A_const_111 *lang.Var

var A_arbace_g2a_build_A_const_112 *lang.Var

var A_arbace_g2a_build_A_const_113 *lang.Var

var A_arbace_g2a_build_A_const_114 *lang.Var

var A_arbace_g2a_build_A_const_115 *lang.Keyword

var A_arbace_g2a_build_A_const_116 *lang.Keyword

var A_arbace_g2a_build_A_const_117 *lang.Keyword

var A_arbace_g2a_build_A_const_118 *lang.Keyword

var A_arbace_g2a_build_A_const_119 *lang.Keyword

var A_arbace_g2a_build_A_const_120 *lang.Var

var A_arbace_g2a_build_A_const_121 any

var A_arbace_g2a_build_A_const_122 *lang.Keyword

var A_arbace_g2a_build_A_const_123 *lang.Keyword

var A_arbace_g2a_build_A_const_124 *lang.Var

var A_arbace_g2a_build_A_const_125 *lang.Var

var A_arbace_g2a_build_A_const_126 *jrt.Class

var A_arbace_g2a_build_A_const_127 *lang.Var

var A_arbace_g2a_build_A_const_128 *lang.Var

var A_arbace_g2a_build_A_const_129 *lang.Keyword

var A_arbace_g2a_build_A_const_130 *lang.Var

var A_arbace_g2a_build_A_const_131 any

var A_arbace_g2a_build_A_const_132 *lang.Var

var A_arbace_g2a_build_A_const_133 *lang.Var

var A_arbace_g2a_build_A_const_134 *lang.Keyword

var A_arbace_g2a_build_A_const_135 *lang.Var

var A_arbace_g2a_build_A_const_136 *lang.Keyword

var A_arbace_g2a_build_A_const_137 *lang.Var

var A_arbace_g2a_build_A_const_138 *lang.Var

var A_arbace_g2a_build_A_const_139 *lang.Keyword

var A_arbace_g2a_build_A_const_140 *lang.Keyword

var A_arbace_g2a_build_A_const_141 *lang.Var

var A_arbace_g2a_build_A_const_142 *lang.Keyword

var A_arbace_g2a_build_A_const_143 *jrt.Class

var A_arbace_g2a_build_A_const_144 *lang.Var

var A_arbace_g2a_build_A_const_145 *lang.Keyword

var A_arbace_g2a_build_A_const_146 *lang.Keyword

var A_arbace_g2a_build_A_const_147 *lang.Var

var A_arbace_g2a_build_A_const_148 *lang.Keyword

var A_arbace_g2a_build_A_const_149 *lang.Keyword

var A_arbace_g2a_build_A_const_150 *lang.Keyword

var A_arbace_g2a_build_A_const_151 *lang.Keyword

var A_arbace_g2a_build_A_const_152 *lang.Var

var A_arbace_g2a_build_A_const_153 *lang.Var

var A_arbace_g2a_build_A_const_154 *lang.Var

var A_arbace_g2a_build_A_const_155 any

var A_arbace_g2a_build_A_const_156 *lang.Keyword

var A_arbace_g2a_build_A_const_157 *lang.Var

var A_arbace_g2a_build_A_const_158 any

var A_arbace_g2a_build_A_const_159 *lang.Var

var A_arbace_g2a_build_A_const_160 *lang.Var

var A_arbace_g2a_build_A_const_161 *lang.Var

var A_arbace_g2a_build_A_const_162 *lang.Var

var A_arbace_g2a_build_A_const_163 *lang.Var

var A_arbace_g2a_build_A_const_164 *lang.Var

var A_arbace_g2a_build_A_const_165 *lang.Var

var A_arbace_g2a_build_A_const_166 *lang.Var

var A_arbace_g2a_build_A_const_167 *lang.Var

var A_arbace_g2a_build_A_const_168 *lang.Var

var A_arbace_g2a_build_A_const_169 any

var A_arbace_g2a_build_A_const_170 any

var A_arbace_g2a_build_A_const_171 any

var A_arbace_g2a_build_A_const_172 *lang.Var

var A_arbace_g2a_build_A_init jrt.ClassInit

func A_arbace_g2a_build_A_Init() { if !A_arbace_g2a_build_A_init.Done() { A_arbace_g2a_build_A_init.Run(A_arbace_g2a_build_A_clinit) } }

func A_arbace_g2a_build_A_clinit() { A_arbace_g2a_build_A_clinit_p0(); A_arbace_g2a_build_A_clinit_p1(); A_arbace_g2a_build_A_clinit_p2(); A_arbace_g2a_build_A_clinit_p3(); A_arbace_g2a_build_A_clinit_p4(); A_arbace_g2a_build_A_clinit_p5(); A_arbace_g2a_build_A_clinit_p6(); A_arbace_g2a_build_A_clinit_p7(); A_arbace_g2a_build_A_clinit_p8(); A_arbace_g2a_build_A_clinit_p9(); A_arbace_g2a_build_A_clinit_p10(); A_arbace_g2a_build_A_clinit_p11(); A_arbace_g2a_build_A_clinit_p12(); A_arbace_g2a_build_A_clinit_p13(); A_arbace_g2a_build_A_clinit_p14() }

func A_arbace_g2a_build_A_clinit_p0() { A_arbace_g2a_build_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 221); A_arbace_g2a_build_A_const_0 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[48]); A_arbace_g2a_build_A_const_1 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[49]); A_arbace_g2a_build_A_const_2 = A_arbace_g2a_build_A_const_pool.A[50]; A_arbace_g2a_build_A_const_3 = A_arbace_g2a_build_A_const_pool.A[51]; A_arbace_g2a_build_A_const_4 = A_arbace_g2a_build_A_const_pool.A[52]; A_arbace_g2a_build_A_const_5 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[53]); A_arbace_g2a_build_A_const_6 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[54]); A_arbace_g2a_build_A_const_7 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[55]); A_arbace_g2a_build_A_const_8 = A_arbace_g2a_build_A_const_pool.A[56]; A_arbace_g2a_build_A_const_9 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[57]); A_arbace_g2a_build_A_const_10 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[58]); A_arbace_g2a_build_A_const_11 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[59]) }

func A_arbace_g2a_build_A_clinit_p1() { A_arbace_g2a_build_A_const_12 = A_arbace_g2a_build_A_const_pool.A[60]; A_arbace_g2a_build_A_const_13 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[61]); A_arbace_g2a_build_A_const_14 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[62]); A_arbace_g2a_build_A_const_15 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[63]); A_arbace_g2a_build_A_const_16 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[64]); A_arbace_g2a_build_A_const_17 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[65]); A_arbace_g2a_build_A_const_18 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[66]); A_arbace_g2a_build_A_const_19 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[67]); A_arbace_g2a_build_A_const_20 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[68]); A_arbace_g2a_build_A_const_21 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[69]); A_arbace_g2a_build_A_const_22 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[70]); A_arbace_g2a_build_A_const_23 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[71]) }

func A_arbace_g2a_build_A_clinit_p2() { A_arbace_g2a_build_A_const_24 = A_arbace_g2a_build_A_const_pool.A[72]; A_arbace_g2a_build_A_const_25 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[73]); A_arbace_g2a_build_A_const_26 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[74]); A_arbace_g2a_build_A_const_27 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[75]); A_arbace_g2a_build_A_const_28 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[76]); A_arbace_g2a_build_A_const_29 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[77]); A_arbace_g2a_build_A_const_30 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[78]); A_arbace_g2a_build_A_const_31 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[79]); A_arbace_g2a_build_A_const_32 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[80]); A_arbace_g2a_build_A_const_33 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[81]); A_arbace_g2a_build_A_const_34 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[82]); A_arbace_g2a_build_A_const_35 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[83]) }

func A_arbace_g2a_build_A_clinit_p3() { A_arbace_g2a_build_A_const_36 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[84]); A_arbace_g2a_build_A_const_37 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[85]); A_arbace_g2a_build_A_const_38 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[86]); A_arbace_g2a_build_A_const_39 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[87]); A_arbace_g2a_build_A_const_40 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[88]); A_arbace_g2a_build_A_const_41 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[89]); A_arbace_g2a_build_A_const_42 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[90]); A_arbace_g2a_build_A_const_43 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[91]); A_arbace_g2a_build_A_const_44 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[92]); A_arbace_g2a_build_A_const_45 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[93]); A_arbace_g2a_build_A_const_46 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[94]); A_arbace_g2a_build_A_const_47 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[95]) }

func A_arbace_g2a_build_A_clinit_p4() { A_arbace_g2a_build_A_const_48 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[96]); A_arbace_g2a_build_A_const_49 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[97]); A_arbace_g2a_build_A_const_50 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[98]); A_arbace_g2a_build_A_const_51 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[99]); A_arbace_g2a_build_A_const_52 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[100]); A_arbace_g2a_build_A_const_53 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[101]); A_arbace_g2a_build_A_const_54 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[102]); A_arbace_g2a_build_A_const_55 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[103]); A_arbace_g2a_build_A_const_56 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[104]); A_arbace_g2a_build_A_const_57 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[105]); A_arbace_g2a_build_A_const_58 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[106]); A_arbace_g2a_build_A_const_59 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[107]) }

func A_arbace_g2a_build_A_clinit_p5() { A_arbace_g2a_build_A_const_60 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[108]); A_arbace_g2a_build_A_const_61 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[109]); A_arbace_g2a_build_A_const_62 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[110]); A_arbace_g2a_build_A_const_63 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[111]); A_arbace_g2a_build_A_const_64 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[112]); A_arbace_g2a_build_A_const_65 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[113]); A_arbace_g2a_build_A_const_66 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[114]); A_arbace_g2a_build_A_const_67 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[115]); A_arbace_g2a_build_A_const_68 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[116]); A_arbace_g2a_build_A_const_69 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[117]); A_arbace_g2a_build_A_const_70 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[118]); A_arbace_g2a_build_A_const_71 = A_arbace_g2a_build_A_const_pool.A[119] }

func A_arbace_g2a_build_A_clinit_p6() { A_arbace_g2a_build_A_const_72 = A_arbace_g2a_build_A_const_pool.A[120]; A_arbace_g2a_build_A_const_73 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[121]); A_arbace_g2a_build_A_const_74 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[122]); A_arbace_g2a_build_A_const_75 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[123]); A_arbace_g2a_build_A_const_76 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[124]); A_arbace_g2a_build_A_const_77 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[125]); A_arbace_g2a_build_A_const_78 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[126]); A_arbace_g2a_build_A_const_79 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[127]); A_arbace_g2a_build_A_const_80 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[128]); A_arbace_g2a_build_A_const_81 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[129]); A_arbace_g2a_build_A_const_82 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[130]); A_arbace_g2a_build_A_const_83 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[131]) }

func A_arbace_g2a_build_A_clinit_p7() { A_arbace_g2a_build_A_const_84 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[132]); A_arbace_g2a_build_A_const_85 = A_arbace_g2a_build_A_const_pool.A[133]; A_arbace_g2a_build_A_const_86 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[134]); A_arbace_g2a_build_A_const_87 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[135]); A_arbace_g2a_build_A_const_88 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[136]); A_arbace_g2a_build_A_const_89 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[137]); A_arbace_g2a_build_A_const_90 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[138]); A_arbace_g2a_build_A_const_91 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[139]); A_arbace_g2a_build_A_const_92 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[140]); A_arbace_g2a_build_A_const_93 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[141]); A_arbace_g2a_build_A_const_94 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[142]); A_arbace_g2a_build_A_const_95 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[143]) }

func A_arbace_g2a_build_A_clinit_p8() { A_arbace_g2a_build_A_const_96 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[144]); A_arbace_g2a_build_A_const_97 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[145]); A_arbace_g2a_build_A_const_98 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[146]); A_arbace_g2a_build_A_const_99 = jrt.Class_Cast(A_arbace_g2a_build_A_const_pool.A[147]); A_arbace_g2a_build_A_const_100 = A_arbace_g2a_build_A_const_pool.A[148]; A_arbace_g2a_build_A_const_101 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[149]); A_arbace_g2a_build_A_const_102 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[150]); A_arbace_g2a_build_A_const_103 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[151]); A_arbace_g2a_build_A_const_104 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[152]); A_arbace_g2a_build_A_const_105 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[153]); A_arbace_g2a_build_A_const_106 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[154]); A_arbace_g2a_build_A_const_107 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[155]) }

func A_arbace_g2a_build_A_clinit_p9() { A_arbace_g2a_build_A_const_108 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[156]); A_arbace_g2a_build_A_const_109 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[157]); A_arbace_g2a_build_A_const_110 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[158]); A_arbace_g2a_build_A_const_111 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[159]); A_arbace_g2a_build_A_const_112 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[160]); A_arbace_g2a_build_A_const_113 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[161]); A_arbace_g2a_build_A_const_114 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[162]); A_arbace_g2a_build_A_const_115 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[163]); A_arbace_g2a_build_A_const_116 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[164]); A_arbace_g2a_build_A_const_117 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[165]); A_arbace_g2a_build_A_const_118 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[166]); A_arbace_g2a_build_A_const_119 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[167]) }

func A_arbace_g2a_build_A_clinit_p10() { A_arbace_g2a_build_A_const_120 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[168]); A_arbace_g2a_build_A_const_121 = A_arbace_g2a_build_A_const_pool.A[169]; A_arbace_g2a_build_A_const_122 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[170]); A_arbace_g2a_build_A_const_123 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[171]); A_arbace_g2a_build_A_const_124 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[172]); A_arbace_g2a_build_A_const_125 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[173]); A_arbace_g2a_build_A_const_126 = jrt.Class_Cast(A_arbace_g2a_build_A_const_pool.A[174]); A_arbace_g2a_build_A_const_127 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[175]); A_arbace_g2a_build_A_const_128 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[176]); A_arbace_g2a_build_A_const_129 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[177]); A_arbace_g2a_build_A_const_130 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[178]); A_arbace_g2a_build_A_const_131 = A_arbace_g2a_build_A_const_pool.A[179] }

func A_arbace_g2a_build_A_clinit_p11() { A_arbace_g2a_build_A_const_132 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[180]); A_arbace_g2a_build_A_const_133 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[181]); A_arbace_g2a_build_A_const_134 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[182]); A_arbace_g2a_build_A_const_135 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[183]); A_arbace_g2a_build_A_const_136 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[184]); A_arbace_g2a_build_A_const_137 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[185]); A_arbace_g2a_build_A_const_138 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[186]); A_arbace_g2a_build_A_const_139 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[187]); A_arbace_g2a_build_A_const_140 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[188]); A_arbace_g2a_build_A_const_141 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[189]); A_arbace_g2a_build_A_const_142 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[190]); A_arbace_g2a_build_A_const_143 = jrt.Class_Cast(A_arbace_g2a_build_A_const_pool.A[191]) }

func A_arbace_g2a_build_A_clinit_p12() { A_arbace_g2a_build_A_const_144 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[192]); A_arbace_g2a_build_A_const_145 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[193]); A_arbace_g2a_build_A_const_146 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[194]); A_arbace_g2a_build_A_const_147 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[195]); A_arbace_g2a_build_A_const_148 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[196]); A_arbace_g2a_build_A_const_149 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[197]); A_arbace_g2a_build_A_const_150 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[198]); A_arbace_g2a_build_A_const_151 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[199]); A_arbace_g2a_build_A_const_152 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[200]); A_arbace_g2a_build_A_const_153 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[201]); A_arbace_g2a_build_A_const_154 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[202]); A_arbace_g2a_build_A_const_155 = A_arbace_g2a_build_A_const_pool.A[203] }

func A_arbace_g2a_build_A_clinit_p13() { A_arbace_g2a_build_A_const_156 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[204]); A_arbace_g2a_build_A_const_157 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[205]); A_arbace_g2a_build_A_const_158 = A_arbace_g2a_build_A_const_pool.A[206]; A_arbace_g2a_build_A_const_159 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[207]); A_arbace_g2a_build_A_const_160 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[208]); A_arbace_g2a_build_A_const_161 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[209]); A_arbace_g2a_build_A_const_162 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[210]); A_arbace_g2a_build_A_const_163 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[211]); A_arbace_g2a_build_A_const_164 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[212]); A_arbace_g2a_build_A_const_165 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[213]); A_arbace_g2a_build_A_const_166 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[214]); A_arbace_g2a_build_A_const_167 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[215]) }

func A_arbace_g2a_build_A_clinit_p14() { A_arbace_g2a_build_A_const_168 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[216]); A_arbace_g2a_build_A_const_169 = A_arbace_g2a_build_A_const_pool.A[217]; A_arbace_g2a_build_A_const_170 = A_arbace_g2a_build_A_const_pool.A[218]; A_arbace_g2a_build_A_const_171 = A_arbace_g2a_build_A_const_pool.A[219]; A_arbace_g2a_build_A_const_172 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[220]) }

func A_arbace_g2a_build_A_New() *A_arbace_g2a_build_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_build_A) Ctor() {}

func (t *A_arbace_g2a_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_build_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_build_A_class }

func (t *A_arbace_g2a_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_build_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_build_A); return ok }

func A_arbace_g2a_build_A_Cast(x any) *A_arbace_g2a_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_build_A_class)) }; return v }



type A_arbace_g2a_build__main_A struct{ a2g_header uint64 }

var A_arbace_g2a_build__main_A_fn_class *jrt.Class



type A_arbace_g2a_build__main_fn__715000263_A struct{ a2g_header uint64; F_usage any }

var A_arbace_g2a_build__main_fn__715000263_A_fn_class *jrt.Class



type A_arbace_g2a_build__main_fn__715000265_A struct{ a2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_g2a_build__main_fn__715000265_A_fn_class *jrt.Class



type A_arbace_g2a_build__main_fn__715000265_fn__715000266_A struct{ a2g_header uint64; F_e any }

var A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_fn_class *jrt.Class



type A_arbace_g2a_build_build_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_build_A_fn_class *jrt.Class



type A_arbace_g2a_build_cache_texts_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_cached_texts_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A struct{ a2g_header uint64; F_entry any }

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A struct{ a2g_header uint64; F_s__715000182, F_entry, F_iter__715000181 any }

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A struct{ a2g_header uint64; F_b__715000184, F_entry any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_fn_class *jrt.Class



type A_arbace_g2a_build_clj_files_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_clj_files_A_fn_class *jrt.Class



type A_arbace_g2a_build_clj_files_fn__715000020_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class *jrt.Class



type A_arbace_g2a_build_clj_files_fn__715000022_A struct{ a2g_header uint64; F_dir any }

var A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class *jrt.Class



type A_arbace_g2a_build_copy_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_copy_file_A_fn_class *jrt.Class



type A_arbace_g2a_build_data_dir_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_build_delete_tree_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_delete_tree_A_fn_class *jrt.Class



type A_arbace_g2a_build_eval715000004_A struct{ jrt.Object }

func A_arbace_g2a_build_eval715000004_A_New() *A_arbace_g2a_build_eval715000004_A { t := &A_arbace_g2a_build_eval715000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_build_eval715000004_A) Ctor() {}

func (t *A_arbace_g2a_build_eval715000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_build_eval715000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_build_eval715000004_A_class }

func (t *A_arbace_g2a_build_eval715000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_build_eval715000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_build_eval715000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_build_eval715000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_build_eval715000004_A); return ok }

func A_arbace_g2a_build_eval715000004_A_Cast(x any) *A_arbace_g2a_build_eval715000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_build_eval715000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_build_eval715000004_A_class)) }; return v }



type A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_fn_class *jrt.Class



type A_arbace_g2a_build_eval715000008_A struct{ jrt.Object }

func A_arbace_g2a_build_eval715000008_A_New() *A_arbace_g2a_build_eval715000008_A { t := &A_arbace_g2a_build_eval715000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_build_eval715000008_A) Ctor() {}

func (t *A_arbace_g2a_build_eval715000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_build_eval715000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_build_eval715000008_A_class }

func (t *A_arbace_g2a_build_eval715000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_build_eval715000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_build_eval715000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_build_eval715000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_build_eval715000008_A); return ok }

func A_arbace_g2a_build_eval715000008_A_Cast(x any) *A_arbace_g2a_build_eval715000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_build_eval715000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_build_eval715000008_A_class)) }; return v }



type A_arbace_g2a_build_eval715000008_fn__715000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_eval715000008_fn__715000009_A_fn_class *jrt.Class



type A_arbace_g2a_build_fail_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_fail_A_fn_class *jrt.Class



type A_arbace_g2a_build_forms_dir_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_forms_dir_A_fn_class *jrt.Class



type A_arbace_g2a_build_go_env_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_go_env_A_fn_class *jrt.Class



type A_arbace_g2a_build_go_mod_cache_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_hex__715000120_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_hex__715000120_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_sha__715000124_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_sha__715000124_A_fn_class *jrt.Class



type A_arbace_g2a_build_package_file_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_build_package_file_QMARK__fn__715000027_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class *jrt.Class



type A_arbace_g2a_build_package_file_QMARK__fn__715000029_A struct{ a2g_header uint64; F_aliases any }

var A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_fn__715000057_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_fn__715000057_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_fn__715000062_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_fn__715000062_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A struct{ a2g_header uint64; F_iter__715000034, F_s__715000035 any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A struct{ a2g_header uint64; F_iter__715000036, F_s__715000037 any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A struct{ a2g_header uint64; F_b__715000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_cache_key_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_print_cache_key_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_cache_key_add__715000172_A struct{ a2g_header uint64; F_md any }

var A_arbace_g2a_build_print_cache_key_add__715000172_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_cache_key_fn__715000178_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_print_cache_key_fn__715000178_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_print_module_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000214_A struct{ a2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_g2a_build_print_module_fn__715000214_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A struct{ a2g_header uint64; F_test_files any }

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A struct{ a2g_header uint64; F_test_files any }

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A struct{ a2g_header uint64; F_pkg any }

var A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_program_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_fn__715000142_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_program_fn__715000142_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_fn__715000154_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_program_fn__715000154_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_iter__715000144__715000148_A struct{ a2g_header uint64; F_module any }

var A_arbace_g2a_build_program_iter__715000144__715000148_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A struct{ a2g_header uint64; F_iter__715000144, F_s__715000145, F_module any }

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A struct{ a2g_header uint64; F_b__715000147 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_all_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_all_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_all_fn__715000066_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_all_fn__715000066_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_all_fn__715000068_A struct{ a2g_header uint64; F_cache any }

var A_arbace_g2a_build_read_all_fn__715000068_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_program_edn_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_program_edn_A_fn_class *jrt.Class



type A_arbace_g2a_build_rel_path_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_rel_path_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000093_A struct{ a2g_header uint64; F_dir any }

var A_arbace_g2a_build_root_packages_fn__715000093_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000098_A struct{ a2g_header uint64; F_dir any }

var A_arbace_g2a_build_root_packages_fn__715000098_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000072__715000076_A struct{ a2g_header uint64; F_dir, F_read_fn any }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A struct{ a2g_header uint64; F_s__715000073, F_dir, F_read_fn, F_iter__715000072 any }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A struct{ a2g_header uint64; F_dir, F_read_fn, F_b__715000075 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A struct{ a2g_header uint64; F_read_fn, F_read any }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A struct{ a2g_header uint64; F_read_fn, F_read any }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_fn_class *jrt.Class



type A_arbace_g2a_build_run_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_run_A_fn_class *jrt.Class



type A_arbace_g2a_build_sha256_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_sha256_A_fn_class *jrt.Class



type A_arbace_g2a_build_sha256_fn__715000158_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_sha256_fn__715000158_A_fn_class *jrt.Class



type A_arbace_g2a_build_tamago_go_sum_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_g2a_build_toolchain_lang_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_with_line_files_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_fn__715000164_A struct{ a2g_header uint64; F_fdir any }

var A_arbace_g2a_build_with_line_files_fn__715000164_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A struct{ a2g_header uint64; F_fdir any }

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A struct{ a2g_header uint64; F_fdir any }

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_fn_class *jrt.Class
