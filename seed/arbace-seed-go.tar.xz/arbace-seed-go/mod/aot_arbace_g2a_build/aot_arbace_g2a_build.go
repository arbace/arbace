//line aot_arbace_g2a_build.ae:1
package aot_arbace_g2a_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_New() *A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_build_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_2); lang.IFn_Cast(A_arbace_g2a_build_A_const_1.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_3, A_arbace_g2a_build_A_const_4); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_57)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_58)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_59)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_60)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_61)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_62)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :1:1
func A_arbace_g2a_build_eval715000008_fn__715000009_A_New() *A_arbace_g2a_build_eval715000008_fn__715000009_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_eval715000008_fn__715000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_build_eval715000008_fn__715000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_build_eval715000008_fn__715000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_9), A_arbace_g2a_build_A_const_7.GetRawRoot__O(), A_arbace_g2a_build_A_const_8) }




























































func A_arbace_g2a_build_fail_A_New() *A_arbace_g2a_build_fail_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_fail_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_g2a_build_fail_A) Ctor() {}
//line :62:1
func (t *A_arbace_g2a_build_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__715000012__1 any) any { var vec__715000013__3 any = p__715000012__1; var data__4 any = lang.RT_Nth_O_I_O__O(vec__715000013__3, lang.RT_IntCast_J__I(0), nil); panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_10.GetRawRoot__O()).Invoke_O_O__O(msg__0, lang.IFn_Cast(A_arbace_g2a_build_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_12, data__4))))) }





func A_arbace_g2a_build_data_dir_QMARK__A_New() *A_arbace_g2a_build_data_dir_QMARK__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_g2a_build_data_dir_QMARK__A) Ctor() {}
//line :68:1
func (t *A_arbace_g2a_build_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.NN(jrt.File_Cast(f__1)).GetParentFile__File().Ref(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z(jrt.NN(jrt.File_Cast(d__3)).GetAbsoluteFile__File().Ref(), jrt.NN(jrt.File_Cast(dir__0)).GetAbsoluteFile__File().Ref()) }; if tmp1 { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_56).IsFile__Z() { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if A_arbace_g2a_build_A_const_13 != nil {

		d__3 = jrt.NN(jrt.File_Cast(d__3)).GetParentFile__File().Ref(); continue L1 } else {
//line :73:1
			return nil } } } } }; /*line :68:1*/panic("a2g: unreachable") }








func A_arbace_g2a_build_clj_files_A_New() *A_arbace_g2a_build_clj_files_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_clj_files_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_g2a_build_clj_files_A) Ctor() {}
//line :77:1
func (t *A_arbace_g2a_build_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_clj_files_fn__715000020_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_clj_files_fn__715000022_A_New_O(dir__0); var tmp7 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class
//line :79:1
	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class = fncls__2d; tmp7 = fncls__2d } else { tmp7 = fncls__2
	}
	return tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_g2a_build_A_const_19.GetRawRoot__O()).Invoke_O__O(dir__0))) }
//line :79:1
func A_arbace_g2a_build_clj_files_fn__715000022_A_New_O(p0 any) *A_arbace_g2a_build_clj_files_fn__715000022_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_clj_files_fn__715000022_A{}; t.Ctor_O(p0); return t }
//line :79:1
func (t *A_arbace_g2a_build_clj_files_fn__715000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :79:1
func (t *A_arbace_g2a_build_clj_files_fn__715000022_A) Invoke_O_O__O(self, p1__715000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__715000018_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_16.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__715000018_SHARP___1)).GetName__String().Ref(), Lit_49); if jrt.A2g_Truth(and__1927000168__auto____3) {
														return lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, p1__715000018_SHARP___1)) } else {
//line :79:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

func A_arbace_g2a_build_clj_files_fn__715000020_A_New() *A_arbace_g2a_build_clj_files_fn__715000020_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_clj_files_fn__715000020_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_g2a_build_clj_files_fn__715000020_A) Ctor() {}
//line :81:1
func (t *A_arbace_g2a_build_clj_files_fn__715000020_A) Invoke_O_O__O(self, p1__715000019_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__715000019_SHARP___1)).GetPath__String().Ref() }

func A_arbace_g2a_build_package_file_QMARK__A_New() *A_arbace_g2a_build_package_file_QMARK__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_package_file_QMARK__A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_g2a_build_package_file_QMARK__A) Ctor() {}
//line :83:1
func (t *A_arbace_g2a_build_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class; if




	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; ns_form__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__3)); var aliases__5 any; if
	jrt.A2g_Truth(ns_form__4) { aliases__5 = A_arbace_g2a_build_A_const_21.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp5 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.A2g_Truth(and__1927000168__auto____6) {
		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_22.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_New_O(aliases__5); var tmp8 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class = fncls__4d; tmp8 = fncls__4d } else { tmp8 = fncls__4 }; tmp5 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), forms__3) } else {
//line :91:1
			tmp5 = and__1927000168__auto____6 }; return /*line :90:1*/ jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp5)).Ref() }
//line :88:1
func A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_New() *A_arbace_g2a_build_package_file_QMARK__fn__715000027_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_package_file_QMARK__fn__715000027_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000027_A) Ctor() {}
//line :88:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000027_A) Invoke_O_O__O(self, p1__715000025_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_23.GetRawRoot__O()).Invoke_O__O(p1__715000025_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_g2a_build_A_const_24; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000025_SHARP___1))).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_New_O(p0 any) *A_arbace_g2a_build_package_file_QMARK__fn__715000029_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_package_file_QMARK__fn__715000029_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :92:1
func (t *A_arbace_g2a_build_package_file_QMARK__fn__715000029_A) Invoke_O_O__O(self, p1__715000026_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_23.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z(Lit_82, lang.IFn_Cast(A_arbace_g2a_build_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1))); if and__1927000168__auto____4 {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp2 any = t.F_aliases; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_build_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000026_SHARP___1))) } else {
//line :92:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_g2a_build_rel_path_A_New() *A_arbace_g2a_build_rel_path_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_rel_path_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_g2a_build_rel_path_A) Ctor() {}
//line :99:1
func (t *A_arbace_g2a_build_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	return lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.NN(jrt.File_Cast(base__0)).GetAbsoluteFile__File()).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).ToPath__Path()))
}
func A_arbace_g2a_build_packages_A_New() *A_arbace_g2a_build_packages_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Ctor() {}
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Invoke_O_O_O_O__O(self, dir__0, roots__1, print_cache__2 any) any { var own__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_30.GetRawRoot__O()).Invoke_O_O__O(dir__0, print_cache__2); var more__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_A_New_O(print_cache__2); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class; if









	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); more__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(roots__1); var pkgs__6 any = /*line :102:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O__O(own__4, more__5)); var seq_715000050__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46, pkgs__6)); var chunk_715000051__8 any; var count_715000052__9 int64 = 0; var i_715000053__10 int64 = 0; L1: for {














		if lang.Numbers_Lt_J_J__Z(i_715000053__10, count_715000052__9) { var vec__715000054__11 any = lang.Indexed_Cast(chunk_715000051__8).Nth_I__O(lang.RT_IntCast_J__I(i_715000053__10)); var path__12 any = lang.RT_Nth_O_I_O__O(vec__715000054__11, lang.RT_IntCast_J__I(0), nil); var ps__13 any = lang.RT_Nth_O_I_O__O(vec__715000054__11, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__13)), 1) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_85, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_packages_fn__715000057_A_New(); var tmp8 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_build_packages_fn__715000057_A_fn_class
			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_g2a_build_packages_fn__715000057_A_fn_class = fncls__10d; tmp8 = fncls__10d } else { tmp8 = fncls__10 }
//line :118:1
			tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__12, nil, tmp5.Invoke_O_O__O(Lit_86, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), ps__13)))).Ref())
//line :117:1
			seq_715000050__7, chunk_715000051__8, count_715000052__9, i_715000053__10 = seq_715000050__7, chunk_715000051__8, count_715000052__9, lang.Numbers_Unchecked_inc_J__J(i_715000053__10); continue L1 } else { seq_715000050__7, chunk_715000051__8, count_715000052__9, i_715000053__10 = seq_715000050__7, chunk_715000051__8, count_715000052__9, lang.Numbers_Unchecked_inc_J__J(i_715000053__10); continue L1 } } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000050__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_715000050__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000050__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000050__12); seq_715000050__7, chunk_715000051__8, count_715000052__9, i_715000053__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000050__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000059__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000050__12); var path__14 any = lang.RT_Nth_O_I_O__O(vec__715000059__13, lang.RT_IntCast_J__I(0), nil); var ps__15 any = lang.RT_Nth_O_I_O__O(vec__715000059__13, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__15)), 1) {
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_85, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_build_packages_fn__715000062_A_New(); var tmp14 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_build_packages_fn__715000062_A_fn_class
				if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_g2a_build_packages_fn__715000062_A_fn_class = fncls__11d; tmp14 = fncls__11d } else { tmp14 = fncls__11 }
//line :118:1
				tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, path__14, nil, tmp11.Invoke_O_O__O(Lit_86, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__15)))).Ref())
//line :117:1
				seq_715000050__7, chunk_715000051__8, count_715000052__9, i_715000053__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000050__12), nil, 0, 0; continue L1 } else { seq_715000050__7, chunk_715000051__8, count_715000052__9, i_715000053__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000050__12), nil, 0, 0; continue L1 } } } }
//line :102:1
		break L1 }; return pkgs__6 }
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any {






	return lang.IFn_Cast(A_arbace_g2a_build_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, roots__1, nil) }
//line :102:1
func (t *A_arbace_g2a_build_packages_A) Invoke_O_O__O(self, dir__0 any) any {





	return lang.IFn_Cast(A_arbace_g2a_build_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, nil, nil)
}


func A_arbace_g2a_build_packages_iter__715000034__715000040_A_New_O(p0 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_A) Ctor_O(c__print_cache any) { t.F_print_cache = c__print_cache }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_A) Invoke_O_O__O(self, s__715000035__1 any) any { var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_New_O_O_O(self, s__715000035__1, t.F_print_cache); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :112:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A) Ctor_O_O_O(c__iter__715000034, c__s__715000035, c__print_cache any) { t.F_iter__715000034 = c__iter__715000034; t.F_s__715000035 = c__s__715000035; t.F_print_cache = c__print_cache }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A) Invoke_O__O(self any) any { { var s__715000035__1 any; var t_ any = t.F_s__715000035; t.F_s__715000035 = nil; s__715000035__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000035__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_30.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(r__4))), t.F_print_cache))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000034); return lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000035__1))) } else { s__715000035__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000035__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :112:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_New() *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A) Ctor() {}
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A) Invoke_O_O__O(self, s__715000037__1 any) any { var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_New_O_O(self, s__715000037__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :112:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A) Ctor_O_O(c__iter__715000036, c__s__715000037 any) { t.F_iter__715000036 = c__iter__715000036; t.F_s__715000037 = c__s__715000037 }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A) Invoke_O__O(self any) any { { var s__715000037__1 any; var t_ any = t.F_s__715000037; t.F_s__715000037 = nil; s__715000037__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000037__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000037__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000037__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000037__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000039__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_New_O_I_O(b__715000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000036); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000039__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000037__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000039__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000037__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_93, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(pkg__4)))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__715000036); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(pkg__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000037__3))) } else { s__715000037__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000037__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :112:1
func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A) Ctor_O_I_O(c__b__715000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__715000039 = c__b__715000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :112:1
func (t *A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A) Invoke_O__O(self any) any { { var i__715000038__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000038__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_93, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(pkg__2)))) { lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__715000039, pkg__2); i__715000038__1 = lang.Numbers_Unchecked_inc_J__J(i__715000038__1); continue L1 } else { i__715000038__1 = lang.Numbers_Unchecked_inc_J__J(i__715000038__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_g2a_build_packages_fn__715000057_A_New() *A_arbace_g2a_build_packages_fn__715000057_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_fn__715000057_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_g2a_build_packages_fn__715000057_A) Ctor() {}
//line :119:1
func (t *A_arbace_g2a_build_packages_fn__715000057_A) Invoke_O_O__O(self, p1__715000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000033_SHARP___1))).GetPath__String().Ref() }
//line :119:1
func A_arbace_g2a_build_packages_fn__715000062_A_New() *A_arbace_g2a_build_packages_fn__715000062_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_packages_fn__715000062_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_g2a_build_packages_fn__715000062_A) Ctor() {}
//line :119:1
func (t *A_arbace_g2a_build_packages_fn__715000062_A) Invoke_O_O__O(self, p1__715000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000033_SHARP___1))).GetPath__String().Ref() }


func A_arbace_g2a_build_read_all_A_New() *A_arbace_g2a_build_read_all_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_all_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_g2a_build_read_all_A) Ctor() {}
//line :122:1
func (t *A_arbace_g2a_build_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_53.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_build_read_all_fn__715000066_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_build_read_all_fn__715000066_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_g2a_build_read_all_fn__715000066_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; cache__2 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), files__0), lang.IFn_Cast(A_arbace_g2a_build_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_54.GetRawRoot__O(), files__0)); var tmp5 any =

	A_arbace_g2a_build_read_all_fn__715000068_A_New_O(cache__2); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_build_read_all_fn__715000068_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_g2a_build_read_all_fn__715000068_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil) }
//line :127:1
func A_arbace_g2a_build_read_all_fn__715000066_A_New() *A_arbace_g2a_build_read_all_fn__715000066_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_all_fn__715000066_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_g2a_build_read_all_fn__715000066_A) Ctor() {}
//line :127:1
func (t *A_arbace_g2a_build_read_all_fn__715000066_A) Invoke_O_O__O(self, p1__715000065_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__715000065_SHARP___1)).GetAbsolutePath__String().Ref() }

func A_arbace_g2a_build_read_all_fn__715000068_A_New_O(p0 any) *A_arbace_g2a_build_read_all_fn__715000068_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_all_fn__715000068_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_g2a_build_read_all_fn__715000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :129:1
func (t *A_arbace_g2a_build_read_all_fn__715000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__1)).GetAbsolutePath__String().Ref(); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()).Invoke_O_O__O(t.F_cache, k__2)) { return lang.RT_Get_O_O__O(t.F_cache, k__2) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_54.GetRawRoot__O()).Invoke_O__O(f__1) } }

func A_arbace_g2a_build_hex_A_New() *A_arbace_g2a_build_hex_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_hex_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_g2a_build_hex_A) Ctor() {}
//line :133:1
func (t *A_arbace_g2a_build_hex_A) Invoke_O_O__O(self, bs__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_hex_fn__715000072_A_New(); var tmp5 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_build_hex_fn__715000072_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_g2a_build_hex_fn__715000072_A_fn_class = fncls__14d; tmp5 = fncls__14d } else { tmp5 = fncls__14 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), bs__0)) }
//line :134:1
func A_arbace_g2a_build_hex_fn__715000072_A_New() *A_arbace_g2a_build_hex_fn__715000072_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_hex_fn__715000072_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_g2a_build_hex_fn__715000072_A) Ctor() {}
//line :134:1
func (t *A_arbace_g2a_build_hex_fn__715000072_A) Invoke_O_O__O(self, p1__715000071_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_57.GetRawRoot__O()).Invoke_O_O__O(Lit_78, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000071_SHARP___1, 255)).Ref()) }

func A_arbace_g2a_build_file_sha_A_New() *A_arbace_g2a_build_file_sha_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_file_sha_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_g2a_build_file_sha_A) Ctor() {}
//line :136:1
func (t *A_arbace_g2a_build_file_sha_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		return lang.IFn_Cast(A_arbace_g2a_build_A_const_58.GetRawRoot__O()).Invoke_O__O(jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_50).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref()) } else {
//line :139:1
			return nil
		}
}
func A_arbace_g2a_build_collect_package_A_New() *A_arbace_g2a_build_collect_package_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_collect_package_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_g2a_build_collect_package_A) Ctor() {}
//line :142:1
func (t *A_arbace_g2a_build_collect_package_A) Invoke_O_O_O_O__O(self, dir__0, f__1, read_fn__2 any) any { var read__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_59.GetRawRoot__O()); var tmp2 *lang.PersistentVector;



	lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; read__4 = tmp1.Invoke_O__O(tmp2.Ref()); var pkg__5 any; var tmp3 lang.IFn = /*line :142:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_60.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_collect_package_fn__715000076_A_New_O_O(read_fn__2, read__4); var tmp5 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_build_collect_package_fn__715000076_A_fn_class; if




	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_g2a_build_collect_package_fn__715000076_A_fn_class = fncls__15d; tmp5 = fncls__15d } else { tmp5 = fncls__15 }; pkg__5 = tmp3.Invoke_O_O__O(f__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); var tmp6 /*line :142:1*/*lang.Keyword = A_arbace_g2a_build_A_const_46; var path__6 any = tmp6.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__5)); if






	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_64.GetRawRoot__O()).Invoke_O__O(path__6)) { } else {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_54), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__0, f__1), nil)).Ref()) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_build_A_const_50; var tmp9 any = A_arbace_g2a_build_A_const_46; var tmp10 any = A_arbace_g2a_build_A_const_66; return tmp7.Invoke_O_O_O_O_O_O_O__O(pkg__5, tmp8, f__1, tmp9, path__6, tmp10, lang.IFn_Cast(A_arbace_g2a_build_A_const_6.GetRawRoot__O()).Invoke_O__O(read__4)) }
//line :147:1
func A_arbace_g2a_build_collect_package_fn__715000076_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_collect_package_fn__715000076_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_collect_package_fn__715000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :147:1
func (t *A_arbace_g2a_build_collect_package_fn__715000076_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :147:1
func (t *A_arbace_g2a_build_collect_package_fn__715000076_A) Invoke_O_O__O(self, file__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_63.GetRawRoot__O()); var tmp2 any = t.F_read; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_g2a_build_A_const_7.GetRawRoot__O(), file__1); return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }











func A_arbace_g2a_build_collect_index_file_A_New() *A_arbace_g2a_build_collect_index_file_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_collect_index_file_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_g2a_build_collect_index_file_A) Ctor() {}
//line :159:1
func (t *A_arbace_g2a_build_collect_index_file_A) Invoke_O_O_O_O__O(self, print_cache__0, host_id__1, dir__2 any) any { var md__4 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_50);

	jrt.MessageDigest_Cast(md__4).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, host_id__1, nil, jrt.NN(jrt.File_Cast(dir__2)).GetPath__String().Ref()))).GetBytes_String__B1(Lit_51)); var tmp1 /*line :159:1*/*jrt.Class = A_arbace_g2a_build_A_const_67; return lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(print_cache__0)), Lit_52), lang.IFn_Cast(A_arbace_g2a_build_A_const_58.GetRawRoot__O()).Invoke_O__O(jrt.MessageDigest_Cast(md__4).Digest__B1().Ref()))) }




func A_arbace_g2a_build_read_index_A_New() *A_arbace_g2a_build_read_index_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_index_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_g2a_build_read_index_A) Ctor() {}
//line :164:1
func (t *A_arbace_g2a_build_read_index_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
//line :167:1
		var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__715000080__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_54.GetRawRoot__O()).Invoke_O__O(f__0); var m__5 any = lang.RT_Nth_O_I_O__O(vec__715000080__4, lang.RT_IntCast_J__I(0), nil)

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_68.GetRawRoot__O()).Invoke_O__O(m__5)) { tmp1 = m__5 } else { tmp1 = nil } }; return nil }()
//line :167:1
		if tmp2 != nil { if true { var ___4 jrt.Throwable_I = tmp2; _ = ___4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_g2a_build_write_index_BANG__A_New() *A_arbace_g2a_build_write_index_BANG__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_write_index_BANG__A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_g2a_build_write_index_BANG__A) Ctor() {}
//line :172:1
func (t *A_arbace_g2a_build_write_index_BANG__A) Invoke_O_O_O__O(self, f__0, index__1 any) any { var printed__3 any; var tmp1 any = A_arbace_g2a_build_write_index_BANG__printed__715000087_A_New(); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_build_write_index_BANG__printed__715000087_A_fn_class; if



	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_180, false); A_arbace_g2a_build_write_index_BANG__printed__715000087_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; printed__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var ok_QMARK___4 any; var tmp3 any = /*line :172:1*/A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A_New_O(printed__3); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A_fn_class; if



	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_181, false); A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; ok_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var index__5 any; var tmp5 lang.IFn = /*line :172:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_A_const_78; var tmp7 any = A_arbace_g2a_build_write_index_BANG__fn__715000091_A_New_O(ok_QMARK___4); var tmp8 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_build_write_index_BANG__fn__715000091_A_fn_class; if





	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, false); A_arbace_g2a_build_write_index_BANG__fn__715000091_A_fn_class = fncls__18d; tmp8 = fncls__18d } else { tmp8 = fncls__18 }; index__5 = tmp5.Invoke_O_O_O__O(index__1, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var tmp__6 any = /*line :172:1*/jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_39, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref())));







	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File()).Mkdirs__Z());
	lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(tmp__6, lang.IFn_Cast(printed__3).Invoke_O__O(index__5)); if
	jrt.NN(jrt.File_Cast(tmp__6)).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(tmp__6)).Delete__Z()).Ref() } }
//line :176:1
func A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A_New_O(p0 any) *A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A) Ctor_O(c__printed any) { t.F_printed = c__printed }
//line :176:1
func (t *A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A) Invoke_O_O__O(self, p1__715000085_SHARP___1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(p1__715000085_SHARP___1, lang.IFn_Cast(A_arbace_g2a_build_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_printed).Invoke_O__O(p1__715000085_SHARP___1)))).Ref()
//line :176:1
	return nil }(); if tmp2 != nil { if true { var ___4 jrt.Throwable_I = tmp2; _ = ___4; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :176:1
func A_arbace_g2a_build_write_index_BANG__printed__715000087_A_New() *A_arbace_g2a_build_write_index_BANG__printed__715000087_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_write_index_BANG__printed__715000087_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_g2a_build_write_index_BANG__printed__715000087_A) Ctor() {}
//line :176:1
func (t *A_arbace_g2a_build_write_index_BANG__printed__715000087_A) Invoke_O_O__O(self, p1__715000084_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_71.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_72.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_build_A_const_73; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O__O(tmp3, tmp4.Ref(), A_arbace_g2a_build_A_const_74, nil, A_arbace_g2a_build_A_const_75, nil)); var tmp5 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(p1__715000084_SHARP___1); return nil }(); lang.IFn_Cast(A_arbace_g2a_build_A_const_70.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp5 }

func A_arbace_g2a_build_write_index_BANG__fn__715000091_A_New_O(p0 any) *A_arbace_g2a_build_write_index_BANG__fn__715000091_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_write_index_BANG__fn__715000091_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_g2a_build_write_index_BANG__fn__715000091_A) Ctor_O(c__ok_QMARK_ any) { t.F_ok_QMARK_ = c__ok_QMARK_ }
//line :178:1
func (t *A_arbace_g2a_build_write_index_BANG__fn__715000091_A) Invoke_O_O__O(self, p1__715000086_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_81.GetRawRoot__O()); var tmp2 any = t.F_ok_QMARK_; var tmp3 any = A_arbace_g2a_build_A_const_82; return lang.IFn_Cast(A_arbace_g2a_build_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_80.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_g2a_build_A_const_83.GetRawRoot__O())), p1__715000086_SHARP___1) }





func A_arbace_g2a_build_root_packages_A_New() *A_arbace_g2a_build_root_packages_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_g2a_build_root_packages_A) Ctor() {}
//line :184:1
func (t *A_arbace_g2a_build_root_packages_A) Invoke_O_O_O__O(self, dir__0, print_cache__1 any) any { var root__3 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_130); if




	jrt.NN(jrt.File_Cast(root__3)).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_131, nil, Lit_132), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref(), nil)).Ref()) }; var files__4 any = /*line :184:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_85.GetRawRoot__O()).Invoke_O__O(root__3); var host_id__5 any = jrt.System_Getenv_String__String(Lit_106).Ref(); var index_file__6 any; var tmp1 any; var and__1927000168__auto____6 any = print_cache__1; if








	jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(host_id__5) } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) { index_file__6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(print_cache__1, host_id__5, dir__0) } else { index_file__6 = nil }; var index__7 any; if
	jrt.A2g_Truth(index_file__6) { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_87.GetRawRoot__O()).Invoke_O__O(index_file__6); if jrt.A2g_Truth(or__1927000174__auto____7) { index__7 = or__1927000174__auto____7 } else { lang.PersistentArrayMap_Init(); index__7 = lang.PersistentArrayMap_EMPTY.Ref() } } else { index__7 = nil }; var shas__8 any; if
	jrt.A2g_Truth(index_file__6) { var m__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_53.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_root_packages_fn__715000099_A_New(); var tmp5 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000099_A_fn_class
		if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_g2a_build_root_packages_fn__715000099_A_fn_class = fncls__22d; tmp5 = fncls__22d } else { tmp5 = fncls__22 }; m__8 = tmp2.Invoke_O_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), files__4), lang.IFn_Cast(A_arbace_g2a_build_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_88.GetRawRoot__O(), files__4))
		var tmp6 any = A_arbace_g2a_build_root_packages_fn__715000101_A_New_O(m__8); var tmp7 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000101_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_g2a_build_root_packages_fn__715000101_A_fn_class = fncls__19d; tmp7 = fncls__19d } else { tmp7 = fncls__19 }; shas__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) } else {
//line :195:1
			shas__8 = nil }; var valid__9 any; if


	jrt.A2g_Truth(index_file__6) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_79.GetRawRoot__O()); var tmp9 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY; var tmp10 any = tmp9.Ref(); var tmp11 any; var iter__1927001039__auto____9 any; var tmp12 any = A_arbace_g2a_build_root_packages_iter__715000103__715000107_A_New_O(shas__8); var tmp13 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000103__715000107_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_g2a_build_root_packages_iter__715000103__715000107_A_fn_class = fncls__27d; tmp13 = fncls__27d } else { tmp13 = fncls__27 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); tmp11 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_g2a_build_A_const_78.Invoke_O__O(index__7)); valid__9 = tmp8.Invoke_O_O__O(tmp10, tmp11) } else {
//line :198:1
			valid__9 = nil }; var covered__10 any; var tmp14 lang.IFn = /*line :184:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_89.GetRawRoot__O()); var tmp15 any; var iter__1927001039__auto____10 any; var tmp16 any = A_arbace_g2a_build_root_packages_iter__715000131__715000137_A_New(); var tmp17 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000131__715000137_A_fn_class; if

















	fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_g2a_build_root_packages_iter__715000131__715000137_A_fn_class = fncls__32d; tmp17 = fncls__32d } else { tmp17 = fncls__32 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); tmp15 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(valid__9); covered__10 = tmp14.Invoke_O__O(tmp15); var pf_index__11 any = /*line :184:1*/A_arbace_g2a_build_A_const_90.Invoke_O__O(index__7); var known_QMARK___12 any; var tmp18 any = A_arbace_g2a_build_root_packages_known_QMARK___715000156_A_New_O_O_O(index_file__6, pf_index__11, shas__8); var tmp19 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_build_root_packages_known_QMARK___715000156_A_fn_class; if






	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_137, false); A_arbace_g2a_build_root_packages_known_QMARK___715000156_A_fn_class = fncls__20d; tmp19 = fncls__20d } else { tmp19 = fncls__20 }; known_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var read_fn__13 any; var tmp20 lang.IFn = /*line :184:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_91.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp22 any = A_arbace_g2a_build_root_packages_fn__715000158_A_New_O_O(covered__10, known_QMARK___12); var tmp23 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000158_A_fn_class; if




















	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, false); A_arbace_g2a_build_root_packages_fn__715000158_A_fn_class = fncls__33d; tmp23 = fncls__33d } else { tmp23 = fncls__33 }; read_fn__13 = tmp20.Invoke_O__O(tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), files__4)); var pkg_file_QMARK___14 any; var tmp24 any = /*line :184:1*/A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A_New_O_O_O_O(read_fn__13, known_QMARK___12, pf_index__11, shas__8); var tmp25 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A_fn_class; if





















	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A_fn_class = fncls__21d; tmp25 = fncls__21d } else { tmp25 = fncls__21 }; pkg_file_QMARK___14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var pkgs__15 any; var tmp26 lang.IFn = /*line :184:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()); var tmp27 any; var iter__1927001039__auto____15 any; var tmp28 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_A_New_O_O_O_O(pkg_file_QMARK___14, read_fn__13, dir__0, valid__9); var tmp29 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_A_fn_class; if























	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_A_fn_class = fncls__40d; tmp29 = fncls__40d } else { tmp29 = fncls__40 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); tmp27 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__4); pkgs__15 = tmp26.Invoke_O__O(tmp27); if




	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_97.GetRawRoot__O()).Invoke_O__O(pkgs__15)) {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_141, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref())).Ref()) }; var seq_715000180__16 any = /*line :184:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46, pkgs__15)); var chunk_715000181__17 any; var count_715000182__18 int64 = 0; var i_715000183__19 int64 = 0; L1: for {






























			if lang.Numbers_Lt_J_J__Z(i_715000183__19, count_715000182__18) { var vec__715000184__20 any = lang.Indexed_Cast(chunk_715000181__17).Nth_I__O(lang.RT_IntCast_J__I(i_715000183__19)); var path__21 any = lang.RT_Nth_O_I_O__O(vec__715000184__20, lang.RT_IntCast_J__I(0), nil); var ps__22 any = lang.RT_Nth_O_I_O__O(vec__715000184__20, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__22)), 1) {
				var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_85, nil); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_build_root_packages_fn__715000187_A_New_O(dir__0); var tmp35 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000187_A_fn_class
				if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_g2a_build_root_packages_fn__715000187_A_fn_class = fncls__41d; tmp35 = fncls__41d } else { tmp35 = fncls__41 }
//line :216:1
				tmp30.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, path__21, nil, tmp32.Invoke_O_O__O(Lit_86, tmp33.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil), ps__22)))).Ref())
//line :215:1
				seq_715000180__16, chunk_715000181__17, count_715000182__18, i_715000183__19 = seq_715000180__16, chunk_715000181__17, count_715000182__18, lang.Numbers_Unchecked_inc_J__J(i_715000183__19); continue L1 } else { seq_715000180__16, chunk_715000181__17, count_715000182__18, i_715000183__19 = seq_715000180__16, chunk_715000181__17, count_715000182__18, lang.Numbers_Unchecked_inc_J__J(i_715000183__19); continue L1 } } else { var temp__1927000414__auto____20 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000180__16); if jrt.A2g_Truth(temp__1927000414__auto____20) { var seq_715000180__21 any = temp__1927000414__auto____20; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000180__21)) { var c__1927000678__auto____22 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000180__21); seq_715000180__16, chunk_715000181__17, count_715000182__18, i_715000183__19 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000180__21), c__1927000678__auto____22, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000189__22 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000180__21); var path__23 any = lang.RT_Nth_O_I_O__O(vec__715000189__22, lang.RT_IntCast_J__I(0), nil); var ps__24 any = lang.RT_Nth_O_I_O__O(vec__715000189__22, lang.RT_IntCast_J__I(1), nil); if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(ps__24)), 1) {
					var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_84, nil, Lit_85, nil); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp40 any = A_arbace_g2a_build_root_packages_fn__715000192_A_New_O(dir__0); var tmp41 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_g2a_build_root_packages_fn__715000192_A_fn_class
					if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_g2a_build_root_packages_fn__715000192_A_fn_class = fncls__42d; tmp41 = fncls__42d } else { tmp41 = fncls__42 }
//line :216:1
					tmp36.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, path__23, nil, tmp38.Invoke_O_O__O(Lit_86, tmp39.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil), ps__24)))).Ref())
//line :215:1
					seq_715000180__16, chunk_715000181__17, count_715000182__18, i_715000183__19 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000180__21), nil, 0, 0; continue L1 } else { seq_715000180__16, chunk_715000181__17, count_715000182__18, i_715000183__19 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000180__21), nil, 0, 0; continue L1 } } } }
//line :184:1
			break L1 }; if

































	jrt.A2g_Truth(index_file__6) { var index_SINGLEQUOTE___16 any; var tmp42 any = A_arbace_g2a_build_A_const_90; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_79.GetRawRoot__O()); var tmp44 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp45 any; var iter__1927001039__auto____16 any; var tmp46 any = A_arbace_g2a_build_root_packages_iter__715000194__715000198_A_New_O_O(pkg_file_QMARK___14, shas__8); var tmp47 *jrt.Class
		var fncls__45 /*line :218:1*/*jrt.Class = A_arbace_g2a_build_root_packages_iter__715000194__715000198_A_fn_class

		if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_g2a_build_root_packages_iter__715000194__715000198_A_fn_class = fncls__45d; tmp47 = fncls__45d } else { tmp47 = fncls__45 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil); tmp45 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(files__4)
//line :218:1
		var tmp48 any = tmp43.Invoke_O_O__O(tmp44, tmp45); var tmp49 any = A_arbace_g2a_build_A_const_78; var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_79.GetRawRoot__O()); var tmp51 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp52 any; var iter__1927001039__auto____16_2 any; var tmp53 any = A_arbace_g2a_build_root_packages_iter__715000204__715000208_A_New_O(shas__8); var tmp54 *jrt.Class
		var fncls__50 /*line :218:1*/*jrt.Class = A_arbace_g2a_build_root_packages_iter__715000204__715000208_A_fn_class




		if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_g2a_build_root_packages_iter__715000204__715000208_A_fn_class = fncls__50d; tmp54 = fncls__50d } else { tmp54 = fncls__50 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil); tmp52 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(pkgs__15)
//line :218:1
		index_SINGLEQUOTE___16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp48, tmp49, tmp50.Invoke_O_O__O(tmp51, tmp52)))








		if lang.Util_Equiv_O_O__Z(index_SINGLEQUOTE___16, index__7) { } else {
			lang.IFn_Cast(A_arbace_g2a_build_A_const_98.GetRawRoot__O()).Invoke_O_O__O(index_file__6, index_SINGLEQUOTE___16) } }; return pkgs__15 }
//line :191:1
func A_arbace_g2a_build_root_packages_known_QMARK___715000156_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_root_packages_known_QMARK___715000156_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_known_QMARK___715000156_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :191:1
func (t *A_arbace_g2a_build_root_packages_known_QMARK___715000156_A) Ctor_O_O_O(c__index_file, c__pf_index, c__shas any) { t.F_index_file = c__index_file; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :191:1
func (t *A_arbace_g2a_build_root_packages_known_QMARK___715000156_A) Invoke_O_O__O(self, p1__715000095_SHARP___1 any) any { var and__1927000168__auto____2 any = t.F_index_file; if












	jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp2 any = t.F_pf_index; var tmp3 lang.IFn = lang.IFn_Cast(t.F_shas); return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__715000095_SHARP___1)).GetPath__String().Ref())) } else { return and__1927000168__auto____2 } }
//line :196:1
func A_arbace_g2a_build_root_packages_fn__715000099_A_New() *A_arbace_g2a_build_root_packages_fn__715000099_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000099_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_g2a_build_root_packages_fn__715000099_A) Ctor() {}
//line :196:1
func (t *A_arbace_g2a_build_root_packages_fn__715000099_A) Invoke_O_O__O(self, p1__715000094_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__715000094_SHARP___1)).GetPath__String().Ref() }
func A_arbace_g2a_build_root_packages_fn__715000101_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_fn__715000101_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000101_A{}; t.Ctor_O(p0); return t }
//line :197:1
func (t *A_arbace_g2a_build_root_packages_fn__715000101_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :197:1
func (t *A_arbace_g2a_build_root_packages_fn__715000101_A) Invoke_O_O__O(self, path__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()).Invoke_O_O__O(t.F_m, path__1)) { return lang.RT_Get_O_O__O(t.F_m, path__1) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_88.GetRawRoot__O()).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(path__1))) } }

func A_arbace_g2a_build_root_packages_iter__715000103__715000107_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_iter__715000103__715000107_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000103__715000107_A{}; t.Ctor_O(p0); return t }
//line :199:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :199:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_A) Invoke_O_O__O(self, s__715000104__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A_New_O_O_O(self, s__715000104__1, t.F_shas); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_146, false); A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :199:1
func A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :199:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A) Ctor_O_O_O(c__iter__715000103, c__s__715000104, c__shas any) { t.F_iter__715000103 = c__iter__715000103; t.F_s__715000104 = c__s__715000104; t.F_shas = c__shas }
//line :199:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A) Invoke_O__O(self any) any { { var s__715000104__1 any; var t_ any = t.F_s__715000104; t.F_s__715000104 = nil; s__715000104__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000104__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000104__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000104__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000104__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000106__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A_New_O_I_O_O(b__715000106__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000103); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000106__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000104__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000106__6), nil) } } else { var vec__715000120__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000104__3); var path__5 any = lang.RT_Nth_O_I_O__O(vec__715000120__4, lang.RT_IntCast_J__I(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O(vec__715000120__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_93.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A_New_O(t.F_shas); var tmp6 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A_fn_class
														if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_148, false); A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A_fn_class = fncls__25d; tmp6 = fncls__25d } else { tmp6 = fncls__25 }
//line :199:1
	if jrt.A2g_Truth(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), A_arbace_g2a_build_A_const_66.Invoke_O__O(e__6))) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__715000103); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(path__5, e__6), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000104__3))) } else { s__715000104__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000104__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :199:1
func A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :199:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A) Ctor_O_I_O_O(c__b__715000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__715000106 = c__b__715000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :199:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A) Invoke_O__O(self any) any { { var i__715000105__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__715000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000105__1)); var path__3 any = lang.RT_Nth_O_I_O__O(vec__715000110__2, lang.RT_IntCast_J__I(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O(vec__715000110__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_93.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A_New_O(t.F_shas); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A_fn_class
																if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, false); A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }
//line :199:1
	if jrt.A2g_Truth(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_g2a_build_A_const_66.Invoke_O__O(e__4))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp6 any = t.F_b__715000106; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(path__3, e__4)); i__715000105__1 = lang.Numbers_Unchecked_inc_J__J(i__715000105__1); continue L1 } else { i__715000105__1 = lang.Numbers_Unchecked_inc_J__J(i__715000105__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A{}; t.Ctor_O(p0); return t }
//line :200:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :200:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A) Invoke_O_O__O(self, p__715000113__1 any) any { var vec__715000115__2 any = p__715000113__1; var rp__3 any = lang.RT_Nth_O_I_O__O(vec__715000115__2, lang.RT_IntCast_J__I(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O(vec__715000115__2, lang.RT_IntCast_J__I(1), nil); return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }
//line :200:1
func A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A{}; t.Ctor_O(p0); return t }
//line :200:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :200:1
func (t *A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A) Invoke_O_O__O(self, p__715000123__1 any) any { var vec__715000125__2 any = p__715000123__1; var rp__3 any = lang.RT_Nth_O_I_O__O(vec__715000125__2, lang.RT_IntCast_J__I(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O(vec__715000125__2, lang.RT_IntCast_J__I(1), nil); return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }

func A_arbace_g2a_build_root_packages_iter__715000131__715000137_A_New() *A_arbace_g2a_build_root_packages_iter__715000131__715000137_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000131__715000137_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_A) Ctor() {}
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_A) Invoke_O_O__O(self, s__715000132__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A_New_O_O(self, s__715000132__1); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :202:1
func A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A) Ctor_O_O(c__iter__715000131, c__s__715000132 any) { t.F_iter__715000131 = c__iter__715000131; t.F_s__715000132 = c__s__715000132 }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A) Invoke_O__O(self any) any { { var s__715000132__1 any; var t_ any = t.F_s__715000132; t.F_s__715000132 = nil; s__715000132__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000132__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__715000139__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__715000139__4, lang.RT_IntCast_J__I(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O(vec__715000139__4, lang.RT_IntCast_J__I(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A_New(); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A_fn_class; _ = ___5; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_151, false); A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_g2a_build_A_const_66.Invoke_O__O(e__6))); if jrt.A2g_Truth(fs__1927001036__auto____8) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000131); return lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____8, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000132__1))) } else { s__715000132__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000132__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :202:1
func A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A_New() *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A) Ctor() {}
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A) Invoke_O_O__O(self, s__715000134__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A_New_O_O(self, s__715000134__1); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_152, false); A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :202:1
func A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A) Ctor_O_O(c__iter__715000133, c__s__715000134 any) { t.F_iter__715000133 = c__iter__715000133; t.F_s__715000134 = c__s__715000134 }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A) Invoke_O__O(self any) any { { var s__715000134__1 any; var t_ any = t.F_s__715000134; t.F_s__715000134 = nil; s__715000134__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000134__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000134__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000134__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000134__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000136__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A_New_O_I_O(b__715000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000133); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000136__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000134__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000136__6), nil) } } else { var vec__715000149__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000134__3); var rp__5 any = lang.RT_Nth_O_I_O__O(vec__715000149__4, lang.RT_IntCast_J__I(0), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__715000133); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(rp__5, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000134__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :202:1
func A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A) Ctor_O_I_O(c__b__715000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__715000136 = c__b__715000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :202:1
func (t *A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A) Invoke_O__O(self any) any { { var i__715000135__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__715000145__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000135__1)); var rp__3 any = lang.RT_Nth_O_I_O__O(vec__715000145__2, lang.RT_IntCast_J__I(0), nil); lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__715000136, rp__3); i__715000135__1 = lang.Numbers_Unchecked_inc_J__J(i__715000135__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_g2a_build_root_packages_fn__715000158_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_fn__715000158_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_g2a_build_root_packages_fn__715000158_A) Ctor_O_O(c__covered, c__known_QMARK_ any) { t.F_covered = c__covered; t.F_known_QMARK_ = c__known_QMARK_ }
//line :205:1
func (t *A_arbace_g2a_build_root_packages_fn__715000158_A) Invoke_O_O__O(self, p1__715000096_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(p1__715000096_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_covered); tmp2 = tmp3.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__715000096_SHARP___1)).GetPath__String().Ref()) } else { tmp2 = and__1927000168__auto____2 }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :206:1
func (t *A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A) Ctor_O_O_O_O(c__read_fn, c__known_QMARK_, c__pf_index, c__shas any) { t.F_read_fn = c__read_fn; t.F_known_QMARK_ = c__known_QMARK_; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :206:1
func (t *A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A) Invoke_O_O__O(self, f__1 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(f__1)) { var tmp1 any = t.F_pf_index; var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.RT_Get_O_O__O(tmp1, tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__1)).GetPath__String().Ref())) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_92.GetRawRoot__O()).Invoke_O_O__O(f__1, t.F_read_fn) } }
func A_arbace_g2a_build_root_packages_iter__715000162__715000166_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_build_root_packages_iter__715000162__715000166_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :208:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid }
//line :208:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_A) Invoke_O_O__O(self, s__715000163__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A_New_O_O_O_O_O_O(self, t.F_pkg_file_QMARK_, t.F_read_fn, s__715000163__1, t.F_dir, t.F_valid); var tmp2 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :208:1
func A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :208:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A) Ctor_O_O_O_O_O_O(c__iter__715000162, c__pkg_file_QMARK_, c__read_fn, c__s__715000163, c__dir, c__valid any) { t.F_iter__715000162 = c__iter__715000162; t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_s__715000163 = c__s__715000163; t.F_dir = c__dir; t.F_valid = c__valid }
//line :208:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A) Invoke_O__O(self any) any { { var s__715000163__1 any; var t_ any = t.F_s__715000163; t.F_s__715000163 = nil; s__715000163__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000163__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000163__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000163__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000163__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000165__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A_New_O_O_O_O_O_I_O(t.F_pkg_file_QMARK_, t.F_read_fn, t.F_dir, t.F_valid, b__715000165__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000162); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000165__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000163__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000165__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000163__3); if jrt.A2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()); var tmp5 any; var tmp6 any = t.F_valid; var temp__1927000408__auto____5 any = lang.RT_Get_O_O__O(tmp6, jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref())
														if jrt.A2g_Truth(temp__1927000408__auto____5) { var e__6 any = temp__1927000408__auto____5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_build_A_const_82.Invoke_O__O(e__6); var tmp9 any = A_arbace_g2a_build_A_const_50; var tmp10 any = A_arbace_g2a_build_A_const_66; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_95.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A_New(); var tmp13 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A_fn_class
															if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_156, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A_fn_class = fncls__38d; tmp13 = fncls__38d } else { tmp13 = fncls__38 }; var tmp14 any = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_g2a_build_A_const_66.Invoke_O__O(e__6)); var tmp15 any = A_arbace_g2a_build_A_const_96; var tmp16 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A_New_O_O(f__4, t.F_dir); var tmp17 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A_fn_class
															if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_157, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A_fn_class = fncls__37d; tmp17 = fncls__37d } else { tmp17 = fncls__37 }
//line :210:1
		tmp5 = tmp7.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp9, f__4, tmp10, tmp14, tmp15, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil))) } else {

			tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()).Invoke_O_O_O__O(t.F_dir, f__4, t.F_read_fn) }
//line :208:1
	var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__715000162); return tmp4.Invoke_O_O__O(tmp5, tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000163__3))) } else { s__715000163__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000163__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :208:1
func A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :208:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A) Ctor_O_O_O_O_O_I_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid, c__b__715000165 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid; t.F_b__715000165 = c__b__715000165; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :208:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A) Invoke_O__O(self any) any { { var i__715000164__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000164__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000164__1)); if jrt.A2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000165; var tmp4 any; var tmp5 any = t.F_valid; var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O(tmp5, jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref())
																if jrt.A2g_Truth(temp__1927000408__auto____3) { var e__4 any = temp__1927000408__auto____3; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_A_const_82.Invoke_O__O(e__4); var tmp8 any = A_arbace_g2a_build_A_const_50; var tmp9 any = A_arbace_g2a_build_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_95.GetRawRoot__O()); var tmp11 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A_New(); var tmp12 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A_fn_class
																	if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_158, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A_fn_class = fncls__35d; tmp12 = fncls__35d } else { tmp12 = fncls__35 }; var tmp13 any = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_g2a_build_A_const_66.Invoke_O__O(e__4)); var tmp14 any = A_arbace_g2a_build_A_const_96; var tmp15 any = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A_New_O_O(f__2, t.F_dir); var tmp16 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A_fn_class
																	if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, false); A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A_fn_class = fncls__34d; tmp16 = fncls__34d } else { tmp16 = fncls__34 }
//line :210:1
		tmp4 = tmp6.Invoke_O_O_O_O_O_O_O__O(tmp7, tmp8, f__2, tmp9, tmp13, tmp14, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))) } else {

			tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()).Invoke_O_O_O__O(t.F_dir, f__2, t.F_read_fn) }
//line :208:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__715000164__1 = lang.Numbers_Unchecked_inc_J__J(i__715000164__1); continue L1 } else { i__715000164__1 = lang.Numbers_Unchecked_inc_J__J(i__715000164__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A_New() *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A) Ctor() {}
//line :210:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A) Invoke_O_O__O(self, p1__715000097_SHARP___1 any) any { return jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000097_SHARP___1))) }
//line :210:1
func A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A_New() *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A) Ctor() {}
//line :210:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A) Invoke_O_O__O(self, p1__715000097_SHARP___1 any) any { return jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__715000097_SHARP___1))) }
func A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :211:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :211:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_dir; t.F_dir = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_f; t.F_f = nil; tmp4 = t__2; return tmp1.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_g2a_build_A_const_54.GetRawRoot__O()) }
//line :211:1
func A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :211:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :211:1
func (t *A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_94.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_dir; t.F_dir = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_f; t.F_f = nil; tmp4 = t__2; return tmp1.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_g2a_build_A_const_54.GetRawRoot__O()) }





func A_arbace_g2a_build_root_packages_fn__715000187_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_fn__715000187_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000187_A{}; t.Ctor_O(p0); return t }
//line :217:1
func (t *A_arbace_g2a_build_root_packages_fn__715000187_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :217:1
func (t *A_arbace_g2a_build_root_packages_fn__715000187_A) Invoke_O_O__O(self, p1__715000098_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_dir; return tmp1.Invoke_O_O__O(tmp2, A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000098_SHARP___1)) }
//line :217:1
func A_arbace_g2a_build_root_packages_fn__715000192_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_fn__715000192_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_fn__715000192_A{}; t.Ctor_O(p0); return t }
//line :217:1
func (t *A_arbace_g2a_build_root_packages_fn__715000192_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :217:1
func (t *A_arbace_g2a_build_root_packages_fn__715000192_A) Invoke_O_O__O(self, p1__715000098_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_dir; return tmp1.Invoke_O_O__O(tmp2, A_arbace_g2a_build_A_const_50.Invoke_O__O(p1__715000098_SHARP___1)) }


func A_arbace_g2a_build_root_packages_iter__715000194__715000198_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_root_packages_iter__715000194__715000198_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000194__715000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_g2a_build_root_packages_iter__715000194__715000198_A) Ctor_O_O(c__pkg_file_QMARK_, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_shas = c__shas }
//line :220:1
func (t *A_arbace_g2a_build_root_packages_iter__715000194__715000198_A) Invoke_O_O__O(self, s__715000195__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A_New_O_O_O_O(t.F_pkg_file_QMARK_, s__715000195__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :220:1
func A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :220:1
func (t *A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__s__715000195, c__iter__715000194, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_s__715000195 = c__s__715000195; t.F_iter__715000194 = c__iter__715000194; t.F_shas = c__shas }
//line :220:1
func (t *A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A) Invoke_O__O(self any) any { { var s__715000195__1 any; var t_ any = t.F_s__715000195; t.F_s__715000195 = nil; s__715000195__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000195__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000195__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000195__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000195__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000197__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A_New_O_O_I_O_O(t.F_pkg_file_QMARK_, b__715000197__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_161, false); A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000194); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000197__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000195__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000197__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000195__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__5 any = tmp4.Invoke_O__O(jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref()); if jrt.A2g_Truth(sha__5) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__715000194); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(sha__5, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4))).Ref()), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000195__3))) } else { s__715000195__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000195__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :220:1
func A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :220:1
func (t *A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A) Ctor_O_O_I_O_O(c__pkg_file_QMARK_, c__b__715000197 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_b__715000197 = c__b__715000197; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :220:1
func (t *A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A) Invoke_O__O(self any) any { { var i__715000196__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__3 any = tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref()); if jrt.A2g_Truth(sha__3) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp4 any = t.F_b__715000197; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(sha__3, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2))).Ref())); i__715000196__1 = lang.Numbers_Unchecked_inc_J__J(i__715000196__1); continue L1 } else { i__715000196__1 = lang.Numbers_Unchecked_inc_J__J(i__715000196__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_g2a_build_root_packages_iter__715000204__715000208_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_iter__715000204__715000208_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000204__715000208_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :223:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_A) Invoke_O_O__O(self, s__715000205__1 any) any { var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A_New_O_O_O(self, s__715000205__1, t.F_shas); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_162, false); A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :223:1
func A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :223:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A) Ctor_O_O_O(c__iter__715000204, c__s__715000205, c__shas any) { t.F_iter__715000204 = c__iter__715000204; t.F_s__715000205 = c__s__715000205; t.F_shas = c__shas }
//line :223:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A) Invoke_O__O(self any) any { { var s__715000205__1 any; var t_ any = t.F_s__715000205; t.F_s__715000205 = nil; s__715000205__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000205__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000205__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000205__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000205__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000207__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A_New_O_I_O_O(b__715000207__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp2 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A_fn_class = fncls__47d; tmp2 = fncls__47d } else { tmp2 = fncls__47 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000204); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000207__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000205__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000207__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000205__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()); var tmp5 any = jrt.NN(jrt.File_Cast(A_arbace_g2a_build_A_const_50.Invoke_O__O(pkg__4))).GetPath__String().Ref(); var tmp6 any = A_arbace_g2a_build_A_const_66; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_95.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A_New_O(t.F_shas); var tmp9 *jrt.Class
														var fncls__48 /*line :223:1*/*jrt.Class = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A_fn_class

	if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_164, false); A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A_fn_class = fncls__48d; tmp9 = fncls__48d } else { tmp9 = fncls__48 }
//line :223:1
	var tmp10 any = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), A_arbace_g2a_build_A_const_66.Invoke_O__O(pkg__4)); var tmp11 any = A_arbace_g2a_build_A_const_82; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__715000204); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp10, tmp11, lang.IFn_Cast(A_arbace_g2a_build_A_const_99.GetRawRoot__O()).Invoke_O_O__O(pkg__4, A_arbace_g2a_build_A_const_101)))), tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000205__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :223:1
func A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :223:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A) Ctor_O_I_O_O(c__b__715000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__715000207 = c__b__715000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :223:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A) Invoke_O__O(self any) any { { var i__715000206__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000206__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000207; var tmp4 any = jrt.NN(jrt.File_Cast(A_arbace_g2a_build_A_const_50.Invoke_O__O(pkg__2))).GetPath__String().Ref(); var tmp5 any = A_arbace_g2a_build_A_const_66; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_95.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A_New_O(t.F_shas); var tmp8 *jrt.Class
																var fncls__46 /*line :223:1*/*jrt.Class = A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A_fn_class

	if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, false); A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A_fn_class = fncls__46d; tmp8 = fncls__46d } else { tmp8 = fncls__46 }
//line :223:1
	var tmp9 any = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), A_arbace_g2a_build_A_const_66.Invoke_O__O(pkg__2)); var tmp10 any = A_arbace_g2a_build_A_const_82; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp9, tmp10, lang.IFn_Cast(A_arbace_g2a_build_A_const_99.GetRawRoot__O()).Invoke_O_O__O(pkg__2, A_arbace_g2a_build_A_const_100))))); i__715000206__1 = lang.Numbers_Unchecked_inc_J__J(i__715000206__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }
//line :225:1
func A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A_New_O(p0 any) *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }





func A_arbace_g2a_build_collected_package_A_New() *A_arbace_g2a_build_collected_package_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_collected_package_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_g2a_build_collected_package_A) Ctor() {}
//line :231:1
func (t *A_arbace_g2a_build_collected_package_A) Invoke_O_O__O(self, pkg__0 any) any { var temp__1927000408__auto____2 any = A_arbace_g2a_build_A_const_96.Invoke_O__O(pkg__0); if



	jrt.A2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var c__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_6.GetRawRoot__O()).Invoke_O__O(d__3)

		if lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_g2a_build_A_const_99.GetRawRoot__O()).Invoke_O_O__O(c__4, A_arbace_g2a_build_A_const_102), lang.IFn_Cast(A_arbace_g2a_build_A_const_99.GetRawRoot__O()).Invoke_O_O__O(pkg__0, A_arbace_g2a_build_A_const_103)) { } else {
			lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__0), nil)).Ref()) }
//line :235:1
		return c__4 } else { return pkg__0 } }






func A_arbace_g2a_build_read_program_edn_A_New() *A_arbace_g2a_build_read_program_edn_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_read_program_edn_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_g2a_build_read_program_edn_A) Ctor() {}
//line :242:1
func (t *A_arbace_g2a_build_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_128); if

	jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var forms__3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_54.GetRawRoot__O()).Invoke_O__O(f__2); var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(forms__3)))

		if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(forms__3)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() }; if jrt.A2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_129) }
		return lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(forms__3) } else {
//line :244:1
			lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_g2a_build_run_A_New() *A_arbace_g2a_build_run_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_run_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_g2a_build_run_A) Ctor() {}
//line :251:1
func (t *A_arbace_g2a_build_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any = jrt.ProcessBuilder_New_List(jrt.List_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), cmd__0)));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :251:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_715000221__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(env__2); var chunk_715000222__8 any; var count_715000223__9 int64 = 0; var i_715000224__10 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i_715000224__10, count_715000223__9) { var vec__715000225__11 any = lang.Indexed_Cast(chunk_715000222__8).Nth_I__O(lang.RT_IntCast_J__I(i_715000224__10)); var k__12 any = lang.RT_Nth_O_I_O__O(vec__715000225__11, lang.RT_IntCast_J__I(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O(vec__715000225__11, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_715000221__7, chunk_715000222__8, count_715000223__9, i_715000224__10 = seq_715000221__7, chunk_715000222__8, count_715000223__9, lang.Numbers_Unchecked_inc_J__J(i_715000224__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000221__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_715000221__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000221__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000221__12); seq_715000221__7, chunk_715000222__8, count_715000223__9, i_715000224__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000221__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000228__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000221__12); var k__14 any = lang.RT_Nth_O_I_O__O(vec__715000228__13, lang.RT_IntCast_J__I(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O(vec__715000228__13, lang.RT_IntCast_J__I(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); seq_715000221__7, chunk_715000222__8, count_715000223__9, i_715000224__10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000221__12), nil, 0, 0; continue L1 } } }
//line :251:1
		break L1 }; if







	jrt.A2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :259:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			var tmp1 *jrt.ProcessBuilder = jrt.ProcessBuilder_Cast(pb__5); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(tmp2).BooleanValue__Z())
//line :259:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_104.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_g2a_build_go_env_A_New() *A_arbace_g2a_build_go_env_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_go_env_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_g2a_build_go_env_A) Ctor() {}
//line :269:1
func (t *A_arbace_g2a_build_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z(goos__2, Lit_27) { var tmp4 *lang.Keyword = A_arbace_g2a_build_A_const_46; tmp3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_63, tmp4.Invoke_O__O(A_arbace_g2a_build_A_const_105.GetRawRoot__O()))) } else { tmp3 = nil }
//line :275:1
	var tmp5 any = tmp3; var tmp6 any
	var G__715000232__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I(G__715000232__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__715000232__4_, Lit_64) { tmp6 = A_arbace_g2a_build_A_const_106; break L1 }; case 1: if lang.Util_Equiv_O_O__Z(G__715000232__4_, Lit_5) { tmp6 = A_arbace_g2a_build_A_const_107; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__715000232__4_)))))}
//line :275:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :269:1
func (t *A_arbace_g2a_build_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	return lang.IFn_Cast(A_arbace_g2a_build_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(goroot__0, arch__1, Lit_37)
}

























func A_arbace_g2a_build_go_mod_cache_A_New() *A_arbace_g2a_build_go_mod_cache_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_go_mod_cache_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_g2a_build_go_mod_cache_A) Ctor() {}
//line :300:1
func (t *A_arbace_g2a_build_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__715000234__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_109.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_66, Lit_67); var tmp3 any = jrt.File_New_String(Lit_68); var tmp4 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_69, goroot__0, Lit_70, Lit_71)); var tmp5 *jrt.Boolean;
											jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; vec__715000234__2 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()); var status__3 any = /*line :300:1*/lang.RT_Nth_O_I_O__O(vec__715000234__2, lang.RT_IntCast_J__I(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O(vec__715000234__2, lang.RT_IntCast_J__I(1), nil); if


	lang.Numbers_IsZero_O__Z(status__3) { } else { lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; return /*line :304:1*/ lang.IFn_Cast(A_arbace_g2a_build_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(out__4)) }

func A_arbace_g2a_build_h1_of_file_A_New() *A_arbace_g2a_build_h1_of_file_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_g2a_build_h1_of_file_A) Ctor() {}
//line :306:1
func (t *A_arbace_g2a_build_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var tmp1 any = A_arbace_g2a_build_h1_of_file_hex__715000239_A_New(); var tmp2 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_g2a_build_h1_of_file_hex__715000239_A_fn_class; if


	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_g2a_build_h1_of_file_hex__715000239_A_fn_class = fncls__53d; tmp2 = fncls__53d } else { tmp2 = fncls__53 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var sha__4 any; var tmp3 any = /*line :306:1*/A_arbace_g2a_build_h1_of_file_sha__715000243_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_g2a_build_h1_of_file_sha__715000243_A_fn_class; if



	fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_g2a_build_h1_of_file_sha__715000243_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var summary__5 any = /*line :306:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_75, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :312:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_51).Ref()), jrt.Prim_byte.ArrayClass())).Ref())).Ref() }
//line :309:1
func A_arbace_g2a_build_h1_of_file_hex__715000239_A_New() *A_arbace_g2a_build_h1_of_file_hex__715000239_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_hex__715000239_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000239_A) Ctor() {}
//line :309:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000239_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A_New(); var tmp5 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A_fn_class = fncls__52d; tmp5 = fncls__52d } else { tmp5 = fncls__52 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), b__1)) }
//line :309:1
func A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A_New() *A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A) Ctor() {}
//line :309:1
func (t *A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A) Invoke_O_O__O(self, p1__715000238_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_57.GetRawRoot__O()).Invoke_O_O__O(Lit_78, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000238_SHARP___1, 255)).Ref()) }
func A_arbace_g2a_build_h1_of_file_sha__715000243_A_New() *A_arbace_g2a_build_h1_of_file_sha__715000243_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_h1_of_file_sha__715000243_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_g2a_build_h1_of_file_sha__715000243_A) Ctor() {}
//line :310:1
func (t *A_arbace_g2a_build_h1_of_file_sha__715000243_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_50).Digest_B1__B1(jrt.A2g_CastArray[*jrt.ByteArray](b__1, jrt.Prim_byte.ArrayClass())).Ref() }



func A_arbace_g2a_build_tamago_go_sum_A_New() *A_arbace_g2a_build_tamago_go_sum_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_tamago_go_sum_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_g2a_build_tamago_go_sum_A) Ctor() {}
//line :314:1
func (t *A_arbace_g2a_build_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__715000246__2 any = A_arbace_g2a_build_A_const_105.GetRawRoot__O(); var map__715000246__3 any; if



	lang.ISeq_InstanceOf(map__715000246__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000246__2)) { map__715000246__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_111.GetRawRoot__O()).Invoke_O__O(map__715000246__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000246__2)) { map__715000246__3 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000246__2) } else { lang.PersistentArrayMap_Init(); map__715000246__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000246__3 = map__715000246__2 }; var path__4 any = /*line :314:1*/lang.RT_Get_O_O__O(map__715000246__3, A_arbace_g2a_build_A_const_46); var version__5 any = lang.RT_Get_O_O__O(map__715000246__3, A_arbace_g2a_build_A_const_112); var zip__6 any = lang.RT_Get_O_O__O(map__715000246__3, A_arbace_g2a_build_A_const_113); var mod__7 any = lang.RT_Get_O_O__O(map__715000246__3, A_arbace_g2a_build_A_const_114); var dir__8 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_167, nil, Lit_168), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_build_A_const_115.GetRawRoot__O()).Invoke_O__O(goroot__0), nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_169), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_170), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp1 bool; var and__1927000168__auto____11 bool = jrt.NN(jrt.File_Cast(zf__9)).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(mf__10)).IsFile__Z(); if and__1927000168__auto____12 { tmp1 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_171), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp1 = and__1927000168__auto____12 } } else { tmp1 = and__1927000168__auto____11 }; if tmp1 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_172, nil, Lit_173, nil, Lit_174), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.NN(jrt.File_Cast(dir__8)).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any = /*line :314:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_104.GetRawRoot__O()).Invoke_O__O(zf__9)); var mh__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_116.GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(mf__10)).ToPath__Path()).Ref(), Lit_98); var tmp2 bool; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z(zh__12, zip__6); if and__1927000168__auto____14 {











				tmp2 = lang.Util_Equiv_O_O__Z(mh__13, mod__7) } else { tmp2 = and__1927000168__auto____14 }; if tmp2 { } else {
					lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :328:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_g2a_build_toolchain_lang_A_New() *A_arbace_g2a_build_toolchain_lang_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_toolchain_lang_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_g2a_build_toolchain_lang_A) Ctor() {}
//line :330:1
func (t *A_arbace_g2a_build_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__715000249__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_109.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_66, Lit_175); var tmp3 any = jrt.File_New_String(Lit_68); var tmp4 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_69, goroot__0, Lit_70, Lit_71)); var tmp5 *jrt.Boolean;


	jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; vec__715000249__2 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5.Ref()); var status__3 any = /*line :330:1*/lang.RT_Nth_O_I_O__O(vec__715000249__2, lang.RT_IntCast_J__I(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O(vec__715000249__2, lang.RT_IntCast_J__I(1), nil); var v__5 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(out__4)); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool = lang.Numbers_IsZero_O__Z(status__3); if and__1927000168__auto____6 {





		temp__1927000408__auto____6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_117.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_118, v__5) } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() }; if jrt.A2g_Truth(temp__1927000408__auto____6) { var vec__715000252__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O(vec__715000252__7, lang.RT_IntCast_J__I(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O(vec__715000252__7, lang.RT_IntCast_J__I(1), nil); _ = ___8; return l__9 } else {

			return lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_176, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_g2a_build_program_A_New() *A_arbace_g2a_build_program_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_g2a_build_program_A) Ctor() {}
//line :340:1
func (t *A_arbace_g2a_build_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__715000258__2 any) any { var map__715000259__4 any = p__715000258__2; var map__715000259__5 any; if lang.ISeq_InstanceOf(map__715000259__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000259__4)) { map__715000259__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_111.GetRawRoot__O()).Invoke_O__O(map__715000259__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000259__4)) { map__715000259__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000259__4) } else { lang.PersistentArrayMap_Init(); map__715000259__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000259__5 = map__715000259__4 }; var opts__6 any = map__715000259__5; var library_QMARK___7 any = lang.RT_Get_O_O__O(map__715000259__5, A_arbace_g2a_build_A_const_119); var roots__8 any = lang.RT_Get_O_O__O(map__715000259__5, A_arbace_g2a_build_A_const_120); var pkgs__9 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, roots__8, A_arbace_g2a_build_A_const_126.Invoke_O__O(opts__6)); var mains__10 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_program_fn__715000261_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_g2a_build_program_fn__715000261_A_fn_class; if








	fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_g2a_build_program_fn__715000261_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; mains__10 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), pkgs__9); var ___11 any; var tmp4 any; var or__1927000174__auto____11 bool = /*line :340:1*/lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(mains__10))); _ = ___11; if or__1927000174__auto____11 {









		tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.A2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_97.GetRawRoot__O()).Invoke_O__O(mains__10); if jrt.A2g_Truth(or__1927000174__auto____13) { tmp4 = or__1927000174__auto____13 } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_97, A_arbace_g2a_build_A_const_121.Invoke_O__O(opts__6))).Ref() } } else { tmp4 = and__1927000168__auto____12 } }; if jrt.A2g_Truth(tmp4) { ___11 = nil } else {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_118, nil, nil); var tmp7 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(mains__10)).Ref(); var tmp8 *jrt.String
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(mains__10)) { tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()).Invoke_O_O__O(Lit_86, lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46, mains__10)))) } else { tmp8 = nil }
//line :351:1
			___11 = tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, tmp8.Ref())).Ref()) }; var main__12 any = /*line :340:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(mains__10); var edn__13 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_122.GetRawRoot__O()).Invoke_O__O(dir__0); var module__14 any; var or__1927000174__auto____14 any = A_arbace_g2a_build_A_const_121.Invoke_O__O(edn__13); if














	jrt.A2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_g2a_build_A_const_121.Invoke_O__O(opts__6); if jrt.A2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_g2a_build_A_const_46.Invoke_O__O(main__12); if jrt.A2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_119) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :340:1*/A_arbace_g2a_build_A_const_123.Invoke_O__O(edn__13); if


















	jrt.A2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_g2a_build_A_const_123.Invoke_O__O(opts__6); if jrt.A2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z(module__14, Lit_97) { golang__15 = nil } else { golang__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_124.GetRawRoot__O()).Invoke_O__O(goroot__1) } } }; var pkgs__16 any; var tmp9 lang.IFn = /*line :340:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____16 any; var tmp11 any = A_arbace_g2a_build_program_iter__715000263__715000267_A_New_O(module__14); var tmp12 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_g2a_build_program_iter__715000263__715000267_A_fn_class; if



















	fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_g2a_build_program_iter__715000263__715000267_A_fn_class = fncls__58d; tmp12 = fncls__58d } else { tmp12 = fncls__58 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); pkgs__16 = tmp9.Invoke_O__O(tmp10); var tmp13 any = A_arbace_g2a_build_A_const_121; var tmp14 any = A_arbace_g2a_build_A_const_123; var tmp15 any = /*line :340:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(golang__15); var tmp16 any = A_arbace_g2a_build_A_const_78; var tmp17 any = A_arbace_g2a_build_A_const_125; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_15.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_build_program_fn__715000273_A_New(); var tmp21 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_g2a_build_program_fn__715000273_A_fn_class; if






























	fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_g2a_build_program_fn__715000273_A_fn_class = fncls__59d; tmp21 = fncls__59d } else { tmp21 = fncls__59 }; return /*line :340:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, module__14, tmp14, tmp15, tmp16, pkgs__16, tmp17, tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), pkgs__16)))) }
//line :340:1
func (t *A_arbace_g2a_build_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_130.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O_O__O(dir__0, goroot__1, tmp2.Ref())
}

func A_arbace_g2a_build_program_fn__715000261_A_New() *A_arbace_g2a_build_program_fn__715000261_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_fn__715000261_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_g2a_build_program_fn__715000261_A) Ctor() {}
//line :349:1
func (t *A_arbace_g2a_build_program_fn__715000261_A) Invoke_O_O__O(self, p1__715000256_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_93, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(p1__715000256_SHARP___1)))).Ref() }










func A_arbace_g2a_build_program_iter__715000263__715000267_A_New_O(p0 any) *A_arbace_g2a_build_program_iter__715000263__715000267_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_iter__715000263__715000267_A{}; t.Ctor_O(p0); return t }
//line :360:1
func (t *A_arbace_g2a_build_program_iter__715000263__715000267_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :360:1
func (t *A_arbace_g2a_build_program_iter__715000263__715000267_A) Invoke_O_O__O(self, s__715000264__1 any) any { var tmp1 any = A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A_New_O_O_O(self, s__715000264__1, t.F_module); var tmp2 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A_fn_class = fncls__57d; tmp2 = fncls__57d } else { tmp2 = fncls__57 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :360:1
func A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :360:1
func (t *A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A) Ctor_O_O_O(c__iter__715000263, c__s__715000264, c__module any) { t.F_iter__715000263 = c__iter__715000263; t.F_s__715000264 = c__s__715000264; t.F_module = c__module }
//line :360:1
func (t *A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A) Invoke_O__O(self any) any { { var s__715000264__1 any; var t_ any = t.F_s__715000264; t.F_s__715000264 = nil; s__715000264__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000264__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000264__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000264__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000264__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000266__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A_New_O_I_O_O(b__715000266__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A_fn_class = fncls__56d; tmp2 = fncls__56d } else { tmp2 = fncls__56 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000263); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000266__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000264__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000266__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000264__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()); var tmp5 any; var path__5 any = A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z(t.F_module, Lit_97) {


		tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__4, A_arbace_g2a_build_A_const_128, path__5) } else {
//line :362:1
			if lang.Util_Equiv_O_O__Z(path__5, t.F_module) {



				tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__4, A_arbace_g2a_build_A_const_128, Lit_95) } else {
//line :362:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_127.GetRawRoot__O()).Invoke_O_O__O(path__5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref())) {





						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_build_A_const_128; tmp5 = tmp6.Invoke_O_O_O__O(pkg__4, tmp7, lang.IFn_Cast(A_arbace_g2a_build_A_const_129.GetRawRoot__O()).Invoke_O_O__O(path__5, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(t.F_module)))).Ref())) } else {
//line :362:1
							if A_arbace_g2a_build_A_const_13 != nil {






								tmp5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_124, nil, Lit_125, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :362:1
									tmp5 = nil } } } }
//line :360:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__715000263); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000264__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :360:1
func A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :360:1
func (t *A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A) Ctor_O_I_O_O(c__b__715000266 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__715000266 = c__b__715000266; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :360:1
func (t *A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A) Invoke_O__O(self any) any { { var i__715000265__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000265__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000265__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000266; var tmp4 any; var path__3 any = A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z(t.F_module, Lit_97) {


		tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__2, A_arbace_g2a_build_A_const_128, path__3) } else {
//line :362:1
			if lang.Util_Equiv_O_O__Z(path__3, t.F_module) {



				tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__2, A_arbace_g2a_build_A_const_128, Lit_95) } else {
//line :362:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_127.GetRawRoot__O()).Invoke_O_O__O(path__3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref())) {





						var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_A_const_128; tmp4 = tmp5.Invoke_O_O_O__O(pkg__2, tmp6, lang.IFn_Cast(A_arbace_g2a_build_A_const_129.GetRawRoot__O()).Invoke_O_O__O(path__3, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(t.F_module)))).Ref())) } else {
//line :362:1
							if A_arbace_g2a_build_A_const_13 != nil {






								tmp4 = lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_124, nil, Lit_125, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :362:1
									tmp4 = nil } } } }
//line :360:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__715000265__1 = lang.Numbers_Unchecked_inc_J__J(i__715000265__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_g2a_build_program_fn__715000273_A_New() *A_arbace_g2a_build_program_fn__715000273_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_program_fn__715000273_A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_g2a_build_program_fn__715000273_A) Ctor() {}
//line :371:1
func (t *A_arbace_g2a_build_program_fn__715000273_A) Invoke_O_O__O(self, p1__715000257_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_93, lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(p1__715000257_SHARP___1)))).Ref() }




func A_arbace_g2a_build_sha256_A_New() *A_arbace_g2a_build_sha256_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_sha256_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_g2a_build_sha256_A) Ctor() {}
//line :376:1
func (t *A_arbace_g2a_build_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_50); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_sha256_fn__715000277_A_New(); var tmp5 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_g2a_build_sha256_fn__715000277_A_fn_class; if

	fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_g2a_build_sha256_fn__715000277_A_fn_class = fncls__60d; tmp5 = fncls__60d } else { tmp5 = fncls__60 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref())) }
//line :378:1
func A_arbace_g2a_build_sha256_fn__715000277_A_New() *A_arbace_g2a_build_sha256_fn__715000277_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_sha256_fn__715000277_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_g2a_build_sha256_fn__715000277_A) Ctor() {}
//line :378:1
func (t *A_arbace_g2a_build_sha256_fn__715000277_A) Invoke_O_O__O(self, p1__715000276_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_57.GetRawRoot__O()).Invoke_O_O__O(Lit_78, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000276_SHARP___1, 255)).Ref()) }

func A_arbace_g2a_build_copy_file_A_New() *A_arbace_g2a_build_copy_file_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_copy_file_A{}; t.Ctor(); return t }
//line :380:1
func (t *A_arbace_g2a_build_copy_file_A) Ctor() {}
//line :380:1
func (t *A_arbace_g2a_build_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_131.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_A_const_132; var tmp5 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp5 = jrt.StandardCopyOption_REPLACE_EXISTING; return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.A2g_CastArray[*jrt.RefArray](tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5.Ref())), jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_g2a_build_forms_dir_A_New() *A_arbace_g2a_build_forms_dir_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_forms_dir_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_g2a_build_forms_dir_A) Ctor() {}
//line :385:1
func (t *A_arbace_g2a_build_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_g2a_build_A_const_50.Invoke_O__O(pkg__0); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_129.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_133; return jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__2)).GetParentFile__File(), jrt.String_Cast(tmp1.Invoke_O_O_O__O(n__3, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(n__3)), 3)).Ref()))) }







func A_arbace_g2a_build_with_line_files_A_New() *A_arbace_g2a_build_with_line_files_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_g2a_build_with_line_files_A) Ctor() {}
//line :393:1
func (t *A_arbace_g2a_build_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_134.GetRawRoot__O()).Invoke_O__O(pkg__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_135; var tmp3 any = A_arbace_g2a_build_with_line_files_fn__715000283_A_New_O(fdir__2); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_g2a_build_with_line_files_fn__715000283_A_fn_class; if






	fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_177, false); A_arbace_g2a_build_with_line_files_fn__715000283_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; return tmp1.Invoke_O_O_O__O(pkg__0, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :400:1
func A_arbace_g2a_build_with_line_files_fn__715000283_A_New_O(p0 any) *A_arbace_g2a_build_with_line_files_fn__715000283_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_fn__715000283_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000283_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :400:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000283_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A_New_O(t.F_fdir); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_178, false); A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :400:1
func A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A_New_O(p0 any) *A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :400:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A) Invoke_O_O__O(self, p1__715000282_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_136; var tmp3 any = A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A_New_O(t.F_fdir); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; return tmp1.Invoke_O_O_O__O(p1__715000282_SHARP___1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :400:1
func A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A_New_O(p0 any) *A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :400:1
func (t *A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_fdir; return tmp1.Invoke_O_O__O(tmp2, jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1)))) }



func A_arbace_g2a_build_print_cache_key_A_New() *A_arbace_g2a_build_print_cache_key_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_cache_key_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_g2a_build_print_cache_key_A) Ctor() {}
//line :404:1
func (t *A_arbace_g2a_build_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_50); var add__7 any; var tmp1 any = A_arbace_g2a_build_print_cache_key_add__715000291_A_New_O(md__6); var tmp2 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_g2a_build_print_cache_key_add__715000291_A_fn_class; if





	fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_g2a_build_print_cache_key_add__715000291_A_fn_class = fncls__64d; tmp2 = fncls__64d } else { tmp2 = fncls__64 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0);
	lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(A_arbace_g2a_build_A_const_137.Invoke_O__O(opts__3), jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_g2a_build_A_const_138.Invoke_O__O(opts__3))).Ref(), jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tests__4)).Ref(), A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(pkg__1))))); var seq_715000293__8 any = /*line :404:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_66.Invoke_O__O(pkg__1)); var chunk_715000294__9 any; var count_715000295__10 int64 = 0; var i_715000296__11 int64 = 0; L1: for {








		if lang.Numbers_Lt_J_J__Z(i_715000296__11, count_715000295__10) { var f__12 any = lang.Indexed_Cast(chunk_715000294__9).Nth_I__O(lang.RT_IntCast_J__I(i_715000296__11))
			lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__2, f__12))
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__12)).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_95)
//line :413:1
			seq_715000293__8, chunk_715000294__9, count_715000295__10, i_715000296__11 = seq_715000293__8, chunk_715000294__9, count_715000295__10, lang.Numbers_Unchecked_inc_J__J(i_715000296__11); continue L1 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000293__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_715000293__13 any = temp__1927000414__auto____12; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000293__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000293__13); seq_715000293__8, chunk_715000294__9, count_715000295__10, i_715000296__11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000293__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__14 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000293__13)
				lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__2, f__14))
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__14)).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_95)
//line :413:1
				seq_715000293__8, chunk_715000294__9, count_715000295__10, i_715000296__11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000293__13), nil, 0, 0; continue L1 } } }
//line :404:1
		break L1 }; var tmp3 lang.IFn =












	lang.IFn_Cast(A_arbace_g2a_build_A_const_56.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_build_A_const_29.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_build_print_cache_key_fn__715000297_A_New(); var tmp7 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_g2a_build_print_cache_key_fn__715000297_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_g2a_build_print_cache_key_fn__715000297_A_fn_class = fncls__65d; tmp7 = fncls__65d } else { tmp7 = fncls__65 }; return tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.MessageDigest_Cast(md__6).Digest__B1().Ref())) }
//line :410:1
func A_arbace_g2a_build_print_cache_key_add__715000291_A_New_O(p0 any) *A_arbace_g2a_build_print_cache_key_add__715000291_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_cache_key_add__715000291_A{}; t.Ctor_O(p0); return t }
//line :410:1
func (t *A_arbace_g2a_build_print_cache_key_add__715000291_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :410:1
func (t *A_arbace_g2a_build_print_cache_key_add__715000291_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_51)); return nil }






func A_arbace_g2a_build_print_cache_key_fn__715000297_A_New() *A_arbace_g2a_build_print_cache_key_fn__715000297_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_cache_key_fn__715000297_A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_g2a_build_print_cache_key_fn__715000297_A) Ctor() {}
//line :417:1
func (t *A_arbace_g2a_build_print_cache_key_fn__715000297_A) Invoke_O_O__O(self, p1__715000290_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_build_A_const_57.GetRawRoot__O()).Invoke_O_O__O(Lit_78, jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(p1__715000290_SHARP___1, 255)).Ref()) }

func A_arbace_g2a_build_cached_texts_A_New() *A_arbace_g2a_build_cached_texts_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_g2a_build_cached_texts_A) Ctor() {}
//line :419:1
func (t *A_arbace_g2a_build_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_41); if





	jrt.NN(jrt.File_Cast(names__2)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(entry__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_79.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp3 any; var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A_New_O(entry__0); var tmp5 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A_fn_class
		if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A_fn_class = fncls__68d; tmp5 = fncls__68d } else { tmp5 = fncls__68 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_139.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_104.GetRawRoot__O()).Invoke_O__O(names__2)))
//line :427:1
		return tmp1.Invoke_O_O__O(tmp2, tmp3) } else {
//line :425:1
			return nil } }


func A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A_New_O(p0 any) *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A{}; t.Ctor_O(p0); return t }
//line :428:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :428:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A) Invoke_O_O__O(self, s__715000301__1 any) any { var tmp1 any = A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A_New_O_O_O(self, s__715000301__1, t.F_entry); var tmp2 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :428:1
func A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :428:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A) Ctor_O_O_O(c__iter__715000300, c__s__715000301, c__entry any) { t.F_iter__715000300 = c__iter__715000300; t.F_s__715000301 = c__s__715000301; t.F_entry = c__entry }
//line :428:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A) Invoke_O__O(self any) any { { var s__715000301__1 any; var t_ any = t.F_s__715000301; t.F_s__715000301 = nil; s__715000301__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__715000301__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__715000301__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(s__715000301__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(s__715000301__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__715000303__6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A_New_O_O_I_O(t.F_entry, b__715000303__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__715000300); return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000303__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(s__715000301__3))) } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_40.GetRawRoot__O()).Invoke_O__O(b__715000303__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(s__715000301__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(n__4)) { var tmp4 *jrt.File = jrt.File_Cast(t.F_entry); var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__715000300); return lang.IFn_Cast(A_arbace_g2a_build_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, jrt.File_New_File_String(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4)))), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000301__3))) } else { s__715000301__1 = lang.IFn_Cast(A_arbace_g2a_build_A_const_42.GetRawRoot__O()).Invoke_O__O(s__715000301__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :428:1
func A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :428:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A) Ctor_O_O_I_O(c__entry, c__b__715000303 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_entry = c__entry; t.F_b__715000303 = c__b__715000303; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :428:1
func (t *A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A) Invoke_O__O(self any) any { { var i__715000302__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__715000302__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__715000302__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(n__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__715000303; var tmp4 *jrt.File = jrt.File_Cast(t.F_entry); tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, jrt.File_New_File_String(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2))))); i__715000302__1 = lang.Numbers_Unchecked_inc_J__J(i__715000302__1); continue L1 } else { i__715000302__1 = lang.Numbers_Unchecked_inc_J__J(i__715000302__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_g2a_build_cache_texts_BANG__A_New() *A_arbace_g2a_build_cache_texts_BANG__A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :431:1
func (t *A_arbace_g2a_build_cache_texts_BANG__A) Ctor() {}
//line :431:1
func (t *A_arbace_g2a_build_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.NN(jrt.File_Cast(entry__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_39, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(entry__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(tmp__3)).Mkdirs__Z()); var seq_715000312__4 any = /*line :431:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(texts__1); var chunk_715000313__5 any; var count_715000314__6 int64 = 0; var i_715000315__7 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z(i_715000315__7, count_715000314__6) { var vec__715000316__8 any = lang.Indexed_Cast(chunk_715000313__5).Nth_I__O(lang.RT_IntCast_J__I(i_715000315__7)); var n__9 any = lang.RT_Nth_O_I_O__O(vec__715000316__8, lang.RT_IntCast_J__I(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O(vec__715000316__8, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_715000312__4, chunk_715000313__5, count_715000314__6, i_715000315__7 = seq_715000312__4, chunk_715000313__5, count_715000314__6, lang.Numbers_Unchecked_inc_J__J(i_715000315__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000312__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_715000312__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000312__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000312__9); seq_715000312__4, chunk_715000313__5, count_715000314__6, i_715000315__7 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000312__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000319__10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000312__9); var n__11 any = lang.RT_Nth_O_I_O__O(vec__715000319__10, lang.RT_IntCast_J__I(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O(vec__715000319__10, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); seq_715000312__4, chunk_715000313__5, count_715000314__6, i_715000315__7 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000312__9), nil, 0, 0; continue L1 } } }
//line :431:1
		break L1 }; var tmp1 lang.IFn =





	lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()); var tmp2 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_41); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A_New(); var tmp6 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A_fn_class = fncls__69d; tmp6 = fncls__69d } else { tmp6 = fncls__69 }; tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_g2a_build_A_const_141.GetRawRoot__O()).Invoke_O__O(texts__1)))); if
	jrt.NN(jrt.File_Cast(tmp__3)).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { return lang.IFn_Cast(A_arbace_g2a_build_A_const_140.GetRawRoot__O()).Invoke_O__O(tmp__3) } }
//line :437:1
func A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A_New() *A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A) Ctor() {}
//line :437:1
func (t *A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A) Invoke_O_O__O(self, p1__715000311_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_43), jrt.RefArrayOf(jrt.Object_class, p1__715000311_SHARP___1, nil)).Ref() }


func A_arbace_g2a_build_print_module_A_New() *A_arbace_g2a_build_print_module_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_g2a_build_print_module_A) Ctor() {}
//line :440:1
func (t *A_arbace_g2a_build_print_module_A) Invoke_O_O_O_O_O__O(self, p__715000327__0, dir__1, out__2, p__715000328__3 any) any { var map__715000329__5 any = p__715000327__0; var map__715000329__6 any; if lang.ISeq_InstanceOf(map__715000329__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000329__5)) { map__715000329__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_111.GetRawRoot__O()).Invoke_O__O(map__715000329__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000329__5)) { map__715000329__6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000329__5) } else { lang.PersistentArrayMap_Init(); map__715000329__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000329__6 = map__715000329__5 }; var module__7 any = lang.RT_Get_O_O__O(map__715000329__6, A_arbace_g2a_build_A_const_121); var packages__8 any = lang.RT_Get_O_O__O(map__715000329__6, A_arbace_g2a_build_A_const_78); var golang__9 any = lang.RT_Get_O_O__O(map__715000329__6, A_arbace_g2a_build_A_const_123); var map__715000331__10 any = p__715000328__3; var map__715000331__11 any; if lang.ISeq_InstanceOf(map__715000331__10) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000331__10)) { map__715000331__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_111.GetRawRoot__O()).Invoke_O__O(map__715000331__10), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000331__10)) { map__715000331__11 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000331__10) } else { lang.PersistentArrayMap_Init(); map__715000331__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000331__11 = map__715000331__10 }; var layout__12 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_137); var line_file__13 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_138); var tests__14 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_142); var goos__15 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_143); var goroot__16 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_144); var goos_dir__17 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_145); var print_cache__18 any = lang.RT_Get_O_O__O(map__715000331__11, A_arbace_g2a_build_A_const_126);









	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(out__2)).Mkdirs__Z()); if
	lang.Util_Equiv_O_O__Z(module__7, Lit_97) { } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()); var tmp2 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_98); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100, nil, Lit_43, nil); var tmp4 *jrt.String
		if lang.Util_Equiv_O_O__Z(goos__15, Lit_27) {
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_43, nil); var tmp6 *lang.Keyword = A_arbace_g2a_build_A_const_46; var tmp7 any = tmp6.Invoke_O__O(A_arbace_g2a_build_A_const_105.GetRawRoot__O()); var tmp8 *lang.Keyword = A_arbace_g2a_build_A_const_112; var tmp9 any = tmp8.Invoke_O__O(A_arbace_g2a_build_A_const_105.GetRawRoot__O()); var tmp10 *jrt.String

			if jrt.A2g_Truth(goos_dir__17) {
				var tmp11 *lang.Keyword = A_arbace_g2a_build_A_const_46; var tmp12 *lang.Keyword = A_arbace_g2a_build_A_const_112; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, tmp11.Invoke_O__O(A_arbace_g2a_build_A_const_105.GetRawRoot__O()), nil, tmp12.Invoke_O__O(A_arbace_g2a_build_A_const_105.GetRawRoot__O()), nil, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(goos_dir__17))).GetAbsoluteFile__File()).GetPath__String().Ref(), nil)) } else {
//line :456:1
					tmp10 = nil }
//line :454:1
			tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp9, nil, tmp10.Ref())) } else {
//line :453:1
				tmp4 = nil }
//line :452:1
		tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__9, nil, tmp4.Ref())).Ref()) }; var tmp13 any; var and__1927000168__auto____19 bool =







	lang.Util_Equiv_O_O__Z(goos__15, Lit_27); if and__1927000168__auto____19 { tmp13 = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(goos_dir__17) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____19).Ref() }; if jrt.A2g_Truth(tmp13) {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_103), lang.IFn_Cast(A_arbace_g2a_build_A_const_146.GetRawRoot__O()).Invoke_O__O(goroot__16)) }; var tmp14 lang.IFn =
	lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()); var tmp16 any; if
	lang.Util_Equiv_O_O__Z(module__7, Lit_97) { tmp16 = nil } else { tmp16 = A_arbace_g2a_build_A_const_147 }; var tmp17 any = tmp16; var tmp18 lang.IFn = /*line :462:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_56.GetRawRoot__O()); var tmp19 any = A_arbace_g2a_build_A_const_43.GetRawRoot__O(); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_55.GetRawRoot__O()); var tmp21 any = A_arbace_g2a_build_print_module_fn__715000333_A_New_O_O_O_O_O_O(dir__1, out__2, tests__14, line_file__13, layout__12, print_cache__18); var tmp22 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000333_A_fn_class; if


	fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_g2a_build_print_module_fn__715000333_A_fn_class = fncls__74d; tmp22 = fncls__74d } else { tmp22 = fncls__74 }; return /*line :462:1*/ tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), packages__8)))) }


func A_arbace_g2a_build_print_module_fn__715000333_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_g2a_build_print_module_fn__715000333_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000333_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :465:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :465:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z(Lit_95, A_arbace_g2a_build_A_const_128.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_g2a_build_A_const_128.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__715000334__3_ any; var tmp2 any = A_arbace_g2a_build_A_const_137; var tmp3 any; var or__1927000174__auto____3 any = /*line :465:1*/t.F_layout; if

	jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.A2g_Truth(t.F_line_file) { tmp3 = A_arbace_g2a_build_A_const_148 } else { tmp3 = A_arbace_g2a_build_A_const_149 } }; G__715000334__3_ = /*line :465:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.A2g_Truth(t.F_line_file) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_A_const_138; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; opts__3 = tmp4.Invoke_O_O_O__O(G__715000334__3_, tmp5, tmp6.Ref()) } else {
//line :467:1
			opts__3 = G__715000334__3_ }; var tmp7 /*line :465:1*/*lang.Keyword = A_arbace_g2a_build_A_const_154; var test_files__4 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), tmp7.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1)))); var printable__5 any; var tmp8 any = A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A_New_O_O(test_files__4, t.F_tests); var tmp9 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A_fn_class; if
	fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A_fn_class = fncls__72d; tmp9 = fncls__72d } else { tmp9 = fncls__72 }; printable__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var host_id__6 any = /*line :465:1*/jrt.System_Getenv_String__String(Lit_106).Ref(); var entry__7 any; var tmp10 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.A2g_Truth(and__1927000168__auto____7) { tmp10 = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(host_id__6) } else { tmp10 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp10) { var k__7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O_O__O(host_id__6, pkg__1, t.F_dir, opts__3, t.F_tests); var tmp11 *jrt.Class = A_arbace_g2a_build_A_const_67; entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp11, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(t.F_print_cache)), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_129.GetRawRoot__O()).Invoke_O_O_O__O(k__7, A_arbace_g2a_build_A_const_133, A_arbace_g2a_build_A_const_155))), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.A2g_Truth(entry__7) { or__1927000174__auto____8 = lang.IFn_Cast(A_arbace_g2a_build_A_const_152.GetRawRoot__O()).Invoke_O__O(entry__7) } else { or__1927000174__auto____8 = nil }; if jrt.A2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_153.GetRawRoot__O()); var tmp13 any; var G__715000341__9_ any = lang.IFn_Cast(printable__5).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_157.GetRawRoot__O()).Invoke_O__O(pkg__1))
		if jrt.A2g_Truth(t.F_line_file) { tmp13 = lang.IFn_Cast(A_arbace_g2a_build_A_const_156.GetRawRoot__O()).Invoke_O__O(G__715000341__9_) } else { tmp13 = G__715000341__9_ }; t__9 = tmp12.Invoke_O_O__O(tmp13, opts__3)
		if jrt.A2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.NN(jrt.File_Cast(entry__7)).GetParentFile__File()).Mkdirs__Z())
			lang.IFn_Cast(A_arbace_g2a_build_A_const_158.GetRawRoot__O()).Invoke_O_O__O(entry__7, t__9) }
//line :477:1
		texts__8 = t__9 }; var declared__9 any; var tmp14 /*line :465:1*/*lang.Keyword = A_arbace_g2a_build_A_const_135; var temp__1927000414__auto____9 any = tmp14.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1)); if

















	jrt.A2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()); var tmp16 any
		if jrt.A2g_Truth(t.F_tests) { var tmp17 *lang.Keyword = A_arbace_g2a_build_A_const_154; tmp16 = tmp17.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1)) } else { tmp16 = nil }; declared__9 = tmp15.Invoke_O_O__O(fs__10, tmp16) } else {
//line :483:1
			declared__9 = nil }; var rel__10 any; var tmp18 any = /*line :465:1*/A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A_New_O(pkg__1); var tmp19 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A_fn_class; if
	fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A_fn_class = fncls__73d; tmp19 = fncls__73d } else { tmp19 = fncls__73 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var src__11 any = /*line :465:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_134.GetRawRoot__O()).Invoke_O__O(pkg__1); var tmp20 any; var and__1927000168__auto____12 any = declared__9; if





















	jrt.A2g_Truth(and__1927000168__auto____12) { tmp20 = lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), declared__9)), lang.IFn_Cast(A_arbace_g2a_build_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_141.GetRawRoot__O()).Invoke_O__O(texts__8))) } else { tmp20 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp20) {
		lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_108, nil, Lit_109, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(declared__9), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_141.GetRawRoot__O()).Invoke_O__O(texts__8))))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(pdir__2)).Mkdirs__Z()); var seq_715000344__12 any = /*line :465:1*/lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(texts__8); var chunk_715000345__13 any; var count_715000346__14 int64 = 0; var i_715000347__15 int64 = 0; L1: for {

























		if lang.Numbers_Lt_J_J__Z(i_715000347__15, count_715000346__14) { var vec__715000348__16 any = lang.Indexed_Cast(chunk_715000345__13).Nth_I__O(lang.RT_IntCast_J__I(i_715000347__15)); var n__17 any = lang.RT_Nth_O_I_O__O(vec__715000348__16, lang.RT_IntCast_J__I(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O(vec__715000348__16, lang.RT_IntCast_J__I(1), nil)
			if jrt.File_InstanceOf(text__18) {
				lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()).Invoke_O_O__O(text__18, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17))) } else {
					lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18) }
//line :491:1
			seq_715000344__12, chunk_715000345__13, count_715000346__14, i_715000347__15 = seq_715000344__12, chunk_715000345__13, count_715000346__14, lang.Numbers_Unchecked_inc_J__J(i_715000347__15); continue L1 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000344__12); if jrt.A2g_Truth(temp__1927000414__auto____16) { var seq_715000344__17 any = temp__1927000414__auto____16; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000344__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000344__17); seq_715000344__12, chunk_715000345__13, count_715000346__14, i_715000347__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000344__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__715000351__18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000344__17); var n__19 any = lang.RT_Nth_O_I_O__O(vec__715000351__18, lang.RT_IntCast_J__I(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O(vec__715000351__18, lang.RT_IntCast_J__I(1), nil)
				if jrt.File_InstanceOf(text__20) {
					lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()).Invoke_O_O__O(text__20, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19))) } else {
						lang.IFn_Cast(A_arbace_g2a_build_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20) }
//line :491:1
				seq_715000344__12, chunk_715000345__13, count_715000346__14, i_715000347__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000344__17), nil, 0, 0; continue L1 } } }
//line :465:1
		break L1 }; var tmp21 *lang.Keyword = A_arbace_g2a_build_A_const_160; var seq_715000354__12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(tmp21.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1))); var chunk_715000355__13 any; var count_715000356__14 int64 = 0; var i_715000357__15 int64 = 0; L2: for {





























			if lang.Numbers_Lt_J_J__Z(i_715000357__15, count_715000356__14) { var f__16 any = lang.Indexed_Cast(chunk_715000355__13).Nth_I__O(lang.RT_IntCast_J__I(i_715000357__15))
				lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__16))), jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__16))))
//line :495:1
				seq_715000354__12, chunk_715000355__13, count_715000356__14, i_715000357__15 = seq_715000354__12, chunk_715000355__13, count_715000356__14, lang.Numbers_Unchecked_inc_J__J(i_715000357__15); continue L2 } else { var temp__1927000414__auto____16_2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000354__12); if jrt.A2g_Truth(temp__1927000414__auto____16_2) { var seq_715000354__17 any = temp__1927000414__auto____16_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000354__17)) { var c__1927000678__auto____18_2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000354__17); seq_715000354__12, chunk_715000355__13, count_715000356__14, i_715000357__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000354__17), c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var f__18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000354__17)
					lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__18))), jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__18))))
//line :495:1
					seq_715000354__12, chunk_715000355__13, count_715000356__14, i_715000357__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000354__17), nil, 0, 0; continue L2 } } }
//line :465:1
			break L2 }; var tmp22 *lang.Keyword = A_arbace_g2a_build_A_const_161; var seq_715000358__12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1))); var chunk_715000359__13 any; var count_715000360__14 int64 = 0; var i_715000361__15 int64 = 0; L3: for {































				if lang.Numbers_Lt_J_J__Z(i_715000361__15, count_715000360__14) { var vec__715000362__16 any = lang.Indexed_Cast(chunk_715000359__13).Nth_I__O(lang.RT_IntCast_J__I(i_715000361__15)); var f__17 any = lang.RT_Nth_O_I_O__O(vec__715000362__16, lang.RT_IntCast_J__I(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O(vec__715000362__16, lang.RT_IntCast_J__I(1), nil); var from__19 any = jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__17)))

					if jrt.NN(jrt.File_Cast(from__19)).IsFile__Z() { } else {
						lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, from__19))).Ref()) }
					var tmp23 any; var and__1927000168__auto____20 any = h__18; if jrt.A2g_Truth(and__1927000168__auto____20) { tmp23 = lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_162.GetRawRoot__O()).Invoke_O__O(from__19), lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(h__18)) } else { tmp23 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp23) {
						lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil, Lit_112, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), nil, f__17, nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_162.GetRawRoot__O()).Invoke_O__O(from__19), nil, h__18)).Ref())
					}
					lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()).Invoke_O_O__O(from__19, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__17))))
//line :497:1
					seq_715000358__12, chunk_715000359__13, count_715000360__14, i_715000361__15 = seq_715000358__12, chunk_715000359__13, count_715000360__14, lang.Numbers_Unchecked_inc_J__J(i_715000361__15); continue L3 } else { var temp__1927000414__auto____16_3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000358__12); if jrt.A2g_Truth(temp__1927000414__auto____16_3) { var seq_715000358__17 any = temp__1927000414__auto____16_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000358__17)) { var c__1927000678__auto____18_3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000358__17); seq_715000358__12, chunk_715000359__13, count_715000360__14, i_715000361__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000358__17), c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__715000365__18 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000358__17); var f__19 any = lang.RT_Nth_O_I_O__O(vec__715000365__18, lang.RT_IntCast_J__I(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O(vec__715000365__18, lang.RT_IntCast_J__I(1), nil); var from__21 any = jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__19)))

						if jrt.NN(jrt.File_Cast(from__21)).IsFile__Z() { } else {
							lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, from__21))).Ref()) }
						var tmp24 any; var and__1927000168__auto____22 any = h__20; if jrt.A2g_Truth(and__1927000168__auto____22) { tmp24 = lang.IFn_Cast(A_arbace_g2a_build_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_162.GetRawRoot__O()).Invoke_O__O(from__21), lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(h__20)) } else { tmp24 = and__1927000168__auto____22 }; if jrt.A2g_Truth(tmp24) {
							lang.IFn_Cast(A_arbace_g2a_build_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil, Lit_112, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_46.Invoke_O__O(pkg__1), nil, f__19, nil, lang.IFn_Cast(A_arbace_g2a_build_A_const_162.GetRawRoot__O()).Invoke_O__O(from__21), nil, h__20)).Ref())
						}
						lang.IFn_Cast(A_arbace_g2a_build_A_const_159.GetRawRoot__O()).Invoke_O_O__O(from__21, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__19))))
//line :497:1
						seq_715000358__12, chunk_715000359__13, count_715000360__14, i_715000361__15 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000358__17), nil, 0, 0; continue L3 } } }
//line :465:1
				break L3 }; var tmp25 /*line :505:1*/*lang.Keyword = A_arbace_g2a_build_A_const_160; var tmp26 *lang.Keyword = A_arbace_g2a_build_A_const_161; return lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(rel__10, lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_141.GetRawRoot__O()).Invoke_O__O(texts__8), lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), tmp25.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1))), lang.IFn_Cast(A_arbace_g2a_build_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_29.GetRawRoot__O(), A_arbace_g2a_build_A_const_20.GetRawRoot__O()), tmp26.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(pkg__1))))) }
//line :466:1
func A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A_New_O_O(p0, p1 any) *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A{}; t.Ctor_O_O(p0, p1); return t }
//line :466:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A) Ctor_O_O(c__test_files, c__tests any) { t.F_test_files = c__test_files; t.F_tests = c__tests }
//line :466:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A) Invoke_O_O__O(self, p1__715000325_SHARP___1 any) any {



	if jrt.A2g_Truth(t.F_tests) { return p1__715000325_SHARP___1 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_135; var tmp3 any = A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A_New_O(t.F_test_files); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; return tmp1.Invoke_O_O_O__O(p1__715000325_SHARP___1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } }
//line :466:1
func A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A_New_O(p0 any) *A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A{}; t.Ctor_O(p0); return t }
//line :466:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :466:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A) Invoke_O_O__O(self, p1__715000326_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z(Lit_95, A_arbace_g2a_build_A_const_128.Invoke_O__O(t.F_pkg)) { return p1__715000326_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_128.Invoke_O__O(t.F_pkg), nil, p1__715000326_SHARP___1)).Ref() } }
//line :472:1
func A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A_New_O(p0 any) *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A{}; t.Ctor_O(p0); return t }
//line :472:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :472:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_150.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A_New_O(t.F_test_files); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :472:1
func A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A_New_O(p0 any) *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A{}; t.Ctor_O(p0); return t }
//line :472:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :472:1
func (t *A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); return lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_36.Invoke_O__O(f__1)))) }







































func A_arbace_g2a_build_delete_tree_A_New() *A_arbace_g2a_build_delete_tree_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_delete_tree_A{}; t.Ctor(); return t }
//line :512:1
func (t *A_arbace_g2a_build_delete_tree_A) Ctor() {}
//line :512:1
func (t *A_arbace_g2a_build_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.NN(jrt.File_Cast(f__0)).IsDirectory__Z() { var seq_715000370__2 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(f__0)).ListFiles__File1().Ref()); var chunk_715000371__3 any; var count_715000372__4 int64 = 0; var i_715000373__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_715000373__5, count_715000372__4) { var c__6 any = lang.Indexed_Cast(chunk_715000371__3).Nth_I__O(lang.RT_IntCast_J__I(i_715000373__5)); lang.IFn_Cast(A_arbace_g2a_build_A_const_140.GetRawRoot__O()).Invoke_O__O(c__6); seq_715000370__2, chunk_715000371__3, count_715000372__4, i_715000373__5 = seq_715000370__2, chunk_715000371__3, count_715000372__4, lang.Numbers_Unchecked_inc_J__J(i_715000373__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_715000370__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_715000370__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_715000370__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_715000370__7); seq_715000370__2, chunk_715000371__3, count_715000372__4, i_715000373__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_715000370__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_715000370__7); lang.IFn_Cast(A_arbace_g2a_build_A_const_140.GetRawRoot__O()).Invoke_O__O(c__8); seq_715000370__2, chunk_715000371__3, count_715000372__4, i_715000373__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_715000370__7), nil, 0, 0; continue L1 } } }
//line :513:1
		break L1
	} }
	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(f__0)).Delete__Z()).Ref()
}
func A_arbace_g2a_build_build_A_New() *A_arbace_g2a_build_build_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_build_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_g2a_build_build_A) Ctor() {}
//line :517:1
func (t *A_arbace_g2a_build_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__715000375__3 any) any { var map__715000376__5 any = p__715000375__3; var map__715000376__6 any; if lang.ISeq_InstanceOf(map__715000376__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(map__715000376__5)) { map__715000376__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_111.GetRawRoot__O()).Invoke_O__O(map__715000376__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(map__715000376__5)) { map__715000376__6 = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__715000376__5) } else { lang.PersistentArrayMap_Init(); map__715000376__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__715000376__6 = map__715000376__5 }; var opts__7 any = map__715000376__6; var work__8 any = lang.RT_Get_O_O__O(map__715000376__6, A_arbace_g2a_build_A_const_163); var goroot__9 any = lang.RT_Get_O_O__O(map__715000376__6, A_arbace_g2a_build_A_const_144); var prog__10 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, goroot__9, opts__7); var main__11 any = A_arbace_g2a_build_A_const_125.Invoke_O__O(prog__10); var tmp1 *lang.Keyword = A_arbace_g2a_build_A_const_164; var config__12 any = tmp1.Invoke_O__O(A_arbace_g2a_build_A_const_61.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z(work__8, nil); var work__14 any; if







	jrt.A2g_Truth(work__8) { work__14 = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(work__8))) } else {

		work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(Lit_26, jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_build_A_const_165.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_167, A_arbace_g2a_build_A_const_133), jrt.FileAttribute_class.ArrayClass())).ToFile__File().Ref() }; var tmp2 any; tmp16 := /*line :517:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_23)












			if jrt.NN(jrt.File_Cast(mod__17)).Exists__Z() { lang.IFn_Cast(A_arbace_g2a_build_A_const_140.GetRawRoot__O()).Invoke_O__O(mod__17) }
			lang.IFn_Cast(A_arbace_g2a_build_A_const_168.GetRawRoot__O()).Invoke_O_O_O_O__O(prog__10, dir__0, mod__17, opts__7)
//line :517:1
			var tags__18 any = A_arbace_g2a_build_A_const_166.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z(A_arbace_g2a_build_A_const_143.Invoke_O__O(opts__7), Lit_27); var cmd__20 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_43.GetRawRoot__O()); var tmp4 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_29, Lit_30, Lit_31); var tmp5 lang.IPersistentVector

















			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(tags__18)) { tmp5 = lang.Tuple_Create_O_O__IPersistentVector(Lit_32, lang.IFn_Cast(A_arbace_g2a_build_A_const_48.GetRawRoot__O()).Invoke_O_O__O(Lit_33, tags__18)) } else { tmp5 = nil }
//line :534:1
			var tmp6 any = tmp5; var tmp7 lang.IPersistentVector

			if tamago_QMARK___19 { tmp7 = lang.Tuple_Create_O_O__IPersistentVector(Lit_34, A_arbace_g2a_build_A_const_171.GetRawRoot__O()) } else { tmp7 = nil }
//line :534:1
			var tmp8 any = tmp7; var tmp9 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_g2a_build_A_const_169.Invoke_O__O(opts__7)


			if jrt.A2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; tmp9 = lang.Tuple_Create_O_O__IPersistentVector(Lit_35, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(o__21))).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp9 = nil }
//line :534:1
			var tmp10 any = tmp9; var tmp11 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_g2a_build_A_const_170.Invoke_O__O(opts__7)




			if jrt.A2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(f__21))).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp11 = nil }
//line :534:1
			cmd__20 = tmp3.Invoke_O_O_O_O_O_O__O(tmp4, tmp6, tmp8, tmp10, tmp11, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.NN(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File()).GetPath__String().Ref(), A_arbace_g2a_build_A_const_46.Invoke_O__O(main__11)))
//line :517:1
			var env__21 any; var G__715000381__21_ any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_108.GetRawRoot__O()); var tmp13 any; var or__1927000174__auto____21 any = A_arbace_g2a_build_A_const_143.Invoke_O__O(opts__7)
























			if jrt.A2g_Truth(or__1927000174__auto____21) { tmp13 = or__1927000174__auto____21 } else { tmp13 = Lit_37 }; G__715000381__21_ = tmp12.Invoke_O_O_O__O(goroot__9, arch__1, tmp13); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_build_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_172.Invoke_O__O(config__12))) {
				env__21 = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(G__715000381__21_, Lit_38, A_arbace_g2a_build_A_const_172.Invoke_O__O(config__12)) } else {
//line :542:1
					env__21 = G__715000381__21_ }
//line :517:1
			var vec__715000378__22 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_109.GetRawRoot__O()); var tmp15 *jrt.Boolean


























			jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; vec__715000378__22 = tmp14.Invoke_O_O_O_O__O(cmd__20, mod__17, env__21, tmp15.Ref())
//line :517:1
			var status__23 any = lang.RT_Nth_O_I_O__O(vec__715000378__22, lang.RT_IntCast_J__I(0), nil); tmp2 = status__23 }; return nil }(); if tmp_QMARK___13 {





























				lang.IFn_Cast(A_arbace_g2a_build_A_const_140.GetRawRoot__O()).Invoke_O__O(work__14) }; if /*line :517:1*/ tmp16 != nil { panic(tmp16) }; return tmp2 }































func A_arbace_g2a_build__main_A_New() *A_arbace_g2a_build__main_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_A{}; t.Ctor(); return t }
//line :549:1
func (t *A_arbace_g2a_build__main_A) Ctor() {}
//line :549:1
func (t *A_arbace_g2a_build__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.A2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :549:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_build_A_const_173, Lit_5, A_arbace_g2a_build_A_const_144, goroot__2)); L1: for { var G__715000383__6_ any = lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4)




		switch lang.Util_Hash_O__I(G__715000383__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_6) {











			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_build_A_const_121; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp1.Invoke_O_O_O__O(opts__5, tmp2, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 6: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_7) {









			var tmp3 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_build_A_const_174; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; as__4, opts__5 = tmp3, tmp4.Invoke_O_O_O__O(opts__5, tmp5, tmp6.Ref()); continue L1 }
//line :554:1
		case 8: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_8) {










			var tmp7 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_build_A_const_142; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; as__4, opts__5 = tmp7, tmp8.Invoke_O_O_O__O(opts__5, tmp9, tmp10.Ref()); continue L1 }
//line :554:1
		case 11: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_9) {






			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_build_A_const_163; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp11.Invoke_O_O_O__O(opts__5, tmp12, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 12: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_10) {




			var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_build_A_const_137; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp13.Invoke_O_O_O__O(opts__5, tmp14, lang.IFn_Cast(A_arbace_g2a_build_A_const_188.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4))); continue L1 }
//line :554:1
		case 26: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_11) {












			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp16 any = A_arbace_g2a_build_A_const_145; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp15.Invoke_O_O_O__O(opts__5, tmp16, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 30: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_12) {



			var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp18 any = A_arbace_g2a_build_A_const_175; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp17.Invoke_O_O_O__O(opts__5, tmp18, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 31: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_13) {
			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_build_A_const_173; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp19.Invoke_O_O_O__O(opts__5, tmp20, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 33: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_14) {





			var tmp21 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp23 any = A_arbace_g2a_build_A_const_138; var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; as__4, opts__5 = tmp21, tmp22.Invoke_O_O_O__O(opts__5, tmp23, tmp24.Ref()); continue L1 }
//line :554:1
		case 38: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_15) {

			var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp26 any = A_arbace_g2a_build_A_const_143; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp25.Invoke_O_O_O__O(opts__5, tmp26, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 40: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_16) {


			var tmp27 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_77.GetRawRoot__O()); var tmp29 any = A_arbace_g2a_build_A_const_120; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_189.GetRawRoot__O()); var tmp31 any = A_arbace_g2a_build_A_const_7.GetRawRoot__O(); var tmp32 *lang.PersistentVector; lang.PersistentVector_Init(); tmp32 = lang.PersistentVector_EMPTY; as__4, opts__5 = tmp27, tmp28.Invoke_O_O_O_O__O(opts__5, tmp29, tmp30.Invoke_O_O__O(tmp31, tmp32.Ref()), lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 43: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_17) {







			var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp34 any = A_arbace_g2a_build_A_const_169; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp33.Invoke_O_O_O__O(opts__5, tmp34, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 44: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_18) {













			var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp36 any = A_arbace_g2a_build_A_const_126; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp35.Invoke_O_O_O__O(opts__5, tmp36, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		case 59: if lang.Util_Equiv_O_O__Z(G__715000383__6_, Lit_19) {








			var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_62.GetRawRoot__O()); var tmp38 any = A_arbace_g2a_build_A_const_170; as__4, opts__5 = lang.IFn_Cast(A_arbace_g2a_build_A_const_186.GetRawRoot__O()).Invoke_O__O(as__4), tmp37.Invoke_O_O_O__O(opts__5, tmp38, lang.IFn_Cast(A_arbace_g2a_build_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :554:1
		default:
		}














		var tmp39 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_127.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4), Lit_20)); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_190); var and__1927000168__auto____9 any = tmp40.Invoke_O__O(A_arbace_g2a_build_A_const_173.Invoke_O__O(opts__5)); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp42 any = A_arbace_g2a_build_A_const_191; var and__1927000168__auto____10 any = tmp41.Invoke_O_O__O(tmp42, A_arbace_g2a_build_A_const_143.Invoke_O__O(opts__5)); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_27.GetRawRoot__O()); var tmp44 any = A_arbace_g2a_build_A_const_192; var and__1927000168__auto____11 any = tmp43.Invoke_O_O__O(tmp44, A_arbace_g2a_build_A_const_137.Invoke_O__O(opts__5)); if jrt.A2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_g2a_build_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_174.Invoke_O__O(opts__5))



			if jrt.A2g_Truth(or__1927000174__auto____12) { tmp39 = or__1927000174__auto____12 } else { tmp39 = A_arbace_g2a_build_A_const_163.Invoke_O__O(opts__5) } } else {
//line :570:1
				tmp39 = and__1927000168__auto____11 } } else { tmp39 = and__1927000168__auto____10 } } else { tmp39 = and__1927000168__auto____9 } } else { tmp39 = and__1927000168__auto____8 } } else { tmp39 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(tmp39) { } else {




					var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_72.GetRawRoot__O()); var tmp46 any = A_arbace_g2a_build_A_const_184; lang.IFn_Cast(A_arbace_g2a_build_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp45.Invoke_O_O__O(tmp46, A_arbace_g2a_build_A_const_185.Get__O())); var tmp47 any = A_arbace_g2a_build__main_fn__715000384_A_New_O(usage__3); var tmp48 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_g2a_build__main_fn__715000384_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_g2a_build__main_fn__715000384_A_fn_class = fncls__78d; tmp48 = fncls__78d } else { tmp48 = fncls__78 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil).Invoke__O()
					jrt.System_Exit_I__V(lang.RT_IntCast_J__I(2)) }
//line :554:1
		var dir__7 any = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4))); var status__8 any; var tmp49 any = A_arbace_g2a_build__main_fn__715000386_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp50 *jrt.Class
		var fncls__77 /*line :554:1*/*jrt.Class = A_arbace_g2a_build__main_fn__715000386_A_fn_class























		if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_g2a_build__main_fn__715000386_A_fn_class = fncls__77d; tmp50 = fncls__77d } else { tmp50 = fncls__77 }; status__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil).Invoke__O()















		lang.IFn_Cast(A_arbace_g2a_build_A_const_193.GetRawRoot__O()).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I(status__8)); return nil } }; /*line :549:1*/panic("a2g: unreachable") }

























func A_arbace_g2a_build__main_fn__715000384_A_New_O(p0 any) *A_arbace_g2a_build__main_fn__715000384_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_fn__715000384_A{}; t.Ctor_O(p0); return t }
//line :575:1
func (t *A_arbace_g2a_build__main_fn__715000384_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :575:1
func (t *A_arbace_g2a_build__main_fn__715000384_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_183.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_build_A_const_70.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_g2a_build__main_fn__715000386_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_build__main_fn__715000386_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_fn__715000386_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :578:1
func (t *A_arbace_g2a_build__main_fn__715000386_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :578:1
func (t *A_arbace_g2a_build__main_fn__715000386_A) Invoke_O__O(self any) any { var tmp1 any; tmp27 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.A2g_Truth(A_arbace_g2a_build_A_const_174.Invoke_O__O(t.F_opts)) { var prog__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_130.GetRawRoot__O()); var tmp3 any = t.F_dir; var tmp4 any; var t_ any = t.F_goroot
											t.F_goroot = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_g2a_build_A_const_119; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; var tmp8 any = tmp7.Ref(); var tmp9 any = A_arbace_g2a_build_A_const_121; var tmp10 any = A_arbace_g2a_build_A_const_121.Invoke_O__O(t.F_opts); var tmp11 any = A_arbace_g2a_build_A_const_120; prog__3 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp10, tmp11, A_arbace_g2a_build_A_const_120.Invoke_O__O(t.F_opts))))
//line :579:1
		var mod__4 any = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_build_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_build_A_const_163.Invoke_O__O(t.F_opts)))), Lit_23)


		if jrt.NN(jrt.File_Cast(mod__4)).Exists__Z() { lang.IFn_Cast(A_arbace_g2a_build_A_const_140.GetRawRoot__O()).Invoke_O__O(mod__4) }
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_168.GetRawRoot__O()); var tmp13 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp13 = t__2; var tmp14 any = tmp13; var tmp15 any; var t__3 any = t.F_opts; t.F_opts = nil; tmp15 = t__3; tmp12.Invoke_O_O_O_O__O(prog__3, tmp14, mod__4, tmp15)
//line :579:1
		tmp1 = A_arbace_g2a_build_A_const_133 } else { var prog_main__3 any





			if jrt.A2g_Truth(A_arbace_g2a_build_A_const_175.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp16 *lang.Keyword = A_arbace_g2a_build_A_const_125; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_130.GetRawRoot__O()); var tmp18 any = t.F_dir; var tmp19 any; var t__4 any = t.F_goroot; t.F_goroot = nil; tmp19 = t__4; prog_main__3 = tmp16.Invoke_O__O(tmp17.Invoke_O_O_O__O(tmp18, tmp19, t.F_opts)) }
//line :579:1
			var out__4 any; var tmp20 *jrt.Class = A_arbace_g2a_build_A_const_67; var tmp21 any; var or__1927000174__auto____4 any = A_arbace_g2a_build_A_const_175.Invoke_O__O(t.F_opts)






			if jrt.A2g_Truth(or__1927000174__auto____4) { tmp21 = or__1927000174__auto____4 } else {
				tmp21 = lang.IFn_Cast(A_arbace_g2a_build_A_const_176.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_178.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_build_A_const_46.Invoke_O__O(prog_main__3), A_arbace_g2a_build_A_const_179)) }
//line :579:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp21))








			var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_177.GetRawRoot__O()); var tmp23 any; var t__5 any = t.F_dir; t.F_dir = nil; tmp23 = t__5; var tmp24 any = tmp23; var tmp25 any = A_arbace_g2a_build_A_const_173.Invoke_O__O(t.F_opts); var tmp26 any; var t__6 any = t.F_opts; t.F_opts = nil; tmp26 = t__6; tmp1 = tmp22.Invoke_O_O_O_O__O(tmp24, tmp25, out__4, tmp26) }
//line :578:1
	return nil }(); if tmp27 != nil { if lang.ExceptionInfo_InstanceOf(tmp27) { var e__3 *lang.ExceptionInfo = lang.ExceptionInfo_Cast(tmp27)
		var tmp28 /*line :578:1*/*lang.Keyword = A_arbace_g2a_build_A_const_180











		if jrt.A2g_Truth(tmp28.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_build_A_const_181.GetRawRoot__O()).Invoke_O__O(e__3.Ref()))) {
			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_72.GetRawRoot__O()); var tmp30 any = A_arbace_g2a_build_A_const_184; lang.IFn_Cast(A_arbace_g2a_build_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O_O__O(tmp30, A_arbace_g2a_build_A_const_185.Get__O())); var tmp31 any = A_arbace_g2a_build__main_fn__715000386_fn__715000387_A_New_O(e__3.Ref()); var tmp32 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_g2a_build__main_fn__715000386_fn__715000387_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_g2a_build__main_fn__715000386_fn__715000387_A_fn_class = fncls__76d; tmp32 = fncls__76d } else { tmp32 = fncls__76 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O()
//line :590:1
			tmp1 = A_arbace_g2a_build_A_const_182 } else { panic(jrt.Thrown(Up_ExceptionInfo_Throwable(e__3))) } } else {
//line :578:1
				panic(tmp27) } }; return tmp1 }












func A_arbace_g2a_build__main_fn__715000386_fn__715000387_A_New_O(p0 any) *A_arbace_g2a_build__main_fn__715000386_fn__715000387_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build__main_fn__715000386_fn__715000387_A{}; t.Ctor_O(p0); return t }
//line :591:1
func (t *A_arbace_g2a_build__main_fn__715000386_fn__715000387_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :591:1
func (t *A_arbace_g2a_build__main_fn__715000386_fn__715000387_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_build_A_const_183.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); lang.IFn_Cast(A_arbace_g2a_build_A_const_70.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }















































































































































type A_arbace_g2a_build_A struct{ jrt.Object }

var A_arbace_g2a_build_A_const_pool *jrt.RefArray

var A_arbace_g2a_build_A_const_0 *lang.Var

var A_arbace_g2a_build_A_const_1 *lang.Var

var A_arbace_g2a_build_A_const_2 any

var A_arbace_g2a_build_A_const_3 any

var A_arbace_g2a_build_A_const_4 any

var A_arbace_g2a_build_A_const_5 *lang.Var

var A_arbace_g2a_build_A_const_6 *lang.Var

var A_arbace_g2a_build_A_const_7 *lang.Var

var A_arbace_g2a_build_A_const_8 any

var A_arbace_g2a_build_A_const_9 *lang.Var

var A_arbace_g2a_build_A_const_10 *lang.Var

var A_arbace_g2a_build_A_const_11 *lang.Var

var A_arbace_g2a_build_A_const_12 any

var A_arbace_g2a_build_A_const_13 *lang.Keyword

var A_arbace_g2a_build_A_const_14 *lang.Var

var A_arbace_g2a_build_A_const_15 *lang.Var

var A_arbace_g2a_build_A_const_16 *lang.Var

var A_arbace_g2a_build_A_const_17 *lang.Var

var A_arbace_g2a_build_A_const_18 *lang.Var

var A_arbace_g2a_build_A_const_19 *lang.Var

var A_arbace_g2a_build_A_const_20 *lang.Var

var A_arbace_g2a_build_A_const_21 *lang.Var

var A_arbace_g2a_build_A_const_22 *lang.Var

var A_arbace_g2a_build_A_const_23 *lang.Var

var A_arbace_g2a_build_A_const_24 any

var A_arbace_g2a_build_A_const_25 *lang.Var

var A_arbace_g2a_build_A_const_26 *lang.Var

var A_arbace_g2a_build_A_const_27 *lang.Var

var A_arbace_g2a_build_A_const_28 *lang.Var

var A_arbace_g2a_build_A_const_29 *lang.Var

var A_arbace_g2a_build_A_const_30 *lang.Var

var A_arbace_g2a_build_A_const_31 *lang.Var

var A_arbace_g2a_build_A_const_32 *lang.Var

var A_arbace_g2a_build_A_const_33 *lang.Var

var A_arbace_g2a_build_A_const_34 *lang.Var

var A_arbace_g2a_build_A_const_35 *lang.Var

var A_arbace_g2a_build_A_const_36 *lang.Keyword

var A_arbace_g2a_build_A_const_37 *lang.Var

var A_arbace_g2a_build_A_const_38 *lang.Var

var A_arbace_g2a_build_A_const_39 *lang.Var

var A_arbace_g2a_build_A_const_40 *lang.Var

var A_arbace_g2a_build_A_const_41 *lang.Var

var A_arbace_g2a_build_A_const_42 *lang.Var

var A_arbace_g2a_build_A_const_43 *lang.Var

var A_arbace_g2a_build_A_const_44 *lang.Var

var A_arbace_g2a_build_A_const_45 *lang.Var

var A_arbace_g2a_build_A_const_46 *lang.Keyword

var A_arbace_g2a_build_A_const_47 *lang.Var

var A_arbace_g2a_build_A_const_48 *lang.Var

var A_arbace_g2a_build_A_const_49 *lang.Var

var A_arbace_g2a_build_A_const_50 *lang.Keyword

var A_arbace_g2a_build_A_const_51 *lang.Var

var A_arbace_g2a_build_A_const_52 *lang.Var

var A_arbace_g2a_build_A_const_53 *lang.Var

var A_arbace_g2a_build_A_const_54 *lang.Var

var A_arbace_g2a_build_A_const_55 *lang.Var

var A_arbace_g2a_build_A_const_56 *lang.Var

var A_arbace_g2a_build_A_const_57 *lang.Var

var A_arbace_g2a_build_A_const_58 *lang.Var

var A_arbace_g2a_build_A_const_59 *lang.Var

var A_arbace_g2a_build_A_const_60 *lang.Var

var A_arbace_g2a_build_A_const_61 *lang.Keyword

var A_arbace_g2a_build_A_const_62 *lang.Var

var A_arbace_g2a_build_A_const_63 *lang.Var

var A_arbace_g2a_build_A_const_64 *lang.Var

var A_arbace_g2a_build_A_const_65 *lang.Var

var A_arbace_g2a_build_A_const_66 *lang.Keyword

var A_arbace_g2a_build_A_const_67 *jrt.Class

var A_arbace_g2a_build_A_const_68 *lang.Var

var A_arbace_g2a_build_A_const_69 *lang.Var

var A_arbace_g2a_build_A_const_70 *lang.Var

var A_arbace_g2a_build_A_const_71 *lang.Var

var A_arbace_g2a_build_A_const_72 *lang.Var

var A_arbace_g2a_build_A_const_73 *lang.Var

var A_arbace_g2a_build_A_const_74 *lang.Var

var A_arbace_g2a_build_A_const_75 *lang.Var

var A_arbace_g2a_build_A_const_76 *lang.Var

var A_arbace_g2a_build_A_const_77 *lang.Var

var A_arbace_g2a_build_A_const_78 *lang.Keyword

var A_arbace_g2a_build_A_const_79 *lang.Var

var A_arbace_g2a_build_A_const_80 *lang.Var

var A_arbace_g2a_build_A_const_81 *lang.Var

var A_arbace_g2a_build_A_const_82 *lang.Keyword

var A_arbace_g2a_build_A_const_83 *lang.Var

var A_arbace_g2a_build_A_const_84 *lang.Var

var A_arbace_g2a_build_A_const_85 *lang.Var

var A_arbace_g2a_build_A_const_86 *lang.Var

var A_arbace_g2a_build_A_const_87 *lang.Var

var A_arbace_g2a_build_A_const_88 *lang.Var

var A_arbace_g2a_build_A_const_89 *lang.Var

var A_arbace_g2a_build_A_const_90 *lang.Keyword

var A_arbace_g2a_build_A_const_91 *lang.Var

var A_arbace_g2a_build_A_const_92 *lang.Var

var A_arbace_g2a_build_A_const_93 *lang.Var

var A_arbace_g2a_build_A_const_94 *lang.Var

var A_arbace_g2a_build_A_const_95 *lang.Var

var A_arbace_g2a_build_A_const_96 *lang.Keyword

var A_arbace_g2a_build_A_const_97 *lang.Var

var A_arbace_g2a_build_A_const_98 *lang.Var

var A_arbace_g2a_build_A_const_99 *lang.Var

var A_arbace_g2a_build_A_const_100 any

var A_arbace_g2a_build_A_const_101 any

var A_arbace_g2a_build_A_const_102 any

var A_arbace_g2a_build_A_const_103 any

var A_arbace_g2a_build_A_const_104 *lang.Var

var A_arbace_g2a_build_A_const_105 *lang.Var

var A_arbace_g2a_build_A_const_106 any

var A_arbace_g2a_build_A_const_107 any

var A_arbace_g2a_build_A_const_108 *lang.Var

var A_arbace_g2a_build_A_const_109 *lang.Var

var A_arbace_g2a_build_A_const_110 *lang.Var

var A_arbace_g2a_build_A_const_111 *lang.Var

var A_arbace_g2a_build_A_const_112 *lang.Keyword

var A_arbace_g2a_build_A_const_113 *lang.Keyword

var A_arbace_g2a_build_A_const_114 *lang.Keyword

var A_arbace_g2a_build_A_const_115 *lang.Var

var A_arbace_g2a_build_A_const_116 *lang.Var

var A_arbace_g2a_build_A_const_117 *lang.Var

var A_arbace_g2a_build_A_const_118 any

var A_arbace_g2a_build_A_const_119 *lang.Keyword

var A_arbace_g2a_build_A_const_120 *lang.Keyword

var A_arbace_g2a_build_A_const_121 *lang.Keyword

var A_arbace_g2a_build_A_const_122 *lang.Var

var A_arbace_g2a_build_A_const_123 *lang.Keyword

var A_arbace_g2a_build_A_const_124 *lang.Var

var A_arbace_g2a_build_A_const_125 *lang.Keyword

var A_arbace_g2a_build_A_const_126 *lang.Keyword

var A_arbace_g2a_build_A_const_127 *lang.Var

var A_arbace_g2a_build_A_const_128 *lang.Keyword

var A_arbace_g2a_build_A_const_129 *lang.Var

var A_arbace_g2a_build_A_const_130 *lang.Var

var A_arbace_g2a_build_A_const_131 *lang.Var

var A_arbace_g2a_build_A_const_132 *jrt.Class

var A_arbace_g2a_build_A_const_133 any

var A_arbace_g2a_build_A_const_134 *lang.Var

var A_arbace_g2a_build_A_const_135 *lang.Keyword

var A_arbace_g2a_build_A_const_136 *lang.Keyword

var A_arbace_g2a_build_A_const_137 *lang.Keyword

var A_arbace_g2a_build_A_const_138 *lang.Keyword

var A_arbace_g2a_build_A_const_139 *lang.Var

var A_arbace_g2a_build_A_const_140 *lang.Var

var A_arbace_g2a_build_A_const_141 *lang.Var

var A_arbace_g2a_build_A_const_142 *lang.Keyword

var A_arbace_g2a_build_A_const_143 *lang.Keyword

var A_arbace_g2a_build_A_const_144 *lang.Keyword

var A_arbace_g2a_build_A_const_145 *lang.Keyword

var A_arbace_g2a_build_A_const_146 *lang.Var

var A_arbace_g2a_build_A_const_147 any

var A_arbace_g2a_build_A_const_148 *lang.Keyword

var A_arbace_g2a_build_A_const_149 *lang.Keyword

var A_arbace_g2a_build_A_const_150 *lang.Var

var A_arbace_g2a_build_A_const_151 *lang.Var

var A_arbace_g2a_build_A_const_152 *lang.Var

var A_arbace_g2a_build_A_const_153 *lang.Var

var A_arbace_g2a_build_A_const_154 *lang.Keyword

var A_arbace_g2a_build_A_const_155 any

var A_arbace_g2a_build_A_const_156 *lang.Var

var A_arbace_g2a_build_A_const_157 *lang.Var

var A_arbace_g2a_build_A_const_158 *lang.Var

var A_arbace_g2a_build_A_const_159 *lang.Var

var A_arbace_g2a_build_A_const_160 *lang.Keyword

var A_arbace_g2a_build_A_const_161 *lang.Keyword

var A_arbace_g2a_build_A_const_162 *lang.Var

var A_arbace_g2a_build_A_const_163 *lang.Keyword

var A_arbace_g2a_build_A_const_164 *lang.Keyword

var A_arbace_g2a_build_A_const_165 *lang.Var

var A_arbace_g2a_build_A_const_166 *lang.Keyword

var A_arbace_g2a_build_A_const_167 *jrt.Class

var A_arbace_g2a_build_A_const_168 *lang.Var

var A_arbace_g2a_build_A_const_169 *lang.Keyword

var A_arbace_g2a_build_A_const_170 *lang.Keyword

var A_arbace_g2a_build_A_const_171 *lang.Var

var A_arbace_g2a_build_A_const_172 *lang.Keyword

var A_arbace_g2a_build_A_const_173 *lang.Keyword

var A_arbace_g2a_build_A_const_174 *lang.Keyword

var A_arbace_g2a_build_A_const_175 *lang.Keyword

var A_arbace_g2a_build_A_const_176 *lang.Var

var A_arbace_g2a_build_A_const_177 *lang.Var

var A_arbace_g2a_build_A_const_178 *lang.Var

var A_arbace_g2a_build_A_const_179 any

var A_arbace_g2a_build_A_const_180 *lang.Keyword

var A_arbace_g2a_build_A_const_181 *lang.Var

var A_arbace_g2a_build_A_const_182 any

var A_arbace_g2a_build_A_const_183 *lang.Var

var A_arbace_g2a_build_A_const_184 *lang.Var

var A_arbace_g2a_build_A_const_185 *lang.Var

var A_arbace_g2a_build_A_const_186 *lang.Var

var A_arbace_g2a_build_A_const_187 *lang.Var

var A_arbace_g2a_build_A_const_188 *lang.Var

var A_arbace_g2a_build_A_const_189 *lang.Var

var A_arbace_g2a_build_A_const_190 any

var A_arbace_g2a_build_A_const_191 any

var A_arbace_g2a_build_A_const_192 any

var A_arbace_g2a_build_A_const_193 *lang.Var

var A_arbace_g2a_build_A_init jrt.ClassInit

func A_arbace_g2a_build_A_Init() { if !A_arbace_g2a_build_A_init.Done() { A_arbace_g2a_build_A_init.Run(A_arbace_g2a_build_A_clinit) } }

func A_arbace_g2a_build_A_clinit() { A_arbace_g2a_build_A_clinit_p0(); A_arbace_g2a_build_A_clinit_p1(); A_arbace_g2a_build_A_clinit_p2(); A_arbace_g2a_build_A_clinit_p3(); A_arbace_g2a_build_A_clinit_p4(); A_arbace_g2a_build_A_clinit_p5(); A_arbace_g2a_build_A_clinit_p6(); A_arbace_g2a_build_A_clinit_p7(); A_arbace_g2a_build_A_clinit_p8(); A_arbace_g2a_build_A_clinit_p9(); A_arbace_g2a_build_A_clinit_p10(); A_arbace_g2a_build_A_clinit_p11(); A_arbace_g2a_build_A_clinit_p12(); A_arbace_g2a_build_A_clinit_p13(); A_arbace_g2a_build_A_clinit_p14(); A_arbace_g2a_build_A_clinit_p15() }

func A_arbace_g2a_build_A_clinit_p0() { A_arbace_g2a_build_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 245); A_arbace_g2a_build_A_const_0 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[51]); A_arbace_g2a_build_A_const_1 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[52]); A_arbace_g2a_build_A_const_2 = A_arbace_g2a_build_A_const_pool.A[53]; A_arbace_g2a_build_A_const_3 = A_arbace_g2a_build_A_const_pool.A[54]; A_arbace_g2a_build_A_const_4 = A_arbace_g2a_build_A_const_pool.A[55]; A_arbace_g2a_build_A_const_5 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[56]); A_arbace_g2a_build_A_const_6 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[57]); A_arbace_g2a_build_A_const_7 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[58]); A_arbace_g2a_build_A_const_8 = A_arbace_g2a_build_A_const_pool.A[59]; A_arbace_g2a_build_A_const_9 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[60]); A_arbace_g2a_build_A_const_10 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[61]); A_arbace_g2a_build_A_const_11 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[62]) }

func A_arbace_g2a_build_A_clinit_p1() { A_arbace_g2a_build_A_const_12 = A_arbace_g2a_build_A_const_pool.A[63]; A_arbace_g2a_build_A_const_13 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[64]); A_arbace_g2a_build_A_const_14 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[65]); A_arbace_g2a_build_A_const_15 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[66]); A_arbace_g2a_build_A_const_16 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[67]); A_arbace_g2a_build_A_const_17 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[68]); A_arbace_g2a_build_A_const_18 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[69]); A_arbace_g2a_build_A_const_19 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[70]); A_arbace_g2a_build_A_const_20 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[71]); A_arbace_g2a_build_A_const_21 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[72]); A_arbace_g2a_build_A_const_22 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[73]); A_arbace_g2a_build_A_const_23 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[74]) }

func A_arbace_g2a_build_A_clinit_p2() { A_arbace_g2a_build_A_const_24 = A_arbace_g2a_build_A_const_pool.A[75]; A_arbace_g2a_build_A_const_25 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[76]); A_arbace_g2a_build_A_const_26 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[77]); A_arbace_g2a_build_A_const_27 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[78]); A_arbace_g2a_build_A_const_28 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[79]); A_arbace_g2a_build_A_const_29 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[80]); A_arbace_g2a_build_A_const_30 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[81]); A_arbace_g2a_build_A_const_31 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[82]); A_arbace_g2a_build_A_const_32 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[83]); A_arbace_g2a_build_A_const_33 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[84]); A_arbace_g2a_build_A_const_34 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[85]); A_arbace_g2a_build_A_const_35 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[86]) }

func A_arbace_g2a_build_A_clinit_p3() { A_arbace_g2a_build_A_const_36 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[87]); A_arbace_g2a_build_A_const_37 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[88]); A_arbace_g2a_build_A_const_38 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[89]); A_arbace_g2a_build_A_const_39 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[90]); A_arbace_g2a_build_A_const_40 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[91]); A_arbace_g2a_build_A_const_41 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[92]); A_arbace_g2a_build_A_const_42 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[93]); A_arbace_g2a_build_A_const_43 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[94]); A_arbace_g2a_build_A_const_44 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[95]); A_arbace_g2a_build_A_const_45 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[96]); A_arbace_g2a_build_A_const_46 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[97]); A_arbace_g2a_build_A_const_47 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[98]) }

func A_arbace_g2a_build_A_clinit_p4() { A_arbace_g2a_build_A_const_48 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[99]); A_arbace_g2a_build_A_const_49 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[100]); A_arbace_g2a_build_A_const_50 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[101]); A_arbace_g2a_build_A_const_51 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[102]); A_arbace_g2a_build_A_const_52 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[103]); A_arbace_g2a_build_A_const_53 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[104]); A_arbace_g2a_build_A_const_54 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[105]); A_arbace_g2a_build_A_const_55 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[106]); A_arbace_g2a_build_A_const_56 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[107]); A_arbace_g2a_build_A_const_57 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[108]); A_arbace_g2a_build_A_const_58 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[109]); A_arbace_g2a_build_A_const_59 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[110]) }

func A_arbace_g2a_build_A_clinit_p5() { A_arbace_g2a_build_A_const_60 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[111]); A_arbace_g2a_build_A_const_61 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[112]); A_arbace_g2a_build_A_const_62 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[113]); A_arbace_g2a_build_A_const_63 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[114]); A_arbace_g2a_build_A_const_64 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[115]); A_arbace_g2a_build_A_const_65 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[116]); A_arbace_g2a_build_A_const_66 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[117]); A_arbace_g2a_build_A_const_67 = jrt.Class_Cast(A_arbace_g2a_build_A_const_pool.A[118]); A_arbace_g2a_build_A_const_68 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[119]); A_arbace_g2a_build_A_const_69 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[120]); A_arbace_g2a_build_A_const_70 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[121]); A_arbace_g2a_build_A_const_71 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[122]) }

func A_arbace_g2a_build_A_clinit_p6() { A_arbace_g2a_build_A_const_72 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[123]); A_arbace_g2a_build_A_const_73 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[124]); A_arbace_g2a_build_A_const_74 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[125]); A_arbace_g2a_build_A_const_75 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[126]); A_arbace_g2a_build_A_const_76 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[127]); A_arbace_g2a_build_A_const_77 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[128]); A_arbace_g2a_build_A_const_78 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[129]); A_arbace_g2a_build_A_const_79 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[130]); A_arbace_g2a_build_A_const_80 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[131]); A_arbace_g2a_build_A_const_81 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[132]); A_arbace_g2a_build_A_const_82 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[133]); A_arbace_g2a_build_A_const_83 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[134]) }

func A_arbace_g2a_build_A_clinit_p7() { A_arbace_g2a_build_A_const_84 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[135]); A_arbace_g2a_build_A_const_85 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[136]); A_arbace_g2a_build_A_const_86 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[137]); A_arbace_g2a_build_A_const_87 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[138]); A_arbace_g2a_build_A_const_88 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[139]); A_arbace_g2a_build_A_const_89 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[140]); A_arbace_g2a_build_A_const_90 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[141]); A_arbace_g2a_build_A_const_91 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[142]); A_arbace_g2a_build_A_const_92 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[143]); A_arbace_g2a_build_A_const_93 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[144]); A_arbace_g2a_build_A_const_94 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[145]); A_arbace_g2a_build_A_const_95 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[146]) }

func A_arbace_g2a_build_A_clinit_p8() { A_arbace_g2a_build_A_const_96 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[147]); A_arbace_g2a_build_A_const_97 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[148]); A_arbace_g2a_build_A_const_98 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[149]); A_arbace_g2a_build_A_const_99 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[150]); A_arbace_g2a_build_A_const_100 = A_arbace_g2a_build_A_const_pool.A[151]; A_arbace_g2a_build_A_const_101 = A_arbace_g2a_build_A_const_pool.A[152]; A_arbace_g2a_build_A_const_102 = A_arbace_g2a_build_A_const_pool.A[153]; A_arbace_g2a_build_A_const_103 = A_arbace_g2a_build_A_const_pool.A[154]; A_arbace_g2a_build_A_const_104 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[155]); A_arbace_g2a_build_A_const_105 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[156]); A_arbace_g2a_build_A_const_106 = A_arbace_g2a_build_A_const_pool.A[157]; A_arbace_g2a_build_A_const_107 = A_arbace_g2a_build_A_const_pool.A[158]; A_arbace_g2a_build_A_const_108 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[159]) }

func A_arbace_g2a_build_A_clinit_p9() { A_arbace_g2a_build_A_const_109 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[160]); A_arbace_g2a_build_A_const_110 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[161]); A_arbace_g2a_build_A_const_111 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[162]); A_arbace_g2a_build_A_const_112 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[163]); A_arbace_g2a_build_A_const_113 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[164]); A_arbace_g2a_build_A_const_114 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[165]); A_arbace_g2a_build_A_const_115 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[166]); A_arbace_g2a_build_A_const_116 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[167]); A_arbace_g2a_build_A_const_117 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[168]); A_arbace_g2a_build_A_const_118 = A_arbace_g2a_build_A_const_pool.A[169]; A_arbace_g2a_build_A_const_119 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[170]); A_arbace_g2a_build_A_const_120 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[171]) }

func A_arbace_g2a_build_A_clinit_p10() { A_arbace_g2a_build_A_const_121 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[172]); A_arbace_g2a_build_A_const_122 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[173]); A_arbace_g2a_build_A_const_123 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[174]); A_arbace_g2a_build_A_const_124 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[175]); A_arbace_g2a_build_A_const_125 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[176]); A_arbace_g2a_build_A_const_126 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[177]); A_arbace_g2a_build_A_const_127 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[178]); A_arbace_g2a_build_A_const_128 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[179]); A_arbace_g2a_build_A_const_129 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[180]); A_arbace_g2a_build_A_const_130 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[181]); A_arbace_g2a_build_A_const_131 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[182]); A_arbace_g2a_build_A_const_132 = jrt.Class_Cast(A_arbace_g2a_build_A_const_pool.A[183]) }

func A_arbace_g2a_build_A_clinit_p11() { A_arbace_g2a_build_A_const_133 = A_arbace_g2a_build_A_const_pool.A[184]; A_arbace_g2a_build_A_const_134 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[185]); A_arbace_g2a_build_A_const_135 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[186]); A_arbace_g2a_build_A_const_136 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[187]); A_arbace_g2a_build_A_const_137 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[188]); A_arbace_g2a_build_A_const_138 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[189]); A_arbace_g2a_build_A_const_139 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[190]); A_arbace_g2a_build_A_const_140 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[191]); A_arbace_g2a_build_A_const_141 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[192]); A_arbace_g2a_build_A_const_142 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[193]); A_arbace_g2a_build_A_const_143 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[194]); A_arbace_g2a_build_A_const_144 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[195]) }

func A_arbace_g2a_build_A_clinit_p12() { A_arbace_g2a_build_A_const_145 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[196]); A_arbace_g2a_build_A_const_146 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[197]); A_arbace_g2a_build_A_const_147 = A_arbace_g2a_build_A_const_pool.A[198]; A_arbace_g2a_build_A_const_148 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[199]); A_arbace_g2a_build_A_const_149 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[200]); A_arbace_g2a_build_A_const_150 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[201]); A_arbace_g2a_build_A_const_151 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[202]); A_arbace_g2a_build_A_const_152 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[203]); A_arbace_g2a_build_A_const_153 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[204]); A_arbace_g2a_build_A_const_154 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[205]); A_arbace_g2a_build_A_const_155 = A_arbace_g2a_build_A_const_pool.A[206]; A_arbace_g2a_build_A_const_156 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[207]) }

func A_arbace_g2a_build_A_clinit_p13() { A_arbace_g2a_build_A_const_157 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[208]); A_arbace_g2a_build_A_const_158 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[209]); A_arbace_g2a_build_A_const_159 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[210]); A_arbace_g2a_build_A_const_160 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[211]); A_arbace_g2a_build_A_const_161 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[212]); A_arbace_g2a_build_A_const_162 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[213]); A_arbace_g2a_build_A_const_163 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[214]); A_arbace_g2a_build_A_const_164 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[215]); A_arbace_g2a_build_A_const_165 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[216]); A_arbace_g2a_build_A_const_166 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[217]); A_arbace_g2a_build_A_const_167 = jrt.Class_Cast(A_arbace_g2a_build_A_const_pool.A[218]); A_arbace_g2a_build_A_const_168 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[219]) }

func A_arbace_g2a_build_A_clinit_p14() { A_arbace_g2a_build_A_const_169 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[220]); A_arbace_g2a_build_A_const_170 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[221]); A_arbace_g2a_build_A_const_171 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[222]); A_arbace_g2a_build_A_const_172 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[223]); A_arbace_g2a_build_A_const_173 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[224]); A_arbace_g2a_build_A_const_174 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[225]); A_arbace_g2a_build_A_const_175 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[226]); A_arbace_g2a_build_A_const_176 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[227]); A_arbace_g2a_build_A_const_177 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[228]); A_arbace_g2a_build_A_const_178 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[229]); A_arbace_g2a_build_A_const_179 = A_arbace_g2a_build_A_const_pool.A[230]; A_arbace_g2a_build_A_const_180 = lang.Keyword_Cast(A_arbace_g2a_build_A_const_pool.A[231]) }

func A_arbace_g2a_build_A_clinit_p15() { A_arbace_g2a_build_A_const_181 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[232]); A_arbace_g2a_build_A_const_182 = A_arbace_g2a_build_A_const_pool.A[233]; A_arbace_g2a_build_A_const_183 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[234]); A_arbace_g2a_build_A_const_184 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[235]); A_arbace_g2a_build_A_const_185 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[236]); A_arbace_g2a_build_A_const_186 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[237]); A_arbace_g2a_build_A_const_187 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[238]); A_arbace_g2a_build_A_const_188 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[239]); A_arbace_g2a_build_A_const_189 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[240]); A_arbace_g2a_build_A_const_190 = A_arbace_g2a_build_A_const_pool.A[241]; A_arbace_g2a_build_A_const_191 = A_arbace_g2a_build_A_const_pool.A[242]; A_arbace_g2a_build_A_const_192 = A_arbace_g2a_build_A_const_pool.A[243]; A_arbace_g2a_build_A_const_193 = lang.Var_Cast(A_arbace_g2a_build_A_const_pool.A[244]) }

func A_arbace_g2a_build_A_New() *A_arbace_g2a_build_A { A_arbace_g2a_build_A_Init(); t := &A_arbace_g2a_build_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_build_A) Ctor() {}

func (t *A_arbace_g2a_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_build_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_build_A_class }

func (t *A_arbace_g2a_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_build_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_build_A); return ok }

func A_arbace_g2a_build_A_Cast(x any) *A_arbace_g2a_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_build_A_class)) }; return v }



type A_arbace_g2a_build__main_A struct{ a2g_header uint64 }

var A_arbace_g2a_build__main_A_fn_class *jrt.Class



type A_arbace_g2a_build__main_fn__715000384_A struct{ a2g_header uint64; F_usage any }

var A_arbace_g2a_build__main_fn__715000384_A_fn_class *jrt.Class



type A_arbace_g2a_build__main_fn__715000386_A struct{ a2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_g2a_build__main_fn__715000386_A_fn_class *jrt.Class



type A_arbace_g2a_build__main_fn__715000386_fn__715000387_A struct{ a2g_header uint64; F_e any }

var A_arbace_g2a_build__main_fn__715000386_fn__715000387_A_fn_class *jrt.Class



type A_arbace_g2a_build_build_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_build_A_fn_class *jrt.Class



type A_arbace_g2a_build_cache_texts_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_cache_texts_BANG__fn__715000322_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_cached_texts_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A struct{ a2g_header uint64; F_entry any }

var A_arbace_g2a_build_cached_texts_iter__715000300__715000304_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A struct{ a2g_header uint64; F_iter__715000300, F_s__715000301, F_entry any }

var A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_A_fn_class *jrt.Class



type A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A struct{ a2g_header uint64; F_entry, F_b__715000303 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_cached_texts_iter__715000300__715000304_fn__715000305_fn__715000306_A_fn_class *jrt.Class



type A_arbace_g2a_build_clj_files_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_clj_files_A_fn_class *jrt.Class



type A_arbace_g2a_build_clj_files_fn__715000020_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class *jrt.Class



type A_arbace_g2a_build_clj_files_fn__715000022_A struct{ a2g_header uint64; F_dir any }

var A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class *jrt.Class



type A_arbace_g2a_build_collect_index_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_collect_index_file_A_fn_class *jrt.Class



type A_arbace_g2a_build_collect_package_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_collect_package_A_fn_class *jrt.Class



type A_arbace_g2a_build_collect_package_fn__715000076_A struct{ a2g_header uint64; F_read_fn, F_read any }

var A_arbace_g2a_build_collect_package_fn__715000076_A_fn_class *jrt.Class



type A_arbace_g2a_build_collected_package_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_collected_package_A_fn_class *jrt.Class



type A_arbace_g2a_build_copy_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_copy_file_A_fn_class *jrt.Class



type A_arbace_g2a_build_data_dir_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_build_delete_tree_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_delete_tree_A_fn_class *jrt.Class



type A_arbace_g2a_build_eval715000004_A struct{ jrt.Object }

func A_arbace_g2a_build_eval715000004_A_New() *A_arbace_g2a_build_eval715000004_A { t := &A_arbace_g2a_build_eval715000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_build_eval715000004_A) Ctor() {}

func (t *A_arbace_g2a_build_eval715000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_build_eval715000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_build_eval715000004_A_class }

func (t *A_arbace_g2a_build_eval715000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_build_eval715000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_build_eval715000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_build_eval715000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_build_eval715000004_A); return ok }

func A_arbace_g2a_build_eval715000004_A_Cast(x any) *A_arbace_g2a_build_eval715000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_build_eval715000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_build_eval715000004_A_class)) }; return v }



type A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_fn_class *jrt.Class



type A_arbace_g2a_build_eval715000008_A struct{ jrt.Object }

func A_arbace_g2a_build_eval715000008_A_New() *A_arbace_g2a_build_eval715000008_A { t := &A_arbace_g2a_build_eval715000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_build_eval715000008_A) Ctor() {}

func (t *A_arbace_g2a_build_eval715000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_build_eval715000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_build_eval715000008_A_class }

func (t *A_arbace_g2a_build_eval715000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_build_eval715000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_build_eval715000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_build_eval715000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_build_eval715000008_A); return ok }

func A_arbace_g2a_build_eval715000008_A_Cast(x any) *A_arbace_g2a_build_eval715000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_build_eval715000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_build_eval715000008_A_class)) }; return v }



type A_arbace_g2a_build_eval715000008_fn__715000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_eval715000008_fn__715000009_A_fn_class *jrt.Class



type A_arbace_g2a_build_fail_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_fail_A_fn_class *jrt.Class



type A_arbace_g2a_build_file_sha_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_file_sha_A_fn_class *jrt.Class



type A_arbace_g2a_build_forms_dir_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_forms_dir_A_fn_class *jrt.Class



type A_arbace_g2a_build_go_env_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_go_env_A_fn_class *jrt.Class



type A_arbace_g2a_build_go_mod_cache_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_hex__715000239_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_hex__715000239_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_hex__715000239_fn__715000240_A_fn_class *jrt.Class



type A_arbace_g2a_build_h1_of_file_sha__715000243_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_h1_of_file_sha__715000243_A_fn_class *jrt.Class



type A_arbace_g2a_build_hex_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_hex_A_fn_class *jrt.Class



type A_arbace_g2a_build_hex_fn__715000072_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_hex_fn__715000072_A_fn_class *jrt.Class



type A_arbace_g2a_build_package_file_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_build_package_file_QMARK__fn__715000027_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class *jrt.Class



type A_arbace_g2a_build_package_file_QMARK__fn__715000029_A struct{ a2g_header uint64; F_aliases any }

var A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_fn__715000057_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_fn__715000057_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_fn__715000062_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_fn__715000062_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_A struct{ a2g_header uint64; F_print_cache any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A struct{ a2g_header uint64; F_iter__715000034, F_s__715000035, F_print_cache any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A struct{ a2g_header uint64; F_iter__715000036, F_s__715000037 any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class *jrt.Class



type A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A struct{ a2g_header uint64; F_b__715000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_cache_key_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_print_cache_key_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_cache_key_add__715000291_A struct{ a2g_header uint64; F_md any }

var A_arbace_g2a_build_print_cache_key_add__715000291_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_cache_key_fn__715000297_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_print_cache_key_fn__715000297_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_print_module_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000333_A struct{ a2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_g2a_build_print_module_fn__715000333_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A struct{ a2g_header uint64; F_test_files, F_tests any }

var A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A struct{ a2g_header uint64; F_test_files any }

var A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A struct{ a2g_header uint64; F_test_files any }

var A_arbace_g2a_build_print_module_fn__715000333_printable__715000335_fn__715000336_fn__715000337_A_fn_class *jrt.Class



type A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A struct{ a2g_header uint64; F_pkg any }

var A_arbace_g2a_build_print_module_fn__715000333_rel__715000342_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_program_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_fn__715000261_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_program_fn__715000261_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_fn__715000273_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_program_fn__715000273_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_iter__715000263__715000267_A struct{ a2g_header uint64; F_module any }

var A_arbace_g2a_build_program_iter__715000263__715000267_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A struct{ a2g_header uint64; F_iter__715000263, F_s__715000264, F_module any }

var A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_A_fn_class *jrt.Class



type A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A struct{ a2g_header uint64; F_b__715000266 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_g2a_build_program_iter__715000263__715000267_fn__715000268_fn__715000269_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_all_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_all_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_all_fn__715000066_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_all_fn__715000066_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_all_fn__715000068_A struct{ a2g_header uint64; F_cache any }

var A_arbace_g2a_build_read_all_fn__715000068_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_index_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_index_A_fn_class *jrt.Class



type A_arbace_g2a_build_read_program_edn_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_read_program_edn_A_fn_class *jrt.Class



type A_arbace_g2a_build_rel_path_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_rel_path_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000099_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_fn__715000099_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000101_A struct{ a2g_header uint64; F_m any }

var A_arbace_g2a_build_root_packages_fn__715000101_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000158_A struct{ a2g_header uint64; F_covered, F_known_QMARK_ any }

var A_arbace_g2a_build_root_packages_fn__715000158_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000187_A struct{ a2g_header uint64; F_dir any }

var A_arbace_g2a_build_root_packages_fn__715000187_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_fn__715000192_A struct{ a2g_header uint64; F_dir any }

var A_arbace_g2a_build_root_packages_fn__715000192_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000103__715000107_A struct{ a2g_header uint64; F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000103__715000107_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A struct{ a2g_header uint64; F_iter__715000103, F_s__715000104, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A struct{ a2g_header uint64; F_b__715000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A struct{ a2g_header uint64; F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000109_fn__715000114_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A struct{ a2g_header uint64; F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000103__715000107_fn__715000108_fn__715000124_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000131__715000137_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_iter__715000131__715000137_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A struct{ a2g_header uint64; F_iter__715000131, F_s__715000132 any }

var A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A struct{ a2g_header uint64; F_iter__715000133, F_s__715000134 any }

var A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A struct{ a2g_header uint64; F_b__715000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_root_packages_iter__715000131__715000137_fn__715000138_iter__715000133__715000142_fn__715000143_fn__715000144_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_A struct{ a2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid any }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A struct{ a2g_header uint64; F_iter__715000162, F_pkg_file_QMARK_, F_read_fn, F_s__715000163, F_dir, F_valid any }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A struct{ a2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid, F_b__715000165 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000169_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A struct{ a2g_header uint64; F_f, F_dir any }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000168_fn__715000171_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000174_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A struct{ a2g_header uint64; F_f, F_dir any }

var A_arbace_g2a_build_root_packages_iter__715000162__715000166_fn__715000167_fn__715000176_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000194__715000198_A struct{ a2g_header uint64; F_pkg_file_QMARK_, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000194__715000198_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A struct{ a2g_header uint64; F_pkg_file_QMARK_, F_s__715000195, F_iter__715000194, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A struct{ a2g_header uint64; F_pkg_file_QMARK_, F_b__715000197 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000194__715000198_fn__715000199_fn__715000200_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000204__715000208_A struct{ a2g_header uint64; F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000204__715000208_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A struct{ a2g_header uint64; F_iter__715000204, F_s__715000205, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A struct{ a2g_header uint64; F_b__715000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A struct{ a2g_header uint64; F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000210_fn__715000211_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A struct{ a2g_header uint64; F_shas any }

var A_arbace_g2a_build_root_packages_iter__715000204__715000208_fn__715000209_fn__715000214_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_known_QMARK___715000156_A struct{ a2g_header uint64; F_index_file, F_pf_index, F_shas any }

var A_arbace_g2a_build_root_packages_known_QMARK___715000156_A_fn_class *jrt.Class



type A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A struct{ a2g_header uint64; F_read_fn, F_known_QMARK_, F_pf_index, F_shas any }

var A_arbace_g2a_build_root_packages_pkg_file_QMARK___715000160_A_fn_class *jrt.Class



type A_arbace_g2a_build_run_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_run_A_fn_class *jrt.Class



type A_arbace_g2a_build_sha256_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_sha256_A_fn_class *jrt.Class



type A_arbace_g2a_build_sha256_fn__715000277_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_sha256_fn__715000277_A_fn_class *jrt.Class



type A_arbace_g2a_build_tamago_go_sum_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_g2a_build_toolchain_lang_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_with_line_files_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_fn__715000283_A struct{ a2g_header uint64; F_fdir any }

var A_arbace_g2a_build_with_line_files_fn__715000283_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A struct{ a2g_header uint64; F_fdir any }

var A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_A_fn_class *jrt.Class



type A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A struct{ a2g_header uint64; F_fdir any }

var A_arbace_g2a_build_with_line_files_fn__715000283_fn__715000284_fn__715000285_A_fn_class *jrt.Class



type A_arbace_g2a_build_write_index_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_build_write_index_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_build_write_index_BANG__fn__715000091_A struct{ a2g_header uint64; F_ok_QMARK_ any }

var A_arbace_g2a_build_write_index_BANG__fn__715000091_A_fn_class *jrt.Class



type A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A struct{ a2g_header uint64; F_printed any }

var A_arbace_g2a_build_write_index_BANG__ok_QMARK___715000089_A_fn_class *jrt.Class



type A_arbace_g2a_build_write_index_BANG__printed__715000087_A struct{ a2g_header uint64 }

var A_arbace_g2a_build_write_index_BANG__printed__715000087_A_fn_class *jrt.Class
