//line a2g_classes.ae:1
package aot_arbace_g2a_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_build__main_A_class, Name: "arbace.g2a.build$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build__main_fn__715000263_A_class, Name: "arbace.g2a.build$_main$fn__715000263", Modifiers: 25, Simple: "fn__715000263", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_fn__715000263_A", Source: "build.ae", Declaring: &A_arbace_g2a_build__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build__main_fn__715000265_A_class, Name: "arbace.g2a.build$_main$fn__715000265", Modifiers: 25, Simple: "fn__715000265", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_fn__715000265_A", Source: "build.ae", Declaring: &A_arbace_g2a_build__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_class, Name: "arbace.g2a.build$_main$fn__715000265$fn__715000266", Modifiers: 25, Simple: "fn__715000266", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_fn__715000265_fn__715000266_A", Source: "build.ae", Declaring: &A_arbace_g2a_build__main_fn__715000265_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_build_A_class, Name: "arbace.g2a.build$build", Modifiers: 25, Simple: "build", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_build_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_cache_texts_BANG__A_class, Name: "arbace.g2a.build$cache_texts_BANG_", Modifiers: 25, Simple: "cache_texts_BANG_", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cache_texts_BANG__A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_class, Name: "arbace.g2a.build$cache_texts_BANG_$fn__715000203", Modifiers: 25, Simple: "fn__715000203", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_cache_texts_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_cached_texts_A_class, Name: "arbace.g2a.build$cached_texts", Modifiers: 25, Simple: "cached_texts", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class, Name: "arbace.g2a.build$cached_texts$iter__715000181__715000185", Modifiers: 25, Simple: "iter__715000181__715000185", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_cached_texts_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class, Name: "arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186", Modifiers: 25, Simple: "fn__715000186", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_class, Name: "arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186$fn__715000187", Modifiers: 25, Simple: "fn__715000187", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_clj_files_A_class, Name: "arbace.g2a.build$clj_files", Modifiers: 25, Simple: "clj_files", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_clj_files_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_clj_files_fn__715000020_A_class, Name: "arbace.g2a.build$clj_files$fn__715000020", Modifiers: 25, Simple: "fn__715000020", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_clj_files_fn__715000020_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_clj_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_clj_files_fn__715000022_A_class, Name: "arbace.g2a.build$clj_files$fn__715000022", Modifiers: 25, Simple: "fn__715000022", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_clj_files_fn__715000022_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_clj_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_copy_file_A_class, Name: "arbace.g2a.build$copy_file", Modifiers: 25, Simple: "copy_file", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_copy_file_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_data_dir_QMARK__A_class, Name: "arbace.g2a.build$data_dir_QMARK_", Modifiers: 25, Simple: "data_dir_QMARK_", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_data_dir_QMARK__A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_delete_tree_A_class, Name: "arbace.g2a.build$delete_tree", Modifiers: 25, Simple: "delete_tree", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_delete_tree_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_class, Name: "arbace.g2a.build$eval715000004$loading__1927001464__auto____715000005", Modifiers: 25, Simple: "loading__1927001464__auto____715000005", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_eval715000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_eval715000008_fn__715000009_A_class, Name: "arbace.g2a.build$eval715000008$fn__715000009", Modifiers: 25, Simple: "fn__715000009", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000008_fn__715000009_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_eval715000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_fail_A_class, Name: "arbace.g2a.build$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_fail_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_forms_dir_A_class, Name: "arbace.g2a.build$forms_dir", Modifiers: 25, Simple: "forms_dir", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_forms_dir_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_go_env_A_class, Name: "arbace.g2a.build$go_env", Modifiers: 25, Simple: "go_env", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_go_env_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_go_mod_cache_A_class, Name: "arbace.g2a.build$go_mod_cache", Modifiers: 25, Simple: "go_mod_cache", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_go_mod_cache_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_h1_of_file_A_class, Name: "arbace.g2a.build$h1_of_file", Modifiers: 25, Simple: "h1_of_file", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_h1_of_file_hex__715000120_A_class, Name: "arbace.g2a.build$h1_of_file$hex__715000120", Modifiers: 25, Simple: "hex__715000120", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_hex__715000120_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_h1_of_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_class, Name: "arbace.g2a.build$h1_of_file$hex__715000120$fn__715000121", Modifiers: 25, Simple: "fn__715000121", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_h1_of_file_hex__715000120_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_h1_of_file_sha__715000124_A_class, Name: "arbace.g2a.build$h1_of_file$sha__715000124", Modifiers: 25, Simple: "sha__715000124", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_sha__715000124_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_h1_of_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_package_file_QMARK__A_class, Name: "arbace.g2a.build$package_file_QMARK_", Modifiers: 25, Simple: "package_file_QMARK_", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_package_file_QMARK__A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_class, Name: "arbace.g2a.build$package_file_QMARK_$fn__715000027", Modifiers: 25, Simple: "fn__715000027", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_package_file_QMARK__fn__715000027_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_package_file_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_class, Name: "arbace.g2a.build$package_file_QMARK_$fn__715000029", Modifiers: 25, Simple: "fn__715000029", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_package_file_QMARK__fn__715000029_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_package_file_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_A_class, Name: "arbace.g2a.build$packages", Modifiers: 25, Simple: "packages", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_fn__715000057_A_class, Name: "arbace.g2a.build$packages$fn__715000057", Modifiers: 25, Simple: "fn__715000057", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_fn__715000057_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_fn__715000062_A_class, Name: "arbace.g2a.build$packages$fn__715000062", Modifiers: 25, Simple: "fn__715000062", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_fn__715000062_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_iter__715000034__715000040_A_class, Name: "arbace.g2a.build$packages$iter__715000034__715000040", Modifiers: 25, Simple: "iter__715000034__715000040", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class, Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041", Modifiers: 25, Simple: "fn__715000041", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_iter__715000034__715000040_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class, Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042", Modifiers: 25, Simple: "iter__715000036__715000042", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class, Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043", Modifiers: 25, Simple: "fn__715000043", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_class, Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043$fn__715000044", Modifiers: 25, Simple: "fn__715000044", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_cache_key_A_class, Name: "arbace.g2a.build$print_cache_key", Modifiers: 25, Simple: "print_cache_key", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_cache_key_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_cache_key_add__715000172_A_class, Name: "arbace.g2a.build$print_cache_key$add__715000172", Modifiers: 25, Simple: "add__715000172", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_cache_key_add__715000172_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_print_cache_key_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_cache_key_fn__715000178_A_class, Name: "arbace.g2a.build$print_cache_key$fn__715000178", Modifiers: 25, Simple: "fn__715000178", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_cache_key_fn__715000178_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_print_cache_key_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_module_A_class, Name: "arbace.g2a.build$print_module", Modifiers: 25, Simple: "print_module", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_module_fn__715000214_A_class, Name: "arbace.g2a.build$print_module$fn__715000214", Modifiers: 25, Simple: "fn__715000214", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_print_module_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class, Name: "arbace.g2a.build$print_module$fn__715000214$fn__715000216", Modifiers: 25, Simple: "fn__715000216", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_print_module_fn__715000214_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_class, Name: "arbace.g2a.build$print_module$fn__715000214$fn__715000216$fn__715000217", Modifiers: 25, Simple: "fn__715000217", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_class, Name: "arbace.g2a.build$print_module$fn__715000214$rel__715000221", Modifiers: 25, Simple: "rel__715000221", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_print_module_fn__715000214_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_program_A_class, Name: "arbace.g2a.build$program", Modifiers: 25, Simple: "program", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_program_fn__715000142_A_class, Name: "arbace.g2a.build$program$fn__715000142", Modifiers: 25, Simple: "fn__715000142", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_fn__715000142_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_program_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_program_fn__715000154_A_class, Name: "arbace.g2a.build$program$fn__715000154", Modifiers: 25, Simple: "fn__715000154", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_fn__715000154_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_program_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_program_iter__715000144__715000148_A_class, Name: "arbace.g2a.build$program$iter__715000144__715000148", Modifiers: 25, Simple: "iter__715000144__715000148", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_iter__715000144__715000148_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_program_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class, Name: "arbace.g2a.build$program$iter__715000144__715000148$fn__715000149", Modifiers: 25, Simple: "fn__715000149", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_program_iter__715000144__715000148_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_class, Name: "arbace.g2a.build$program$iter__715000144__715000148$fn__715000149$fn__715000150", Modifiers: 25, Simple: "fn__715000150", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_read_all_A_class, Name: "arbace.g2a.build$read_all", Modifiers: 25, Simple: "read_all", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_all_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_read_all_fn__715000066_A_class, Name: "arbace.g2a.build$read_all$fn__715000066", Modifiers: 25, Simple: "fn__715000066", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_all_fn__715000066_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_read_all_fn__715000068_A_class, Name: "arbace.g2a.build$read_all$fn__715000068", Modifiers: 25, Simple: "fn__715000068", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_all_fn__715000068_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_read_program_edn_A_class, Name: "arbace.g2a.build$read_program_edn", Modifiers: 25, Simple: "read_program_edn", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_program_edn_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_rel_path_A_class, Name: "arbace.g2a.build$rel_path", Modifiers: 25, Simple: "rel_path", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_rel_path_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_A_class, Name: "arbace.g2a.build$root_packages", Modifiers: 25, Simple: "root_packages", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_fn__715000093_A_class, Name: "arbace.g2a.build$root_packages$fn__715000093", Modifiers: 25, Simple: "fn__715000093", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_fn__715000093_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_fn__715000098_A_class, Name: "arbace.g2a.build$root_packages$fn__715000098", Modifiers: 25, Simple: "fn__715000098", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_fn__715000098_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class, Name: "arbace.g2a.build$root_packages$iter__715000072__715000076", Modifiers: 25, Simple: "iter__715000072__715000076", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class, Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077", Modifiers: 25, Simple: "fn__715000077", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class, Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078", Modifiers: 25, Simple: "fn__715000078", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_class, Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078$fn__715000079", Modifiers: 25, Simple: "fn__715000079", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_class, Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000082", Modifiers: 25, Simple: "fn__715000082", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_run_A_class, Name: "arbace.g2a.build$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_run_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_sha256_A_class, Name: "arbace.g2a.build$sha256", Modifiers: 25, Simple: "sha256", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_sha256_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_sha256_fn__715000158_A_class, Name: "arbace.g2a.build$sha256$fn__715000158", Modifiers: 25, Simple: "fn__715000158", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_sha256_fn__715000158_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_sha256_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_tamago_go_sum_A_class, Name: "arbace.g2a.build$tamago_go_sum", Modifiers: 25, Simple: "tamago_go_sum", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_tamago_go_sum_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_toolchain_lang_A_class, Name: "arbace.g2a.build$toolchain_lang", Modifiers: 25, Simple: "toolchain_lang", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_toolchain_lang_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_with_line_files_A_class, Name: "arbace.g2a.build$with_line_files", Modifiers: 25, Simple: "with_line_files", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_with_line_files_fn__715000164_A_class, Name: "arbace.g2a.build$with_line_files$fn__715000164", Modifiers: 25, Simple: "fn__715000164", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_fn__715000164_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_with_line_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class, Name: "arbace.g2a.build$with_line_files$fn__715000164$fn__715000165", Modifiers: 25, Simple: "fn__715000165", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_with_line_files_fn__715000164_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_class, Name: "arbace.g2a.build$with_line_files$fn__715000164$fn__715000165$fn__715000166", Modifiers: 25, Simple: "fn__715000166", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A", Source: "build.ae", Declaring: &A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_A_New()}; return nil }

var A_arbace_g2a_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_build_A_new}

var A_arbace_g2a_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_A"})

func init() { i := A_arbace_g2a_build_A_class.Info(); i.IsInstance = A_arbace_g2a_build_A_InstanceOf; i.Init = A_arbace_g2a_build_A_Init; i.Table = A_arbace_g2a_build_A_members }

var A_arbace_g2a_build__main_A_class *jrt.Class

var A_arbace_g2a_build__main_fn__715000263_A_class *jrt.Class

var A_arbace_g2a_build__main_fn__715000265_A_class *jrt.Class

var A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_class *jrt.Class

var A_arbace_g2a_build_build_A_class *jrt.Class

var A_arbace_g2a_build_cache_texts_BANG__A_class *jrt.Class

var A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_class *jrt.Class

var A_arbace_g2a_build_cached_texts_A_class *jrt.Class

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class *jrt.Class

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class *jrt.Class

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_class *jrt.Class

var A_arbace_g2a_build_clj_files_A_class *jrt.Class

var A_arbace_g2a_build_clj_files_fn__715000020_A_class *jrt.Class

var A_arbace_g2a_build_clj_files_fn__715000022_A_class *jrt.Class

var A_arbace_g2a_build_copy_file_A_class *jrt.Class

var A_arbace_g2a_build_data_dir_QMARK__A_class *jrt.Class

var A_arbace_g2a_build_delete_tree_A_class *jrt.Class

func A_arbace_g2a_build_eval715000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_eval715000004_A_New()}; return nil }

var A_arbace_g2a_build_eval715000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_build_eval715000004_A_new}

var A_arbace_g2a_build_eval715000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$eval715000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_build_A_class, Simple: "eval715000004", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000004_A"})

func init() { i := A_arbace_g2a_build_eval715000004_A_class.Info(); i.IsInstance = A_arbace_g2a_build_eval715000004_A_InstanceOf; i.Table = A_arbace_g2a_build_eval715000004_A_members }

var A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_class *jrt.Class

func A_arbace_g2a_build_eval715000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_eval715000008_A_New()}; return nil }

var A_arbace_g2a_build_eval715000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_build_eval715000008_A_new}

var A_arbace_g2a_build_eval715000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$eval715000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_build_A_class, Simple: "eval715000008", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000008_A"})

func init() { i := A_arbace_g2a_build_eval715000008_A_class.Info(); i.IsInstance = A_arbace_g2a_build_eval715000008_A_InstanceOf; i.Table = A_arbace_g2a_build_eval715000008_A_members }

var A_arbace_g2a_build_eval715000008_fn__715000009_A_class *jrt.Class

var A_arbace_g2a_build_fail_A_class *jrt.Class

var A_arbace_g2a_build_forms_dir_A_class *jrt.Class

var A_arbace_g2a_build_go_env_A_class *jrt.Class

var A_arbace_g2a_build_go_mod_cache_A_class *jrt.Class

var A_arbace_g2a_build_h1_of_file_A_class *jrt.Class

var A_arbace_g2a_build_h1_of_file_hex__715000120_A_class *jrt.Class

var A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_class *jrt.Class

var A_arbace_g2a_build_h1_of_file_sha__715000124_A_class *jrt.Class

var A_arbace_g2a_build_package_file_QMARK__A_class *jrt.Class

var A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_class *jrt.Class

var A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_class *jrt.Class

var A_arbace_g2a_build_packages_A_class *jrt.Class

var A_arbace_g2a_build_packages_fn__715000057_A_class *jrt.Class

var A_arbace_g2a_build_packages_fn__715000062_A_class *jrt.Class

var A_arbace_g2a_build_packages_iter__715000034__715000040_A_class *jrt.Class

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class *jrt.Class

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class *jrt.Class

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class *jrt.Class

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_class *jrt.Class

var A_arbace_g2a_build_print_cache_key_A_class *jrt.Class

var A_arbace_g2a_build_print_cache_key_add__715000172_A_class *jrt.Class

var A_arbace_g2a_build_print_cache_key_fn__715000178_A_class *jrt.Class

var A_arbace_g2a_build_print_module_A_class *jrt.Class

var A_arbace_g2a_build_print_module_fn__715000214_A_class *jrt.Class

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class *jrt.Class

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_class *jrt.Class

var A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_class *jrt.Class

var A_arbace_g2a_build_program_A_class *jrt.Class

var A_arbace_g2a_build_program_fn__715000142_A_class *jrt.Class

var A_arbace_g2a_build_program_fn__715000154_A_class *jrt.Class

var A_arbace_g2a_build_program_iter__715000144__715000148_A_class *jrt.Class

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class *jrt.Class

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_class *jrt.Class

var A_arbace_g2a_build_read_all_A_class *jrt.Class

var A_arbace_g2a_build_read_all_fn__715000066_A_class *jrt.Class

var A_arbace_g2a_build_read_all_fn__715000068_A_class *jrt.Class

var A_arbace_g2a_build_read_program_edn_A_class *jrt.Class

var A_arbace_g2a_build_rel_path_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_fn__715000093_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_fn__715000098_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_class *jrt.Class

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_class *jrt.Class

var A_arbace_g2a_build_run_A_class *jrt.Class

var A_arbace_g2a_build_sha256_A_class *jrt.Class

var A_arbace_g2a_build_sha256_fn__715000158_A_class *jrt.Class

var A_arbace_g2a_build_tamago_go_sum_A_class *jrt.Class

var A_arbace_g2a_build_toolchain_lang_A_class *jrt.Class

var A_arbace_g2a_build_with_line_files_A_class *jrt.Class

var A_arbace_g2a_build_with_line_files_fn__715000164_A_class *jrt.Class

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class *jrt.Class

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_class *jrt.Class

func A_arbace_g2a_build__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_build__init_A_Load__O()}; return nil }

func A_arbace_g2a_build__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build__init_A_New()}; return nil }

var A_arbace_g2a_build__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_build__init_A_invoke, New: A_arbace_g2a_build__init_A_new}

var A_arbace_g2a_build__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__init_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build__init_A_class.Info(); i.IsInstance = A_arbace_g2a_build__init_A_InstanceOf; i.Init = A_arbace_g2a_build__init_A_Init; i.Table = A_arbace_g2a_build__init_A_members }
