//line a2g_classes.ae:1
package aot_arbace_g2a_build

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_A_New()}; return nil }

var A_arbace_g2a_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_build_A_new}

var A_arbace_g2a_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_A"})

func init() { i := A_arbace_g2a_build_A_class.Info(); i.IsInstance = A_arbace_g2a_build_A_InstanceOf; i.Init = A_arbace_g2a_build_A_Init; i.Table = A_arbace_g2a_build_A_members; jrt.RegisterGoType(A_arbace_g2a_build_A_class, reflect.TypeFor[A_arbace_g2a_build_A]()) }

func A_arbace_g2a_build__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build__main_A_New()}; return nil }

func A_arbace_g2a_build__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build__main_A_fn_class)}; return nil }

var A_arbace_g2a_build__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build__main_A_invoke, New: A_arbace_g2a_build__main_A_new, Get: A_arbace_g2a_build__main_A_get}

var A_arbace_g2a_build__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "_main", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build__main_A_class.Info(); i.IsInstance = A_arbace_g2a_build__main_A_InstanceOf; i.Init = A_arbace_g2a_build__main_A_Init; i.Table = A_arbace_g2a_build__main_A_members; jrt.RegisterGoType(A_arbace_g2a_build__main_A_class, reflect.TypeFor[A_arbace_g2a_build__main_A]()) }

func A_arbace_g2a_build__main_fn__715000263_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build__main_fn__715000263_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build__main_fn__715000263_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build__main_fn__715000263_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build__main_fn__715000263_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build__main_fn__715000263_A_fn_class)}; return nil }

var A_arbace_g2a_build__main_fn__715000263_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build__main_fn__715000263_A_invoke, New: A_arbace_g2a_build__main_fn__715000263_A_new, Get: A_arbace_g2a_build__main_fn__715000263_A_get}

var A_arbace_g2a_build__main_fn__715000263_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$_main$fn__715000263", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build__main_A_class, Simple: "fn__715000263", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_fn__715000263_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build__main_fn__715000263_A_class.Info(); i.IsInstance = A_arbace_g2a_build__main_fn__715000263_A_InstanceOf; i.Init = A_arbace_g2a_build__main_fn__715000263_A_Init; i.Table = A_arbace_g2a_build__main_fn__715000263_A_members; jrt.RegisterGoType(A_arbace_g2a_build__main_fn__715000263_A_class, reflect.TypeFor[A_arbace_g2a_build__main_fn__715000263_A]()) }

func A_arbace_g2a_build__main_fn__715000265_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build__main_fn__715000265_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build__main_fn__715000265_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build__main_fn__715000265_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build__main_fn__715000265_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build__main_fn__715000265_A_fn_class)}; return nil }

var A_arbace_g2a_build__main_fn__715000265_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build__main_fn__715000265_A_invoke, New: A_arbace_g2a_build__main_fn__715000265_A_new, Get: A_arbace_g2a_build__main_fn__715000265_A_get}

var A_arbace_g2a_build__main_fn__715000265_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$_main$fn__715000265", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build__main_A_class, Simple: "fn__715000265", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_fn__715000265_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build__main_fn__715000265_A_class.Info(); i.IsInstance = A_arbace_g2a_build__main_fn__715000265_A_InstanceOf; i.Init = A_arbace_g2a_build__main_fn__715000265_A_Init; i.Table = A_arbace_g2a_build__main_fn__715000265_A_members; jrt.RegisterGoType(A_arbace_g2a_build__main_fn__715000265_A_class, reflect.TypeFor[A_arbace_g2a_build__main_fn__715000265_A]()) }

func A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build__main_fn__715000265_fn__715000266_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_fn_class)}; return nil }

var A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_invoke, New: A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_new, Get: A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_get}

var A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$_main$fn__715000265$fn__715000266", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build__main_fn__715000265_A_class, Simple: "fn__715000266", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__main_fn__715000265_fn__715000266_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_class.Info(); i.IsInstance = A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_InstanceOf; i.Init = A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_Init; i.Table = A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_members; jrt.RegisterGoType(A_arbace_g2a_build__main_fn__715000265_fn__715000266_A_class, reflect.TypeFor[A_arbace_g2a_build__main_fn__715000265_fn__715000266_A]()) }

func A_arbace_g2a_build_build_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_build_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_build_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_build_A_New()}; return nil }

func A_arbace_g2a_build_build_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_build_A_fn_class)}; return nil }

var A_arbace_g2a_build_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_build_A_invoke, New: A_arbace_g2a_build_build_A_new, Get: A_arbace_g2a_build_build_A_get}

var A_arbace_g2a_build_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$build", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "build", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_build_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_build_A_class.Info(); i.IsInstance = A_arbace_g2a_build_build_A_InstanceOf; i.Init = A_arbace_g2a_build_build_A_Init; i.Table = A_arbace_g2a_build_build_A_members; jrt.RegisterGoType(A_arbace_g2a_build_build_A_class, reflect.TypeFor[A_arbace_g2a_build_build_A]()) }

func A_arbace_g2a_build_cache_texts_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_cache_texts_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_cache_texts_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_cache_texts_BANG__A_New()}; return nil }

func A_arbace_g2a_build_cache_texts_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_cache_texts_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_build_cache_texts_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_cache_texts_BANG__A_invoke, New: A_arbace_g2a_build_cache_texts_BANG__A_new, Get: A_arbace_g2a_build_cache_texts_BANG__A_get}

var A_arbace_g2a_build_cache_texts_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$cache_texts_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "cache_texts_BANG_", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cache_texts_BANG__A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_cache_texts_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_build_cache_texts_BANG__A_InstanceOf; i.Init = A_arbace_g2a_build_cache_texts_BANG__A_Init; i.Table = A_arbace_g2a_build_cache_texts_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_build_cache_texts_BANG__A_class, reflect.TypeFor[A_arbace_g2a_build_cache_texts_BANG__A]()) }

func A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_New()}; return nil }

func A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_fn_class)}; return nil }

var A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_invoke, New: A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_new, Get: A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_get}

var A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$cache_texts_BANG_$fn__715000203", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_cache_texts_BANG__A_class, Simple: "fn__715000203", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_class.Info(); i.IsInstance = A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_InstanceOf; i.Init = A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_Init; i.Table = A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_members; jrt.RegisterGoType(A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A_class, reflect.TypeFor[A_arbace_g2a_build_cache_texts_BANG__fn__715000203_A]()) }

func A_arbace_g2a_build_cached_texts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_cached_texts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_cached_texts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_cached_texts_A_New()}; return nil }

func A_arbace_g2a_build_cached_texts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_cached_texts_A_fn_class)}; return nil }

var A_arbace_g2a_build_cached_texts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_cached_texts_A_invoke, New: A_arbace_g2a_build_cached_texts_A_new, Get: A_arbace_g2a_build_cached_texts_A_get}

var A_arbace_g2a_build_cached_texts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$cached_texts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "cached_texts", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_cached_texts_A_class.Info(); i.IsInstance = A_arbace_g2a_build_cached_texts_A_InstanceOf; i.Init = A_arbace_g2a_build_cached_texts_A_Init; i.Table = A_arbace_g2a_build_cached_texts_A_members; jrt.RegisterGoType(A_arbace_g2a_build_cached_texts_A_class, reflect.TypeFor[A_arbace_g2a_build_cached_texts_A]()) }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_fn_class)}; return nil }

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_invoke, New: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_new, Get: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_get}

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$cached_texts$iter__715000181__715000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_cached_texts_A_class, Simple: "iter__715000181__715000185", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class.Info(); i.IsInstance = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_InstanceOf; i.Init = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_Init; i.Table = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_members; jrt.RegisterGoType(A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class, reflect.TypeFor[A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A]()) }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_fn_class)}; return nil }

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_invoke, New: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_new, Get: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_get}

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_A_class, Simple: "fn__715000186", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class.Info(); i.IsInstance = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_InstanceOf; i.Init = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_Init; i.Table = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_members; jrt.RegisterGoType(A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class, reflect.TypeFor[A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A]()) }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_fn_class)}; return nil }

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_invoke, New: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_new, Get: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_get}

var A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186$fn__715000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_A_class, Simple: "fn__715000187", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_class.Info(); i.IsInstance = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_InstanceOf; i.Init = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_Init; i.Table = A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_members; jrt.RegisterGoType(A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A_class, reflect.TypeFor[A_arbace_g2a_build_cached_texts_iter__715000181__715000185_fn__715000186_fn__715000187_A]()) }

func A_arbace_g2a_build_clj_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_clj_files_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_clj_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_clj_files_A_New()}; return nil }

func A_arbace_g2a_build_clj_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_clj_files_A_fn_class)}; return nil }

var A_arbace_g2a_build_clj_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_clj_files_A_invoke, New: A_arbace_g2a_build_clj_files_A_new, Get: A_arbace_g2a_build_clj_files_A_get}

var A_arbace_g2a_build_clj_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$clj_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "clj_files", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_clj_files_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_clj_files_A_class.Info(); i.IsInstance = A_arbace_g2a_build_clj_files_A_InstanceOf; i.Init = A_arbace_g2a_build_clj_files_A_Init; i.Table = A_arbace_g2a_build_clj_files_A_members; jrt.RegisterGoType(A_arbace_g2a_build_clj_files_A_class, reflect.TypeFor[A_arbace_g2a_build_clj_files_A]()) }

func A_arbace_g2a_build_clj_files_fn__715000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_clj_files_fn__715000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_clj_files_fn__715000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_clj_files_fn__715000020_A_New()}; return nil }

func A_arbace_g2a_build_clj_files_fn__715000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_clj_files_fn__715000020_A_fn_class)}; return nil }

var A_arbace_g2a_build_clj_files_fn__715000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_clj_files_fn__715000020_A_invoke, New: A_arbace_g2a_build_clj_files_fn__715000020_A_new, Get: A_arbace_g2a_build_clj_files_fn__715000020_A_get}

var A_arbace_g2a_build_clj_files_fn__715000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$clj_files$fn__715000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_clj_files_A_class, Simple: "fn__715000020", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_clj_files_fn__715000020_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_clj_files_fn__715000020_A_class.Info(); i.IsInstance = A_arbace_g2a_build_clj_files_fn__715000020_A_InstanceOf; i.Init = A_arbace_g2a_build_clj_files_fn__715000020_A_Init; i.Table = A_arbace_g2a_build_clj_files_fn__715000020_A_members; jrt.RegisterGoType(A_arbace_g2a_build_clj_files_fn__715000020_A_class, reflect.TypeFor[A_arbace_g2a_build_clj_files_fn__715000020_A]()) }

func A_arbace_g2a_build_clj_files_fn__715000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_clj_files_fn__715000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_clj_files_fn__715000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_clj_files_fn__715000022_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_clj_files_fn__715000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_clj_files_fn__715000022_A_fn_class)}; return nil }

var A_arbace_g2a_build_clj_files_fn__715000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_clj_files_fn__715000022_A_invoke, New: A_arbace_g2a_build_clj_files_fn__715000022_A_new, Get: A_arbace_g2a_build_clj_files_fn__715000022_A_get}

var A_arbace_g2a_build_clj_files_fn__715000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$clj_files$fn__715000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_clj_files_A_class, Simple: "fn__715000022", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_clj_files_fn__715000022_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_clj_files_fn__715000022_A_class.Info(); i.IsInstance = A_arbace_g2a_build_clj_files_fn__715000022_A_InstanceOf; i.Init = A_arbace_g2a_build_clj_files_fn__715000022_A_Init; i.Table = A_arbace_g2a_build_clj_files_fn__715000022_A_members; jrt.RegisterGoType(A_arbace_g2a_build_clj_files_fn__715000022_A_class, reflect.TypeFor[A_arbace_g2a_build_clj_files_fn__715000022_A]()) }

func A_arbace_g2a_build_copy_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_copy_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_copy_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_copy_file_A_New()}; return nil }

func A_arbace_g2a_build_copy_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_copy_file_A_fn_class)}; return nil }

var A_arbace_g2a_build_copy_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_copy_file_A_invoke, New: A_arbace_g2a_build_copy_file_A_new, Get: A_arbace_g2a_build_copy_file_A_get}

var A_arbace_g2a_build_copy_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$copy_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "copy_file", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_copy_file_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_copy_file_A_class.Info(); i.IsInstance = A_arbace_g2a_build_copy_file_A_InstanceOf; i.Init = A_arbace_g2a_build_copy_file_A_Init; i.Table = A_arbace_g2a_build_copy_file_A_members; jrt.RegisterGoType(A_arbace_g2a_build_copy_file_A_class, reflect.TypeFor[A_arbace_g2a_build_copy_file_A]()) }

func A_arbace_g2a_build_data_dir_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_data_dir_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_data_dir_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_data_dir_QMARK__A_New()}; return nil }

func A_arbace_g2a_build_data_dir_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_data_dir_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_build_data_dir_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_data_dir_QMARK__A_invoke, New: A_arbace_g2a_build_data_dir_QMARK__A_new, Get: A_arbace_g2a_build_data_dir_QMARK__A_get}

var A_arbace_g2a_build_data_dir_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$data_dir_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "data_dir_QMARK_", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_data_dir_QMARK__A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_data_dir_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_build_data_dir_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_build_data_dir_QMARK__A_Init; i.Table = A_arbace_g2a_build_data_dir_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_build_data_dir_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_build_data_dir_QMARK__A]()) }

func A_arbace_g2a_build_delete_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_delete_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_delete_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_delete_tree_A_New()}; return nil }

func A_arbace_g2a_build_delete_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_delete_tree_A_fn_class)}; return nil }

var A_arbace_g2a_build_delete_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_delete_tree_A_invoke, New: A_arbace_g2a_build_delete_tree_A_new, Get: A_arbace_g2a_build_delete_tree_A_get}

var A_arbace_g2a_build_delete_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$delete_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "delete_tree", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_delete_tree_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_delete_tree_A_class.Info(); i.IsInstance = A_arbace_g2a_build_delete_tree_A_InstanceOf; i.Init = A_arbace_g2a_build_delete_tree_A_Init; i.Table = A_arbace_g2a_build_delete_tree_A_members; jrt.RegisterGoType(A_arbace_g2a_build_delete_tree_A_class, reflect.TypeFor[A_arbace_g2a_build_delete_tree_A]()) }

func A_arbace_g2a_build_eval715000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_eval715000004_A_New()}; return nil }

var A_arbace_g2a_build_eval715000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_build_eval715000004_A_new}

var A_arbace_g2a_build_eval715000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$eval715000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_build_A_class, Simple: "eval715000004", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000004_A"})

func init() { i := A_arbace_g2a_build_eval715000004_A_class.Info(); i.IsInstance = A_arbace_g2a_build_eval715000004_A_InstanceOf; i.Table = A_arbace_g2a_build_eval715000004_A_members; jrt.RegisterGoType(A_arbace_g2a_build_eval715000004_A_class, reflect.TypeFor[A_arbace_g2a_build_eval715000004_A]()) }

func A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_New()}; return nil }

func A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_fn_class)}; return nil }

var A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_invoke, New: A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_new, Get: A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_get}

var A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$eval715000004$loading__1927001464__auto____715000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_eval715000004_A_class, Simple: "loading__1927001464__auto____715000005", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_class.Info(); i.IsInstance = A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_InstanceOf; i.Init = A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_Init; i.Table = A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_members; jrt.RegisterGoType(A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A_class, reflect.TypeFor[A_arbace_g2a_build_eval715000004_loading__1927001464__auto____715000005_A]()) }

func A_arbace_g2a_build_eval715000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_eval715000008_A_New()}; return nil }

var A_arbace_g2a_build_eval715000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_build_eval715000008_A_new}

var A_arbace_g2a_build_eval715000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$eval715000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_build_A_class, Simple: "eval715000008", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000008_A"})

func init() { i := A_arbace_g2a_build_eval715000008_A_class.Info(); i.IsInstance = A_arbace_g2a_build_eval715000008_A_InstanceOf; i.Table = A_arbace_g2a_build_eval715000008_A_members; jrt.RegisterGoType(A_arbace_g2a_build_eval715000008_A_class, reflect.TypeFor[A_arbace_g2a_build_eval715000008_A]()) }

func A_arbace_g2a_build_eval715000008_fn__715000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_eval715000008_fn__715000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_eval715000008_fn__715000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_eval715000008_fn__715000009_A_New()}; return nil }

func A_arbace_g2a_build_eval715000008_fn__715000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_eval715000008_fn__715000009_A_fn_class)}; return nil }

var A_arbace_g2a_build_eval715000008_fn__715000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_eval715000008_fn__715000009_A_invoke, New: A_arbace_g2a_build_eval715000008_fn__715000009_A_new, Get: A_arbace_g2a_build_eval715000008_fn__715000009_A_get}

var A_arbace_g2a_build_eval715000008_fn__715000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$eval715000008$fn__715000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_eval715000008_A_class, Simple: "fn__715000009", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_eval715000008_fn__715000009_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_eval715000008_fn__715000009_A_class.Info(); i.IsInstance = A_arbace_g2a_build_eval715000008_fn__715000009_A_InstanceOf; i.Init = A_arbace_g2a_build_eval715000008_fn__715000009_A_Init; i.Table = A_arbace_g2a_build_eval715000008_fn__715000009_A_members; jrt.RegisterGoType(A_arbace_g2a_build_eval715000008_fn__715000009_A_class, reflect.TypeFor[A_arbace_g2a_build_eval715000008_fn__715000009_A]()) }

func A_arbace_g2a_build_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_fail_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_fail_A_New()}; return nil }

func A_arbace_g2a_build_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_fail_A_fn_class)}; return nil }

var A_arbace_g2a_build_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_fail_A_invoke, New: A_arbace_g2a_build_fail_A_new, Get: A_arbace_g2a_build_fail_A_get}

var A_arbace_g2a_build_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "fail", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_fail_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_fail_A_class.Info(); i.IsInstance = A_arbace_g2a_build_fail_A_InstanceOf; i.Init = A_arbace_g2a_build_fail_A_Init; i.Table = A_arbace_g2a_build_fail_A_members; jrt.RegisterGoType(A_arbace_g2a_build_fail_A_class, reflect.TypeFor[A_arbace_g2a_build_fail_A]()) }

func A_arbace_g2a_build_forms_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_forms_dir_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_forms_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_forms_dir_A_New()}; return nil }

func A_arbace_g2a_build_forms_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_forms_dir_A_fn_class)}; return nil }

var A_arbace_g2a_build_forms_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_forms_dir_A_invoke, New: A_arbace_g2a_build_forms_dir_A_new, Get: A_arbace_g2a_build_forms_dir_A_get}

var A_arbace_g2a_build_forms_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$forms_dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "forms_dir", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_forms_dir_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_forms_dir_A_class.Info(); i.IsInstance = A_arbace_g2a_build_forms_dir_A_InstanceOf; i.Init = A_arbace_g2a_build_forms_dir_A_Init; i.Table = A_arbace_g2a_build_forms_dir_A_members; jrt.RegisterGoType(A_arbace_g2a_build_forms_dir_A_class, reflect.TypeFor[A_arbace_g2a_build_forms_dir_A]()) }

func A_arbace_g2a_build_go_env_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_go_env_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_g2a_build_go_env_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_build_go_env_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_go_env_A_New()}; return nil }

func A_arbace_g2a_build_go_env_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_go_env_A_fn_class)}; return nil }

var A_arbace_g2a_build_go_env_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_go_env_A_invoke, New: A_arbace_g2a_build_go_env_A_new, Get: A_arbace_g2a_build_go_env_A_get}

var A_arbace_g2a_build_go_env_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$go_env", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "go_env", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_go_env_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_go_env_A_class.Info(); i.IsInstance = A_arbace_g2a_build_go_env_A_InstanceOf; i.Init = A_arbace_g2a_build_go_env_A_Init; i.Table = A_arbace_g2a_build_go_env_A_members; jrt.RegisterGoType(A_arbace_g2a_build_go_env_A_class, reflect.TypeFor[A_arbace_g2a_build_go_env_A]()) }

func A_arbace_g2a_build_go_mod_cache_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_go_mod_cache_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_go_mod_cache_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_go_mod_cache_A_New()}; return nil }

func A_arbace_g2a_build_go_mod_cache_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_go_mod_cache_A_fn_class)}; return nil }

var A_arbace_g2a_build_go_mod_cache_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_go_mod_cache_A_invoke, New: A_arbace_g2a_build_go_mod_cache_A_new, Get: A_arbace_g2a_build_go_mod_cache_A_get}

var A_arbace_g2a_build_go_mod_cache_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$go_mod_cache", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "go_mod_cache", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_go_mod_cache_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_go_mod_cache_A_class.Info(); i.IsInstance = A_arbace_g2a_build_go_mod_cache_A_InstanceOf; i.Init = A_arbace_g2a_build_go_mod_cache_A_Init; i.Table = A_arbace_g2a_build_go_mod_cache_A_members; jrt.RegisterGoType(A_arbace_g2a_build_go_mod_cache_A_class, reflect.TypeFor[A_arbace_g2a_build_go_mod_cache_A]()) }

func A_arbace_g2a_build_h1_of_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_h1_of_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_h1_of_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_h1_of_file_A_New()}; return nil }

func A_arbace_g2a_build_h1_of_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_h1_of_file_A_fn_class)}; return nil }

var A_arbace_g2a_build_h1_of_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_h1_of_file_A_invoke, New: A_arbace_g2a_build_h1_of_file_A_new, Get: A_arbace_g2a_build_h1_of_file_A_get}

var A_arbace_g2a_build_h1_of_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$h1_of_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "h1_of_file", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_h1_of_file_A_class.Info(); i.IsInstance = A_arbace_g2a_build_h1_of_file_A_InstanceOf; i.Init = A_arbace_g2a_build_h1_of_file_A_Init; i.Table = A_arbace_g2a_build_h1_of_file_A_members; jrt.RegisterGoType(A_arbace_g2a_build_h1_of_file_A_class, reflect.TypeFor[A_arbace_g2a_build_h1_of_file_A]()) }

func A_arbace_g2a_build_h1_of_file_hex__715000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_h1_of_file_hex__715000120_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_h1_of_file_hex__715000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_h1_of_file_hex__715000120_A_New()}; return nil }

func A_arbace_g2a_build_h1_of_file_hex__715000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_h1_of_file_hex__715000120_A_fn_class)}; return nil }

var A_arbace_g2a_build_h1_of_file_hex__715000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_h1_of_file_hex__715000120_A_invoke, New: A_arbace_g2a_build_h1_of_file_hex__715000120_A_new, Get: A_arbace_g2a_build_h1_of_file_hex__715000120_A_get}

var A_arbace_g2a_build_h1_of_file_hex__715000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$h1_of_file$hex__715000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_h1_of_file_A_class, Simple: "hex__715000120", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_hex__715000120_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_h1_of_file_hex__715000120_A_class.Info(); i.IsInstance = A_arbace_g2a_build_h1_of_file_hex__715000120_A_InstanceOf; i.Init = A_arbace_g2a_build_h1_of_file_hex__715000120_A_Init; i.Table = A_arbace_g2a_build_h1_of_file_hex__715000120_A_members; jrt.RegisterGoType(A_arbace_g2a_build_h1_of_file_hex__715000120_A_class, reflect.TypeFor[A_arbace_g2a_build_h1_of_file_hex__715000120_A]()) }

func A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_New()}; return nil }

func A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_fn_class)}; return nil }

var A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_invoke, New: A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_new, Get: A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_get}

var A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$h1_of_file$hex__715000120$fn__715000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_h1_of_file_hex__715000120_A_class, Simple: "fn__715000121", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_class.Info(); i.IsInstance = A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_InstanceOf; i.Init = A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_Init; i.Table = A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_members; jrt.RegisterGoType(A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A_class, reflect.TypeFor[A_arbace_g2a_build_h1_of_file_hex__715000120_fn__715000121_A]()) }

func A_arbace_g2a_build_h1_of_file_sha__715000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_h1_of_file_sha__715000124_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_h1_of_file_sha__715000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_h1_of_file_sha__715000124_A_New()}; return nil }

func A_arbace_g2a_build_h1_of_file_sha__715000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_h1_of_file_sha__715000124_A_fn_class)}; return nil }

var A_arbace_g2a_build_h1_of_file_sha__715000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_h1_of_file_sha__715000124_A_invoke, New: A_arbace_g2a_build_h1_of_file_sha__715000124_A_new, Get: A_arbace_g2a_build_h1_of_file_sha__715000124_A_get}

var A_arbace_g2a_build_h1_of_file_sha__715000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$h1_of_file$sha__715000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_h1_of_file_A_class, Simple: "sha__715000124", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_h1_of_file_sha__715000124_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_h1_of_file_sha__715000124_A_class.Info(); i.IsInstance = A_arbace_g2a_build_h1_of_file_sha__715000124_A_InstanceOf; i.Init = A_arbace_g2a_build_h1_of_file_sha__715000124_A_Init; i.Table = A_arbace_g2a_build_h1_of_file_sha__715000124_A_members; jrt.RegisterGoType(A_arbace_g2a_build_h1_of_file_sha__715000124_A_class, reflect.TypeFor[A_arbace_g2a_build_h1_of_file_sha__715000124_A]()) }

func A_arbace_g2a_build_package_file_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_package_file_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_package_file_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_package_file_QMARK__A_New()}; return nil }

func A_arbace_g2a_build_package_file_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_package_file_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_build_package_file_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_package_file_QMARK__A_invoke, New: A_arbace_g2a_build_package_file_QMARK__A_new, Get: A_arbace_g2a_build_package_file_QMARK__A_get}

var A_arbace_g2a_build_package_file_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$package_file_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "package_file_QMARK_", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_package_file_QMARK__A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_package_file_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_build_package_file_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_build_package_file_QMARK__A_Init; i.Table = A_arbace_g2a_build_package_file_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_build_package_file_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_build_package_file_QMARK__A]()) }

func A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_package_file_QMARK__fn__715000027_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_New()}; return nil }

func A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_fn_class)}; return nil }

var A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_invoke, New: A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_new, Get: A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_get}

var A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$package_file_QMARK_$fn__715000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_package_file_QMARK__A_class, Simple: "fn__715000027", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_package_file_QMARK__fn__715000027_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_class.Info(); i.IsInstance = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_InstanceOf; i.Init = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_Init; i.Table = A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_members; jrt.RegisterGoType(A_arbace_g2a_build_package_file_QMARK__fn__715000027_A_class, reflect.TypeFor[A_arbace_g2a_build_package_file_QMARK__fn__715000027_A]()) }

func A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_package_file_QMARK__fn__715000029_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_fn_class)}; return nil }

var A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_invoke, New: A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_new, Get: A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_get}

var A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$package_file_QMARK_$fn__715000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_package_file_QMARK__A_class, Simple: "fn__715000029", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_package_file_QMARK__fn__715000029_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_class.Info(); i.IsInstance = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_InstanceOf; i.Init = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_Init; i.Table = A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_members; jrt.RegisterGoType(A_arbace_g2a_build_package_file_QMARK__fn__715000029_A_class, reflect.TypeFor[A_arbace_g2a_build_package_file_QMARK__fn__715000029_A]()) }

func A_arbace_g2a_build_packages_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_g2a_build_packages_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_packages_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_A_New()}; return nil }

func A_arbace_g2a_build_packages_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_A_invoke, New: A_arbace_g2a_build_packages_A_new, Get: A_arbace_g2a_build_packages_A_get}

var A_arbace_g2a_build_packages_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "packages", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_A_Init; i.Table = A_arbace_g2a_build_packages_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_A]()) }

func A_arbace_g2a_build_packages_fn__715000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_fn__715000057_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_packages_fn__715000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_fn__715000057_A_New()}; return nil }

func A_arbace_g2a_build_packages_fn__715000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_fn__715000057_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_fn__715000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_fn__715000057_A_invoke, New: A_arbace_g2a_build_packages_fn__715000057_A_new, Get: A_arbace_g2a_build_packages_fn__715000057_A_get}

var A_arbace_g2a_build_packages_fn__715000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$fn__715000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_packages_A_class, Simple: "fn__715000057", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_fn__715000057_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_fn__715000057_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_fn__715000057_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_fn__715000057_A_Init; i.Table = A_arbace_g2a_build_packages_fn__715000057_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_fn__715000057_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_fn__715000057_A]()) }

func A_arbace_g2a_build_packages_fn__715000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_fn__715000062_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_packages_fn__715000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_fn__715000062_A_New()}; return nil }

func A_arbace_g2a_build_packages_fn__715000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_fn__715000062_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_fn__715000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_fn__715000062_A_invoke, New: A_arbace_g2a_build_packages_fn__715000062_A_new, Get: A_arbace_g2a_build_packages_fn__715000062_A_get}

var A_arbace_g2a_build_packages_fn__715000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$fn__715000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_packages_A_class, Simple: "fn__715000062", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_fn__715000062_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_fn__715000062_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_fn__715000062_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_fn__715000062_A_Init; i.Table = A_arbace_g2a_build_packages_fn__715000062_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_fn__715000062_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_fn__715000062_A]()) }

func A_arbace_g2a_build_packages_iter__715000034__715000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_iter__715000034__715000040_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_iter__715000034__715000040_A_New()}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_iter__715000034__715000040_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_iter__715000034__715000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_iter__715000034__715000040_A_invoke, New: A_arbace_g2a_build_packages_iter__715000034__715000040_A_new, Get: A_arbace_g2a_build_packages_iter__715000034__715000040_A_get}

var A_arbace_g2a_build_packages_iter__715000034__715000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$iter__715000034__715000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_packages_A_class, Simple: "iter__715000034__715000040", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_iter__715000034__715000040_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_iter__715000034__715000040_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_iter__715000034__715000040_A_Init; i.Table = A_arbace_g2a_build_packages_iter__715000034__715000040_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_iter__715000034__715000040_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_iter__715000034__715000040_A]()) }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_invoke, New: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_new, Get: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_get}

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_packages_iter__715000034__715000040_A_class, Simple: "fn__715000041", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_Init; i.Table = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A]()) }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_New()}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_invoke, New: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_new, Get: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_get}

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_A_class, Simple: "iter__715000036__715000042", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_Init; i.Table = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A]()) }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_invoke, New: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_new, Get: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_get}

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_A_class, Simple: "fn__715000043", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_Init; i.Table = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A]()) }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_fn_class)}; return nil }

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_invoke, New: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_new, Get: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_get}

var A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043$fn__715000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_A_class, Simple: "fn__715000044", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_class.Info(); i.IsInstance = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_InstanceOf; i.Init = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_Init; i.Table = A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_members; jrt.RegisterGoType(A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A_class, reflect.TypeFor[A_arbace_g2a_build_packages_iter__715000034__715000040_fn__715000041_iter__715000036__715000042_fn__715000043_fn__715000044_A]()) }

func A_arbace_g2a_build_print_cache_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_cache_key_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_build_print_cache_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_cache_key_A_New()}; return nil }

func A_arbace_g2a_build_print_cache_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_cache_key_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_cache_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_cache_key_A_invoke, New: A_arbace_g2a_build_print_cache_key_A_new, Get: A_arbace_g2a_build_print_cache_key_A_get}

var A_arbace_g2a_build_print_cache_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_cache_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "print_cache_key", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_cache_key_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_cache_key_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_cache_key_A_InstanceOf; i.Init = A_arbace_g2a_build_print_cache_key_A_Init; i.Table = A_arbace_g2a_build_print_cache_key_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_cache_key_A_class, reflect.TypeFor[A_arbace_g2a_build_print_cache_key_A]()) }

func A_arbace_g2a_build_print_cache_key_add__715000172_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_cache_key_add__715000172_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_print_cache_key_add__715000172_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_cache_key_add__715000172_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_print_cache_key_add__715000172_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_cache_key_add__715000172_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_cache_key_add__715000172_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_cache_key_add__715000172_A_invoke, New: A_arbace_g2a_build_print_cache_key_add__715000172_A_new, Get: A_arbace_g2a_build_print_cache_key_add__715000172_A_get}

var A_arbace_g2a_build_print_cache_key_add__715000172_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_cache_key$add__715000172", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_print_cache_key_A_class, Simple: "add__715000172", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_cache_key_add__715000172_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_cache_key_add__715000172_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_cache_key_add__715000172_A_InstanceOf; i.Init = A_arbace_g2a_build_print_cache_key_add__715000172_A_Init; i.Table = A_arbace_g2a_build_print_cache_key_add__715000172_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_cache_key_add__715000172_A_class, reflect.TypeFor[A_arbace_g2a_build_print_cache_key_add__715000172_A]()) }

func A_arbace_g2a_build_print_cache_key_fn__715000178_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_cache_key_fn__715000178_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_print_cache_key_fn__715000178_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_cache_key_fn__715000178_A_New()}; return nil }

func A_arbace_g2a_build_print_cache_key_fn__715000178_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_cache_key_fn__715000178_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_cache_key_fn__715000178_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_cache_key_fn__715000178_A_invoke, New: A_arbace_g2a_build_print_cache_key_fn__715000178_A_new, Get: A_arbace_g2a_build_print_cache_key_fn__715000178_A_get}

var A_arbace_g2a_build_print_cache_key_fn__715000178_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_cache_key$fn__715000178", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_print_cache_key_A_class, Simple: "fn__715000178", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_cache_key_fn__715000178_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_cache_key_fn__715000178_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_cache_key_fn__715000178_A_InstanceOf; i.Init = A_arbace_g2a_build_print_cache_key_fn__715000178_A_Init; i.Table = A_arbace_g2a_build_print_cache_key_fn__715000178_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_cache_key_fn__715000178_A_class, reflect.TypeFor[A_arbace_g2a_build_print_cache_key_fn__715000178_A]()) }

func A_arbace_g2a_build_print_module_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_module_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_build_print_module_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_module_A_New()}; return nil }

func A_arbace_g2a_build_print_module_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_module_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_module_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_module_A_invoke, New: A_arbace_g2a_build_print_module_A_new, Get: A_arbace_g2a_build_print_module_A_get}

var A_arbace_g2a_build_print_module_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_module", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "print_module", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_module_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_module_A_InstanceOf; i.Init = A_arbace_g2a_build_print_module_A_Init; i.Table = A_arbace_g2a_build_print_module_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_module_A_class, reflect.TypeFor[A_arbace_g2a_build_print_module_A]()) }

func A_arbace_g2a_build_print_module_fn__715000214_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_module_fn__715000214_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_module_fn__715000214_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_module_fn__715000214_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_module_fn__715000214_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_module_fn__715000214_A_invoke, New: A_arbace_g2a_build_print_module_fn__715000214_A_new, Get: A_arbace_g2a_build_print_module_fn__715000214_A_get}

var A_arbace_g2a_build_print_module_fn__715000214_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_module$fn__715000214", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_print_module_A_class, Simple: "fn__715000214", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_module_fn__715000214_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_module_fn__715000214_A_InstanceOf; i.Init = A_arbace_g2a_build_print_module_fn__715000214_A_Init; i.Table = A_arbace_g2a_build_print_module_fn__715000214_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_module_fn__715000214_A_class, reflect.TypeFor[A_arbace_g2a_build_print_module_fn__715000214_A]()) }

func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_invoke, New: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_new, Get: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_get}

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_module$fn__715000214$fn__715000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_print_module_fn__715000214_A_class, Simple: "fn__715000216", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_InstanceOf; i.Init = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_Init; i.Table = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class, reflect.TypeFor[A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A]()) }

func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_invoke, New: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_new, Get: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_get}

var A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_module$fn__715000214$fn__715000216$fn__715000217", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_A_class, Simple: "fn__715000217", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_InstanceOf; i.Init = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_Init; i.Table = A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A_class, reflect.TypeFor[A_arbace_g2a_build_print_module_fn__715000214_fn__715000216_fn__715000217_A]()) }

func A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_fn_class)}; return nil }

var A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_invoke, New: A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_new, Get: A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_get}

var A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$print_module$fn__715000214$rel__715000221", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_print_module_fn__715000214_A_class, Simple: "rel__715000221", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_class.Info(); i.IsInstance = A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_InstanceOf; i.Init = A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_Init; i.Table = A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_members; jrt.RegisterGoType(A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A_class, reflect.TypeFor[A_arbace_g2a_build_print_module_fn__715000214_rel__715000221_A]()) }

func A_arbace_g2a_build_program_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_program_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_g2a_build_program_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_build_program_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_program_A_New()}; return nil }

func A_arbace_g2a_build_program_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_program_A_fn_class)}; return nil }

var A_arbace_g2a_build_program_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_program_A_invoke, New: A_arbace_g2a_build_program_A_new, Get: A_arbace_g2a_build_program_A_get}

var A_arbace_g2a_build_program_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$program", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "program", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_program_A_class.Info(); i.IsInstance = A_arbace_g2a_build_program_A_InstanceOf; i.Init = A_arbace_g2a_build_program_A_Init; i.Table = A_arbace_g2a_build_program_A_members; jrt.RegisterGoType(A_arbace_g2a_build_program_A_class, reflect.TypeFor[A_arbace_g2a_build_program_A]()) }

func A_arbace_g2a_build_program_fn__715000142_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_program_fn__715000142_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_program_fn__715000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_program_fn__715000142_A_New()}; return nil }

func A_arbace_g2a_build_program_fn__715000142_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_program_fn__715000142_A_fn_class)}; return nil }

var A_arbace_g2a_build_program_fn__715000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_program_fn__715000142_A_invoke, New: A_arbace_g2a_build_program_fn__715000142_A_new, Get: A_arbace_g2a_build_program_fn__715000142_A_get}

var A_arbace_g2a_build_program_fn__715000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$program$fn__715000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_program_A_class, Simple: "fn__715000142", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_fn__715000142_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_program_fn__715000142_A_class.Info(); i.IsInstance = A_arbace_g2a_build_program_fn__715000142_A_InstanceOf; i.Init = A_arbace_g2a_build_program_fn__715000142_A_Init; i.Table = A_arbace_g2a_build_program_fn__715000142_A_members; jrt.RegisterGoType(A_arbace_g2a_build_program_fn__715000142_A_class, reflect.TypeFor[A_arbace_g2a_build_program_fn__715000142_A]()) }

func A_arbace_g2a_build_program_fn__715000154_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_program_fn__715000154_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_program_fn__715000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_program_fn__715000154_A_New()}; return nil }

func A_arbace_g2a_build_program_fn__715000154_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_program_fn__715000154_A_fn_class)}; return nil }

var A_arbace_g2a_build_program_fn__715000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_program_fn__715000154_A_invoke, New: A_arbace_g2a_build_program_fn__715000154_A_new, Get: A_arbace_g2a_build_program_fn__715000154_A_get}

var A_arbace_g2a_build_program_fn__715000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$program$fn__715000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_program_A_class, Simple: "fn__715000154", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_fn__715000154_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_program_fn__715000154_A_class.Info(); i.IsInstance = A_arbace_g2a_build_program_fn__715000154_A_InstanceOf; i.Init = A_arbace_g2a_build_program_fn__715000154_A_Init; i.Table = A_arbace_g2a_build_program_fn__715000154_A_members; jrt.RegisterGoType(A_arbace_g2a_build_program_fn__715000154_A_class, reflect.TypeFor[A_arbace_g2a_build_program_fn__715000154_A]()) }

func A_arbace_g2a_build_program_iter__715000144__715000148_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_program_iter__715000144__715000148_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_program_iter__715000144__715000148_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_program_iter__715000144__715000148_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_program_iter__715000144__715000148_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_program_iter__715000144__715000148_A_fn_class)}; return nil }

var A_arbace_g2a_build_program_iter__715000144__715000148_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_program_iter__715000144__715000148_A_invoke, New: A_arbace_g2a_build_program_iter__715000144__715000148_A_new, Get: A_arbace_g2a_build_program_iter__715000144__715000148_A_get}

var A_arbace_g2a_build_program_iter__715000144__715000148_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$program$iter__715000144__715000148", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_program_A_class, Simple: "iter__715000144__715000148", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_iter__715000144__715000148_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_program_iter__715000144__715000148_A_class.Info(); i.IsInstance = A_arbace_g2a_build_program_iter__715000144__715000148_A_InstanceOf; i.Init = A_arbace_g2a_build_program_iter__715000144__715000148_A_Init; i.Table = A_arbace_g2a_build_program_iter__715000144__715000148_A_members; jrt.RegisterGoType(A_arbace_g2a_build_program_iter__715000144__715000148_A_class, reflect.TypeFor[A_arbace_g2a_build_program_iter__715000144__715000148_A]()) }

func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_fn_class)}; return nil }

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_invoke, New: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_new, Get: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_get}

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$program$iter__715000144__715000148$fn__715000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_program_iter__715000144__715000148_A_class, Simple: "fn__715000149", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class.Info(); i.IsInstance = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_InstanceOf; i.Init = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_Init; i.Table = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_members; jrt.RegisterGoType(A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class, reflect.TypeFor[A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A]()) }

func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_fn_class)}; return nil }

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_invoke, New: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_new, Get: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_get}

var A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$program$iter__715000144__715000148$fn__715000149$fn__715000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_A_class, Simple: "fn__715000150", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_class.Info(); i.IsInstance = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_InstanceOf; i.Init = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_Init; i.Table = A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_members; jrt.RegisterGoType(A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A_class, reflect.TypeFor[A_arbace_g2a_build_program_iter__715000144__715000148_fn__715000149_fn__715000150_A]()) }

func A_arbace_g2a_build_read_all_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_read_all_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_read_all_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_read_all_A_New()}; return nil }

func A_arbace_g2a_build_read_all_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_read_all_A_fn_class)}; return nil }

var A_arbace_g2a_build_read_all_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_read_all_A_invoke, New: A_arbace_g2a_build_read_all_A_new, Get: A_arbace_g2a_build_read_all_A_get}

var A_arbace_g2a_build_read_all_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$read_all", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "read_all", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_all_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_read_all_A_class.Info(); i.IsInstance = A_arbace_g2a_build_read_all_A_InstanceOf; i.Init = A_arbace_g2a_build_read_all_A_Init; i.Table = A_arbace_g2a_build_read_all_A_members; jrt.RegisterGoType(A_arbace_g2a_build_read_all_A_class, reflect.TypeFor[A_arbace_g2a_build_read_all_A]()) }

func A_arbace_g2a_build_read_all_fn__715000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_read_all_fn__715000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_read_all_fn__715000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_read_all_fn__715000066_A_New()}; return nil }

func A_arbace_g2a_build_read_all_fn__715000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_read_all_fn__715000066_A_fn_class)}; return nil }

var A_arbace_g2a_build_read_all_fn__715000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_read_all_fn__715000066_A_invoke, New: A_arbace_g2a_build_read_all_fn__715000066_A_new, Get: A_arbace_g2a_build_read_all_fn__715000066_A_get}

var A_arbace_g2a_build_read_all_fn__715000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$read_all$fn__715000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_read_all_A_class, Simple: "fn__715000066", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_all_fn__715000066_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_read_all_fn__715000066_A_class.Info(); i.IsInstance = A_arbace_g2a_build_read_all_fn__715000066_A_InstanceOf; i.Init = A_arbace_g2a_build_read_all_fn__715000066_A_Init; i.Table = A_arbace_g2a_build_read_all_fn__715000066_A_members; jrt.RegisterGoType(A_arbace_g2a_build_read_all_fn__715000066_A_class, reflect.TypeFor[A_arbace_g2a_build_read_all_fn__715000066_A]()) }

func A_arbace_g2a_build_read_all_fn__715000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_read_all_fn__715000068_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_read_all_fn__715000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_read_all_fn__715000068_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_read_all_fn__715000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_read_all_fn__715000068_A_fn_class)}; return nil }

var A_arbace_g2a_build_read_all_fn__715000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_read_all_fn__715000068_A_invoke, New: A_arbace_g2a_build_read_all_fn__715000068_A_new, Get: A_arbace_g2a_build_read_all_fn__715000068_A_get}

var A_arbace_g2a_build_read_all_fn__715000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$read_all$fn__715000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_read_all_A_class, Simple: "fn__715000068", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_all_fn__715000068_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_read_all_fn__715000068_A_class.Info(); i.IsInstance = A_arbace_g2a_build_read_all_fn__715000068_A_InstanceOf; i.Init = A_arbace_g2a_build_read_all_fn__715000068_A_Init; i.Table = A_arbace_g2a_build_read_all_fn__715000068_A_members; jrt.RegisterGoType(A_arbace_g2a_build_read_all_fn__715000068_A_class, reflect.TypeFor[A_arbace_g2a_build_read_all_fn__715000068_A]()) }

func A_arbace_g2a_build_read_program_edn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_read_program_edn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_read_program_edn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_read_program_edn_A_New()}; return nil }

func A_arbace_g2a_build_read_program_edn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_read_program_edn_A_fn_class)}; return nil }

var A_arbace_g2a_build_read_program_edn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_read_program_edn_A_invoke, New: A_arbace_g2a_build_read_program_edn_A_new, Get: A_arbace_g2a_build_read_program_edn_A_get}

var A_arbace_g2a_build_read_program_edn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$read_program_edn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "read_program_edn", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_read_program_edn_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_read_program_edn_A_class.Info(); i.IsInstance = A_arbace_g2a_build_read_program_edn_A_InstanceOf; i.Init = A_arbace_g2a_build_read_program_edn_A_Init; i.Table = A_arbace_g2a_build_read_program_edn_A_members; jrt.RegisterGoType(A_arbace_g2a_build_read_program_edn_A_class, reflect.TypeFor[A_arbace_g2a_build_read_program_edn_A]()) }

func A_arbace_g2a_build_rel_path_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_rel_path_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_build_rel_path_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_rel_path_A_New()}; return nil }

func A_arbace_g2a_build_rel_path_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_rel_path_A_fn_class)}; return nil }

var A_arbace_g2a_build_rel_path_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_rel_path_A_invoke, New: A_arbace_g2a_build_rel_path_A_new, Get: A_arbace_g2a_build_rel_path_A_get}

var A_arbace_g2a_build_rel_path_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$rel_path", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "rel_path", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_rel_path_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_rel_path_A_class.Info(); i.IsInstance = A_arbace_g2a_build_rel_path_A_InstanceOf; i.Init = A_arbace_g2a_build_rel_path_A_Init; i.Table = A_arbace_g2a_build_rel_path_A_members; jrt.RegisterGoType(A_arbace_g2a_build_rel_path_A_class, reflect.TypeFor[A_arbace_g2a_build_rel_path_A]()) }

func A_arbace_g2a_build_root_packages_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_A_New()}; return nil }

func A_arbace_g2a_build_root_packages_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_A_invoke, New: A_arbace_g2a_build_root_packages_A_new, Get: A_arbace_g2a_build_root_packages_A_get}

var A_arbace_g2a_build_root_packages_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "root_packages", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_A_Init; i.Table = A_arbace_g2a_build_root_packages_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_A]()) }

func A_arbace_g2a_build_root_packages_fn__715000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_fn__715000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_fn__715000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_fn__715000093_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_root_packages_fn__715000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_fn__715000093_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_fn__715000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_fn__715000093_A_invoke, New: A_arbace_g2a_build_root_packages_fn__715000093_A_new, Get: A_arbace_g2a_build_root_packages_fn__715000093_A_get}

var A_arbace_g2a_build_root_packages_fn__715000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$fn__715000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_root_packages_A_class, Simple: "fn__715000093", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_fn__715000093_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_fn__715000093_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_fn__715000093_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_fn__715000093_A_Init; i.Table = A_arbace_g2a_build_root_packages_fn__715000093_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_fn__715000093_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_fn__715000093_A]()) }

func A_arbace_g2a_build_root_packages_fn__715000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_fn__715000098_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_fn__715000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_fn__715000098_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_root_packages_fn__715000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_fn__715000098_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_fn__715000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_fn__715000098_A_invoke, New: A_arbace_g2a_build_root_packages_fn__715000098_A_new, Get: A_arbace_g2a_build_root_packages_fn__715000098_A_get}

var A_arbace_g2a_build_root_packages_fn__715000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$fn__715000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_root_packages_A_class, Simple: "fn__715000098", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_fn__715000098_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_fn__715000098_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_fn__715000098_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_fn__715000098_A_Init; i.Table = A_arbace_g2a_build_root_packages_fn__715000098_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_fn__715000098_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_fn__715000098_A]()) }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_iter__715000072__715000076_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_invoke, New: A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_new, Get: A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_get}

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$iter__715000072__715000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_root_packages_A_class, Simple: "iter__715000072__715000076", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_Init; i.Table = A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_iter__715000072__715000076_A]()) }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_invoke, New: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_new, Get: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_get}

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_root_packages_iter__715000072__715000076_A_class, Simple: "fn__715000077", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_Init; i.Table = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A]()) }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_invoke, New: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_new, Get: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_get}

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class, Simple: "fn__715000078", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_Init; i.Table = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A]()) }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_invoke, New: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_new, Get: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_get}

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078$fn__715000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_A_class, Simple: "fn__715000079", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_Init; i.Table = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000078_fn__715000079_A]()) }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_fn_class)}; return nil }

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_invoke, New: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_new, Get: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_get}

var A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_A_class, Simple: "fn__715000082", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_class.Info(); i.IsInstance = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_InstanceOf; i.Init = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_Init; i.Table = A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_members; jrt.RegisterGoType(A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A_class, reflect.TypeFor[A_arbace_g2a_build_root_packages_iter__715000072__715000076_fn__715000077_fn__715000082_A]()) }

func A_arbace_g2a_build_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_run_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_build_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_run_A_New()}; return nil }

func A_arbace_g2a_build_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_run_A_fn_class)}; return nil }

var A_arbace_g2a_build_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_run_A_invoke, New: A_arbace_g2a_build_run_A_new, Get: A_arbace_g2a_build_run_A_get}

var A_arbace_g2a_build_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "run", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_run_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_run_A_class.Info(); i.IsInstance = A_arbace_g2a_build_run_A_InstanceOf; i.Init = A_arbace_g2a_build_run_A_Init; i.Table = A_arbace_g2a_build_run_A_members; jrt.RegisterGoType(A_arbace_g2a_build_run_A_class, reflect.TypeFor[A_arbace_g2a_build_run_A]()) }

func A_arbace_g2a_build_sha256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_sha256_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_sha256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_sha256_A_New()}; return nil }

func A_arbace_g2a_build_sha256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_sha256_A_fn_class)}; return nil }

var A_arbace_g2a_build_sha256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_sha256_A_invoke, New: A_arbace_g2a_build_sha256_A_new, Get: A_arbace_g2a_build_sha256_A_get}

var A_arbace_g2a_build_sha256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$sha256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "sha256", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_sha256_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_sha256_A_class.Info(); i.IsInstance = A_arbace_g2a_build_sha256_A_InstanceOf; i.Init = A_arbace_g2a_build_sha256_A_Init; i.Table = A_arbace_g2a_build_sha256_A_members; jrt.RegisterGoType(A_arbace_g2a_build_sha256_A_class, reflect.TypeFor[A_arbace_g2a_build_sha256_A]()) }

func A_arbace_g2a_build_sha256_fn__715000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_sha256_fn__715000158_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_sha256_fn__715000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_sha256_fn__715000158_A_New()}; return nil }

func A_arbace_g2a_build_sha256_fn__715000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_sha256_fn__715000158_A_fn_class)}; return nil }

var A_arbace_g2a_build_sha256_fn__715000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_sha256_fn__715000158_A_invoke, New: A_arbace_g2a_build_sha256_fn__715000158_A_new, Get: A_arbace_g2a_build_sha256_fn__715000158_A_get}

var A_arbace_g2a_build_sha256_fn__715000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$sha256$fn__715000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_sha256_A_class, Simple: "fn__715000158", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_sha256_fn__715000158_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_sha256_fn__715000158_A_class.Info(); i.IsInstance = A_arbace_g2a_build_sha256_fn__715000158_A_InstanceOf; i.Init = A_arbace_g2a_build_sha256_fn__715000158_A_Init; i.Table = A_arbace_g2a_build_sha256_fn__715000158_A_members; jrt.RegisterGoType(A_arbace_g2a_build_sha256_fn__715000158_A_class, reflect.TypeFor[A_arbace_g2a_build_sha256_fn__715000158_A]()) }

func A_arbace_g2a_build_tamago_go_sum_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_tamago_go_sum_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_tamago_go_sum_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_tamago_go_sum_A_New()}; return nil }

func A_arbace_g2a_build_tamago_go_sum_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_tamago_go_sum_A_fn_class)}; return nil }

var A_arbace_g2a_build_tamago_go_sum_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_tamago_go_sum_A_invoke, New: A_arbace_g2a_build_tamago_go_sum_A_new, Get: A_arbace_g2a_build_tamago_go_sum_A_get}

var A_arbace_g2a_build_tamago_go_sum_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$tamago_go_sum", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "tamago_go_sum", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_tamago_go_sum_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_tamago_go_sum_A_class.Info(); i.IsInstance = A_arbace_g2a_build_tamago_go_sum_A_InstanceOf; i.Init = A_arbace_g2a_build_tamago_go_sum_A_Init; i.Table = A_arbace_g2a_build_tamago_go_sum_A_members; jrt.RegisterGoType(A_arbace_g2a_build_tamago_go_sum_A_class, reflect.TypeFor[A_arbace_g2a_build_tamago_go_sum_A]()) }

func A_arbace_g2a_build_toolchain_lang_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_toolchain_lang_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_toolchain_lang_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_toolchain_lang_A_New()}; return nil }

func A_arbace_g2a_build_toolchain_lang_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_toolchain_lang_A_fn_class)}; return nil }

var A_arbace_g2a_build_toolchain_lang_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_toolchain_lang_A_invoke, New: A_arbace_g2a_build_toolchain_lang_A_new, Get: A_arbace_g2a_build_toolchain_lang_A_get}

var A_arbace_g2a_build_toolchain_lang_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$toolchain_lang", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "toolchain_lang", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_toolchain_lang_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_toolchain_lang_A_class.Info(); i.IsInstance = A_arbace_g2a_build_toolchain_lang_A_InstanceOf; i.Init = A_arbace_g2a_build_toolchain_lang_A_Init; i.Table = A_arbace_g2a_build_toolchain_lang_A_members; jrt.RegisterGoType(A_arbace_g2a_build_toolchain_lang_A_class, reflect.TypeFor[A_arbace_g2a_build_toolchain_lang_A]()) }

func A_arbace_g2a_build_with_line_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_with_line_files_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_with_line_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_with_line_files_A_New()}; return nil }

func A_arbace_g2a_build_with_line_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_with_line_files_A_fn_class)}; return nil }

var A_arbace_g2a_build_with_line_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_with_line_files_A_invoke, New: A_arbace_g2a_build_with_line_files_A_new, Get: A_arbace_g2a_build_with_line_files_A_get}

var A_arbace_g2a_build_with_line_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$with_line_files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_A_class, Simple: "with_line_files", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_with_line_files_A_class.Info(); i.IsInstance = A_arbace_g2a_build_with_line_files_A_InstanceOf; i.Init = A_arbace_g2a_build_with_line_files_A_Init; i.Table = A_arbace_g2a_build_with_line_files_A_members; jrt.RegisterGoType(A_arbace_g2a_build_with_line_files_A_class, reflect.TypeFor[A_arbace_g2a_build_with_line_files_A]()) }

func A_arbace_g2a_build_with_line_files_fn__715000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_with_line_files_fn__715000164_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_with_line_files_fn__715000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_with_line_files_fn__715000164_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_with_line_files_fn__715000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_with_line_files_fn__715000164_A_fn_class)}; return nil }

var A_arbace_g2a_build_with_line_files_fn__715000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_with_line_files_fn__715000164_A_invoke, New: A_arbace_g2a_build_with_line_files_fn__715000164_A_new, Get: A_arbace_g2a_build_with_line_files_fn__715000164_A_get}

var A_arbace_g2a_build_with_line_files_fn__715000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$with_line_files$fn__715000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_with_line_files_A_class, Simple: "fn__715000164", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_fn__715000164_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_with_line_files_fn__715000164_A_class.Info(); i.IsInstance = A_arbace_g2a_build_with_line_files_fn__715000164_A_InstanceOf; i.Init = A_arbace_g2a_build_with_line_files_fn__715000164_A_Init; i.Table = A_arbace_g2a_build_with_line_files_fn__715000164_A_members; jrt.RegisterGoType(A_arbace_g2a_build_with_line_files_fn__715000164_A_class, reflect.TypeFor[A_arbace_g2a_build_with_line_files_fn__715000164_A]()) }

func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_fn_class)}; return nil }

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_invoke, New: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_new, Get: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_get}

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$with_line_files$fn__715000164$fn__715000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_with_line_files_fn__715000164_A_class, Simple: "fn__715000165", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class.Info(); i.IsInstance = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_InstanceOf; i.Init = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_Init; i.Table = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_members; jrt.RegisterGoType(A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class, reflect.TypeFor[A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A]()) }

func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_New_O(args[0])}; return nil }

func A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_fn_class)}; return nil }

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_invoke, New: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_new, Get: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_get}

var A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build$with_line_files$fn__715000164$fn__715000165$fn__715000166", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_A_class, Simple: "fn__715000166", Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_class.Info(); i.IsInstance = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_InstanceOf; i.Init = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_Init; i.Table = A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_members; jrt.RegisterGoType(A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A_class, reflect.TypeFor[A_arbace_g2a_build_with_line_files_fn__715000164_fn__715000165_fn__715000166_A]()) }

func A_arbace_g2a_build__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_build__init_A_Load__O(); case 1: return A_arbace_g2a_build__init_A_Unit0__O(); case 2: return A_arbace_g2a_build__init_A_Unit1__O(); case 3: return A_arbace_g2a_build__init_A_Unit10__O(); case 4: return A_arbace_g2a_build__init_A_Unit11__O(); case 5: return A_arbace_g2a_build__init_A_Unit12__O(); case 6: return A_arbace_g2a_build__init_A_Unit13__O(); case 7: return A_arbace_g2a_build__init_A_Unit14__O(); case 8: return A_arbace_g2a_build__init_A_Unit15__O(); case 9: return A_arbace_g2a_build__init_A_Unit16__O(); case 10: return A_arbace_g2a_build__init_A_Unit17__O(); case 11: return A_arbace_g2a_build__init_A_Unit18__O(); case 12: return A_arbace_g2a_build__init_A_Unit19__O(); case 13: return A_arbace_g2a_build__init_A_Unit2__O(); case 14: return A_arbace_g2a_build__init_A_Unit20__O(); case 15: return A_arbace_g2a_build__init_A_Unit21__O(); case 16: return A_arbace_g2a_build__init_A_Unit22__O(); case 17: return A_arbace_g2a_build__init_A_Unit23__O(); case 18: return A_arbace_g2a_build__init_A_Unit24__O(); case 19: return A_arbace_g2a_build__init_A_Unit25__O(); case 20: return A_arbace_g2a_build__init_A_Unit26__O(); case 21: return A_arbace_g2a_build__init_A_Unit27__O(); case 22: return A_arbace_g2a_build__init_A_Unit28__O(); case 23: return A_arbace_g2a_build__init_A_Unit29__O(); case 24: return A_arbace_g2a_build__init_A_Unit3__O(); case 25: return A_arbace_g2a_build__init_A_Unit30__O(); case 26: return A_arbace_g2a_build__init_A_Unit31__O(); case 27: return A_arbace_g2a_build__init_A_Unit32__O(); case 28: return A_arbace_g2a_build__init_A_Unit33__O(); case 29: return A_arbace_g2a_build__init_A_Unit34__O(); case 30: return A_arbace_g2a_build__init_A_Unit35__O(); case 31: return A_arbace_g2a_build__init_A_Unit4__O(); case 32: return A_arbace_g2a_build__init_A_Unit5__O(); case 33: return A_arbace_g2a_build__init_A_Unit6__O(); case 34: return A_arbace_g2a_build__init_A_Unit7__O(); case 35: return A_arbace_g2a_build__init_A_Unit8__O(); case 36: return A_arbace_g2a_build__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_build__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_build__init_A_New()}; return nil }

var A_arbace_g2a_build__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_build__init_A_invoke, New: A_arbace_g2a_build__init_A_new}

var A_arbace_g2a_build__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.build__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_build.A_arbace_g2a_build__init_A", Source: "build.ae"})

func init() { i := A_arbace_g2a_build__init_A_class.Info(); i.IsInstance = A_arbace_g2a_build__init_A_InstanceOf; i.Init = A_arbace_g2a_build__init_A_Init; i.Table = A_arbace_g2a_build__init_A_members; jrt.RegisterGoType(A_arbace_g2a_build__init_A_class, reflect.TypeFor[A_arbace_g2a_build__init_A]()) }
