//line a2g_strings.ae:1
package aot_arbace_g2a_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn16,arbace.g2a.printkn2,asyn1,pyn13,arbace.stringyn3,strkn3,docks16,arbace.g2a.build4,userkn4,elseyn2,nskn4,namekn4,pathkn4,filekn7,packagekn4,readkn7,versionkn3,zipkn3,modkn8,library?kn5,rootskn6,modulekn2,gokn8,packageskn4,mainkn3,dirkn5,fileskn3,srckn6,layoutkn9,line-filekn5,testskn4,gooskn6,gorootkn8,goos-dirkn11,print-cachekn5,lineskn5,gofmtkn10,test-fileskn11,other-fileskn11,embed-fileskn4,workkn6,configkn4,tagskn7,overlaykn3,pgokn12,goexperimentkn4,archkn10,print-onlykn3,outv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.g2a.buildm2,R6,s4020,g2a's program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/g2a build [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] DIR\n  bin/g2a build --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.g2a.build with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.g2a.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $G2A_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with G2A_HOST_ID set, as bin/g2a sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)v11,arbace.core13,*loaded-libs*v11,arbace.core7,ex-infov11,arbace.core5,mergem2,R7,TR8,v11,arbace.core7,sort-byv11,arbace.core6,filterv13,arbace.string10,ends-with?v11,arbace.core3,notv16,arbace.g2a.build9,data-dir?v11,arbace.core8,file-seqv11,arbace.core5,firstv16,arbace.g2a.print13,go-ns-aliasesv11,arbace.core4,somev11,arbace.core4,seq?R9,v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core9,contains?v11,arbace.core9,namespacev11,arbace.core3,strv16,arbace.g2a.build13,root-packagesv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core4,not=R10,v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core6,concatv11,arbace.core3,vecv11,arbace.core8,group-byR11,v16,arbace.g2a.build4,failv13,arbace.string4,joinv11,arbace.core3,mapR12,v11,arbace.core4,nextv16,arbace.g2a.build8,packagesv11,arbace.core6,zipmapv16,arbace.g2a.print10,read-formsv11,arbace.core4,pmapv16,arbace.g2a.build9,clj-filesv16,arbace.g2a.build8,read-allv16,arbace.g2a.build13,package-file?v11,arbace.core4,atomv16,arbace.g2a.print7,collectR13,v11,arbace.core5,assocv11,arbace.core5,swap!v11,arbace.core7,string?v16,arbace.g2a.build8,rel-pathR14,v11,arbace.core6,empty?v11,arbace.core4,map?v11,arbace.core5,slurpv16,arbace.g2a.build11,tamago-goosm2,s7,GOARM64s4,v8.0m2,s7,GOAMD64s2,v1v16,arbace.g2a.build6,go-envv16,arbace.g2a.build3,runv13,arbace.string4,trimv11,arbace.core5,applyv11,arbace.core6,formatv11,arbace.core8,to-arrayR15,R16,R17,v16,arbace.g2a.build12,go-mod-cachev16,arbace.g2a.build10,h1-of-filev11,arbace.core7,re-findp13,^go(\\d+\\.\\d+)R18,R19,v16,arbace.g2a.build16,read-program-ednR20,R21,v16,arbace.g2a.build14,toolchain-langR22,R23,v13,arbace.string12,starts-with?R24,v11,arbace.core4,subsv16,arbace.g2a.build7,programv11,arbace.core10,into-arrayC24,java.nio.file.CopyOptionl0,v16,arbace.g2a.build9,forms-dirv11,arbace.core6,updateR25,v11,arbace.core4,mapvR26,v11,arbace.core6,pr-strR27,R28,v11,arbace.core4,intov11,arbace.core10,sorted-mapv13,arbace.string11,split-linesv16,arbace.g2a.build11,delete-treev11,arbace.core4,spitv11,arbace.core4,keysR29,R30,R31,R32,R33,v16,arbace.g2a.build13,tamago-go-sumV1,s6,go.modR34,R35,v11,arbace.core3,setv16,arbace.g2a.build15,print-cache-keyC12,java.io.Filev16,arbace.g2a.build12,cached-textsv16,arbace.g2a.print11,print-formsR36,v11,arbace.core7,filtervl2,v16,arbace.g2a.build15,with-line-filesv16,arbace.g2a.build12,cache-texts!R37,v16,arbace.g2a.build9,copy-fileR38,v16,arbace.g2a.build6,sha256v11,arbace.core4,compR39,R40,v11,arbace.core10,make-arrayR41,C37,java.nio.file.attribute.FileAttributev16,arbace.g2a.build12,print-moduleR42,R43,v16,arbace.g2a.build14,tamago-ldflagsR44,R45,R46,R47,v11,arbace.core4,lastv16,arbace.g2a.build5,buildv13,arbace.string5,splitp1,/R7,v11,arbace.core7,ex-datal1,v11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,nnextv11,arbace.core6,secondv11,arbace.core7,keywordv11,arbace.core4,fnilS2,s5,amd64s5,arm64S4,ns5,linuxs6,tamagos6,darwinS3,nR34,R35,v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("G2A_GOROOT")

var Lit_2 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_3 *jrt.String = jrt.Intern("usage: bin/g2a build [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines] [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--root ROOT]... [--goos-dir DIR] DIR\n")

var Lit_4 *jrt.String = jrt.Intern("       bin/g2a build --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines] [--line-file] SRC")

var Lit_5 *jrt.String = jrt.Intern("amd64")

var Lit_6 *jrt.String = jrt.Intern("--module")

var Lit_7 *jrt.String = jrt.Intern("--print-only")

var Lit_8 *jrt.String = jrt.Intern("--tests")

var Lit_9 *jrt.String = jrt.Intern("--work")

var Lit_10 *jrt.String = jrt.Intern("--layout")

var Lit_11 *jrt.String = jrt.Intern("--goos-dir")

var Lit_12 *jrt.String = jrt.Intern("-o")

var Lit_13 *jrt.String = jrt.Intern("--arch")

var Lit_14 *jrt.String = jrt.Intern("--line-file")

var Lit_15 *jrt.String = jrt.Intern("--goos")

var Lit_16 *jrt.String = jrt.Intern("--root")

var Lit_17 *jrt.String = jrt.Intern("--overlay")

var Lit_18 *jrt.String = jrt.Intern("--print-cache")

var Lit_19 *jrt.String = jrt.Intern("--pgo")

var Lit_20 *jrt.String = jrt.Intern("-")

var Lit_21 *jrt.String = jrt.Intern("arbace.g2a.build$_main$fn__715000263")

var Lit_22 *jrt.String = jrt.Intern("arbace.g2a.build$_main$fn__715000265")

var Lit_23 *jrt.String = jrt.Intern("mod")

var Lit_24 *jrt.String = jrt.Intern("arbace.g2a.build$_main$fn__715000265$fn__715000266")

var Lit_25 *jrt.String = jrt.Intern("g2a build: ")

var Lit_26 *jrt.String = jrt.Intern("g2a-build")

var Lit_27 *jrt.String = jrt.Intern("tamago")

var Lit_28 *jrt.String = jrt.Intern("/bin/go")

var Lit_29 *jrt.String = jrt.Intern("build")

var Lit_30 *jrt.String = jrt.Intern("-trimpath")

var Lit_31 *jrt.String = jrt.Intern("-buildvcs=false")

var Lit_32 *jrt.String = jrt.Intern("-tags")

var Lit_33 *jrt.String = jrt.Intern(",")

var Lit_34 *jrt.String = jrt.Intern("-ldflags")

var Lit_35 *jrt.String = jrt.Intern("-overlay")

var Lit_36 *jrt.String = jrt.Intern("-pgo")

var Lit_37 *jrt.String = jrt.Intern("linux")

var Lit_38 *jrt.String = jrt.Intern("GOEXPERIMENT")

var Lit_39 *jrt.String = jrt.Intern(".tmp.")

var Lit_40 *jrt.String = jrt.Intern("f-")

var Lit_41 *jrt.String = jrt.Intern("names")

var Lit_42 *jrt.String = jrt.Intern("arbace.g2a.build$cache_texts_BANG_$fn__715000203")

var Lit_43 *jrt.String = jrt.Intern("\n")

var Lit_44 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts$iter__715000181__715000185")

var Lit_45 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186")

var Lit_46 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186$fn__715000187")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.build$clj_files$fn__715000020")

var Lit_48 *jrt.String = jrt.Intern("arbace.g2a.build$clj_files$fn__715000022")

var Lit_49 *jrt.String = jrt.Intern(".ae")

var Lit_50 *jrt.String = jrt.Intern(".g2a-data")

var Lit_51 *jrt.String = jrt.Intern("java.io.File")

var Lit_52 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_53 *jrt.String = jrt.Intern("java.nio.file.CopyOption")

var Lit_54 *jrt.String = jrt.Intern("java.nio.file.StandardCopyOption")

var Lit_55 *jrt.String = jrt.Intern("java.nio.file.attribute.FileAttribute")

var Lit_56 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_57 *jrt.String = jrt.Intern("GOOSPKG")

var Lit_58 *jrt.String = jrt.Intern("arm64")

var Lit_59 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_60 *jrt.String = jrt.Intern("env")

var Lit_61 *jrt.String = jrt.Intern("GOMODCACHE")

var Lit_62 *jrt.String = jrt.Intern(".")

var Lit_63 *jrt.String = jrt.Intern("GOROOT")

var Lit_64 *jrt.String = jrt.Intern("GOTOOLCHAIN")

var Lit_65 *jrt.String = jrt.Intern("local")

var Lit_66 *jrt.String = jrt.Intern("go env GOMODCACHE: ")

var Lit_67 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file$hex__715000120")

var Lit_68 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file$sha__715000124")

var Lit_69 *jrt.String = jrt.Intern("  ")

var Lit_70 *jrt.String = jrt.Intern("h1:")

var Lit_71 *jrt.String = jrt.Intern("UTF-8")

var Lit_72 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file$hex__715000120$fn__715000121")

var Lit_73 *jrt.String = jrt.Intern("%02x")

var Lit_74 *jrt.String = jrt.Intern("SHA-256")

var Lit_75 *jrt.String = jrt.Intern("arbace.g2a.build$package_file_QMARK_$fn__715000027")

var Lit_76 *jrt.String = jrt.Intern("arbace.g2a.build$package_file_QMARK_$fn__715000029")

var Lit_77 *jrt.String = jrt.Intern("package")

var Lit_78 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040")

var Lit_79 *jrt.String = jrt.Intern("two package files for ")

var Lit_80 *jrt.String = jrt.Intern(": ")

var Lit_81 *jrt.String = jrt.Intern(", ")

var Lit_82 *jrt.String = jrt.Intern("arbace.g2a.build$packages$fn__715000057")

var Lit_83 *jrt.String = jrt.Intern("arbace.g2a.build$packages$fn__715000062")

var Lit_84 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041")

var Lit_85 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042")

var Lit_86 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043")

var Lit_87 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043$fn__715000044")

var Lit_88 *jrt.String = jrt.Intern("main")

var Lit_89 *jrt.String = jrt.Intern("arbace.g2a.build$print_cache_key$add__715000172")

var Lit_90 *jrt.String = jrt.Intern("")

var Lit_91 *jrt.String = jrt.Intern("arbace.g2a.build$print_cache_key$fn__715000178")

var Lit_92 *jrt.String = jrt.Intern("std")

var Lit_93 *jrt.String = jrt.Intern("go.mod")

var Lit_94 *jrt.String = jrt.Intern("module ")

var Lit_95 *jrt.String = jrt.Intern("\n\ngo ")

var Lit_96 *jrt.String = jrt.Intern("\n// GOOSPKG, the runtime's goos (TamaGo's): imported by no package\nrequire ")

var Lit_97 *jrt.String = jrt.Intern(" ")

var Lit_98 *jrt.String = jrt.Intern("go.sum")

var Lit_99 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214")

var Lit_100 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214$fn__715000216")

var Lit_101 *jrt.String = jrt.Intern("G2A_HOST_ID")

var Lit_102 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214$rel__715000221")

var Lit_103 *jrt.String = jrt.Intern(": go/package :files ")

var Lit_104 *jrt.String = jrt.Intern(" but go/file forms ")

var Lit_105 *jrt.String = jrt.Intern(": no embedded file ")

var Lit_106 *jrt.String = jrt.Intern(": embedded file ")

var Lit_107 *jrt.String = jrt.Intern(" has sha256 ")

var Lit_108 *jrt.String = jrt.Intern(", the forms say ")

var Lit_109 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214$fn__715000216$fn__715000217")

var Lit_110 *jrt.String = jrt.Intern("/")

var Lit_111 *jrt.String = jrt.Intern("arbace.g2a.build$program$fn__715000142")

var Lit_112 *jrt.String = jrt.Intern("a program has one main package; found ")

var Lit_113 *jrt.String = jrt.Intern("no module path: give program.edn's :module or --module")

var Lit_114 *jrt.String = jrt.Intern("arbace.g2a.build$program$iter__715000144__715000148")

var Lit_115 *jrt.String = jrt.Intern("arbace.g2a.build$program$fn__715000154")

var Lit_116 *jrt.String = jrt.Intern("arbace.g2a.build$program$iter__715000144__715000148$fn__715000149")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.build$program$iter__715000144__715000148$fn__715000149$fn__715000150")

var Lit_118 *jrt.String = jrt.Intern("package ")

var Lit_119 *jrt.String = jrt.Intern(" is not in the module ")

var Lit_120 *jrt.String = jrt.Intern("arbace.g2a.build$read_all$fn__715000066")

var Lit_121 *jrt.String = jrt.Intern("arbace.g2a.build$read_all$fn__715000068")

var Lit_122 *jrt.String = jrt.Intern("program.edn")

var Lit_123 *jrt.String = jrt.Intern("program.edn must hold one map, {:module \"path\" :go \"1.N\"}")

var Lit_124 *jrt.String = jrt.Intern("go")

var Lit_125 *jrt.String = jrt.Intern("no ")

var Lit_126 *jrt.String = jrt.Intern(": the program's forms go under DIR/go (doc/go/BUILD.md)")

var Lit_127 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076")

var Lit_128 *jrt.String = jrt.Intern("no package files (ns and go/package) under ")

var Lit_129 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$fn__715000093")

var Lit_130 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$fn__715000098")

var Lit_131 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077")

var Lit_132 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078")

var Lit_133 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000082")

var Lit_134 *jrt.String = jrt.Intern(": go/package without :path")

var Lit_135 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078$fn__715000079")

var Lit_136 *jrt.String = jrt.Intern("arbace.g2a.build$sha256$fn__715000158")

var Lit_137 *jrt.String = jrt.Intern("/cache/download/")

var Lit_138 *jrt.String = jrt.Intern("/@v")

var Lit_139 *jrt.String = jrt.Intern(".ziphash")

var Lit_140 *jrt.String = jrt.Intern(".mod")

var Lit_141 *jrt.String = jrt.Intern(".zip")

var Lit_142 *jrt.String = jrt.Intern("@")

var Lit_143 *jrt.String = jrt.Intern(" is not in Go's module cache (")

var Lit_144 *jrt.String = jrt.Intern("): GOPROXY=off")

var Lit_145 *jrt.String = jrt.Intern("GOVERSION")

var Lit_146 *jrt.String = jrt.Intern("go env GOVERSION: ")

var Lit_147 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files$fn__715000164")

var Lit_148 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files$fn__715000164$fn__715000165")

var Lit_149 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files$fn__715000164$fn__715000165$fn__715000166")

var Lit_150 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,msgyn1,&yn4,datakn4,linekn6,columnkn4,filekn3,tagyn4,Fileyn7,read-fnkn8,declaredyn5,rootsyn5,filesyn3,cmdyn3,envyn8,inherit?yn6,gorootyn4,archyn4,gooskn4,pathkn7,versionkn3,zipkn3,modyn5,bytesyn4,namekn4,keysyn8,library?kn2,asyn4,optsyn3,pkgyn12,java.io.Fileyn7,host-idyn5,testsyn5,textsyn6,moduleyn8,packagesyn6,golangkn2,goyn6,layoutyn9,line-fileyn8,goos-diryn11,print-cacheyn4,workyn4,argvv11,arbace.core5,in-nsMyn16,arbace.g2a.buildm2,R0,s4020,g2a's program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/g2a build [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] DIR\n  bin/g2a build --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.g2a.build with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.g2a.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $G2A_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with G2A_HOST_ID set, as bin/g2a sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)m2,R0,s4020,g2a's program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/g2a build [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] DIR\n  bin/g2a build --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.g2a.build with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.g2a.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $G2A_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with G2A_HOST_ID set, as bin/g2a sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)R1,v16,arbace.g2a.build4,failm10,R2,TR3,L1,V3,R4,R5,V1,R6,R7,i62,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build9,data-dir?m12,R2,TR3,L1,V2,Myn3,dirm2,R10,R11,Myn1,fm2,R10,R11,R0,s166,Whether f is under a directory of data, not forms: one holding a file .g2a-data (a\n  package's embedded files, such as a2g --program's sources, doc/go/EVAL-NOTES.md).R7,i68,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build9,clj-filesm10,R2,TR3,L1,V1,Myn3,dirm2,R10,R11,R7,i77,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build13,package-file?m12,R2,TR3,L1,V2,Myn1,fm2,R10,R11,R12,R0,s109,Whether a forms file is a package file: it holds an ns form and a go/package form.\n  read-fn gives its forms.R7,i83,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build13,root-packagesm8,R13,TR7,i97,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build8,rel-pathm10,R2,TR3,L1,V2,Myn4,basem2,R10,R11,Myn1,fm2,R10,R11,R7,i99,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build8,packagesm10,R3,L2,V1,Myn3,dirm2,R10,R11,V2,Myn3,dirm2,R10,R11,R14,R0,s216,The program's packages: the package files under DIR/go, each collected (arbace.g2a.print\n  /collect) with :file (the package file) and :path; then those of each of the other roots\n  (--root), but their main packages.R7,i102,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build8,read-allm12,R2,TR3,L1,V1,R15,R0,s253,A function of a forms file giving its forms (p/read-forms), the files given read\n  beforehand, in parallel, each once: reading is most of collecting a large program on the Go\n  executable, whose reader is slower than the JVM's (doc/STANDALONE-NOTES.md).R7,i119,R8,i1,R9,s19,arbace/g2a/build.aem12,R2,TR3,L1,V1,Myn3,dirm2,R10,R11,R0,s42,The package files under DIR/go, collected.R7,i130,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build16,read-program-ednm10,R2,TR3,L1,V1,Myn3,dirm2,R10,R11,R7,i153,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build3,runm12,R2,TR3,L1,V4,R16,Myn3,dirm2,R10,R11,R17,R18,R0,s148,Runs cmd in dir with env added to the JVM's; [exit output] with output captured, or\n  [exit nil] with the child's output on the JVM's when inherit?.R7,i162,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build11,tamago-goosm8,R13,TR7,i178,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build6,go-envm10,R3,L2,V2,R19,R20,V3,R19,R20,R21,R0,s195,The build's environment: the toolchain, GOOS/ARCH (linux by default; tamago with TamaGo's\n  goos module as GOOSPKG), no cgo, nothing from the user's Go environment that could change\n  the output.R7,i180,R8,i1,R9,s19,arbace/g2a/build.aem8,R22,s27,github.com/usbarmory/tamagoR23,s7,v1.27.1R24,s47,h1:Zl4w3hu5DaogGvcLzunS4gjwNEqdjFFJedMO3pDQa5k=R25,s47,h1:nLuV/bBHbtlpWOJftse7cr219b/Z6vitr5fyv/OHkK4=m8,R7,i197,R8,i1,R9,s19,arbace/g2a/build.aeR0,s275,TamaGo's goos module, the runtime/goos implementation a GOOS=tamago build names as GOOSPKG\n  (BSD-3-Clause, LICENSE.md): its version and its go.sum hashes, pinned (the module's zip, its\n  go.mod). The build takes it from Go's module cache (GOPROXY=off) and checks the hashes.v16,arbace.g2a.build14,tamago-ldflagsm8,R7,i205,R8,i1,R9,s19,arbace/g2a/build.aeR0,s189,A box guest's link: text at 0x201000, 4 KiB segments (go-whim's guest/gotamago.go), the\n  symbol table kept (the monitor finds the board's and the runtime's symbols in it), DWARF\n  dropped.v16,arbace.g2a.build12,go-mod-cachem10,R2,TR3,L1,V1,R19,R7,i211,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build10,h1-of-filem12,R2,TR3,L1,V2,Myn4,datam2,R10,R26,R27,R0,s75,go.sum's h1 hash of one file named name (golang.org/x/mod's dirhash.Hash1).R7,i217,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build13,tamago-go-summ10,R3,L1,V1,R19,R0,s101,go.sum's lines for TamaGo's goos module, from Go's module cache, checked against the pinned\n  hashes.R7,i225,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build14,toolchain-langm12,R2,TR3,L1,V1,R19,R0,s62,The toolchain's language version, 1.N (from go env GOVERSION).R7,i241,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build7,programm10,R3,L2,V2,Myn3,dirm2,R10,R11,R19,V3,Myn3,dirm2,R10,R11,R19,m4,R28,V2,R29,R14,R30,R31,R0,s352,The program in DIR: {:module :go :main pkg :packages [pkg ...]}, every package with :dir,\n  its directory in the module (\"\" for the module's root). With :library? (opts), no main\n  package is required and :module (opts) gives the module path when program.edn does not;\n  :go (opts) the language version when program.edn does not (else the toolchain's).R7,i251,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build6,sha256m10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i286,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build9,copy-filem10,R2,TR3,L1,V2,Myn4,fromm2,R10,R11,Myn2,tom2,R10,R11,R7,i290,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build9,forms-dirm12,R2,TR3,L1,MV1,R32,m2,R10,R33,R0,s114,The package's forms directory: its package file without .ae (SPEC §4.1), where its\n  other and embedded files are.R7,i295,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build15,with-line-filesm12,R2,TR3,L1,V1,R32,R0,s348,The package's files with :src for --line-file: the forms file's path relative to the\n  package's forms directory (go/<path>/), which gc resolves in the package's directory, so\n  that -trimpath names it <package path>/<file>.ae, wherever DIR is. (A path outside the\n  package's directory would escape -trimpath's rewriting and keep the host's path.)R7,i303,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build11,delete-treem8,R13,TR7,i312,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build15,print-cache-keym12,R2,TR3,L1,V5,R34,R32,Myn3,dirm2,R10,R11,R31,R35,R0,s274,The key of a package's printed files in the print cache: the host's identity (G2A_HOST_ID:\n  the executable's and g2a's sources' hashes, bin/lib/g2a-host.bash), the options that change\n  the printing, the package's path and its forms files (their paths in dir and contents).R7,i314,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build12,cached-textsm12,R2,TR3,L1,V1,Myn5,entrym2,R10,R11,R0,s132,The printed files of a package from the print cache (its entry's mtime set: bin/arbace-go\n  trims entries unused for hours), or nil.R7,i329,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build12,cache-texts!m12,R2,TR3,L1,V2,Myn5,entrym2,R10,R11,R36,R0,s87,Records a package's printed files in the print cache, atomically (a directory renamed).R7,i340,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build12,print-modulem10,R3,L1,V4,m4,R28,V2,R37,R38,R39,R40,Myn3,dirm2,R10,R11,Myn3,outm2,R10,R11,m2,R28,V7,R41,R42,R35,R21,R19,R43,R44,R0,s709,Prints the program into the module directory out: go.mod, and per package its Go files\n  and the other and embedded files it names. Returns the printed files, relative to out.\n  The module std (the standard library, GOROOT/src) gets no go.mod: GOROOT/src's go.mod,\n  go.sum and vendor/modules.txt are files of the tree it is printed into (bin/tamago-vendor).\n  With goos-dir (GOOS=tamago), TamaGo's goos module is that directory (a replace), not Go's\n  module cache. Packages are printed in parallel. With print-cache (a directory) and the\n  environment's G2A_HOST_ID, a package printed before by the same host from the same forms is\n  taken from the cache (standalone S6: a build reprints only what changed).R7,i349,R8,i1,R9,s19,arbace/g2a/build.aem10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i419,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build5,buildm10,R3,L1,V4,Myn3,dirm2,R10,R11,R20,Myn3,outm2,R10,R11,m4,R28,V2,R45,R19,R30,R31,R0,s118,Builds the program in dir for linux/arch into out (a File); returns go build's exit\n  status, its output on the JVM's.R7,i424,R8,i1,R9,s19,arbace/g2a/build.aev16,arbace.g2a.build5,-mainm8,R3,L1,V2,R5,R46,R7,i456,R8,i1,R9,s19,arbace/g2a/build.ae")

var Lit_151 *jrt.String = jrt.Intern("arbace.g2a.build$eval715000004$loading__1927001464__auto____715000005")

var Lit_152 *jrt.String = jrt.Intern("arbace.g2a.build$eval715000008$fn__715000009")

var Lit_153 *jrt.String = jrt.Intern("arbace.g2a.build$fail")

var Lit_154 *jrt.String = jrt.Intern("arbace.g2a.build$data_dir_QMARK_")

var Lit_155 *jrt.String = jrt.Intern("arbace.g2a.build$clj_files")

var Lit_156 *jrt.String = jrt.Intern("arbace.g2a.build$package_file_QMARK_")

var Lit_157 *jrt.String = jrt.Intern("arbace.g2a.build$rel_path")

var Lit_158 *jrt.String = jrt.Intern("arbace.g2a.build$packages")

var Lit_159 *jrt.String = jrt.Intern("arbace.g2a.build$read_all")

var Lit_160 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages")

var Lit_161 *jrt.String = jrt.Intern("arbace.g2a.build$read_program_edn")

var Lit_162 *jrt.String = jrt.Intern("arbace.g2a.build$run")

var Lit_163 *jrt.String = jrt.Intern("arbace.g2a.build$go_env")

var Lit_164 *jrt.String = jrt.Intern("-T 0x201000 -R 0x1000 -w")

var Lit_165 *jrt.String = jrt.Intern("arbace.g2a.build$go_mod_cache")

var Lit_166 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file")

var Lit_167 *jrt.String = jrt.Intern("arbace.g2a.build$tamago_go_sum")

var Lit_168 *jrt.String = jrt.Intern("arbace.g2a.build$toolchain_lang")

var Lit_169 *jrt.String = jrt.Intern("arbace.g2a.build$program")

var Lit_170 *jrt.String = jrt.Intern("arbace.g2a.build$sha256")

var Lit_171 *jrt.String = jrt.Intern("arbace.g2a.build$copy_file")

var Lit_172 *jrt.String = jrt.Intern("arbace.g2a.build$forms_dir")

var Lit_173 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files")

var Lit_174 *jrt.String = jrt.Intern("arbace.g2a.build$print_cache_key")

var Lit_175 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts")

var Lit_176 *jrt.String = jrt.Intern("arbace.g2a.build$cache_texts_BANG_")

var Lit_177 *jrt.String = jrt.Intern("arbace.g2a.build$print_module")

var Lit_178 *jrt.String = jrt.Intern("arbace.g2a.build$delete_tree")

var Lit_179 *jrt.String = jrt.Intern("arbace.g2a.build$build")

var Lit_180 *jrt.String = jrt.Intern("arbace.g2a.build$_main")
