//line a2g_strings.ae:1
package aot_arbace_g2a_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.print")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("p")

var Lit_6 *jrt.String = jrt.Intern("arbace.string")

var Lit_7 *jrt.String = jrt.Intern("str")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.g2a.build")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("g2a's program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/g2a build [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] DIR\n  bin/g2a build --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.g2a.build with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.g2a.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $G2A_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with G2A_HOST_ID set, as bin/g2a sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("ex-info")

var Lit_16 *jrt.String = jrt.Intern("merge")

var Lit_17 *jrt.String = jrt.Intern("user")

var Lit_18 *jrt.String = jrt.Intern("else")

var Lit_19 *jrt.String = jrt.Intern("sort-by")

var Lit_20 *jrt.String = jrt.Intern("filter")

var Lit_21 *jrt.String = jrt.Intern("ends-with?")

var Lit_22 *jrt.String = jrt.Intern("not")

var Lit_23 *jrt.String = jrt.Intern("data-dir?")

var Lit_24 *jrt.String = jrt.Intern("file-seq")

var Lit_25 *jrt.String = jrt.Intern("first")

var Lit_26 *jrt.String = jrt.Intern("go-ns-aliases")

var Lit_27 *jrt.String = jrt.Intern("some")

var Lit_28 *jrt.String = jrt.Intern("seq?")

var Lit_29 *jrt.String = jrt.Intern("ns")

var Lit_30 *jrt.String = jrt.Intern("symbol?")

var Lit_31 *jrt.String = jrt.Intern("name")

var Lit_32 *jrt.String = jrt.Intern("contains?")

var Lit_33 *jrt.String = jrt.Intern("namespace")

var Lit_34 *jrt.String = jrt.Intern("root-packages")

var Lit_35 *jrt.String = jrt.Intern("seq")

var Lit_36 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_37 *jrt.String = jrt.Intern("chunk-first")

var Lit_38 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_39 *jrt.String = jrt.Intern("not=")

var Lit_40 *jrt.String = jrt.Intern("chunk-append")

var Lit_41 *jrt.String = jrt.Intern("chunk-cons")

var Lit_42 *jrt.String = jrt.Intern("cons")

var Lit_43 *jrt.String = jrt.Intern("chunk")

var Lit_44 *jrt.String = jrt.Intern("chunk-rest")

var Lit_45 *jrt.String = jrt.Intern("rest")

var Lit_46 *jrt.String = jrt.Intern("concat")

var Lit_47 *jrt.String = jrt.Intern("vec")

var Lit_48 *jrt.String = jrt.Intern("group-by")

var Lit_49 *jrt.String = jrt.Intern("path")

var Lit_50 *jrt.String = jrt.Intern("fail")

var Lit_51 *jrt.String = jrt.Intern("join")

var Lit_52 *jrt.String = jrt.Intern("map")

var Lit_53 *jrt.String = jrt.Intern("file")

var Lit_54 *jrt.String = jrt.Intern("next")

var Lit_55 *jrt.String = jrt.Intern("packages")

var Lit_56 *jrt.String = jrt.Intern("zipmap")

var Lit_57 *jrt.String = jrt.Intern("read-forms")

var Lit_58 *jrt.String = jrt.Intern("pmap")

var Lit_59 *jrt.String = jrt.Intern("clj-files")

var Lit_60 *jrt.String = jrt.Intern("read-all")

var Lit_61 *jrt.String = jrt.Intern("package-file?")

var Lit_62 *jrt.String = jrt.Intern("atom")

var Lit_63 *jrt.String = jrt.Intern("collect")

var Lit_64 *jrt.String = jrt.Intern("package")

var Lit_65 *jrt.String = jrt.Intern("assoc")

var Lit_66 *jrt.String = jrt.Intern("swap!")

var Lit_67 *jrt.String = jrt.Intern("string?")

var Lit_68 *jrt.String = jrt.Intern("rel-path")

var Lit_69 *jrt.String = jrt.Intern("read")

var Lit_70 *jrt.String = jrt.Intern("empty?")

var Lit_71 *jrt.String = jrt.Intern("map?")

var Lit_72 *jrt.String = jrt.Intern("slurp")

var Lit_73 *jrt.String = jrt.Intern("tamago-goos")

var Lit_74 *jrt.String = jrt.Intern("GOARM64")

var Lit_75 *jrt.String = jrt.Intern("v8.0")

var Lit_76 *jrt.String = jrt.Intern("GOAMD64")

var Lit_77 *jrt.String = jrt.Intern("v1")

var Lit_78 *jrt.String = jrt.Intern("go-env")

var Lit_79 *jrt.String = jrt.Intern("run")

var Lit_80 *jrt.String = jrt.Intern("trim")

var Lit_81 *jrt.String = jrt.Intern("apply")

var Lit_82 *jrt.String = jrt.Intern("format")

var Lit_83 *jrt.String = jrt.Intern("to-array")

var Lit_84 *jrt.String = jrt.Intern("version")

var Lit_85 *jrt.String = jrt.Intern("zip")

var Lit_86 *jrt.String = jrt.Intern("mod")

var Lit_87 *jrt.String = jrt.Intern("go-mod-cache")

var Lit_88 *jrt.String = jrt.Intern("h1-of-file")

var Lit_89 *jrt.String = jrt.Intern("re-find")

var Lit_90 *jrt.String = jrt.Intern("^go(\\d+\\.\\d+)")

var Lit_91 *jrt.String = jrt.Intern("library?")

var Lit_92 *jrt.String = jrt.Intern("roots")

var Lit_93 *jrt.String = jrt.Intern("read-program-edn")

var Lit_94 *jrt.String = jrt.Intern("module")

var Lit_95 *jrt.String = jrt.Intern("go")

var Lit_96 *jrt.String = jrt.Intern("toolchain-lang")

var Lit_97 *jrt.String = jrt.Intern("main")

var Lit_98 *jrt.String = jrt.Intern("starts-with?")

var Lit_99 *jrt.String = jrt.Intern("dir")

var Lit_100 *jrt.String = jrt.Intern("subs")

var Lit_101 *jrt.String = jrt.Intern("program")

var Lit_102 *jrt.String = jrt.Intern("into-array")

var Lit_103 *jrt.String = jrt.Intern("java.nio.file.CopyOption")

var Lit_104 *jrt.String = jrt.Intern("forms-dir")

var Lit_105 *jrt.String = jrt.Intern("update")

var Lit_106 *jrt.String = jrt.Intern("files")

var Lit_107 *jrt.String = jrt.Intern("mapv")

var Lit_108 *jrt.String = jrt.Intern("src")

var Lit_109 *jrt.String = jrt.Intern("pr-str")

var Lit_110 *jrt.String = jrt.Intern("layout")

var Lit_111 *jrt.String = jrt.Intern("line-file")

var Lit_112 *jrt.String = jrt.Intern("into")

var Lit_113 *jrt.String = jrt.Intern("sorted-map")

var Lit_114 *jrt.String = jrt.Intern("split-lines")

var Lit_115 *jrt.String = jrt.Intern("delete-tree")

var Lit_116 *jrt.String = jrt.Intern("spit")

var Lit_117 *jrt.String = jrt.Intern("keys")

var Lit_118 *jrt.String = jrt.Intern("tests")

var Lit_119 *jrt.String = jrt.Intern("goos")

var Lit_120 *jrt.String = jrt.Intern("goroot")

var Lit_121 *jrt.String = jrt.Intern("goos-dir")

var Lit_122 *jrt.String = jrt.Intern("print-cache")

var Lit_123 *jrt.String = jrt.Intern("tamago-go-sum")

var Lit_124 *jrt.String = jrt.Intern("go.mod")

var Lit_125 *jrt.String = jrt.Intern("lines")

var Lit_126 *jrt.String = jrt.Intern("gofmt")

var Lit_127 *jrt.String = jrt.Intern("set")

var Lit_128 *jrt.String = jrt.Intern("print-cache-key")

var Lit_129 *jrt.String = jrt.Intern("java.io.File")

var Lit_130 *jrt.String = jrt.Intern("cached-texts")

var Lit_131 *jrt.String = jrt.Intern("print-forms")

var Lit_132 *jrt.String = jrt.Intern("test-files")

var Lit_133 *jrt.String = jrt.Intern("filterv")

var Lit_134 *jrt.String = jrt.Intern("with-line-files")

var Lit_135 *jrt.String = jrt.Intern("cache-texts!")

var Lit_136 *jrt.String = jrt.Intern("other-files")

var Lit_137 *jrt.String = jrt.Intern("copy-file")

var Lit_138 *jrt.String = jrt.Intern("embed-files")

var Lit_139 *jrt.String = jrt.Intern("sha256")

var Lit_140 *jrt.String = jrt.Intern("comp")

var Lit_141 *jrt.String = jrt.Intern("work")

var Lit_142 *jrt.String = jrt.Intern("config")

var Lit_143 *jrt.String = jrt.Intern("make-array")

var Lit_144 *jrt.String = jrt.Intern("tags")

var Lit_145 *jrt.String = jrt.Intern("java.nio.file.attribute.FileAttribute")

var Lit_146 *jrt.String = jrt.Intern("print-module")

var Lit_147 *jrt.String = jrt.Intern("overlay")

var Lit_148 *jrt.String = jrt.Intern("pgo")

var Lit_149 *jrt.String = jrt.Intern("tamago-ldflags")

var Lit_150 *jrt.String = jrt.Intern("goexperiment")

var Lit_151 *jrt.String = jrt.Intern("arch")

var Lit_152 *jrt.String = jrt.Intern("print-only")

var Lit_153 *jrt.String = jrt.Intern("out")

var Lit_154 *jrt.String = jrt.Intern("last")

var Lit_155 *jrt.String = jrt.Intern("build")

var Lit_156 *jrt.String = jrt.Intern("split")

var Lit_157 *jrt.String = jrt.Intern("/")

var Lit_158 *jrt.String = jrt.Intern("ex-data")

var Lit_159 *jrt.String = jrt.Intern("println")

var Lit_160 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_161 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_162 *jrt.String = jrt.Intern("hash-map")

var Lit_163 *jrt.String = jrt.Intern("*out*")

var Lit_164 *jrt.String = jrt.Intern("*err*")

var Lit_165 *jrt.String = jrt.Intern("nnext")

var Lit_166 *jrt.String = jrt.Intern("second")

var Lit_167 *jrt.String = jrt.Intern("keyword")

var Lit_168 *jrt.String = jrt.Intern("fnil")

var Lit_169 *jrt.String = jrt.Intern("amd64")

var Lit_170 *jrt.String = jrt.Intern("arm64")

var Lit_171 *jrt.String = jrt.Intern("linux")

var Lit_172 *jrt.String = jrt.Intern("tamago")

var Lit_173 *jrt.String = jrt.Intern("darwin")

var Lit_174 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_175 *jrt.String = jrt.Intern("arbace.g2a.build$_main")

var Lit_176 *jrt.String = jrt.Intern("G2A_GOROOT")

var Lit_177 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_178 *jrt.String = jrt.Intern("usage: bin/g2a build [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines] [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--root ROOT]... [--goos-dir DIR] DIR\n")

var Lit_179 *jrt.String = jrt.Intern("       bin/g2a build --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines] [--line-file] SRC")

var Lit_180 *jrt.String = jrt.Intern("--module")

var Lit_181 *jrt.String = jrt.Intern("--print-only")

var Lit_182 *jrt.String = jrt.Intern("--tests")

var Lit_183 *jrt.String = jrt.Intern("--work")

var Lit_184 *jrt.String = jrt.Intern("--layout")

var Lit_185 *jrt.String = jrt.Intern("--goos-dir")

var Lit_186 *jrt.String = jrt.Intern("-o")

var Lit_187 *jrt.String = jrt.Intern("--arch")

var Lit_188 *jrt.String = jrt.Intern("--line-file")

var Lit_189 *jrt.String = jrt.Intern("--goos")

var Lit_190 *jrt.String = jrt.Intern("--root")

var Lit_191 *jrt.String = jrt.Intern("--overlay")

var Lit_192 *jrt.String = jrt.Intern("--print-cache")

var Lit_193 *jrt.String = jrt.Intern("--pgo")

var Lit_194 *jrt.String = jrt.Intern("-")

var Lit_195 *jrt.String = jrt.Intern("arbace.g2a.build$_main$fn__715000263")

var Lit_196 *jrt.String = jrt.Intern("arbace.g2a.build$_main$fn__715000265")

var Lit_197 *jrt.String = jrt.Intern("arbace.g2a.build$_main$fn__715000265$fn__715000266")

var Lit_198 *jrt.String = jrt.Intern("g2a build: ")

var Lit_199 *jrt.String = jrt.Intern("arbace.g2a.build$build")

var Lit_200 *jrt.String = jrt.Intern("g2a-build")

var Lit_201 *jrt.String = jrt.Intern("/bin/go")

var Lit_202 *jrt.String = jrt.Intern("-trimpath")

var Lit_203 *jrt.String = jrt.Intern("-buildvcs=false")

var Lit_204 *jrt.String = jrt.Intern("-tags")

var Lit_205 *jrt.String = jrt.Intern(",")

var Lit_206 *jrt.String = jrt.Intern("-ldflags")

var Lit_207 *jrt.String = jrt.Intern("-overlay")

var Lit_208 *jrt.String = jrt.Intern("-pgo")

var Lit_209 *jrt.String = jrt.Intern("GOEXPERIMENT")

var Lit_210 *jrt.String = jrt.Intern("arbace.g2a.build$cache_texts_BANG_")

var Lit_211 *jrt.String = jrt.Intern(".tmp.")

var Lit_212 *jrt.String = jrt.Intern("f-")

var Lit_213 *jrt.String = jrt.Intern("names")

var Lit_214 *jrt.String = jrt.Intern("arbace.g2a.build$cache_texts_BANG_$fn__715000203")

var Lit_215 *jrt.String = jrt.Intern("\n")

var Lit_216 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts")

var Lit_217 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts$iter__715000181__715000185")

var Lit_218 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186")

var Lit_219 *jrt.String = jrt.Intern("arbace.g2a.build$cached_texts$iter__715000181__715000185$fn__715000186$fn__715000187")

var Lit_220 *jrt.String = jrt.Intern("arbace.g2a.build$clj_files")

var Lit_221 *jrt.String = jrt.Intern("arbace.g2a.build$clj_files$fn__715000020")

var Lit_222 *jrt.String = jrt.Intern("arbace.g2a.build$clj_files$fn__715000022")

var Lit_223 *jrt.String = jrt.Intern(".ae")

var Lit_224 *jrt.String = jrt.Intern("arbace.g2a.build$copy_file")

var Lit_225 *jrt.String = jrt.Intern("arbace.g2a.build$data_dir_QMARK_")

var Lit_226 *jrt.String = jrt.Intern(".g2a-data")

var Lit_227 *jrt.String = jrt.Intern("arbace.g2a.build$delete_tree")

var Lit_228 *jrt.String = jrt.Intern("arbace.g2a.build$eval715000004$loading__1927001464__auto____715000005")

var Lit_229 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_230 *jrt.String = jrt.Intern("java.nio.file.StandardCopyOption")

var Lit_231 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_232 *jrt.String = jrt.Intern("arbace.g2a.build$eval715000008$fn__715000009")

var Lit_233 *jrt.String = jrt.Intern("arbace.g2a.build$fail")

var Lit_234 *jrt.String = jrt.Intern("arbace.g2a.build$forms_dir")

var Lit_235 *jrt.String = jrt.Intern("arbace.g2a.build$go_env")

var Lit_236 *jrt.String = jrt.Intern("GOOSPKG")

var Lit_237 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_238 *jrt.String = jrt.Intern("arbace.g2a.build$go_mod_cache")

var Lit_239 *jrt.String = jrt.Intern("env")

var Lit_240 *jrt.String = jrt.Intern("GOMODCACHE")

var Lit_241 *jrt.String = jrt.Intern(".")

var Lit_242 *jrt.String = jrt.Intern("GOROOT")

var Lit_243 *jrt.String = jrt.Intern("GOTOOLCHAIN")

var Lit_244 *jrt.String = jrt.Intern("local")

var Lit_245 *jrt.String = jrt.Intern("go env GOMODCACHE: ")

var Lit_246 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file")

var Lit_247 *jrt.String = jrt.Intern("  ")

var Lit_248 *jrt.String = jrt.Intern("h1:")

var Lit_249 *jrt.String = jrt.Intern("UTF-8")

var Lit_250 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file$hex__715000120")

var Lit_251 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file$hex__715000120$fn__715000121")

var Lit_252 *jrt.String = jrt.Intern("%02x")

var Lit_253 *jrt.String = jrt.Intern("arbace.g2a.build$h1_of_file$sha__715000124")

var Lit_254 *jrt.String = jrt.Intern("SHA-256")

var Lit_255 *jrt.String = jrt.Intern("arbace.g2a.build$package_file_QMARK_")

var Lit_256 *jrt.String = jrt.Intern("arbace.g2a.build$package_file_QMARK_$fn__715000027")

var Lit_257 *jrt.String = jrt.Intern("arbace.g2a.build$package_file_QMARK_$fn__715000029")

var Lit_258 *jrt.String = jrt.Intern("arbace.g2a.build$packages")

var Lit_259 *jrt.String = jrt.Intern("two package files for ")

var Lit_260 *jrt.String = jrt.Intern(": ")

var Lit_261 *jrt.String = jrt.Intern(", ")

var Lit_262 *jrt.String = jrt.Intern("arbace.g2a.build$packages$fn__715000057")

var Lit_263 *jrt.String = jrt.Intern("arbace.g2a.build$packages$fn__715000062")

var Lit_264 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040")

var Lit_265 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041")

var Lit_266 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042")

var Lit_267 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043")

var Lit_268 *jrt.String = jrt.Intern("arbace.g2a.build$packages$iter__715000034__715000040$fn__715000041$iter__715000036__715000042$fn__715000043$fn__715000044")

var Lit_269 *jrt.String = jrt.Intern("arbace.g2a.build$print_cache_key")

var Lit_270 *jrt.String = jrt.Intern("")

var Lit_271 *jrt.String = jrt.Intern("arbace.g2a.build$print_cache_key$add__715000172")

var Lit_272 *jrt.String = jrt.Intern("arbace.g2a.build$print_cache_key$fn__715000178")

var Lit_273 *jrt.String = jrt.Intern("arbace.g2a.build$print_module")

var Lit_274 *jrt.String = jrt.Intern("std")

var Lit_275 *jrt.String = jrt.Intern("module ")

var Lit_276 *jrt.String = jrt.Intern("\n\ngo ")

var Lit_277 *jrt.String = jrt.Intern("\n// GOOSPKG, the runtime's goos (TamaGo's): imported by no package\nrequire ")

var Lit_278 *jrt.String = jrt.Intern(" ")

var Lit_279 *jrt.String = jrt.Intern("go.sum")

var Lit_280 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214")

var Lit_281 *jrt.String = jrt.Intern("G2A_HOST_ID")

var Lit_282 *jrt.String = jrt.Intern(": go/package :files ")

var Lit_283 *jrt.String = jrt.Intern(" but go/file forms ")

var Lit_284 *jrt.String = jrt.Intern(": no embedded file ")

var Lit_285 *jrt.String = jrt.Intern(": embedded file ")

var Lit_286 *jrt.String = jrt.Intern(" has sha256 ")

var Lit_287 *jrt.String = jrt.Intern(", the forms say ")

var Lit_288 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214$fn__715000216")

var Lit_289 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214$fn__715000216$fn__715000217")

var Lit_290 *jrt.String = jrt.Intern("arbace.g2a.build$print_module$fn__715000214$rel__715000221")

var Lit_291 *jrt.String = jrt.Intern("arbace.g2a.build$program")

var Lit_292 *jrt.String = jrt.Intern("a program has one main package; found ")

var Lit_293 *jrt.String = jrt.Intern("no module path: give program.edn's :module or --module")

var Lit_294 *jrt.String = jrt.Intern("arbace.g2a.build$program$fn__715000142")

var Lit_295 *jrt.String = jrt.Intern("arbace.g2a.build$program$fn__715000154")

var Lit_296 *jrt.String = jrt.Intern("arbace.g2a.build$program$iter__715000144__715000148")

var Lit_297 *jrt.String = jrt.Intern("arbace.g2a.build$program$iter__715000144__715000148$fn__715000149")

var Lit_298 *jrt.String = jrt.Intern("package ")

var Lit_299 *jrt.String = jrt.Intern(" is not in the module ")

var Lit_300 *jrt.String = jrt.Intern("arbace.g2a.build$program$iter__715000144__715000148$fn__715000149$fn__715000150")

var Lit_301 *jrt.String = jrt.Intern("arbace.g2a.build$read_all")

var Lit_302 *jrt.String = jrt.Intern("arbace.g2a.build$read_all$fn__715000066")

var Lit_303 *jrt.String = jrt.Intern("arbace.g2a.build$read_all$fn__715000068")

var Lit_304 *jrt.String = jrt.Intern("arbace.g2a.build$read_program_edn")

var Lit_305 *jrt.String = jrt.Intern("program.edn")

var Lit_306 *jrt.String = jrt.Intern("program.edn must hold one map, {:module \"path\" :go \"1.N\"}")

var Lit_307 *jrt.String = jrt.Intern("arbace.g2a.build$rel_path")

var Lit_308 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages")

var Lit_309 *jrt.String = jrt.Intern("no ")

var Lit_310 *jrt.String = jrt.Intern(": the program's forms go under DIR/go (doc/go/BUILD.md)")

var Lit_311 *jrt.String = jrt.Intern("no package files (ns and go/package) under ")

var Lit_312 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$fn__715000093")

var Lit_313 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$fn__715000098")

var Lit_314 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076")

var Lit_315 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077")

var Lit_316 *jrt.String = jrt.Intern(": go/package without :path")

var Lit_317 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078")

var Lit_318 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000078$fn__715000079")

var Lit_319 *jrt.String = jrt.Intern("arbace.g2a.build$root_packages$iter__715000072__715000076$fn__715000077$fn__715000082")

var Lit_320 *jrt.String = jrt.Intern("arbace.g2a.build$run")

var Lit_321 *jrt.String = jrt.Intern("arbace.g2a.build$sha256")

var Lit_322 *jrt.String = jrt.Intern("arbace.g2a.build$sha256$fn__715000158")

var Lit_323 *jrt.String = jrt.Intern("arbace.g2a.build$tamago_go_sum")

var Lit_324 *jrt.String = jrt.Intern("/cache/download/")

var Lit_325 *jrt.String = jrt.Intern("/@v")

var Lit_326 *jrt.String = jrt.Intern(".ziphash")

var Lit_327 *jrt.String = jrt.Intern(".mod")

var Lit_328 *jrt.String = jrt.Intern(".zip")

var Lit_329 *jrt.String = jrt.Intern("@")

var Lit_330 *jrt.String = jrt.Intern(" is not in Go's module cache (")

var Lit_331 *jrt.String = jrt.Intern("): GOPROXY=off")

var Lit_332 *jrt.String = jrt.Intern("arbace.g2a.build$toolchain_lang")

var Lit_333 *jrt.String = jrt.Intern("GOVERSION")

var Lit_334 *jrt.String = jrt.Intern("go env GOVERSION: ")

var Lit_335 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files")

var Lit_336 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files$fn__715000164")

var Lit_337 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files$fn__715000164$fn__715000165")

var Lit_338 *jrt.String = jrt.Intern("arbace.g2a.build$with_line_files$fn__715000164$fn__715000165$fn__715000166")

var Lit_339 *jrt.String = jrt.Intern("in-ns")

var Lit_340 *jrt.String = jrt.Intern("private")

var Lit_341 *jrt.String = jrt.Intern("arglists")

var Lit_342 *jrt.String = jrt.Intern("msg")

var Lit_343 *jrt.String = jrt.Intern("&")

var Lit_344 *jrt.String = jrt.Intern("data")

var Lit_345 *jrt.String = jrt.Intern("line")

var Lit_346 *jrt.String = jrt.Intern("column")

var Lit_347 *jrt.String = jrt.Intern("arbace/g2a/build.ae")

var Lit_348 *jrt.String = jrt.Intern("tag")

var Lit_349 *jrt.String = jrt.Intern("File")

var Lit_350 *jrt.String = jrt.Intern("f")

var Lit_351 *jrt.String = jrt.Intern("Whether f is under a directory of data, not forms: one holding a file .g2a-data (a\n  package's embedded files, such as a2g --program's sources, doc/go/EVAL-NOTES.md).")

var Lit_352 *jrt.String = jrt.Intern("read-fn")

var Lit_353 *jrt.String = jrt.Intern("Whether a forms file is a package file: it holds an ns form and a go/package form.\n  read-fn gives its forms.")

var Lit_354 *jrt.String = jrt.Intern("declared")

var Lit_355 *jrt.String = jrt.Intern("base")

var Lit_356 *jrt.String = jrt.Intern("The program's packages: the package files under DIR/go, each collected (arbace.g2a.print\n  /collect) with :file (the package file) and :path; then those of each of the other roots\n  (--root), but their main packages.")

var Lit_357 *jrt.String = jrt.Intern("A function of a forms file giving its forms (p/read-forms), the files given read\n  beforehand, in parallel, each once: reading is most of collecting a large program on the Go\n  executable, whose reader is slower than the JVM's (doc/STANDALONE-NOTES.md).")

var Lit_358 *jrt.String = jrt.Intern("The package files under DIR/go, collected.")

var Lit_359 *jrt.String = jrt.Intern("cmd")

var Lit_360 *jrt.String = jrt.Intern("inherit?")

var Lit_361 *jrt.String = jrt.Intern("Runs cmd in dir with env added to the JVM's; [exit output] with output captured, or\n  [exit nil] with the child's output on the JVM's when inherit?.")

var Lit_362 *jrt.String = jrt.Intern("The build's environment: the toolchain, GOOS/ARCH (linux by default; tamago with TamaGo's\n  goos module as GOOSPKG), no cgo, nothing from the user's Go environment that could change\n  the output.")

var Lit_363 *jrt.String = jrt.Intern("github.com/usbarmory/tamago")

var Lit_364 *jrt.String = jrt.Intern("v1.27.1")

var Lit_365 *jrt.String = jrt.Intern("h1:Zl4w3hu5DaogGvcLzunS4gjwNEqdjFFJedMO3pDQa5k=")

var Lit_366 *jrt.String = jrt.Intern("h1:nLuV/bBHbtlpWOJftse7cr219b/Z6vitr5fyv/OHkK4=")

var Lit_367 *jrt.String = jrt.Intern("TamaGo's goos module, the runtime/goos implementation a GOOS=tamago build names as GOOSPKG\n  (BSD-3-Clause, LICENSE.md): its version and its go.sum hashes, pinned (the module's zip, its\n  go.mod). The build takes it from Go's module cache (GOPROXY=off) and checks the hashes.")

var Lit_368 *jrt.String = jrt.Intern("A box guest's link: text at 0x201000, 4 KiB segments (go-whim's guest/gotamago.go), the\n  symbol table kept (the monitor finds the board's and the runtime's symbols in it), DWARF\n  dropped.")

var Lit_369 *jrt.String = jrt.Intern("bytes")

var Lit_370 *jrt.String = jrt.Intern("go.sum's h1 hash of one file named name (golang.org/x/mod's dirhash.Hash1).")

var Lit_371 *jrt.String = jrt.Intern("go.sum's lines for TamaGo's goos module, from Go's module cache, checked against the pinned\n  hashes.")

var Lit_372 *jrt.String = jrt.Intern("The toolchain's language version, 1.N (from go env GOVERSION).")

var Lit_373 *jrt.String = jrt.Intern("opts")

var Lit_374 *jrt.String = jrt.Intern("The program in DIR: {:module :go :main pkg :packages [pkg ...]}, every package with :dir,\n  its directory in the module (\"\" for the module's root). With :library? (opts), no main\n  package is required and :module (opts) gives the module path when program.edn does not;\n  :go (opts) the language version when program.edn does not (else the toolchain's).")

var Lit_375 *jrt.String = jrt.Intern("from")

var Lit_376 *jrt.String = jrt.Intern("to")

var Lit_377 *jrt.String = jrt.Intern("pkg")

var Lit_378 *jrt.String = jrt.Intern("The package's forms directory: its package file without .ae (SPEC §4.1), where its\n  other and embedded files are.")

var Lit_379 *jrt.String = jrt.Intern("The package's files with :src for --line-file: the forms file's path relative to the\n  package's forms directory (go/<path>/), which gc resolves in the package's directory, so\n  that -trimpath names it <package path>/<file>.ae, wherever DIR is. (A path outside the\n  package's directory would escape -trimpath's rewriting and keep the host's path.)")

var Lit_380 *jrt.String = jrt.Intern("host-id")

var Lit_381 *jrt.String = jrt.Intern("The key of a package's printed files in the print cache: the host's identity (G2A_HOST_ID:\n  the executable's and g2a's sources' hashes, bin/lib/g2a-host.bash), the options that change\n  the printing, the package's path and its forms files (their paths in dir and contents).")

var Lit_382 *jrt.String = jrt.Intern("entry")

var Lit_383 *jrt.String = jrt.Intern("The printed files of a package from the print cache (its entry's mtime set: bin/arbace-go\n  trims entries unused for hours), or nil.")

var Lit_384 *jrt.String = jrt.Intern("texts")

var Lit_385 *jrt.String = jrt.Intern("Records a package's printed files in the print cache, atomically (a directory renamed).")

var Lit_386 *jrt.String = jrt.Intern("golang")

var Lit_387 *jrt.String = jrt.Intern("Prints the program into the module directory out: go.mod, and per package its Go files\n  and the other and embedded files it names. Returns the printed files, relative to out.\n  The module std (the standard library, GOROOT/src) gets no go.mod: GOROOT/src's go.mod,\n  go.sum and vendor/modules.txt are files of the tree it is printed into (bin/tamago-vendor).\n  With goos-dir (GOOS=tamago), TamaGo's goos module is that directory (a replace), not Go's\n  module cache. Packages are printed in parallel. With print-cache (a directory) and the\n  environment's G2A_HOST_ID, a package printed before by the same host from the same forms is\n  taken from the cache (standalone S6: a build reprints only what changed).")

var Lit_388 *jrt.String = jrt.Intern("Builds the program in dir for linux/arch into out (a File); returns go build's exit\n  status, its output on the JVM's.")

var Lit_389 *jrt.String = jrt.Intern("-main")

var Lit_390 *jrt.String = jrt.Intern("argv")

var Lit_391 *jrt.String = jrt.Intern("-T 0x201000 -R 0x1000 -w")
