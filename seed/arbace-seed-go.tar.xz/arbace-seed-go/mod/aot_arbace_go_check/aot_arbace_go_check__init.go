//line aot_arbace_go_check__init.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check__init_A_Unit0__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check__init_A_const_1) }
//line :1:1
func A_arbace_go_check__init_A_Unit1__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_2)) }
//line :1:1
func A_arbace_go_check__init_A_Unit2__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, nil); A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_check__init_A_Unit3__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check__init_A_const_1)).Equals_O__Z(A_arbace_go_check__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_eval1685000008_fn__1685000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, nil); A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_check__init_A_Load__O() any { A_arbace_go_check__init_A_Init(); jrt.StartCheck(); A_arbace_go_check__init_A_Unit0__O(); A_arbace_go_check__init_A_Unit1__O(); A_arbace_go_check__init_A_Unit2__O(); A_arbace_go_check__init_A_Unit3__O(); A_arbace_go_check__init_A_Unit4__O(); A_arbace_go_check__init_A_Unit5__O(); A_arbace_go_check__init_A_Unit6__O(); A_arbace_go_check__init_A_Unit7__O(); A_arbace_go_check__init_A_Unit8__O(); A_arbace_go_check__init_A_Unit9__O(); A_arbace_go_check__init_A_Unit10__O(); A_arbace_go_check__init_A_Unit11__O(); A_arbace_go_check__init_A_Unit12__O(); A_arbace_go_check__init_A_Unit13__O(); A_arbace_go_check__init_A_Unit14__O(); A_arbace_go_check__init_A_Unit15__O(); A_arbace_go_check__init_A_Unit16__O(); A_arbace_go_check__init_A_Unit17__O(); A_arbace_go_check__init_A_Unit18__O(); A_arbace_go_check__init_A_Unit19__O(); A_arbace_go_check__init_A_Unit20__O(); A_arbace_go_check__init_A_Unit21__O(); A_arbace_go_check__init_A_Unit22__O(); A_arbace_go_check__init_A_Unit23__O(); A_arbace_go_check__init_A_Unit24__O(); A_arbace_go_check__init_A_Unit25__O(); A_arbace_go_check__init_A_Unit26__O(); A_arbace_go_check__init_A_Unit27__O(); A_arbace_go_check__init_A_Unit28__O(); A_arbace_go_check__init_A_Unit29__O(); A_arbace_go_check__init_A_Unit30__O(); A_arbace_go_check__init_A_Unit31__O(); A_arbace_go_check__init_A_Unit32__O(); A_arbace_go_check__init_A_Unit33__O(); A_arbace_go_check__init_A_Unit34__O(); A_arbace_go_check__init_A_Unit35__O(); A_arbace_go_check__init_A_Unit36__O(); A_arbace_go_check__init_A_Unit37__O(); A_arbace_go_check__init_A_Unit38__O(); A_arbace_go_check__init_A_Unit39__O(); return nil }

























func A_arbace_go_check__init_A_Unit4__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_annotations_present_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_annotations_present_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, nil); A_arbace_go_check_annotations_present_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_5)); return A_arbace_go_check__init_A_const_4 }
































func A_arbace_go_check__init_A_Unit5__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_nodes_seq_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_nodes_seq_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, nil); A_arbace_go_check_nodes_seq_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_7)); return A_arbace_go_check__init_A_const_6 }
















func A_arbace_go_check__init_A_Unit6__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_verify_tags_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_verify_tags_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, nil); A_arbace_go_check_verify_tags_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_9)); return A_arbace_go_check__init_A_const_8 }



















func A_arbace_go_check__init_A_Unit7__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_file_info_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_file_info_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, nil); A_arbace_go_check_file_info_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_11)); return A_arbace_go_check__init_A_const_10 }







func A_arbace_go_check__init_A_Unit8__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_mark_qualifiers_used_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, nil); A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_13)); return A_arbace_go_check__init_A_const_12 }























func A_arbace_go_check__init_A_Unit9__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_syntactic_deps_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, nil); A_arbace_go_check_syntactic_deps_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_15)); return A_arbace_go_check__init_A_const_14 }

















func A_arbace_go_check__init_A_Unit10__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_number_local_types_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_number_local_types_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, nil); A_arbace_go_check_number_local_types_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_17)); return A_arbace_go_check__init_A_const_16 }









func A_arbace_go_check__init_A_Unit11__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_18; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__20 any = A_arbace_go_check_check_package_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_check_package_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, true, nil); A_arbace_go_check_check_package_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__20, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_19)); return A_arbace_go_check__init_A_const_18 }





























































































































































































func A_arbace_go_check__init_A_Unit12__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_session_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_session_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_go_check_session_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_21)); return A_arbace_go_check__init_A_const_20 }





func A_arbace_go_check__init_A_Unit13__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_23)); return A_arbace_go_check__init_A_const_22 }

func A_arbace_go_check__init_A_Unit14__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_ns_package_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_ns_package_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, nil); A_arbace_go_check_ns_package_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_25)); return A_arbace_go_check__init_A_const_24 }








func A_arbace_go_check__init_A_Unit15__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_resolver_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_resolver_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, nil); A_arbace_go_check_resolver_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_27)); return A_arbace_go_check__init_A_const_26 }



















func A_arbace_go_check__init_A_Unit16__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(388, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_ensure_package_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_ensure_package_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, nil); A_arbace_go_check_ensure_package_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_28)); return A_arbace_go_check__init_A_const_22 }


























func A_arbace_go_check__init_A_Unit17__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_check_check_src_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_check_src_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, nil); A_arbace_go_check_check_src_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_30)); return A_arbace_go_check__init_A_const_29 }






func A_arbace_go_check__init_A_Unit18__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(422, 1); A_arbace_go_check__init_A_const_31.BindRoot_O__V(Lit_137); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_32)); return A_arbace_go_check__init_A_const_31.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check__init_A_Unit19__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(424, 1); A_arbace_go_check__init_A_const_33.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_34)); return A_arbace_go_check__init_A_const_33.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check__init_A_Unit20__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(430, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_check_corpus_config_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_corpus_config_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_go_check_corpus_config_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_36)); return A_arbace_go_check__init_A_const_35 }

























func A_arbace_go_check__init_A_Unit21__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(456, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_check_std_session_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_std_session_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, nil); A_arbace_go_check_std_session_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_38)); return A_arbace_go_check__init_A_const_37 }



func A_arbace_go_check__init_A_Unit22__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(460, 1); A_arbace_go_check__init_A_const_39.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_39; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_40)); return A_arbace_go_check__init_A_const_39.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check__init_A_Unit23__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(464, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_check_run_parallel_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_run_parallel_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, nil); A_arbace_go_check_run_parallel_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_42)); return A_arbace_go_check__init_A_const_41 }


















func A_arbace_go_check__init_A_Unit24__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(483, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_check_result_of_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_result_of_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, nil); A_arbace_go_check_result_of_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_44)); return A_arbace_go_check__init_A_const_43 }

func A_arbace_go_check__init_A_Unit25__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(485, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_check_error_result_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_error_result_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, nil); A_arbace_go_check_error_result_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_46)); return A_arbace_go_check__init_A_const_45 }






func A_arbace_go_check__init_A_Unit26__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(492, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_check_check_corpus_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_check_corpus_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_180, false, nil); A_arbace_go_check_check_corpus_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_48)); return A_arbace_go_check__init_A_const_47 }

























































func A_arbace_go_check__init_A_Unit27__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(550, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_check_summarize_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_summarize_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_181, false, nil); A_arbace_go_check_summarize_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_50)); return A_arbace_go_check__init_A_const_49 }

























func A_arbace_go_check__init_A_Unit28__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(576, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_check_report_errors_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_report_errors_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, false, nil); A_arbace_go_check_report_errors_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_52)); return A_arbace_go_check__init_A_const_51 }







func A_arbace_go_check__init_A_Unit29__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(584, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_check_forms_source_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_forms_source_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, nil); A_arbace_go_check_forms_source_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_54)); return A_arbace_go_check__init_A_const_53 }









func A_arbace_go_check__init_A_Unit30__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_check_read_string_forms_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_read_string_forms_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_184, false, nil); A_arbace_go_check_read_string_forms_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_56)); return A_arbace_go_check__init_A_const_55 }









func A_arbace_go_check__init_A_Unit31__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(604, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_57; var tmp2 any; var root_51 any = A_arbace_go_check__init_A_const_58.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_52 == nil { tmp2 = ifn_53.Invoke_O__O(arg_54) } else { tmp2 = linked_52.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_51, arg_54) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check__init_A_const_57; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_59)); return A_arbace_go_check__init_A_const_57 }

func A_arbace_go_check__init_A_Unit32__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_check_std_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_check_std_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_185, false, nil); A_arbace_go_check_std_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_61)); return A_arbace_go_check__init_A_const_60 }







func A_arbace_go_check__init_A_Unit33__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(614, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_check_check_forms_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_check_check_forms_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_186, false, nil); A_arbace_go_check_check_forms_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_63)); return A_arbace_go_check__init_A_const_62 }











func A_arbace_go_check__init_A_Unit34__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(626, 1); A_arbace_go_check__init_A_const_64.BindRoot_O__V(A_arbace_go_check__init_A_const_65); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_66)); return A_arbace_go_check__init_A_const_64 }



func A_arbace_go_check__init_A_Unit35__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(630, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_check_write_edn_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_check_write_edn_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_187, false, nil); A_arbace_go_check_write_edn_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_68)); return A_arbace_go_check__init_A_const_67 }



func A_arbace_go_check__init_A_Unit36__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(634, 1); A_arbace_go_check__init_A_const_69.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_69; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_70)); return A_arbace_go_check__init_A_const_69.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check__init_A_Unit37__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(639, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_check_reference_path_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_check_reference_path_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_188, false, nil); A_arbace_go_check_reference_path_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_72)); return A_arbace_go_check__init_A_const_71 }




func A_arbace_go_check__init_A_Unit38__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(644, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_check_annotations_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_check_annotations_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_189, false, nil); A_arbace_go_check_annotations_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_74)); return A_arbace_go_check__init_A_const_73 }










































func A_arbace_go_check__init_A_Unit39__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_75; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__66 any = A_arbace_go_check__main_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_check__main_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, true, nil); A_arbace_go_check__main_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__66, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_76)); return A_arbace_go_check__init_A_const_75 }



type A_arbace_go_check__init_A struct{ jrt.Object }

var A_arbace_go_check__init_A_const_pool *jrt.RefArray

var A_arbace_go_check__init_A_const_0 *lang.Var

var A_arbace_go_check__init_A_const_1 any

var A_arbace_go_check__init_A_const_2 any

var A_arbace_go_check__init_A_const_3 any

var A_arbace_go_check__init_A_const_4 *lang.Var

var A_arbace_go_check__init_A_const_5 any

var A_arbace_go_check__init_A_const_6 *lang.Var

var A_arbace_go_check__init_A_const_7 any

var A_arbace_go_check__init_A_const_8 *lang.Var

var A_arbace_go_check__init_A_const_9 any

var A_arbace_go_check__init_A_const_10 *lang.Var

var A_arbace_go_check__init_A_const_11 any

var A_arbace_go_check__init_A_const_12 *lang.Var

var A_arbace_go_check__init_A_const_13 any

var A_arbace_go_check__init_A_const_14 *lang.Var

var A_arbace_go_check__init_A_const_15 any

var A_arbace_go_check__init_A_const_16 *lang.Var

var A_arbace_go_check__init_A_const_17 any

var A_arbace_go_check__init_A_const_18 *lang.Var

var A_arbace_go_check__init_A_const_19 any

var A_arbace_go_check__init_A_const_20 *lang.Var

var A_arbace_go_check__init_A_const_21 any

var A_arbace_go_check__init_A_const_22 *lang.Var

var A_arbace_go_check__init_A_const_23 any

var A_arbace_go_check__init_A_const_24 *lang.Var

var A_arbace_go_check__init_A_const_25 any

var A_arbace_go_check__init_A_const_26 *lang.Var

var A_arbace_go_check__init_A_const_27 any

var A_arbace_go_check__init_A_const_28 any

var A_arbace_go_check__init_A_const_29 *lang.Var

var A_arbace_go_check__init_A_const_30 any

var A_arbace_go_check__init_A_const_31 *lang.Var

var A_arbace_go_check__init_A_const_32 any

var A_arbace_go_check__init_A_const_33 *lang.Var

var A_arbace_go_check__init_A_const_34 any

var A_arbace_go_check__init_A_const_35 *lang.Var

var A_arbace_go_check__init_A_const_36 any

var A_arbace_go_check__init_A_const_37 *lang.Var

var A_arbace_go_check__init_A_const_38 any

var A_arbace_go_check__init_A_const_39 *lang.Var

var A_arbace_go_check__init_A_const_40 any

var A_arbace_go_check__init_A_const_41 *lang.Var

var A_arbace_go_check__init_A_const_42 any

var A_arbace_go_check__init_A_const_43 *lang.Var

var A_arbace_go_check__init_A_const_44 any

var A_arbace_go_check__init_A_const_45 *lang.Var

var A_arbace_go_check__init_A_const_46 any

var A_arbace_go_check__init_A_const_47 *lang.Var

var A_arbace_go_check__init_A_const_48 any

var A_arbace_go_check__init_A_const_49 *lang.Var

var A_arbace_go_check__init_A_const_50 any

var A_arbace_go_check__init_A_const_51 *lang.Var

var A_arbace_go_check__init_A_const_52 any

var A_arbace_go_check__init_A_const_53 *lang.Var

var A_arbace_go_check__init_A_const_54 any

var A_arbace_go_check__init_A_const_55 *lang.Var

var A_arbace_go_check__init_A_const_56 any

var A_arbace_go_check__init_A_const_57 *lang.Var

var A_arbace_go_check__init_A_const_58 *lang.Var

var A_arbace_go_check__init_A_const_59 any

var A_arbace_go_check__init_A_const_60 *lang.Var

var A_arbace_go_check__init_A_const_61 any

var A_arbace_go_check__init_A_const_62 *lang.Var

var A_arbace_go_check__init_A_const_63 any

var A_arbace_go_check__init_A_const_64 *lang.Var

var A_arbace_go_check__init_A_const_65 any

var A_arbace_go_check__init_A_const_66 any

var A_arbace_go_check__init_A_const_67 *lang.Var

var A_arbace_go_check__init_A_const_68 any

var A_arbace_go_check__init_A_const_69 *lang.Var

var A_arbace_go_check__init_A_const_70 any

var A_arbace_go_check__init_A_const_71 *lang.Var

var A_arbace_go_check__init_A_const_72 any

var A_arbace_go_check__init_A_const_73 *lang.Var

var A_arbace_go_check__init_A_const_74 any

var A_arbace_go_check__init_A_const_75 *lang.Var

var A_arbace_go_check__init_A_const_76 any

var A_arbace_go_check__init_A_init jrt.ClassInit

func A_arbace_go_check__init_A_Init() { if !A_arbace_go_check__init_A_init.Done() { A_arbace_go_check__init_A_init.Run(A_arbace_go_check__init_A_clinit) } }

func A_arbace_go_check__init_A_clinit() { A_arbace_go_check__init_A_clinit_p0(); A_arbace_go_check__init_A_clinit_p1(); A_arbace_go_check__init_A_clinit_p2(); A_arbace_go_check__init_A_clinit_p3(); A_arbace_go_check__init_A_clinit_p4(); A_arbace_go_check__init_A_clinit_p5() }

func A_arbace_go_check__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_159, 121); A_arbace_go_check__init_A_const_0 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[44]); A_arbace_go_check__init_A_const_1 = A_arbace_go_check__init_A_const_pool.A[45]; A_arbace_go_check__init_A_const_2 = A_arbace_go_check__init_A_const_pool.A[46]; A_arbace_go_check__init_A_const_3 = A_arbace_go_check__init_A_const_pool.A[47]; A_arbace_go_check__init_A_const_4 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[48]); A_arbace_go_check__init_A_const_5 = A_arbace_go_check__init_A_const_pool.A[49]; A_arbace_go_check__init_A_const_6 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[50]); A_arbace_go_check__init_A_const_7 = A_arbace_go_check__init_A_const_pool.A[51]; A_arbace_go_check__init_A_const_8 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[52]); A_arbace_go_check__init_A_const_9 = A_arbace_go_check__init_A_const_pool.A[53]; A_arbace_go_check__init_A_const_10 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[54]); A_arbace_go_check__init_A_const_11 = A_arbace_go_check__init_A_const_pool.A[55]; A_arbace_go_check__init_A_const_12 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[56]) }

func A_arbace_go_check__init_A_clinit_p1() { A_arbace_go_check__init_A_const_13 = A_arbace_go_check__init_A_const_pool.A[57]; A_arbace_go_check__init_A_const_14 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[58]); A_arbace_go_check__init_A_const_15 = A_arbace_go_check__init_A_const_pool.A[59]; A_arbace_go_check__init_A_const_16 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[60]); A_arbace_go_check__init_A_const_17 = A_arbace_go_check__init_A_const_pool.A[61]; A_arbace_go_check__init_A_const_18 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[62]); A_arbace_go_check__init_A_const_19 = A_arbace_go_check__init_A_const_pool.A[63]; A_arbace_go_check__init_A_const_20 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[64]); A_arbace_go_check__init_A_const_21 = A_arbace_go_check__init_A_const_pool.A[65]; A_arbace_go_check__init_A_const_22 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[66]); A_arbace_go_check__init_A_const_23 = A_arbace_go_check__init_A_const_pool.A[67]; A_arbace_go_check__init_A_const_24 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[68]); A_arbace_go_check__init_A_const_25 = A_arbace_go_check__init_A_const_pool.A[69] }

func A_arbace_go_check__init_A_clinit_p2() { A_arbace_go_check__init_A_const_26 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[70]); A_arbace_go_check__init_A_const_27 = A_arbace_go_check__init_A_const_pool.A[71]; A_arbace_go_check__init_A_const_28 = A_arbace_go_check__init_A_const_pool.A[72]; A_arbace_go_check__init_A_const_29 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[73]); A_arbace_go_check__init_A_const_30 = A_arbace_go_check__init_A_const_pool.A[74]; A_arbace_go_check__init_A_const_31 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[75]); A_arbace_go_check__init_A_const_32 = A_arbace_go_check__init_A_const_pool.A[76]; A_arbace_go_check__init_A_const_33 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[77]); A_arbace_go_check__init_A_const_34 = A_arbace_go_check__init_A_const_pool.A[78]; A_arbace_go_check__init_A_const_35 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[79]); A_arbace_go_check__init_A_const_36 = A_arbace_go_check__init_A_const_pool.A[80]; A_arbace_go_check__init_A_const_37 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[81]); A_arbace_go_check__init_A_const_38 = A_arbace_go_check__init_A_const_pool.A[82] }

func A_arbace_go_check__init_A_clinit_p3() { A_arbace_go_check__init_A_const_39 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[83]); A_arbace_go_check__init_A_const_40 = A_arbace_go_check__init_A_const_pool.A[84]; A_arbace_go_check__init_A_const_41 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[85]); A_arbace_go_check__init_A_const_42 = A_arbace_go_check__init_A_const_pool.A[86]; A_arbace_go_check__init_A_const_43 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[87]); A_arbace_go_check__init_A_const_44 = A_arbace_go_check__init_A_const_pool.A[88]; A_arbace_go_check__init_A_const_45 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[89]); A_arbace_go_check__init_A_const_46 = A_arbace_go_check__init_A_const_pool.A[90]; A_arbace_go_check__init_A_const_47 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[91]); A_arbace_go_check__init_A_const_48 = A_arbace_go_check__init_A_const_pool.A[92]; A_arbace_go_check__init_A_const_49 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[93]); A_arbace_go_check__init_A_const_50 = A_arbace_go_check__init_A_const_pool.A[94]; A_arbace_go_check__init_A_const_51 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[95]) }

func A_arbace_go_check__init_A_clinit_p4() { A_arbace_go_check__init_A_const_52 = A_arbace_go_check__init_A_const_pool.A[96]; A_arbace_go_check__init_A_const_53 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[97]); A_arbace_go_check__init_A_const_54 = A_arbace_go_check__init_A_const_pool.A[98]; A_arbace_go_check__init_A_const_55 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[99]); A_arbace_go_check__init_A_const_56 = A_arbace_go_check__init_A_const_pool.A[100]; A_arbace_go_check__init_A_const_57 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[101]); A_arbace_go_check__init_A_const_58 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[102]); A_arbace_go_check__init_A_const_59 = A_arbace_go_check__init_A_const_pool.A[103]; A_arbace_go_check__init_A_const_60 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[104]); A_arbace_go_check__init_A_const_61 = A_arbace_go_check__init_A_const_pool.A[105]; A_arbace_go_check__init_A_const_62 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[106]); A_arbace_go_check__init_A_const_63 = A_arbace_go_check__init_A_const_pool.A[107]; A_arbace_go_check__init_A_const_64 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[108]) }

func A_arbace_go_check__init_A_clinit_p5() { A_arbace_go_check__init_A_const_65 = A_arbace_go_check__init_A_const_pool.A[109]; A_arbace_go_check__init_A_const_66 = A_arbace_go_check__init_A_const_pool.A[110]; A_arbace_go_check__init_A_const_67 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[111]); A_arbace_go_check__init_A_const_68 = A_arbace_go_check__init_A_const_pool.A[112]; A_arbace_go_check__init_A_const_69 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[113]); A_arbace_go_check__init_A_const_70 = A_arbace_go_check__init_A_const_pool.A[114]; A_arbace_go_check__init_A_const_71 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[115]); A_arbace_go_check__init_A_const_72 = A_arbace_go_check__init_A_const_pool.A[116]; A_arbace_go_check__init_A_const_73 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[117]); A_arbace_go_check__init_A_const_74 = A_arbace_go_check__init_A_const_pool.A[118]; A_arbace_go_check__init_A_const_75 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[119]); A_arbace_go_check__init_A_const_76 = A_arbace_go_check__init_A_const_pool.A[120] }

func A_arbace_go_check__init_A_New() *A_arbace_go_check__init_A { A_arbace_go_check__init_A_Init(); t := &A_arbace_go_check__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check__init_A) Ctor() {}

func (t *A_arbace_go_check__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check__init_A_class }

func (t *A_arbace_go_check__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check__init_A); return ok }

func A_arbace_go_check__init_A_Cast(x any) *A_arbace_go_check__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check__init_A_class)) }; return v }
