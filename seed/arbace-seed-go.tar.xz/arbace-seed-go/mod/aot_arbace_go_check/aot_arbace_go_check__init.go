//line aot_arbace_go_check__init.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check__init_A_Unit0__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check__init_A_const_1) }
//line :1:1
func A_arbace_go_check__init_A_Unit1__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_2)) }
//line :1:1
func A_arbace_go_check__init_A_Unit2__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check__init_A_Unit3__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check__init_A_const_1)).Equals_O__Z(A_arbace_go_check__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_eval1685000008_fn__1685000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check__init_A_Load__O() any { A_arbace_go_check__init_A_Init(); jrt.StartCheck(); A_arbace_go_check__init_A_Unit0__O(); A_arbace_go_check__init_A_Unit1__O(); A_arbace_go_check__init_A_Unit2__O(); A_arbace_go_check__init_A_Unit3__O(); A_arbace_go_check__init_A_Unit4__O(); A_arbace_go_check__init_A_Unit5__O(); A_arbace_go_check__init_A_Unit6__O(); A_arbace_go_check__init_A_Unit7__O(); A_arbace_go_check__init_A_Unit8__O(); A_arbace_go_check__init_A_Unit9__O(); A_arbace_go_check__init_A_Unit10__O(); A_arbace_go_check__init_A_Unit11__O(); A_arbace_go_check__init_A_Unit12__O(); A_arbace_go_check__init_A_Unit13__O(); A_arbace_go_check__init_A_Unit14__O(); A_arbace_go_check__init_A_Unit15__O(); A_arbace_go_check__init_A_Unit16__O(); A_arbace_go_check__init_A_Unit17__O(); A_arbace_go_check__init_A_Unit18__O(); A_arbace_go_check__init_A_Unit19__O(); A_arbace_go_check__init_A_Unit20__O(); A_arbace_go_check__init_A_Unit21__O(); A_arbace_go_check__init_A_Unit22__O(); A_arbace_go_check__init_A_Unit23__O(); A_arbace_go_check__init_A_Unit24__O(); A_arbace_go_check__init_A_Unit25__O(); A_arbace_go_check__init_A_Unit26__O(); A_arbace_go_check__init_A_Unit27__O(); A_arbace_go_check__init_A_Unit28__O(); A_arbace_go_check__init_A_Unit29__O(); A_arbace_go_check__init_A_Unit30__O(); A_arbace_go_check__init_A_Unit31__O(); A_arbace_go_check__init_A_Unit32__O(); A_arbace_go_check__init_A_Unit33__O(); A_arbace_go_check__init_A_Unit34__O(); A_arbace_go_check__init_A_Unit35__O(); return nil }

























func A_arbace_go_check__init_A_Unit4__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_4; var tmp2 any = A_arbace_go_check_annotations_present_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_annotations_present_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_go_check_annotations_present_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_5)); return A_arbace_go_check__init_A_const_4 }
































func A_arbace_go_check__init_A_Unit5__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_6; var tmp2 any = A_arbace_go_check_nodes_seq_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_nodes_seq_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_go_check_nodes_seq_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_7)); return A_arbace_go_check__init_A_const_6 }
















func A_arbace_go_check__init_A_Unit6__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_8; var tmp2 any = A_arbace_go_check_verify_tags_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_verify_tags_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_go_check_verify_tags_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_9)); return A_arbace_go_check__init_A_const_8 }



















func A_arbace_go_check__init_A_Unit7__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_10; var tmp2 any = A_arbace_go_check_file_info_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_file_info_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_go_check_file_info_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_11)); return A_arbace_go_check__init_A_const_10 }







func A_arbace_go_check__init_A_Unit8__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_12; var tmp2 any = A_arbace_go_check_mark_qualifiers_used_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_13)); return A_arbace_go_check__init_A_const_12 }























func A_arbace_go_check__init_A_Unit9__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_14; var tmp2 any = A_arbace_go_check_syntactic_deps_BANG__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_go_check_syntactic_deps_BANG__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_15)); return A_arbace_go_check__init_A_const_14 }

















func A_arbace_go_check__init_A_Unit10__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_16; var tmp2 any = A_arbace_go_check_check_package_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_check_package_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, true); A_arbace_go_check_check_package_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_17)); return A_arbace_go_check__init_A_const_16 }















































































































































func A_arbace_go_check__init_A_Unit11__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_18; var tmp2 any = A_arbace_go_check_session_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_session_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_go_check_session_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_19)); return A_arbace_go_check__init_A_const_18 }





func A_arbace_go_check__init_A_Unit12__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(301, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_21)); return A_arbace_go_check__init_A_const_20 }

func A_arbace_go_check__init_A_Unit13__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_22; var tmp2 any = A_arbace_go_check_ns_package_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_ns_package_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_go_check_ns_package_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_23)); return A_arbace_go_check__init_A_const_22 }








func A_arbace_go_check__init_A_Unit14__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_24; var tmp2 any = A_arbace_go_check_resolver_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_resolver_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_go_check_resolver_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_25)); return A_arbace_go_check__init_A_const_24 }
















func A_arbace_go_check__init_A_Unit15__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_20; var tmp2 any = A_arbace_go_check_ensure_package_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_ensure_package_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_go_check_ensure_package_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_26)); return A_arbace_go_check__init_A_const_20 }


























func A_arbace_go_check__init_A_Unit16__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); A_arbace_go_check__init_A_const_27.BindRoot_O__V(Lit_124); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_28)); return A_arbace_go_check__init_A_const_27.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check__init_A_Unit17__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_29; var tmp2 any = A_arbace_go_check_corpus_config_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_corpus_config_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_go_check_corpus_config_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_30)); return A_arbace_go_check__init_A_const_29 }















func A_arbace_go_check__init_A_Unit18__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_31; var tmp2 any = A_arbace_go_check_std_session_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_std_session_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_go_check_std_session_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_32)); return A_arbace_go_check__init_A_const_31 }



func A_arbace_go_check__init_A_Unit19__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); A_arbace_go_check__init_A_const_33.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_34)); return A_arbace_go_check__init_A_const_33.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check__init_A_Unit20__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(382, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_35; var tmp2 any = A_arbace_go_check_run_parallel_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_run_parallel_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_go_check_run_parallel_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_36)); return A_arbace_go_check__init_A_const_35 }


















func A_arbace_go_check__init_A_Unit21__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(401, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_37; var tmp2 any = A_arbace_go_check_result_of_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_result_of_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_go_check_result_of_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_38)); return A_arbace_go_check__init_A_const_37 }

func A_arbace_go_check__init_A_Unit22__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(403, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_39; var tmp2 any = A_arbace_go_check_error_result_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_error_result_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_go_check_error_result_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_40)); return A_arbace_go_check__init_A_const_39 }






func A_arbace_go_check__init_A_Unit23__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(410, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_41; var tmp2 any = A_arbace_go_check_check_corpus_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_check_corpus_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_go_check_check_corpus_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_42)); return A_arbace_go_check__init_A_const_41 }

























































func A_arbace_go_check__init_A_Unit24__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(468, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_43; var tmp2 any = A_arbace_go_check_summarize_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_summarize_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_go_check_summarize_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_44)); return A_arbace_go_check__init_A_const_43 }

























func A_arbace_go_check__init_A_Unit25__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(494, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_45; var tmp2 any = A_arbace_go_check_report_errors_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_report_errors_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_go_check_report_errors_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_46)); return A_arbace_go_check__init_A_const_45 }







func A_arbace_go_check__init_A_Unit26__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(502, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_47; var tmp2 any = A_arbace_go_check_forms_source_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_forms_source_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_go_check_forms_source_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_48)); return A_arbace_go_check__init_A_const_47 }









func A_arbace_go_check__init_A_Unit27__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(512, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_49; var tmp2 any = A_arbace_go_check_read_string_forms_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_read_string_forms_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_go_check_read_string_forms_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_50)); return A_arbace_go_check__init_A_const_49 }









func A_arbace_go_check__init_A_Unit28__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_51; var tmp2 any; var root_24 any = A_arbace_go_check__init_A_const_52.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_24, arg_27) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check__init_A_const_51; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_53)); return A_arbace_go_check__init_A_const_51 }

func A_arbace_go_check__init_A_Unit29__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(524, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_54; var tmp2 any = A_arbace_go_check_std_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_check_std_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_go_check_std_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_55)); return A_arbace_go_check__init_A_const_54 }







func A_arbace_go_check__init_A_Unit30__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(532, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_56; var tmp2 any = A_arbace_go_check_check_forms_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_check_forms_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_go_check_check_forms_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_57)); return A_arbace_go_check__init_A_const_56 }











func A_arbace_go_check__init_A_Unit31__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(544, 1); A_arbace_go_check__init_A_const_58.BindRoot_O__V(A_arbace_go_check__init_A_const_59); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_60)); return A_arbace_go_check__init_A_const_58 }



func A_arbace_go_check__init_A_Unit32__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(548, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_61; var tmp2 any = A_arbace_go_check_write_edn_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_write_edn_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_go_check_write_edn_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_62)); return A_arbace_go_check__init_A_const_61 }



func A_arbace_go_check__init_A_Unit33__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_63; var tmp2 any = A_arbace_go_check_reference_path_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_reference_path_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_go_check_reference_path_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_64)); return A_arbace_go_check__init_A_const_63 }

func A_arbace_go_check__init_A_Unit34__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(554, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_65; var tmp2 any = A_arbace_go_check_annotations_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_check_annotations_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_go_check_annotations_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_66)); return A_arbace_go_check__init_A_const_65 }









































func A_arbace_go_check__init_A_Unit35__O() any { A_arbace_go_check__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); var tmp1 *lang.Var = A_arbace_go_check__init_A_const_67; var tmp2 any = A_arbace_go_check__main_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check__main_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, true); A_arbace_go_check__main_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_go_check__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check__init_A_const_68)); return A_arbace_go_check__init_A_const_67 }



type A_arbace_go_check__init_A struct{ jrt.Object }

var A_arbace_go_check__init_A_const_pool *jrt.RefArray

var A_arbace_go_check__init_A_const_0 *lang.Var

var A_arbace_go_check__init_A_const_1 any

var A_arbace_go_check__init_A_const_2 any

var A_arbace_go_check__init_A_const_3 any

var A_arbace_go_check__init_A_const_4 *lang.Var

var A_arbace_go_check__init_A_const_5 any

var A_arbace_go_check__init_A_const_6 *lang.Var

var A_arbace_go_check__init_A_const_7 any

var A_arbace_go_check__init_A_const_8 *lang.Var

var A_arbace_go_check__init_A_const_9 any

var A_arbace_go_check__init_A_const_10 *lang.Var

var A_arbace_go_check__init_A_const_11 any

var A_arbace_go_check__init_A_const_12 *lang.Var

var A_arbace_go_check__init_A_const_13 any

var A_arbace_go_check__init_A_const_14 *lang.Var

var A_arbace_go_check__init_A_const_15 any

var A_arbace_go_check__init_A_const_16 *lang.Var

var A_arbace_go_check__init_A_const_17 any

var A_arbace_go_check__init_A_const_18 *lang.Var

var A_arbace_go_check__init_A_const_19 any

var A_arbace_go_check__init_A_const_20 *lang.Var

var A_arbace_go_check__init_A_const_21 any

var A_arbace_go_check__init_A_const_22 *lang.Var

var A_arbace_go_check__init_A_const_23 any

var A_arbace_go_check__init_A_const_24 *lang.Var

var A_arbace_go_check__init_A_const_25 any

var A_arbace_go_check__init_A_const_26 any

var A_arbace_go_check__init_A_const_27 *lang.Var

var A_arbace_go_check__init_A_const_28 any

var A_arbace_go_check__init_A_const_29 *lang.Var

var A_arbace_go_check__init_A_const_30 any

var A_arbace_go_check__init_A_const_31 *lang.Var

var A_arbace_go_check__init_A_const_32 any

var A_arbace_go_check__init_A_const_33 *lang.Var

var A_arbace_go_check__init_A_const_34 any

var A_arbace_go_check__init_A_const_35 *lang.Var

var A_arbace_go_check__init_A_const_36 any

var A_arbace_go_check__init_A_const_37 *lang.Var

var A_arbace_go_check__init_A_const_38 any

var A_arbace_go_check__init_A_const_39 *lang.Var

var A_arbace_go_check__init_A_const_40 any

var A_arbace_go_check__init_A_const_41 *lang.Var

var A_arbace_go_check__init_A_const_42 any

var A_arbace_go_check__init_A_const_43 *lang.Var

var A_arbace_go_check__init_A_const_44 any

var A_arbace_go_check__init_A_const_45 *lang.Var

var A_arbace_go_check__init_A_const_46 any

var A_arbace_go_check__init_A_const_47 *lang.Var

var A_arbace_go_check__init_A_const_48 any

var A_arbace_go_check__init_A_const_49 *lang.Var

var A_arbace_go_check__init_A_const_50 any

var A_arbace_go_check__init_A_const_51 *lang.Var

var A_arbace_go_check__init_A_const_52 *lang.Var

var A_arbace_go_check__init_A_const_53 any

var A_arbace_go_check__init_A_const_54 *lang.Var

var A_arbace_go_check__init_A_const_55 any

var A_arbace_go_check__init_A_const_56 *lang.Var

var A_arbace_go_check__init_A_const_57 any

var A_arbace_go_check__init_A_const_58 *lang.Var

var A_arbace_go_check__init_A_const_59 any

var A_arbace_go_check__init_A_const_60 any

var A_arbace_go_check__init_A_const_61 *lang.Var

var A_arbace_go_check__init_A_const_62 any

var A_arbace_go_check__init_A_const_63 *lang.Var

var A_arbace_go_check__init_A_const_64 any

var A_arbace_go_check__init_A_const_65 *lang.Var

var A_arbace_go_check__init_A_const_66 any

var A_arbace_go_check__init_A_const_67 *lang.Var

var A_arbace_go_check__init_A_const_68 any

var A_arbace_go_check__init_A_init jrt.ClassInit

func A_arbace_go_check__init_A_Init() { if !A_arbace_go_check__init_A_init.Done() { A_arbace_go_check__init_A_init.Run(A_arbace_go_check__init_A_clinit) } }

func A_arbace_go_check__init_A_clinit() { A_arbace_go_check__init_A_clinit_p0(); A_arbace_go_check__init_A_clinit_p1(); A_arbace_go_check__init_A_clinit_p2(); A_arbace_go_check__init_A_clinit_p3(); A_arbace_go_check__init_A_clinit_p4(); A_arbace_go_check__init_A_clinit_p5() }

func A_arbace_go_check__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_146, 112); A_arbace_go_check__init_A_const_0 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[43]); A_arbace_go_check__init_A_const_1 = A_arbace_go_check__init_A_const_pool.A[44]; A_arbace_go_check__init_A_const_2 = A_arbace_go_check__init_A_const_pool.A[45]; A_arbace_go_check__init_A_const_3 = A_arbace_go_check__init_A_const_pool.A[46]; A_arbace_go_check__init_A_const_4 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[47]); A_arbace_go_check__init_A_const_5 = A_arbace_go_check__init_A_const_pool.A[48]; A_arbace_go_check__init_A_const_6 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[49]); A_arbace_go_check__init_A_const_7 = A_arbace_go_check__init_A_const_pool.A[50]; A_arbace_go_check__init_A_const_8 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[51]); A_arbace_go_check__init_A_const_9 = A_arbace_go_check__init_A_const_pool.A[52]; A_arbace_go_check__init_A_const_10 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[53]); A_arbace_go_check__init_A_const_11 = A_arbace_go_check__init_A_const_pool.A[54]; A_arbace_go_check__init_A_const_12 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[55]) }

func A_arbace_go_check__init_A_clinit_p1() { A_arbace_go_check__init_A_const_13 = A_arbace_go_check__init_A_const_pool.A[56]; A_arbace_go_check__init_A_const_14 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[57]); A_arbace_go_check__init_A_const_15 = A_arbace_go_check__init_A_const_pool.A[58]; A_arbace_go_check__init_A_const_16 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[59]); A_arbace_go_check__init_A_const_17 = A_arbace_go_check__init_A_const_pool.A[60]; A_arbace_go_check__init_A_const_18 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[61]); A_arbace_go_check__init_A_const_19 = A_arbace_go_check__init_A_const_pool.A[62]; A_arbace_go_check__init_A_const_20 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[63]); A_arbace_go_check__init_A_const_21 = A_arbace_go_check__init_A_const_pool.A[64]; A_arbace_go_check__init_A_const_22 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[65]); A_arbace_go_check__init_A_const_23 = A_arbace_go_check__init_A_const_pool.A[66]; A_arbace_go_check__init_A_const_24 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[67]); A_arbace_go_check__init_A_const_25 = A_arbace_go_check__init_A_const_pool.A[68]; A_arbace_go_check__init_A_const_26 = A_arbace_go_check__init_A_const_pool.A[69] }

func A_arbace_go_check__init_A_clinit_p2() { A_arbace_go_check__init_A_const_27 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[70]); A_arbace_go_check__init_A_const_28 = A_arbace_go_check__init_A_const_pool.A[71]; A_arbace_go_check__init_A_const_29 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[72]); A_arbace_go_check__init_A_const_30 = A_arbace_go_check__init_A_const_pool.A[73]; A_arbace_go_check__init_A_const_31 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[74]); A_arbace_go_check__init_A_const_32 = A_arbace_go_check__init_A_const_pool.A[75]; A_arbace_go_check__init_A_const_33 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[76]); A_arbace_go_check__init_A_const_34 = A_arbace_go_check__init_A_const_pool.A[77]; A_arbace_go_check__init_A_const_35 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[78]); A_arbace_go_check__init_A_const_36 = A_arbace_go_check__init_A_const_pool.A[79]; A_arbace_go_check__init_A_const_37 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[80]); A_arbace_go_check__init_A_const_38 = A_arbace_go_check__init_A_const_pool.A[81]; A_arbace_go_check__init_A_const_39 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[82]) }

func A_arbace_go_check__init_A_clinit_p3() { A_arbace_go_check__init_A_const_40 = A_arbace_go_check__init_A_const_pool.A[83]; A_arbace_go_check__init_A_const_41 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[84]); A_arbace_go_check__init_A_const_42 = A_arbace_go_check__init_A_const_pool.A[85]; A_arbace_go_check__init_A_const_43 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[86]); A_arbace_go_check__init_A_const_44 = A_arbace_go_check__init_A_const_pool.A[87]; A_arbace_go_check__init_A_const_45 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[88]); A_arbace_go_check__init_A_const_46 = A_arbace_go_check__init_A_const_pool.A[89]; A_arbace_go_check__init_A_const_47 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[90]); A_arbace_go_check__init_A_const_48 = A_arbace_go_check__init_A_const_pool.A[91]; A_arbace_go_check__init_A_const_49 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[92]); A_arbace_go_check__init_A_const_50 = A_arbace_go_check__init_A_const_pool.A[93]; A_arbace_go_check__init_A_const_51 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[94]); A_arbace_go_check__init_A_const_52 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[95]) }

func A_arbace_go_check__init_A_clinit_p4() { A_arbace_go_check__init_A_const_53 = A_arbace_go_check__init_A_const_pool.A[96]; A_arbace_go_check__init_A_const_54 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[97]); A_arbace_go_check__init_A_const_55 = A_arbace_go_check__init_A_const_pool.A[98]; A_arbace_go_check__init_A_const_56 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[99]); A_arbace_go_check__init_A_const_57 = A_arbace_go_check__init_A_const_pool.A[100]; A_arbace_go_check__init_A_const_58 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[101]); A_arbace_go_check__init_A_const_59 = A_arbace_go_check__init_A_const_pool.A[102]; A_arbace_go_check__init_A_const_60 = A_arbace_go_check__init_A_const_pool.A[103]; A_arbace_go_check__init_A_const_61 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[104]); A_arbace_go_check__init_A_const_62 = A_arbace_go_check__init_A_const_pool.A[105]; A_arbace_go_check__init_A_const_63 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[106]); A_arbace_go_check__init_A_const_64 = A_arbace_go_check__init_A_const_pool.A[107]; A_arbace_go_check__init_A_const_65 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[108]); A_arbace_go_check__init_A_const_66 = A_arbace_go_check__init_A_const_pool.A[109] }

func A_arbace_go_check__init_A_clinit_p5() { A_arbace_go_check__init_A_const_67 = lang.Var_Cast(A_arbace_go_check__init_A_const_pool.A[110]); A_arbace_go_check__init_A_const_68 = A_arbace_go_check__init_A_const_pool.A[111] }

func A_arbace_go_check__init_A_New() *A_arbace_go_check__init_A { A_arbace_go_check__init_A_Init(); t := &A_arbace_go_check__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check__init_A) Ctor() {}

func (t *A_arbace_go_check__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check__init_A_class }

func (t *A_arbace_go_check__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check__init_A); return ok }

func A_arbace_go_check__init_A_Cast(x any) *A_arbace_go_check__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check__init_A_class)) }; return v }
