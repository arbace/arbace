//line j2g_strings.ae:1
package aot_arbace_go_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn13,arbace.pprintyn2,ppyn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,ekn5,referyn1,oyn5,oset!yn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.declyn4,declyn20,arbace.go.check.loadyn4,loadyn20,arbace.repr.go.typeskn3,dockn3,tagkn4,elseks2,go3,viayn4,convys2,go2,idkn3,valkn6,assignkn4,convkn4,instkn4,recvkn5,ifacekn6,methodkn4,refskn9,recv-typekn6,paramskn5,fieldkn4,typekn8,tag-typekn3,lhskn3,sigkn3,varkn4,formkn3,objkn4,objskn2,tokn7,resultskn2,opkn8,tag-formkn9,annotatedkn6,binarykn9,shift-lhskn1,xkn7,invalidks2,go2,opkn4,namekn5,scopekn4,filekn4,langkn4,optskn4,linekn7,importskn5,declskn4,dotskn11,dot-importskn11,import-objskn4,usedkn3,pkgkn4,kindkn4,funckn5,constkn4,depskn4,initkn4,specks3,goi6,vargenkn10,keep-treeskn7,packagekn4,pathkn6,configkn11,local-typeskn7,answerskn9,positionskn7,methodskn6,bodieskn5,initskn5,flagskn7,resolvekn5,fileskn4,declkn10,init-orderyn6,valueskn8,verifiedkn5,countkn11,unsupportedkn2,idkn7,generickn13,generic-formskn13,generic-declskn17,unsupported-formskn15,generic-presentkn5,formskn7,presentkn10,unverifiedkn13,unverified-atkn8,verticeskn5,edgeskn5,canonkn3,idxkn12,BlankPkgNamekn5,aliaskn10,decl-orderkn4,treekn5,laterks19,arbace.go.check.env11,unsupportedkn4,modekn5,finalkn10,unrecordedkn12,x-unrecordedkn2,pfkn8,pkg-linekn18,AnnotationMismatchkn6,resultkn6,errorskn14,generic-errorskn5,treeskn10,decl-infoskn4,basekn5,orderkn18,resolve-init-orderkn3,poskn7,tparamskn8,rtparamskn2,cxkn4,bodykn9,sig-formskn11,resolve-srckn5,cachekn8,ns-indexkn8,delegatekn13,local-importskn6,refusekn5,localkn13,scope-entrieskn5,nameskn5,rootskn8,dirtestskn3,dirkn3,subkn4,gooskn6,goarchkn7,goamd64kn8,programskn7,goarm64kn6,corpuskn7,overlaykn5,crashkn3,msgkn4,codekn5,Crashkn7,skippedkn8,packageskn12,declarationskn7,checkedkn18,unsupported-errorskn7,crasheskn7,crashedkn11,annotationskn14,in-unsupportedkn12,initializerskn10,mismatchesys2,go7,packagekn4,jobskn6,recordkn4,workkn7,summarykn4,notekn7,secondskn7,corporakn9,referencev11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V5,R12,R2,R13,R14,V2,R15,R16,V3,R17,R2,R18,V3,R19,R2,R20,V3,R21,R2,R22,V1,R23,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.checkm2,R24,s1046,goi's checker (doc/go/GOI-SPEC.md §3): Go forms type-checked as go/types checks Go, with\n  the converter's annotations verified (§3.6) and the checked tree (§3.7) as its output.\n\n  GR2, built before GR1 (the user's choice, 2026-10-17): an imported package is checked from its\n  forms (the forms root's, tamago/goroot's or a corpus's); in the program (GR3, the REPL and\n  bin/goi run: arbace.go.repl) a listed package is checked from GR1's digest, whose constants\n  have their :val and no init (§6.5: trusted). Generic code is checked since GR6 (§9.1): type\n  parameters and constraints, instantiation, inference after go/types' infer.go and unify.go.\n\n  Parts: arbace.go.check.types (types), .const (constants), .env (objects, scopes, errors),\n  .code (type expressions, expressions, statements), .decl (a package's declarations, init\n  order), .load (forms roots, build constraints).\n\n  Use: (check-package session src) checks one package; (annotations corpus) checks a corpus\n  and reports the annotations verified (bin/goi annotations, §11.4).v11,arbace.core9,volatile!v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core1,+l0,v11,arbace.core4,seq?R25,v11,arbace.core7,symbol?v11,arbace.core7,vector?v11,arbace.core4,map?R26,R27,R28,v11,arbace.core5,firstv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core3,notv11,arbace.core4,not=R29,R29,v11,arbace.core9,contains?R30,R29,R31,l1,R32,v11,arbace.core10,chunk-restv11,arbace.core4,nextR33,S18,R34,R35,R36,R37,R38,R39,R30,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,S18,R34,R35,R36,R37,R38,R39,R30,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,v15,arbace.go.check9,nodes-seqR52,R42,v21,arbace.go.check.types5,same?R41,v19,arbace.go.check.env9,verified!v21,arbace.go.check.types6,valid?v19,arbace.go.check.env17,annotation-error!v20,arbace.go.check.code8,expr-strv21,arbace.go.check.types8,type-strR53,v20,arbace.go.check.code8,cx-flagsR54,v20,arbace.go.check.code9,shift-opsR55,R56,v21,arbace.go.check.types6,typed?R57,R46,R58,R59,R60,v19,arbace.go.check.env5,scopeR61,R62,v20,arbace.go.check.code10,lang-minorv11,arbace.core6,get-inV2,R63,R62,R64,v20,arbace.go.check.code5,flineR65,R63,R66,R67,R68,R69,v11,arbace.core9,namespacev11,arbace.core4,namev19,arbace.go.check.env5,oset!R70,v19,arbace.go.check.env9,scope-getR71,v19,arbace.go.check.env1,oR72,S3,R73,R74,R45,R75,v20,arbace.go.check.code9,head-namev13,arbace.string12,starts-with?S2,R74,R45,R76,R77,v11,arbace.core7,sort-byv11,arbace.core11,map-indexedv11,arbace.core6,vectorv21,arbace.go.check.types12,update-info!v11,arbace.core5,assocR78,v11,arbace.core8,to-arrayR79,R80,R81,R82,R83,v11,arbace.core5,some?R84,R85,R48,R86,R87,R88,R89,R90,v11,arbace.core4,mapvv15,arbace.go.check9,file-infoR91,v11,arbace.core8,distinctv11,arbace.core3,mapR92,v20,arbace.go.check.decl10,init-orderv11,arbace.core6,empty?v20,arbace.go.check.decl10,monomorph!v20,arbace.go.check.code18,anon-iface-cycles!V2,R63,R93,v20,arbace.repr.go.types9,name-formv11,arbace.core5,applyv11,arbace.core4,listR94,R94,v11,arbace.core4,restR95,R96,m2,R95,Fv11,arbace.core3,setv11,arbace.core4,keepR97,R98,v11,arbace.core6,removev11,arbace.core6,reducev11,arbace.core4,someR99,v15,arbace.go.check19,annotations-presentv11,arbace.core10,merge-withR100,v11,arbace.core3,incR101,R102,R103,v11,arbace.core4,intov11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consR104,R105,R106,R107,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv19,arbace.go.check.env5,*pkg*v19,arbace.go.check.env8,*errors*v19,arbace.go.check.env6,*seen*v20,arbace.go.check.decl5,*ctx*v19,arbace.go.check.env9,*answers*v21,arbace.go.check.types9,*spelled*v21,arbace.go.check.types15,*resolve-named*v20,arbace.go.check.decl14,resolve-named!v21,arbace.go.check.types12,*method-obj*v20,arbace.go.check.decl12,method-data!v21,arbace.go.check.types9,*qualify*v21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv20,arbace.go.check.code10,*obj-decl*v20,arbace.go.check.decl9,obj-decl!v20,arbace.go.check.code9,*on-path*v20,arbace.go.check.decl8,on-path!v20,arbace.go.check.code15,*package-of-ns*v20,arbace.go.check.load8,path->nsv20,arbace.go.check.code13,*instantiate*v20,arbace.go.check.decl11,instantiatev20,arbace.go.check.code7,*subst*v20,arbace.go.check.decl5,substv20,arbace.go.check.code14,*verify-later*v20,arbace.go.check.decl13,verify-later!v20,arbace.go.check.code13,*valid-types*v20,arbace.go.check.decl6,*mono*R108,R109,R110,R111,v20,arbace.go.check.code13,*anon-ifaces*v20,arbace.go.check.decl21,resolve-method-bases!v19,arbace.go.check.env6,error!R112,v20,arbace.go.check.decl16,declare-imports!v20,arbace.go.check.decl13,collect-file!v20,arbace.go.check.decl21,file-scope-conflicts!v20,arbace.go.check.decl14,direct-cycles!R113,v15,arbace.go.check19,number-local-types!R114,v20,arbace.go.check.decl11,check-body!v11,arbace.core7,vreset!R115,R116,v19,arbace.go.check.env12,unsupported?R117,v11,arbace.core7,ex-datav19,arbace.go.check.env6,*decl*v19,arbace.go.check.env8,*gofile*v19,arbace.go.check.env6,*line*R47,v15,arbace.go.check12,verify-tags!v19,arbace.go.check.env7,answer!R118,R119,R120,R121,v15,arbace.go.check21,mark-qualifiers-used!v20,arbace.go.check.decl15,unused-imports!R122,R123,R124,v11,arbace.core6,formatv11,arbace.core6,pr-strR125,R126,v11,arbace.core3,vecv11,arbace.core4,juxtR127,R93,R128,R129,v11,arbace.core11,select-keysV12,R98,R72,R77,R46,R47,R43,R115,R99,R97,R36,R130,R61,V12,R98,R72,R77,R46,R47,R43,R115,R99,R97,R36,R130,R61,R131,R132,v11,arbace.core6,secondR133,V8,R98,R72,R47,R43,R99,R97,R36,R130,V8,R98,R72,R47,R43,R99,R97,R36,R130,R73,R134,R135,v11,arbace.core6,dissocR136,R137,R138,R139,R140,R141,v11,arbace.core4,atomv11,arbace.core9,realized?R142,v15,arbace.go.check10,ns-packagev19,arbace.go.check.env14,unsafe-packageR143,R144,v15,arbace.go.check14,ensure-packagev13,arbace.string9,includes?v13,arbace.string5,splitp1,/R145,v11,arbace.core7,promisev15,arbace.go.check13,check-packagev15,arbace.go.check8,resolverv11,arbace.core7,ex-infov11,arbace.core7,deliverv13,arbace.string4,joinR146,R147,v11,arbace.core5,swap!v15,arbace.go.check12,*forms-root*R148,R149,R150,R151,m6,R152,s5,linuxR153,s5,amd64R154,s2,v1R155,m6,R152,s5,linuxR153,s5,amd64R154,s2,v1m6,R152,s6,tamagoR153,s5,amd64R154,s2,v1m6,R152,s6,tamagoR153,s5,arm64R156,s4,v8.0R157,v15,arbace.go.check6,*root*m6,R152,s5,linuxR153,s5,amd64R154,s2,v1m6,R152,s5,linuxR153,s5,amd64R154,s2,v1m6,R152,s6,tamagoR153,s5,amd64R154,s2,v1m6,R152,s6,tamagoR153,s5,arm64R156,s4,v8.0m6,R152,s5,linuxR153,s5,amd64R154,s2,v1R158,m6,R152,s5,linuxR153,s5,amd64R154,s2,v1v15,arbace.go.check7,sessionv20,arbace.go.check.load14,package-sourcev11,arbace.core5,doallv11,arbace.core11,future-callv15,arbace.go.check10,*progress*l-1,v11,arbace.core5,rangeR159,R160,R161,R162,v15,arbace.go.check13,corpus-configv15,arbace.go.check11,std-sessionv20,arbace.go.check.load15,package-path-ofv20,arbace.go.check.load13,package-filesv15,arbace.go.check12,run-parallelv15,arbace.go.check9,result-ofR163,v15,arbace.go.check12,error-resultv11,arbace.core4,subsv11,arbace.core8,group-byv11,arbace.core7,re-findp21,^(.*?_dir)(?:/|\\.ae$)v11,arbace.core6,concatm2,R163,Tm2,R163,Tv11,arbace.core3,keyR164,R165,R166,R167,R168,v11,arbace.core6,filterR169,R170,v11,arbace.core10,sorted-mapR171,V2,R93,R95,R172,R173,v11,arbace.core6,false?V2,R93,R95,V2,R93,R96,v20,arbace.repr.go.print13,collect-formsv11,arbace.core5,mergem2,R62,s6,go1.27v20,arbace.repr.go.print9,name-textR174,v11,arbace.core4,readv11,arbace.core11,*read-eval*v15,arbace.go.check12,std-sessionsv15,arbace.go.check3,stdv15,arbace.go.check12,forms-sourcev15,arbace.go.check11,check-formsv11,arbace.core4,spitv11,arbace.core3,strv13,arbace.pprint6,pprintv11,arbace.core5,*out*v14,arbace.java.io12,make-parentsv15,arbace.go.check15,*reference-dir*R175,R176,R177,v15,arbace.go.check12,check-corpusv15,arbace.go.check9,summarizeC12,java.io.Filev15,arbace.go.check14,reference-pathv11,arbace.core11,read-stringv11,arbace.core5,slurpR178,V2,R170,R106,V2,R165,R97,V3,R170,R93,R173,R179,v15,arbace.go.check9,write-ednR180,v15,arbace.go.check13,report-errorsv11,arbace.core7,printlnV2,R165,R166,V2,R165,R99,V2,R165,R97,V2,R170,R95,V3,R170,R93,R164,V3,R170,R93,R172,v11,arbace.core4,takel20,V2,R170,R106,V2,R170,R106,l24,R181,v11,arbace.core5,nnextR182,v15,arbace.go.check7,corporav15,arbace.go.check11,annotationsv11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("annotations")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check$_main$fn__1685000515")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check$_main$fn__1685000518")

var Lit_4 *jrt.String = jrt.Intern("usage: arbace.go.check annotations [--record] [--jobs N] [--work DIR] [--forms DIR] [--reference DIR] [CORPUS...]")

var Lit_5 *jrt.String = jrt.Intern("/.tmp/goi")

var Lit_6 *jrt.String = jrt.Intern("--forms")

var Lit_7 *jrt.String = jrt.Intern("--reference")

var Lit_8 *jrt.String = jrt.Intern("--jobs")

var Lit_9 *jrt.String = jrt.Intern("--record")

var Lit_10 *jrt.String = jrt.Intern("--work")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check$_main$fn__1685000518$iter__1685000519__1685000523")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check$_main$fn__1685000518$iter__1685000519__1685000523$fn__1685000524")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check$_main$fn__1685000518$iter__1685000519__1685000523$fn__1685000524$fn__1685000525")

var Lit_14 *jrt.String = jrt.Intern("/annotations-")

var Lit_15 *jrt.String = jrt.Intern(".report.edn")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000490__1685000496")

var Lit_17 *jrt.String = jrt.Intern("goi annotations %s: %d packages, %d declarations checked (%d of them using generics; %d not checked), %d errors; verified %s; init-order %d packages, %d initializers; %.1f s")

var Lit_18 *jrt.String = jrt.Intern("  ")

var Lit_19 *jrt.String = jrt.Intern("   annotations not verified:")

var Lit_20 *jrt.String = jrt.Intern("   not checked:")

var Lit_21 *jrt.String = jrt.Intern("bin/goi annotations --record")

var Lit_22 *jrt.String = jrt.Intern("   recorded")

var Lit_23 *jrt.String = jrt.Intern("   no reference")

var Lit_24 *jrt.String = jrt.Intern("(bin/goi annotations --record)")

var Lit_25 *jrt.String = jrt.Intern("   the counts differ from the reference")

var Lit_26 *jrt.String = jrt.Intern(":")

var Lit_27 *jrt.String = jrt.Intern("   recorded:")

var Lit_28 *jrt.String = jrt.Intern("   now:     ")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000490__1685000496$fn__1685000497")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000490__1685000496$fn__1685000497$iter__1685000492__1685000498")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000490__1685000496$fn__1685000497$iter__1685000492__1685000498$fn__1685000499")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000490__1685000496$fn__1685000497$iter__1685000492__1685000498$fn__1685000499$fn__1685000500")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check$annotations_present$add_BANG___1685000012")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check$annotations_present$walk__1685000014")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$iter__1685000360__1685000364")

var Lit_36 *jrt.String = jrt.Intern("")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000370")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000374")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000378")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000388__1685000392")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$fn__1685000398")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$fn__1685000400")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000402__1685000406")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000388__1685000392$fn__1685000393")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000388__1685000392$fn__1685000393$fn__1685000394")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000402__1685000406$fn__1685000407")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000402__1685000406$fn__1685000407$fn__1685000408")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000402__1685000406$fn__1685000407$fn__1685000418")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000384$iter__1685000402__1685000406$fn__1685000407$fn__1685000408$fn__1685000412")

var Lit_51 *jrt.String = jrt.Intern(" ")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$iter__1685000360__1685000364$fn__1685000365")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$iter__1685000360__1685000364$fn__1685000365$fn__1685000366")

var Lit_54 *jrt.String = jrt.Intern("tamago-amd64")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000129")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000131")

var Lit_57 *jrt.String = jrt.Intern("_")

var Lit_58 *jrt.String = jrt.Intern("invalid package name _")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000179")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000186")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000193")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000203")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000205")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.check$check_package$init_entry__1685000231")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.check$check_package$norm__1685000235")

var Lit_66 *jrt.String = jrt.Intern("annotation :init-order on package %s disagrees with goi's checker: forms say %s, the checker says %s")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000239")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000241")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000247")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000299")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check$check_package$iter__1685000301__1685000305")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000311")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000254")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000256")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000258")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000260")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000262")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$iter__1685000266__1685000270")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000282")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000284")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000286")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000288")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$fn__1685000262$fn__1685000263")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$iter__1685000266__1685000270$fn__1685000271")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000250$iter__1685000266__1685000270$fn__1685000271$fn__1685000272")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000311$fn__1685000312")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.check$check_package$init_entry__1685000231$one__1685000232")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.check$check_package$iter__1685000301__1685000305$fn__1685000306")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.check$check_package$iter__1685000301__1685000305$fn__1685000306$fn__1685000307")

var Lit_91 *jrt.String = jrt.Intern("values")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.check$check_package$norm__1685000235$fn__1685000236")

var Lit_93 *jrt.String = jrt.Intern("linux-dirtest")

var Lit_94 *jrt.String = jrt.Intern("/linux-amd64")

var Lit_95 *jrt.String = jrt.Intern("/linux-dirtest")

var Lit_96 *jrt.String = jrt.Intern("test")

var Lit_97 *jrt.String = jrt.Intern("linux-test")

var Lit_98 *jrt.String = jrt.Intern("/linux-test")

var Lit_99 *jrt.String = jrt.Intern("/amd64")

var Lit_100 *jrt.String = jrt.Intern("tamago-arm64")

var Lit_101 *jrt.String = jrt.Intern("/arm64")

var Lit_102 *jrt.String = jrt.Intern("linux-amd64")

var Lit_103 *jrt.String = jrt.Intern("unknown corpus ")

var Lit_104 *jrt.String = jrt.Intern("/.tmp/repr-go/forms/linux-amd64")

var Lit_105 *jrt.String = jrt.Intern("/.tmp/repr-go/forms/linux-dirtest")

var Lit_106 *jrt.String = jrt.Intern("/.tmp/repr-go/forms/linux-test")

var Lit_107 *jrt.String = jrt.Intern("/tamago/goroot")

var Lit_108 *jrt.String = jrt.Intern("/tamago/goroot/arch/amd64")

var Lit_109 *jrt.String = jrt.Intern("/tamago/goroot/arch/arm64")

var Lit_110 *jrt.String = jrt.Intern("import cycle not allowed: ")

var Lit_111 *jrt.String = jrt.Intern(" -> ")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.check$ensure_package$fn__1685000321")

var Lit_113 *jrt.String = jrt.Intern("checking ")

var Lit_114 *jrt.String = jrt.Intern(": ")

var Lit_115 *jrt.String = jrt.Intern("checker crash: ")

var Lit_116 *jrt.String = jrt.Intern(" / ")

var Lit_117 *jrt.String = jrt.Intern("java.io.File")

var Lit_118 *jrt.String = jrt.Intern("main")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.check$forms_source$fn__1685000467")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.check$forms_source$iter__1685000469__1685000473")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.check$forms_source$iter__1685000469__1685000473$fn__1685000474")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.check$forms_source$iter__1685000469__1685000473$fn__1685000474$fn__1685000475")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.check$mark_qualifiers_used_BANG_$walk__1685000048")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.check$mark_qualifiers_used_BANG_$walk2__1685000061")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.check$nodes_seq$walk__1685000025")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.check$number_local_types_BANG_$fn__1685000083")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.check$number_local_types_BANG_$fn__1685000089")

var Lit_128 *jrt.String = jrt.Intern("/test/goi/annotations-")

var Lit_129 *jrt.String = jrt.Intern(".edn")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000447__1685000453")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000447__1685000453$fn__1685000454")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000447__1685000453$fn__1685000454$iter__1685000449__1685000455")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000447__1685000453$fn__1685000454$iter__1685000449__1685000455$fn__1685000456")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000447__1685000453$fn__1685000454$iter__1685000449__1685000455$fn__1685000456$fn__1685000457")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.check$resolver$fn__1685000318")

var Lit_136 *jrt.String = jrt.Intern("unsafe")

var Lit_137 *jrt.String = jrt.Intern(".")

var Lit_138 *jrt.String = jrt.Intern("vendor/")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000338__1685000342")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000338__1685000342$fn__1685000343")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000338__1685000342$fn__1685000343$fn__1685000344")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000338__1685000342$fn__1685000343$fn__1685000348")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000338__1685000342$fn__1685000343$fn__1685000344$fn__1685000345")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.check$std_session$fn__1685000333")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.check$std_session$fn__1685000333$fn__1685000334")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.check$summarize$sum__1685000430")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.check$summarize$msum__1685000432")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000434")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000436")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000438")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000440")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000442")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000444")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.check$syntactic_deps_BANG_$walk__1685000071")

var Lit_155 *jrt.String = jrt.Intern(".-")

var Lit_156 *jrt.String = jrt.Intern(":tag")

var Lit_157 *jrt.String = jrt.Intern("none")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.check$write_edn$fn__1685000483")

var Lit_159 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn4,formkn4,linekn6,columnkn4,filekn7,privateyn4,treeyn9,pkg-scopeyn2,fiyn6,configyn1,dyn3,ltsyn3,srcyn7,resolveyn1,&kn4,keysyn10,keep-treesyn11,resolve-srckn8,declaredyn1,skn3,tagyn6,Stringyn5,chainyn4,pathyn8,importerkn7,dynamicyn6,corpusyn5,rootsyn1,nyn1,fyn2,xsyn3,pkgyn4,whatyn2,exyn4,jobsyn7,resultsyn5,formsyn4,optsyn1,xyn6,recordyn4,workyn4,argsv11,arbace.core5,in-nsMyn15,arbace.go.checkm2,R0,s1046,goi's checker (doc/go/GOI-SPEC.md §3): Go forms type-checked as go/types checks Go, with\n  the converter's annotations verified (§3.6) and the checked tree (§3.7) as its output.\n\n  GR2, built before GR1 (the user's choice, 2026-10-17): an imported package is checked from its\n  forms (the forms root's, tamago/goroot's or a corpus's); in the program (GR3, the REPL and\n  bin/goi run: arbace.go.repl) a listed package is checked from GR1's digest, whose constants\n  have their :val and no init (§6.5: trusted). Generic code is checked since GR6 (§9.1): type\n  parameters and constraints, instantiation, inference after go/types' infer.go and unify.go.\n\n  Parts: arbace.go.check.types (types), .const (constants), .env (objects, scopes, errors),\n  .code (type expressions, expressions, statements), .decl (a package's declarations, init\n  order), .load (forms roots, build constraints).\n\n  Use: (check-package session src) checks one package; (annotations corpus) checks a corpus\n  and reports the annotations verified (bin/goi annotations, §11.4).m2,R0,s1046,goi's checker (doc/go/GOI-SPEC.md §3): Go forms type-checked as go/types checks Go, with\n  the converter's annotations verified (§3.6) and the checked tree (§3.7) as its output.\n\n  GR2, built before GR1 (the user's choice, 2026-10-17): an imported package is checked from its\n  forms (the forms root's, tamago/goroot's or a corpus's); in the program (GR3, the REPL and\n  bin/goi run: arbace.go.repl) a listed package is checked from GR1's digest, whose constants\n  have their :val and no init (§6.5: trusted). Generic code is checked since GR6 (§9.1): type\n  parameters and constraints, instantiation, inference after go/types' infer.go and unify.go.\n\n  Parts: arbace.go.check.types (types), .const (constants), .env (objects, scopes, errors),\n  .code (type expressions, expressions, statements), .decl (a package's declarations, init\n  order), .load (forms roots, build constraints).\n\n  Use: (check-package session src) checks one package; (annotations corpus) checks a corpus\n  and reports the annotations verified (bin/goi annotations, §11.4).R1,v15,arbace.go.check19,annotations-presentm10,R2,L1,V1,R3,R0,s220,The converter's annotations in a declaration form, by kind: :val (on constant names), :tag\n  (on expressions: lists), :go/via (selections, literal keys), :assign (:= targets), :inst\n  (generic uses), :conv (conversions).R4,i31,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,nodes-seqm12,R7,TR2,L1,V1,R8,R0,s57,The nodes of a checked tree (maps with :op), depth first.R4,i64,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,verify-tags!m10,R2,L1,V1,R8,R0,s212,Compares the type of every expression the forms tag (:tag on a list) with the checker's;\n  in annotated forms, a non-constant shift of an untyped constant with a typed type must carry\n  one (doc/go/SPEC.md §8.3).R4,i81,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,file-infom10,R7,TR2,L1,V3,R9,R10,R11,R4,i101,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check21,mark-qualifiers-used!m12,R7,TR2,L1,V2,R10,R3,R0,s88,Marks the imports a skipped declaration's forms name as used (its code was not checked).R4,i109,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check15,syntactic-deps!m12,R7,TR2,L1,V2,R12,R9,R0,s88,The package-level objects a skipped declaration's forms name (for initialization order).R4,i133,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check19,number-local-types!m12,R7,TR2,L1,V1,R13,R0,s362,Numbers the package's function-scoped defined types as gc's noder does (its typegen, the ·N of\n  their link names, writer.go's collectDecls: source order): by their package-level declarations\n  (whose ids are in source order), then in the order their bodies declare them: :goi/vargen in\n  each one's info (GR9c, the runtime names of local types in generic code).R4,i151,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check13,check-packagem10,R2,L1,V4,R14,R15,R16,m2,R17,V1,R18,R0,s209,Checks the package of source src (load/package-source) in session: the package (a\n  volatile, its :scope its objects) with :result {:errors :decls ...}. resolve: path, file ->\n  the imported package (checked).R4,i161,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check7,sessionm10,R2,L1,V1,R19,R0,s113,A checking session over roots: resolve-src is path, importer-src -> the source of an imported\n  package (or nil).R4,i351,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check14,ensure-packagem8,R20,TR4,i357,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check10,ns-packagem12,R7,TR2,L1,V2,R21,Myn7,ns-namem2,R22,R23,R0,s154,The package of session s (or its delegate's) whose namespace is ns-name (the forms' qualified\n  names in annotations, SPEC.md §4.4), when checked, or nil.R4,i359,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check8,resolverm12,R7,TR2,L1,V3,R21,R14,R24,R0,s142,The import resolver of a package being checked in session s (chain: the import path); with\n  one argument, a namespace's package (ns-package).R4,i368,R5,i1,R6,s18,arbace/go/check.aem10,R2,L1,V4,R21,R25,R26,R24,R0,s79,The checked package of import path in session s (checked on first use), or nil.R4,i388,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,check-srcm10,R2,L1,V2,R21,R14,R0,s88,Checks the package of source src (not cached) against session s's packages: the package.R4,i415,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check6,*root*m10,R27,TR4,i422,R5,i1,R6,s18,arbace/go/check.aeR0,s13,The checkout.v15,arbace.go.check12,*forms-root*m10,R27,TR4,i424,R5,i1,R6,s18,arbace/go/check.aeR0,s258,When set (bin/goi annotations --forms DIR), the corpora's forms are DIR's: DIR/amd64 and\n  DIR/arm64 for tamago's std (one tree each, no overlay), DIR/linux-amd64, DIR/linux-test and\n  DIR/linux-dirtest (bin/repr-go read --reader native --forms writes them).v15,arbace.go.check13,corpus-configm8,R2,L1,V1,R28,R4,i430,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check11,std-sessionm10,R7,TR2,L1,V1,m2,R17,V2,R29,R11,R4,i456,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check10,*progress*m10,R27,TR4,i460,R5,i1,R6,s18,arbace/go/check.aeR0,s81,When set, a function called with each item done and its time (ms), for long runs.v15,arbace.go.check12,run-parallelm12,R7,TR2,L1,V3,R30,R31,R32,R0,s67,Applies f to each x of xs on up to n threads, the results in order.R4,i464,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,result-ofm10,R7,TR2,L1,V1,R33,R4,i483,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,error-resultm10,R7,TR2,L1,V2,R34,R35,R4,i485,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,check-corpusm10,R2,L1,V2,R28,R36,R0,s48,Checks every package of a corpus: their results.R4,i492,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,summarizem10,R2,L1,V2,R28,R37,R0,s65,The corpus's counts: packages, declarations, errors, annotations.R4,i550,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check13,report-errorsm10,R2,L1,V1,R37,R0,s67,The errors of the results as lines FILE:LINE: MESSAGE, per package.R4,i576,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,forms-sourcem10,R2,L1,V2,R38,R11,R0,s157,The source of a package given as forms in memory (go/package, go/file and declaration\n  forms, as one file holds them; arbace.repr.go.print's collect-forms).R4,i584,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check17,read-string-formsm10,R2,L1,V1,Myn4,textm2,R22,R23,R0,s44,The forms of a text, read with line numbers.R4,i594,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,std-sessionsv11,arbace.core4,atomm8,R7,TR4,i604,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check3,stdm10,R2,L1,V1,R28,R0,s87,A session over a corpus's standard library (cached), for checking forms that import it.R4,i606,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check11,check-formsm10,R2,L2,V1,R38,V3,R38,R28,R39,R0,s126,Checks the package of forms (in memory) against the standard library of corpus (default\n  tamago-amd64): the package's result.R4,i614,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check7,corporaV5,s12,tamago-amd64s12,tamago-arm64s11,linux-amd64s10,linux-tests13,linux-dirtestm8,R4,i626,R5,i1,R6,s18,arbace/go/check.aeR0,s46,The corpora of the annotation check, in order.v15,arbace.go.check9,write-ednm10,R7,TR2,L1,V2,R25,R40,R4,i630,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check15,*reference-dir*m10,R27,TR4,i634,R5,i1,R6,s18,arbace/go/check.aeR0,s192,When set (--reference DIR), the counts compared are DIR/annotations-CORPUS.report.edn's (another\n  run's report, its :summary): the native conversions' against the helper's of the same corpus.v15,arbace.go.check14,reference-pathm8,R2,L1,V1,R28,R4,i639,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check11,annotationsm10,R2,L1,V2,R28,m2,R17,V3,R36,R41,R42,R0,s346,Checks a corpus, writes its report under work, compares its counts with the reference\n  (test/goi/annotations-CORPUS.edn; record: writes it). True when it passes: no error, no\n  crash, no declaration left unchecked, every annotation verified (:inst included, GR6),\n  :init-order verified in every package that has one, and the counts as recorded.R4,i644,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check5,-mainm10,R2,L1,V2,R16,R43,R0,s82,bin/goi's Arbace side: annotations [--record] [--jobs N] [--work DIR] [CORPUS...].R4,i687,R5,i1,R6,s18,arbace/go/check.ae")

var Lit_160 *jrt.String = jrt.Intern("arbace.go.check$eval1685000004$loading__1927001464__auto____1685000005")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.check$eval1685000008$fn__1685000009")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.check$annotations_present")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.check$nodes_seq")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.check$verify_tags_BANG_")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.check$file_info")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.check$mark_qualifiers_used_BANG_")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.check$syntactic_deps_BANG_")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.check$number_local_types_BANG_")

var Lit_169 *jrt.String = jrt.Intern("arbace.go.check$check_package")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.check$session")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.check$ns_package")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.check$resolver")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.check$ensure_package")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.check$check_src")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.check$corpus_config")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.check$std_session")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.check$run_parallel")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.check$result_of")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.check$error_result")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.check$check_corpus")

var Lit_181 *jrt.String = jrt.Intern("arbace.go.check$summarize")

var Lit_182 *jrt.String = jrt.Intern("arbace.go.check$report_errors")

var Lit_183 *jrt.String = jrt.Intern("arbace.go.check$forms_source")

var Lit_184 *jrt.String = jrt.Intern("arbace.go.check$read_string_forms")

var Lit_185 *jrt.String = jrt.Intern("arbace.go.check$std")

var Lit_186 *jrt.String = jrt.Intern("arbace.go.check$check_forms")

var Lit_187 *jrt.String = jrt.Intern("arbace.go.check$write_edn")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.check$reference_path")

var Lit_189 *jrt.String = jrt.Intern("arbace.go.check$annotations")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.check$_main")
