//line j2g_strings.ae:1
package aot_arbace_go_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn13,arbace.pprintyn2,ppyn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,ekn5,referyn1,oyn5,oset!yn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.declyn4,declyn20,arbace.go.check.loadyn4,loadyn20,arbace.repr.go.typeskn3,dockn3,tagkn4,elseks2,go3,viayn4,convys2,go2,idkn3,valkn6,assignkn4,convkn4,instkn4,recvkn5,ifacekn6,methodkn4,refskn9,recv-typekn6,paramskn5,fieldkn4,typekn8,tag-typekn3,lhskn3,sigkn3,varkn4,formkn3,objkn4,objskn2,tokn7,resultskn2,opkn8,tag-formkn9,annotatedkn6,binarykn9,shift-lhskn1,xkn7,invalidks2,go2,opkn4,namekn5,scopekn4,filekn4,langkn4,optskn4,linekn7,importskn5,declskn4,dotskn11,dot-importskn11,import-objskn4,usedkn3,pkgkn4,kindkn4,funckn5,constkn4,depskn4,initkn4,speckn10,keep-treeskn7,packagekn4,pathkn6,configkn9,positionskn7,methodskn6,bodieskn5,initskn5,flagskn5,fileskn4,declkn10,init-orderyn6,valueskn8,verifiedkn5,countkn11,unsupportedkn2,idkn7,generickn13,generic-formskn13,generic-declskn17,unsupported-formskn15,generic-presentkn5,formskn7,presentkn10,unverifiedkn13,unverified-atkn5,aliaskn10,decl-orderkn4,treekn5,laterks19,arbace.go.check.env11,unsupportedkn2,pfkn8,pkg-linekn18,AnnotationMismatchkn6,resultkn6,errorskn14,generic-errorskn5,treeskn10,decl-infoskn4,basekn5,orderkn7,tparamskn8,rtparamskn2,cxkn4,bodykn9,sig-formskn11,resolve-srckn5,cachekn8,ns-indexkn8,delegatekn13,local-importskn5,localkn13,scope-entrieskn5,nameskn5,rootskn8,dirtestskn3,dirkn3,subkn4,gooskn6,goarchkn7,goamd64kn8,programskn7,goarm64kn6,corpuskn7,overlaykn5,crashkn3,msgkn4,codekn5,Crashkn7,skippedkn8,packageskn12,declarationskn7,checkedkn18,unsupported-errorskn7,crasheskn7,crashedkn11,annotationskn14,in-unsupportedkn12,initializerskn10,mismatchesys2,go7,packagekn4,jobskn6,recordkn4,workkn4,notekn7,summarykn7,secondskn7,corporav11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V5,R12,R2,R13,R14,V2,R15,R16,V3,R17,R2,R18,V3,R19,R2,R20,V3,R21,R2,R22,V1,R23,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.checkm2,R24,s1046,goi's checker (doc/go/GOI-SPEC.md §3): Go forms type-checked as go/types checks Go, with\n  the converter's annotations verified (§3.6) and the checked tree (§3.7) as its output.\n\n  GR2, built before GR1 (the user's choice, 2026-10-17): an imported package is checked from its\n  forms (the forms root's, tamago/goroot's or a corpus's); in the program (GR3, the REPL and\n  bin/goi run: arbace.go.repl) a listed package is checked from GR1's digest, whose constants\n  have their :val and no init (§6.5: trusted). Generic code is checked since GR6 (§9.1): type\n  parameters and constraints, instantiation, inference after go/types' infer.go and unify.go.\n\n  Parts: arbace.go.check.types (types), .const (constants), .env (objects, scopes, errors),\n  .code (type expressions, expressions, statements), .decl (a package's declarations, init\n  order), .load (forms roots, build constraints).\n\n  Use: (check-package session src) checks one package; (annotations corpus) checks a corpus\n  and reports the annotations verified (bin/goi annotations, §11.4).v11,arbace.core9,volatile!v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core1,+l0,v11,arbace.core4,seq?R25,v11,arbace.core7,symbol?v11,arbace.core7,vector?v11,arbace.core4,map?R26,R27,R28,v11,arbace.core5,firstv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core3,notv11,arbace.core4,not=R29,R29,v11,arbace.core9,contains?R30,R29,R31,l1,R32,v11,arbace.core10,chunk-restv11,arbace.core4,nextR33,S18,R34,R35,R36,R37,R38,R39,R30,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,S18,R34,R35,R36,R37,R38,R39,R30,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,v15,arbace.go.check9,nodes-seqR52,R42,R41,v19,arbace.go.check.env9,verified!v21,arbace.go.check.types6,valid?v19,arbace.go.check.env17,annotation-error!v20,arbace.go.check.code8,expr-strv21,arbace.go.check.types8,type-strR53,v20,arbace.go.check.code8,cx-flagsR54,v20,arbace.go.check.code9,shift-opsR55,R56,v21,arbace.go.check.types6,typed?R57,R46,R58,R59,R60,v19,arbace.go.check.env5,scopeR61,R62,v20,arbace.go.check.code10,lang-minorv11,arbace.core6,get-inV2,R63,R62,R64,v20,arbace.go.check.code5,flineR65,R63,R66,R67,R68,R69,v11,arbace.core9,namespacev11,arbace.core4,namev19,arbace.go.check.env5,oset!R70,v19,arbace.go.check.env9,scope-getR71,v19,arbace.go.check.env1,oR72,S3,R73,R74,R45,R75,v20,arbace.go.check.code9,head-namev13,arbace.string12,starts-with?S2,R74,R45,R76,R77,v11,arbace.core8,to-arrayR78,R79,R80,R81,R82,R48,R83,R84,R85,R86,v11,arbace.core4,mapvv15,arbace.go.check9,file-infoR87,v11,arbace.core8,distinctv11,arbace.core3,mapR88,v20,arbace.go.check.decl10,init-orderV2,R63,R89,v20,arbace.repr.go.types9,name-formv11,arbace.core5,applyv11,arbace.core4,listR90,R90,v11,arbace.core4,restv11,arbace.core5,some?R91,R92,m2,R91,Fv11,arbace.core3,setv11,arbace.core4,keepR93,R94,v11,arbace.core6,removev11,arbace.core6,reducev11,arbace.core4,someR95,v15,arbace.go.check19,annotations-presentv11,arbace.core10,merge-withR96,v11,arbace.core3,incR97,R98,R99,v11,arbace.core4,intov11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consR100,R101,R102,R103,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv19,arbace.go.check.env5,*pkg*v19,arbace.go.check.env8,*errors*v19,arbace.go.check.env6,*seen*v20,arbace.go.check.decl5,*ctx*v21,arbace.go.check.types15,*resolve-named*v20,arbace.go.check.decl14,resolve-named!v21,arbace.go.check.types12,*method-obj*v20,arbace.go.check.decl12,method-data!v21,arbace.go.check.types9,*qualify*v21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv20,arbace.go.check.code10,*obj-decl*v20,arbace.go.check.decl9,obj-decl!v20,arbace.go.check.code15,*package-of-ns*v20,arbace.go.check.load8,path->nsv20,arbace.go.check.code13,*instantiate*v20,arbace.go.check.decl11,instantiatev20,arbace.go.check.code7,*subst*v20,arbace.go.check.decl5,substv20,arbace.go.check.code14,*verify-later*v20,arbace.go.check.decl13,verify-later!v20,arbace.go.check.decl21,resolve-method-bases!v20,arbace.go.check.decl16,declare-imports!v20,arbace.go.check.decl13,collect-file!v20,arbace.go.check.decl21,file-scope-conflicts!v11,arbace.core11,map-indexedv11,arbace.core6,vectorR104,R105,v20,arbace.go.check.decl11,check-body!R106,R107,v11,arbace.core5,assocv19,arbace.go.check.env12,unsupported?R108,v11,arbace.core7,ex-datav19,arbace.go.check.env6,*decl*v19,arbace.go.check.env8,*gofile*v19,arbace.go.check.env6,*line*R47,v15,arbace.go.check12,verify-tags!v15,arbace.go.check21,mark-qualifiers-used!v20,arbace.go.check.decl15,unused-imports!v19,arbace.go.check.env6,error!R109,R110,R111,v11,arbace.core6,formatv11,arbace.core6,pr-strR112,R113,v11,arbace.core3,vecv11,arbace.core7,sort-byv11,arbace.core4,juxtR114,R89,R115,R116,v11,arbace.core11,select-keysV12,R94,R72,R77,R46,R47,R43,R106,R95,R93,R36,R117,R61,V12,R94,R72,R77,R46,R47,R43,R106,R95,R93,R36,R117,R61,R118,R73,R119,R120,v11,arbace.core6,dissocR121,R122,R123,R124,R125,R126,v11,arbace.core4,atomv11,arbace.core9,realized?R127,v15,arbace.go.check10,ns-packagev19,arbace.go.check.env14,unsafe-packageR128,v15,arbace.go.check14,ensure-packagev13,arbace.string9,includes?v13,arbace.string5,splitp1,/R129,v11,arbace.core7,promisev15,arbace.go.check13,check-packagev15,arbace.go.check8,resolverv11,arbace.core7,ex-infov11,arbace.core7,deliverv13,arbace.string4,joinR130,R131,v11,arbace.core5,swap!R132,R133,R134,v15,arbace.go.check6,*root*R135,m6,R136,s5,linuxR137,s5,amd64R138,s2,v1R139,m6,R136,s5,linuxR137,s5,amd64R138,s2,v1m6,R136,s6,tamagoR137,s5,amd64R138,s2,v1m6,R136,s6,tamagoR137,s5,arm64R140,s4,v8.0R141,R142,m6,R136,s5,linuxR137,s5,amd64R138,s2,v1v15,arbace.go.check7,sessionv20,arbace.go.check.load14,package-sourcev11,arbace.core5,doallv11,arbace.core11,future-callv15,arbace.go.check10,*progress*l-1,v11,arbace.core5,rangeR143,R144,R145,R146,v15,arbace.go.check13,corpus-configv15,arbace.go.check11,std-sessionv20,arbace.go.check.load15,package-path-ofv20,arbace.go.check.load13,package-filesv15,arbace.go.check12,run-parallelv15,arbace.go.check9,result-ofR147,v15,arbace.go.check12,error-resultv11,arbace.core6,empty?v11,arbace.core4,subsv11,arbace.core8,group-byv11,arbace.core7,re-findp21,^(.*?_dir)(?:/|\\.ae$)v11,arbace.core6,concatm2,R147,Tm2,R147,Tv11,arbace.core3,keyR148,R149,R150,R151,R152,v11,arbace.core6,filterR153,R154,v11,arbace.core10,sorted-mapR155,V2,R89,R91,R156,R157,v11,arbace.core6,false?V2,R89,R91,V2,R89,R92,v20,arbace.repr.go.print13,collect-formsv11,arbace.core5,mergem2,R62,s6,go1.27v20,arbace.repr.go.print9,name-textR158,v11,arbace.core4,readv11,arbace.core11,*read-eval*v15,arbace.go.check12,std-sessionsv15,arbace.go.check3,stdv15,arbace.go.check12,forms-sourcev15,arbace.go.check11,check-formsv11,arbace.core4,spitv11,arbace.core3,strv13,arbace.pprint6,pprintv11,arbace.core5,*out*v14,arbace.java.io12,make-parentsR159,R160,R161,v15,arbace.go.check12,check-corpusv15,arbace.go.check9,summarizeC12,java.io.Filev15,arbace.go.check14,reference-pathv11,arbace.core11,read-stringv11,arbace.core5,slurpV2,R154,R102,V2,R149,R93,V3,R154,R89,R157,R162,v15,arbace.go.check9,write-ednR163,R164,v15,arbace.go.check13,report-errorsv11,arbace.core7,printlnV2,R149,R150,V2,R149,R95,V2,R149,R93,V2,R154,R91,V3,R154,R89,R148,V3,R154,R89,R156,v11,arbace.core4,takel20,V2,R154,R102,V2,R154,R102,l24,R165,v11,arbace.core5,nnextv11,arbace.core6,secondv15,arbace.go.check7,corporav15,arbace.go.check11,annotationsv11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("annotations")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check$_main$fn__1685000451")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check$_main$iter__1685000454__1685000458")

var Lit_4 *jrt.String = jrt.Intern("usage: arbace.go.check annotations [--record] [--jobs N] [--work DIR] [CORPUS...]")

var Lit_5 *jrt.String = jrt.Intern("/.tmp/goi")

var Lit_6 *jrt.String = jrt.Intern("--jobs")

var Lit_7 *jrt.String = jrt.Intern("--record")

var Lit_8 *jrt.String = jrt.Intern("--work")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check$_main$iter__1685000454__1685000458$fn__1685000459")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check$_main$iter__1685000454__1685000458$fn__1685000459$fn__1685000460")

var Lit_11 *jrt.String = jrt.Intern("/annotations-")

var Lit_12 *jrt.String = jrt.Intern(".report.edn")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000426__1685000432")

var Lit_14 *jrt.String = jrt.Intern("goi annotations %s: %d packages, %d declarations checked (%d of them using generics; %d not checked), %d errors; verified %s; init-order %d packages, %d initializers; %.1f s")

var Lit_15 *jrt.String = jrt.Intern("  ")

var Lit_16 *jrt.String = jrt.Intern("   annotations not verified:")

var Lit_17 *jrt.String = jrt.Intern("   not checked:")

var Lit_18 *jrt.String = jrt.Intern("bin/goi annotations --record")

var Lit_19 *jrt.String = jrt.Intern("   recorded")

var Lit_20 *jrt.String = jrt.Intern("   no reference")

var Lit_21 *jrt.String = jrt.Intern("(bin/goi annotations --record)")

var Lit_22 *jrt.String = jrt.Intern("   the counts differ from the reference")

var Lit_23 *jrt.String = jrt.Intern(":")

var Lit_24 *jrt.String = jrt.Intern("   recorded:")

var Lit_25 *jrt.String = jrt.Intern("   now:     ")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000426__1685000432$fn__1685000433")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000426__1685000432$fn__1685000433$iter__1685000428__1685000434")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000426__1685000432$fn__1685000433$iter__1685000428__1685000434$fn__1685000435")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check$annotations$iter__1685000426__1685000432$fn__1685000433$iter__1685000428__1685000434$fn__1685000435$fn__1685000436")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check$annotations_present$add_BANG___1685000012")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check$annotations_present$walk__1685000014")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$iter__1685000296__1685000300")

var Lit_33 *jrt.String = jrt.Intern("")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000306")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000310")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000314")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000324__1685000328")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$fn__1685000334")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$fn__1685000336")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000338__1685000342")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000324__1685000328$fn__1685000329")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000324__1685000328$fn__1685000329$fn__1685000330")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000338__1685000342$fn__1685000343")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000338__1685000342$fn__1685000343$fn__1685000344")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000338__1685000342$fn__1685000343$fn__1685000354")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$fn__1685000320$iter__1685000338__1685000342$fn__1685000343$fn__1685000344$fn__1685000348")

var Lit_48 *jrt.String = jrt.Intern(" ")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$iter__1685000296__1685000300$fn__1685000301")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check$check_corpus$iter__1685000296__1685000300$fn__1685000301$fn__1685000302")

var Lit_51 *jrt.String = jrt.Intern("tamago-amd64")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000100")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000102")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000142")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000149")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000156")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000166")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000168")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check$check_package$init_entry__1685000178")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check$check_package$norm__1685000182")

var Lit_61 *jrt.String = jrt.Intern("annotation :init-order on package %s disagrees with goi's checker: forms say %s, the checker says %s")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000186")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000188")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000194")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000242")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.check$check_package$iter__1685000244__1685000248")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000201")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000203")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000205")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000207")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000209")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$iter__1685000213__1685000217")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000229")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000231")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000233")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000235")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$fn__1685000209$fn__1685000210")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$iter__1685000213__1685000217$fn__1685000218")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.check$check_package$fn__1685000197$iter__1685000213__1685000217$fn__1685000218$fn__1685000219")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.check$check_package$init_entry__1685000178$one__1685000179")

var Lit_82 *jrt.String = jrt.Intern("_")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.check$check_package$iter__1685000244__1685000248$fn__1685000249")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check$check_package$iter__1685000244__1685000248$fn__1685000249$fn__1685000250")

var Lit_85 *jrt.String = jrt.Intern("values")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check$check_package$norm__1685000182$fn__1685000183")

var Lit_87 *jrt.String = jrt.Intern("linux-dirtest")

var Lit_88 *jrt.String = jrt.Intern("/.tmp/repr-go/forms/linux-amd64")

var Lit_89 *jrt.String = jrt.Intern("/.tmp/repr-go/forms/linux-dirtest")

var Lit_90 *jrt.String = jrt.Intern("test")

var Lit_91 *jrt.String = jrt.Intern("linux-test")

var Lit_92 *jrt.String = jrt.Intern("/.tmp/repr-go/forms/linux-test")

var Lit_93 *jrt.String = jrt.Intern("/tamago/goroot")

var Lit_94 *jrt.String = jrt.Intern("/tamago/goroot/arch/amd64")

var Lit_95 *jrt.String = jrt.Intern("tamago-arm64")

var Lit_96 *jrt.String = jrt.Intern("/tamago/goroot/arch/arm64")

var Lit_97 *jrt.String = jrt.Intern("linux-amd64")

var Lit_98 *jrt.String = jrt.Intern("unknown corpus ")

var Lit_99 *jrt.String = jrt.Intern("import cycle not allowed: ")

var Lit_100 *jrt.String = jrt.Intern(" -> ")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.check$ensure_package$fn__1685000260")

var Lit_102 *jrt.String = jrt.Intern("checking ")

var Lit_103 *jrt.String = jrt.Intern(": ")

var Lit_104 *jrt.String = jrt.Intern("checker crash: ")

var Lit_105 *jrt.String = jrt.Intern(" / ")

var Lit_106 *jrt.String = jrt.Intern("java.io.File")

var Lit_107 *jrt.String = jrt.Intern("main")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.check$forms_source$fn__1685000403")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.check$forms_source$iter__1685000405__1685000409")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.check$forms_source$iter__1685000405__1685000409$fn__1685000410")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.check$forms_source$iter__1685000405__1685000409$fn__1685000410$fn__1685000411")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.check$mark_qualifiers_used_BANG_$walk__1685000048")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.check$mark_qualifiers_used_BANG_$walk2__1685000061")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.check$nodes_seq$walk__1685000025")

var Lit_115 *jrt.String = jrt.Intern("/test/goi/annotations-")

var Lit_116 *jrt.String = jrt.Intern(".edn")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000383__1685000389")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000383__1685000389$fn__1685000390")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000383__1685000389$fn__1685000390$iter__1685000385__1685000391")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000383__1685000389$fn__1685000390$iter__1685000385__1685000391$fn__1685000392")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.check$report_errors$iter__1685000383__1685000389$fn__1685000390$iter__1685000385__1685000391$fn__1685000392$fn__1685000393")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.check$resolver$fn__1685000257")

var Lit_123 *jrt.String = jrt.Intern("unsafe")

var Lit_124 *jrt.String = jrt.Intern(".")

var Lit_125 *jrt.String = jrt.Intern("vendor/")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000274__1685000278")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000274__1685000278$fn__1685000279")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000274__1685000278$fn__1685000279$fn__1685000280")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000274__1685000278$fn__1685000279$fn__1685000284")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.check$run_parallel$iter__1685000274__1685000278$fn__1685000279$fn__1685000280$fn__1685000281")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.check$std_session$fn__1685000269")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.check$std_session$fn__1685000269$fn__1685000270")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.check$summarize$sum__1685000366")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.check$summarize$msum__1685000368")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000370")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000372")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000374")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000376")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000378")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.check$summarize$fn__1685000380")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.check$syntactic_deps_BANG_$walk__1685000071")

var Lit_142 *jrt.String = jrt.Intern(".-")

var Lit_143 *jrt.String = jrt.Intern(":tag")

var Lit_144 *jrt.String = jrt.Intern("none")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.check$write_edn$fn__1685000419")

var Lit_146 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn4,formkn4,linekn6,columnkn4,filekn7,privateyn4,treeyn9,pkg-scopeyn2,fiyn6,configyn1,dyn3,srcyn7,resolveyn1,&kn4,keysyn10,keep-treesyn11,resolve-srckn8,declaredyn1,skn3,tagyn6,Stringyn5,chainyn4,pathyn8,importerkn7,dynamicyn6,corpusyn5,rootsyn1,nyn1,fyn2,xsyn3,pkgyn4,whatyn2,exyn4,jobsyn7,resultsyn5,formsyn4,optsyn1,xyn6,recordyn4,workyn4,argsv11,arbace.core5,in-nsMyn15,arbace.go.checkm2,R0,s1046,goi's checker (doc/go/GOI-SPEC.md §3): Go forms type-checked as go/types checks Go, with\n  the converter's annotations verified (§3.6) and the checked tree (§3.7) as its output.\n\n  GR2, built before GR1 (the user's choice, 2026-10-17): an imported package is checked from its\n  forms (the forms root's, tamago/goroot's or a corpus's); in the program (GR3, the REPL and\n  bin/goi run: arbace.go.repl) a listed package is checked from GR1's digest, whose constants\n  have their :val and no init (§6.5: trusted). Generic code is checked since GR6 (§9.1): type\n  parameters and constraints, instantiation, inference after go/types' infer.go and unify.go.\n\n  Parts: arbace.go.check.types (types), .const (constants), .env (objects, scopes, errors),\n  .code (type expressions, expressions, statements), .decl (a package's declarations, init\n  order), .load (forms roots, build constraints).\n\n  Use: (check-package session src) checks one package; (annotations corpus) checks a corpus\n  and reports the annotations verified (bin/goi annotations, §11.4).m2,R0,s1046,goi's checker (doc/go/GOI-SPEC.md §3): Go forms type-checked as go/types checks Go, with\n  the converter's annotations verified (§3.6) and the checked tree (§3.7) as its output.\n\n  GR2, built before GR1 (the user's choice, 2026-10-17): an imported package is checked from its\n  forms (the forms root's, tamago/goroot's or a corpus's); in the program (GR3, the REPL and\n  bin/goi run: arbace.go.repl) a listed package is checked from GR1's digest, whose constants\n  have their :val and no init (§6.5: trusted). Generic code is checked since GR6 (§9.1): type\n  parameters and constraints, instantiation, inference after go/types' infer.go and unify.go.\n\n  Parts: arbace.go.check.types (types), .const (constants), .env (objects, scopes, errors),\n  .code (type expressions, expressions, statements), .decl (a package's declarations, init\n  order), .load (forms roots, build constraints).\n\n  Use: (check-package session src) checks one package; (annotations corpus) checks a corpus\n  and reports the annotations verified (bin/goi annotations, §11.4).R1,v15,arbace.go.check19,annotations-presentm10,R2,L1,V1,R3,R0,s220,The converter's annotations in a declaration form, by kind: :val (on constant names), :tag\n  (on expressions: lists), :go/via (selections, literal keys), :assign (:= targets), :inst\n  (generic uses), :conv (conversions).R4,i31,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,nodes-seqm12,R7,TR2,L1,V1,R8,R0,s57,The nodes of a checked tree (maps with :op), depth first.R4,i64,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,verify-tags!m10,R2,L1,V1,R8,R0,s212,Compares the type of every expression the forms tag (:tag on a list) with the checker's;\n  in annotated forms, a non-constant shift of an untyped constant with a typed type must carry\n  one (doc/go/SPEC.md §8.3).R4,i81,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,file-infom10,R7,TR2,L1,V3,R9,R10,R11,R4,i101,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check21,mark-qualifiers-used!m12,R7,TR2,L1,V2,R10,R3,R0,s88,Marks the imports a skipped declaration's forms name as used (its code was not checked).R4,i109,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check15,syntactic-deps!m12,R7,TR2,L1,V2,R12,R9,R0,s88,The package-level objects a skipped declaration's forms name (for initialization order).R4,i133,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check13,check-packagem10,R2,L1,V4,R13,R14,R15,m2,R16,V1,R17,R0,s209,Checks the package of source src (load/package-source) in session: the package (a\n  volatile, its :scope its objects) with :result {:errors :decls ...}. resolve: path, file ->\n  the imported package (checked).R4,i151,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check7,sessionm10,R2,L1,V1,R18,R0,s113,A checking session over roots: resolve-src is path, importer-src -> the source of an imported\n  package (or nil).R4,i296,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check14,ensure-packagem8,R19,TR4,i302,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check10,ns-packagem12,R7,TR2,L1,V2,R20,Myn7,ns-namem2,R21,R22,R0,s154,The package of session s (or its delegate's) whose namespace is ns-name (the forms' qualified\n  names in annotations, SPEC.md §4.4), when checked, or nil.R4,i304,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check8,resolverm12,R7,TR2,L1,V3,R20,R13,R23,R0,s142,The import resolver of a package being checked in session s (chain: the import path); with\n  one argument, a namespace's package (ns-package).R4,i313,R5,i1,R6,s18,arbace/go/check.aem10,R2,L1,V4,R20,R24,R25,R23,R0,s79,The checked package of import path in session s (checked on first use), or nil.R4,i330,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check6,*root*m10,R26,TR4,i357,R5,i1,R6,s18,arbace/go/check.aeR0,s13,The checkout.v15,arbace.go.check13,corpus-configm8,R2,L1,V1,R27,R4,i359,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check11,std-sessionm10,R7,TR2,L1,V1,m2,R16,V2,R28,R11,R4,i375,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check10,*progress*m10,R26,TR4,i379,R5,i1,R6,s18,arbace/go/check.aeR0,s81,When set, a function called with each item done and its time (ms), for long runs.v15,arbace.go.check12,run-parallelm12,R7,TR2,L1,V3,R29,R30,R31,R0,s67,Applies f to each x of xs on up to n threads, the results in order.R4,i383,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,result-ofm10,R7,TR2,L1,V1,R32,R4,i402,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,error-resultm10,R7,TR2,L1,V2,R33,R34,R4,i404,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,check-corpusm10,R2,L1,V2,R27,R35,R0,s48,Checks every package of a corpus: their results.R4,i411,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check9,summarizem10,R2,L1,V2,R27,R36,R0,s65,The corpus's counts: packages, declarations, errors, annotations.R4,i469,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check13,report-errorsm10,R2,L1,V1,R36,R0,s67,The errors of the results as lines FILE:LINE: MESSAGE, per package.R4,i495,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,forms-sourcem10,R2,L1,V2,R37,R11,R0,s157,The source of a package given as forms in memory (go/package, go/file and declaration\n  forms, as one file holds them; arbace.repr.go.print's collect-forms).R4,i503,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check17,read-string-formsm10,R2,L1,V1,Myn4,textm2,R21,R22,R0,s44,The forms of a text, read with line numbers.R4,i513,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check12,std-sessionsv11,arbace.core4,atomm8,R7,TR4,i523,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check3,stdm10,R2,L1,V1,R27,R0,s87,A session over a corpus's standard library (cached), for checking forms that import it.R4,i525,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check11,check-formsm10,R2,L2,V1,R37,V3,R37,R27,R38,R0,s126,Checks the package of forms (in memory) against the standard library of corpus (default\n  tamago-amd64): the package's result.R4,i533,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check7,corporaV5,s12,tamago-amd64s12,tamago-arm64s11,linux-amd64s10,linux-tests13,linux-dirtestm8,R4,i545,R5,i1,R6,s18,arbace/go/check.aeR0,s46,The corpora of the annotation check, in order.v15,arbace.go.check9,write-ednm10,R7,TR2,L1,V2,R24,R39,R4,i549,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check14,reference-pathm8,R2,L1,V1,R27,R4,i553,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check11,annotationsm10,R2,L1,V2,R27,m2,R16,V3,R35,R40,R41,R0,s346,Checks a corpus, writes its report under work, compares its counts with the reference\n  (test/goi/annotations-CORPUS.edn; record: writes it). True when it passes: no error, no\n  crash, no declaration left unchecked, every annotation verified (:inst included, GR6),\n  :init-order verified in every package that has one, and the counts as recorded.R4,i555,R5,i1,R6,s18,arbace/go/check.aev15,arbace.go.check5,-mainm10,R2,L1,V2,R15,R42,R0,s82,bin/goi's Arbace side: annotations [--record] [--jobs N] [--work DIR] [CORPUS...].R4,i597,R5,i1,R6,s18,arbace/go/check.ae")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.check$eval1685000004$loading__1927001464__auto____1685000005")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.check$eval1685000008$fn__1685000009")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.check$annotations_present")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.check$nodes_seq")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.check$verify_tags_BANG_")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.check$file_info")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.check$mark_qualifiers_used_BANG_")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.check$syntactic_deps_BANG_")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.check$check_package")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.check$session")

var Lit_157 *jrt.String = jrt.Intern("arbace.go.check$ns_package")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.check$resolver")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.check$ensure_package")

var Lit_160 *jrt.String = jrt.Intern("arbace.go.check$corpus_config")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.check$std_session")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.check$run_parallel")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.check$result_of")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.check$error_result")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.check$check_corpus")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.check$summarize")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.check$report_errors")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.check$forms_source")

var Lit_169 *jrt.String = jrt.Intern("arbace.go.check$read_string_forms")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.check$std")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.check$check_forms")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.check$write_edn")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.check$reference_path")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.check$annotations")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.check$_main")
