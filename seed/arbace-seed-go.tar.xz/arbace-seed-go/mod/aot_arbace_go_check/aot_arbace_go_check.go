//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_106)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__7, A_arbace_go_check_A_const_54.Invoke_O__O(n__6))).Ref() } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_262 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_go_check_A_const_24; var arg_266 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_268 == nil { tmp2 = ifn_269.Invoke_O__O(arg_270) } else { tmp2 = linked_268.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_267, arg_270) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_271 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_275 any = Lit_145; var arg_276 any; var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_280 == nil { arg_276 = ifn_281.Invoke_O__O(arg_282) } else { arg_276 = linked_280.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_279, arg_282) }; var arg_277 any; var root_283 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_285 lang.IFn
							if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = want__7; if linked_284 == nil { arg_277 = ifn_285.Invoke_O__O(arg_286) } else { arg_277 = linked_284.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_283, arg_286) }
//line :93:1
							var arg_278 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_289 lang.IFn
							if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_288 == nil { arg_278 = ifn_289.Invoke_O__O(arg_290) } else { arg_278 = linked_288.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_287, arg_290) }
//line :93:1
							if linked_272 == nil { ifn_273.Invoke_O_O_O_O_O__O(arg_274, arg_275, arg_276, arg_277, arg_278) } else { linked_272.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_271, arg_274, arg_275, arg_276, arg_277, arg_278) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_291 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_293 lang.IFn
									if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_292 == nil { and__1927000168__auto____11 = ifn_293.Invoke_O__O(arg_294) } else { and__1927000168__auto____11 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_295 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_67; var arg_299 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_300 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); var arg_304 any = Lit_145; var arg_305 any; var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); if linked_309 == nil { arg_305 = ifn_310.Invoke_O__O(arg_311) } else { arg_305 = linked_309.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_308, arg_311) }; var arg_306 any = Lit_146; var arg_307 any; var root_312 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_313 == nil { arg_307 = ifn_314.Invoke_O__O(arg_315) } else { arg_307 = linked_313.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_312, arg_315) }; if linked_301 == nil { ifn_302.Invoke_O_O_O_O_O__O(arg_303, arg_304, arg_305, arg_306, arg_307) } else { linked_301.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_300, arg_303, arg_304, arg_305, arg_306, arg_307) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1685000042__7; if linked_317 == nil { tmp8 = ifn_318.Invoke_O__O(arg_319) } else { tmp8 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_316, arg_319) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__9, A_arbace_go_check_A_const_54.Invoke_O__O(n__8))).Ref() } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_320 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_24; var arg_324 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_321 == nil { ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { linked_321.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_325 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_326 == nil { tmp10 = ifn_327.Invoke_O__O(arg_328) } else { tmp10 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_325, arg_328) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_329 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_333 any = Lit_145; var arg_334 any; var root_337 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_338 == nil { arg_334 = ifn_339.Invoke_O__O(arg_340) } else { arg_334 = linked_338.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_337, arg_340) }; var arg_335 any; var root_341 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_343 lang.IFn
								if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = want__9; if linked_342 == nil { arg_335 = ifn_343.Invoke_O__O(arg_344) } else { arg_335 = linked_342.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_341, arg_344) }
//line :93:1
								var arg_336 any; var root_345 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_347 lang.IFn
								if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_346 == nil { arg_336 = ifn_347.Invoke_O__O(arg_348) } else { arg_336 = linked_346.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_345, arg_348) }
//line :93:1
								if linked_330 == nil { ifn_331.Invoke_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336) } else { linked_330.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_349 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_351 lang.IFn
										if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_350 == nil { and__1927000168__auto____13 = ifn_351.Invoke_O__O(arg_352) } else { and__1927000168__auto____13 = linked_350.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_353 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_go_check_A_const_67; var arg_357 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_354 == nil { tmp11 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp11 = linked_354.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_358 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); var arg_362 any = Lit_145; var arg_363 any; var root_366 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); if linked_367 == nil { arg_363 = ifn_368.Invoke_O__O(arg_369) } else { arg_363 = linked_367.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_366, arg_369) }; var arg_364 any = Lit_146; var arg_365 any; var root_370 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_371 == nil { arg_365 = ifn_372.Invoke_O__O(arg_373) } else { arg_365 = linked_371.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_370, arg_373) }; if linked_359 == nil { ifn_360.Invoke_O_O_O_O_O__O(arg_361, arg_362, arg_363, arg_364, arg_365) } else { linked_359.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_358, arg_361, arg_362, arg_363, arg_364, arg_365) } } }
//line :86:1
				var tmp15 any; var root_374 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1685000042__7; if linked_375 == nil { tmp15 = ifn_376.Invoke_O__O(arg_377) } else { tmp15 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_70; var tmp2 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_71; var tmp4 any; var root_378 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_380 lang.IFn; if
													linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = pkg_scope__0; var arg_382 any = A_arbace_go_check_A_const_73; if linked_379 == nil { tmp4 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp4 = linked_379.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_74; var tmp7 any; var root_383 any = /*line :101:1*/A_arbace_go_check_A_const_75.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_385 lang.IFn; if


	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var or__1927000174__auto____4 any; var root_387 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = fi__1; var arg_391 any = A_arbace_go_check_A_const_77; if linked_388 == nil { or__1927000174__auto____4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { or__1927000174__auto____4 = linked_388.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_386 = or__1927000174__auto____4 } else { arg_386 = A_arbace_go_check_A_const_74.Invoke_O__O(config__2) }; if linked_384 == nil { tmp7 = ifn_385.Invoke_O__O(arg_386) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_384.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_383, arg_386)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_78; var tmp10 any; var root_392 any = /*line :101:1*/A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_394 lang.IFn; if



	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_go_check_A_const_73.Invoke_O__O(fi__1); if linked_393 == nil { tmp10 = ifn_394.Invoke_O__O(arg_395) } else { tmp10 = linked_393.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_392, arg_395) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_80; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_80; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_81.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_82; var tmp16 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_83; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_84; var tmp20 any; var root_396 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_398 lang.IFn; if





	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.PersistentVector_EMPTY.Ref(); if linked_397 == nil { tmp20 = ifn_398.Invoke_O__O(arg_399) } else { tmp20 = linked_397.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_396, arg_399) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_85; var tmp23 any; var root_400 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_402 lang.IFn; if





	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.PersistentVector_EMPTY.Ref(); if linked_401 == nil { tmp23 = ifn_402.Invoke_O__O(arg_403) } else { tmp23 = linked_401.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_400, arg_403) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__502d; tmp1 = fncls__502d } else { tmp1 = fncls__502 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_503 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_A_const_84.Invoke_O__O(fi__0); if linked_508 == nil { arg_506 = ifn_509.Invoke_O__O(arg_510) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_507, arg_510) }; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__561d; tmp3 = fncls__561d } else { tmp3 = fncls__561 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_404 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_406 lang.IFn
	if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = f__1; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_404, arg_407) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_408 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = f__1; if linked_409 == nil { temp__1927000414__auto____2 = ifn_410.Invoke_O__O(arg_411) } else { temp__1927000414__auto____2 = linked_409.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_470 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_472 lang.IFn
			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_go_check_A_const_71.Invoke_O__O(t.F_fi); var arg_474 any = q__3; if linked_471 == nil { temp__1927000414__auto____4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { temp__1927000414__auto____4 = linked_471.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_91; var tmp3 any; var root_475 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_477 lang.IFn
				if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__5; var arg_479 any = A_arbace_go_check_A_const_93; if linked_476 == nil { tmp3 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp3 = linked_476.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_480 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = x__5; var arg_484 any = A_arbace_go_check_A_const_89; var arg_485 any = jrt.Boolean_TRUE.Ref(); if linked_481 == nil { ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp5 any; var root_412 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_414 lang.IFn


			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; if linked_413 == nil { tmp5 = ifn_414.Invoke_O__O(arg_415) } else { tmp5 = linked_413.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_412, arg_415) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_416 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_418 lang.IFn; _ = ___6; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = imp__7; var arg_420 any = A_arbace_go_check_A_const_89; var arg_421 any = jrt.Boolean_TRUE.Ref(); if linked_417 == nil { ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { linked_417.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } } } else {
//line :113:1
				var tmp6 any; var root_422 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_424 lang.IFn




				if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp6 = ifn_424.Invoke_O__O(arg_425) } else { tmp6 = linked_423.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_422, arg_425) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_426 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn




					if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = f__1; if linked_427 == nil { seq_1685000052__2 = ifn_428.Invoke_O__O(arg_429) } else { seq_1685000052__2 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1685000052__2; if linked_431 == nil { temp__1927000414__auto____6 = ifn_432.Invoke_O__O(arg_433) } else { temp__1927000414__auto____6 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1685000052__7; if linked_435 == nil { tmp7 = ifn_436.Invoke_O__O(arg_437) } else { tmp7 = linked_435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_1685000052__7; if linked_439 == nil { c__1927000678__auto____8 = ifn_440.Invoke_O__O(arg_441) } else { c__1927000678__auto____8 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_438, arg_441) }; var tmp8 any; var root_486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1685000052__7; if linked_487 == nil { tmp8 = ifn_488.Invoke_O__O(arg_489) } else { tmp8 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1685000052__7; if linked_443 == nil { x__8 = ifn_444.Invoke_O__O(arg_445) } else { x__8 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_1685000052__7; if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_490, arg_493) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_446 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_448 lang.IFn





							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; if linked_447 == nil { tmp10 = ifn_448.Invoke_O__O(arg_449) } else { tmp10 = linked_447.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_446, arg_449) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_450 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn





								if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = f__1; if linked_451 == nil { seq_1685000056__2 = ifn_452.Invoke_O__O(arg_453) } else { seq_1685000056__2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1685000056__2; if linked_455 == nil { temp__1927000414__auto____6_2 = ifn_456.Invoke_O__O(arg_457) } else { temp__1927000414__auto____6_2 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_458 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1685000056__7; if linked_459 == nil { tmp11 = ifn_460.Invoke_O__O(arg_461) } else { tmp11 = linked_459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_462 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1685000056__7; if linked_463 == nil { c__1927000678__auto____8_2 = ifn_464.Invoke_O__O(arg_465) } else { c__1927000678__auto____8_2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_462, arg_465) }; var tmp12 any; var root_494 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1685000056__7; if linked_495 == nil { tmp12 = ifn_496.Invoke_O__O(arg_497) } else { tmp12 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_466 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1685000056__7; if linked_467 == nil { x__8_2 = ifn_468.Invoke_O__O(arg_469) } else { x__8_2 = linked_467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_466, arg_469) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1685000056__7; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_511 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_513 lang.IFn
		if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = f__1; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp3 any; var root_515 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn
			if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__1; if linked_516 == nil { tmp3 = ifn_517.Invoke_O__O(arg_518) } else { tmp3 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_521 lang.IFn; _ = ___4; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = imp__5; var arg_523 any = A_arbace_go_check_A_const_89; var arg_524 any = jrt.Boolean_TRUE.Ref(); if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_525 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_527 lang.IFn

				if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { or__1927000174__auto____2 = ifn_527.Invoke_O__O(arg_528) } else { or__1927000174__auto____2 = linked_526.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_529 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_529, arg_532) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__1; if linked_534 == nil { seq_1685000065__2 = ifn_535.Invoke_O__O(arg_536) } else { seq_1685000065__2 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1685000065__2; if linked_538 == nil { temp__1927000414__auto____6 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000414__auto____6 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1685000065__7; if linked_542 == nil { tmp5 = ifn_543.Invoke_O__O(arg_544) } else { tmp5 = linked_542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_541, arg_544) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = seq_1685000065__7; if linked_546 == nil { c__1927000678__auto____8 = ifn_547.Invoke_O__O(arg_548) } else { c__1927000678__auto____8 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_545, arg_548) }; var tmp6 any; var root_553 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = seq_1685000065__7; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1685000065__7; if linked_550 == nil { x__8 = ifn_551.Invoke_O__O(arg_552) } else { x__8 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_557 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1685000065__7; if linked_558 == nil { tmp7 = ifn_559.Invoke_O__O(arg_560) } else { tmp7 = linked_558.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_557, arg_560) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_98); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp6 any; var root_682 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = d__0; if linked_683 == nil { tmp6 = ifn_684.Invoke_O__O(arg_685) } else { tmp6 = linked_683.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_99; var tmp8 any; var root_674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { tmp8 = ifn_676.Invoke_O__O(arg_677) } else { tmp8 = linked_675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_674, arg_677) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp10 any; var root_678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = d__0; if linked_679 == nil { tmp10 = ifn_680.Invoke_O__O(arg_681) } else { tmp10 = linked_679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_678, arg_681) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_564 lang.IFn
		if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = f__1; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_566 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = f__1; if linked_567 == nil { tmp2 = ifn_568.Invoke_O__O(arg_569) } else { tmp2 = linked_567.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_566, arg_569) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_572 lang.IFn

			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = t.F_pkg_scope; var arg_574 any; var root_575 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = f__1; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_575, arg_578) }; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_94); var tmp4 any; var root_634 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_636 lang.IFn
				if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__3; var arg_638 any = A_arbace_go_check_A_const_93; if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp4 = linked_635.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_579 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_583 any = A_arbace_go_check_A_const_95; var arg_584 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_585 any = x__3; if linked_580 == nil { tmp6 = ifn_581.Invoke_O_O_O_O__O(arg_582, arg_583, arg_584, arg_585) } else { tmp6 = linked_580.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_579, arg_582, arg_583, arg_584, arg_585) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_586 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_588 lang.IFn




								if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = f__1; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_586, arg_589) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_639 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_641 lang.IFn




									if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = f__1; if linked_640 == nil { temp__1927000414__auto____2_2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2_2 = linked_640.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_643 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_645 lang.IFn
										if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = h__3; var arg_647 any = Lit_126; if linked_644 == nil { and__1927000168__auto____4 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { and__1927000168__auto____4 = linked_644.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_648 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = h__3; var arg_656 any = Lit_144; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { and__1927000168__auto____5 = ifn_650.Invoke_O__O(arg_651) } else { and__1927000168__auto____5 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn








									if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { seq_1685000072__2 = ifn_592.Invoke_O__O(arg_593) } else { seq_1685000072__2 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_1685000072__2; if linked_595 == nil { temp__1927000414__auto____6 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____6 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_1685000072__7; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_1685000072__7; if linked_603 == nil { c__1927000678__auto____8 = ifn_604.Invoke_O__O(arg_605) } else { c__1927000678__auto____8 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_602, arg_605) }; var tmp10 any; var root_657 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1685000072__7; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_657, arg_660) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1685000072__7; if linked_607 == nil { x__8 = ifn_608.Invoke_O__O(arg_609) } else { x__8 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_661 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1685000072__7; if linked_662 == nil { tmp11 = ifn_663.Invoke_O__O(arg_664) } else { tmp11 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_610 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_612 lang.IFn









											if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = f__1; if linked_611 == nil { tmp12 = ifn_612.Invoke_O__O(arg_613) } else { tmp12 = linked_611.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_610, arg_613) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_614 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn









												if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = f__1; if linked_615 == nil { seq_1685000076__2 = ifn_616.Invoke_O__O(arg_617) } else { seq_1685000076__2 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_1685000076__2; if linked_619 == nil { temp__1927000414__auto____6_2 = ifn_620.Invoke_O__O(arg_621) } else { temp__1927000414__auto____6_2 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_622 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_1685000076__7; if linked_623 == nil { tmp13 = ifn_624.Invoke_O__O(arg_625) } else { tmp13 = linked_623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_626 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = seq_1685000076__7; if linked_627 == nil { c__1927000678__auto____8_2 = ifn_628.Invoke_O__O(arg_629) } else { c__1927000678__auto____8_2 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any; var root_665 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1685000076__7; if linked_666 == nil { tmp14 = ifn_667.Invoke_O__O(arg_668) } else { tmp14 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_630 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1685000076__7; if linked_631 == nil { x__8_2 = ifn_632.Invoke_O__O(arg_633) } else { x__8_2 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_669 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = seq_1685000076__7; if linked_670 == nil { tmp15 = ifn_671.Invoke_O__O(arg_672) } else { tmp15 = linked_670.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_669, arg_672) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_number_local_types_BANG__A_New() *A_arbace_go_check_number_local_types_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Invoke_O_O__O(self, lts__0 any) any { { var sorted__2 any; var root_686 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_688 lang.IFn





	if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any; var tmp1 any = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New(); var tmp2 *jrt.Class; var fncls__691 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class; if fncls__691 == nil { var fncls__691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class = fncls__691d; tmp2 = fncls__691d } else { tmp2 = fncls__691 }; arg_689 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_690 any; var root_692 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any; var tmp3 any = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New(); var tmp4 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class = fncls__697d; tmp4 = fncls__697d } else { tmp4 = fncls__697 }; arg_695 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_696 any = lts__0; if linked_693 == nil { arg_690 = ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { arg_690 = linked_693.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }; if linked_687 == nil { sorted__2 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { sorted__2 = linked_687.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }
//line :151:1
	var seq_1685000094__3 any; var root_698 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_700 lang.IFn






	if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any; var root_702 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var arg_706 any = sorted__2; if linked_703 == nil { arg_701 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_699 == nil { seq_1685000094__3 = ifn_700.Invoke_O__O(arg_701) } else { seq_1685000094__3 = linked_699.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_698, arg_701) }
//line :151:1
	var chunk_1685000095__4 any; var count_1685000096__5 int64 = 0; var i_1685000097__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000097__6, count_1685000096__5) { var vec__1685000098__7 any = lang.Indexed_Cast(chunk_1685000095__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000097__6)); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000101__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_104.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var tmp7 any = A_arbace_go_check_A_const_106; var tmp8 jrt.Number_I; var na_730 any = n__8; _ = ___10
			if jrt.Long_InstanceOf(na_730) { var n0_731 int64 = jrt.NN(jrt.Long_Cast(na_730)).LongValue__J(); if n0_731 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_730) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_731 + 1)) } } else { if jrt.Double_InstanceOf(na_730) { var n0_731_2 float64 = jrt.NN(jrt.Double_Cast(na_730)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_731_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_730) } }; tmp5.Invoke_O_O_O_O__O(nt__11, tmp6, tmp7, tmp8)
//line :158:1
			seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000097__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_707 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = seq_1685000094__3; if linked_708 == nil { temp__1927000414__auto____7 = ifn_709.Invoke_O__O(arg_710) } else { temp__1927000414__auto____7 = linked_708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_707, arg_710) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000094__8 any = temp__1927000414__auto____7; var tmp9 any; var root_711 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = seq_1685000094__8; if linked_712 == nil { tmp9 = ifn_713.Invoke_O__O(arg_714) } else { tmp9 = linked_712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____9 any; var root_715 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = seq_1685000094__8; if linked_716 == nil { c__1927000678__auto____9 = ifn_717.Invoke_O__O(arg_718) } else { c__1927000678__auto____9 = linked_716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_715, arg_718) }; var tmp10 any; var root_732 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = seq_1685000094__8; if linked_733 == nil { tmp10 = ifn_734.Invoke_O__O(arg_735) } else { tmp10 = linked_733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_732, arg_735) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp10, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000104__9 any; var root_719 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = seq_1685000094__8; if linked_720 == nil { vec__1685000104__9 = ifn_721.Invoke_O__O(arg_722) } else { vec__1685000104__9 = linked_720.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_719, arg_722) }; var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000107__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(1), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_104.GetRawRoot__O()); var tmp12 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var tmp13 any = A_arbace_go_check_A_const_106; var tmp14 jrt.Number_I; var na_743 any = n__10; _ = ___12
				if jrt.Long_InstanceOf(na_743) { var n0_744 int64 = jrt.NN(jrt.Long_Cast(na_743)).LongValue__J(); if n0_744 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_743) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_744 + 1)) } } else { if jrt.Double_InstanceOf(na_743) { var n0_744_2 float64 = jrt.NN(jrt.Double_Cast(na_743)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_744_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_743) } }; tmp11.Invoke_O_O_O_O__O(nt__13, tmp12, tmp13, tmp14)
//line :158:1
				var tmp15 any; var root_745 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = seq_1685000094__8; if linked_746 == nil { tmp15 = ifn_747.Invoke_O__O(arg_748) } else { tmp15 = linked_746.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_745, arg_748) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :151:1*/panic("j2g: unreachable") }





func A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000083_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Invoke_O_O__O(self, p__1685000082__1 any) any { var vec__1685000084__2 any = p__1685000082__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(id__3, k__5) }
//line :157:1
func A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000089_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Invoke_O_O_O__O(self, k__1, p__1685000088__2 any) any { var vec__1685000090__3 any = p__1685000088__2; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(id__4, nt__5, k__1) }



func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000126__2 any) any { var map__1685000127__4 any = p__1685000126__2; var map__1685000127__5 any; if lang.ISeq_InstanceOf(map__1685000127__4) { var tmp1 any; var root_749 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = map__1685000127__4; if linked_750 == nil { tmp1 = ifn_751.Invoke_O__O(arg_752) } else { tmp1 = linked_750.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_753 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = map__1685000127__4; if linked_754 == nil { tmp2 = ifn_755.Invoke_O__O(arg_756) } else { tmp2 = linked_754.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_753, arg_756) }; map__1685000127__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_757 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = map__1685000127__4; if linked_758 == nil { tmp3 = ifn_759.Invoke_O__O(arg_760) } else { tmp3 = linked_758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_757, arg_760) }; if jrt.J2g_Truth(tmp3) { var root_761 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = map__1685000127__4; if linked_762 == nil { map__1685000127__5 = ifn_763.Invoke_O__O(arg_764) } else { map__1685000127__5 = linked_762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_761, arg_764) } } else { map__1685000127__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000127__5 = map__1685000127__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000127__5, A_arbace_go_check_A_const_108); var pkg_scope__7 any; var root_765 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_767 lang.IFn; if




	linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var arg_769 any = A_arbace_go_check_A_const_109; if linked_766 == nil { pkg_scope__7 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { pkg_scope__7 = linked_766.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; var pkg__8 any; var root_770 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_772 lang.IFn; if





	linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var tmp4 any = A_arbace_go_check_A_const_110; var tmp5 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_70; var tmp7 any = A_arbace_go_check_A_const_70.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_71; var tmp9 any = A_arbace_go_check_A_const_111; var tmp10 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp11 any = A_arbace_go_check_A_const_112; var tmp12 any; var root_774 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_776 lang.IFn; if
	linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = lang.PersistentVector_EMPTY.Ref(); if linked_775 == nil { tmp12 = ifn_776.Invoke_O__O(arg_777) } else { tmp12 = linked_775.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_774, arg_777) }; arg_773 = /*line :167:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, tmp10, tmp11, tmp12)); if linked_771 == nil { pkg__8 = ifn_772.Invoke_O__O(arg_773) } else { pkg__8 = linked_771.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_770, arg_773) }; var errors__9 any; var root_778 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_780 lang.IFn; if







	linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = lang.PersistentVector_EMPTY.Ref(); if linked_779 == nil { errors__9 = ifn_780.Invoke_O__O(arg_781) } else { errors__9 = linked_779.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_778, arg_781) }; var annotated__10 any; var root_782 any = /*line :161:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_784 lang.IFn; if








	linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = A_arbace_go_check_A_const_81.Invoke_O__O(src__0); var arg_786 any = A_arbace_go_check_A_const_113; if linked_783 == nil { annotated__10 = ifn_784.Invoke_O_O__O(arg_785, arg_786) } else { annotated__10 = linked_783.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_782, arg_785, arg_786) }; var ctx__11 any; var tmp13 any = A_arbace_go_check_A_const_114; var tmp14 any; var root_787 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_789 lang.IFn; if









	linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = lang.PersistentVector_EMPTY.Ref(); if linked_788 == nil { tmp14 = ifn_789.Invoke_O__O(arg_790) } else { tmp14 = linked_788.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_787, arg_790) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_115; var tmp17 any; var root_791 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_793 lang.IFn; if









	linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_792 == nil { tmp17 = ifn_793.Invoke_O__O(arg_794) } else { tmp17 = linked_792.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_791, arg_794) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_116; var tmp20 any; var root_795 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_797 lang.IFn; if









	linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = lang.PersistentVector_EMPTY.Ref(); if linked_796 == nil { tmp20 = ifn_797.Invoke_O__O(arg_798) } else { tmp20 = linked_796.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_795, arg_798) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_117; var tmp23 any; var root_799 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_801 lang.IFn; if









	linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = lang.PersistentVector_EMPTY.Ref(); if linked_800 == nil { tmp23 = ifn_801.Invoke_O__O(arg_802) } else { tmp23 = linked_800.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_799, arg_802) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_go_check_A_const_118; ctx__11 = /*line :161:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)))); var fis__12 any; var root_803 any = A_arbace_go_check_A_const_119.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_805 lang.IFn; if











	linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any; var tmp26 any = A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(src__0, pkg_scope__7); var tmp27 *jrt.Class; var fncls__814 *jrt.Class = A_arbace_go_check_check_package_fn__1685000129_A_fn_class; if fncls__814 == nil { var fncls__814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_package_fn__1685000129_A_fn_class = fncls__814d; tmp27 = fncls__814d } else { tmp27 = fncls__814 }; arg_806 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_807 any = A_arbace_go_check_A_const_121.Invoke_O__O(src__0); if linked_804 == nil { fis__12 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { fis__12 = linked_804.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) }; var root_1272 any =
	A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()); var tmp29 any = A_arbace_go_check_A_const_168; var tmp30 any = A_arbace_go_check_A_const_169; var tmp31 any = A_arbace_go_check_A_const_170; var tmp32 any = jrt.IdentityHashMap_New(); var tmp33 any = A_arbace_go_check_A_const_171; var tmp34 any = A_arbace_go_check_A_const_61; var tmp35 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)); var tmp36 any = A_arbace_go_check_A_const_172; var tmp37 any = A_arbace_go_check_A_const_173.GetRawRoot__O(); var tmp38 any = A_arbace_go_check_A_const_174; var tmp39 any = A_arbace_go_check_A_const_175.GetRawRoot__O(); var tmp40 any = A_arbace_go_check_A_const_176; var tmp41 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp42 any = A_arbace_go_check_A_const_177; var tmp43 any = A_arbace_go_check_A_const_178.GetRawRoot__O(); var tmp44 any = A_arbace_go_check_A_const_179; var tmp45 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var tmp46 any = A_arbace_go_check_A_const_181; var tmp47 any = A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp48 *jrt.Class; var fncls__1280 *jrt.Class = A_arbace_go_check_check_package_fn__1685000131_A_fn_class; if









	fncls__1280 == nil { var fncls__1280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_package_fn__1685000131_A_fn_class = fncls__1280d; tmp48 = fncls__1280d } else { tmp48 = fncls__1280 }; var tmp49 any = /*line :174:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil); var tmp50 any = A_arbace_go_check_A_const_183; var tmp51 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var tmp52 any = A_arbace_go_check_A_const_185; var tmp53 any = A_arbace_go_check_A_const_186.GetRawRoot__O(); var tmp54 any = A_arbace_go_check_A_const_187; var tmp55 any = A_arbace_go_check_A_const_188.GetRawRoot__O(); var tmp56 any = A_arbace_go_check_A_const_189; var tmp57 any; var root_1281 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1283 lang.IFn; if














	linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = lang.PersistentVector_EMPTY.Ref(); if linked_1282 == nil { tmp57 = ifn_1283.Invoke_O__O(arg_1284) } else { tmp57 = linked_1282.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1281, arg_1284) }; var tmp58 any = tmp57; var tmp59 any = A_arbace_go_check_A_const_190; var tmp60 any; var root_1285 any = /*line :174:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1287 lang.IFn; if















	linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_191, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_192, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_193, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_194, lang.PersistentArrayMap_EMPTY.Ref())); if linked_1286 == nil { tmp60 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp60 = linked_1286.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1285, arg_1288) }; var tmp61 any = tmp60; var tmp62 any = A_arbace_go_check_A_const_195; var tmp63 any; var root_1289 any = /*line :174:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1291 lang.IFn; if
















	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.PersistentVector_EMPTY.Ref(); if linked_1290 == nil { tmp63 = ifn_1291.Invoke_O__O(arg_1292) } else { tmp63 = linked_1290.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1289, arg_1292) }; arg_1275 = /*line :174:1*/tmp28.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp29, pkg__8, tmp30, errors__9, tmp31, tmp32, tmp33, ctx__11, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp49, tmp50, tmp51, tmp52, tmp53, tmp54, tmp55, tmp56, tmp58, tmp59, tmp61, tmp62, tmp63)))); if linked_1273 == nil { ifn_1274.Invoke_O__O(arg_1275) } else { linked_1273.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1272, arg_1275) }; var tmp64 any; tmp270 := /*line :161:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000133__15 any; var root_1293 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1295 lang.IFn






























		if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = fis__12; if linked_1294 == nil { seq_1685000133__15 = ifn_1295.Invoke_O__O(arg_1296) } else { seq_1685000133__15 = linked_1294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1293, arg_1296) }
//line :161:1
		var chunk_1685000134__16 any; var count_1685000135__17 int64 = 0; var i_1685000136__18 int64 = 0; L1: for {






























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000136__18, count_1685000135__17) { var fi__19 any = lang.Indexed_Cast(chunk_1685000134__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000136__18)); var root_1356 any = A_arbace_go_check_A_const_197.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = fi__19; var arg_1360 any = resolve__1; if linked_1357 == nil { ifn_1358.Invoke_O_O__O(arg_1359, arg_1360) } else { linked_1357.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1356, arg_1359, arg_1360) }; seq_1685000133__15, chunk_1685000134__16, count_1685000135__17, i_1685000136__18 = seq_1685000133__15, chunk_1685000134__16, count_1685000135__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000136__18); continue L1 } else { var temp__1927000414__auto____19 any; var root_1297 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = seq_1685000133__15; if linked_1298 == nil { temp__1927000414__auto____19 = ifn_1299.Invoke_O__O(arg_1300) } else { temp__1927000414__auto____19 = linked_1298.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1297, arg_1300) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_1685000133__20 any = temp__1927000414__auto____19; var tmp65 any; var root_1301 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = seq_1685000133__20; if linked_1302 == nil { tmp65 = ifn_1303.Invoke_O__O(arg_1304) } else { tmp65 = linked_1302.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1301, arg_1304) }; if jrt.J2g_Truth(tmp65) { var c__1927000678__auto____21 any; var root_1305 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = seq_1685000133__20; if linked_1306 == nil { c__1927000678__auto____21 = ifn_1307.Invoke_O__O(arg_1308) } else { c__1927000678__auto____21 = linked_1306.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1305, arg_1308) }; var tmp66 any; var root_1361 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = seq_1685000133__20; if linked_1362 == nil { tmp66 = ifn_1363.Invoke_O__O(arg_1364) } else { tmp66 = linked_1362.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1361, arg_1364) }; seq_1685000133__15, chunk_1685000134__16, count_1685000135__17, i_1685000136__18 = tmp66, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__21 any; var root_1309 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = seq_1685000133__20; if linked_1310 == nil { fi__21 = ifn_1311.Invoke_O__O(arg_1312) } else { fi__21 = linked_1310.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1309, arg_1312) }; var root_1365 any = A_arbace_go_check_A_const_197.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = fi__21; var arg_1369 any = resolve__1; if linked_1366 == nil { ifn_1367.Invoke_O_O__O(arg_1368, arg_1369) } else { linked_1366.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1365, arg_1368, arg_1369) }; var tmp67 any; var root_1370 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = seq_1685000133__20; if linked_1371 == nil { tmp67 = ifn_1372.Invoke_O__O(arg_1373) } else { tmp67 = linked_1371.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1370, arg_1373) }; seq_1685000133__15, chunk_1685000134__16, count_1685000135__17, i_1685000136__18 = tmp67, nil, 0, 0; continue L1 } } }
//line :161:1
			break L1 }; var seq_1685000137__15 any; var root_1313 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1315 lang.IFn































		if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = fis__12; if linked_1314 == nil { seq_1685000137__15 = ifn_1315.Invoke_O__O(arg_1316) } else { seq_1685000137__15 = linked_1314.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1313, arg_1316) }
//line :161:1
		var chunk_1685000138__16 any; var count_1685000139__17 int64 = 0; var i_1685000140__18 int64 = 0; L2: for {































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000140__18, count_1685000139__17) { var fi__19_2 any = lang.Indexed_Cast(chunk_1685000138__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000140__18)); var root_1374 any = A_arbace_go_check_A_const_198.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = fi__19_2; if linked_1375 == nil { ifn_1376.Invoke_O__O(arg_1377) } else { linked_1375.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1374, arg_1377) }; seq_1685000137__15, chunk_1685000138__16, count_1685000139__17, i_1685000140__18 = seq_1685000137__15, chunk_1685000138__16, count_1685000139__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000140__18); continue L2 } else { var temp__1927000414__auto____19_2 any; var root_1317 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = seq_1685000137__15; if linked_1318 == nil { temp__1927000414__auto____19_2 = ifn_1319.Invoke_O__O(arg_1320) } else { temp__1927000414__auto____19_2 = linked_1318.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1317, arg_1320) }; if jrt.J2g_Truth(temp__1927000414__auto____19_2) { var seq_1685000137__20 any = temp__1927000414__auto____19_2; var tmp68 any; var root_1321 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = seq_1685000137__20; if linked_1322 == nil { tmp68 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp68 = linked_1322.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1321, arg_1324) }; if jrt.J2g_Truth(tmp68) { var c__1927000678__auto____21_2 any; var root_1325 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = seq_1685000137__20; if linked_1326 == nil { c__1927000678__auto____21_2 = ifn_1327.Invoke_O__O(arg_1328) } else { c__1927000678__auto____21_2 = linked_1326.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1325, arg_1328) }; var tmp69 any; var root_1378 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = seq_1685000137__20; if linked_1379 == nil { tmp69 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp69 = linked_1379.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1378, arg_1381) }; seq_1685000137__15, chunk_1685000138__16, count_1685000139__17, i_1685000140__18 = tmp69, c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__21_2 any; var root_1329 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = seq_1685000137__20; if linked_1330 == nil { fi__21_2 = ifn_1331.Invoke_O__O(arg_1332) } else { fi__21_2 = linked_1330.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1329, arg_1332) }; var root_1382 any = A_arbace_go_check_A_const_198.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = fi__21_2; if linked_1383 == nil { ifn_1384.Invoke_O__O(arg_1385) } else { linked_1383.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1382, arg_1385) }; var tmp70 any; var root_1386 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = seq_1685000137__20; if linked_1387 == nil { tmp70 = ifn_1388.Invoke_O__O(arg_1389) } else { tmp70 = linked_1387.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1386, arg_1389) }; seq_1685000137__15, chunk_1685000138__16, count_1685000139__17, i_1685000140__18 = tmp70, nil, 0, 0; continue L2 } } }
//line :161:1
			break L2 }; var seq_1685000141__15 any; var root_1333 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1335 lang.IFn
































		if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = fis__12; if linked_1334 == nil { seq_1685000141__15 = ifn_1335.Invoke_O__O(arg_1336) } else { seq_1685000141__15 = linked_1334.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1333, arg_1336) }
//line :161:1
		var chunk_1685000142__16 any; var count_1685000143__17 int64 = 0; var i_1685000144__18 int64 = 0; L3: for {
































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000144__18, count_1685000143__17) { var fi__19_3 any = lang.Indexed_Cast(chunk_1685000142__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000144__18)); var root_1390 any = A_arbace_go_check_A_const_199.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = fi__19_3; if linked_1391 == nil { ifn_1392.Invoke_O__O(arg_1393) } else { linked_1391.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1390, arg_1393) }; seq_1685000141__15, chunk_1685000142__16, count_1685000143__17, i_1685000144__18 = seq_1685000141__15, chunk_1685000142__16, count_1685000143__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000144__18); continue L3 } else { var temp__1927000414__auto____19_3 any; var root_1337 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = seq_1685000141__15; if linked_1338 == nil { temp__1927000414__auto____19_3 = ifn_1339.Invoke_O__O(arg_1340) } else { temp__1927000414__auto____19_3 = linked_1338.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1337, arg_1340) }; if jrt.J2g_Truth(temp__1927000414__auto____19_3) { var seq_1685000141__20 any = temp__1927000414__auto____19_3; var tmp71 any; var root_1341 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = seq_1685000141__20; if linked_1342 == nil { tmp71 = ifn_1343.Invoke_O__O(arg_1344) } else { tmp71 = linked_1342.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1341, arg_1344) }; if jrt.J2g_Truth(tmp71) { var c__1927000678__auto____21_3 any; var root_1345 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = seq_1685000141__20; if linked_1346 == nil { c__1927000678__auto____21_3 = ifn_1347.Invoke_O__O(arg_1348) } else { c__1927000678__auto____21_3 = linked_1346.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1345, arg_1348) }; var tmp72 any; var root_1394 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = seq_1685000141__20; if linked_1395 == nil { tmp72 = ifn_1396.Invoke_O__O(arg_1397) } else { tmp72 = linked_1395.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1394, arg_1397) }; seq_1685000141__15, chunk_1685000142__16, count_1685000143__17, i_1685000144__18 = tmp72, c__1927000678__auto____21_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__21_3 any; var root_1349 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = seq_1685000141__20; if linked_1350 == nil { fi__21_3 = ifn_1351.Invoke_O__O(arg_1352) } else { fi__21_3 = linked_1350.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1349, arg_1352) }; var root_1398 any = A_arbace_go_check_A_const_199.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = fi__21_3; if linked_1399 == nil { ifn_1400.Invoke_O__O(arg_1401) } else { linked_1399.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1398, arg_1401) }; var tmp73 any; var root_1402 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = seq_1685000141__20; if linked_1403 == nil { tmp73 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp73 = linked_1403.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1402, arg_1405) }; seq_1685000141__15, chunk_1685000142__16, count_1685000143__17, i_1685000144__18 = tmp73, nil, 0, 0; continue L3 } } }
//line :161:1
			break L3
		}
































		var root_1353 any = A_arbace_go_check_A_const_196.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; if linked_1354 == nil { ifn_1355.Invoke__O() } else { linked_1354.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1353) }
//line :161:1
		var objs__15 any; var root_815 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_817 lang.IFn


































		if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = A_arbace_go_check_A_const_114.Invoke_O__O(ctx__11); if linked_816 == nil { objs__15 = ifn_817.Invoke_O__O(arg_818) } else { objs__15 = linked_816.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_815, arg_818) }
//line :161:1
		var seq_1685000145__16 any; var root_1406 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1408 lang.IFn



































		if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any; var root_1410 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var arg_1414 any = objs__15; if linked_1411 == nil { arg_1409 = ifn_1412.Invoke_O_O__O(arg_1413, arg_1414) } else { arg_1409 = linked_1411.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1410, arg_1413, arg_1414) }; if linked_1407 == nil { seq_1685000145__16 = ifn_1408.Invoke_O__O(arg_1409) } else { seq_1685000145__16 = linked_1407.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1406, arg_1409) }
//line :161:1
		var chunk_1685000146__17 any; var count_1685000147__18 int64 = 0; var i_1685000148__19 int64 = 0; L4: for {



































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000148__19, count_1685000147__18) { var vec__1685000149__20 any = lang.Indexed_Cast(chunk_1685000146__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000148__19)); var i__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000149__20, lang.RT_IntCast_J__I_NoInit(0), nil); var x__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000149__20, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1608 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = x__22; var arg_1612 any = A_arbace_go_check_A_const_203; var arg_1613 any = i__21; if linked_1609 == nil { ifn_1610.Invoke_O_O_O__O(arg_1611, arg_1612, arg_1613) } else { linked_1609.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1608, arg_1611, arg_1612, arg_1613) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000148__19); continue L4 } else { var temp__1927000414__auto____20 any; var root_1415 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = seq_1685000145__16; if linked_1416 == nil { temp__1927000414__auto____20 = ifn_1417.Invoke_O__O(arg_1418) } else { temp__1927000414__auto____20 = linked_1416.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1415, arg_1418) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000145__21 any = temp__1927000414__auto____20; var tmp74 any; var root_1419 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = seq_1685000145__21; if linked_1420 == nil { tmp74 = ifn_1421.Invoke_O__O(arg_1422) } else { tmp74 = linked_1420.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1419, arg_1422) }; if jrt.J2g_Truth(tmp74) { var c__1927000678__auto____22 any; var root_1423 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = seq_1685000145__21; if linked_1424 == nil { c__1927000678__auto____22 = ifn_1425.Invoke_O__O(arg_1426) } else { c__1927000678__auto____22 = linked_1424.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1423, arg_1426) }; var tmp75 any; var root_1614 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = seq_1685000145__21; if linked_1615 == nil { tmp75 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp75 = linked_1615.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1614, arg_1617) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp75, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1685000152__22 any; var root_1427 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = seq_1685000145__21; if linked_1428 == nil { vec__1685000152__22 = ifn_1429.Invoke_O__O(arg_1430) } else { vec__1685000152__22 = linked_1428.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1427, arg_1430) }; var i__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000152__22, lang.RT_IntCast_J__I_NoInit(0), nil); var x__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000152__22, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1618 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = x__24; var arg_1622 any = A_arbace_go_check_A_const_203; var arg_1623 any = i__23; if linked_1619 == nil { ifn_1620.Invoke_O_O_O__O(arg_1621, arg_1622, arg_1623) } else { linked_1619.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1618, arg_1621, arg_1622, arg_1623) }; var tmp76 any; var root_1624 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = seq_1685000145__21; if linked_1625 == nil { tmp76 = ifn_1626.Invoke_O__O(arg_1627) } else { tmp76 = linked_1625.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1624, arg_1627) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp76, nil, 0, 0; continue L4 } } }
//line :161:1
			break L4
		}




































		var root_1431 any = A_arbace_go_check_A_const_200.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = objs__15; if linked_1432 == nil { ifn_1433.Invoke_O__O(arg_1434) } else { linked_1432.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A).Invoke_O_O__O(root_1431, arg_1434) }
//line :161:1
		var seq_1685000155__16 any; var root_1435 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1437 lang.IFn







































		if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = objs__15; if linked_1436 == nil { seq_1685000155__16 = ifn_1437.Invoke_O__O(arg_1438) } else { seq_1685000155__16 = linked_1436.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1435, arg_1438) }
//line :161:1
		var chunk_1685000156__17 any; var count_1685000157__18 int64 = 0; var i_1685000158__19 int64 = 0; L5: for {







































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000158__19, count_1685000157__18) { var x__20 any = lang.Indexed_Cast(chunk_1685000156__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000158__19)); var tmp77 any; var and__1927000168__auto____21 bool; var tmp78 any = A_arbace_go_check_A_const_54; var tmp79 any; var root_1439 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = x__20; var arg_1443 any = A_arbace_go_check_A_const_93; if linked_1440 == nil { tmp79 = ifn_1441.Invoke_O_O__O(arg_1442, arg_1443) } else { tmp79 = linked_1440.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1439, arg_1442, arg_1443) }; and__1927000168__auto____21 = lang.Util_Equiv_O_O__Z_NoInit(tmp78, tmp79); if and__1927000168__auto____21 { var root_1444 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any; var root_1448 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = x__20; var arg_1452 any = A_arbace_go_check_A_const_201; if linked_1449 == nil { arg_1447 = ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { arg_1447 = linked_1449.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; if linked_1445 == nil { tmp77 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp77 = linked_1445.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1444, arg_1447) } } else { tmp77 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }; if jrt.J2g_Truth(tmp77) { var root_1628 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = x__20; if linked_1629 == nil { ifn_1630.Invoke_O__O(arg_1631) } else { linked_1629.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1628, arg_1631) }; seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, i_1685000158__19 = seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000158__19); continue L5 } else { seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, i_1685000158__19 = seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000158__19); continue L5 } } else { var temp__1927000414__auto____20_2 any; var root_1453 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = seq_1685000155__16; if linked_1454 == nil { temp__1927000414__auto____20_2 = ifn_1455.Invoke_O__O(arg_1456) } else { temp__1927000414__auto____20_2 = linked_1454.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1453, arg_1456) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000155__21 any = temp__1927000414__auto____20_2; var tmp80 any; var root_1457 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = seq_1685000155__21; if linked_1458 == nil { tmp80 = ifn_1459.Invoke_O__O(arg_1460) } else { tmp80 = linked_1458.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1457, arg_1460) }; if jrt.J2g_Truth(tmp80) { var c__1927000678__auto____22_2 any; var root_1461 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = seq_1685000155__21; if linked_1462 == nil { c__1927000678__auto____22_2 = ifn_1463.Invoke_O__O(arg_1464) } else { c__1927000678__auto____22_2 = linked_1462.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1461, arg_1464) }; var tmp81 any; var root_1632 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = seq_1685000155__21; if linked_1633 == nil { tmp81 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp81 = linked_1633.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1632, arg_1635) }; seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, i_1685000158__19 = tmp81, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var x__22_2 any; var root_1465 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = seq_1685000155__21; if linked_1466 == nil { x__22_2 = ifn_1467.Invoke_O__O(arg_1468) } else { x__22_2 = linked_1466.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1465, arg_1468) }; var tmp82 any; var and__1927000168__auto____23 bool; var tmp83 any = A_arbace_go_check_A_const_54; var tmp84 any; var root_1469 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = x__22_2; var arg_1473 any = A_arbace_go_check_A_const_93; if linked_1470 == nil { tmp84 = ifn_1471.Invoke_O_O__O(arg_1472, arg_1473) } else { tmp84 = linked_1470.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1469, arg_1472, arg_1473) }; and__1927000168__auto____23 = lang.Util_Equiv_O_O__Z_NoInit(tmp83, tmp84); if and__1927000168__auto____23 { var root_1474 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any; var root_1478 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = x__22_2; var arg_1482 any = A_arbace_go_check_A_const_201; if linked_1479 == nil { arg_1477 = ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { arg_1477 = linked_1479.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }; if linked_1475 == nil { tmp82 = ifn_1476.Invoke_O__O(arg_1477) } else { tmp82 = linked_1475.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1474, arg_1477) } } else { tmp82 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }; if jrt.J2g_Truth(tmp82) { var root_1636 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = x__22_2; if linked_1637 == nil { ifn_1638.Invoke_O__O(arg_1639) } else { linked_1637.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1636, arg_1639) }; var tmp85 any; var root_1640 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = seq_1685000155__21; if linked_1641 == nil { tmp85 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp85 = linked_1641.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1640, arg_1643) }; seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, i_1685000158__19 = tmp85, nil, 0, 0; continue L5 } else { var tmp86 any; var root_1644 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = seq_1685000155__21; if linked_1645 == nil { tmp86 = ifn_1646.Invoke_O__O(arg_1647) } else { tmp86 = linked_1645.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1644, arg_1647) }; seq_1685000155__16, chunk_1685000156__17, count_1685000157__18, i_1685000158__19 = tmp86, nil, 0, 0; continue L5 } } } }
//line :161:1
			break L5 }; var seq_1685000159__16 any; var root_1483 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1485 lang.IFn








































		if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = objs__15; if linked_1484 == nil { seq_1685000159__16 = ifn_1485.Invoke_O__O(arg_1486) } else { seq_1685000159__16 = linked_1484.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1483, arg_1486) }
//line :161:1
		var chunk_1685000160__17 any; var count_1685000161__18 int64 = 0; var i_1685000162__19 int64 = 0; L6: for {








































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000162__19, count_1685000161__18) { var x__20_2 any = lang.Indexed_Cast(chunk_1685000160__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000162__19)); var tmp87 any; var and__1927000168__auto____21_2 bool; var tmp88 any = A_arbace_go_check_A_const_54; var tmp89 any; var root_1487 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = x__20_2; var arg_1491 any = A_arbace_go_check_A_const_93; if linked_1488 == nil { tmp89 = ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { tmp89 = linked_1488.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) }; and__1927000168__auto____21_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp88, tmp89); if and__1927000168__auto____21_2 { var root_1492 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = x__20_2; var arg_1496 any = A_arbace_go_check_A_const_201; if linked_1493 == nil { tmp87 = ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { tmp87 = linked_1493.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } } else { tmp87 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }; if jrt.J2g_Truth(tmp87) { var root_1648 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = x__20_2; if linked_1649 == nil { ifn_1650.Invoke_O__O(arg_1651) } else { linked_1649.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1648, arg_1651) }; seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, i_1685000162__19 = seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__19); continue L6 } else { seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, i_1685000162__19 = seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__19); continue L6 } } else { var temp__1927000414__auto____20_3 any; var root_1497 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = seq_1685000159__16; if linked_1498 == nil { temp__1927000414__auto____20_3 = ifn_1499.Invoke_O__O(arg_1500) } else { temp__1927000414__auto____20_3 = linked_1498.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1497, arg_1500) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000159__21 any = temp__1927000414__auto____20_3; var tmp90 any; var root_1501 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = seq_1685000159__21; if linked_1502 == nil { tmp90 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp90 = linked_1502.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1501, arg_1504) }; if jrt.J2g_Truth(tmp90) { var c__1927000678__auto____22_3 any; var root_1505 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = seq_1685000159__21; if linked_1506 == nil { c__1927000678__auto____22_3 = ifn_1507.Invoke_O__O(arg_1508) } else { c__1927000678__auto____22_3 = linked_1506.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1505, arg_1508) }; var tmp91 any; var root_1652 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = seq_1685000159__21; if linked_1653 == nil { tmp91 = ifn_1654.Invoke_O__O(arg_1655) } else { tmp91 = linked_1653.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1652, arg_1655) }; seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, i_1685000162__19 = tmp91, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__22_3 any; var root_1509 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = seq_1685000159__21; if linked_1510 == nil { x__22_3 = ifn_1511.Invoke_O__O(arg_1512) } else { x__22_3 = linked_1510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1509, arg_1512) }; var tmp92 any; var and__1927000168__auto____23_2 bool; var tmp93 any = A_arbace_go_check_A_const_54; var tmp94 any; var root_1513 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = x__22_3; var arg_1517 any = A_arbace_go_check_A_const_93; if linked_1514 == nil { tmp94 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { tmp94 = linked_1514.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }; and__1927000168__auto____23_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp93, tmp94); if and__1927000168__auto____23_2 { var root_1518 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = x__22_3; var arg_1522 any = A_arbace_go_check_A_const_201; if linked_1519 == nil { tmp92 = ifn_1520.Invoke_O_O__O(arg_1521, arg_1522) } else { tmp92 = linked_1519.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1518, arg_1521, arg_1522) } } else { tmp92 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23_2).Ref() }; if jrt.J2g_Truth(tmp92) { var root_1656 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = x__22_3; if linked_1657 == nil { ifn_1658.Invoke_O__O(arg_1659) } else { linked_1657.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1656, arg_1659) }; var tmp95 any; var root_1660 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = seq_1685000159__21; if linked_1661 == nil { tmp95 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp95 = linked_1661.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1660, arg_1663) }; seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, i_1685000162__19 = tmp95, nil, 0, 0; continue L6 } else { var tmp96 any; var root_1664 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = seq_1685000159__21; if linked_1665 == nil { tmp96 = ifn_1666.Invoke_O__O(arg_1667) } else { tmp96 = linked_1665.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1664, arg_1667) }; seq_1685000159__16, chunk_1685000160__17, count_1685000161__18, i_1685000162__19 = tmp96, nil, 0, 0; continue L6 } } } }
//line :161:1
			break L6 }; var seq_1685000163__16 any; var root_1523 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1525 lang.IFn









































		if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = objs__15; if linked_1524 == nil { seq_1685000163__16 = ifn_1525.Invoke_O__O(arg_1526) } else { seq_1685000163__16 = linked_1524.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1523, arg_1526) }
//line :161:1
		var chunk_1685000164__17 any; var count_1685000165__18 int64 = 0; var i_1685000166__19 int64 = 0; L7: for {









































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000166__19, count_1685000165__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1685000164__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000166__19)); var tmp97 any; var root_1527 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = A_arbace_go_check_A_const_54; var arg_1531 any; var root_1532 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = x__20_3; var arg_1536 any = A_arbace_go_check_A_const_93; if linked_1533 == nil { arg_1531 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { arg_1531 = linked_1533.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }; if linked_1528 == nil { tmp97 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { tmp97 = linked_1528.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) }; if jrt.J2g_Truth(tmp97) { var root_1668 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = x__20_3; if linked_1669 == nil { ifn_1670.Invoke_O__O(arg_1671) } else { linked_1669.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1668, arg_1671) }; seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, i_1685000166__19 = seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__19); continue L7 } else { seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, i_1685000166__19 = seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__19); continue L7 } } else { var temp__1927000414__auto____20_4 any; var root_1537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = seq_1685000163__16; if linked_1538 == nil { temp__1927000414__auto____20_4 = ifn_1539.Invoke_O__O(arg_1540) } else { temp__1927000414__auto____20_4 = linked_1538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1537, arg_1540) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000163__21 any = temp__1927000414__auto____20_4; var tmp98 any; var root_1541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = seq_1685000163__21; if linked_1542 == nil { tmp98 = ifn_1543.Invoke_O__O(arg_1544) } else { tmp98 = linked_1542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1541, arg_1544) }; if jrt.J2g_Truth(tmp98) { var c__1927000678__auto____22_4 any; var root_1545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = seq_1685000163__21; if linked_1546 == nil { c__1927000678__auto____22_4 = ifn_1547.Invoke_O__O(arg_1548) } else { c__1927000678__auto____22_4 = linked_1546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1545, arg_1548) }; var tmp99 any; var root_1672 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = seq_1685000163__21; if linked_1673 == nil { tmp99 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp99 = linked_1673.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1672, arg_1675) }; seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, i_1685000166__19 = tmp99, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22_4 any; var root_1549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = seq_1685000163__21; if linked_1550 == nil { x__22_4 = ifn_1551.Invoke_O__O(arg_1552) } else { x__22_4 = linked_1550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1549, arg_1552) }; var tmp100 any; var root_1553 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = A_arbace_go_check_A_const_54; var arg_1557 any; var root_1558 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = x__22_4; var arg_1562 any = A_arbace_go_check_A_const_93; if linked_1559 == nil { arg_1557 = ifn_1560.Invoke_O_O__O(arg_1561, arg_1562) } else { arg_1557 = linked_1559.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1558, arg_1561, arg_1562) }; if linked_1554 == nil { tmp100 = ifn_1555.Invoke_O_O__O(arg_1556, arg_1557) } else { tmp100 = linked_1554.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1553, arg_1556, arg_1557) }; if jrt.J2g_Truth(tmp100) { var root_1676 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = x__22_4; if linked_1677 == nil { ifn_1678.Invoke_O__O(arg_1679) } else { linked_1677.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1676, arg_1679) }; var tmp101 any; var root_1680 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = seq_1685000163__21; if linked_1681 == nil { tmp101 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp101 = linked_1681.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1680, arg_1683) }; seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, i_1685000166__19 = tmp101, nil, 0, 0; continue L7 } else { var tmp102 any; var root_1684 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = seq_1685000163__21; if linked_1685 == nil { tmp102 = ifn_1686.Invoke_O__O(arg_1687) } else { tmp102 = linked_1685.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1684, arg_1687) }; seq_1685000163__16, chunk_1685000164__17, count_1685000165__18, i_1685000166__19 = tmp102, nil, 0, 0; continue L7 } } } }
//line :161:1
			break L7 }; var seq_1685000167__16 any; var root_1563 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1565 lang.IFn











































		if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any; var root_1567 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = A_arbace_go_check_A_const_116.Invoke_O__O(ctx__11); if linked_1568 == nil { arg_1566 = ifn_1569.Invoke_O__O(arg_1570) } else { arg_1566 = linked_1568.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1567, arg_1570) }; if linked_1564 == nil { seq_1685000167__16 = ifn_1565.Invoke_O__O(arg_1566) } else { seq_1685000167__16 = linked_1564.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1563, arg_1566) }
//line :161:1
		var chunk_1685000168__17 any; var count_1685000169__18 int64 = 0; var i_1685000170__19 int64 = 0; L8: for {











































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000170__19, count_1685000169__18) { var x__20_4 any = lang.Indexed_Cast(chunk_1685000168__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000170__19)); var root_1688 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = x__20_4; if linked_1689 == nil { ifn_1690.Invoke_O__O(arg_1691) } else { linked_1689.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1688, arg_1691) }; seq_1685000167__16, chunk_1685000168__17, count_1685000169__18, i_1685000170__19 = seq_1685000167__16, chunk_1685000168__17, count_1685000169__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__19); continue L8 } else { var temp__1927000414__auto____20_5 any; var root_1571 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = seq_1685000167__16; if linked_1572 == nil { temp__1927000414__auto____20_5 = ifn_1573.Invoke_O__O(arg_1574) } else { temp__1927000414__auto____20_5 = linked_1572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1571, arg_1574) }; if jrt.J2g_Truth(temp__1927000414__auto____20_5) { var seq_1685000167__21 any = temp__1927000414__auto____20_5; var tmp103 any; var root_1575 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = seq_1685000167__21; if linked_1576 == nil { tmp103 = ifn_1577.Invoke_O__O(arg_1578) } else { tmp103 = linked_1576.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1575, arg_1578) }; if jrt.J2g_Truth(tmp103) { var c__1927000678__auto____22_5 any; var root_1579 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = seq_1685000167__21; if linked_1580 == nil { c__1927000678__auto____22_5 = ifn_1581.Invoke_O__O(arg_1582) } else { c__1927000678__auto____22_5 = linked_1580.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1579, arg_1582) }; var tmp104 any; var root_1692 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = seq_1685000167__21; if linked_1693 == nil { tmp104 = ifn_1694.Invoke_O__O(arg_1695) } else { tmp104 = linked_1693.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1692, arg_1695) }; seq_1685000167__16, chunk_1685000168__17, count_1685000169__18, i_1685000170__19 = tmp104, c__1927000678__auto____22_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__22_5 any; var root_1583 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = seq_1685000167__21; if linked_1584 == nil { x__22_5 = ifn_1585.Invoke_O__O(arg_1586) } else { x__22_5 = linked_1584.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1583, arg_1586) }; var root_1696 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = x__22_5; if linked_1697 == nil { ifn_1698.Invoke_O__O(arg_1699) } else { linked_1697.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1696, arg_1699) }; var tmp105 any; var root_1700 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = seq_1685000167__21; if linked_1701 == nil { tmp105 = ifn_1702.Invoke_O__O(arg_1703) } else { tmp105 = linked_1701.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1700, arg_1703) }; seq_1685000167__16, chunk_1685000168__17, count_1685000169__18, i_1685000170__19 = tmp105, nil, 0, 0; continue L8 } } }
//line :161:1
			break L8 }; L9: for { var vs__16 any; var root_1587 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1589 lang.IFn














































				if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = A_arbace_go_check_A_const_189.Get__O(); if linked_1588 == nil { vs__16 = ifn_1589.Invoke_O__O(arg_1590) } else { vs__16 = linked_1588.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1587, arg_1590) }
				var tmp106 any; var root_1591 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = vs__16; if linked_1592 == nil { tmp106 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp106 = linked_1592.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1591, arg_1594) }; if jrt.J2g_Truth(tmp106) {
					var root_1704 any = A_arbace_go_check_A_const_205.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = A_arbace_go_check_A_const_189.Get__O(); var arg_1708 any = lang.PersistentVector_EMPTY.Ref(); if linked_1705 == nil { ifn_1706.Invoke_O_O__O(arg_1707, arg_1708) } else { linked_1705.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1704, arg_1707, arg_1708) }
//line :209:1
					var seq_1685000171__17 any; var root_1709 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1711 lang.IFn

					if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = vs__16; if linked_1710 == nil { seq_1685000171__17 = ifn_1711.Invoke_O__O(arg_1712) } else { seq_1685000171__17 = linked_1710.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1709, arg_1712) }
//line :209:1
					var chunk_1685000172__18 any; var count_1685000173__19 int64 = 0; var i_1685000174__20 int64 = 0; L10: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000174__20, count_1685000173__19) { var v__21 any = lang.Indexed_Cast(chunk_1685000172__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000174__20)); lang.IFn_Cast(v__21).Invoke__O(); seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000174__20); continue L10 } else { var temp__1927000414__auto____21 any; var root_1713 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = seq_1685000171__17; if linked_1714 == nil { temp__1927000414__auto____21 = ifn_1715.Invoke_O__O(arg_1716) } else { temp__1927000414__auto____21 = linked_1714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1713, arg_1716) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000171__22 any = temp__1927000414__auto____21; var tmp107 any; var root_1717 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = seq_1685000171__22; if linked_1718 == nil { tmp107 = ifn_1719.Invoke_O__O(arg_1720) } else { tmp107 = linked_1718.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1717, arg_1720) }; if jrt.J2g_Truth(tmp107) { var c__1927000678__auto____23 any; var root_1721 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = seq_1685000171__22; if linked_1722 == nil { c__1927000678__auto____23 = ifn_1723.Invoke_O__O(arg_1724) } else { c__1927000678__auto____23 = linked_1722.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1721, arg_1724) }; var tmp108 any; var root_1729 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = seq_1685000171__22; if linked_1730 == nil { tmp108 = ifn_1731.Invoke_O__O(arg_1732) } else { tmp108 = linked_1730.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1729, arg_1732) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp108, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L10 } else { var v__23 any; var root_1725 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = seq_1685000171__22; if linked_1726 == nil { v__23 = ifn_1727.Invoke_O__O(arg_1728) } else { v__23 = linked_1726.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1725, arg_1728) }; lang.IFn_Cast(v__23).Invoke__O(); var tmp109 any; var root_1733 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = seq_1685000171__22; if linked_1734 == nil { tmp109 = ifn_1735.Invoke_O__O(arg_1736) } else { tmp109 = linked_1734.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1733, arg_1736) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp109, nil, 0, 0; continue L10 } } }
//line :209:1
						break L10
					}

					continue L9 }
//line :161:1
				break L9
			}


















































		var root_1595 any = A_arbace_go_check_A_const_202.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, A_arbace_go_check_number_local_types_BANG__A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any; var root_1599 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any; var root_1603 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = pkg__8; var arg_1607 any = A_arbace_go_check_A_const_112; if linked_1604 == nil { arg_1602 = ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { arg_1602 = linked_1604.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) }; if linked_1600 == nil { arg_1598 = ifn_1601.Invoke_O__O(arg_1602) } else { arg_1598 = linked_1600.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1599, arg_1602) }; if linked_1596 == nil { ifn_1597.Invoke_O__O(arg_1598) } else { linked_1596.(*A_arbace_go_check_number_local_types_BANG__A).Invoke_O_O__O(root_1595, arg_1598) }
//line :161:1
		var decls__16 any; var root_819 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_821 lang.IFn




















































		if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any; var root_823 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var tmp110 any = A_arbace_go_check_check_package_fn__1685000175_A_New(); var tmp111 *jrt.Class; var fncls__833 *jrt.Class = A_arbace_go_check_check_package_fn__1685000175_A_fn_class; if fncls__833 == nil { var fncls__833d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_check_package_fn__1685000175_A_fn_class = fncls__833d; tmp111 = fncls__833d } else { tmp111 = fncls__833 }; arg_826 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp110, tmp111, nil); var arg_827 any = objs__15; if linked_824 == nil { arg_822 = ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { arg_822 = linked_824.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_823, arg_826, arg_827) }; if linked_820 == nil { decls__16 = ifn_821.Invoke_O__O(arg_822) } else { decls__16 = linked_820.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_819, arg_822) }
//line :161:1
		var seq_1685000177__17 any; var root_1737 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1739 lang.IFn





















































		if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = decls__16; if linked_1738 == nil { seq_1685000177__17 = ifn_1739.Invoke_O__O(arg_1740) } else { seq_1685000177__17 = linked_1738.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1737, arg_1740) }
//line :161:1
		var chunk_1685000178__18 any; var count_1685000179__19 int64 = 0; var i_1685000180__20 int64 = 0; L11: for {





















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000180__20, count_1685000179__19) { var d__21 any = lang.Indexed_Cast(chunk_1685000178__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000180__20)); L12: for { var ls__22 any; var tmp112 *lang.Keyword = A_arbace_go_check_A_const_207; var tmp113 any; var root_1833 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1835 lang.IFn

				if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = d__21; if linked_1834 == nil { tmp113 = ifn_1835.Invoke_O__O(arg_1836) } else { tmp113 = linked_1834.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1833, arg_1836) }; ls__22 = tmp112.Invoke_O__O(tmp113)
				var tmp114 any; var root_1837 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = ls__22; if linked_1838 == nil { tmp114 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp114 = linked_1838.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1837, arg_1840) }; if jrt.J2g_Truth(tmp114) {
					var tmp115 *lang.Volatile = lang.Volatile_Cast(d__21); var tmp116 any; var root_1841 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = jrt.NN(lang.Volatile_Cast(d__21)).Deref__O(); var arg_1845 any = A_arbace_go_check_A_const_207; var arg_1846 any = lang.PersistentVector_EMPTY.Ref(); if linked_1842 == nil { tmp116 = ifn_1843.Invoke_O_O_O__O(arg_1844, arg_1845, arg_1846) } else { tmp116 = linked_1842.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1841, arg_1844, arg_1845, arg_1846) }; jrt.NN(tmp115).Reset_O__O(tmp116)
					var root_1893 any = A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any; var tmp117 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()); var tmp118 any = A_arbace_go_check_A_const_211; var tmp119 any = A_arbace_go_check_A_const_212; var tmp120 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp121 any; var root_1906 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = d__21; if linked_1907 == nil { tmp121 = ifn_1908.Invoke_O__O(arg_1909) } else { tmp121 = linked_1907.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1906, arg_1909) }; var tmp122 any = tmp120.Invoke_O__O(tmp121); var tmp123 any = A_arbace_go_check_A_const_213; var tmp124 any; var G__1685000181__23_ any; var tmp125 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp126 any; var root_1910 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = d__21; if linked_1911 == nil { tmp126 = ifn_1912.Invoke_O__O(arg_1913) } else { tmp126 = linked_1911.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1910, arg_1913) }; G__1685000181__23_ = tmp125.Invoke_O__O(tmp126); if lang.Util_Identical_O_O__Z_NoInit(G__1685000181__23_, nil) { tmp124 = nil } else { var root_1914 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = G__1685000181__23_; var arg_1918 any = A_arbace_go_check_A_const_78; if linked_1915 == nil { tmp124 = ifn_1916.Invoke_O_O__O(arg_1917, arg_1918) } else { tmp124 = linked_1915.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1914, arg_1917, arg_1918) } }; arg_1896 = tmp117.Invoke_O_O_O_O_O_O__O(tmp118, d__21, tmp119, tmp122, tmp123, tmp124); if linked_1894 == nil { ifn_1895.Invoke_O__O(arg_1896) } else { linked_1894.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1893, arg_1896) }; var tmp127 any = A_arbace_go_check_check_package_fn__1685000182_A_New_O_O(d__21, ls__22); var tmp128 *jrt.Class; var fncls__1892 *jrt.Class = A_arbace_go_check_check_package_fn__1685000182_A_fn_class; if fncls__1892 == nil { var fncls__1892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000182_A_fn_class = fncls__1892d; tmp128 = fncls__1892d } else { tmp128 = fncls__1892 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp127, tmp128, nil).Invoke__O()


					continue L12 }
//line :215:1
				break L12 }; seq_1685000177__17, chunk_1685000178__18, count_1685000179__19, i_1685000180__20 = seq_1685000177__17, chunk_1685000178__18, count_1685000179__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000180__20); continue L11 } else { var temp__1927000414__auto____21_2 any; var root_1741 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = seq_1685000177__17; if linked_1742 == nil { temp__1927000414__auto____21_2 = ifn_1743.Invoke_O__O(arg_1744) } else { temp__1927000414__auto____21_2 = linked_1742.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1741, arg_1744) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000177__22 any = temp__1927000414__auto____21_2; var tmp129 any; var root_1745 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1747 lang.IFn; if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any = seq_1685000177__22; if linked_1746 == nil { tmp129 = ifn_1747.Invoke_O__O(arg_1748) } else { tmp129 = linked_1746.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1745, arg_1748) }; if jrt.J2g_Truth(tmp129) { var c__1927000678__auto____23_2 any; var root_1749 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = seq_1685000177__22; if linked_1750 == nil { c__1927000678__auto____23_2 = ifn_1751.Invoke_O__O(arg_1752) } else { c__1927000678__auto____23_2 = linked_1750.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1749, arg_1752) }; var tmp130 any; var root_1919 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = seq_1685000177__22; if linked_1920 == nil { tmp130 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp130 = linked_1920.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1919, arg_1922) }; seq_1685000177__17, chunk_1685000178__18, count_1685000179__19, i_1685000180__20 = tmp130, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var d__23 any; var root_1753 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = seq_1685000177__22; if linked_1754 == nil { d__23 = ifn_1755.Invoke_O__O(arg_1756) } else { d__23 = linked_1754.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1753, arg_1756) }; L13: for { var ls__24 any; var tmp131 *lang.Keyword = A_arbace_go_check_A_const_207; var tmp132 any; var root_1923 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1925 lang.IFn

					if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = d__23; if linked_1924 == nil { tmp132 = ifn_1925.Invoke_O__O(arg_1926) } else { tmp132 = linked_1924.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1923, arg_1926) }; ls__24 = tmp131.Invoke_O__O(tmp132)
					var tmp133 any; var root_1927 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = ls__24; if linked_1928 == nil { tmp133 = ifn_1929.Invoke_O__O(arg_1930) } else { tmp133 = linked_1928.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1927, arg_1930) }; if jrt.J2g_Truth(tmp133) {
						var tmp134 *lang.Volatile = lang.Volatile_Cast(d__23); var tmp135 any; var root_1931 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1931, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1933 lang.IFn; if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = jrt.NN(lang.Volatile_Cast(d__23)).Deref__O(); var arg_1935 any = A_arbace_go_check_A_const_207; var arg_1936 any = lang.PersistentVector_EMPTY.Ref(); if linked_1932 == nil { tmp135 = ifn_1933.Invoke_O_O_O__O(arg_1934, arg_1935, arg_1936) } else { tmp135 = linked_1932.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1931, arg_1934, arg_1935, arg_1936) }; jrt.NN(tmp134).Reset_O__O(tmp135)
						var root_1983 any = A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any; var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()); var tmp137 any = A_arbace_go_check_A_const_211; var tmp138 any = A_arbace_go_check_A_const_212; var tmp139 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp140 any; var root_1996 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = d__23; if linked_1997 == nil { tmp140 = ifn_1998.Invoke_O__O(arg_1999) } else { tmp140 = linked_1997.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1996, arg_1999) }; var tmp141 any = tmp139.Invoke_O__O(tmp140); var tmp142 any = A_arbace_go_check_A_const_213; var tmp143 any; var G__1685000188__25_ any; var tmp144 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp145 any; var root_2000 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = d__23; if linked_2001 == nil { tmp145 = ifn_2002.Invoke_O__O(arg_2003) } else { tmp145 = linked_2001.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2000, arg_2003) }; G__1685000188__25_ = tmp144.Invoke_O__O(tmp145); if lang.Util_Identical_O_O__Z_NoInit(G__1685000188__25_, nil) { tmp143 = nil } else { var root_2004 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = G__1685000188__25_; var arg_2008 any = A_arbace_go_check_A_const_78; if linked_2005 == nil { tmp143 = ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { tmp143 = linked_2005.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) } }; arg_1986 = tmp136.Invoke_O_O_O_O_O_O__O(tmp137, d__23, tmp138, tmp141, tmp142, tmp143); if linked_1984 == nil { ifn_1985.Invoke_O__O(arg_1986) } else { linked_1984.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1983, arg_1986) }; var tmp146 any = A_arbace_go_check_check_package_fn__1685000189_A_New_O_O(d__23, ls__24); var tmp147 *jrt.Class; var fncls__1982 *jrt.Class = A_arbace_go_check_check_package_fn__1685000189_A_fn_class; if fncls__1982 == nil { var fncls__1982d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000189_A_fn_class = fncls__1982d; tmp147 = fncls__1982d } else { tmp147 = fncls__1982 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp146, tmp147, nil).Invoke__O()


						continue L13 }
//line :215:1
					break L13 }; var tmp148 any; var root_2009 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = seq_1685000177__22; if linked_2010 == nil { tmp148 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp148 = linked_2010.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2009, arg_2012) }; seq_1685000177__17, chunk_1685000178__18, count_1685000179__19, i_1685000180__20 = tmp148, nil, 0, 0; continue L11 } } }
//line :161:1
			break L11 }; var seq_1685000195__17 any; var root_1757 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1759 lang.IFn































































		if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = decls__16; if linked_1758 == nil { seq_1685000195__17 = ifn_1759.Invoke_O__O(arg_1760) } else { seq_1685000195__17 = linked_1758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1757, arg_1760) }
//line :161:1
		var chunk_1685000196__18 any; var count_1685000197__19 int64 = 0; var i_1685000198__20 int64 = 0; L14: for {































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000198__20, count_1685000197__19) { var d__21_2 any = lang.Indexed_Cast(chunk_1685000196__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000198__20)); var tmp149 *lang.Keyword = A_arbace_go_check_A_const_206; var tmp150 any; var root_1761 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = d__21_2; if linked_1762 == nil { tmp150 = ifn_1763.Invoke_O__O(arg_1764) } else { tmp150 = linked_1762.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1761, arg_1764) }; if jrt.J2g_Truth(tmp149.Invoke_O__O(tmp150)) {
				var root_2025 any = A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any; var tmp151 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()); var tmp152 any = A_arbace_go_check_A_const_211; var tmp153 any = A_arbace_go_check_A_const_212; var tmp154 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp155 any; var root_2036 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = d__21_2; if linked_2037 == nil { tmp155 = ifn_2038.Invoke_O__O(arg_2039) } else { tmp155 = linked_2037.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2036, arg_2039) }; arg_2028 = tmp151.Invoke_O_O_O_O__O(tmp152, d__21_2, tmp153, tmp154.Invoke_O__O(tmp155)); if linked_2026 == nil { ifn_2027.Invoke_O__O(arg_2028) } else { linked_2026.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2025, arg_2028) }; var tmp156 any = A_arbace_go_check_check_package_fn__1685000199_A_New_O(d__21_2); var tmp157 *jrt.Class; var fncls__2024 *jrt.Class = A_arbace_go_check_check_package_fn__1685000199_A_fn_class; if fncls__2024 == nil { var fncls__2024d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_check_check_package_fn__1685000199_A_fn_class = fncls__2024d; tmp157 = fncls__2024d } else { tmp157 = fncls__2024 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp156, tmp157, nil).Invoke__O()
//line :225:1
				seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, i_1685000198__20 = seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000198__20); continue L14 } else { seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, i_1685000198__20 = seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000198__20); continue L14 } } else { var temp__1927000414__auto____21_3 any; var root_1765 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = seq_1685000195__17; if linked_1766 == nil { temp__1927000414__auto____21_3 = ifn_1767.Invoke_O__O(arg_1768) } else { temp__1927000414__auto____21_3 = linked_1766.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1765, arg_1768) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000195__22 any = temp__1927000414__auto____21_3; var tmp158 any; var root_1769 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = seq_1685000195__22; if linked_1770 == nil { tmp158 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp158 = linked_1770.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1769, arg_1772) }; if jrt.J2g_Truth(tmp158) { var c__1927000678__auto____23_3 any; var root_1773 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = seq_1685000195__22; if linked_1774 == nil { c__1927000678__auto____23_3 = ifn_1775.Invoke_O__O(arg_1776) } else { c__1927000678__auto____23_3 = linked_1774.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1773, arg_1776) }; var tmp159 any; var root_2040 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = seq_1685000195__22; if linked_2041 == nil { tmp159 = ifn_2042.Invoke_O__O(arg_2043) } else { tmp159 = linked_2041.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2040, arg_2043) }; seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, i_1685000198__20 = tmp159, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var d__23_2 any; var root_1777 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = seq_1685000195__22; if linked_1778 == nil { d__23_2 = ifn_1779.Invoke_O__O(arg_1780) } else { d__23_2 = linked_1778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1777, arg_1780) }; var tmp160 *lang.Keyword = A_arbace_go_check_A_const_206; var tmp161 any; var root_1781 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = d__23_2; if linked_1782 == nil { tmp161 = ifn_1783.Invoke_O__O(arg_1784) } else { tmp161 = linked_1782.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1781, arg_1784) }; if jrt.J2g_Truth(tmp160.Invoke_O__O(tmp161)) {
					var root_2056 any = A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2058 lang.IFn; if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any; var tmp162 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()); var tmp163 any = A_arbace_go_check_A_const_211; var tmp164 any = A_arbace_go_check_A_const_212; var tmp165 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp166 any; var root_2067 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = d__23_2; if linked_2068 == nil { tmp166 = ifn_2069.Invoke_O__O(arg_2070) } else { tmp166 = linked_2068.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2067, arg_2070) }; arg_2059 = tmp162.Invoke_O_O_O_O__O(tmp163, d__23_2, tmp164, tmp165.Invoke_O__O(tmp166)); if linked_2057 == nil { ifn_2058.Invoke_O__O(arg_2059) } else { linked_2057.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2056, arg_2059) }; var tmp167 any = A_arbace_go_check_check_package_fn__1685000201_A_New_O(d__23_2); var tmp168 *jrt.Class; var fncls__2055 *jrt.Class = A_arbace_go_check_check_package_fn__1685000201_A_fn_class; if fncls__2055 == nil { var fncls__2055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_check_check_package_fn__1685000201_A_fn_class = fncls__2055d; tmp168 = fncls__2055d } else { tmp168 = fncls__2055 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp167, tmp168, nil).Invoke__O()
//line :225:1
					var tmp169 any; var root_2071 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = seq_1685000195__22; if linked_2072 == nil { tmp169 = ifn_2073.Invoke_O__O(arg_2074) } else { tmp169 = linked_2072.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2071, arg_2074) }; seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, i_1685000198__20 = tmp169, nil, 0, 0; continue L14 } else { var tmp170 any; var root_2075 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = seq_1685000195__22; if linked_2076 == nil { tmp170 = ifn_2077.Invoke_O__O(arg_2078) } else { tmp170 = linked_2076.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2075, arg_2078) }; seq_1685000195__17, chunk_1685000196__18, count_1685000197__19, i_1685000198__20 = tmp170, nil, 0, 0; continue L14 } } } }
//line :161:1
			break L14 }; var seq_1685000203__17 any; var root_1785 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1787 lang.IFn



































































		if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = decls__16; if linked_1786 == nil { seq_1685000203__17 = ifn_1787.Invoke_O__O(arg_1788) } else { seq_1685000203__17 = linked_1786.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1785, arg_1788) }
//line :161:1
		var chunk_1685000204__18 any; var count_1685000205__19 int64 = 0; var i_1685000206__20 int64 = 0; L15: for {



































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000206__20, count_1685000205__19) { var d__21_3 any = lang.Indexed_Cast(chunk_1685000204__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000206__20)); var tmp171 *lang.Keyword = A_arbace_go_check_A_const_142; var tmp172 any; var root_1789 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = d__21_3; if linked_1790 == nil { tmp172 = ifn_1791.Invoke_O__O(arg_1792) } else { tmp172 = linked_1790.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1789, arg_1792) }; if jrt.J2g_Truth(tmp171.Invoke_O__O(tmp172)) {
				var root_2079 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any; var tmp173 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp174 any; var root_2084 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = d__21_3; if linked_2085 == nil { tmp174 = ifn_2086.Invoke_O__O(arg_2087) } else { tmp174 = linked_2085.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2084, arg_2087) }; arg_2082 = tmp173.Invoke_O__O(tmp174); var arg_2083 any; var tmp175 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp176 any; var root_2088 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = d__21_3; if linked_2089 == nil { tmp176 = ifn_2090.Invoke_O__O(arg_2091) } else { tmp176 = linked_2089.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2088, arg_2091) }; arg_2083 = tmp175.Invoke_O__O(tmp176); if linked_2080 == nil { ifn_2081.Invoke_O_O__O(arg_2082, arg_2083) } else { linked_2080.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2079, arg_2082, arg_2083) }
//line :229:1
				seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, i_1685000206__20 = seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000206__20); continue L15 } else { seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, i_1685000206__20 = seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000206__20); continue L15 } } else { var temp__1927000414__auto____21_4 any; var root_1793 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = seq_1685000203__17; if linked_1794 == nil { temp__1927000414__auto____21_4 = ifn_1795.Invoke_O__O(arg_1796) } else { temp__1927000414__auto____21_4 = linked_1794.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1793, arg_1796) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000203__22 any = temp__1927000414__auto____21_4; var tmp177 any; var root_1797 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = seq_1685000203__22; if linked_1798 == nil { tmp177 = ifn_1799.Invoke_O__O(arg_1800) } else { tmp177 = linked_1798.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1797, arg_1800) }; if jrt.J2g_Truth(tmp177) { var c__1927000678__auto____23_4 any; var root_1801 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = seq_1685000203__22; if linked_1802 == nil { c__1927000678__auto____23_4 = ifn_1803.Invoke_O__O(arg_1804) } else { c__1927000678__auto____23_4 = linked_1802.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1801, arg_1804) }; var tmp178 any; var root_2092 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = seq_1685000203__22; if linked_2093 == nil { tmp178 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp178 = linked_2093.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2092, arg_2095) }; seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, i_1685000206__20 = tmp178, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__23_3 any; var root_1805 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = seq_1685000203__22; if linked_1806 == nil { d__23_3 = ifn_1807.Invoke_O__O(arg_1808) } else { d__23_3 = linked_1806.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1805, arg_1808) }; var tmp179 *lang.Keyword = A_arbace_go_check_A_const_142; var tmp180 any; var root_1809 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = d__23_3; if linked_1810 == nil { tmp180 = ifn_1811.Invoke_O__O(arg_1812) } else { tmp180 = linked_1810.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1809, arg_1812) }; if jrt.J2g_Truth(tmp179.Invoke_O__O(tmp180)) {
					var root_2096 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any; var tmp181 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp182 any; var root_2101 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = d__23_3; if linked_2102 == nil { tmp182 = ifn_2103.Invoke_O__O(arg_2104) } else { tmp182 = linked_2102.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2101, arg_2104) }; arg_2099 = tmp181.Invoke_O__O(tmp182); var arg_2100 any; var tmp183 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp184 any; var root_2105 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = d__23_3; if linked_2106 == nil { tmp184 = ifn_2107.Invoke_O__O(arg_2108) } else { tmp184 = linked_2106.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2105, arg_2108) }; arg_2100 = tmp183.Invoke_O__O(tmp184); if linked_2097 == nil { ifn_2098.Invoke_O_O__O(arg_2099, arg_2100) } else { linked_2097.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2096, arg_2099, arg_2100) }
//line :229:1
					var tmp185 any; var root_2109 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any = seq_1685000203__22; if linked_2110 == nil { tmp185 = ifn_2111.Invoke_O__O(arg_2112) } else { tmp185 = linked_2110.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2109, arg_2112) }; seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, i_1685000206__20 = tmp185, nil, 0, 0; continue L15 } else { var tmp186 any; var root_2113 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = seq_1685000203__22; if linked_2114 == nil { tmp186 = ifn_2115.Invoke_O__O(arg_2116) } else { tmp186 = linked_2114.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2113, arg_2116) }; seq_1685000203__17, chunk_1685000204__18, count_1685000205__19, i_1685000206__20 = tmp186, nil, 0, 0; continue L15 } } } }
//line :161:1
			break L15 }; var seq_1685000207__17 any; var root_1813 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1815 lang.IFn





































































		if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = fis__12; if linked_1814 == nil { seq_1685000207__17 = ifn_1815.Invoke_O__O(arg_1816) } else { seq_1685000207__17 = linked_1814.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1813, arg_1816) }
//line :161:1
		var chunk_1685000208__18 any; var count_1685000209__19 int64 = 0; var i_1685000210__20 int64 = 0; L16: for {





































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000210__20, count_1685000209__19) { var fi__21_4 any = lang.Indexed_Cast(chunk_1685000208__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000210__20)); var root_2117 any = A_arbace_go_check_A_const_217.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = fi__21_4; if linked_2118 == nil { ifn_2119.Invoke_O__O(arg_2120) } else { linked_2118.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2117, arg_2120) }; seq_1685000207__17, chunk_1685000208__18, count_1685000209__19, i_1685000210__20 = seq_1685000207__17, chunk_1685000208__18, count_1685000209__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__20); continue L16 } else { var temp__1927000414__auto____21_5 any; var root_1817 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = seq_1685000207__17; if linked_1818 == nil { temp__1927000414__auto____21_5 = ifn_1819.Invoke_O__O(arg_1820) } else { temp__1927000414__auto____21_5 = linked_1818.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1817, arg_1820) }; if jrt.J2g_Truth(temp__1927000414__auto____21_5) { var seq_1685000207__22 any = temp__1927000414__auto____21_5; var tmp187 any; var root_1821 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = seq_1685000207__22; if linked_1822 == nil { tmp187 = ifn_1823.Invoke_O__O(arg_1824) } else { tmp187 = linked_1822.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1821, arg_1824) }; if jrt.J2g_Truth(tmp187) { var c__1927000678__auto____23_5 any; var root_1825 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = seq_1685000207__22; if linked_1826 == nil { c__1927000678__auto____23_5 = ifn_1827.Invoke_O__O(arg_1828) } else { c__1927000678__auto____23_5 = linked_1826.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1825, arg_1828) }; var tmp188 any; var root_2121 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any = seq_1685000207__22; if linked_2122 == nil { tmp188 = ifn_2123.Invoke_O__O(arg_2124) } else { tmp188 = linked_2122.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2121, arg_2124) }; seq_1685000207__17, chunk_1685000208__18, count_1685000209__19, i_1685000210__20 = tmp188, c__1927000678__auto____23_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var fi__23 any; var root_1829 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = seq_1685000207__22; if linked_1830 == nil { fi__23 = ifn_1831.Invoke_O__O(arg_1832) } else { fi__23 = linked_1830.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1829, arg_1832) }; var root_2125 any = A_arbace_go_check_A_const_217.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = fi__23; if linked_2126 == nil { ifn_2127.Invoke_O__O(arg_2128) } else { linked_2126.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2125, arg_2128) }; var tmp189 any; var root_2129 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = seq_1685000207__22; if linked_2130 == nil { tmp189 = ifn_2131.Invoke_O__O(arg_2132) } else { tmp189 = linked_2130.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2129, arg_2132) }; seq_1685000207__17, chunk_1685000208__18, count_1685000209__19, i_1685000210__20 = tmp189, nil, 0, 0; continue L16 } } }
//line :161:1
			break L16 }; var order__17 any; var root_834 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_836 lang.IFn







































































		if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = objs__15; if linked_835 == nil { order__17 = ifn_836.Invoke_O__O(arg_837) } else { order__17 = linked_835.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_834, arg_837) }
//line :161:1
		var ___18 any; var tmp190 any; var root_838 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_840 lang.IFn; _ = ___18









































































		if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any; var root_842 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = errors__9; if linked_843 == nil { arg_841 = ifn_844.Invoke_O__O(arg_845) } else { arg_841 = linked_843.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_842, arg_845) }; if linked_839 == nil { tmp190 = ifn_840.Invoke_O__O(arg_841) } else { tmp190 = linked_839.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_838, arg_841) }; if jrt.J2g_Truth(tmp190) { var root_846 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; if linked_847 == nil { ___18 = ifn_848.Invoke__O() } else { ___18 = linked_847.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A).Invoke_O__O(root_846) } } else { ___18 = nil }
//line :161:1
		var ___19 any; var tmp191 any; var root_849 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_851 lang.IFn; _ = ___19











































































		if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any; var root_853 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = errors__9; if linked_854 == nil { arg_852 = ifn_855.Invoke_O__O(arg_856) } else { arg_852 = linked_854.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_853, arg_856) }; if linked_850 == nil { tmp191 = ifn_851.Invoke_O__O(arg_852) } else { tmp191 = linked_850.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_849, arg_852) }; if jrt.J2g_Truth(tmp191) { var root_857 any = A_arbace_go_check_A_const_128.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; if linked_858 == nil { ___19 = ifn_859.Invoke__O() } else { ___19 = linked_858.(*aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A).Invoke_O__O(root_857) } } else { ___19 = nil }
//line :161:1
		var say__20 any; var root_860 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_862 lang.IFn












































































		if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = src__0; var arg_864 any = A_arbace_go_check_A_const_129; if linked_861 == nil { say__20 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { say__20 = linked_861.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }
//line :161:1
		var init_entry__21 any; var tmp192 any = A_arbace_go_check_check_package_init_entry__1685000211_A_New(); var tmp193 *jrt.Class
		var fncls__905 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000211_A_fn_class













































































		if fncls__905 == nil { var fncls__905d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_check_package_init_entry__1685000211_A_fn_class = fncls__905d; tmp193 = fncls__905d } else { tmp193 = fncls__905 }; init_entry__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp192, tmp193, nil)
//line :161:1
		var have__22 any; var root_906 any = A_arbace_go_check_A_const_119.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_908 lang.IFn
















































































		if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = init_entry__21; var arg_910 any = order__17; if linked_907 == nil { have__22 = ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { have__22 = linked_907.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) }
//line :161:1
		var norm__23 any; var tmp194 any = A_arbace_go_check_check_package_norm__1685000215_A_New(); var tmp195 *jrt.Class
		var fncls__939 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000215_A_fn_class


















































































		if fncls__939 == nil { var fncls__939d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_norm__1685000215_A_fn_class = fncls__939d; tmp195 = fncls__939d } else { tmp195 = fncls__939 }; norm__23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp194, tmp195, nil)
//line :161:1
		var init_result__24 any; var tmp196 any; var root_940 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_942 lang.IFn























































































		if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = say__20; if linked_941 == nil { tmp196 = ifn_942.Invoke_O__O(arg_943) } else { tmp196 = linked_941.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_940, arg_943) }; if jrt.J2g_Truth(tmp196) {
			var tmp197 any; var root_944 any = A_arbace_go_check_A_const_119.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = norm__23; var arg_948 any = say__20; if linked_945 == nil { tmp197 = ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { tmp197 = linked_945.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_944, arg_947, arg_948) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp197, have__22) { var tmp198 any = A_arbace_go_check_A_const_137; var tmp199 any = jrt.Boolean_TRUE.Ref(); var tmp200 any = A_arbace_go_check_A_const_138; init_result__24 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp198, tmp199, tmp200, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__20)).Ref())) } else {

				var root_2133 any = A_arbace_go_check_A_const_218.GetRawRoot__O(); var linked_2134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2133, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_2135 lang.IFn; if linked_2134 == nil { ifn_2135 = lang.IFn_Cast(root_2133) } else { ifn_2135 = nil }; var arg_2136 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_219.Invoke_O__O(src__0)) { arg_2136 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_219.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp201 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp202 any; var root_2140 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = A_arbace_go_check_A_const_121.Invoke_O__O(src__0); if linked_2141 == nil { tmp202 = ifn_2142.Invoke_O__O(arg_2143) } else { tmp202 = linked_2141.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2140, arg_2143) }; arg_2136 = tmp201.Invoke_O__O(tmp202) }; var arg_2137 any; var or__1927000174__auto____24 any = A_arbace_go_check_A_const_220.Invoke_O__O(src__0)
				if jrt.J2g_Truth(or__1927000174__auto____24) { arg_2137 = or__1927000174__auto____24 } else { arg_2137 = A_arbace_go_check_A_const_22 }
//line :252:1
				var arg_2138 any = A_arbace_go_check_A_const_221; var arg_2139 any = lang.IFn_Cast(A_arbace_go_check_A_const_222.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_61, A_arbace_go_check_A_const_110.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O__O(say__20), lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O__O(have__22)); if linked_2134 == nil { ifn_2135.Invoke_O_O_O_O__O(arg_2136, arg_2137, arg_2138, arg_2139) } else { linked_2134.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_2133, arg_2136, arg_2137, arg_2138, arg_2139) }
//line :250:1
				init_result__24 = A_arbace_go_check_A_const_139 } } else {
//line :249:1
					init_result__24 = nil }
//line :161:1
		var generic_ids__25 any; var root_949 any = A_arbace_go_check_A_const_140.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_951 lang.IFn
































































































		if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any; var root_953 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any; var tmp203 any = A_arbace_go_check_check_package_fn__1685000219_A_New(); var tmp204 *jrt.Class; var fncls__966 *jrt.Class = A_arbace_go_check_check_package_fn__1685000219_A_fn_class; if fncls__966 == nil { var fncls__966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_fn__1685000219_A_fn_class = fncls__966d; tmp204 = fncls__966d } else { tmp204 = fncls__966 }; arg_956 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp203, tmp204, nil); var arg_957 any = decls__16; if linked_954 == nil { arg_952 = ifn_955.Invoke_O_O__O(arg_956, arg_957) } else { arg_952 = linked_954.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_953, arg_956, arg_957) }; if linked_950 == nil { generic_ids__25 = ifn_951.Invoke_O__O(arg_952) } else { generic_ids__25 = linked_950.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_949, arg_952) }
//line :161:1
		var errs__26 any; var root_967 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_969 lang.IFn







































































		if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = errors__9; if linked_968 == nil { errs__26 = ifn_969.Invoke_O__O(arg_970) } else { errs__26 = linked_968.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_967, arg_970) }
//line :161:1
		var counted__27 any; var root_971 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_973 lang.IFn


































































































		if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var tmp205 any = A_arbace_go_check_check_package_fn__1685000221_A_New_O(generic_ids__25); var tmp206 *jrt.Class; var fncls__981 *jrt.Class = A_arbace_go_check_check_package_fn__1685000221_A_fn_class; if fncls__981 == nil { var fncls__981d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_fn__1685000221_A_fn_class = fncls__981d; tmp206 = fncls__981d } else { tmp206 = fncls__981 }; arg_974 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp205, tmp206, nil); var arg_975 any = errs__26; if linked_972 == nil { counted__27 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { counted__27 = linked_972.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }
//line :161:1
		var forms__28 any; var m__28 any = jrt.IdentityHashMap_New(); var order__29 any = jrt.ArrayList_New(); var seq_1685000223__30 any; var root_2159 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2161 lang.IFn






































































































		if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = decls__16; if linked_2160 == nil { seq_1685000223__30 = ifn_2161.Invoke_O__O(arg_2162) } else { seq_1685000223__30 = linked_2160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2159, arg_2162) }
//line :161:1
		var chunk_1685000224__31 any; var count_1685000225__32 int64 = 0; var i_1685000226__33 int64 = 0; L17: for {






































































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000226__33, count_1685000225__32) { var d__34 any = lang.Indexed_Cast(chunk_1685000224__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000226__33)); var f__35 any; var tmp207 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp208 any; var root_2179 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2181 lang.IFn
				if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = d__34; if linked_2180 == nil { tmp208 = ifn_2181.Invoke_O__O(arg_2182) } else { tmp208 = linked_2180.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2179, arg_2182) }; f__35 = tmp207.Invoke_O__O(tmp208)
				if jrt.NN(jrt.IdentityHashMap_Cast(m__28)).ContainsKey_O__Z(f__35) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__29)).Add_O__Z(f__35)); jrt.NN(jrt.IdentityHashMap_Cast(m__28)).Put_O_O__O(f__35, lang.PersistentVector_EMPTY.Ref()) }
				var tmp209 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__28); var tmp210 any; var root_2183 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = jrt.NN(jrt.IdentityHashMap_Cast(m__28)).Get_O__O(f__35); var arg_2187 any = d__34; if linked_2184 == nil { tmp210 = ifn_2185.Invoke_O_O__O(arg_2186, arg_2187) } else { tmp210 = linked_2184.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2183, arg_2186, arg_2187) }; jrt.NN(tmp209).Put_O_O__O(f__35, tmp210)
//line :264:1
				seq_1685000223__30, chunk_1685000224__31, count_1685000225__32, i_1685000226__33 = seq_1685000223__30, chunk_1685000224__31, count_1685000225__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__33); continue L17 } else { var temp__1927000414__auto____34 any; var root_2163 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = seq_1685000223__30; if linked_2164 == nil { temp__1927000414__auto____34 = ifn_2165.Invoke_O__O(arg_2166) } else { temp__1927000414__auto____34 = linked_2164.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2163, arg_2166) }; if jrt.J2g_Truth(temp__1927000414__auto____34) { var seq_1685000223__35 any = temp__1927000414__auto____34; var tmp211 any; var root_2167 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = seq_1685000223__35; if linked_2168 == nil { tmp211 = ifn_2169.Invoke_O__O(arg_2170) } else { tmp211 = linked_2168.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2167, arg_2170) }; if jrt.J2g_Truth(tmp211) { var c__1927000678__auto____36 any; var root_2171 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any = seq_1685000223__35; if linked_2172 == nil { c__1927000678__auto____36 = ifn_2173.Invoke_O__O(arg_2174) } else { c__1927000678__auto____36 = linked_2172.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2171, arg_2174) }; var tmp212 any; var root_2188 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2190 lang.IFn; if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any = seq_1685000223__35; if linked_2189 == nil { tmp212 = ifn_2190.Invoke_O__O(arg_2191) } else { tmp212 = linked_2189.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2188, arg_2191) }; seq_1685000223__30, chunk_1685000224__31, count_1685000225__32, i_1685000226__33 = tmp212, c__1927000678__auto____36, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L17 } else { var d__36 any; var root_2175 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = seq_1685000223__35; if linked_2176 == nil { d__36 = ifn_2177.Invoke_O__O(arg_2178) } else { d__36 = linked_2176.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2175, arg_2178) }; var f__37 any; var tmp213 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp214 any; var root_2192 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2194 lang.IFn
					if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any = d__36; if linked_2193 == nil { tmp214 = ifn_2194.Invoke_O__O(arg_2195) } else { tmp214 = linked_2193.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2192, arg_2195) }; f__37 = tmp213.Invoke_O__O(tmp214)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__28)).ContainsKey_O__Z(f__37) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__29)).Add_O__Z(f__37)); jrt.NN(jrt.IdentityHashMap_Cast(m__28)).Put_O_O__O(f__37, lang.PersistentVector_EMPTY.Ref()) }
					var tmp215 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__28); var tmp216 any; var root_2196 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2198 lang.IFn; if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = jrt.NN(jrt.IdentityHashMap_Cast(m__28)).Get_O__O(f__37); var arg_2200 any = d__36; if linked_2197 == nil { tmp216 = ifn_2198.Invoke_O_O__O(arg_2199, arg_2200) } else { tmp216 = linked_2197.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2196, arg_2199, arg_2200) }; jrt.NN(tmp215).Put_O_O__O(f__37, tmp216)
//line :264:1
					var tmp217 any; var root_2201 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2203 lang.IFn; if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = seq_1685000223__35; if linked_2202 == nil { tmp217 = ifn_2203.Invoke_O__O(arg_2204) } else { tmp217 = linked_2202.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2201, arg_2204) }; seq_1685000223__30, chunk_1685000224__31, count_1685000225__32, i_1685000226__33 = tmp217, nil, 0, 0; continue L17 } } }
//line :161:1
			break L17
		}









































































































		var root_982 any = A_arbace_go_check_A_const_119.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any; var tmp218 any = A_arbace_go_check_check_package_fn__1685000227_A_New_O(m__28); var tmp219 *jrt.Class; var fncls__987 *jrt.Class = A_arbace_go_check_check_package_fn__1685000227_A_fn_class; if fncls__987 == nil { var fncls__987d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_check_check_package_fn__1685000227_A_fn_class = fncls__987d; tmp219 = fncls__987d } else { tmp219 = fncls__987 }; arg_985 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp218, tmp219, nil); var arg_986 any = order__29; if linked_983 == nil { forms__28 = ifn_984.Invoke_O_O__O(arg_985, arg_986) } else { forms__28 = linked_983.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_982, arg_985, arg_986) }
//line :161:1
		var stats__29 any; var root_988 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_990 lang.IFn











































































































		if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var tmp220 any = A_arbace_go_check_check_package_fn__1685000230_A_New(); var tmp221 *jrt.Class; var fncls__1268 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_A_fn_class
		if fncls__1268 == nil { var fncls__1268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_fn__1685000230_A_fn_class = fncls__1268d; tmp221 = fncls__1268d } else { tmp221 = fncls__1268 }; arg_991 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp220, tmp221, nil)
//line :269:1
		var arg_992 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_161, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_150, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_162, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_137, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_163, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_154, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_142, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_164, lang.PersistentVector_EMPTY.Ref())); var arg_993 any = forms__28; if linked_989 == nil { stats__29 = ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { stats__29 = linked_989.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993)
		}




























		if jrt.J2g_Truth(keep_trees__6) { } else { var seq_1685000271__30 any; var root_2205 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2207 lang.IFn
			if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any = decls__16; if linked_2206 == nil { seq_1685000271__30 = ifn_2207.Invoke_O__O(arg_2208) } else { seq_1685000271__30 = linked_2206.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2205, arg_2208) }
//line :299:1
			var chunk_1685000272__31 any; var count_1685000273__32 int64 = 0; var i_1685000274__33 int64 = 0; L18: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000274__33, count_1685000273__32) { var d__34_2 any = lang.Indexed_Cast(chunk_1685000272__31).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000274__33)); var tmp222 any; var and__1927000168__auto____35 bool; var tmp223 any = A_arbace_go_check_A_const_236; var tmp224 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp225 any; var root_2366 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2366, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2368 lang.IFn
					if linked_2367 == nil { ifn_2368 = lang.IFn_Cast(root_2366) } else { ifn_2368 = nil }; var arg_2369 any = d__34_2; if linked_2367 == nil { tmp225 = ifn_2368.Invoke_O__O(arg_2369) } else { tmp225 = linked_2367.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2366, arg_2369) }; and__1927000168__auto____35 = lang.Util_Equiv_O_O__Z_NoInit(tmp223, tmp224.Invoke_O__O(tmp225)); if and__1927000168__auto____35 { var or__1927000174__auto____36 any; var root_2370 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any; var root_2374 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any; var tmp226 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp227 any; var root_2379 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = d__34_2; if linked_2380 == nil { tmp227 = ifn_2381.Invoke_O__O(arg_2382) } else { tmp227 = linked_2380.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2379, arg_2382) }; arg_2377 = tmp226.Invoke_O__O(tmp227); var arg_2378 any = A_arbace_go_check_A_const_237; if linked_2375 == nil { arg_2373 = ifn_2376.Invoke_O_O__O(arg_2377, arg_2378) } else { arg_2373 = linked_2375.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2374, arg_2377, arg_2378) }; if linked_2371 == nil { or__1927000174__auto____36 = ifn_2372.Invoke_O__O(arg_2373) } else { or__1927000174__auto____36 = linked_2371.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2370, arg_2373) }; if jrt.J2g_Truth(or__1927000174__auto____36) { tmp222 = or__1927000174__auto____36 } else { var root_2383 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2385 lang.IFn; if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any; var root_2387 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any; var tmp228 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp229 any; var root_2392 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2392, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2394 lang.IFn; if linked_2393 == nil { ifn_2394 = lang.IFn_Cast(root_2392) } else { ifn_2394 = nil }; var arg_2395 any = d__34_2; if linked_2393 == nil { tmp229 = ifn_2394.Invoke_O__O(arg_2395) } else { tmp229 = linked_2393.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2392, arg_2395) }; arg_2390 = tmp228.Invoke_O__O(tmp229); var arg_2391 any = A_arbace_go_check_A_const_238; if linked_2388 == nil { arg_2386 = ifn_2389.Invoke_O_O__O(arg_2390, arg_2391) } else { arg_2386 = linked_2388.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2387, arg_2390, arg_2391) }; if linked_2384 == nil { tmp222 = ifn_2385.Invoke_O__O(arg_2386) } else { tmp222 = linked_2384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2383, arg_2386) } } } else { tmp222 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____35).Ref() }; if jrt.J2g_Truth(tmp222) {
						jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_239.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_240, A_arbace_go_check_A_const_241, A_arbace_go_check_A_const_242)) } else {
							jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_239.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_206, A_arbace_go_check_A_const_240, A_arbace_go_check_A_const_241, A_arbace_go_check_A_const_242)) }
//line :300:1
					seq_1685000271__30, chunk_1685000272__31, count_1685000273__32, i_1685000274__33 = seq_1685000271__30, chunk_1685000272__31, count_1685000273__32, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000274__33); continue L18 } else { var temp__1927000414__auto____34_2 any; var root_2209 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2211 lang.IFn; if linked_2210 == nil { ifn_2211 = lang.IFn_Cast(root_2209) } else { ifn_2211 = nil }; var arg_2212 any = seq_1685000271__30; if linked_2210 == nil { temp__1927000414__auto____34_2 = ifn_2211.Invoke_O__O(arg_2212) } else { temp__1927000414__auto____34_2 = linked_2210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2209, arg_2212) }; if jrt.J2g_Truth(temp__1927000414__auto____34_2) { var seq_1685000271__35 any = temp__1927000414__auto____34_2; var tmp230 any; var root_2213 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2213, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2215 lang.IFn; if linked_2214 == nil { ifn_2215 = lang.IFn_Cast(root_2213) } else { ifn_2215 = nil }; var arg_2216 any = seq_1685000271__35; if linked_2214 == nil { tmp230 = ifn_2215.Invoke_O__O(arg_2216) } else { tmp230 = linked_2214.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2213, arg_2216) }; if jrt.J2g_Truth(tmp230) { var c__1927000678__auto____36_2 any; var root_2217 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any = seq_1685000271__35; if linked_2218 == nil { c__1927000678__auto____36_2 = ifn_2219.Invoke_O__O(arg_2220) } else { c__1927000678__auto____36_2 = linked_2218.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2217, arg_2220) }; var tmp231 any; var root_2411 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = seq_1685000271__35; if linked_2412 == nil { tmp231 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp231 = linked_2412.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2411, arg_2414) }; seq_1685000271__30, chunk_1685000272__31, count_1685000273__32, i_1685000274__33 = tmp231, c__1927000678__auto____36_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____36_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L18 } else { var d__36_2 any; var root_2221 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = seq_1685000271__35; if linked_2222 == nil { d__36_2 = ifn_2223.Invoke_O__O(arg_2224) } else { d__36_2 = linked_2222.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2221, arg_2224) }
						var tmp232 any; var and__1927000168__auto____37 bool; var tmp233 any = A_arbace_go_check_A_const_236; var tmp234 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp235 any; var root_2415 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = d__36_2; if linked_2416 == nil { tmp235 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp235 = linked_2416.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2415, arg_2418) }; and__1927000168__auto____37 = lang.Util_Equiv_O_O__Z_NoInit(tmp233, tmp234.Invoke_O__O(tmp235)); if and__1927000168__auto____37 { var or__1927000174__auto____38 any; var root_2419 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any; var root_2423 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any; var tmp236 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp237 any; var root_2428 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2430 lang.IFn; if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any = d__36_2; if linked_2429 == nil { tmp237 = ifn_2430.Invoke_O__O(arg_2431) } else { tmp237 = linked_2429.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2428, arg_2431) }; arg_2426 = tmp236.Invoke_O__O(tmp237); var arg_2427 any = A_arbace_go_check_A_const_237; if linked_2424 == nil { arg_2422 = ifn_2425.Invoke_O_O__O(arg_2426, arg_2427) } else { arg_2422 = linked_2424.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2423, arg_2426, arg_2427) }; if linked_2420 == nil { or__1927000174__auto____38 = ifn_2421.Invoke_O__O(arg_2422) } else { or__1927000174__auto____38 = linked_2420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2419, arg_2422) }; if jrt.J2g_Truth(or__1927000174__auto____38) { tmp232 = or__1927000174__auto____38 } else { var root_2432 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any; var root_2436 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2438 lang.IFn; if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any; var tmp238 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp239 any; var root_2441 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = d__36_2; if linked_2442 == nil { tmp239 = ifn_2443.Invoke_O__O(arg_2444) } else { tmp239 = linked_2442.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2441, arg_2444) }; arg_2439 = tmp238.Invoke_O__O(tmp239); var arg_2440 any = A_arbace_go_check_A_const_238; if linked_2437 == nil { arg_2435 = ifn_2438.Invoke_O_O__O(arg_2439, arg_2440) } else { arg_2435 = linked_2437.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2436, arg_2439, arg_2440) }; if linked_2433 == nil { tmp232 = ifn_2434.Invoke_O__O(arg_2435) } else { tmp232 = linked_2433.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2432, arg_2435) } } } else { tmp232 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____37).Ref() }; if jrt.J2g_Truth(tmp232) {
							jrt.NN(lang.Volatile_Cast(d__36_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_239.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__36_2)).Deref__O(), A_arbace_go_check_A_const_240, A_arbace_go_check_A_const_241, A_arbace_go_check_A_const_242)) } else {
								jrt.NN(lang.Volatile_Cast(d__36_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_239.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__36_2)).Deref__O(), A_arbace_go_check_A_const_206, A_arbace_go_check_A_const_240, A_arbace_go_check_A_const_241, A_arbace_go_check_A_const_242)) }
//line :300:1
						var tmp240 any; var root_2460 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2462 lang.IFn; if linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = seq_1685000271__35; if linked_2461 == nil { tmp240 = ifn_2462.Invoke_O__O(arg_2463) } else { tmp240 = linked_2461.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2460, arg_2463) }; seq_1685000271__30, chunk_1685000272__31, count_1685000273__32, i_1685000274__33 = tmp240, nil, 0, 0; continue L18 } } }
//line :299:1
				break L18
			}
		}


		var tmp241 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp242 any; var root_2225 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2229 any = A_arbace_go_check_A_const_224; var arg_2230 any; var tmp243 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp244 any = A_arbace_go_check_A_const_110; var tmp245 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp246 any = A_arbace_go_check_A_const_225; var tmp247 any; var root_2253 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2255 lang.IFn


		if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any; var root_2257 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any; var root_2262 any = A_arbace_go_check_A_const_227.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = A_arbace_go_check_A_const_73; var arg_2266 any = A_arbace_go_check_A_const_78; if linked_2263 == nil { arg_2260 = ifn_2264.Invoke_O_O__O(arg_2265, arg_2266) } else { arg_2260 = linked_2263.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2262, arg_2265, arg_2266) }; var arg_2261 any = counted__27; if linked_2258 == nil { arg_2256 = ifn_2259.Invoke_O_O__O(arg_2260, arg_2261) } else { arg_2256 = linked_2258.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2257, arg_2260, arg_2261) }; if linked_2254 == nil { tmp247 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp247 = linked_2254.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2253, arg_2256) }
//line :305:1
		var tmp248 any = tmp247; var tmp249 any = A_arbace_go_check_A_const_228; var tmp250 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__26)), int64(lang.RT_Count_O__I_NoInit(counted__27)))).Ref(); var tmp251 any = A_arbace_go_check_A_const_229; var tmp252 any = A_arbace_go_check_A_const_230; var tmp253 any




		if jrt.J2g_Truth(keep_trees__6) { var root_2267 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2267, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2269 lang.IFn; if linked_2268 == nil { ifn_2269 = lang.IFn_Cast(root_2267) } else { ifn_2269 = nil }; var arg_2270 any; var root_2271 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any; var tmp254 any = A_arbace_go_check_check_package_fn__1685000275_A_New(); var tmp255 *jrt.Class; var fncls__2280 *jrt.Class = A_arbace_go_check_check_package_fn__1685000275_A_fn_class; if fncls__2280 == nil { var fncls__2280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_check_package_fn__1685000275_A_fn_class = fncls__2280d; tmp255 = fncls__2280d } else { tmp255 = fncls__2280 }; arg_2274 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp254, tmp255, nil); var arg_2275 any = decls__16; if linked_2272 == nil { arg_2270 = ifn_2273.Invoke_O_O__O(arg_2274, arg_2275) } else { arg_2270 = linked_2272.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2271, arg_2274, arg_2275) }; if linked_2268 == nil { tmp253 = ifn_2269.Invoke_O__O(arg_2270) } else { tmp253 = linked_2268.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2267, arg_2270) } } else { tmp253 = nil }
//line :305:1
		var tmp256 any = tmp253; var tmp257 any = A_arbace_go_check_A_const_231; var tmp258 any







		if jrt.J2g_Truth(keep_trees__6) {
			var root_2281 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any; var iter__1927001039__auto____30 any; var tmp259 any = A_arbace_go_check_check_package_iter__1685000277__1685000281_A_New(); var tmp260 *jrt.Class; var fncls__2361 *jrt.Class = A_arbace_go_check_check_package_iter__1685000277__1685000281_A_fn_class; if fncls__2361 == nil { var fncls__2361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_iter__1685000277__1685000281_A_fn_class = fncls__2361d; tmp260 = fncls__2361d } else { tmp260 = fncls__2361 }; iter__1927001039__auto____30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp259, tmp260, nil); arg_2284 = lang.IFn_Cast(iter__1927001039__auto____30).Invoke_O__O(decls__16); if linked_2282 == nil { tmp258 = ifn_2283.Invoke_O__O(arg_2284) } else { tmp258 = linked_2282.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2281, arg_2284) } } else {
//line :313:1
				tmp258 = nil }
//line :305:1
		var tmp261 any = tmp258; var tmp262 any = A_arbace_go_check_A_const_235; var tmp263 any











		if jrt.J2g_Truth(keep_trees__6) { tmp263 = order__17 } else { tmp263 = nil }
//line :305:1
		var tmp264 any = tmp263; var tmp265 any = A_arbace_go_check_A_const_71; var tmp266 any












		if jrt.J2g_Truth(keep_trees__6) { tmp266 = pkg_scope__7 } else { tmp266 = nil }
//line :305:1
		var tmp267 any = tmp266; var tmp268 any = A_arbace_go_check_A_const_117; var tmp269 any













		if jrt.J2g_Truth(keep_trees__6) { var root_2362 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2362, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2364 lang.IFn; if linked_2363 == nil { ifn_2364 = lang.IFn_Cast(root_2362) } else { ifn_2364 = nil }; var arg_2365 any = A_arbace_go_check_A_const_117.Invoke_O__O(ctx__11); if linked_2363 == nil { tmp269 = ifn_2364.Invoke_O__O(arg_2365) } else { tmp269 = linked_2363.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2362, arg_2365) } } else { tmp269 = nil }
//line :305:1
		arg_2230 = tmp243.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(stats__29, tmp244, tmp245, tmp246, tmp248, tmp249, tmp250, tmp251, init_result__24, tmp252, tmp256, tmp257, tmp261, tmp262, tmp264, tmp265, tmp267, tmp268, tmp269)
//line :304:1
		if linked_2226 == nil { tmp242 = ifn_2227.Invoke_O_O_O__O(arg_2228, arg_2229, arg_2230) } else { tmp242 = linked_2226.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2225, arg_2228, arg_2229, arg_2230) }; jrt.NN(tmp241).Reset_O__O(tmp242)
//line :161:1
		tmp64 = pkg__8 }; return nil }(); var root_1269 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1271 lang.IFn; if












	linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; if linked_1270 == nil { ifn_1271.Invoke__O() } else { linked_1270.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1269) }; if /*line :161:1*/ tmp270 != nil { panic(tmp270) }; return tmp64 }











func A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000129_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :173:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :173:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Invoke_O_O__O(self, p1__1685000111_SHARP___1 any) any { var root_808 any = A_arbace_go_check_A_const_120.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, A_arbace_go_check_file_info_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = t.F_pkg_scope; var arg_812 any = p1__1685000111_SHARP___1; var arg_813 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src); if linked_809 == nil { return ifn_810.Invoke_O_O_O__O(arg_811, arg_812, arg_813) } else { return linked_809.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_808, arg_811, arg_812, arg_813) } }










func A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000131_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :184:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :184:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1276 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = A_arbace_go_check_A_const_110.Invoke_O__O(t.F_src); if linked_1277 == nil { tmp1 = ifn_1278.Invoke_O__O(arg_1279) } else { tmp1 = linked_1277.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1276, arg_1279) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :184:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }





























func A_arbace_go_check_check_package_fn__1685000175_A_New() *A_arbace_go_check_check_package_fn__1685000175_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000175_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_check_check_package_fn__1685000175_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_check_check_package_fn__1685000175_A) Invoke_O_O__O(self, p1__1685000112_SHARP___1 any) any { var root_828 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = p1__1685000112_SHARP___1; var arg_832 any = A_arbace_go_check_A_const_124; if linked_829 == nil { return ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { return linked_829.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) } }





func A_arbace_go_check_check_package_fn__1685000182_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000182_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000182_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_go_check_check_package_fn__1685000182_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :220:1
func (t *A_arbace_go_check_check_package_fn__1685000182_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000183__5 any; var root_1847 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1849 lang.IFn
											if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1850 = t_; if linked_1848 == nil { seq_1685000183__5 = ifn_1849.Invoke_O__O(arg_1850) } else { seq_1685000183__5 = linked_1848.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1847, arg_1850) }
//line :220:1
	var chunk_1685000184__6 any; var count_1685000185__7 int64 = 0; var i_1685000186__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000186__8, count_1685000185__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000184__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000186__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, i_1685000186__8 = seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000186__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1851 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = seq_1685000183__5; if linked_1852 == nil { temp__1927000414__auto____9 = ifn_1853.Invoke_O__O(arg_1854) } else { temp__1927000414__auto____9 = linked_1852.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1851, arg_1854) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000183__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1855 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any = seq_1685000183__10; if linked_1856 == nil { tmp2 = ifn_1857.Invoke_O__O(arg_1858) } else { tmp2 = linked_1856.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1855, arg_1858) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1859 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1861 lang.IFn; if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any = seq_1685000183__10; if linked_1860 == nil { c__1927000678__auto____11 = ifn_1861.Invoke_O__O(arg_1862) } else { c__1927000678__auto____11 = linked_1860.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1859, arg_1862) }; var tmp3 any; var root_1870 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = seq_1685000183__10; if linked_1871 == nil { tmp3 = ifn_1872.Invoke_O__O(arg_1873) } else { tmp3 = linked_1871.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1870, arg_1873) }; seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, i_1685000186__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1863 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1865 lang.IFn; if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = seq_1685000183__10; if linked_1864 == nil { l__11 = ifn_1865.Invoke_O__O(arg_1866) } else { l__11 = linked_1864.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1863, arg_1866) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1874 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = seq_1685000183__10; if linked_1875 == nil { tmp4 = ifn_1876.Invoke_O__O(arg_1877) } else { tmp4 = linked_1875.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1874, arg_1877) }; seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, i_1685000186__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :220:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1878 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1880 lang.IFn

			if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = ex__5; if linked_1879 == nil { tmp6 = ifn_1880.Invoke_O__O(arg_1881) } else { tmp6 = linked_1879.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1878, arg_1881) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1882 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1885 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1886 any = A_arbace_go_check_A_const_142; var arg_1887 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_209; var tmp11 any; var root_1888 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = ex__5; if linked_1889 == nil { tmp11 = ifn_1890.Invoke_O__O(arg_1891) } else { tmp11 = linked_1889.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1888, arg_1891) }; arg_1887 = tmp10.Invoke_O__O(tmp11); if linked_1883 == nil { tmp8 = ifn_1884.Invoke_O_O_O__O(arg_1885, arg_1886, arg_1887) } else { tmp8 = linked_1883.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1882, arg_1885, arg_1886, arg_1887) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :220:1
				panic(tmp5) } } }; return nil }(); var root_1867 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; if linked_1868 == nil { ifn_1869.Invoke__O() } else { linked_1868.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1867) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :220:1
func A_arbace_go_check_check_package_fn__1685000189_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000189_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000189_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_go_check_check_package_fn__1685000189_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :220:1
func (t *A_arbace_go_check_check_package_fn__1685000189_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000190__5 any; var root_1937 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1939 lang.IFn
											if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1940 = t_; if linked_1938 == nil { seq_1685000190__5 = ifn_1939.Invoke_O__O(arg_1940) } else { seq_1685000190__5 = linked_1938.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1937, arg_1940) }
//line :220:1
	var chunk_1685000191__6 any; var count_1685000192__7 int64 = 0; var i_1685000193__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000193__8, count_1685000192__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000191__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000193__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, i_1685000193__8 = seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000193__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1941 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = seq_1685000190__5; if linked_1942 == nil { temp__1927000414__auto____9 = ifn_1943.Invoke_O__O(arg_1944) } else { temp__1927000414__auto____9 = linked_1942.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1941, arg_1944) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000190__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1945 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = seq_1685000190__10; if linked_1946 == nil { tmp2 = ifn_1947.Invoke_O__O(arg_1948) } else { tmp2 = linked_1946.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1945, arg_1948) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1949 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1951 lang.IFn; if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = seq_1685000190__10; if linked_1950 == nil { c__1927000678__auto____11 = ifn_1951.Invoke_O__O(arg_1952) } else { c__1927000678__auto____11 = linked_1950.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1949, arg_1952) }; var tmp3 any; var root_1960 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = seq_1685000190__10; if linked_1961 == nil { tmp3 = ifn_1962.Invoke_O__O(arg_1963) } else { tmp3 = linked_1961.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1960, arg_1963) }; seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, i_1685000193__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1953 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = seq_1685000190__10; if linked_1954 == nil { l__11 = ifn_1955.Invoke_O__O(arg_1956) } else { l__11 = linked_1954.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1953, arg_1956) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1964 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = seq_1685000190__10; if linked_1965 == nil { tmp4 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp4 = linked_1965.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1964, arg_1967) }; seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, i_1685000193__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :220:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1968 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1970 lang.IFn

			if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = ex__5; if linked_1969 == nil { tmp6 = ifn_1970.Invoke_O__O(arg_1971) } else { tmp6 = linked_1969.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1968, arg_1971) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1972 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1975 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1976 any = A_arbace_go_check_A_const_142; var arg_1977 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_209; var tmp11 any; var root_1978 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = ex__5; if linked_1979 == nil { tmp11 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp11 = linked_1979.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1978, arg_1981) }; arg_1977 = tmp10.Invoke_O__O(tmp11); if linked_1973 == nil { tmp8 = ifn_1974.Invoke_O_O_O__O(arg_1975, arg_1976, arg_1977) } else { tmp8 = linked_1973.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1972, arg_1975, arg_1976, arg_1977) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :220:1
				panic(tmp5) } } }; return nil }(); var root_1957 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; if linked_1958 == nil { ifn_1959.Invoke__O() } else { linked_1958.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1957) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000199_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000199_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000199_A{}; t.Ctor_O(p0); return t }
//line :226:1
func (t *A_arbace_go_check_check_package_fn__1685000199_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :226:1
func (t *A_arbace_go_check_check_package_fn__1685000199_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2013 any = A_arbace_go_check_A_const_215.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_206; var tmp3 any; var root_2017 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any; var t_ any = t.F_d; t.F_d = nil; arg_2020 = t_; if linked_2018 == nil { tmp3 = ifn_2019.Invoke_O__O(arg_2020) } else { tmp3 = linked_2018.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2017, arg_2020) }; arg_2016 = tmp2.Invoke_O__O(tmp3); if linked_2014 == nil { tmp1 = ifn_2015.Invoke_O__O(arg_2016) } else { tmp1 = linked_2014.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2013, arg_2016) } }
//line :226:1
	return nil }(); var root_2021 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; if linked_2022 == nil { ifn_2023.Invoke__O() } else { linked_2022.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2021) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :226:1
func A_arbace_go_check_check_package_fn__1685000201_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000201_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000201_A{}; t.Ctor_O(p0); return t }
//line :226:1
func (t *A_arbace_go_check_check_package_fn__1685000201_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :226:1
func (t *A_arbace_go_check_check_package_fn__1685000201_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2044 any = A_arbace_go_check_A_const_215.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_206; var tmp3 any; var root_2048 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any; var t_ any = t.F_d; t.F_d = nil; arg_2051 = t_; if linked_2049 == nil { tmp3 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp3 = linked_2049.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2048, arg_2051) }; arg_2047 = tmp2.Invoke_O__O(tmp3); if linked_2045 == nil { tmp1 = ifn_2046.Invoke_O__O(arg_2047) } else { tmp1 = linked_2045.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2044, arg_2047) } }
//line :226:1
	return nil }(); var root_2052 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; if linked_2053 == nil { ifn_2054.Invoke__O() } else { linked_2053.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2052) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }












func A_arbace_go_check_check_package_init_entry__1685000211_A_New() *A_arbace_go_check_check_package_init_entry__1685000211_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000211_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_go_check_check_package_init_entry__1685000211_A) Ctor() {}
//line :239:1
func (t *A_arbace_go_check_check_package_init_entry__1685000211_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A_New(); var tmp2 *jrt.Class; var fncls__889 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A_fn_class; if
													fncls__889 == nil { var fncls__889d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A_fn_class = fncls__889d; tmp2 = fncls__889d } else { tmp2 = fncls__889 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_901 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = lhs__1; if linked_902 == nil { tmp4 = ifn_903.Invoke_O__O(arg_904) } else { tmp4 = linked_902.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_901, arg_904) }; return tmp3.Invoke_O__O(tmp4) } else { var root_890 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = A_arbace_go_check_A_const_132.GetRawRoot__O(); var arg_894 any = A_arbace_go_check_A_const_133; var arg_895 any; var root_896 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = one__2; var arg_900 any = lhs__1; if linked_897 == nil { arg_895 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { arg_895 = linked_897.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }; if linked_891 == nil { return ifn_892.Invoke_O_O_O__O(arg_893, arg_894, arg_895) } else { return linked_891.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_890, arg_893, arg_894, arg_895) } } }
//line :240:1
func A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A_New() *A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A) Ctor() {}
//line :240:1
func (t *A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_865 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = v__1; var arg_869 any = A_arbace_go_check_A_const_70; if linked_866 == nil { tmp1 = ifn_867.Invoke_O_O__O(arg_868, arg_869) } else { tmp1 = linked_866.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_865, arg_868, arg_869) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_82, tmp1) { var tmp2 any; var root_879 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = v__1; var arg_883 any = A_arbace_go_check_A_const_73; if linked_880 == nil { tmp2 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { tmp2 = linked_880.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }; var tmp3 any = tmp2; var tmp4 any; var root_884 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = v__1; var arg_888 any = A_arbace_go_check_A_const_78; if linked_885 == nil { tmp4 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { tmp4 = linked_885.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_870 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var root_874 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = v__1; var arg_878 any = A_arbace_go_check_A_const_70; if linked_875 == nil { arg_873 = ifn_876.Invoke_O_O__O(arg_877, arg_878) } else { arg_873 = linked_875.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_874, arg_877, arg_878) }; if linked_871 == nil { return ifn_872.Invoke_O__O(arg_873) } else { return linked_871.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_870, arg_873) } } }



func A_arbace_go_check_check_package_norm__1685000215_A_New() *A_arbace_go_check_check_package_norm__1685000215_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000215_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_check_check_package_norm__1685000215_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_check_check_package_norm__1685000215_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_911 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_913 lang.IFn; if
												linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = x__1; if linked_912 == nil { tmp1 = ifn_913.Invoke_O__O(arg_914) } else { tmp1 = linked_912.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_911, arg_914) }; if /*line :244:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_915 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_917 lang.IFn

		if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = x__1; if linked_916 == nil { tmp2 = ifn_917.Invoke_O__O(arg_918) } else { tmp2 = linked_916.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_915, arg_918) }
//line :244:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_85, tmp2) {


			var root_919 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = A_arbace_go_check_A_const_132.GetRawRoot__O(); var arg_923 any = A_arbace_go_check_A_const_134; var arg_924 any; var root_925 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A_New(); var tmp4 *jrt.Class; var fncls__934 *jrt.Class = A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A_fn_class; if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A_fn_class = fncls__934d; tmp4 = fncls__934d } else { tmp4 = fncls__934 }; arg_928 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_929 any; var root_935 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = x__1; if linked_936 == nil { arg_929 = ifn_937.Invoke_O__O(arg_938) } else { arg_929 = linked_936.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_935, arg_938) }; if linked_926 == nil { arg_924 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { arg_924 = linked_926.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }; if linked_920 == nil { return ifn_921.Invoke_O_O_O__O(arg_922, arg_923, arg_924) } else { return linked_920.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_919, arg_922, arg_923, arg_924) } } else {
//line :244:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A_New() *A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A) Ctor() {}
//line :247:1
func (t *A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A) Invoke_O_O__O(self, p1__1685000113_SHARP___1 any) any { var tmp1 any; var root_930 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = p1__1685000113_SHARP___1; if linked_931 == nil { tmp1 = ifn_932.Invoke_O__O(arg_933) } else { tmp1 = linked_931.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_930, arg_933) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000113_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000219_A_New() *A_arbace_go_check_check_package_fn__1685000219_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000219_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_fn__1685000219_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_check_package_fn__1685000219_A) Invoke_O_O__O(self, p1__1685000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_142; var tmp2 any; var root_958 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = p1__1685000114_SHARP___1; if linked_959 == nil { tmp2 = ifn_960.Invoke_O__O(arg_961) } else { tmp2 = linked_959.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_958, arg_961) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_143; var tmp4 any; var root_962 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = p1__1685000114_SHARP___1; if linked_963 == nil { tmp4 = ifn_964.Invoke_O__O(arg_965) } else { tmp4 = linked_963.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_962, arg_965) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000221_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000221_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000221_A{}; t.Ctor_O(p0); return t }
//line :260:1
func (t *A_arbace_go_check_check_package_fn__1685000221_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :260:1
func (t *A_arbace_go_check_check_package_fn__1685000221_A) Invoke_O_O__O(self, p1__1685000115_SHARP___1 any) any { var root_976 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = t.F_generic_ids; var arg_980 any = A_arbace_go_check_A_const_124.Invoke_O__O(p1__1685000115_SHARP___1); if linked_977 == nil { return ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { return linked_977.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_976, arg_979, arg_980) } }







func A_arbace_go_check_check_package_fn__1685000227_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000227_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000227_A{}; t.Ctor_O(p0); return t }
//line :268:1
func (t *A_arbace_go_check_check_package_fn__1685000227_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :268:1
func (t *A_arbace_go_check_check_package_fn__1685000227_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000230_A_New() *A_arbace_go_check_check_package_fn__1685000230_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_go_check_check_package_fn__1685000230_A) Ctor() {}
//line :270:1
func (t *A_arbace_go_check_check_package_fn__1685000230_A) Invoke_O_O_O__O(self, acc__1, p__1685000229__2 any) any { var vec__1685000231__3 any = p__1685000229__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000231__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000231__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_994 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_996 lang.IFn; if
															linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A_New(); var tmp2 *jrt.Class; var fncls__1003 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A_fn_class; if fncls__1003 == nil { var fncls__1003d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A_fn_class = fncls__1003d; tmp2 = fncls__1003d } else { tmp2 = fncls__1003 }; arg_997 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_998 any = ds__5; if linked_995 == nil { gen__6 = ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { gen__6 = linked_995.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_994, arg_997, arg_998) }; var uses_generics__7 any; var root_1004 any = /*line :270:1*/A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1006 lang.IFn; if

	linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A_New(); var tmp4 *jrt.Class; var fncls__1013 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A_fn_class; if fncls__1013 == nil { var fncls__1013d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A_fn_class = fncls__1013d; tmp4 = fncls__1013d } else { tmp4 = fncls__1013 }; arg_1007 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1008 any = ds__5; if linked_1005 == nil { uses_generics__7 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { uses_generics__7 = linked_1005.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }; var present__8 any; var root_1014 any = /*line :270:1*/A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, A_arbace_go_check_annotations_present_A_fn_class); var ifn_1016 lang.IFn; if


	linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = form__4; if linked_1015 == nil { present__8 = ifn_1016.Invoke_O__O(arg_1017) } else { present__8 = linked_1015.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_1014, arg_1017) }; var verified__9 any; var root_1018 any = /*line :270:1*/A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1020 lang.IFn; if



	linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var arg_1022 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1023 any; var root_1024 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A_New(); var tmp6 *jrt.Class; var fncls__1033 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A_fn_class; if fncls__1033 == nil { var fncls__1033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A_fn_class = fncls__1033d; tmp6 = fncls__1033d } else { tmp6 = fncls__1033 }; arg_1027 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1028 any = ds__5; if linked_1025 == nil { arg_1023 = ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { arg_1023 = linked_1025.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) }; if linked_1019 == nil { verified__9 = ifn_1020.Invoke_O_O_O__O(arg_1021, arg_1022, arg_1023) } else { verified__9 = linked_1019.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1018, arg_1021, arg_1022, arg_1023) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_1034 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any; var root_1041 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = acc__1; var arg_1045 any = A_arbace_go_check_A_const_150; var arg_1046 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); if linked_1042 == nil { arg_1037 = ifn_1043.Invoke_O_O_O__O(arg_1044, arg_1045, arg_1046) } else { arg_1037 = linked_1042.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1041, arg_1044, arg_1045, arg_1046) }; var arg_1038 any = A_arbace_go_check_A_const_152; var arg_1039 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1040 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1035 == nil { acc__10 = ifn_1036.Invoke_O_O_O_O__O(arg_1037, arg_1038, arg_1039, arg_1040) } else { acc__10 = linked_1035.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1034, arg_1037, arg_1038, arg_1039, arg_1040) } } else {
//line :275:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_1047 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any; var root_1053 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1055 lang.IFn
//line :281:1
		if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any; var root_1059 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1061 lang.IFn
//line :280:1
		if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = acc__10; var arg_1063 any = A_arbace_go_check_A_const_153; var arg_1064 any; var root_1065 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var arg_1069 any = A_arbace_go_check_A_const_22; if linked_1066 == nil { arg_1064 = ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { arg_1064 = linked_1066.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) }; if linked_1060 == nil { arg_1056 = ifn_1061.Invoke_O_O_O__O(arg_1062, arg_1063, arg_1064) } else { arg_1056 = linked_1060.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1059, arg_1062, arg_1063, arg_1064) }
		var arg_1057 any = A_arbace_go_check_A_const_154; var arg_1058 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A_New_O(present__8); var tmp8 *jrt.Class; var fncls__1076 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A_fn_class; if fncls__1076 == nil { var fncls__1076d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A_fn_class = fncls__1076d; tmp8 = fncls__1076d } else { tmp8 = fncls__1076 }; arg_1058 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_1054 == nil { arg_1050 = ifn_1055.Invoke_O_O_O__O(arg_1056, arg_1057, arg_1058) } else { arg_1050 = linked_1054.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1053, arg_1056, arg_1057, arg_1058) }
		var arg_1051 any = A_arbace_go_check_A_const_142; var arg_1052 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A_New_O(ds__5); var tmp10 *jrt.Class; var fncls__1099 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A_fn_class; if fncls__1099 == nil { var fncls__1099d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A_fn_class = fncls__1099d; tmp10 = fncls__1099d } else { tmp10 = fncls__1099 }; arg_1052 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1048 == nil { return ifn_1049.Invoke_O_O_O__O(arg_1050, arg_1051, arg_1052) } else { return linked_1048.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1047, arg_1050, arg_1051, arg_1052) } } else {
//line :278:1
			var unver__11 any; var root_1100 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1102 lang.IFn




			if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1104 any; var iter__1927001039__auto____11 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A_New_O(verified__9); var tmp12 *jrt.Class; var fncls__1187 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A_fn_class; if fncls__1187 == nil { var fncls__1187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A_fn_class = fncls__1187d; tmp12 = fncls__1187d } else { tmp12 = fncls__1187 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1104 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1101 == nil { unver__11 = ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { unver__11 = linked_1101.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104)
			}








			var root_1188 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any; var root_1194 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1196 lang.IFn
//line :292:1
			if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var root_1200 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1202 lang.IFn
//line :291:1
			if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any; var root_1206 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1208 lang.IFn
//line :290:1
			if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any; var root_1212 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1214 lang.IFn
//line :289:1
			if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any; var root_1219 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1221 lang.IFn
//line :288:1
			if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = acc__10; var arg_1223 any = A_arbace_go_check_A_const_161; var arg_1224 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); if linked_1220 == nil { arg_1215 = ifn_1221.Invoke_O_O_O__O(arg_1222, arg_1223, arg_1224) } else { arg_1215 = linked_1220.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1219, arg_1222, arg_1223, arg_1224) }
			var arg_1216 any = A_arbace_go_check_A_const_82; var arg_1217 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1218 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1213 == nil { arg_1209 = ifn_1214.Invoke_O_O_O_O__O(arg_1215, arg_1216, arg_1217, arg_1218) } else { arg_1209 = linked_1213.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1212, arg_1215, arg_1216, arg_1217, arg_1218) }
			var arg_1210 any = A_arbace_go_check_A_const_162; var arg_1211 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A_New_O(present__8); var tmp14 *jrt.Class; var fncls__1231 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A_fn_class; if fncls__1231 == nil { var fncls__1231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A_fn_class = fncls__1231d; tmp14 = fncls__1231d } else { tmp14 = fncls__1231 }; arg_1211 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1207 == nil { arg_1203 = ifn_1208.Invoke_O_O_O__O(arg_1209, arg_1210, arg_1211) } else { arg_1203 = linked_1207.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1206, arg_1209, arg_1210, arg_1211) }
			var arg_1204 any = A_arbace_go_check_A_const_137; var arg_1205 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A_New_O(verified__9); var tmp16 *jrt.Class; var fncls__1238 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A_fn_class; if fncls__1238 == nil { var fncls__1238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A_fn_class = fncls__1238d; tmp16 = fncls__1238d } else { tmp16 = fncls__1238 }; arg_1205 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1201 == nil { arg_1197 = ifn_1202.Invoke_O_O_O__O(arg_1203, arg_1204, arg_1205) } else { arg_1197 = linked_1201.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1200, arg_1203, arg_1204, arg_1205) }
			var arg_1198 any = A_arbace_go_check_A_const_163; var arg_1199 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A_New_O(unver__11); var tmp18 *jrt.Class; var fncls__1245 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A_fn_class; if fncls__1245 == nil { var fncls__1245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A_fn_class = fncls__1245d; tmp18 = fncls__1245d } else { tmp18 = fncls__1245 }; arg_1199 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1195 == nil { arg_1191 = ifn_1196.Invoke_O_O_O__O(arg_1197, arg_1198, arg_1199) } else { arg_1191 = linked_1195.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1194, arg_1197, arg_1198, arg_1199) }
			var arg_1192 any = A_arbace_go_check_A_const_164; var arg_1193 any; var tmp19 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A_New_O_O_O(form__4, ds__5, unver__11); var tmp20 *jrt.Class; var fncls__1267 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A_fn_class; if fncls__1267 == nil { var fncls__1267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A_fn_class = fncls__1267d; tmp20 = fncls__1267d } else { tmp20 = fncls__1267 }; arg_1193 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); if linked_1189 == nil { return ifn_1190.Invoke_O_O_O__O(arg_1191, arg_1192, arg_1193) } else { return linked_1189.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1188, arg_1191, arg_1192, arg_1193) } } }
//line :271:1
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A_New() *A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A) Ctor() {}
//line :271:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A) Invoke_O_O__O(self, p1__1685000116_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_142; var tmp2 any; var root_999 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = p1__1685000116_SHARP___1; if linked_1000 == nil { tmp2 = ifn_1001.Invoke_O__O(arg_1002) } else { tmp2 = linked_1000.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_999, arg_1002) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A_New() *A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A) Ctor() {}
//line :272:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A) Invoke_O_O__O(self, p1__1685000117_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_147; var tmp2 any; var root_1009 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = p1__1685000117_SHARP___1; if linked_1010 == nil { tmp2 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp2 = linked_1010.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1009, arg_1012) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A_New() *A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A) Invoke_O_O__O(self, p1__1685000118_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_137; var tmp2 any; var root_1029 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = p1__1685000118_SHARP___1; if linked_1030 == nil { tmp2 = ifn_1031.Invoke_O__O(arg_1032) } else { tmp2 = linked_1030.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1029, arg_1032) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A{}; t.Ctor_O(p0); return t }
//line :281:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :281:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A) Invoke_O_O__O(self, p1__1685000119_SHARP___1 any) any { var root_1070 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1074 any = p1__1685000119_SHARP___1; var arg_1075 any = t.F_present; if linked_1071 == nil { return ifn_1072.Invoke_O_O_O__O(arg_1073, arg_1074, arg_1075) } else { return linked_1071.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1070, arg_1073, arg_1074, arg_1075) } }
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A{}; t.Ctor_O(p0); return t }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A) Invoke_O_O__O(self, p1__1685000120_SHARP___1 any) any { var root_1077 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A_New(); var tmp2 *jrt.Class; var fncls__1098 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A_fn_class; if fncls__1098 == nil { var fncls__1098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A_fn_class = fncls__1098d; tmp2 = fncls__1098d } else { tmp2 = fncls__1098 }; arg_1080 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1081 any = p1__1685000120_SHARP___1; var arg_1082 any = t.F_ds; if linked_1078 == nil { return ifn_1079.Invoke_O_O_O__O(arg_1080, arg_1081, arg_1082) } else { return linked_1078.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1077, arg_1080, arg_1081, arg_1082) } }
//line :282:1
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A_New() *A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A) Ctor() {}
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_142; var tmp2 any; var root_1083 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = d__2; if linked_1084 == nil { tmp2 = ifn_1085.Invoke_O__O(arg_1086) } else { tmp2 = linked_1084.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1083, arg_1086) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_1087 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = m__1; var arg_1091 any = u__4; var arg_1092 any; var root_1093 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var arg_1097 any = A_arbace_go_check_A_const_22; if linked_1094 == nil { arg_1092 = ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { arg_1092 = linked_1094.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) }; if linked_1088 == nil { return ifn_1089.Invoke_O_O_O__O(arg_1090, arg_1091, arg_1092) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1087, arg_1090, arg_1091, arg_1092) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A{}; t.Ctor_O(p0); return t }
//line :283:1
func (t *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :283:1
func (t *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A) Invoke_O_O__O(self, s__1685000247__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A_New_O_O_O(s__1685000247__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1186 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A_fn_class; if fncls__1186 == nil { var fncls__1186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A_fn_class = fncls__1186d; tmp2 = fncls__1186d } else { tmp2 = fncls__1186 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :283:1
func A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :283:1
func (t *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A) Ctor_O_O_O(c__s__1685000247, c__iter__1685000246, c__verified any) { t.F_s__1685000247 = c__s__1685000247; t.F_iter__1685000246 = c__iter__1685000246; t.F_verified = c__verified }
//line :283:1
func (t *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A) Invoke_O__O(self any) any { { var s__1685000247__1 any; var t_ any = t.F_s__1685000247; t.F_s__1685000247 = nil; s__1685000247__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1105 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = s__1685000247__1; if linked_1106 == nil { temp__1927000414__auto____2 = ifn_1107.Invoke_O__O(arg_1108) } else { temp__1927000414__auto____2 = linked_1106.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1105, arg_1108) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000247__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1109 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = s__1685000247__3; if linked_1110 == nil { tmp1 = ifn_1111.Invoke_O__O(arg_1112) } else { tmp1 = linked_1110.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1109, arg_1112) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1113 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = s__1685000247__3; if linked_1114 == nil { c__1927001037__auto____4 = ifn_1115.Invoke_O__O(arg_1116) } else { c__1927001037__auto____4 = linked_1114.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1113, arg_1116) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000249__6 any; var root_1117 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1118 == nil { b__1685000249__6 = ifn_1119.Invoke_O__O(arg_1120) } else { b__1685000249__6 = linked_1118.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1117, arg_1120) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A_New_O_I_O_O(b__1685000249__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1136 *jrt.Class = A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A_fn_class; if fncls__1136 == nil { var fncls__1136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A_fn_class = fncls__1136d; tmp3 = fncls__1136d } else { tmp3 = fncls__1136 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1137 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any; var root_1142 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = b__1685000249__6; if linked_1143 == nil { arg_1140 = ifn_1144.Invoke_O__O(arg_1145) } else { arg_1140 = linked_1143.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1142, arg_1145) }; var arg_1141 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000246); var tmp5 any; var root_1146 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = s__1685000247__3; if linked_1147 == nil { tmp5 = ifn_1148.Invoke_O__O(arg_1149) } else { tmp5 = linked_1147.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1146, arg_1149) }; arg_1141 = tmp4.Invoke_O__O(tmp5); if linked_1138 == nil { return ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { return linked_1138.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) } } else { var root_1150 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var root_1155 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = b__1685000249__6; if linked_1156 == nil { arg_1153 = ifn_1157.Invoke_O__O(arg_1158) } else { arg_1153 = linked_1156.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1155, arg_1158) }; var arg_1154 any; if linked_1151 == nil { return ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { return linked_1151.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) } } } else { var vec__1685000257__4 any; var root_1159 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = s__1685000247__3; if linked_1160 == nil { vec__1685000257__4 = ifn_1161.Invoke_O__O(arg_1162) } else { vec__1685000257__4 = linked_1160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1159, arg_1162) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000257__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000257__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1163 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1165 lang.IFn

	if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = n__6; var arg_1167 any = v__7; if linked_1164 == nil { tmp6 = ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { tmp6 = linked_1164.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) }
//line :283:1
	if jrt.J2g_Truth(tmp6) { var root_1168 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any; var tmp7 jrt.Number_I; var na_1173 any = n__6; var na_1174 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1173); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1174) }; tmp8 = tmp9; if tmp8 { var n0_1175 int64 = jrt.NN(jrt.Long_Cast(na_1173)).LongValue__J(); var n1_1176 int64 = jrt.NN(jrt.Long_Cast(na_1174)).LongValue__J(); var nr_1177 int64 = n0_1175 - n1_1176; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1176 == -9223372036854775808); if tmp11 { tmp11 = (n0_1175^n1_1176)&(n0_1175^nr_1177) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1177)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1173, na_1174) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1173); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1174) }; tmp12 = tmp13; if tmp12 { var n0_1175_2 float64 = jrt.NN(jrt.Double_Cast(na_1173)).DoubleValue__D(); var n1_1176_2 float64 = jrt.NN(jrt.Double_Cast(na_1174)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1175_2 + -n1_1176_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1173, na_1174) } }
//line :283:1
		arg_1171 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1172 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000246); var tmp15 any; var root_1178 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = s__1685000247__3; if linked_1179 == nil { tmp15 = ifn_1180.Invoke_O__O(arg_1181) } else { tmp15 = linked_1179.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1178, arg_1181) }; arg_1172 = tmp14.Invoke_O__O(tmp15); if linked_1169 == nil { return ifn_1170.Invoke_O_O__O(arg_1171, arg_1172) } else { return linked_1169.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1168, arg_1171, arg_1172) } } else { var tmp16 any; var root_1182 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = s__1685000247__3; if linked_1183 == nil { tmp16 = ifn_1184.Invoke_O__O(arg_1185) } else { tmp16 = linked_1183.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1182, arg_1185) }; s__1685000247__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :283:1
func A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :283:1
func (t *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A) Ctor_O_I_O_O(c__b__1685000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1685000249 = c__b__1685000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :283:1
func (t *A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A) Invoke_O__O(self any) any { { var i__1685000248__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000253__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000248__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000253__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000253__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1121 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1123 lang.IFn

	if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = n__4; var arg_1125 any = v__5; if linked_1122 == nil { tmp2 = ifn_1123.Invoke_O_O__O(arg_1124, arg_1125) } else { tmp2 = linked_1122.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1121, arg_1124, arg_1125) }
//line :283:1
	if jrt.J2g_Truth(tmp2) { var root_1126 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = t.F_b__1685000249; var arg_1130 any; var tmp3 jrt.Number_I; var na_1131 any = n__4; var na_1132 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1131); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1132) }; tmp4 = tmp5; if tmp4 { var n0_1133 int64 = jrt.NN(jrt.Long_Cast(na_1131)).LongValue__J(); var n1_1134 int64 = jrt.NN(jrt.Long_Cast(na_1132)).LongValue__J(); var nr_1135 int64 = n0_1133 - n1_1134; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1134 == -9223372036854775808); if tmp7 { tmp7 = (n0_1133^n1_1134)&(n0_1133^nr_1135) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1135)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1131, na_1132) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1131); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1132) }; tmp8 = tmp9; if tmp8 { var n0_1133_2 float64 = jrt.NN(jrt.Double_Cast(na_1131)).DoubleValue__D(); var n1_1134_2 float64 = jrt.NN(jrt.Double_Cast(na_1132)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1133_2 + -n1_1134_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1131, na_1132) } }
//line :283:1
		arg_1130 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1127 == nil { ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { linked_1127.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) }; i__1685000248__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000248__1); continue L1 } else { i__1685000248__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000248__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A{}; t.Ctor_O(p0); return t }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A) Invoke_O_O__O(self, p1__1685000121_SHARP___1 any) any { var root_1225 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1229 any = p1__1685000121_SHARP___1; var arg_1230 any = t.F_present; if linked_1226 == nil { return ifn_1227.Invoke_O_O_O__O(arg_1228, arg_1229, arg_1230) } else { return linked_1226.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1225, arg_1228, arg_1229, arg_1230) } }
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A{}; t.Ctor_O(p0); return t }
//line :291:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :291:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A) Invoke_O_O__O(self, p1__1685000122_SHARP___1 any) any { var root_1232 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1236 any = p1__1685000122_SHARP___1; var arg_1237 any = t.F_verified; if linked_1233 == nil { return ifn_1234.Invoke_O_O_O__O(arg_1235, arg_1236, arg_1237) } else { return linked_1233.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1232, arg_1235, arg_1236, arg_1237) } }
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A{}; t.Ctor_O(p0); return t }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A) Invoke_O_O__O(self, p1__1685000123_SHARP___1 any) any { var root_1239 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1243 any = p1__1685000123_SHARP___1; var arg_1244 any = t.F_unver; if linked_1240 == nil { return ifn_1241.Invoke_O_O_O__O(arg_1242, arg_1243, arg_1244) } else { return linked_1240.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1239, arg_1242, arg_1243, arg_1244) } }
func A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :293:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :293:1
func (t *A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A) Invoke_O_O__O(self, p1__1685000124_SHARP___1 any) any { var tmp1 any; var root_1246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = t.F_unver; if linked_1247 == nil { tmp1 = ifn_1248.Invoke_O__O(arg_1249) } else { tmp1 = linked_1247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1246, arg_1249) }; if jrt.J2g_Truth(tmp1) { var root_1250 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = p1__1685000124_SHARP___1; var arg_1254 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp4 any; var root_1255 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any; var root_1259 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = t.F_ds; if linked_1260 == nil { arg_1258 = ifn_1261.Invoke_O__O(arg_1262) } else { arg_1258 = linked_1260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1259, arg_1262) }; if linked_1256 == nil { tmp4 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp4 = linked_1256.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1255, arg_1258) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1263 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = t.F_form; if linked_1264 == nil { tmp6 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp6 = linked_1264.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1263, arg_1266) }; arg_1254 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1251 == nil { return ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { return linked_1251.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) } } else { return p1__1685000124_SHARP___1 } }
















func A_arbace_go_check_check_package_fn__1685000275_A_New() *A_arbace_go_check_check_package_fn__1685000275_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000275_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000275_A) Ctor() {}
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000275_A) Invoke_O_O__O(self, p1__1685000125_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_206; var tmp2 any; var root_2276 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = p1__1685000125_SHARP___1; if linked_2277 == nil { tmp2 = ifn_2278.Invoke_O__O(arg_2279) } else { tmp2 = linked_2277.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2276, arg_2279) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000277__1685000281_A_New() *A_arbace_go_check_check_package_iter__1685000277__1685000281_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000277__1685000281_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_go_check_check_package_iter__1685000277__1685000281_A) Ctor() {}
//line :314:1
func (t *A_arbace_go_check_check_package_iter__1685000277__1685000281_A) Invoke_O_O__O(self, s__1685000278__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A_New_O_O(s__1685000278__1, self); var tmp2 *jrt.Class; var fncls__2360 *jrt.Class = A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A_fn_class; if fncls__2360 == nil { var fncls__2360d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A_fn_class = fncls__2360d; tmp2 = fncls__2360d } else { tmp2 = fncls__2360 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :314:1
func A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A{}; t.Ctor_O_O(p0, p1); return t }
//line :314:1
func (t *A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A) Ctor_O_O(c__s__1685000278, c__iter__1685000277 any) { t.F_s__1685000278 = c__s__1685000278; t.F_iter__1685000277 = c__iter__1685000277 }
//line :314:1
func (t *A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A) Invoke_O__O(self any) any { { var s__1685000278__1 any; var t_ any = t.F_s__1685000278; t.F_s__1685000278 = nil; s__1685000278__1 = t_; for { var temp__1927000414__auto____2 any; var root_2285 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = s__1685000278__1; if linked_2286 == nil { temp__1927000414__auto____2 = ifn_2287.Invoke_O__O(arg_2288) } else { temp__1927000414__auto____2 = linked_2286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2285, arg_2288) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000278__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2289 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = s__1685000278__3; if linked_2290 == nil { tmp1 = ifn_2291.Invoke_O__O(arg_2292) } else { tmp1 = linked_2290.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2289, arg_2292) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2293 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = s__1685000278__3; if linked_2294 == nil { c__1927001037__auto____4 = ifn_2295.Invoke_O__O(arg_2296) } else { c__1927001037__auto____4 = linked_2294.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2293, arg_2296) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000280__6 any; var root_2297 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2298 == nil { b__1685000280__6 = ifn_2299.Invoke_O__O(arg_2300) } else { b__1685000280__6 = linked_2298.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2297, arg_2300) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A_New_O_I_O(b__1685000280__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2315 *jrt.Class = A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A_fn_class; if fncls__2315 == nil { var fncls__2315d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A_fn_class = fncls__2315d; tmp3 = fncls__2315d } else { tmp3 = fncls__2315 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2316 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any; var root_2321 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = b__1685000280__6; if linked_2322 == nil { arg_2319 = ifn_2323.Invoke_O__O(arg_2324) } else { arg_2319 = linked_2322.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2321, arg_2324) }; var arg_2320 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000277); var tmp5 any; var root_2325 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = s__1685000278__3; if linked_2326 == nil { tmp5 = ifn_2327.Invoke_O__O(arg_2328) } else { tmp5 = linked_2326.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2325, arg_2328) }; arg_2320 = tmp4.Invoke_O__O(tmp5); if linked_2317 == nil { return ifn_2318.Invoke_O_O__O(arg_2319, arg_2320) } else { return linked_2317.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2316, arg_2319, arg_2320) } } else { var root_2329 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any; var root_2334 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = b__1685000280__6; if linked_2335 == nil { arg_2332 = ifn_2336.Invoke_O__O(arg_2337) } else { arg_2332 = linked_2335.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2334, arg_2337) }; var arg_2333 any; if linked_2330 == nil { return ifn_2331.Invoke_O_O__O(arg_2332, arg_2333) } else { return linked_2330.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2329, arg_2332, arg_2333) } } } else { var d__4 any; var root_2338 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = s__1685000278__3; if linked_2339 == nil { d__4 = ifn_2340.Invoke_O__O(arg_2341) } else { d__4 = linked_2339.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2338, arg_2341) }; var root_2342 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2342, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2344 lang.IFn; if linked_2343 == nil { ifn_2344 = lang.IFn_Cast(root_2342) } else { ifn_2344 = nil }; var arg_2345 any; var root_2347 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2349 lang.IFn
															if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any; var root_2352 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = d__4; if linked_2353 == nil { arg_2350 = ifn_2354.Invoke_O__O(arg_2355) } else { arg_2350 = linked_2353.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2352, arg_2355) }; var arg_2351 any = A_arbace_go_check_A_const_234; if linked_2348 == nil { arg_2345 = ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { arg_2345 = linked_2348.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }
//line :314:1
	var arg_2346 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000277); var tmp7 any; var root_2356 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = s__1685000278__3; if linked_2357 == nil { tmp7 = ifn_2358.Invoke_O__O(arg_2359) } else { tmp7 = linked_2357.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2356, arg_2359) }; arg_2346 = tmp6.Invoke_O__O(tmp7); if linked_2343 == nil { return ifn_2344.Invoke_O_O__O(arg_2345, arg_2346) } else { return linked_2343.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2342, arg_2345, arg_2346) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :314:1
func A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :314:1
func (t *A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A) Ctor_O_I_O(c__b__1685000280 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000280 = c__b__1685000280; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :314:1
func (t *A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A) Invoke_O__O(self any) any { { var i__1685000279__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000279__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000279__1)); var root_2301 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = t.F_b__1685000280; var arg_2305 any; var root_2306 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2308 lang.IFn
																	if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any; var root_2311 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2313 lang.IFn; if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = d__2; if linked_2312 == nil { arg_2309 = ifn_2313.Invoke_O__O(arg_2314) } else { arg_2309 = linked_2312.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2311, arg_2314) }; var arg_2310 any = A_arbace_go_check_A_const_233; if linked_2307 == nil { arg_2305 = ifn_2308.Invoke_O_O__O(arg_2309, arg_2310) } else { arg_2305 = linked_2307.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2306, arg_2309, arg_2310) }
//line :314:1
	if linked_2302 == nil { ifn_2303.Invoke_O_O__O(arg_2304, arg_2305) } else { linked_2302.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2301, arg_2304, arg_2305) }; i__1685000279__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000279__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :324:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_243; var tmp2 any = A_arbace_go_check_A_const_244; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_245; var tmp5 any; var root_2464 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2464, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2466 lang.IFn; if



	linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2465 == nil { tmp5 = ifn_2466.Invoke_O__O(arg_2467) } else { tmp5 = linked_2465.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2464, arg_2467) }; return /*line :324:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :332:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2468 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2470 lang.IFn; if



	linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = A_arbace_go_check_A_const_245.Invoke_O__O(s__0); if linked_2469 == nil { tmp1 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp1 = linked_2469.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2468, arg_2471) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_244.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2472 any = A_arbace_go_check_A_const_247.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = p__5; if linked_2473 == nil { tmp2 = ifn_2474.Invoke_O__O(arg_2475) } else { tmp2 = linked_2473.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2472, arg_2475) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2476 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = p__5; if linked_2477 == nil { or__1927000174__auto____3 = ifn_2478.Invoke_O__O(arg_2479) } else { or__1927000174__auto____3 = linked_2477.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2476, arg_2479) } } else { or__1927000174__auto____3 = nil } } else {
//line :336:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_248.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2480 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, A_arbace_go_check_ns_package_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = d__5; var arg_2484 any = ns_name__1; if linked_2481 == nil { return ifn_2482.Invoke_O_O__O(arg_2483, arg_2484) } else { return linked_2481.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2480, arg_2483, arg_2484) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :341:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000290_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2528 *jrt.Class = A_arbace_go_check_resolver_fn__1685000290_A_fn_class; _ = deps__4; if




	fncls__2528 == nil { var fncls__2528d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_check_resolver_fn__1685000290_A_fn_class = fncls__2528d; tmp2 = fncls__2528d } else { tmp2 = fncls__2528 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :346:1
func A_arbace_go_check_resolver_fn__1685000290_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000290_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000290_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :346:1
func (t *A_arbace_go_check_resolver_fn__1685000290_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :346:1
func (t *A_arbace_go_check_resolver_fn__1685000290_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_125, path__1) { return A_arbace_go_check_A_const_250.GetRawRoot__O() } else { var lp__3 any; var root_2485 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2487 lang.IFn

		if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = t.F_src; var arg_2489 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_81, A_arbace_go_check_A_const_251, path__1); var arg_2490 any = path__1; if linked_2486 == nil { lp__3 = ifn_2487.Invoke_O_O_O__O(arg_2488, arg_2489, arg_2490) } else { lp__3 = linked_2486.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2485, arg_2488, arg_2489, arg_2490) }
//line :349:1
		var why__4 any; var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_252.Invoke_O__O(t.F_s)



		if jrt.J2g_Truth(temp__1927000414__auto____4) { var rf__5 any = temp__1927000414__auto____4; why__4 = lang.IFn_Cast(rf__5).Invoke_O_O__O(lp__3, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_src)) } else { why__4 = nil }
//line :349:1
		var p__5 any
		var or__1927000174__auto____5 any = why__4




		if jrt.J2g_Truth(or__1927000174__auto____5) { p__5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_2491 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_2492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2491, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2493 lang.IFn
			if linked_2492 == nil { ifn_2493 = lang.IFn_Cast(root_2491) } else { ifn_2493 = nil }; var arg_2494 any = t.F_s; var arg_2495 any = lp__3; var arg_2496 any = t.F_src; var arg_2497 any = t.F_chain; if linked_2492 == nil { or__1927000174__auto____6 = ifn_2493.Invoke_O_O_O_O__O(arg_2494, arg_2495, arg_2496, arg_2497) } else { or__1927000174__auto____6 = linked_2492.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2491, arg_2494, arg_2495, arg_2496, arg_2497) }
//line :355:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { p__5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 any; var and__1927000168__auto____7 any; var root_2498 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2500 lang.IFn

				if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any; var root_2502 any = A_arbace_go_check_A_const_254.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2504 lang.IFn; if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any; var root_2507 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any; var root_2511 any = A_arbace_go_check_A_const_255.GetRawRoot__O(); var linked_2512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2511, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2513 lang.IFn; if linked_2512 == nil { ifn_2513 = lang.IFn_Cast(root_2511) } else { ifn_2513 = nil }; var arg_2514 any = lp__3; var arg_2515 any = A_arbace_go_check_A_const_256; if linked_2512 == nil { arg_2510 = ifn_2513.Invoke_O_O__O(arg_2514, arg_2515) } else { arg_2510 = linked_2512.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2511, arg_2514, arg_2515) }; if linked_2508 == nil { arg_2505 = ifn_2509.Invoke_O__O(arg_2510) } else { arg_2505 = linked_2508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2507, arg_2510) }; var arg_2506 any = Lit_126; if linked_2503 == nil { arg_2501 = ifn_2504.Invoke_O_O__O(arg_2505, arg_2506) } else { arg_2501 = linked_2503.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2502, arg_2505, arg_2506) }; if linked_2499 == nil { and__1927000168__auto____7 = ifn_2500.Invoke_O__O(arg_2501) } else { and__1927000168__auto____7 = linked_2499.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2498, arg_2501) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____7 = nil } else { or__1927000174__auto____7 = nil }
//line :355:1
				if jrt.J2g_Truth(or__1927000174__auto____7) { p__5 = or__1927000174__auto____7 } else {


					var root_2516 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = t.F_s; var arg_2520 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2521 any = t.F_src; var arg_2522 any = t.F_chain; if linked_2517 == nil { p__5 = ifn_2518.Invoke_O_O_O_O__O(arg_2519, arg_2520, arg_2521, arg_2522) } else { p__5 = linked_2517.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2516, arg_2519, arg_2520, arg_2521, arg_2522) } } } }
//line :349:1
		return p__5 } }
//line :346:1
func (t *A_arbace_go_check_resolver_fn__1685000290_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2523 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, A_arbace_go_check_ns_package_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = t.F_s; var arg_2527 any = ns_name__1; if linked_2524 == nil { return ifn_2525.Invoke_O_O__O(arg_2526, arg_2527) } else { return linked_2524.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2523, arg_2526, arg_2527)
	}
}











func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :361:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2610 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2610, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2612 lang.IFn; if linked_2611 == nil { ifn_2612 = lang.IFn_Cast(root_2610) } else { ifn_2612 = nil }; var arg_2613 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2614 any = chain__3; if linked_2611 == nil { tmp1 = ifn_2612.Invoke_O_O__O(arg_2613, arg_2614) } else { tmp1 = linked_2611.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2610, arg_2613, arg_2614) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2615 any = A_arbace_go_check_A_const_261.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2617 lang.IFn
		if linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil); var tmp4 any; var root_2620 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = Lit_100; var arg_2624 any; var root_2625 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = chain__3; var arg_2629 any = path__1; if linked_2626 == nil { arg_2624 = ifn_2627.Invoke_O_O__O(arg_2628, arg_2629) } else { arg_2624 = linked_2626.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2625, arg_2628, arg_2629) }; if linked_2621 == nil { tmp4 = ifn_2622.Invoke_O_O__O(arg_2623, arg_2624) } else { tmp4 = linked_2621.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2620, arg_2623, arg_2624) }; arg_2618 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2619 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110, path__1)); if linked_2616 == nil { tmp2 = ifn_2617.Invoke_O_O__O(arg_2618, arg_2619) } else { tmp2 = linked_2616.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2615, arg_2618, arg_2619) }
//line :364:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :361:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_248.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2529 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2529, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2531 lang.IFn; if linked_2530 == nil { ifn_2531 = lang.IFn_Cast(root_2529) } else { ifn_2531 = nil }; var arg_2532 any = lang.IFn_Cast(A_arbace_go_check_A_const_257.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2530 == nil { and__1927000168__auto____6 = ifn_2531.Invoke_O__O(arg_2532) } else { and__1927000168__auto____6 = linked_2530.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2529, arg_2532) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_248.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2533 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_2534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2533, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2535 lang.IFn

		if linked_2534 == nil { ifn_2535 = lang.IFn_Cast(root_2533) } else { ifn_2535 = nil }; var arg_2536 any = d__6; var arg_2537 any = path__1; var arg_2538 any = importer__2; var arg_2539 any = chain__3; if linked_2534 == nil { return ifn_2535.Invoke_O_O_O_O__O(arg_2536, arg_2537, arg_2538, arg_2539) } else { return linked_2534.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2533, arg_2536, arg_2537, arg_2538, arg_2539) } } else {
//line :366:1
			var cache__6 any = A_arbace_go_check_A_const_244.Invoke_O__O(s__0); var p__7 any; var root_2540 any = A_arbace_go_check_A_const_258.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2542 lang.IFn



			if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; if linked_2541 == nil { p__7 = ifn_2542.Invoke__O() } else { p__7 = linked_2541.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2540) }
//line :366:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2543 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = prev__8; if linked_2544 == nil { return ifn_2545.Invoke_O__O(arg_2546) } else { return linked_2544.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2543, arg_2546) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_243.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2547 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = A_arbace_go_check_A_const_121.Invoke_O__O(src__9); if linked_2548 == nil { tmp5 = ifn_2549.Invoke_O__O(arg_2550) } else { tmp5 = linked_2548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2547, arg_2550) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000293_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2609 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000293_A_fn_class; if fncls__2609 == nil { var fncls__2609d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_go_check_ensure_package_fn__1685000293_A_fn_class = fncls__2609d; tmp7 = fncls__2609d } else { tmp7 = fncls__2609 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :375:1
						pkg__10 = nil
					}






				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2630 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2631 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2630, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2632 lang.IFn; if linked_2631 == nil { ifn_2632 = lang.IFn_Cast(root_2630) } else { ifn_2632 = nil }; var arg_2633 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2634 any = A_arbace_go_check_A_const_264; var arg_2635 any; var root_2636 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2640 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_265; var tmp11 any; var root_2641 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = pkg__10; var arg_2645 any = A_arbace_go_check_A_const_71; if linked_2642 == nil { tmp11 = ifn_2643.Invoke_O_O__O(arg_2644, arg_2645) } else { tmp11 = linked_2642.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2641, arg_2644, arg_2645) }; arg_2640 = tmp10.Invoke_O__O(tmp11); if linked_2637 == nil { arg_2635 = ifn_2638.Invoke_O_O__O(arg_2639, arg_2640) } else { arg_2635 = linked_2637.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2636, arg_2639, arg_2640) }; if linked_2631 == nil { tmp9 = ifn_2632.Invoke_O_O_O__O(arg_2633, arg_2634, arg_2635) } else { tmp9 = linked_2631.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2630, arg_2633, arg_2634, arg_2635) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2646 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = A_arbace_go_check_A_const_245.Invoke_O__O(s__0); var arg_2650 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var arg_2651 any; var root_2653 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = path__1; if linked_2654 == nil { arg_2651 = ifn_2655.Invoke_O__O(arg_2656) } else { arg_2651 = linked_2654.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2653, arg_2656) }; var arg_2652 any = path__1; if linked_2647 == nil { ifn_2648.Invoke_O_O_O_O__O(arg_2649, arg_2650, arg_2651, arg_2652) } else { linked_2647.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2646, arg_2649, arg_2650, arg_2651, arg_2652) }
				var root_2657 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = p__7; var arg_2661 any = pkg__10; if linked_2658 == nil { ifn_2659.Invoke_O_O__O(arg_2660, arg_2661) } else { linked_2658.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2657, arg_2660, arg_2661) }
//line :372:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000293_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000293_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000293_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :376:1
func (t *A_arbace_go_check_ensure_package_fn__1685000293_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :376:1
func (t *A_arbace_go_check_ensure_package_fn__1685000293_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var G__1685000294__3_ any = A_arbace_go_check_A_const_108.Invoke_O__O(t.F_s); if lang.Util_Identical_O_O__Z_NoInit(G__1685000294__3_, nil) { tmp2 = nil } else { var root_2551 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = G__1685000294__3_; var arg_2555 any = lang.Tuple_Create_O__IPersistentVector(t.F_path); if linked_2552 == nil { tmp2 = ifn_2553.Invoke_O_O__O(arg_2554, arg_2555) } else { tmp2 = linked_2552.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2551, arg_2554, arg_2555) } }; if jrt.J2g_Truth(tmp2) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()); var tmp4 any = t.F_src; var tmp5 any; var root_2563 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, A_arbace_go_check_resolver_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any; var t_ any = t.F_s; t.F_s = nil; arg_2566 = t_; var arg_2567 any; var t__2 any = t.F_src; t.F_src = nil; arg_2567 = t__2; var arg_2568 any; var root_2569 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any; var root_2574 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2577 = t__3; if linked_2575 == nil { arg_2572 = ifn_2576.Invoke_O__O(arg_2577) } else { arg_2572 = linked_2575.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2574, arg_2577) }; var arg_2573 any = t.F_path; if linked_2570 == nil { arg_2568 = ifn_2571.Invoke_O_O__O(arg_2572, arg_2573) } else { arg_2568 = linked_2570.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2569, arg_2572, arg_2573) }; if linked_2564 == nil { tmp5 = ifn_2565.Invoke_O_O_O__O(arg_2566, arg_2567, arg_2568) } else { tmp5 = linked_2564.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2563, arg_2566, arg_2567, arg_2568) }; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, A_arbace_go_check_A_const_108, jrt.Boolean_TRUE.Ref()) } else {
													var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()); var tmp7 any = t.F_src; var tmp8 any; var root_2583 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, A_arbace_go_check_resolver_A_fn_class); var ifn_2585 lang.IFn; if linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any; var t__4 any = t.F_s; t.F_s = nil; arg_2586 = t__4; var arg_2587 any; var t__5 any = t.F_src; t.F_src = nil; arg_2587 = t__5; var arg_2588 any; var root_2589 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any; var root_2594 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2596 lang.IFn; if linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any; var t__6 any = t.F_chain; t.F_chain = nil; arg_2597 = t__6; if linked_2595 == nil { arg_2592 = ifn_2596.Invoke_O__O(arg_2597) } else { arg_2592 = linked_2595.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2594, arg_2597) }; var arg_2593 any = t.F_path; if linked_2590 == nil { arg_2588 = ifn_2591.Invoke_O_O__O(arg_2592, arg_2593) } else { arg_2588 = linked_2590.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2589, arg_2592, arg_2593) }; if linked_2584 == nil { tmp8 = ifn_2585.Invoke_O_O_O__O(arg_2586, arg_2587, arg_2588) } else { tmp8 = linked_2584.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2583, arg_2586, arg_2587, arg_2588) }; tmp1 = tmp6.Invoke_O_O__O(tmp7, tmp8) } }
//line :376:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_2604 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2606 lang.IFn




		if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any; var t__7 any = t.F_p; t.F_p = nil; arg_2607 = t__7; var arg_2608 any; if linked_2605 == nil { ifn_2606.Invoke_O_O__O(arg_2607, arg_2608) } else { linked_2605.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2604, arg_2607, arg_2608) }
//line :376:1
		var tmp10 any; var root_2598 any = A_arbace_go_check_A_const_261.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2600 lang.IFn





		if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var tmp11 any = t.F_path; var arg_2601 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2602 any; var tmp12 any = A_arbace_go_check_A_const_110; var tmp13 any; var t__8 any = t.F_path; t.F_path = nil; tmp13 = t__8; arg_2602 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); var arg_2603 any = ex__3; if linked_2599 == nil { tmp10 = ifn_2600.Invoke_O_O_O__O(arg_2601, arg_2602, arg_2603) } else { tmp10 = linked_2599.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2598, arg_2601, arg_2602, arg_2603) }
//line :376:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) } }; return tmp1 }















func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :392:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var G__1685000297__2_ any = corpus__0; switch
											lang.Util_Hash_O__I_NoInit(G__1685000297__2_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000297__2_, Lit_87) { var tmp1 any = A_arbace_go_check_A_const_267; var tmp2 any = A_arbace_go_check_A_const_269; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_268; var tmp5 any = A_arbace_go_check_A_const_269; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_89), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_271, Lit_90)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_272)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000297__2_, Lit_91) { var tmp6 any = A_arbace_go_check_A_const_267; var tmp7 any = A_arbace_go_check_A_const_269; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_273; var tmp10 any = A_arbace_go_check_A_const_269; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_92), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_271, Lit_90)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_274)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000297__2_, Lit_51) { var tmp11 any = A_arbace_go_check_A_const_267; var tmp12 any = A_arbace_go_check_A_const_269; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref(); var tmp14 any = A_arbace_go_check_A_const_278; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_275)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000297__2_, Lit_95) { var tmp15 any = A_arbace_go_check_A_const_267; var tmp16 any = A_arbace_go_check_A_const_269; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref(); var tmp18 any = A_arbace_go_check_A_const_278; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_96), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_276)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000297__2_, Lit_97) { var tmp19 any = A_arbace_go_check_A_const_267; var tmp20 any = A_arbace_go_check_A_const_269; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_279)) }; default:}; var tmp21 any; var root_2663 any = A_arbace_go_check_A_const_261.GetRawRoot__O(); var linked_2664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2663, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2665 lang.IFn; if












	linked_2664 == nil { ifn_2665 = lang.IFn_Cast(root_2663) } else { ifn_2665 = nil }; var arg_2666 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2667 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_277, corpus__0)); if linked_2664 == nil { tmp21 = ifn_2665.Invoke_O_O__O(arg_2666, arg_2667) } else { tmp21 = linked_2664.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2663, arg_2666, arg_2667) }; /*line :393:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp21))) }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :408:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000300__0 any) any { var map__1685000301__2 any = p__1685000300__0; var map__1685000301__3 any; if lang.ISeq_InstanceOf(map__1685000301__2) { var tmp1 any; var root_2668 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = map__1685000301__2; if linked_2669 == nil { tmp1 = ifn_2670.Invoke_O__O(arg_2671) } else { tmp1 = linked_2669.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2668, arg_2671) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2672 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = map__1685000301__2; if linked_2673 == nil { tmp2 = ifn_2674.Invoke_O__O(arg_2675) } else { tmp2 = linked_2673.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2672, arg_2675) }; map__1685000301__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2676 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2676, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2678 lang.IFn; if linked_2677 == nil { ifn_2678 = lang.IFn_Cast(root_2676) } else { ifn_2678 = nil }; var arg_2679 any = map__1685000301__2; if linked_2677 == nil { tmp3 = ifn_2678.Invoke_O__O(arg_2679) } else { tmp3 = linked_2677.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2676, arg_2679) }; if jrt.J2g_Truth(tmp3) { var root_2680 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = map__1685000301__2; if linked_2681 == nil { map__1685000301__3 = ifn_2682.Invoke_O__O(arg_2683) } else { map__1685000301__3 = linked_2681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2680, arg_2683) } } else { map__1685000301__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000301__3 = map__1685000301__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000301__3, A_arbace_go_check_A_const_267); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000301__3, A_arbace_go_check_A_const_111); var root_2684 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, A_arbace_go_check_session_A_fn_class); var ifn_2686 lang.IFn; if
											linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000303_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__2700 *jrt.Class = A_arbace_go_check_std_session_fn__1685000303_A_fn_class; if fncls__2700 == nil { var fncls__2700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_std_session_fn__1685000303_A_fn_class = fncls__2700d; tmp5 = fncls__2700d } else { tmp5 = fncls__2700 }; arg_2687 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_2685 == nil { return ifn_2686.Invoke_O__O(arg_2687) } else { return linked_2685.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2684, arg_2687) } }
//line :409:1
func A_arbace_go_check_std_session_fn__1685000303_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000303_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000303_A{}; t.Ctor_O_O(p0, p1); return t }
//line :409:1
func (t *A_arbace_go_check_std_session_fn__1685000303_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :409:1
func (t *A_arbace_go_check_std_session_fn__1685000303_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_2688 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2690 lang.IFn; if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__2699 *jrt.Class = A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A_fn_class; if fncls__2699 == nil { var fncls__2699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A_fn_class = fncls__2699d; tmp2 = fncls__2699d } else { tmp2 = fncls__2699 }; arg_2691 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2692 any = t.F_roots; if linked_2689 == nil { return ifn_2690.Invoke_O_O__O(arg_2691, arg_2692) } else { return linked_2689.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2688, arg_2691, arg_2692) } }
//line :410:1
func A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A{}; t.Ctor_O_O(p0, p1); return t }
//line :410:1
func (t *A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :410:1
func (t *A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A) Invoke_O_O__O(self, p1__1685000299_SHARP___1 any) any { var root_2693 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2695 lang.IFn; if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = p1__1685000299_SHARP___1; var arg_2697 any = t.F_path; var arg_2698 any = t.F_config; if linked_2694 == nil { return ifn_2695.Invoke_O_O_O__O(arg_2696, arg_2697, arg_2698) } else { return linked_2694.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_2693, arg_2696, arg_2697, arg_2698) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :416:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_2701 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2703 lang.IFn; if


	linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = xs__2; if linked_2702 == nil { xs__4 = ifn_2703.Invoke_O__O(arg_2704) } else { xs__4 = linked_2702.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2701, arg_2704) }; var q__5 any = /*line :416:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_2705 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_2706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2705, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2707 lang.IFn; if





	linked_2706 == nil { ifn_2707 = lang.IFn_Cast(root_2705) } else { ifn_2707 = nil }; var arg_2708 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__2777 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A_fn_class; if fncls__2777 == nil { var fncls__2777d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A_fn_class = fncls__2777d; tmp2 = fncls__2777d } else { tmp2 = fncls__2777 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_2778 any = A_arbace_go_check_A_const_286.GetRawRoot__O(); var linked_2779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2778, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2780 lang.IFn; if linked_2779 == nil { ifn_2780 = lang.IFn_Cast(root_2778) } else { ifn_2780 = nil }; var arg_2781 any = n__0; if linked_2779 == nil { tmp4 = ifn_2780.Invoke_O__O(arg_2781) } else { tmp4 = linked_2779.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2778, arg_2781) }; arg_2708 = tmp3.Invoke_O__O(tmp4); if linked_2706 == nil { workers__7 = ifn_2707.Invoke_O__O(arg_2708) } else { workers__7 = linked_2706.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2705, arg_2708) }; var seq_1685000322__8 any; var root_2786 any = /*line :416:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2788 lang.IFn; if















	linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any = workers__7; if linked_2787 == nil { seq_1685000322__8 = ifn_2788.Invoke_O__O(arg_2789) } else { seq_1685000322__8 = linked_2787.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2786, arg_2789) }; var chunk_1685000323__9 any; var count_1685000324__10 int64 = 0; var i_1685000325__11 int64 = 0; L1:
//line :416:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000325__11, count_1685000324__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000323__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000325__11)); var root_2806 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2808 lang.IFn; if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = w__12; if linked_2807 == nil { ifn_2808.Invoke_O__O(arg_2809) } else { linked_2807.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2806, arg_2809) }; seq_1685000322__8, chunk_1685000323__9, count_1685000324__10, i_1685000325__11 = seq_1685000322__8, chunk_1685000323__9, count_1685000324__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000325__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_2790 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any = seq_1685000322__8; if linked_2791 == nil { temp__1927000414__auto____12 = ifn_2792.Invoke_O__O(arg_2793) } else { temp__1927000414__auto____12 = linked_2791.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2790, arg_2793) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000322__13 any = temp__1927000414__auto____12; var tmp5 any; var root_2794 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any = seq_1685000322__13; if linked_2795 == nil { tmp5 = ifn_2796.Invoke_O__O(arg_2797) } else { tmp5 = linked_2795.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2794, arg_2797) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_2798 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2798, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2800 lang.IFn; if linked_2799 == nil { ifn_2800 = lang.IFn_Cast(root_2798) } else { ifn_2800 = nil }; var arg_2801 any = seq_1685000322__13; if linked_2799 == nil { c__1927000678__auto____14 = ifn_2800.Invoke_O__O(arg_2801) } else { c__1927000678__auto____14 = linked_2799.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2798, arg_2801) }; var tmp6 any; var root_2810 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2810, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2812 lang.IFn; if linked_2811 == nil { ifn_2812 = lang.IFn_Cast(root_2810) } else { ifn_2812 = nil }; var arg_2813 any = seq_1685000322__13; if linked_2811 == nil { tmp6 = ifn_2812.Invoke_O__O(arg_2813) } else { tmp6 = linked_2811.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2810, arg_2813) }; seq_1685000322__8, chunk_1685000323__9, count_1685000324__10, i_1685000325__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_2802 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2804 lang.IFn; if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any = seq_1685000322__13; if linked_2803 == nil { w__14 = ifn_2804.Invoke_O__O(arg_2805) } else { w__14 = linked_2803.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2802, arg_2805) }; var root_2814 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2814, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2816 lang.IFn; if linked_2815 == nil { ifn_2816 = lang.IFn_Cast(root_2814) } else { ifn_2816 = nil }; var arg_2817 any = w__14; if linked_2815 == nil { ifn_2816.Invoke_O__O(arg_2817) } else { linked_2815.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2814, arg_2817) }; var tmp7 any; var root_2818 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2818, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2820 lang.IFn; if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any = seq_1685000322__13; if linked_2819 == nil { tmp7 = ifn_2820.Invoke_O__O(arg_2821) } else { tmp7 = linked_2819.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2818, arg_2821) }; seq_1685000322__8, chunk_1685000323__9, count_1685000324__10, i_1685000325__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :416:1
		break L1 }; var root_2782 any =
















	A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2782, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2784 lang.IFn; if linked_2783 == nil { ifn_2784 = lang.IFn_Cast(root_2782) } else { ifn_2784 = nil }; var arg_2785 any = out__6; if linked_2783 == nil { return ifn_2784.Invoke_O__O(arg_2785) } else { return linked_2783.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2782, arg_2785) } }
//line :422:1
func A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :422:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :422:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A) Invoke_O_O__O(self, s__1685000309__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A_New_O_O_O_O_O_O(s__1685000309__1, t.F_f, self, t.F_out, t.F_q, t.F_xs); var tmp2 *jrt.Class; var fncls__2776 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A_fn_class; if fncls__2776 == nil { var fncls__2776d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A_fn_class = fncls__2776d; tmp2 = fncls__2776d } else { tmp2 = fncls__2776 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :422:1
func A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :422:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A) Ctor_O_O_O_O_O_O(c__s__1685000309, c__f, c__iter__1685000308, c__out, c__q, c__xs any) { t.F_s__1685000309 = c__s__1685000309; t.F_f = c__f; t.F_iter__1685000308 = c__iter__1685000308; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :422:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A) Invoke_O__O(self any) any { { var s__1685000309__1 any; var t_ any = t.F_s__1685000309; t.F_s__1685000309 = nil; s__1685000309__1 = t_; for { var temp__1927000414__auto____2 any; var root_2709 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2709, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2711 lang.IFn; if linked_2710 == nil { ifn_2711 = lang.IFn_Cast(root_2709) } else { ifn_2711 = nil }; var arg_2712 any = s__1685000309__1; if linked_2710 == nil { temp__1927000414__auto____2 = ifn_2711.Invoke_O__O(arg_2712) } else { temp__1927000414__auto____2 = linked_2710.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2709, arg_2712) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000309__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2713 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = s__1685000309__3; if linked_2714 == nil { tmp1 = ifn_2715.Invoke_O__O(arg_2716) } else { tmp1 = linked_2714.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2713, arg_2716) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2717 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = s__1685000309__3; if linked_2718 == nil { c__1927001037__auto____4 = ifn_2719.Invoke_O__O(arg_2720) } else { c__1927001037__auto____4 = linked_2718.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2717, arg_2720) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000311__6 any; var root_2721 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2722 == nil { b__1685000311__6 = ifn_2723.Invoke_O__O(arg_2724) } else { b__1685000311__6 = linked_2722.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2721, arg_2724) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A_New_O_O_O_O_O_I_O(b__1685000311__6, t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2735 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A_fn_class; if fncls__2735 == nil { var fncls__2735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A_fn_class = fncls__2735d; tmp3 = fncls__2735d } else { tmp3 = fncls__2735 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2736 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2736, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; var arg_2739 any; var root_2741 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2741, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2743 lang.IFn; if linked_2742 == nil { ifn_2743 = lang.IFn_Cast(root_2741) } else { ifn_2743 = nil }; var arg_2744 any = b__1685000311__6; if linked_2742 == nil { arg_2739 = ifn_2743.Invoke_O__O(arg_2744) } else { arg_2739 = linked_2742.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2741, arg_2744) }; var arg_2740 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000308); var tmp5 any; var root_2745 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2745, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2747 lang.IFn; if linked_2746 == nil { ifn_2747 = lang.IFn_Cast(root_2745) } else { ifn_2747 = nil }; var arg_2748 any = s__1685000309__3; if linked_2746 == nil { tmp5 = ifn_2747.Invoke_O__O(arg_2748) } else { tmp5 = linked_2746.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2745, arg_2748) }; arg_2740 = tmp4.Invoke_O__O(tmp5); if linked_2737 == nil { return ifn_2738.Invoke_O_O__O(arg_2739, arg_2740) } else { return linked_2737.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2736, arg_2739, arg_2740) } } else { var root_2749 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2749, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2751 lang.IFn; if linked_2750 == nil { ifn_2751 = lang.IFn_Cast(root_2749) } else { ifn_2751 = nil }; var arg_2752 any; var root_2754 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2754, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2756 lang.IFn; if linked_2755 == nil { ifn_2756 = lang.IFn_Cast(root_2754) } else { ifn_2756 = nil }; var arg_2757 any = b__1685000311__6; if linked_2755 == nil { arg_2752 = ifn_2756.Invoke_O__O(arg_2757) } else { arg_2752 = linked_2755.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2754, arg_2757) }; var arg_2753 any; if linked_2750 == nil { return ifn_2751.Invoke_O_O__O(arg_2752, arg_2753) } else { return linked_2750.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2749, arg_2752, arg_2753) } } } else { var ___4 any; var root_2758 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2760 lang.IFn; _ = ___4; if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any = s__1685000309__3; if linked_2759 == nil { ___4 = ifn_2760.Invoke_O__O(arg_2761) } else { ___4 = linked_2759.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2758, arg_2761) }; var root_2762 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any; var root_2767 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_2768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2767, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2769 lang.IFn
															if linked_2768 == nil { ifn_2769 = lang.IFn_Cast(root_2767) } else { ifn_2769 = nil }; var arg_2770 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__2771 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A_fn_class; if fncls__2771 == nil { var fncls__2771d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A_fn_class = fncls__2771d; tmp7 = fncls__2771d } else { tmp7 = fncls__2771 }; arg_2770 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2768 == nil { arg_2765 = ifn_2769.Invoke_O__O(arg_2770) } else { arg_2765 = linked_2768.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2767, arg_2770) }
//line :422:1
	var arg_2766 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000308); var tmp9 any; var root_2772 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2774 lang.IFn; if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = s__1685000309__3; if linked_2773 == nil { tmp9 = ifn_2774.Invoke_O__O(arg_2775) } else { tmp9 = linked_2773.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2772, arg_2775) }; arg_2766 = tmp8.Invoke_O__O(tmp9); if linked_2763 == nil { return ifn_2764.Invoke_O_O__O(arg_2765, arg_2766) } else { return linked_2763.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2762, arg_2765, arg_2766) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :422:1
func A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :422:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A) Ctor_O_O_O_O_O_I_O(c__b__1685000311, c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000311 = c__b__1685000311; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :422:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A) Invoke_O__O(self any) any { { var i__1685000310__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000310__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000310__1)); var root_2725 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2727 lang.IFn; _ = ___2; if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any = t.F_b__1685000311; var arg_2729 any; var root_2730 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2732 lang.IFn
																if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__2734 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A_fn_class; if fncls__2734 == nil { var fncls__2734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A_fn_class = fncls__2734d; tmp3 = fncls__2734d } else { tmp3 = fncls__2734 }; arg_2733 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2731 == nil { arg_2729 = ifn_2732.Invoke_O__O(arg_2733) } else { arg_2729 = linked_2731.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2730, arg_2733) }
//line :422:1
	if linked_2726 == nil { ifn_2727.Invoke_O_O__O(arg_2728, arg_2729) } else { linked_2726.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2725, arg_2728, arg_2729) }; i__1685000310__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000310__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :423:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :423:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_284.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_284.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_285) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_284.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_284.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :426:1
			return nil } } }; /*line :423:1*/panic("j2g: unreachable") }
//line :423:1
func A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :423:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :423:1
func (t *A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_284.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_284.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_285) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_284.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_284.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :426:1
			return nil } } }; /*line :423:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :435:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_2822 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2822, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2824 lang.IFn; if linked_2823 == nil { ifn_2824 = lang.IFn_Cast(root_2822) } else { ifn_2824 = nil }; var arg_2825 any = pkg__0; var arg_2826 any = A_arbace_go_check_A_const_224; if linked_2823 == nil { return ifn_2824.Invoke_O_O__O(arg_2825, arg_2826) } else { return linked_2823.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2822, arg_2825, arg_2826) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :437:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_110; var tmp2 any = A_arbace_go_check_A_const_225; var tmp3 any = A_arbace_go_check_A_const_73; var tmp4 any = A_arbace_go_check_A_const_78; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_288; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_104, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :437:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_289, A_arbace_go_check_A_const_290))), A_arbace_go_check_A_const_161, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_150, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_162, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_137, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_163, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_154, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_142, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_287, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :444:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :444:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_2827 any = A_arbace_go_check_A_const_291.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2827, A_arbace_go_check_corpus_config_A_fn_class); var ifn_2829 lang.IFn; if


	linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any = corpus__0; if linked_2828 == nil { cc__3 = ifn_2829.Invoke_O__O(arg_2830) } else { cc__3 = linked_2828.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_2827, arg_2830) }; var s__4 any; var root_2831 any = /*line :444:1*/A_arbace_go_check_A_const_292.GetRawRoot__O(); var linked_2832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2831, A_arbace_go_check_std_session_A_fn_class); var ifn_2833 lang.IFn; if



	linked_2832 == nil { ifn_2833 = lang.IFn_Cast(root_2831) } else { ifn_2833 = nil }; var arg_2834 any = cc__3; if linked_2832 == nil { s__4 = ifn_2833.Invoke_O__O(arg_2834) } else { s__4 = linked_2832.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_2831, arg_2834) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :444:1*/A_arbace_go_check_A_const_273.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_268.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_2835 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2837 lang.IFn
		if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = A_arbace_go_check_A_const_267.Invoke_O__O(cc__3); if linked_2836 == nil { root__5 = ifn_2837.Invoke_O__O(arg_2838) } else { root__5 = linked_2836.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2835, arg_2838) }
		var root_2839 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2839, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A_New(); var tmp3 *jrt.Class; var fncls__2909 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A_fn_class; if fncls__2909 == nil { var fncls__2909d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A_fn_class = fncls__2909d; tmp3 = fncls__2909d } else { tmp3 = fncls__2909 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_2910 any = A_arbace_go_check_A_const_294.GetRawRoot__O(); var linked_2911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2910, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2912 lang.IFn; if linked_2911 == nil { ifn_2912 = lang.IFn_Cast(root_2910) } else { ifn_2912 = nil }; var arg_2913 any = root__5; var arg_2914 any = Lit_33; if linked_2911 == nil { tmp5 = ifn_2912.Invoke_O_O__O(arg_2913, arg_2914) } else { tmp5 = linked_2911.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2910, arg_2913, arg_2914) }; arg_2842 = tmp4.Invoke_O__O(tmp5); if linked_2840 == nil { std_pkgs__5 = ifn_2841.Invoke_O__O(arg_2842) } else { std_pkgs__5 = linked_2840.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2839, arg_2842) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_2915 any = A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_2916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2915, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2917 lang.IFn; if linked_2916 == nil { ifn_2917 = lang.IFn_Cast(root_2915) } else { ifn_2917 = nil }; var arg_2918 any = jobs__1; var arg_2919 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000340_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__2937 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000340_A_fn_class
		if fncls__2937 == nil { var fncls__2937d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_check_corpus_fn__1685000340_A_fn_class = fncls__2937d; tmp7 = fncls__2937d } else { tmp7 = fncls__2937 }; arg_2919 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :456:1
		var arg_2920 any = std_pkgs__5; if linked_2916 == nil { return ifn_2917.Invoke_O_O_O__O(arg_2918, arg_2919, arg_2920) } else { return linked_2916.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2915, arg_2918, arg_2919, arg_2920) } } else {
//line :454:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_273.Invoke_O__O(cc__3)) { var map__1685000342__6 any = A_arbace_go_check_A_const_273.Invoke_O__O(cc__3); var map__1685000342__7 any








				if lang.ISeq_InstanceOf(map__1685000342__6) { var tmp8 any; var root_2938 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2938, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2940 lang.IFn; if linked_2939 == nil { ifn_2940 = lang.IFn_Cast(root_2938) } else { ifn_2940 = nil }; var arg_2941 any = map__1685000342__6; if linked_2939 == nil { tmp8 = ifn_2940.Invoke_O__O(arg_2941) } else { tmp8 = linked_2939.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2938, arg_2941) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2942 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_2943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2942, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2944 lang.IFn; if linked_2943 == nil { ifn_2944 = lang.IFn_Cast(root_2942) } else { ifn_2944 = nil }; var arg_2945 any = map__1685000342__6; if linked_2943 == nil { tmp9 = ifn_2944.Invoke_O__O(arg_2945) } else { tmp9 = linked_2943.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2942, arg_2945) }; map__1685000342__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_2946 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2946, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2948 lang.IFn; if linked_2947 == nil { ifn_2948 = lang.IFn_Cast(root_2946) } else { ifn_2948 = nil }; var arg_2949 any = map__1685000342__6; if linked_2947 == nil { tmp10 = ifn_2948.Invoke_O__O(arg_2949) } else { tmp10 = linked_2947.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2946, arg_2949) }; if jrt.J2g_Truth(tmp10) { var root_2950 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2950, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2952 lang.IFn; if linked_2951 == nil { ifn_2952 = lang.IFn_Cast(root_2950) } else { ifn_2952 = nil }; var arg_2953 any = map__1685000342__6; if linked_2951 == nil { map__1685000342__7 = ifn_2952.Invoke_O__O(arg_2953) } else { map__1685000342__7 = linked_2951.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2950, arg_2953) } } else { map__1685000342__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000342__7 = map__1685000342__6 }
//line :454:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000342__7, A_arbace_go_check_A_const_269); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000342__7, A_arbace_go_check_A_const_271); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_269, dir__8)); var root_2954 any = A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2956 lang.IFn










				if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any = jobs__1; var arg_2958 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000344_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__3002 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000344_A_fn_class
				if fncls__3002 == nil { var fncls__3002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_fn__1685000344_A_fn_class = fncls__3002d; tmp12 = fncls__3002d } else { tmp12 = fncls__3002 }; arg_2958 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :465:1
				var arg_2959 any; var root_3003 any = A_arbace_go_check_A_const_294.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3005 lang.IFn








				if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = root__10; var arg_3007 any = sub__9; if linked_3004 == nil { arg_2959 = ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { arg_2959 = linked_3004.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) }
//line :465:1
				if linked_2955 == nil { return ifn_2956.Invoke_O_O_O__O(arg_2957, arg_2958, arg_2959) } else { return linked_2955.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2954, arg_2957, arg_2958, arg_2959) } } else {
//line :454:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_268.Invoke_O__O(cc__3)) { var map__1685000346__6 any = A_arbace_go_check_A_const_268.Invoke_O__O(cc__3); var map__1685000346__7 any





















						if lang.ISeq_InstanceOf(map__1685000346__6) { var tmp13 any; var root_3008 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3010 lang.IFn; if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = map__1685000346__6; if linked_3009 == nil { tmp13 = ifn_3010.Invoke_O__O(arg_3011) } else { tmp13 = linked_3009.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3008, arg_3011) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_3012 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = map__1685000346__6; if linked_3013 == nil { tmp14 = ifn_3014.Invoke_O__O(arg_3015) } else { tmp14 = linked_3013.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3012, arg_3015) }; map__1685000346__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp14, jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 any; var root_3016 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any = map__1685000346__6; if linked_3017 == nil { tmp15 = ifn_3018.Invoke_O__O(arg_3019) } else { tmp15 = linked_3017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3016, arg_3019) }; if jrt.J2g_Truth(tmp15) { var root_3020 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3022 lang.IFn; if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = map__1685000346__6; if linked_3021 == nil { map__1685000346__7 = ifn_3022.Invoke_O__O(arg_3023) } else { map__1685000346__7 = linked_3021.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3020, arg_3023) } } else { map__1685000346__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000346__7 = map__1685000346__6 }
//line :454:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000346__7, A_arbace_go_check_A_const_269); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000346__7, A_arbace_go_check_A_const_271); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_269, dir__8_2)); var pfs__11 any; var root_3024 any = A_arbace_go_check_A_const_294.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3026 lang.IFn























						if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = root__10_2; var arg_3028 any = sub__9_2; if linked_3025 == nil { pfs__11 = ifn_3026.Invoke_O_O__O(arg_3027, arg_3028) } else { pfs__11 = linked_3025.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3024, arg_3027, arg_3028) }
//line :454:1
						var tests__12 any; var root_3029 any = A_arbace_go_check_A_const_300.GetRawRoot__O(); var linked_3030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3029, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3031 lang.IFn

























						if linked_3030 == nil { ifn_3031 = lang.IFn_Cast(root_3029) } else { ifn_3031 = nil }; var arg_3032 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000348_A_New(); var tmp17 *jrt.Class; var fncls__3039 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000348_A_fn_class; if fncls__3039 == nil { var fncls__3039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_check_corpus_fn__1685000348_A_fn_class = fncls__3039d; tmp17 = fncls__3039d } else { tmp17 = fncls__3039 }; arg_3032 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3033 any = pfs__11; if linked_3030 == nil { tests__12 = ifn_3031.Invoke_O_O__O(arg_3032, arg_3033) } else { tests__12 = linked_3030.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3029, arg_3032, arg_3033)
						}


						var root_3040 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any; var root_3044 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var arg_3048 any; var root_3049 any = A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3051 lang.IFn
						if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any = jobs__1; var arg_3053 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000354_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__3282 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_A_fn_class
						if fncls__3282 == nil { var fncls__3282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000354_A_fn_class = fncls__3282d; tmp19 = fncls__3282d } else { tmp19 = fncls__3282 }; arg_3053 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :485:1
						var arg_3054 any; var root_3283 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3285 lang.IFn














						if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var arg_3287 any = tests__12; if linked_3284 == nil { arg_3054 = ifn_3285.Invoke_O_O__O(arg_3286, arg_3287) } else { arg_3054 = linked_3284.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3283, arg_3286, arg_3287) }
//line :485:1
						if linked_3050 == nil { arg_3048 = ifn_3051.Invoke_O_O_O__O(arg_3052, arg_3053, arg_3054) } else { arg_3048 = linked_3050.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3049, arg_3052, arg_3053, arg_3054) }
//line :484:1
						if linked_3045 == nil { arg_3043 = ifn_3046.Invoke_O_O__O(arg_3047, arg_3048) } else { arg_3043 = linked_3045.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3044, arg_3047, arg_3048) }; if linked_3041 == nil { return ifn_3042.Invoke_O__O(arg_3043) } else { return linked_3041.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3040, arg_3043) } } else {
//line :454:1
							return nil } } } }
//line :452:1
func A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A_New() *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A{}; t.Ctor(); return t }
//line :452:1
func (t *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A) Ctor() {}
//line :452:1
func (t *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A) Invoke_O_O__O(self, s__1685000331__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A_New_O_O(s__1685000331__1, self); var tmp2 *jrt.Class; var fncls__2908 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A_fn_class; if fncls__2908 == nil { var fncls__2908d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A_fn_class = fncls__2908d; tmp2 = fncls__2908d } else { tmp2 = fncls__2908 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :452:1
func A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A{}; t.Ctor_O_O(p0, p1); return t }
//line :452:1
func (t *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A) Ctor_O_O(c__s__1685000331, c__iter__1685000330 any) { t.F_s__1685000331 = c__s__1685000331; t.F_iter__1685000330 = c__iter__1685000330 }
//line :452:1
func (t *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A) Invoke_O__O(self any) any { { var s__1685000331__1 any; var t_ any = t.F_s__1685000331; t.F_s__1685000331 = nil; s__1685000331__1 = t_; for { var temp__1927000414__auto____2 any; var root_2843 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any = s__1685000331__1; if linked_2844 == nil { temp__1927000414__auto____2 = ifn_2845.Invoke_O__O(arg_2846) } else { temp__1927000414__auto____2 = linked_2844.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2843, arg_2846) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000331__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2847 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2849 lang.IFn; if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = s__1685000331__3; if linked_2848 == nil { tmp1 = ifn_2849.Invoke_O__O(arg_2850) } else { tmp1 = linked_2848.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2847, arg_2850) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2851 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = s__1685000331__3; if linked_2852 == nil { c__1927001037__auto____4 = ifn_2853.Invoke_O__O(arg_2854) } else { c__1927001037__auto____4 = linked_2852.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2851, arg_2854) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000333__6 any; var root_2855 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2856 == nil { b__1685000333__6 = ifn_2857.Invoke_O__O(arg_2858) } else { b__1685000333__6 = linked_2856.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2855, arg_2858) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A_New_O_I_O(b__1685000333__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2868 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A_fn_class; if fncls__2868 == nil { var fncls__2868d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A_fn_class = fncls__2868d; tmp3 = fncls__2868d } else { tmp3 = fncls__2868 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2869 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2871 lang.IFn; if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any; var root_2874 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any = b__1685000333__6; if linked_2875 == nil { arg_2872 = ifn_2876.Invoke_O__O(arg_2877) } else { arg_2872 = linked_2875.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2874, arg_2877) }; var arg_2873 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000330); var tmp5 any; var root_2878 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2880 lang.IFn; if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = s__1685000331__3; if linked_2879 == nil { tmp5 = ifn_2880.Invoke_O__O(arg_2881) } else { tmp5 = linked_2879.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2878, arg_2881) }; arg_2873 = tmp4.Invoke_O__O(tmp5); if linked_2870 == nil { return ifn_2871.Invoke_O_O__O(arg_2872, arg_2873) } else { return linked_2870.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2869, arg_2872, arg_2873) } } else { var root_2882 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2882, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2884 lang.IFn; if linked_2883 == nil { ifn_2884 = lang.IFn_Cast(root_2882) } else { ifn_2884 = nil }; var arg_2885 any; var root_2887 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2887, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2889 lang.IFn; if linked_2888 == nil { ifn_2889 = lang.IFn_Cast(root_2887) } else { ifn_2889 = nil }; var arg_2890 any = b__1685000333__6; if linked_2888 == nil { arg_2885 = ifn_2889.Invoke_O__O(arg_2890) } else { arg_2885 = linked_2888.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2887, arg_2890) }; var arg_2886 any; if linked_2883 == nil { return ifn_2884.Invoke_O_O__O(arg_2885, arg_2886) } else { return linked_2883.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2882, arg_2885, arg_2886) } } } else { var pf__4 any; var root_2891 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = s__1685000331__3; if linked_2892 == nil { pf__4 = ifn_2893.Invoke_O__O(arg_2894) } else { pf__4 = linked_2892.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2891, arg_2894) }; var root_2895 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any; var root_2900 any = A_arbace_go_check_A_const_293.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2902 lang.IFn
															if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var arg_2903 any = pf__4; if linked_2901 == nil { arg_2898 = ifn_2902.Invoke_O__O(arg_2903) } else { arg_2898 = linked_2901.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2900, arg_2903) }
//line :452:1
	var arg_2899 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000330); var tmp7 any; var root_2904 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2904, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2906 lang.IFn; if linked_2905 == nil { ifn_2906 = lang.IFn_Cast(root_2904) } else { ifn_2906 = nil }; var arg_2907 any = s__1685000331__3; if linked_2905 == nil { tmp7 = ifn_2906.Invoke_O__O(arg_2907) } else { tmp7 = linked_2905.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2904, arg_2907) }; arg_2899 = tmp6.Invoke_O__O(tmp7); if linked_2896 == nil { return ifn_2897.Invoke_O_O__O(arg_2898, arg_2899) } else { return linked_2896.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2895, arg_2898, arg_2899) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :452:1
func A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :452:1
func (t *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A) Ctor_O_I_O(c__b__1685000333 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000333 = c__b__1685000333; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :452:1
func (t *A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A) Invoke_O__O(self any) any { { var i__1685000332__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000332__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000332__1)); var root_2859 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2861 lang.IFn; if linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any = t.F_b__1685000333; var arg_2863 any; var root_2864 any = A_arbace_go_check_A_const_293.GetRawRoot__O(); var linked_2865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2864, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2866 lang.IFn
																if linked_2865 == nil { ifn_2866 = lang.IFn_Cast(root_2864) } else { ifn_2866 = nil }; var arg_2867 any = pf__2; if linked_2865 == nil { arg_2863 = ifn_2866.Invoke_O__O(arg_2867) } else { arg_2863 = linked_2865.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2864, arg_2867) }
//line :452:1
	if linked_2860 == nil { ifn_2861.Invoke_O_O__O(arg_2862, arg_2863) } else { linked_2860.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2859, arg_2862, arg_2863) }; i__1685000332__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000332__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000340_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000340_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000340_A{}; t.Ctor_O(p0); return t }
//line :457:1
func (t *A_arbace_go_check_check_corpus_fn__1685000340_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :457:1
func (t *A_arbace_go_check_check_corpus_fn__1685000340_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_2921 any = A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_2922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2921, A_arbace_go_check_result_of_A_fn_class); var ifn_2923 lang.IFn
												if linked_2922 == nil { ifn_2923 = lang.IFn_Cast(root_2921) } else { ifn_2923 = nil }; var arg_2924 any; var root_2925 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = t.F_s; var arg_2929 any = path__1; var arg_2930 any; var arg_2931 any = lang.PersistentVector_EMPTY.Ref(); if linked_2926 == nil { arg_2924 = ifn_2927.Invoke_O_O_O_O__O(arg_2928, arg_2929, arg_2930, arg_2931) } else { arg_2924 = linked_2926.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2925, arg_2928, arg_2929, arg_2930, arg_2931) }; if linked_2922 == nil { or__1927000174__auto____4 = ifn_2923.Invoke_O__O(arg_2924) } else { or__1927000174__auto____4 = linked_2922.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2921, arg_2924) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110, path__1, A_arbace_go_check_A_const_297, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :457:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_2932 any = A_arbace_go_check_A_const_298.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2932, A_arbace_go_check_error_result_A_fn_class); var ifn_2934 lang.IFn


		if linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any = path__1; var arg_2936 any = ex__4; if linked_2933 == nil { tmp1 = ifn_2934.Invoke_O_O__O(arg_2935, arg_2936) } else { tmp1 = linked_2933.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2932, arg_2935, arg_2936) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000344_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000344_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :466:1
func (t *A_arbace_go_check_check_corpus_fn__1685000344_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :466:1
func (t *A_arbace_go_check_check_corpus_fn__1685000344_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_2960 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2960, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2962 lang.IFn

	if linked_2961 == nil { ifn_2962 = lang.IFn_Cast(root_2960) } else { ifn_2962 = nil }; var arg_2963 any = t.F_root; var arg_2964 any; var arg_2965 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_cc); var arg_2966 any = pf__1; if linked_2961 == nil { src__4 = ifn_2962.Invoke_O_O_O_O__O(arg_2963, arg_2964, arg_2965, arg_2966) } else { src__4 = linked_2961.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2960, arg_2963, arg_2964, arg_2965, arg_2966) }
	var tmp2 any; var root_2967 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = A_arbace_go_check_A_const_121.Invoke_O__O(src__4); if linked_2968 == nil { tmp2 = ifn_2969.Invoke_O__O(arg_2970) } else { tmp2 = linked_2968.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2967, arg_2970) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_110; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_297, jrt.Boolean_TRUE.Ref())) } else {

		var root_2971 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any; var root_2977 any = A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, A_arbace_go_check_result_of_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()); var tmp5 any; var root_2986 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, A_arbace_go_check_resolver_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = t.F_s; var arg_2990 any = src__4; var arg_2991 any = lang.PersistentVector_EMPTY.Ref(); if linked_2987 == nil { tmp5 = ifn_2988.Invoke_O_O_O__O(arg_2989, arg_2990, arg_2991) } else { tmp5 = linked_2987.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2986, arg_2989, arg_2990, arg_2991) }; arg_2980 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_2978 == nil { arg_2974 = ifn_2979.Invoke_O__O(arg_2980) } else { arg_2974 = linked_2978.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2977, arg_2980) }; var arg_2975 any = A_arbace_go_check_A_const_110; var arg_2976 any; var root_2992 any = A_arbace_go_check_A_const_299.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2994 lang.IFn
		if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2996 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_2993 == nil { arg_2976 = ifn_2994.Invoke_O_O__O(arg_2995, arg_2996) } else { arg_2976 = linked_2993.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2992, arg_2995, arg_2996) }
//line :471:1
		if linked_2972 == nil { tmp1 = ifn_2973.Invoke_O_O_O__O(arg_2974, arg_2975, arg_2976) } else { tmp1 = linked_2972.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2971, arg_2974, arg_2975, arg_2976) } } }; return nil }(); if /*line :466:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_2997 any = A_arbace_go_check_A_const_298.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, A_arbace_go_check_error_result_A_fn_class); var ifn_2999 lang.IFn






			if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3001 any = ex__4; if linked_2998 == nil { tmp1 = ifn_2999.Invoke_O_O__O(arg_3000, arg_3001) } else { tmp1 = linked_2998.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2997, arg_3000, arg_3001) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000348_A_New() *A_arbace_go_check_check_corpus_fn__1685000348_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000348_A{}; t.Ctor(); return t }
//line :480:1
func (t *A_arbace_go_check_check_corpus_fn__1685000348_A) Ctor() {}
//line :480:1
func (t *A_arbace_go_check_check_corpus_fn__1685000348_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_3034 any = A_arbace_go_check_A_const_301.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3036 lang.IFn; if

	linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any = A_arbace_go_check_A_const_302; var arg_3038 any = p__2; if linked_3035 == nil { temp__1927000408__auto____3 = ifn_3036.Invoke_O_O__O(arg_3037, arg_3038) } else { temp__1927000408__auto____3 = linked_3035.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3034, arg_3037, arg_3038) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000349__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000349__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000349__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000354_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000354_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :486:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :486:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_A) Invoke_O_O__O(self, p__1685000353__1 any) any { var vec__1685000355__2 any = p__1685000353__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000355__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000355__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_3055 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3057 lang.IFn

	if linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3059 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A_New(); var tmp3 *jrt.Class; var fncls__3126 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A_fn_class; if fncls__3126 == nil { var fncls__3126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A_fn_class = fncls__3126d; tmp3 = fncls__3126d } else { tmp3 = fncls__3126 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_3059 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_3056 == nil { by_path__7 = ifn_3057.Invoke_O_O__O(arg_3058, arg_3059) } else { by_path__7 = linked_3056.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3055, arg_3058, arg_3059) }
//line :486:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp5 any; var root_3135 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3135, A_arbace_go_check_session_A_fn_class); var ifn_3137 lang.IFn



	if linked_3136 == nil { ifn_3137 = lang.IFn_Cast(root_3135) } else { ifn_3137 = nil }; var arg_3138 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__3146 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A_fn_class; if fncls__3146 == nil { var fncls__3146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A_fn_class = fncls__3146d; tmp7 = fncls__3146d } else { tmp7 = fncls__3146 }; arg_3138 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3136 == nil { tmp5 = ifn_3137.Invoke_O__O(arg_3138) } else { tmp5 = linked_3136.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3135, arg_3138) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_248; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_257; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__3152 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A_fn_class; if fncls__3152 == nil { var fncls__3152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A_fn_class = fncls__3152d; tmp13 = fncls__3152d } else { tmp13 = fncls__3152 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_3153 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_3154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3153, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3155 lang.IFn; if linked_3154 == nil { ifn_3155 = lang.IFn_Cast(root_3153) } else { ifn_3155 = nil }; var arg_3156 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__3271 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A_fn_class; if fncls__3271 == nil { var fncls__3271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A_fn_class = fncls__3271d; tmp15 = fncls__3271d } else { tmp15 = fncls__3271 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_3272 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var arg_3276 any = by_path__7; if linked_3273 == nil { tmp17 = ifn_3274.Invoke_O_O__O(arg_3275, arg_3276) } else { tmp17 = linked_3273.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3272, arg_3275, arg_3276) }; arg_3156 = tmp16.Invoke_O__O(tmp17); if linked_3154 == nil { tmp1 = ifn_3155.Invoke_O__O(arg_3156) } else { tmp1 = linked_3154.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3153, arg_3156) } }; return nil }(); if /*line :486:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_3277 any = A_arbace_go_check_A_const_298.GetRawRoot__O(); var linked_3278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3277, A_arbace_go_check_error_result_A_fn_class); var ifn_3279 lang.IFn












		if linked_3278 == nil { ifn_3279 = lang.IFn_Cast(root_3277) } else { ifn_3279 = nil }; var arg_3280 any = tdir__3; var arg_3281 any = ex__7; if linked_3278 == nil { tmp19 = ifn_3279.Invoke_O_O__O(arg_3280, arg_3281) } else { tmp19 = linked_3278.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3277, arg_3280, arg_3281) }
//line :486:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A_New() *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A) Ctor() {}
//line :488:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A) Invoke_O_O__O(self, s__1685000359__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A_New_O_O(self, s__1685000359__1); var tmp2 *jrt.Class; var fncls__3125 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A_fn_class; if fncls__3125 == nil { var fncls__3125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A_fn_class = fncls__3125d; tmp2 = fncls__3125d } else { tmp2 = fncls__3125 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :488:1
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :488:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A) Ctor_O_O(c__iter__1685000358, c__s__1685000359 any) { t.F_iter__1685000358 = c__iter__1685000358; t.F_s__1685000359 = c__s__1685000359 }
//line :488:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A) Invoke_O__O(self any) any { { var s__1685000359__1 any; var t_ any = t.F_s__1685000359; t.F_s__1685000359 = nil; s__1685000359__1 = t_; for { var temp__1927000414__auto____2 any; var root_3060 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3062 lang.IFn; if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any = s__1685000359__1; if linked_3061 == nil { temp__1927000414__auto____2 = ifn_3062.Invoke_O__O(arg_3063) } else { temp__1927000414__auto____2 = linked_3061.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3060, arg_3063) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000359__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3064 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3064, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3066 lang.IFn; if linked_3065 == nil { ifn_3066 = lang.IFn_Cast(root_3064) } else { ifn_3066 = nil }; var arg_3067 any = s__1685000359__3; if linked_3065 == nil { tmp1 = ifn_3066.Invoke_O__O(arg_3067) } else { tmp1 = linked_3065.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3064, arg_3067) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3068 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3068, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3070 lang.IFn; if linked_3069 == nil { ifn_3070 = lang.IFn_Cast(root_3068) } else { ifn_3070 = nil }; var arg_3071 any = s__1685000359__3; if linked_3069 == nil { c__1927001037__auto____4 = ifn_3070.Invoke_O__O(arg_3071) } else { c__1927001037__auto____4 = linked_3069.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3068, arg_3071) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000361__6 any; var root_3072 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3072, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3074 lang.IFn; if linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3073 == nil { b__1685000361__6 = ifn_3074.Invoke_O__O(arg_3075) } else { b__1685000361__6 = linked_3073.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3072, arg_3075) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A_New_I_O_O(size__1927001038__auto____5, b__1685000361__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3085 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A_fn_class; if fncls__3085 == nil { var fncls__3085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A_fn_class = fncls__3085d; tmp3 = fncls__3085d } else { tmp3 = fncls__3085 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3086 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any; var root_3091 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3091, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3093 lang.IFn; if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = b__1685000361__6; if linked_3092 == nil { arg_3089 = ifn_3093.Invoke_O__O(arg_3094) } else { arg_3089 = linked_3092.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3091, arg_3094) }; var arg_3090 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000358); var tmp5 any; var root_3095 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3097 lang.IFn; if linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any = s__1685000359__3; if linked_3096 == nil { tmp5 = ifn_3097.Invoke_O__O(arg_3098) } else { tmp5 = linked_3096.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3095, arg_3098) }; arg_3090 = tmp4.Invoke_O__O(tmp5); if linked_3087 == nil { return ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { return linked_3087.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) } } else { var root_3099 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any; var root_3104 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3104, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3106 lang.IFn; if linked_3105 == nil { ifn_3106 = lang.IFn_Cast(root_3104) } else { ifn_3106 = nil }; var arg_3107 any = b__1685000361__6; if linked_3105 == nil { arg_3102 = ifn_3106.Invoke_O__O(arg_3107) } else { arg_3102 = linked_3105.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3104, arg_3107) }; var arg_3103 any; if linked_3100 == nil { return ifn_3101.Invoke_O_O__O(arg_3102, arg_3103) } else { return linked_3100.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3099, arg_3102, arg_3103) } } } else { var pf__4 any; var root_3108 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3110 lang.IFn; if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; var arg_3111 any = s__1685000359__3; if linked_3109 == nil { pf__4 = ifn_3110.Invoke_O__O(arg_3111) } else { pf__4 = linked_3109.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3108, arg_3111) }; var root_3112 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3112, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3114 lang.IFn; if linked_3113 == nil { ifn_3114 = lang.IFn_Cast(root_3112) } else { ifn_3114 = nil }; var arg_3115 any; var tmp6 any; var root_3117 any = A_arbace_go_check_A_const_293.GetRawRoot__O(); var linked_3118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3117, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3119 lang.IFn; if linked_3118 == nil { ifn_3119 = lang.IFn_Cast(root_3117) } else { ifn_3119 = nil }; var arg_3120 any = pf__4; if linked_3118 == nil { tmp6 = ifn_3119.Invoke_O__O(arg_3120) } else { tmp6 = linked_3118.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3117, arg_3120) }; arg_3115 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_3116 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000358); var tmp8 any; var root_3121 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3121, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3123 lang.IFn; if linked_3122 == nil { ifn_3123 = lang.IFn_Cast(root_3121) } else { ifn_3123 = nil }; var arg_3124 any = s__1685000359__3; if linked_3122 == nil { tmp8 = ifn_3123.Invoke_O__O(arg_3124) } else { tmp8 = linked_3122.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3121, arg_3124) }; arg_3116 = tmp7.Invoke_O__O(tmp8); if linked_3113 == nil { return ifn_3114.Invoke_O_O__O(arg_3115, arg_3116) } else { return linked_3113.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3112, arg_3115, arg_3116) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :488:1
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :488:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1685000361, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000361 = c__b__1685000361; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :488:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A) Invoke_O__O(self any) any { { var i__1685000360__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000360__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000360__1)); var root_3076 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3078 lang.IFn; if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = t.F_b__1685000361; var arg_3080 any; var tmp2 any; var root_3081 any = A_arbace_go_check_A_const_293.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = pf__2; if linked_3082 == nil { tmp2 = ifn_3083.Invoke_O__O(arg_3084) } else { tmp2 = linked_3082.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3081, arg_3084) }; arg_3080 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_3077 == nil { ifn_3078.Invoke_O_O__O(arg_3079, arg_3080) } else { linked_3077.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3076, arg_3079, arg_3080) }; i__1685000360__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000360__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :490:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :490:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_3139 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3139, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3141 lang.IFn
																	if linked_3140 == nil { ifn_3141 = lang.IFn_Cast(root_3139) } else { ifn_3141 = nil }; var arg_3142 any = t.F_root; var arg_3143 any = path__1; var arg_3144 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_cc); var arg_3145 any = pf__4; if linked_3140 == nil { return ifn_3141.Invoke_O_O_O_O__O(arg_3142, arg_3143, arg_3144, arg_3145) } else { return linked_3140.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3139, arg_3142, arg_3143, arg_3144, arg_3145) } } else {
//line :491:1
			return nil } }
//line :490:1
func A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A{}; t.Ctor_O(p0); return t }
//line :490:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :490:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A) Invoke_O_O__O(self, p1__1685000329_SHARP___1 any) any {


	var root_3147 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_3148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3147, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3149 lang.IFn; if linked_3148 == nil { ifn_3149 = lang.IFn_Cast(root_3147) } else { ifn_3149 = nil }; var arg_3150 any = t.F_by_path; var arg_3151 any = p1__1685000329_SHARP___1; if linked_3148 == nil { return ifn_3149.Invoke_O_O__O(arg_3150, arg_3151) } else { return linked_3148.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3147, arg_3150, arg_3151) } }
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :494:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :494:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A) Invoke_O_O__O(self, s__1685000373__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A_New_O_O_O_O_O(t.F_dir, s__1685000373__1, t.F_tdir, t.F_ts, self); var tmp2 *jrt.Class; var fncls__3270 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A_fn_class; if fncls__3270 == nil { var fncls__3270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A_fn_class = fncls__3270d; tmp2 = fncls__3270d } else { tmp2 = fncls__3270 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :494:1
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :494:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A) Ctor_O_O_O_O_O(c__dir, c__s__1685000373, c__tdir, c__ts, c__iter__1685000372 any) { t.F_dir = c__dir; t.F_s__1685000373 = c__s__1685000373; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_iter__1685000372 = c__iter__1685000372 }
//line :494:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A) Invoke_O__O(self any) any { { var s__1685000373__1 any; var t_ any = t.F_s__1685000373; t.F_s__1685000373 = nil; s__1685000373__1 = t_; for { var temp__1927000414__auto____2 any; var root_3157 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3159 lang.IFn; if linked_3158 == nil { ifn_3159 = lang.IFn_Cast(root_3157) } else { ifn_3159 = nil }; var arg_3160 any = s__1685000373__1; if linked_3158 == nil { temp__1927000414__auto____2 = ifn_3159.Invoke_O__O(arg_3160) } else { temp__1927000414__auto____2 = linked_3158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3157, arg_3160) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000373__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3161 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3163 lang.IFn; if linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any = s__1685000373__3; if linked_3162 == nil { tmp1 = ifn_3163.Invoke_O__O(arg_3164) } else { tmp1 = linked_3162.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3161, arg_3164) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3165 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3165, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3167 lang.IFn; if linked_3166 == nil { ifn_3167 = lang.IFn_Cast(root_3165) } else { ifn_3167 = nil }; var arg_3168 any = s__1685000373__3; if linked_3166 == nil { c__1927001037__auto____4 = ifn_3167.Invoke_O__O(arg_3168) } else { c__1927001037__auto____4 = linked_3166.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3165, arg_3168) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000375__6 any; var root_3169 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3169, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3171 lang.IFn; if linked_3170 == nil { ifn_3171 = lang.IFn_Cast(root_3169) } else { ifn_3171 = nil }; var arg_3172 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3170 == nil { b__1685000375__6 = ifn_3171.Invoke_O__O(arg_3172) } else { b__1685000375__6 = linked_3170.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3169, arg_3172) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A_New_O_O_O_I_O_O(t.F_dir, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000375__6); var tmp3 *jrt.Class; var fncls__3206 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A_fn_class; if fncls__3206 == nil { var fncls__3206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A_fn_class = fncls__3206d; tmp3 = fncls__3206d } else { tmp3 = fncls__3206 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3207 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3207, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3209 lang.IFn; if linked_3208 == nil { ifn_3209 = lang.IFn_Cast(root_3207) } else { ifn_3209 = nil }; var arg_3210 any; var root_3212 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3212, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3214 lang.IFn; if linked_3213 == nil { ifn_3214 = lang.IFn_Cast(root_3212) } else { ifn_3214 = nil }; var arg_3215 any = b__1685000375__6; if linked_3213 == nil { arg_3210 = ifn_3214.Invoke_O__O(arg_3215) } else { arg_3210 = linked_3213.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3212, arg_3215) }; var arg_3211 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000372); var tmp5 any; var root_3216 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3216, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3218 lang.IFn; if linked_3217 == nil { ifn_3218 = lang.IFn_Cast(root_3216) } else { ifn_3218 = nil }; var arg_3219 any = s__1685000373__3; if linked_3217 == nil { tmp5 = ifn_3218.Invoke_O__O(arg_3219) } else { tmp5 = linked_3217.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3216, arg_3219) }; arg_3211 = tmp4.Invoke_O__O(tmp5); if linked_3208 == nil { return ifn_3209.Invoke_O_O__O(arg_3210, arg_3211) } else { return linked_3208.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3207, arg_3210, arg_3211) } } else { var root_3220 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3220, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3222 lang.IFn; if linked_3221 == nil { ifn_3222 = lang.IFn_Cast(root_3220) } else { ifn_3222 = nil }; var arg_3223 any; var root_3225 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3225, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3227 lang.IFn; if linked_3226 == nil { ifn_3227 = lang.IFn_Cast(root_3225) } else { ifn_3227 = nil }; var arg_3228 any = b__1685000375__6; if linked_3226 == nil { arg_3223 = ifn_3227.Invoke_O__O(arg_3228) } else { arg_3223 = linked_3226.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3225, arg_3228) }; var arg_3224 any; if linked_3221 == nil { return ifn_3222.Invoke_O_O__O(arg_3223, arg_3224) } else { return linked_3221.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3220, arg_3223, arg_3224) } } } else { var vec__1685000385__4 any; var root_3229 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3229, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3231 lang.IFn; if linked_3230 == nil { ifn_3231 = lang.IFn_Cast(root_3229) } else { ifn_3231 = nil }; var arg_3232 any = s__1685000373__3; if linked_3230 == nil { vec__1685000385__4 = ifn_3231.Invoke_O__O(arg_3232) } else { vec__1685000385__4 = linked_3230.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3229, arg_3232) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3233 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3233, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3235 lang.IFn; _ = pf__6; if linked_3234 == nil { ifn_3235 = lang.IFn_Cast(root_3233) } else { ifn_3235 = nil }; var arg_3236 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3265 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A_fn_class
																if fncls__3265 == nil { var fncls__3265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A_fn_class = fncls__3265d; tmp7 = fncls__3265d } else { tmp7 = fncls__3265 }; arg_3236 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :494:1
	var arg_3237 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000372); var tmp9 any; var root_3266 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3266, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3268 lang.IFn; if linked_3267 == nil { ifn_3268 = lang.IFn_Cast(root_3266) } else { ifn_3268 = nil }; var arg_3269 any = s__1685000373__3; if linked_3267 == nil { tmp9 = ifn_3268.Invoke_O__O(arg_3269) } else { tmp9 = linked_3267.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3266, arg_3269) }; arg_3237 = tmp8.Invoke_O__O(tmp9); if linked_3234 == nil { return ifn_3235.Invoke_O_O__O(arg_3236, arg_3237) } else { return linked_3234.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3233, arg_3236, arg_3237) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :494:1
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :494:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A) Ctor_O_O_O_I_O_O(c__dir, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000375 any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000375 = c__b__1685000375 }
//line :494:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A) Invoke_O__O(self any) any { { var i__1685000374__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000374__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000379__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000374__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3173 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3175 lang.IFn; _ = pf__4; if linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any = t.F_b__1685000375; var arg_3177 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3205 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A_fn_class
																		if fncls__3205 == nil { var fncls__3205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A_fn_class = fncls__3205d; tmp3 = fncls__3205d } else { tmp3 = fncls__3205 }; arg_3177 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :494:1
	if linked_3174 == nil { ifn_3175.Invoke_O_O__O(arg_3176, arg_3177) } else { linked_3174.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3173, arg_3176, arg_3177) }; i__1685000374__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000374__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :495:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :495:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_3178 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3178, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3180 lang.IFn; if linked_3179 == nil { ifn_3180 = lang.IFn_Cast(root_3178) } else { ifn_3180 = nil }; var arg_3181 any; var or__1927000174__auto____3 any; var root_3184 any = A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_3185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3184, A_arbace_go_check_result_of_A_fn_class); var ifn_3186 lang.IFn; if linked_3185 == nil { ifn_3186 = lang.IFn_Cast(root_3184) } else { ifn_3186 = nil }; var arg_3187 any; var root_3188 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_3189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3188, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3190 lang.IFn; if linked_3189 == nil { ifn_3190 = lang.IFn_Cast(root_3188) } else { ifn_3190 = nil }; var arg_3191 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3191 = t_; var arg_3192 any = t.F_path; var arg_3193 any; var arg_3194 any = lang.PersistentVector_EMPTY.Ref(); if linked_3189 == nil { arg_3187 = ifn_3190.Invoke_O_O_O_O__O(arg_3191, arg_3192, arg_3193, arg_3194) } else { arg_3187 = linked_3189.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3188, arg_3191, arg_3192, arg_3193, arg_3194) }; if linked_3185 == nil { or__1927000174__auto____3 = ifn_3186.Invoke_O__O(arg_3187) } else { or__1927000174__auto____3 = linked_3185.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3184, arg_3187) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3181 = or__1927000174__auto____3 } else { arg_3181 = A_arbace_go_check_A_const_304 }; var arg_3182 any = A_arbace_go_check_A_const_110; var arg_3183 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp3 any; var root_3195 any = A_arbace_go_check_A_const_299.GetRawRoot__O(); var linked_3196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3195, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3197 lang.IFn
																					if linked_3196 == nil { ifn_3197 = lang.IFn_Cast(root_3195) } else { ifn_3197 = nil }; var arg_3198 any = t.F_tdir; var arg_3199 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3199 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3196 == nil { tmp3 = ifn_3197.Invoke_O_O__O(arg_3198, arg_3199) } else { tmp3 = linked_3196.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3195, arg_3198, arg_3199) }; arg_3183 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :496:1
		if linked_3179 == nil { tmp1 = ifn_3180.Invoke_O_O_O__O(arg_3181, arg_3182, arg_3183) } else { tmp1 = linked_3179.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3178, arg_3181, arg_3182, arg_3183) } }
//line :495:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3200 any = A_arbace_go_check_A_const_298.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, A_arbace_go_check_error_result_A_fn_class); var ifn_3202 lang.IFn


		if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3203 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3204 any = ex__3; if linked_3201 == nil { tmp1 = ifn_3202.Invoke_O_O__O(arg_3203, arg_3204) } else { tmp1 = linked_3201.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3200, arg_3203, arg_3204) } } }; return tmp1 }
//line :495:1
func A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :495:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :495:1
func (t *A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3238 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3238, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3240 lang.IFn; if linked_3239 == nil { ifn_3240 = lang.IFn_Cast(root_3238) } else { ifn_3240 = nil }; var arg_3241 any; var or__1927000174__auto____3 any; var root_3244 any = A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_3245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3244, A_arbace_go_check_result_of_A_fn_class); var ifn_3246 lang.IFn; if linked_3245 == nil { ifn_3246 = lang.IFn_Cast(root_3244) } else { ifn_3246 = nil }; var arg_3247 any; var root_3248 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_3249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3248, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3250 lang.IFn; if linked_3249 == nil { ifn_3250 = lang.IFn_Cast(root_3248) } else { ifn_3250 = nil }; var arg_3251 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3251 = t_; var arg_3252 any = t.F_path; var arg_3253 any; var arg_3254 any = lang.PersistentVector_EMPTY.Ref(); if linked_3249 == nil { arg_3247 = ifn_3250.Invoke_O_O_O_O__O(arg_3251, arg_3252, arg_3253, arg_3254) } else { arg_3247 = linked_3249.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3248, arg_3251, arg_3252, arg_3253, arg_3254) }; if linked_3245 == nil { or__1927000174__auto____3 = ifn_3246.Invoke_O__O(arg_3247) } else { or__1927000174__auto____3 = linked_3245.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3244, arg_3247) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3241 = or__1927000174__auto____3 } else { arg_3241 = A_arbace_go_check_A_const_305 }; var arg_3242 any = A_arbace_go_check_A_const_110; var arg_3243 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp3 any; var root_3255 any = A_arbace_go_check_A_const_299.GetRawRoot__O(); var linked_3256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3255, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3257 lang.IFn
																			if linked_3256 == nil { ifn_3257 = lang.IFn_Cast(root_3255) } else { ifn_3257 = nil }; var arg_3258 any = t.F_tdir; var arg_3259 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3259 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3256 == nil { tmp3 = ifn_3257.Invoke_O_O__O(arg_3258, arg_3259) } else { tmp3 = linked_3256.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3255, arg_3258, arg_3259) }; arg_3243 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :496:1
		if linked_3239 == nil { tmp1 = ifn_3240.Invoke_O_O_O__O(arg_3241, arg_3242, arg_3243) } else { tmp1 = linked_3239.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3238, arg_3241, arg_3242, arg_3243) } }
//line :495:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3260 any = A_arbace_go_check_A_const_298.GetRawRoot__O(); var linked_3261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3260, A_arbace_go_check_error_result_A_fn_class); var ifn_3262 lang.IFn


		if linked_3261 == nil { ifn_3262 = lang.IFn_Cast(root_3260) } else { ifn_3262 = nil }; var arg_3263 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3263 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3264 any = ex__3; if linked_3261 == nil { tmp1 = ifn_3262.Invoke_O_O__O(arg_3263, arg_3264) } else { tmp1 = linked_3261.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3260, arg_3263, arg_3264) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :502:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3288 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3290 lang.IFn; if


	linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = A_arbace_go_check_A_const_297; var arg_3292 any = results__1; if linked_3289 == nil { rs__3 = ifn_3290.Invoke_O_O__O(arg_3291, arg_3292) } else { rs__3 = linked_3289.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3288, arg_3291, arg_3292) }; var sum__4 any; var tmp1 any = /*line :502:1*/A_arbace_go_check_summarize_sum__1685000400_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3304 *jrt.Class = A_arbace_go_check_summarize_sum__1685000400_A_fn_class; if



	fncls__3304 == nil { var fncls__3304d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_summarize_sum__1685000400_A_fn_class = fncls__3304d; tmp2 = fncls__3304d } else { tmp2 = fncls__3304 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :502:1*/A_arbace_go_check_summarize_msum__1685000402_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__3317 *jrt.Class = A_arbace_go_check_summarize_msum__1685000402_A_fn_class; if




	fncls__3317 == nil { var fncls__3317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_go_check_summarize_msum__1685000402_A_fn_class = fncls__3317d; tmp4 = fncls__3317d } else { tmp4 = fncls__3317 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_277; var tmp6 any = A_arbace_go_check_A_const_307; var tmp7 any = /*line :502:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_308; var tmp9 any = A_arbace_go_check_A_const_309; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_82); var tmp11 any = A_arbace_go_check_A_const_161; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_161); var tmp13 any = A_arbace_go_check_A_const_147; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_152); var tmp15 any = A_arbace_go_check_A_const_150; var tmp16 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_150); var tmp17 any = A_arbace_go_check_A_const_142; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_153))); var tmp19 any = A_arbace_go_check_A_const_225; var tmp20 lang.IFn = lang.IFn_Cast(sum__4); var tmp21 any = A_arbace_go_check_summarize_fn__1685000404_A_New(); var tmp22 *jrt.Class; var fncls__3400 *jrt.Class = A_arbace_go_check_summarize_fn__1685000404_A_fn_class; if












	fncls__3400 == nil { var fncls__3400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_go_check_summarize_fn__1685000404_A_fn_class = fncls__3400d; tmp22 = fncls__3400d } else { tmp22 = fncls__3400 }; var tmp23 any = /*line :502:1*/tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)); var tmp24 any = A_arbace_go_check_A_const_310; var tmp25 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_228); var tmp26 any = A_arbace_go_check_A_const_311; var tmp27 any; var root_3318 any = A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3318, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3320 lang.IFn; if














	linked_3319 == nil { ifn_3320 = lang.IFn_Cast(root_3318) } else { ifn_3320 = nil }; var arg_3321 any; var tmp28 any = A_arbace_go_check_summarize_fn__1685000406_A_New(); var tmp29 *jrt.Class; var fncls__3323 *jrt.Class = A_arbace_go_check_summarize_fn__1685000406_A_fn_class; if fncls__3323 == nil { var fncls__3323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_check_summarize_fn__1685000406_A_fn_class = fncls__3323d; tmp29 = fncls__3323d } else { tmp29 = fncls__3323 }; arg_3321 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_3322 any = rs__3; if linked_3319 == nil { tmp27 = ifn_3320.Invoke_O_O__O(arg_3321, arg_3322) } else { tmp27 = linked_3319.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3318, arg_3321, arg_3322) }; var tmp30 any = /*line :502:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref(); var tmp31 any = A_arbace_go_check_A_const_313; var tmp32 any; var root_3324 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_3325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3324, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3326 lang.IFn; if















	linked_3325 == nil { ifn_3326 = lang.IFn_Cast(root_3324) } else { ifn_3326 = nil }; var arg_3327 any; var root_3328 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3330 lang.IFn; if linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any; var tmp33 any = A_arbace_go_check_summarize_fn__1685000408_A_New(); var tmp34 *jrt.Class; var fncls__3333 *jrt.Class = A_arbace_go_check_summarize_fn__1685000408_A_fn_class; if fncls__3333 == nil { var fncls__3333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_summarize_fn__1685000408_A_fn_class = fncls__3333d; tmp34 = fncls__3333d } else { tmp34 = fncls__3333 }; arg_3331 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3332 any = rs__3; if linked_3329 == nil { arg_3327 = ifn_3330.Invoke_O_O__O(arg_3331, arg_3332) } else { arg_3327 = linked_3329.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3328, arg_3331, arg_3332) }; if linked_3325 == nil { tmp32 = ifn_3326.Invoke_O__O(arg_3327) } else { tmp32 = linked_3325.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3324, arg_3327) }; var tmp35 any = tmp32; var tmp36 any = A_arbace_go_check_A_const_314; var tmp37 any = A_arbace_go_check_A_const_137; var tmp38 any; var root_3334 any = /*line :502:1*/A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3336 lang.IFn; if
















	linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = lang.IFn_Cast(A_arbace_go_check_A_const_315.GetRawRoot__O()).Invoke__O(); var arg_3338 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_137); if linked_3335 == nil { tmp38 = ifn_3336.Invoke_O_O__O(arg_3337, arg_3338) } else { tmp38 = linked_3335.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3334, arg_3337, arg_3338) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_go_check_A_const_162; var tmp41 any; var root_3342 any = /*line :502:1*/A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3342, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3344 lang.IFn; if

















	linked_3343 == nil { ifn_3344 = lang.IFn_Cast(root_3342) } else { ifn_3344 = nil }; var arg_3345 any = lang.IFn_Cast(A_arbace_go_check_A_const_315.GetRawRoot__O()).Invoke__O(); var arg_3346 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_162); if linked_3343 == nil { tmp41 = ifn_3344.Invoke_O_O__O(arg_3345, arg_3346) } else { tmp41 = linked_3343.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3342, arg_3345, arg_3346) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_go_check_A_const_163; var tmp44 any; var root_3350 any = /*line :502:1*/A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3350, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3352 lang.IFn; if


















	linked_3351 == nil { ifn_3352 = lang.IFn_Cast(root_3350) } else { ifn_3352 = nil }; var arg_3353 any = lang.IFn_Cast(A_arbace_go_check_A_const_315.GetRawRoot__O()).Invoke__O(); var arg_3354 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_163); if linked_3351 == nil { tmp44 = ifn_3352.Invoke_O_O__O(arg_3353, arg_3354) } else { tmp44 = linked_3351.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3350, arg_3353, arg_3354) }; var tmp45 any = tmp44; var tmp46 any = A_arbace_go_check_A_const_316; var tmp47 any; var root_3358 any = /*line :502:1*/A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3360 lang.IFn; if



















	linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = lang.IFn_Cast(A_arbace_go_check_A_const_315.GetRawRoot__O()).Invoke__O(); var arg_3362 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_154); if linked_3359 == nil { tmp47 = ifn_3360.Invoke_O_O__O(arg_3361, arg_3362) } else { tmp47 = linked_3359.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3358, arg_3361, arg_3362) }; var tmp48 any = tmp47; var tmp49 any = A_arbace_go_check_A_const_229; var tmp50 any = A_arbace_go_check_A_const_307; var tmp51 any; var root_3366 any = /*line :502:1*/A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3366, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3368 lang.IFn; if




















	linked_3367 == nil { ifn_3368 = lang.IFn_Cast(root_3366) } else { ifn_3368 = nil }; var arg_3369 any; var tmp52 any = A_arbace_go_check_summarize_fn__1685000410_A_New(); var tmp53 *jrt.Class; var fncls__3376 *jrt.Class = A_arbace_go_check_summarize_fn__1685000410_A_fn_class; if fncls__3376 == nil { var fncls__3376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_summarize_fn__1685000410_A_fn_class = fncls__3376d; tmp53 = fncls__3376d } else { tmp53 = fncls__3376 }; arg_3369 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var arg_3370 any = rs__3; if linked_3367 == nil { tmp51 = ifn_3368.Invoke_O_O__O(arg_3369, arg_3370) } else { tmp51 = linked_3367.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3366, arg_3369, arg_3370) }; var tmp54 any = /*line :502:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp51)).Ref(); var tmp55 any = A_arbace_go_check_A_const_318; var tmp56 lang.IFn = lang.IFn_Cast(sum__4); var tmp57 any = A_arbace_go_check_summarize_fn__1685000412_A_New(); var tmp58 *jrt.Class; var fncls__3407 *jrt.Class = A_arbace_go_check_summarize_fn__1685000412_A_fn_class; if





















	fncls__3407 == nil { var fncls__3407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_summarize_fn__1685000412_A_fn_class = fncls__3407d; tmp58 = fncls__3407d } else { tmp58 = fncls__3407 }; var tmp59 any = /*line :502:1*/tmp56.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil)); var tmp60 any = A_arbace_go_check_A_const_319; var tmp61 any; var root_3377 any = A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3377, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3379 lang.IFn; if






















	linked_3378 == nil { ifn_3379 = lang.IFn_Cast(root_3377) } else { ifn_3379 = nil }; var arg_3380 any; var tmp62 any = A_arbace_go_check_summarize_fn__1685000414_A_New(); var tmp63 *jrt.Class; var fncls__3391 *jrt.Class = A_arbace_go_check_summarize_fn__1685000414_A_fn_class; if fncls__3391 == nil { var fncls__3391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_check_summarize_fn__1685000414_A_fn_class = fncls__3391d; tmp63 = fncls__3391d } else { tmp63 = fncls__3391 }; arg_3380 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil); var arg_3381 any = rs__3; if linked_3378 == nil { tmp61 = ifn_3379.Invoke_O_O__O(arg_3380, arg_3381) } else { tmp61 = linked_3378.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3377, arg_3380, arg_3381) }; var tmp64 any = /*line :502:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, tmp40, tmp42, tmp43, tmp45, tmp46, tmp48, tmp49, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp54, tmp55, tmp59, tmp60, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp61)).Ref())))); var tmp65 any = A_arbace_go_check_A_const_142; var tmp66 any; var root_3392 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3392, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3394 lang.IFn; if























	linked_3393 == nil { ifn_3394 = lang.IFn_Cast(root_3392) } else { ifn_3394 = nil }; var arg_3395 any = lang.IFn_Cast(A_arbace_go_check_A_const_315.GetRawRoot__O()).Invoke__O(); var arg_3396 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_142); if linked_3393 == nil { tmp66 = ifn_3394.Invoke_O_O__O(arg_3395, arg_3396) } else { tmp66 = linked_3393.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3392, arg_3395, arg_3396) }; return /*line :502:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp18, tmp19, tmp23, tmp24, tmp25, tmp26, tmp30, tmp31, tmp35, tmp36, tmp64, tmp65, tmp66)) }



func A_arbace_go_check_summarize_sum__1685000400_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000400_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000400_A{}; t.Ctor_O(p0); return t }
//line :506:1
func (t *A_arbace_go_check_summarize_sum__1685000400_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :506:1
func (t *A_arbace_go_check_summarize_sum__1685000400_A) Invoke_O_O__O(self, k__1 any) any { var root_3293 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3293, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3295 lang.IFn; if linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3297 any = A_arbace_go_check_A_const_22; var arg_3298 any; var root_3299 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var linked_3300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3299, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3301 lang.IFn; if linked_3300 == nil { ifn_3301 = lang.IFn_Cast(root_3299) } else { ifn_3301 = nil }; var arg_3302 any = k__1; var arg_3303 any = t.F_rs; if linked_3300 == nil { arg_3298 = ifn_3301.Invoke_O_O__O(arg_3302, arg_3303) } else { arg_3298 = linked_3300.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3299, arg_3302, arg_3303) }; if linked_3294 == nil { return ifn_3295.Invoke_O_O_O__O(arg_3296, arg_3297, arg_3298) } else { return linked_3294.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3293, arg_3296, arg_3297, arg_3298) } }
func A_arbace_go_check_summarize_msum__1685000402_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000402_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000402_A{}; t.Ctor_O(p0); return t }
//line :507:1
func (t *A_arbace_go_check_summarize_msum__1685000402_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :507:1
func (t *A_arbace_go_check_summarize_msum__1685000402_A) Invoke_O_O__O(self, k__1 any) any { var root_3305 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3305, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3307 lang.IFn; if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var arg_3309 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3310 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3311 any; var root_3312 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_3313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3312, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3314 lang.IFn; if linked_3313 == nil { ifn_3314 = lang.IFn_Cast(root_3312) } else { ifn_3314 = nil }; var arg_3315 any = k__1; var arg_3316 any = t.F_rs; if linked_3313 == nil { arg_3311 = ifn_3314.Invoke_O_O__O(arg_3315, arg_3316) } else { arg_3311 = linked_3313.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3312, arg_3315, arg_3316) }; if linked_3306 == nil { return ifn_3307.Invoke_O_O_O_O__O(arg_3308, arg_3309, arg_3310, arg_3311) } else { return linked_3306.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3305, arg_3308, arg_3309, arg_3310, arg_3311) } }







func A_arbace_go_check_summarize_fn__1685000404_A_New() *A_arbace_go_check_summarize_fn__1685000404_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000404_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_go_check_summarize_fn__1685000404_A) Ctor() {}
//line :515:1
func (t *A_arbace_go_check_summarize_fn__1685000404_A) Invoke_O_O__O(self, p1__1685000394_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_225.Invoke_O__O(p1__1685000394_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000406_A_New() *A_arbace_go_check_summarize_fn__1685000406_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000406_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_go_check_summarize_fn__1685000406_A) Ctor() {}
//line :517:1
func (t *A_arbace_go_check_summarize_fn__1685000406_A) Invoke_O_O__O(self, p1__1685000395_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_287.Invoke_O__O(p1__1685000395_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000395_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000408_A_New() *A_arbace_go_check_summarize_fn__1685000408_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000408_A{}; t.Ctor(); return t }
//line :518:1
func (t *A_arbace_go_check_summarize_fn__1685000408_A) Ctor() {}
//line :518:1
func (t *A_arbace_go_check_summarize_fn__1685000408_A) Invoke_O_O__O(self, p1__1685000396_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_287.Invoke_O__O(p1__1685000396_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000396_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_110.Invoke_O__O(p1__1685000396_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000410_A_New() *A_arbace_go_check_summarize_fn__1685000410_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000410_A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_go_check_summarize_fn__1685000410_A) Ctor() {}
//line :523:1
func (t *A_arbace_go_check_summarize_fn__1685000410_A) Invoke_O_O__O(self, p1__1685000397_SHARP___1 any) any { var root_3371 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3373 lang.IFn; if linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = p1__1685000397_SHARP___1; var arg_3375 any = A_arbace_go_check_A_const_317; if linked_3372 == nil { return ifn_3373.Invoke_O_O__O(arg_3374, arg_3375) } else { return linked_3372.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3371, arg_3374, arg_3375) } }
func A_arbace_go_check_summarize_fn__1685000412_A_New() *A_arbace_go_check_summarize_fn__1685000412_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000412_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_go_check_summarize_fn__1685000412_A) Ctor() {}
//line :524:1
func (t *A_arbace_go_check_summarize_fn__1685000412_A) Invoke_O_O__O(self, p1__1685000398_SHARP___1 any) any { var root_3401 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3403 lang.IFn; if linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; var arg_3404 any = p1__1685000398_SHARP___1; var arg_3405 any = A_arbace_go_check_A_const_322; var arg_3406 any = A_arbace_go_check_A_const_22; if linked_3402 == nil { return ifn_3403.Invoke_O_O_O__O(arg_3404, arg_3405, arg_3406) } else { return linked_3402.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3401, arg_3404, arg_3405, arg_3406) } }
func A_arbace_go_check_summarize_fn__1685000414_A_New() *A_arbace_go_check_summarize_fn__1685000414_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000414_A{}; t.Ctor(); return t }
//line :525:1
func (t *A_arbace_go_check_summarize_fn__1685000414_A) Ctor() {}
//line :525:1
func (t *A_arbace_go_check_summarize_fn__1685000414_A) Invoke_O_O__O(self, p1__1685000399_SHARP___1 any) any { var root_3382 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3382, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3384 lang.IFn; if linked_3383 == nil { ifn_3384 = lang.IFn_Cast(root_3382) } else { ifn_3384 = nil }; var arg_3385 any; var root_3386 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3386, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3388 lang.IFn; if linked_3387 == nil { ifn_3388 = lang.IFn_Cast(root_3386) } else { ifn_3388 = nil }; var arg_3389 any = p1__1685000399_SHARP___1; var arg_3390 any = A_arbace_go_check_A_const_321; if linked_3387 == nil { arg_3385 = ifn_3388.Invoke_O_O__O(arg_3389, arg_3390) } else { arg_3385 = linked_3387.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3386, arg_3389, arg_3390) }; if linked_3383 == nil { return ifn_3384.Invoke_O__O(arg_3385) } else { return linked_3383.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3382, arg_3385) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :528:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :528:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000417__1685000423_A_New(); var tmp2 *jrt.Class; var fncls__3493 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000417__1685000423_A_fn_class; if


	fncls__3493 == nil { var fncls__3493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_report_errors_iter__1685000417__1685000423_A_fn_class = fncls__3493d; tmp2 = fncls__3493d } else { tmp2 = fncls__3493 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :531:1
func A_arbace_go_check_report_errors_iter__1685000417__1685000423_A_New() *A_arbace_go_check_report_errors_iter__1685000417__1685000423_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000417__1685000423_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_A) Ctor() {}
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_A) Invoke_O_O__O(self, s__1685000418__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A_New_O_O(self, s__1685000418__1); var tmp2 *jrt.Class; var fncls__3492 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A_fn_class; if fncls__3492 == nil { var fncls__3492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A_fn_class = fncls__3492d; tmp2 = fncls__3492d } else { tmp2 = fncls__3492 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :531:1
func A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A{}; t.Ctor_O_O(p0, p1); return t }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A) Ctor_O_O(c__iter__1685000417, c__s__1685000418 any) { t.F_iter__1685000417 = c__iter__1685000417; t.F_s__1685000418 = c__s__1685000418 }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A) Invoke_O__O(self any) any { { var s__1685000418__1 any; var t_ any = t.F_s__1685000418; t.F_s__1685000418 = nil; s__1685000418__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3408 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3410 lang.IFn; if linked_3409 == nil { ifn_3410 = lang.IFn_Cast(root_3408) } else { ifn_3410 = nil }; var arg_3411 any = s__1685000418__1; if linked_3409 == nil { temp__1927000414__auto____2 = ifn_3410.Invoke_O__O(arg_3411) } else { temp__1927000414__auto____2 = linked_3409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3408, arg_3411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3412 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3412, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3414 lang.IFn; if linked_3413 == nil { ifn_3414 = lang.IFn_Cast(root_3412) } else { ifn_3414 = nil }; var arg_3415 any = xs__1927001018__auto____3; if linked_3413 == nil { r__4 = ifn_3414.Invoke_O__O(arg_3415) } else { r__4 = linked_3413.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3412, arg_3415) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3474 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A_fn_class; if fncls__3474 == nil { var fncls__3474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A_fn_class = fncls__3474d; tmp2 = fncls__3474d } else { tmp2 = fncls__3474 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3475 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3477 lang.IFn; if linked_3476 == nil { ifn_3477 = lang.IFn_Cast(root_3475) } else { ifn_3477 = nil }; var arg_3478 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_225.Invoke_O__O(r__4)); if linked_3476 == nil { fs__1927001036__auto____6 = ifn_3477.Invoke_O__O(arg_3478) } else { fs__1927001036__auto____6 = linked_3476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3475, arg_3478) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3479 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3479, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3481 lang.IFn; if linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any = fs__1927001036__auto____6; var arg_3483 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000417); var tmp4 any; var root_3484 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3484, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3486 lang.IFn; if linked_3485 == nil { ifn_3486 = lang.IFn_Cast(root_3484) } else { ifn_3486 = nil }; var arg_3487 any = s__1685000418__1; if linked_3485 == nil { tmp4 = ifn_3486.Invoke_O__O(arg_3487) } else { tmp4 = linked_3485.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3484, arg_3487) }; arg_3483 = tmp3.Invoke_O__O(tmp4); if linked_3480 == nil { return ifn_3481.Invoke_O_O__O(arg_3482, arg_3483) } else { return linked_3480.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3479, arg_3482, arg_3483) } } else { var tmp5 any; var root_3488 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3490 lang.IFn; if linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any = s__1685000418__1; if linked_3489 == nil { tmp5 = ifn_3490.Invoke_O__O(arg_3491) } else { tmp5 = linked_3489.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3488, arg_3491) }; s__1685000418__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :531:1
func A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A{}; t.Ctor_O(p0); return t }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A) Invoke_O_O__O(self, s__1685000420__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A_New_O_O_O(self, t.F_r, s__1685000420__1); var tmp2 *jrt.Class; var fncls__3473 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A_fn_class; if fncls__3473 == nil { var fncls__3473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A_fn_class = fncls__3473d; tmp2 = fncls__3473d } else { tmp2 = fncls__3473 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :531:1
func A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A) Ctor_O_O_O(c__iter__1685000419, c__r, c__s__1685000420 any) { t.F_iter__1685000419 = c__iter__1685000419; t.F_r = c__r; t.F_s__1685000420 = c__s__1685000420 }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A) Invoke_O__O(self any) any { { var s__1685000420__1 any; var t_ any = t.F_s__1685000420; t.F_s__1685000420 = nil; s__1685000420__1 = t_; for { var temp__1927000414__auto____2 any; var root_3416 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3418 lang.IFn; if linked_3417 == nil { ifn_3418 = lang.IFn_Cast(root_3416) } else { ifn_3418 = nil }; var arg_3419 any = s__1685000420__1; if linked_3417 == nil { temp__1927000414__auto____2 = ifn_3418.Invoke_O__O(arg_3419) } else { temp__1927000414__auto____2 = linked_3417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3416, arg_3419) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000420__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3420 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3420, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3422 lang.IFn; if linked_3421 == nil { ifn_3422 = lang.IFn_Cast(root_3420) } else { ifn_3422 = nil }; var arg_3423 any = s__1685000420__3; if linked_3421 == nil { tmp1 = ifn_3422.Invoke_O__O(arg_3423) } else { tmp1 = linked_3421.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3420, arg_3423) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3424 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3424, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3426 lang.IFn; if linked_3425 == nil { ifn_3426 = lang.IFn_Cast(root_3424) } else { ifn_3426 = nil }; var arg_3427 any = s__1685000420__3; if linked_3425 == nil { c__1927001037__auto____4 = ifn_3426.Invoke_O__O(arg_3427) } else { c__1927001037__auto____4 = linked_3425.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3424, arg_3427) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000422__6 any; var root_3428 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3428, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3430 lang.IFn; if linked_3429 == nil { ifn_3430 = lang.IFn_Cast(root_3428) } else { ifn_3430 = nil }; var arg_3431 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3429 == nil { b__1685000422__6 = ifn_3430.Invoke_O__O(arg_3431) } else { b__1685000422__6 = linked_3429.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3428, arg_3431) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A_New_O_O_I_O(b__1685000422__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3437 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A_fn_class; if fncls__3437 == nil { var fncls__3437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A_fn_class = fncls__3437d; tmp3 = fncls__3437d } else { tmp3 = fncls__3437 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3438 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3438, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3440 lang.IFn; if linked_3439 == nil { ifn_3440 = lang.IFn_Cast(root_3438) } else { ifn_3440 = nil }; var arg_3441 any; var root_3443 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3445 lang.IFn; if linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = b__1685000422__6; if linked_3444 == nil { arg_3441 = ifn_3445.Invoke_O__O(arg_3446) } else { arg_3441 = linked_3444.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3443, arg_3446) }; var arg_3442 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000419); var tmp5 any; var root_3447 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3449 lang.IFn; if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any = s__1685000420__3; if linked_3448 == nil { tmp5 = ifn_3449.Invoke_O__O(arg_3450) } else { tmp5 = linked_3448.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3447, arg_3450) }; arg_3442 = tmp4.Invoke_O__O(tmp5); if linked_3439 == nil { return ifn_3440.Invoke_O_O__O(arg_3441, arg_3442) } else { return linked_3439.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3438, arg_3441, arg_3442) } } else { var root_3451 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3453 lang.IFn; if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any; var root_3456 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3456, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3458 lang.IFn; if linked_3457 == nil { ifn_3458 = lang.IFn_Cast(root_3456) } else { ifn_3458 = nil }; var arg_3459 any = b__1685000422__6; if linked_3457 == nil { arg_3454 = ifn_3458.Invoke_O__O(arg_3459) } else { arg_3454 = linked_3457.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3456, arg_3459) }; var arg_3455 any; if linked_3452 == nil { return ifn_3453.Invoke_O_O__O(arg_3454, arg_3455) } else { return linked_3452.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3451, arg_3454, arg_3455) } } } else { var e__4 any; var root_3460 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3460, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3462 lang.IFn; if linked_3461 == nil { ifn_3462 = lang.IFn_Cast(root_3460) } else { ifn_3462 = nil }; var arg_3463 any = s__1685000420__3; if linked_3461 == nil { e__4 = ifn_3462.Invoke_O__O(arg_3463) } else { e__4 = linked_3461.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3460, arg_3463) }; var root_3464 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3464, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3466 lang.IFn; if linked_3465 == nil { ifn_3466 = lang.IFn_Cast(root_3464) } else { ifn_3466 = nil }; var arg_3467 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_23, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_288.Invoke_O__O(e__4))).Ref(); var arg_3468 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000419); var tmp7 any; var root_3469 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3469, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3471 lang.IFn; if linked_3470 == nil { ifn_3471 = lang.IFn_Cast(root_3469) } else { ifn_3471 = nil }; var arg_3472 any = s__1685000420__3; if linked_3470 == nil { tmp7 = ifn_3471.Invoke_O__O(arg_3472) } else { tmp7 = linked_3470.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3469, arg_3472) }; arg_3468 = tmp6.Invoke_O__O(tmp7); if linked_3465 == nil { return ifn_3466.Invoke_O_O__O(arg_3467, arg_3468) } else { return linked_3465.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3464, arg_3467, arg_3468) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :531:1
func A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A) Ctor_O_O_I_O(c__b__1685000422, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000422 = c__b__1685000422; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :531:1
func (t *A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A) Invoke_O__O(self any) any { { var i__1685000421__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000421__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000421__1)); var root_3432 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3432, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3434 lang.IFn; if linked_3433 == nil { ifn_3434 = lang.IFn_Cast(root_3432) } else { ifn_3434 = nil }; var arg_3435 any = t.F_b__1685000422; var arg_3436 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_23, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_288.Invoke_O__O(e__2))).Ref(); if linked_3433 == nil { ifn_3434.Invoke_O_O__O(arg_3435, arg_3436) } else { linked_3433.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3432, arg_3435, arg_3436) }; i__1685000421__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000421__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :536:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000435__3 any; var root_3494 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3494, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3496 lang.IFn; if



	linked_3495 == nil { ifn_3496 = lang.IFn_Cast(root_3494) } else { ifn_3496 = nil }; var arg_3497 any = forms__0; if linked_3495 == nil { map__1685000435__3 = ifn_3496.Invoke_O__O(arg_3497) } else { map__1685000435__3 = linked_3495.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3494, arg_3497) }; var map__1685000435__4 any; if lang.ISeq_InstanceOf(map__1685000435__3) { var tmp1 any; var root_3498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3500 lang.IFn; if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = map__1685000435__3; if linked_3499 == nil { tmp1 = ifn_3500.Invoke_O__O(arg_3501) } else { tmp1 = linked_3499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3498, arg_3501) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3502 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3502, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3504 lang.IFn; if linked_3503 == nil { ifn_3504 = lang.IFn_Cast(root_3502) } else { ifn_3504 = nil }; var arg_3505 any = map__1685000435__3; if linked_3503 == nil { tmp2 = ifn_3504.Invoke_O__O(arg_3505) } else { tmp2 = linked_3503.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3502, arg_3505) }; map__1685000435__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3506 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3506, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3508 lang.IFn; if linked_3507 == nil { ifn_3508 = lang.IFn_Cast(root_3506) } else { ifn_3508 = nil }; var arg_3509 any = map__1685000435__3; if linked_3507 == nil { tmp3 = ifn_3508.Invoke_O__O(arg_3509) } else { tmp3 = linked_3507.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3506, arg_3509) }; if jrt.J2g_Truth(tmp3) { var root_3510 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3510, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3512 lang.IFn; if linked_3511 == nil { ifn_3512 = lang.IFn_Cast(root_3510) } else { ifn_3512 = nil }; var arg_3513 any = map__1685000435__3; if linked_3511 == nil { map__1685000435__4 = ifn_3512.Invoke_O__O(arg_3513) } else { map__1685000435__4 = linked_3511.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3510, arg_3513) } } else { map__1685000435__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000435__4 = map__1685000435__3 }; var package__5 any = /*line :536:1*/lang.RT_Get_O_O__O_NoInit(map__1685000435__4, A_arbace_go_check_A_const_109); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000435__4, A_arbace_go_check_A_const_70); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000435__4, A_arbace_go_check_A_const_121); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_324.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_325; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_111.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_110; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_110.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_107 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_70; var tmp10 any; var root_3520 any = /*line :536:1*/A_arbace_go_check_A_const_326.GetRawRoot__O(); var linked_3521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3520, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3522 lang.IFn; if





	linked_3521 == nil { ifn_3522 = lang.IFn_Cast(root_3520) } else { ifn_3522 = nil }; var arg_3523 any = name__6; if linked_3521 == nil { tmp10 = ifn_3522.Invoke_O__O(arg_3523) } else { tmp10 = linked_3521.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3520, arg_3523) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_111; var tmp13 any = A_arbace_go_check_A_const_81; var tmp14 any = A_arbace_go_check_A_const_220; var tmp15 any; var root_3524 any = /*line :536:1*/A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3524, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3526 lang.IFn; if






	linked_3525 == nil { ifn_3526 = lang.IFn_Cast(root_3524) } else { ifn_3526 = nil }; var arg_3527 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000437_A_New(); var tmp17 *jrt.Class; var fncls__3541 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000437_A_fn_class; if fncls__3541 == nil { var fncls__3541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_check_forms_source_fn__1685000437_A_fn_class = fncls__3541d; tmp17 = fncls__3541d } else { tmp17 = fncls__3541 }; arg_3527 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3528 any = forms__0; if linked_3525 == nil { tmp15 = ifn_3526.Invoke_O_O__O(arg_3527, arg_3528) } else { tmp15 = linked_3525.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3524, arg_3527, arg_3528) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_121; var tmp20 any; var root_3542 any = /*line :536:1*/A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_3543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3542, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3544 lang.IFn; if







	linked_3543 == nil { ifn_3544 = lang.IFn_Cast(root_3542) } else { ifn_3544 = nil }; var arg_3545 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000439__1685000443_A_New(); var tmp22 *jrt.Class; var fncls__3616 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000439__1685000443_A_fn_class; if fncls__3616 == nil { var fncls__3616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_go_check_forms_source_iter__1685000439__1685000443_A_fn_class = fncls__3616d; tmp22 = fncls__3616d } else { tmp22 = fncls__3616 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3545 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3543 == nil { tmp20 = ifn_3544.Invoke_O__O(arg_3545) } else { tmp20 = linked_3543.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3542, arg_3545) }; return /*line :536:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000437_A_New() *A_arbace_go_check_forms_source_fn__1685000437_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000437_A{}; t.Ctor(); return t }
//line :543:1
func (t *A_arbace_go_check_forms_source_fn__1685000437_A) Ctor() {}
//line :543:1
func (t *A_arbace_go_check_forms_source_fn__1685000437_A) Invoke_O_O__O(self, p1__1685000434_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3529 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3529, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3531 lang.IFn; if linked_3530 == nil { ifn_3531 = lang.IFn_Cast(root_3529) } else { ifn_3531 = nil }; var arg_3532 any = p1__1685000434_SHARP___1; if linked_3530 == nil { and__1927000168__auto____2 = ifn_3531.Invoke_O__O(arg_3532) } else { and__1927000168__auto____2 = linked_3530.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3529, arg_3532) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_327; var tmp3 any; var root_3533 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3535 lang.IFn; if linked_3534 == nil { ifn_3535 = lang.IFn_Cast(root_3533) } else { ifn_3535 = nil }; var arg_3536 any = p1__1685000434_SHARP___1; if linked_3534 == nil { tmp3 = ifn_3535.Invoke_O__O(arg_3536) } else { tmp3 = linked_3534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3533, arg_3536) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3537 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_3538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3537, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3539 lang.IFn; if linked_3538 == nil { ifn_3539 = lang.IFn_Cast(root_3537) } else { ifn_3539 = nil }; var arg_3540 any = p1__1685000434_SHARP___1; if linked_3538 == nil { return ifn_3539.Invoke_O__O(arg_3540) } else { return linked_3538.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3537, arg_3540) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000439__1685000443_A_New() *A_arbace_go_check_forms_source_iter__1685000439__1685000443_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000439__1685000443_A{}; t.Ctor(); return t }
//line :544:1
func (t *A_arbace_go_check_forms_source_iter__1685000439__1685000443_A) Ctor() {}
//line :544:1
func (t *A_arbace_go_check_forms_source_iter__1685000439__1685000443_A) Invoke_O_O__O(self, s__1685000440__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A_New_O_O(self, s__1685000440__1); var tmp2 *jrt.Class; var fncls__3615 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A_fn_class; if fncls__3615 == nil { var fncls__3615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A_fn_class = fncls__3615d; tmp2 = fncls__3615d } else { tmp2 = fncls__3615 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :544:1
func A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A{}; t.Ctor_O_O(p0, p1); return t }
//line :544:1
func (t *A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A) Ctor_O_O(c__iter__1685000439, c__s__1685000440 any) { t.F_iter__1685000439 = c__iter__1685000439; t.F_s__1685000440 = c__s__1685000440 }
//line :544:1
func (t *A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A) Invoke_O__O(self any) any { { var s__1685000440__1 any; var t_ any = t.F_s__1685000440; t.F_s__1685000440 = nil; s__1685000440__1 = t_; for { var temp__1927000414__auto____2 any; var root_3546 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3546, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3548 lang.IFn; if linked_3547 == nil { ifn_3548 = lang.IFn_Cast(root_3546) } else { ifn_3548 = nil }; var arg_3549 any = s__1685000440__1; if linked_3547 == nil { temp__1927000414__auto____2 = ifn_3548.Invoke_O__O(arg_3549) } else { temp__1927000414__auto____2 = linked_3547.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3546, arg_3549) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000440__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3550 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3552 lang.IFn; if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = s__1685000440__3; if linked_3551 == nil { tmp1 = ifn_3552.Invoke_O__O(arg_3553) } else { tmp1 = linked_3551.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3550, arg_3553) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3554 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3554, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3556 lang.IFn; if linked_3555 == nil { ifn_3556 = lang.IFn_Cast(root_3554) } else { ifn_3556 = nil }; var arg_3557 any = s__1685000440__3; if linked_3555 == nil { c__1927001037__auto____4 = ifn_3556.Invoke_O__O(arg_3557) } else { c__1927001037__auto____4 = linked_3555.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3554, arg_3557) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000442__6 any; var root_3558 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3558, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3560 lang.IFn; if linked_3559 == nil { ifn_3560 = lang.IFn_Cast(root_3558) } else { ifn_3560 = nil }; var arg_3561 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3559 == nil { b__1685000442__6 = ifn_3560.Invoke_O__O(arg_3561) } else { b__1685000442__6 = linked_3559.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3558, arg_3561) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A_New_O_I_O(b__1685000442__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3573 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A_fn_class; if fncls__3573 == nil { var fncls__3573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A_fn_class = fncls__3573d; tmp3 = fncls__3573d } else { tmp3 = fncls__3573 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3574 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3574, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3576 lang.IFn; if linked_3575 == nil { ifn_3576 = lang.IFn_Cast(root_3574) } else { ifn_3576 = nil }; var arg_3577 any; var root_3579 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3581 lang.IFn; if linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any = b__1685000442__6; if linked_3580 == nil { arg_3577 = ifn_3581.Invoke_O__O(arg_3582) } else { arg_3577 = linked_3580.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3579, arg_3582) }; var arg_3578 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000439); var tmp5 any; var root_3583 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3583, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3585 lang.IFn; if linked_3584 == nil { ifn_3585 = lang.IFn_Cast(root_3583) } else { ifn_3585 = nil }; var arg_3586 any = s__1685000440__3; if linked_3584 == nil { tmp5 = ifn_3585.Invoke_O__O(arg_3586) } else { tmp5 = linked_3584.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3583, arg_3586) }; arg_3578 = tmp4.Invoke_O__O(tmp5); if linked_3575 == nil { return ifn_3576.Invoke_O_O__O(arg_3577, arg_3578) } else { return linked_3575.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3574, arg_3577, arg_3578) } } else { var root_3587 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3589 lang.IFn; if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any; var root_3592 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3592, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3594 lang.IFn; if linked_3593 == nil { ifn_3594 = lang.IFn_Cast(root_3592) } else { ifn_3594 = nil }; var arg_3595 any = b__1685000442__6; if linked_3593 == nil { arg_3590 = ifn_3594.Invoke_O__O(arg_3595) } else { arg_3590 = linked_3593.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3592, arg_3595) }; var arg_3591 any; if linked_3588 == nil { return ifn_3589.Invoke_O_O__O(arg_3590, arg_3591) } else { return linked_3588.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3587, arg_3590, arg_3591) } } } else { var fi__4 any; var root_3596 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3596, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3598 lang.IFn; if linked_3597 == nil { ifn_3598 = lang.IFn_Cast(root_3596) } else { ifn_3598 = nil }; var arg_3599 any = s__1685000440__3; if linked_3597 == nil { fi__4 = ifn_3598.Invoke_O__O(arg_3599) } else { fi__4 = linked_3597.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3596, arg_3599) }; var root_3600 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3600, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3602 lang.IFn; if linked_3601 == nil { ifn_3602 = lang.IFn_Cast(root_3600) } else { ifn_3602 = nil }; var arg_3603 any; var root_3605 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3605, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3607 lang.IFn; if linked_3606 == nil { ifn_3607 = lang.IFn_Cast(root_3605) } else { ifn_3607 = nil }; var arg_3608 any = fi__4; var arg_3609 any = A_arbace_go_check_A_const_81; var arg_3610 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__4); if linked_3606 == nil { arg_3603 = ifn_3607.Invoke_O_O_O__O(arg_3608, arg_3609, arg_3610) } else { arg_3603 = linked_3606.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3605, arg_3608, arg_3609, arg_3610) }; var arg_3604 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000439); var tmp7 any; var root_3611 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3611, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3613 lang.IFn; if linked_3612 == nil { ifn_3613 = lang.IFn_Cast(root_3611) } else { ifn_3613 = nil }; var arg_3614 any = s__1685000440__3; if linked_3612 == nil { tmp7 = ifn_3613.Invoke_O__O(arg_3614) } else { tmp7 = linked_3612.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3611, arg_3614) }; arg_3604 = tmp6.Invoke_O__O(tmp7); if linked_3601 == nil { return ifn_3602.Invoke_O_O__O(arg_3603, arg_3604) } else { return linked_3601.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3600, arg_3603, arg_3604) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :544:1
func A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :544:1
func (t *A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A) Ctor_O_I_O(c__b__1685000442 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000442 = c__b__1685000442; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :544:1
func (t *A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A) Invoke_O__O(self any) any { { var i__1685000441__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000441__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000441__1)); var root_3562 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3562, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3564 lang.IFn; if linked_3563 == nil { ifn_3564 = lang.IFn_Cast(root_3562) } else { ifn_3564 = nil }; var arg_3565 any = t.F_b__1685000442; var arg_3566 any; var root_3567 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3568 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3567, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3569 lang.IFn; if linked_3568 == nil { ifn_3569 = lang.IFn_Cast(root_3567) } else { ifn_3569 = nil }; var arg_3570 any = fi__2; var arg_3571 any = A_arbace_go_check_A_const_81; var arg_3572 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__2); if linked_3568 == nil { arg_3566 = ifn_3569.Invoke_O_O_O__O(arg_3570, arg_3571, arg_3572) } else { arg_3566 = linked_3568.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3567, arg_3570, arg_3571, arg_3572) }; if linked_3563 == nil { ifn_3564.Invoke_O_O__O(arg_3565, arg_3566) } else { linked_3563.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3562, arg_3565, arg_3566) }; i__1685000441__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000441__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :546:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3626 any = A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_3627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3626, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3628 lang.IFn; if




	linked_3627 == nil { ifn_3628 = lang.IFn_Cast(root_3626) } else { ifn_3628 = nil }; var arg_3629 any = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_329, jrt.Boolean_FALSE.Ref()); if linked_3627 == nil { ifn_3628.Invoke_O__O(arg_3629) } else { linked_3627.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3626, arg_3629) }; var tmp1 any; tmp3 := /*line :546:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3617 any = A_arbace_go_check_A_const_328.GetRawRoot__O(); var linked_3618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3617, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3619 lang.IFn






		if linked_3618 == nil { ifn_3619 = lang.IFn_Cast(root_3617) } else { ifn_3619 = nil }; var arg_3620 any = r__2; var arg_3621 any = jrt.Boolean_FALSE.Ref(); var arg_3622 any = eof__3; if linked_3618 == nil { f__7 = ifn_3619.Invoke_O_O_O__O(arg_3620, arg_3621, arg_3622) } else { f__7 = linked_3618.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3617, arg_3620, arg_3621, arg_3622) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3635 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3635, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any = acc__6; var arg_3639 any = f__7; if linked_3636 == nil { tmp2 = ifn_3637.Invoke_O_O__O(arg_3638, arg_3639) } else { tmp2 = linked_3636.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3635, arg_3638, arg_3639) }; acc__6 = tmp2; continue L1 }
//line :546:1
		break L1 } }; return nil }(); var root_3623 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3623, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3625 lang.IFn; if




	linked_3624 == nil { ifn_3625 = lang.IFn_Cast(root_3623) } else { ifn_3625 = nil }; if linked_3624 == nil { ifn_3625.Invoke__O() } else { linked_3624.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3623) }; if /*line :546:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :558:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :558:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3640 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3640, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3642 lang.IFn; if


	linked_3641 == nil { ifn_3642 = lang.IFn_Cast(root_3640) } else { ifn_3642 = nil }; var arg_3643 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); if linked_3641 == nil { tmp1 = ifn_3642.Invoke_O__O(arg_3643) } else { tmp1 = linked_3641.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3640, arg_3643) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3644 any = A_arbace_go_check_A_const_292.GetRawRoot__O(); var linked_3645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3644, A_arbace_go_check_std_session_A_fn_class); var ifn_3646 lang.IFn
		if linked_3645 == nil { ifn_3646 = lang.IFn_Cast(root_3644) } else { ifn_3646 = nil }; var arg_3647 any; var root_3648 any = A_arbace_go_check_A_const_291.GetRawRoot__O(); var linked_3649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3648, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3650 lang.IFn; if linked_3649 == nil { ifn_3650 = lang.IFn_Cast(root_3648) } else { ifn_3650 = nil }; var arg_3651 any = corpus__0; if linked_3649 == nil { arg_3647 = ifn_3650.Invoke_O__O(arg_3651) } else { arg_3647 = linked_3649.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3648, arg_3651) }; if linked_3645 == nil { s__3 = ifn_3646.Invoke_O__O(arg_3647) } else { s__3 = linked_3645.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3644, arg_3647) }
		var root_3652 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_3653 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3652, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3654 lang.IFn; if linked_3653 == nil { ifn_3654 = lang.IFn_Cast(root_3652) } else { ifn_3654 = nil }; var arg_3655 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); var arg_3656 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var arg_3657 any = corpus__0; var arg_3658 any = s__3; if linked_3653 == nil { ifn_3654.Invoke_O_O_O_O__O(arg_3655, arg_3656, arg_3657, arg_3658) } else { linked_3653.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3652, arg_3655, arg_3656, arg_3657, arg_3658) }
//line :561:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :566:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :566:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3659 any = A_arbace_go_check_A_const_331.GetRawRoot__O(); var linked_3660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3659, A_arbace_go_check_std_A_fn_class); var ifn_3661 lang.IFn; if




	linked_3660 == nil { ifn_3661 = lang.IFn_Cast(root_3659) } else { ifn_3661 = nil }; var arg_3662 any = corpus__1; if linked_3660 == nil { s__4 = ifn_3661.Invoke_O__O(arg_3662) } else { s__4 = linked_3660.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3659, arg_3662) }; var src__5 any; var root_3663 any = /*line :566:1*/A_arbace_go_check_A_const_332.GetRawRoot__O(); var linked_3664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3663, A_arbace_go_check_forms_source_A_fn_class); var ifn_3665 lang.IFn; if





	linked_3664 == nil { ifn_3665 = lang.IFn_Cast(root_3663) } else { ifn_3665 = nil }; var arg_3666 any = forms__0; var arg_3667 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_111; var tmp2 any; var root_3668 any = A_arbace_go_check_A_const_291.GetRawRoot__O(); var linked_3669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3668, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3670 lang.IFn; if linked_3669 == nil { ifn_3670 = lang.IFn_Cast(root_3668) } else { ifn_3670 = nil }; var arg_3671 any = corpus__1; if linked_3669 == nil { tmp2 = ifn_3670.Invoke_O__O(arg_3671) } else { tmp2 = linked_3669.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3668, arg_3671) }; arg_3667 = tmp1.Invoke_O__O(tmp2); if linked_3664 == nil { src__5 = ifn_3665.Invoke_O_O__O(arg_3666, arg_3667) } else { src__5 = linked_3664.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3663, arg_3666, arg_3667) }; var pkg__6 any; var tmp3 lang.IFn = /*line :566:1*/lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()); var tmp4 any; var root_3679 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_3680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3679, A_arbace_go_check_resolver_A_fn_class); var ifn_3681 lang.IFn; if






	linked_3680 == nil { ifn_3681 = lang.IFn_Cast(root_3679) } else { ifn_3681 = nil }; var arg_3682 any = s__4; var arg_3683 any = src__5; var arg_3684 any = lang.PersistentVector_EMPTY.Ref(); if linked_3680 == nil { tmp4 = ifn_3681.Invoke_O_O_O__O(arg_3682, arg_3683, arg_3684) } else { tmp4 = linked_3680.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3679, arg_3682, arg_3683, arg_3684) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_108; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_108.Invoke_O__O(opts__2)); var root_3685 any =
	A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3685, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3687 lang.IFn; if linked_3686 == nil { ifn_3687 = lang.IFn_Cast(root_3685) } else { ifn_3687 = nil }; var arg_3688 any = pkg__6; var arg_3689 any = A_arbace_go_check_A_const_224; if linked_3686 == nil { return ifn_3687.Invoke_O_O__O(arg_3688, arg_3689) } else { return linked_3686.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3685, arg_3688, arg_3689) } }
//line :566:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_3690 any = A_arbace_go_check_A_const_333.GetRawRoot__O(); var linked_3691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3690, A_arbace_go_check_check_forms_A_fn_class); var ifn_3692 lang.IFn; if linked_3691 == nil { ifn_3692 = lang.IFn_Cast(root_3690) } else { ifn_3692 = nil }; var arg_3693 any = forms__0; var arg_3694 any = Lit_51; var arg_3695 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3691 == nil { return ifn_3692.Invoke_O_O_O__O(arg_3693, arg_3694, arg_3695) } else { return linked_3691.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_3690, arg_3693, arg_3694, arg_3695)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :582:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :582:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_338.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_334.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_3713 any = A_arbace_go_check_A_const_166.GetRawRoot__O(); var linked_3714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3713, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3715 lang.IFn; if linked_3714 == nil { ifn_3715 = lang.IFn_Cast(root_3713) } else { ifn_3715 = nil }; var arg_3716 any = lang.IFn_Cast(A_arbace_go_check_A_const_167.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_337, s__1927001093__auto____3); if linked_3714 == nil { ifn_3715.Invoke_O__O(arg_3716) } else { linked_3714.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3713, arg_3716) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000453_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__3712 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000453_A_fn_class; if fncls__3712 == nil { var fncls__3712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_check_write_edn_fn__1685000453_A_fn_class = fncls__3712d; tmp4 = fncls__3712d } else { tmp4 = fncls__3712 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :584:1
func A_arbace_go_check_write_edn_fn__1685000453_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000453_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000453_A{}; t.Ctor_O_O(p0, p1); return t }
//line :584:1
func (t *A_arbace_go_check_write_edn_fn__1685000453_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :584:1
func (t *A_arbace_go_check_write_edn_fn__1685000453_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3708 any = A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3708, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_3710 lang.IFn; if linked_3709 == nil { ifn_3710 = lang.IFn_Cast(root_3708) } else { ifn_3710 = nil }; var arg_3711 any; var t_ any = t.F_x; t.F_x = nil; arg_3711 = t_; if linked_3709 == nil { ifn_3710.Invoke_O__O(arg_3711) } else { linked_3709.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_3708, arg_3711) }; var root_3701 any = A_arbace_go_check_A_const_335.GetRawRoot__O(); var linked_3702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3701, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3703 lang.IFn; if linked_3702 == nil { ifn_3703 = lang.IFn_Cast(root_3701) } else { ifn_3703 = nil }; var arg_3704 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_3704 = t__2; if linked_3702 == nil { tmp1 = ifn_3703.Invoke_O__O(arg_3704) } else { tmp1 = linked_3702.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3701, arg_3704) } }; return nil }(); var root_3705 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3705, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3707 lang.IFn; if linked_3706 == nil { ifn_3707 = lang.IFn_Cast(root_3705) } else { ifn_3707 = nil }; if linked_3706 == nil { ifn_3707.Invoke__O() } else { linked_3706.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3705) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :586:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :586:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil, Lit_118), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil, corpus__0, nil)).Ref() }

func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :588:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :588:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000457__1 any) any { var map__1685000458__3 any = p__1685000457__1; var map__1685000458__4 any; if lang.ISeq_InstanceOf(map__1685000458__3) { var tmp1 any; var root_3726 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3726, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3728 lang.IFn; if linked_3727 == nil { ifn_3728 = lang.IFn_Cast(root_3726) } else { ifn_3728 = nil }; var arg_3729 any = map__1685000458__3; if linked_3727 == nil { tmp1 = ifn_3728.Invoke_O__O(arg_3729) } else { tmp1 = linked_3727.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3726, arg_3729) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3730 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3730, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3732 lang.IFn; if linked_3731 == nil { ifn_3732 = lang.IFn_Cast(root_3730) } else { ifn_3732 = nil }; var arg_3733 any = map__1685000458__3; if linked_3731 == nil { tmp2 = ifn_3732.Invoke_O__O(arg_3733) } else { tmp2 = linked_3731.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3730, arg_3733) }; map__1685000458__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3734 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3734, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3736 lang.IFn; if linked_3735 == nil { ifn_3736 = lang.IFn_Cast(root_3734) } else { ifn_3736 = nil }; var arg_3737 any = map__1685000458__3; if linked_3735 == nil { tmp3 = ifn_3736.Invoke_O__O(arg_3737) } else { tmp3 = linked_3735.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3734, arg_3737) }; if jrt.J2g_Truth(tmp3) { var root_3738 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3738, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3740 lang.IFn; if linked_3739 == nil { ifn_3740 = lang.IFn_Cast(root_3738) } else { ifn_3740 = nil }; var arg_3741 any = map__1685000458__3; if linked_3739 == nil { map__1685000458__4 = ifn_3740.Invoke_O__O(arg_3741) } else { map__1685000458__4 = linked_3739.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3738, arg_3741) } } else { map__1685000458__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000458__4 = map__1685000458__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000458__4, A_arbace_go_check_A_const_339); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000458__4, A_arbace_go_check_A_const_340); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000458__4, A_arbace_go_check_A_const_341); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_3742 any = A_arbace_go_check_A_const_342.GetRawRoot__O(); var linked_3743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3742, A_arbace_go_check_check_corpus_A_fn_class); var ifn_3744 lang.IFn; if






	linked_3743 == nil { ifn_3744 = lang.IFn_Cast(root_3742) } else { ifn_3744 = nil }; var arg_3745 any = corpus__0; var arg_3746 any = jobs__5; if linked_3743 == nil { rs__9 = ifn_3744.Invoke_O_O__O(arg_3745, arg_3746) } else { rs__9 = linked_3743.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_3742, arg_3745, arg_3746) }; var sm__10 any; var root_3747 any = /*line :588:1*/A_arbace_go_check_A_const_343.GetRawRoot__O(); var linked_3748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3747, A_arbace_go_check_summarize_A_fn_class); var ifn_3749 lang.IFn; if







	linked_3748 == nil { ifn_3749 = lang.IFn_Cast(root_3747) } else { ifn_3749 = nil }; var arg_3750 any = corpus__0; var arg_3751 any = rs__9; if linked_3748 == nil { sm__10 = ifn_3749.Invoke_O_O__O(arg_3750, arg_3751) } else { sm__10 = linked_3748.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_3747, arg_3750, arg_3751) }; var secs__11 float64 = /*line :588:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_344; var tmp5 any; var root_3752 any = A_arbace_go_check_A_const_345.GetRawRoot__O(); var linked_3753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3752, A_arbace_go_check_reference_path_A_fn_class); var ifn_3754 lang.IFn; if









	linked_3753 == nil { ifn_3754 = lang.IFn_Cast(root_3752) } else { ifn_3754 = nil }; var arg_3755 any = corpus__0; if linked_3753 == nil { tmp5 = ifn_3754.Invoke_O__O(arg_3755) } else { tmp5 = linked_3753.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3752, arg_3755) }; ref_file__12 = /*line :588:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var root_3756 any = A_arbace_go_check_A_const_346.GetRawRoot__O(); var linked_3757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3756, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_3758 lang.IFn; if linked_3757 == nil { ifn_3758 = lang.IFn_Cast(root_3756) } else { ifn_3758 = nil }; var arg_3759 any = lang.IFn_Cast(A_arbace_go_check_A_const_347.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_3757 == nil { ref__13 = ifn_3758.Invoke_O__O(arg_3759) } else { ref__13 = linked_3757.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_3756, arg_3759) } } else { ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_3764 any = /*line :588:1*/A_arbace_go_check_A_const_225.Invoke_O__O(sm__10); if











	jrt.Long_InstanceOf(na_3764) { var n0_3765 int64 = jrt.NN(jrt.Long_Cast(na_3764)).LongValue__J(); and__1927000168__auto____14 = n0_3765 == 0 } else { if jrt.Double_InstanceOf(na_3764) { var n0_3765_2 float64 = jrt.NN(jrt.Double_Cast(na_3764)).DoubleValue__D(); and__1927000168__auto____14 = n0_3765_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_3764) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_3766 any = A_arbace_go_check_A_const_311.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_3766) { var n0_3767 int64 = jrt.NN(jrt.Long_Cast(na_3766)).LongValue__J(); and__1927000168__auto____15 = n0_3767 == 0 } else { if jrt.Double_InstanceOf(na_3766) { var n0_3767_2 float64 = jrt.NN(jrt.Double_Cast(na_3766)).DoubleValue__D(); and__1927000168__auto____15 = n0_3767_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_3766) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_3768 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_3769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3768, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3770 lang.IFn; if linked_3769 == nil { ifn_3770 = lang.IFn_Cast(root_3768) } else { ifn_3770 = nil }; var arg_3771 any; var root_3772 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3772, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3774 lang.IFn; if linked_3773 == nil { ifn_3774 = lang.IFn_Cast(root_3772) } else { ifn_3774 = nil }; var arg_3775 any = sm__10; var arg_3776 any = A_arbace_go_check_A_const_348; if linked_3773 == nil { arg_3771 = ifn_3774.Invoke_O_O__O(arg_3775, arg_3776) } else { arg_3771 = linked_3773.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3772, arg_3775, arg_3776) }; if linked_3769 == nil { and__1927000168__auto____16 = ifn_3770.Invoke_O__O(arg_3771) } else { and__1927000168__auto____16 = linked_3769.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3768, arg_3771) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_3777 any; var root_3778 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3780 lang.IFn
		if linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any = sm__10; var arg_3782 any = A_arbace_go_check_A_const_349; if linked_3779 == nil { na_3777 = ifn_3780.Invoke_O_O__O(arg_3781, arg_3782) } else { na_3777 = linked_3779.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3778, arg_3781, arg_3782) }; if jrt.Long_InstanceOf(na_3777) { var n0_3783 int64 = jrt.NN(jrt.Long_Cast(na_3777)).LongValue__J(); and__1927000168__auto____17 = n0_3783 == 0 } else { if jrt.Double_InstanceOf(na_3777) { var n0_3783_2 float64 = jrt.NN(jrt.Double_Cast(na_3777)).DoubleValue__D(); and__1927000168__auto____17 = n0_3783_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_3777) } }
//line :600:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_3784 any; var root_3785 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3785, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3787 lang.IFn; if linked_3786 == nil { ifn_3787 = lang.IFn_Cast(root_3785) } else { ifn_3787 = nil }; var arg_3788 any = sm__10; var arg_3789 any = A_arbace_go_check_A_const_350; if linked_3786 == nil { na_3784 = ifn_3787.Invoke_O_O__O(arg_3788, arg_3789) } else { na_3784 = linked_3786.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3785, arg_3788, arg_3789) }; if jrt.Long_InstanceOf(na_3784) { var n0_3790 int64 = jrt.NN(jrt.Long_Cast(na_3784)).LongValue__J(); tmp6 = n0_3790 == 0 } else { if jrt.Double_InstanceOf(na_3784) { var n0_3790_2 float64 = jrt.NN(jrt.Double_Cast(na_3784)).DoubleValue__D(); tmp6 = n0_3790_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_3784) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :600:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_3791 any = /*line :588:1*/A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3793 lang.IFn; if














	linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; var arg_3794 any = ref__13; var arg_3795 any = A_arbace_go_check_A_const_351; if linked_3792 == nil { tmp7 = ifn_3793.Invoke_O_O__O(arg_3794, arg_3795) } else { tmp7 = linked_3792.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3791, arg_3794, arg_3795) }; var tmp8 any = tmp7; var tmp9 any; var root_3796 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3796, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3798 lang.IFn; if linked_3797 == nil { ifn_3798 = lang.IFn_Cast(root_3796) } else { ifn_3798 = nil }; var arg_3799 any = sm__10; var arg_3800 any = A_arbace_go_check_A_const_313; if linked_3797 == nil { tmp9 = ifn_3798.Invoke_O_O__O(arg_3799, arg_3800) } else { tmp9 = linked_3797.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3796, arg_3799, arg_3800) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_3809 any =
	A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_3810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3809, A_arbace_go_check_write_edn_A_fn_class); var ifn_3811 lang.IFn; if linked_3810 == nil { ifn_3811 = lang.IFn_Cast(root_3809) } else { ifn_3811 = nil }; var arg_3812 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_3813 any; var tmp10 any = A_arbace_go_check_A_const_353; var tmp11 any = A_arbace_go_check_A_const_354; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_225; var tmp14 any; var root_3814 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_3815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3814, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3816 lang.IFn; if

	linked_3815 == nil { ifn_3816 = lang.IFn_Cast(root_3814) } else { ifn_3816 = nil }; var arg_3817 any; var root_3818 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_3819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3818, A_arbace_go_check_report_errors_A_fn_class); var ifn_3820 lang.IFn; if linked_3819 == nil { ifn_3820 = lang.IFn_Cast(root_3818) } else { ifn_3820 = nil }; var arg_3821 any = rs__9; if linked_3819 == nil { arg_3817 = ifn_3820.Invoke_O__O(arg_3821) } else { arg_3817 = linked_3819.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3818, arg_3821) }; if linked_3815 == nil { tmp14 = ifn_3816.Invoke_O__O(arg_3817) } else { tmp14 = linked_3815.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3814, arg_3817) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_163; var tmp17 any; var root_3822 any = /*line :604:1*/A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_3823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3822, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3824 lang.IFn; if


	linked_3823 == nil { ifn_3824 = lang.IFn_Cast(root_3822) } else { ifn_3824 = nil }; var arg_3825 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000460__1685000466_A_New(); var tmp19 *jrt.Class; var fncls__3911 *jrt.Class = A_arbace_go_check_annotations_iter__1685000460__1685000466_A_fn_class; if fncls__3911 == nil { var fncls__3911d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_annotations_iter__1685000460__1685000466_A_fn_class = fncls__3911d; tmp19 = fncls__3911d } else { tmp19 = fncls__3911 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_3825 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_3823 == nil { tmp17 = ifn_3824.Invoke_O__O(arg_3825) } else { tmp17 = linked_3823.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3822, arg_3825) }; arg_3813 = /*line :604:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_3810 == nil { ifn_3811.Invoke_O_O__O(arg_3812, arg_3813) } else { linked_3810.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3809, arg_3812, arg_3813) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_222.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_307.Invoke_O__O(sm__10); var tmp23 any; var root_3930 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3930, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3932 lang.IFn; if
	linked_3931 == nil { ifn_3932 = lang.IFn_Cast(root_3930) } else { ifn_3932 = nil }; var arg_3933 any = sm__10; var arg_3934 any = A_arbace_go_check_A_const_357; if linked_3931 == nil { tmp23 = ifn_3932.Invoke_O_O__O(arg_3933, arg_3934) } else { tmp23 = linked_3931.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3930, arg_3933, arg_3934) }; var tmp24 any = tmp23; var tmp25 any; var root_3935 any = /*line :608:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3935, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3937 lang.IFn; if
	linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; var arg_3938 any = sm__10; var arg_3939 any = A_arbace_go_check_A_const_358; if linked_3936 == nil { tmp25 = ifn_3937.Invoke_O_O__O(arg_3938, arg_3939) } else { tmp25 = linked_3936.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3935, arg_3938, arg_3939) }; var tmp26 any = tmp25; var tmp27 any; var root_3940 any = /*line :608:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3940, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3942 lang.IFn; if

	linked_3941 == nil { ifn_3942 = lang.IFn_Cast(root_3940) } else { ifn_3942 = nil }; var arg_3943 any = sm__10; var arg_3944 any = A_arbace_go_check_A_const_359; if linked_3941 == nil { tmp27 = ifn_3942.Invoke_O_O__O(arg_3943, arg_3944) } else { tmp27 = linked_3941.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3940, arg_3943, arg_3944) }; var tmp28 any = tmp27; var tmp29 any = /*line :608:1*/A_arbace_go_check_A_const_225.Invoke_O__O(sm__10); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()); var tmp31 any; var root_3949 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3949, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3951 lang.IFn; if


	linked_3950 == nil { ifn_3951 = lang.IFn_Cast(root_3949) } else { ifn_3951 = nil }; var arg_3952 any = sm__10; var arg_3953 any = A_arbace_go_check_A_const_360; if linked_3950 == nil { tmp31 = ifn_3951.Invoke_O_O__O(arg_3952, arg_3953) } else { tmp31 = linked_3950.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3949, arg_3952, arg_3953) }; var tmp32 any = /*line :608:1*/tmp30.Invoke_O__O(tmp31); var tmp33 any; var root_3954 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3954, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3956 lang.IFn; if



	linked_3955 == nil { ifn_3956 = lang.IFn_Cast(root_3954) } else { ifn_3956 = nil }; var arg_3957 any = sm__10; var arg_3958 any = A_arbace_go_check_A_const_361; if linked_3955 == nil { tmp33 = ifn_3956.Invoke_O_O__O(arg_3957, arg_3958) } else { tmp33 = linked_3955.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3954, arg_3957, arg_3958) }; var tmp34 any = tmp33; var tmp35 any; var root_3959 any = /*line :608:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3959, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3961 lang.IFn; if



	linked_3960 == nil { ifn_3961 = lang.IFn_Cast(root_3959) } else { ifn_3961 = nil }; var arg_3962 any = sm__10; var arg_3963 any = A_arbace_go_check_A_const_362; if linked_3960 == nil { tmp35 = ifn_3961.Invoke_O_O__O(arg_3962, arg_3963) } else { tmp35 = linked_3960.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3959, arg_3962, arg_3963) }; /*line :608:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_14, corpus__0, tmp22, tmp24, tmp26, tmp28, tmp29, tmp32, tmp34, tmp35, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000476__16 any; var root_3964 any = /*line :588:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3964, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3966 lang.IFn; if
























	linked_3965 == nil { ifn_3966 = lang.IFn_Cast(root_3964) } else { ifn_3966 = nil }; var arg_3967 any; var root_3968 any = A_arbace_go_check_A_const_363.GetRawRoot__O(); var linked_3969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3968, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3970 lang.IFn; if linked_3969 == nil { ifn_3970 = lang.IFn_Cast(root_3968) } else { ifn_3970 = nil }; var arg_3971 any = A_arbace_go_check_A_const_364; var arg_3972 any; var root_3973 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_3974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3973, A_arbace_go_check_report_errors_A_fn_class); var ifn_3975 lang.IFn; if linked_3974 == nil { ifn_3975 = lang.IFn_Cast(root_3973) } else { ifn_3975 = nil }; var arg_3976 any = rs__9; if linked_3974 == nil { arg_3972 = ifn_3975.Invoke_O__O(arg_3976) } else { arg_3972 = linked_3974.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3973, arg_3976) }; if linked_3969 == nil { arg_3967 = ifn_3970.Invoke_O_O__O(arg_3971, arg_3972) } else { arg_3967 = linked_3969.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3968, arg_3971, arg_3972) }; if linked_3965 == nil { seq_1685000476__16 = ifn_3966.Invoke_O__O(arg_3967) } else { seq_1685000476__16 = linked_3965.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3964, arg_3967) }; var chunk_1685000477__17 any; var count_1685000478__18 int64 = 0; var i_1685000479__19 int64 = 0; L1:
//line :588:1
	for {
























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000479__19, count_1685000478__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000477__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000479__19)); lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__20); seq_1685000476__16, chunk_1685000477__17, count_1685000478__18, i_1685000479__19 = seq_1685000476__16, chunk_1685000477__17, count_1685000478__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000479__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_3977 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3977, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3979 lang.IFn; if linked_3978 == nil { ifn_3979 = lang.IFn_Cast(root_3977) } else { ifn_3979 = nil }; var arg_3980 any = seq_1685000476__16; if linked_3978 == nil { temp__1927000414__auto____20 = ifn_3979.Invoke_O__O(arg_3980) } else { temp__1927000414__auto____20 = linked_3978.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3977, arg_3980) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000476__21 any = temp__1927000414__auto____20; var tmp36 any; var root_3981 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3981, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3983 lang.IFn; if linked_3982 == nil { ifn_3983 = lang.IFn_Cast(root_3981) } else { ifn_3983 = nil }; var arg_3984 any = seq_1685000476__21; if linked_3982 == nil { tmp36 = ifn_3983.Invoke_O__O(arg_3984) } else { tmp36 = linked_3982.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3981, arg_3984) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____22 any; var root_3985 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3985, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3987 lang.IFn; if linked_3986 == nil { ifn_3987 = lang.IFn_Cast(root_3985) } else { ifn_3987 = nil }; var arg_3988 any = seq_1685000476__21; if linked_3986 == nil { c__1927000678__auto____22 = ifn_3987.Invoke_O__O(arg_3988) } else { c__1927000678__auto____22 = linked_3986.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3985, arg_3988) }; var tmp37 any; var root_4034 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4034, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4036 lang.IFn; if linked_4035 == nil { ifn_4036 = lang.IFn_Cast(root_4034) } else { ifn_4036 = nil }; var arg_4037 any = seq_1685000476__21; if linked_4035 == nil { tmp37 = ifn_4036.Invoke_O__O(arg_4037) } else { tmp37 = linked_4035.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4034, arg_4037) }; seq_1685000476__16, chunk_1685000477__17, count_1685000478__18, i_1685000479__19 = tmp37, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_3989 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3989, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3991 lang.IFn; if linked_3990 == nil { ifn_3991 = lang.IFn_Cast(root_3989) } else { ifn_3991 = nil }; var arg_3992 any = seq_1685000476__21; if linked_3990 == nil { l__22 = ifn_3991.Invoke_O__O(arg_3992) } else { l__22 = linked_3990.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3989, arg_3992) }; lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__22); var tmp38 any; var root_4043 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4043, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4045 lang.IFn; if linked_4044 == nil { ifn_4045 = lang.IFn_Cast(root_4043) } else { ifn_4045 = nil }; var arg_4046 any = seq_1685000476__21; if linked_4044 == nil { tmp38 = ifn_4045.Invoke_O__O(arg_4046) } else { tmp38 = linked_4044.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4043, arg_4046) }; seq_1685000476__16, chunk_1685000477__17, count_1685000478__18, i_1685000479__19 = tmp38, nil, 0, 0; continue L1 } } }
//line :588:1
		break L1 }; var tmp39 any; var root_3993 any =

























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3993, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3995 lang.IFn; if linked_3994 == nil { ifn_3995 = lang.IFn_Cast(root_3993) } else { ifn_3995 = nil }; var arg_3996 any; var root_3997 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3997, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3999 lang.IFn; if linked_3998 == nil { ifn_3999 = lang.IFn_Cast(root_3997) } else { ifn_3999 = nil }; var arg_4000 any = sm__10; var arg_4001 any = A_arbace_go_check_A_const_365; if linked_3998 == nil { arg_3996 = ifn_3999.Invoke_O_O__O(arg_4000, arg_4001) } else { arg_3996 = linked_3998.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3997, arg_4000, arg_4001) }; if linked_3994 == nil { tmp39 = ifn_3995.Invoke_O__O(arg_3996) } else { tmp39 = linked_3994.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3993, arg_3996) }; if jrt.J2g_Truth(tmp39) {
		var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()); var tmp42 any; var root_4011 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4011, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4013 lang.IFn; if linked_4012 == nil { ifn_4013 = lang.IFn_Cast(root_4011) } else { ifn_4013 = nil }; var arg_4014 any = sm__10; var arg_4015 any = A_arbace_go_check_A_const_366; if linked_4012 == nil { tmp42 = ifn_4013.Invoke_O_O__O(arg_4014, arg_4015) } else { tmp42 = linked_4012.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4011, arg_4014, arg_4015) }; tmp40.Invoke_O_O__O(Lit_16, tmp41.Invoke_O__O(tmp42)) }; var tmp43 any; var root_4016 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4018 lang.IFn; if linked_4017 == nil { ifn_4018 = lang.IFn_Cast(root_4016) } else { ifn_4018 = nil }; var arg_4019 any = A_arbace_go_check_A_const_142.Invoke_O__O(sm__10); if linked_4017 == nil { tmp43 = ifn_4018.Invoke_O__O(arg_4019) } else { tmp43 = linked_4017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4016, arg_4019) }; if jrt.J2g_Truth(tmp43) {
		lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_142.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_4047 any = A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_4048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4047, A_arbace_go_check_write_edn_A_fn_class); var ifn_4049 lang.IFn; if linked_4048 == nil { ifn_4049 = lang.IFn_Cast(root_4047) } else { ifn_4049 = nil }; var arg_4050 any; var root_4052 any = A_arbace_go_check_A_const_345.GetRawRoot__O(); var linked_4053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4052, A_arbace_go_check_reference_path_A_fn_class); var ifn_4054 lang.IFn; if linked_4053 == nil { ifn_4054 = lang.IFn_Cast(root_4052) } else { ifn_4054 = nil }; var arg_4055 any = corpus__0; if linked_4053 == nil { arg_4050 = ifn_4054.Invoke_O__O(arg_4055) } else { arg_4050 = linked_4053.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4052, arg_4055) }; var arg_4051 any; var root_4056 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4057 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4056, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4058 lang.IFn; if linked_4057 == nil { ifn_4058 = lang.IFn_Cast(root_4056) } else { ifn_4058 = nil }; var arg_4059 any; var root_4062 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4063 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4062, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4064 lang.IFn; if linked_4063 == nil { ifn_4064 = lang.IFn_Cast(root_4062) } else { ifn_4064 = nil }; var arg_4065 any = sm__10; var arg_4066 any = A_arbace_go_check_A_const_313; if linked_4063 == nil { arg_4059 = ifn_4064.Invoke_O_O__O(arg_4065, arg_4066) } else { arg_4059 = linked_4063.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4062, arg_4065, arg_4066) }; var arg_4060 any = A_arbace_go_check_A_const_351; var arg_4061 any = Lit_18; if linked_4057 == nil { arg_4051 = ifn_4058.Invoke_O_O_O__O(arg_4059, arg_4060, arg_4061) } else { arg_4051 = linked_4057.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4056, arg_4059, arg_4060, arg_4061) }; if linked_4048 == nil { ifn_4049.Invoke_O_O__O(arg_4050, arg_4051) } else { linked_4048.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4047, arg_4050, arg_4051) }
		var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp45 any; var root_4072 any = A_arbace_go_check_A_const_345.GetRawRoot__O(); var linked_4073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4072, A_arbace_go_check_reference_path_A_fn_class); var ifn_4074 lang.IFn; if linked_4073 == nil { ifn_4074 = lang.IFn_Cast(root_4072) } else { ifn_4074 = nil }; var arg_4075 any = corpus__0; if linked_4073 == nil { tmp45 = ifn_4074.Invoke_O__O(arg_4075) } else { tmp45 = linked_4073.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4072, arg_4075) }; tmp44.Invoke_O_O__O(Lit_19, tmp45)
//line :618:1
		return clean__14 } else { var tmp46 any; var root_3801 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3801, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3803 lang.IFn



			if linked_3802 == nil { ifn_3803 = lang.IFn_Cast(root_3801) } else { ifn_3803 = nil }; var arg_3804 any = clean__14; if linked_3802 == nil { tmp46 = ifn_3803.Invoke_O__O(arg_3804) } else { tmp46 = linked_3802.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3801, arg_3804) }
//line :618:1
			if jrt.J2g_Truth(tmp46) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp48 any; var root_4082 any = A_arbace_go_check_A_const_345.GetRawRoot__O(); var linked_4083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4082, A_arbace_go_check_reference_path_A_fn_class); var ifn_4084 lang.IFn; if linked_4083 == nil { ifn_4084 = lang.IFn_Cast(root_4082) } else { ifn_4084 = nil }; var arg_4085 any = corpus__0; if linked_4083 == nil { tmp48 = ifn_4084.Invoke_O__O(arg_4085) } else { tmp48 = linked_4083.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4082, arg_4085) }; tmp47.Invoke_O_O_O__O(Lit_20, tmp48, Lit_21)
//line :618:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp49 any; var root_3805 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3805, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3807 lang.IFn





					if linked_3806 == nil { ifn_3807 = lang.IFn_Cast(root_3805) } else { ifn_3807 = nil }; var arg_3808 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_3806 == nil { tmp49 = ifn_3807.Invoke_O__O(arg_3808) } else { tmp49 = linked_3806.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3805, arg_3808) }
//line :618:1
					if jrt.J2g_Truth(tmp49) {





						var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp51 any; var root_4092 any = A_arbace_go_check_A_const_345.GetRawRoot__O(); var linked_4093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4092, A_arbace_go_check_reference_path_A_fn_class); var ifn_4094 lang.IFn; if linked_4093 == nil { ifn_4094 = lang.IFn_Cast(root_4092) } else { ifn_4094 = nil }; var arg_4095 any = corpus__0; if linked_4093 == nil { tmp51 = ifn_4094.Invoke_O__O(arg_4095) } else { tmp51 = linked_4093.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4092, arg_4095) }; tmp50.Invoke_O_O_O__O(Lit_22, tmp51, Lit_23)
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()); var tmp54 any; var root_4105 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4105, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4107 lang.IFn; if linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any = ref__13; var arg_4109 any = A_arbace_go_check_A_const_351; if linked_4106 == nil { tmp54 = ifn_4107.Invoke_O_O__O(arg_4108, arg_4109) } else { tmp54 = linked_4106.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4105, arg_4108, arg_4109) }; tmp52.Invoke_O_O__O(Lit_24, tmp53.Invoke_O__O(tmp54))
						var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()); var tmp57 any; var root_4119 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4119, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4121 lang.IFn; if linked_4120 == nil { ifn_4121 = lang.IFn_Cast(root_4119) } else { ifn_4121 = nil }; var arg_4122 any = sm__10; var arg_4123 any = A_arbace_go_check_A_const_313; if linked_4120 == nil { tmp57 = ifn_4121.Invoke_O_O__O(arg_4122, arg_4123) } else { tmp57 = linked_4120.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4119, arg_4122, arg_4123) }; tmp55.Invoke_O_O__O(Lit_25, tmp56.Invoke_O__O(tmp57))
//line :618:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :607:1
func A_arbace_go_check_annotations_iter__1685000460__1685000466_A_New() *A_arbace_go_check_annotations_iter__1685000460__1685000466_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000460__1685000466_A{}; t.Ctor(); return t }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_A) Ctor() {}
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_A) Invoke_O_O__O(self, s__1685000461__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A_New_O_O(s__1685000461__1, self); var tmp2 *jrt.Class; var fncls__3910 *jrt.Class = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A_fn_class; if fncls__3910 == nil { var fncls__3910d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A_fn_class = fncls__3910d; tmp2 = fncls__3910d } else { tmp2 = fncls__3910 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :607:1
func A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A{}; t.Ctor_O_O(p0, p1); return t }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A) Ctor_O_O(c__s__1685000461, c__iter__1685000460 any) { t.F_s__1685000461 = c__s__1685000461; t.F_iter__1685000460 = c__iter__1685000460 }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A) Invoke_O__O(self any) any { { var s__1685000461__1 any; var t_ any = t.F_s__1685000461; t.F_s__1685000461 = nil; s__1685000461__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3826 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3826, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3828 lang.IFn; if linked_3827 == nil { ifn_3828 = lang.IFn_Cast(root_3826) } else { ifn_3828 = nil }; var arg_3829 any = s__1685000461__1; if linked_3827 == nil { temp__1927000414__auto____2 = ifn_3828.Invoke_O__O(arg_3829) } else { temp__1927000414__auto____2 = linked_3827.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3826, arg_3829) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3830 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3830, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3832 lang.IFn; if linked_3831 == nil { ifn_3832 = lang.IFn_Cast(root_3830) } else { ifn_3832 = nil }; var arg_3833 any = xs__1927001018__auto____3; if linked_3831 == nil { r__4 = ifn_3832.Invoke_O__O(arg_3833) } else { r__4 = linked_3831.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3830, arg_3833) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3892 *jrt.Class = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A_fn_class; if fncls__3892 == nil { var fncls__3892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A_fn_class = fncls__3892d; tmp2 = fncls__3892d } else { tmp2 = fncls__3892 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3893 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3893, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3895 lang.IFn; if linked_3894 == nil { ifn_3895 = lang.IFn_Cast(root_3893) } else { ifn_3895 = nil }; var arg_3896 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_164.Invoke_O__O(r__4)); if linked_3894 == nil { fs__1927001036__auto____6 = ifn_3895.Invoke_O__O(arg_3896) } else { fs__1927001036__auto____6 = linked_3894.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3893, arg_3896) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3897 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_3898 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3897, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3899 lang.IFn; if linked_3898 == nil { ifn_3899 = lang.IFn_Cast(root_3897) } else { ifn_3899 = nil }; var arg_3900 any = fs__1927001036__auto____6; var arg_3901 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000460); var tmp4 any; var root_3902 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = s__1685000461__1; if linked_3903 == nil { tmp4 = ifn_3904.Invoke_O__O(arg_3905) } else { tmp4 = linked_3903.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3902, arg_3905) }; arg_3901 = tmp3.Invoke_O__O(tmp4); if linked_3898 == nil { return ifn_3899.Invoke_O_O__O(arg_3900, arg_3901) } else { return linked_3898.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3897, arg_3900, arg_3901) } } else { var tmp5 any; var root_3906 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3908 lang.IFn; if linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any = s__1685000461__1; if linked_3907 == nil { tmp5 = ifn_3908.Invoke_O__O(arg_3909) } else { tmp5 = linked_3907.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3906, arg_3909) }; s__1685000461__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :607:1
func A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A{}; t.Ctor_O(p0); return t }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A) Invoke_O_O__O(self, s__1685000463__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A_New_O_O_O(t.F_r, s__1685000463__1, self); var tmp2 *jrt.Class; var fncls__3891 *jrt.Class = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A_fn_class; if fncls__3891 == nil { var fncls__3891d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A_fn_class = fncls__3891d; tmp2 = fncls__3891d } else { tmp2 = fncls__3891 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :607:1
func A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A) Ctor_O_O_O(c__r, c__s__1685000463, c__iter__1685000462 any) { t.F_r = c__r; t.F_s__1685000463 = c__s__1685000463; t.F_iter__1685000462 = c__iter__1685000462 }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A) Invoke_O__O(self any) any { { var s__1685000463__1 any; var t_ any = t.F_s__1685000463; t.F_s__1685000463 = nil; s__1685000463__1 = t_; for { var temp__1927000414__auto____2 any; var root_3834 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3834, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3836 lang.IFn; if linked_3835 == nil { ifn_3836 = lang.IFn_Cast(root_3834) } else { ifn_3836 = nil }; var arg_3837 any = s__1685000463__1; if linked_3835 == nil { temp__1927000414__auto____2 = ifn_3836.Invoke_O__O(arg_3837) } else { temp__1927000414__auto____2 = linked_3835.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3834, arg_3837) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000463__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3838 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3838, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3840 lang.IFn; if linked_3839 == nil { ifn_3840 = lang.IFn_Cast(root_3838) } else { ifn_3840 = nil }; var arg_3841 any = s__1685000463__3; if linked_3839 == nil { tmp1 = ifn_3840.Invoke_O__O(arg_3841) } else { tmp1 = linked_3839.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3838, arg_3841) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3842 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3842, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3844 lang.IFn; if linked_3843 == nil { ifn_3844 = lang.IFn_Cast(root_3842) } else { ifn_3844 = nil }; var arg_3845 any = s__1685000463__3; if linked_3843 == nil { c__1927001037__auto____4 = ifn_3844.Invoke_O__O(arg_3845) } else { c__1927001037__auto____4 = linked_3843.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3842, arg_3845) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000465__6 any; var root_3846 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3846, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3848 lang.IFn; if linked_3847 == nil { ifn_3848 = lang.IFn_Cast(root_3846) } else { ifn_3848 = nil }; var arg_3849 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3847 == nil { b__1685000465__6 = ifn_3848.Invoke_O__O(arg_3849) } else { b__1685000465__6 = linked_3847.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3846, arg_3849) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A_New_O_O_I_O(b__1685000465__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3855 *jrt.Class = A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A_fn_class; if fncls__3855 == nil { var fncls__3855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A_fn_class = fncls__3855d; tmp3 = fncls__3855d } else { tmp3 = fncls__3855 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3856 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3856, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3858 lang.IFn; if linked_3857 == nil { ifn_3858 = lang.IFn_Cast(root_3856) } else { ifn_3858 = nil }; var arg_3859 any; var root_3861 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3861, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3863 lang.IFn; if linked_3862 == nil { ifn_3863 = lang.IFn_Cast(root_3861) } else { ifn_3863 = nil }; var arg_3864 any = b__1685000465__6; if linked_3862 == nil { arg_3859 = ifn_3863.Invoke_O__O(arg_3864) } else { arg_3859 = linked_3862.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3861, arg_3864) }; var arg_3860 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000462); var tmp5 any; var root_3865 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3865, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3867 lang.IFn; if linked_3866 == nil { ifn_3867 = lang.IFn_Cast(root_3865) } else { ifn_3867 = nil }; var arg_3868 any = s__1685000463__3; if linked_3866 == nil { tmp5 = ifn_3867.Invoke_O__O(arg_3868) } else { tmp5 = linked_3866.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3865, arg_3868) }; arg_3860 = tmp4.Invoke_O__O(tmp5); if linked_3857 == nil { return ifn_3858.Invoke_O_O__O(arg_3859, arg_3860) } else { return linked_3857.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3856, arg_3859, arg_3860) } } else { var root_3869 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3869, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3871 lang.IFn; if linked_3870 == nil { ifn_3871 = lang.IFn_Cast(root_3869) } else { ifn_3871 = nil }; var arg_3872 any; var root_3874 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3874, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3876 lang.IFn; if linked_3875 == nil { ifn_3876 = lang.IFn_Cast(root_3874) } else { ifn_3876 = nil }; var arg_3877 any = b__1685000465__6; if linked_3875 == nil { arg_3872 = ifn_3876.Invoke_O__O(arg_3877) } else { arg_3872 = linked_3875.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3874, arg_3877) }; var arg_3873 any; if linked_3870 == nil { return ifn_3871.Invoke_O_O__O(arg_3872, arg_3873) } else { return linked_3870.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3869, arg_3872, arg_3873) } } } else { var u__4 any; var root_3878 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3878, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3880 lang.IFn; if linked_3879 == nil { ifn_3880 = lang.IFn_Cast(root_3878) } else { ifn_3880 = nil }; var arg_3881 any = s__1685000463__3; if linked_3879 == nil { u__4 = ifn_3880.Invoke_O__O(arg_3881) } else { u__4 = linked_3879.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3878, arg_3881) }; var root_3882 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3882, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3884 lang.IFn; if linked_3883 == nil { ifn_3884 = lang.IFn_Cast(root_3882) } else { ifn_3884 = nil }; var arg_3885 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), u__4); var arg_3886 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000462); var tmp7 any; var root_3887 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3887, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3889 lang.IFn; if linked_3888 == nil { ifn_3889 = lang.IFn_Cast(root_3887) } else { ifn_3889 = nil }; var arg_3890 any = s__1685000463__3; if linked_3888 == nil { tmp7 = ifn_3889.Invoke_O__O(arg_3890) } else { tmp7 = linked_3888.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3887, arg_3890) }; arg_3886 = tmp6.Invoke_O__O(tmp7); if linked_3883 == nil { return ifn_3884.Invoke_O_O__O(arg_3885, arg_3886) } else { return linked_3883.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3882, arg_3885, arg_3886) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :607:1
func A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A) Ctor_O_O_I_O(c__b__1685000465, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000465 = c__b__1685000465; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :607:1
func (t *A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A) Invoke_O__O(self any) any { { var i__1685000464__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000464__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000464__1)); var root_3850 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3850, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3852 lang.IFn; if linked_3851 == nil { ifn_3852 = lang.IFn_Cast(root_3850) } else { ifn_3852 = nil }; var arg_3853 any = t.F_b__1685000465; var arg_3854 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), u__2); if linked_3851 == nil { ifn_3852.Invoke_O_O__O(arg_3853, arg_3854) } else { linked_3851.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3850, arg_3853, arg_3854) }; i__1685000464__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000464__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :630:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000481__2 any = args__0; var seq__1685000482__3 any; var root_4124 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4126 lang.IFn; if


	linked_4125 == nil { ifn_4126 = lang.IFn_Cast(root_4124) } else { ifn_4126 = nil }; var arg_4127 any = vec__1685000481__2; if linked_4125 == nil { seq__1685000482__3 = ifn_4126.Invoke_O__O(arg_4127) } else { seq__1685000482__3 = linked_4125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4124, arg_4127) }; var first__1685000483__4 any; var root_4128 any = /*line :630:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4128, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4130 lang.IFn; if


	linked_4129 == nil { ifn_4130 = lang.IFn_Cast(root_4128) } else { ifn_4130 = nil }; var arg_4131 any = seq__1685000482__3; if linked_4129 == nil { first__1685000483__4 = ifn_4130.Invoke_O__O(arg_4131) } else { first__1685000483__4 = linked_4129.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4128, arg_4131) }; var seq__1685000482__5 any; var root_4132 any = /*line :630:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4132, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4134 lang.IFn; if


	linked_4133 == nil { ifn_4134 = lang.IFn_Cast(root_4132) } else { ifn_4134 = nil }; var arg_4135 any = seq__1685000482__3; if linked_4133 == nil { seq__1685000482__5 = ifn_4134.Invoke_O__O(arg_4135) } else { seq__1685000482__5 = linked_4133.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4132, arg_4135) }; var cmd__6 any = first__1685000483__4; var args__7 any = seq__1685000482__5; var G__1685000484__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000484__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000484__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000485_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4199 /*line :634:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000485_A_fn_class

		if fncls__4199 == nil { var fncls__4199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000485_A_fn_class = fncls__4199d; tmp2 = fncls__4199d } else { tmp2 = fncls__4199 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :634:1
		var cs__10 any; var tmp3 any; var root_4200 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4200, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4202 lang.IFn









		if linked_4201 == nil { ifn_4202 = lang.IFn_Cast(root_4200) } else { ifn_4202 = nil }; var arg_4203 any = A_arbace_go_check_A_const_368.Invoke_O__O(opts__9); if linked_4201 == nil { tmp3 = ifn_4202.Invoke_O__O(arg_4203) } else { tmp3 = linked_4201.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4200, arg_4203) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_368.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_371.GetRawRoot__O() }
//line :634:1
		var ok__11 any; var root_4204 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_4205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4204, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4206 lang.IFn










		if linked_4205 == nil { ifn_4206 = lang.IFn_Cast(root_4204) } else { ifn_4206 = nil }; var arg_4207 any; var iter__1927001039__auto____11 any; var tmp4 any = A_arbace_go_check__main_iter__1685000488__1685000492_A_New_O(opts__9); var tmp5 *jrt.Class; var fncls__4276 *jrt.Class = A_arbace_go_check__main_iter__1685000488__1685000492_A_fn_class; if fncls__4276 == nil { var fncls__4276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_iter__1685000488__1685000492_A_fn_class = fncls__4276d; tmp5 = fncls__4276d } else { tmp5 = fncls__4276 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_4207 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(cs__10); if linked_4205 == nil { ok__11 = ifn_4206.Invoke_O__O(arg_4207) } else { ok__11 = linked_4205.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4204, arg_4207) }
		var root_4282 any = A_arbace_go_check_A_const_375.GetRawRoot__O(); var linked_4283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4282, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4284 lang.IFn; if linked_4283 == nil { ifn_4284 = lang.IFn_Cast(root_4282) } else { ifn_4284 = nil }; if linked_4283 == nil { ifn_4284.Invoke__O() } else { linked_4283.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4282) }
		var tmp6 int64; var tmp7 any; var root_4277 any = A_arbace_go_check_A_const_373.GetRawRoot__O(); var linked_4278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4277, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4279 lang.IFn; if linked_4278 == nil { ifn_4279 = lang.IFn_Cast(root_4277) } else { ifn_4279 = nil }; var arg_4280 any = A_arbace_go_check_A_const_374.GetRawRoot__O(); var arg_4281 any = ok__11; if linked_4278 == nil { tmp7 = ifn_4279.Invoke_O_O__O(arg_4280, arg_4281) } else { tmp7 = linked_4278.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4277, arg_4280, arg_4281) }; if jrt.J2g_Truth(tmp7) { tmp6 = 0 } else { tmp6 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp6)); return nil }
//line :634:1
	default:};













	lang.IFn_Cast(A_arbace_go_check_A_const_356.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :636:1
func A_arbace_go_check__main_fn__1685000485_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000485_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000485_A{}; t.Ctor_O(p0); return t }
//line :636:1
func (t *A_arbace_go_check__main_fn__1685000485_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :636:1
func (t *A_arbace_go_check__main_fn__1685000485_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_339; var tmp2 any = A_arbace_go_check_A_const_367; var tmp3 any = A_arbace_go_check_A_const_341; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_270.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_368, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_4137 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_4138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4137, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4139 lang.IFn; if linked_4138 == nil { ifn_4139 = lang.IFn_Cast(root_4137) } else { ifn_4139 = nil }; var arg_4140 any = as__1; if linked_4138 == nil { tmp4 = ifn_4139.Invoke_O__O(arg_4140) } else { tmp4 = linked_4138.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4137, arg_4140) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000486__3_ any; var root_4141 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4141, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4143 lang.IFn

		if linked_4142 == nil { ifn_4143 = lang.IFn_Cast(root_4141) } else { ifn_4143 = nil }; var arg_4144 any = as__1; if linked_4142 == nil { G__1685000486__3_ = ifn_4143.Invoke_O__O(arg_4144) } else { G__1685000486__3_ = linked_4142.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4141, arg_4144) }; switch lang.Util_Hash_O__I_NoInit(G__1685000486__3_) >> 10 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000486__3_, Lit_6) {

			var tmp5 any; var root_4146 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4146, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4148 lang.IFn; if linked_4147 == nil { ifn_4148 = lang.IFn_Cast(root_4146) } else { ifn_4148 = nil }; var arg_4149 any = as__1; if linked_4147 == nil { tmp5 = ifn_4148.Invoke_O__O(arg_4149) } else { tmp5 = linked_4147.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4146, arg_4149) }; var tmp6 any = tmp5; var tmp7 any; var root_4150 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4150, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4152 lang.IFn; if linked_4151 == nil { ifn_4152 = lang.IFn_Cast(root_4150) } else { ifn_4152 = nil }; var arg_4153 any = o__2; var arg_4154 any = A_arbace_go_check_A_const_339; var arg_4155 any; var tmp8 any; var root_4156 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4156, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4158 lang.IFn; if linked_4157 == nil { ifn_4158 = lang.IFn_Cast(root_4156) } else { ifn_4158 = nil }; var arg_4159 any = as__1; if linked_4157 == nil { tmp8 = ifn_4158.Invoke_O__O(arg_4159) } else { tmp8 = linked_4157.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4156, arg_4159) }; arg_4155 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp8))).Ref(); if linked_4151 == nil { tmp7 = ifn_4152.Invoke_O_O_O__O(arg_4153, arg_4154, arg_4155) } else { tmp7 = linked_4151.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4150, arg_4153, arg_4154, arg_4155) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :639:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000486__3_, Lit_7) {
			var tmp9 any; var root_4160 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_4161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4160, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4162 lang.IFn; if linked_4161 == nil { ifn_4162 = lang.IFn_Cast(root_4160) } else { ifn_4162 = nil }; var arg_4163 any = as__1; if linked_4161 == nil { tmp9 = ifn_4162.Invoke_O__O(arg_4163) } else { tmp9 = linked_4161.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4160, arg_4163) }; var tmp10 any = tmp9; var tmp11 any; var root_4164 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4164, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4166 lang.IFn; if linked_4165 == nil { ifn_4166 = lang.IFn_Cast(root_4164) } else { ifn_4166 = nil }; var arg_4167 any = o__2; var arg_4168 any = A_arbace_go_check_A_const_340; var arg_4169 any = jrt.Boolean_TRUE.Ref(); if linked_4165 == nil { tmp11 = ifn_4166.Invoke_O_O_O__O(arg_4167, arg_4168, arg_4169) } else { tmp11 = linked_4165.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4164, arg_4167, arg_4168, arg_4169) }; as__1, o__2 = tmp10, tmp11; continue L1 }
//line :639:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000486__3_, Lit_8) {


			var tmp12 any; var root_4170 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4170, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4172 lang.IFn; if linked_4171 == nil { ifn_4172 = lang.IFn_Cast(root_4170) } else { ifn_4172 = nil }; var arg_4173 any = as__1; if linked_4171 == nil { tmp12 = ifn_4172.Invoke_O__O(arg_4173) } else { tmp12 = linked_4171.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4170, arg_4173) }; var tmp13 any = tmp12; var tmp14 any; var root_4174 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4174, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4176 lang.IFn; if linked_4175 == nil { ifn_4176 = lang.IFn_Cast(root_4174) } else { ifn_4176 = nil }; var arg_4177 any = o__2; var arg_4178 any = A_arbace_go_check_A_const_341; var arg_4179 any; var root_4180 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4180, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4182 lang.IFn; if linked_4181 == nil { ifn_4182 = lang.IFn_Cast(root_4180) } else { ifn_4182 = nil }; var arg_4183 any = as__1; if linked_4181 == nil { arg_4179 = ifn_4182.Invoke_O__O(arg_4183) } else { arg_4179 = linked_4181.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4180, arg_4183) }; if linked_4175 == nil { tmp14 = ifn_4176.Invoke_O_O_O__O(arg_4177, arg_4178, arg_4179) } else { tmp14 = linked_4175.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4174, arg_4177, arg_4178, arg_4179) }; as__1, o__2 = tmp13, tmp14; continue L1 }
//line :639:1
		default:
		}


		var tmp15 any; var root_4184 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_4185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4184, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4186 lang.IFn; if linked_4185 == nil { ifn_4186 = lang.IFn_Cast(root_4184) } else { ifn_4186 = nil }; var arg_4187 any = as__1; if linked_4185 == nil { tmp15 = ifn_4186.Invoke_O__O(arg_4187) } else { tmp15 = linked_4185.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4184, arg_4187) }; var tmp16 any = tmp15; var tmp17 any; var root_4188 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4189 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4188, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4190 lang.IFn; if linked_4189 == nil { ifn_4190 = lang.IFn_Cast(root_4188) } else { ifn_4190 = nil }; var arg_4191 any = o__2; var arg_4192 any = A_arbace_go_check_A_const_368; var arg_4193 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4194 any; var root_4195 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4197 lang.IFn; if linked_4196 == nil { ifn_4197 = lang.IFn_Cast(root_4195) } else { ifn_4197 = nil }; var arg_4198 any = as__1; if linked_4196 == nil { arg_4194 = ifn_4197.Invoke_O__O(arg_4198) } else { arg_4194 = linked_4196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4195, arg_4198) }; if linked_4189 == nil { tmp17 = ifn_4190.Invoke_O_O_O_O__O(arg_4191, arg_4192, arg_4193, arg_4194) } else { tmp17 = linked_4189.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4188, arg_4191, arg_4192, arg_4193, arg_4194) }; as__1, o__2 = tmp16, tmp17; continue L1 } } }; /*line :636:1*/panic("j2g: unreachable") }








func A_arbace_go_check__main_iter__1685000488__1685000492_A_New_O(p0 any) *A_arbace_go_check__main_iter__1685000488__1685000492_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000488__1685000492_A{}; t.Ctor_O(p0); return t }
//line :645:1
func (t *A_arbace_go_check__main_iter__1685000488__1685000492_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :645:1
func (t *A_arbace_go_check__main_iter__1685000488__1685000492_A) Invoke_O_O__O(self, s__1685000489__1 any) any { var tmp1 any = A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A_New_O_O_O(t.F_opts, s__1685000489__1, self); var tmp2 *jrt.Class; var fncls__4275 *jrt.Class = A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A_fn_class; if fncls__4275 == nil { var fncls__4275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A_fn_class = fncls__4275d; tmp2 = fncls__4275d } else { tmp2 = fncls__4275 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :645:1
func A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :645:1
func (t *A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A) Ctor_O_O_O(c__opts, c__s__1685000489, c__iter__1685000488 any) { t.F_opts = c__opts; t.F_s__1685000489 = c__s__1685000489; t.F_iter__1685000488 = c__iter__1685000488 }
//line :645:1
func (t *A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A) Invoke_O__O(self any) any { { var s__1685000489__1 any; var t_ any = t.F_s__1685000489; t.F_s__1685000489 = nil; s__1685000489__1 = t_; for { var temp__1927000414__auto____2 any; var root_4208 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4208, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4210 lang.IFn; if linked_4209 == nil { ifn_4210 = lang.IFn_Cast(root_4208) } else { ifn_4210 = nil }; var arg_4211 any = s__1685000489__1; if linked_4209 == nil { temp__1927000414__auto____2 = ifn_4210.Invoke_O__O(arg_4211) } else { temp__1927000414__auto____2 = linked_4209.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4208, arg_4211) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000489__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4212 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4212, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4214 lang.IFn; if linked_4213 == nil { ifn_4214 = lang.IFn_Cast(root_4212) } else { ifn_4214 = nil }; var arg_4215 any = s__1685000489__3; if linked_4213 == nil { tmp1 = ifn_4214.Invoke_O__O(arg_4215) } else { tmp1 = linked_4213.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4212, arg_4215) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4216 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4216, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4218 lang.IFn; if linked_4217 == nil { ifn_4218 = lang.IFn_Cast(root_4216) } else { ifn_4218 = nil }; var arg_4219 any = s__1685000489__3; if linked_4217 == nil { c__1927001037__auto____4 = ifn_4218.Invoke_O__O(arg_4219) } else { c__1927001037__auto____4 = linked_4217.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4216, arg_4219) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000491__6 any; var root_4220 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_4221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4220, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4222 lang.IFn; if linked_4221 == nil { ifn_4222 = lang.IFn_Cast(root_4220) } else { ifn_4222 = nil }; var arg_4223 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4221 == nil { b__1685000491__6 = ifn_4222.Invoke_O__O(arg_4223) } else { b__1685000491__6 = linked_4221.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4220, arg_4223) }; var tmp2 any = A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A_New_O_O_I_O(t.F_opts, b__1685000491__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4234 *jrt.Class = A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A_fn_class; if fncls__4234 == nil { var fncls__4234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A_fn_class = fncls__4234d; tmp3 = fncls__4234d } else { tmp3 = fncls__4234 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4235 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_4236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4235, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4237 lang.IFn; if linked_4236 == nil { ifn_4237 = lang.IFn_Cast(root_4235) } else { ifn_4237 = nil }; var arg_4238 any; var root_4240 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4240, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4242 lang.IFn; if linked_4241 == nil { ifn_4242 = lang.IFn_Cast(root_4240) } else { ifn_4242 = nil }; var arg_4243 any = b__1685000491__6; if linked_4241 == nil { arg_4238 = ifn_4242.Invoke_O__O(arg_4243) } else { arg_4238 = linked_4241.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4240, arg_4243) }; var arg_4239 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000488); var tmp5 any; var root_4244 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4244, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4246 lang.IFn; if linked_4245 == nil { ifn_4246 = lang.IFn_Cast(root_4244) } else { ifn_4246 = nil }; var arg_4247 any = s__1685000489__3; if linked_4245 == nil { tmp5 = ifn_4246.Invoke_O__O(arg_4247) } else { tmp5 = linked_4245.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4244, arg_4247) }; arg_4239 = tmp4.Invoke_O__O(tmp5); if linked_4236 == nil { return ifn_4237.Invoke_O_O__O(arg_4238, arg_4239) } else { return linked_4236.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4235, arg_4238, arg_4239) } } else { var root_4248 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_4249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4248, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4250 lang.IFn; if linked_4249 == nil { ifn_4250 = lang.IFn_Cast(root_4248) } else { ifn_4250 = nil }; var arg_4251 any; var root_4253 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4253, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4255 lang.IFn; if linked_4254 == nil { ifn_4255 = lang.IFn_Cast(root_4253) } else { ifn_4255 = nil }; var arg_4256 any = b__1685000491__6; if linked_4254 == nil { arg_4251 = ifn_4255.Invoke_O__O(arg_4256) } else { arg_4251 = linked_4254.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4253, arg_4256) }; var arg_4252 any; if linked_4249 == nil { return ifn_4250.Invoke_O_O__O(arg_4251, arg_4252) } else { return linked_4249.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4248, arg_4251, arg_4252) } } } else { var c__4 any; var root_4257 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4259 lang.IFn; if linked_4258 == nil { ifn_4259 = lang.IFn_Cast(root_4257) } else { ifn_4259 = nil }; var arg_4260 any = s__1685000489__3; if linked_4258 == nil { c__4 = ifn_4259.Invoke_O__O(arg_4260) } else { c__4 = linked_4258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4257, arg_4260) }; var root_4261 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4261, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4263 lang.IFn; if linked_4262 == nil { ifn_4263 = lang.IFn_Cast(root_4261) } else { ifn_4263 = nil }; var arg_4264 any; var root_4266 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4266, A_arbace_go_check_annotations_A_fn_class); var ifn_4268 lang.IFn; if linked_4267 == nil { ifn_4268 = lang.IFn_Cast(root_4266) } else { ifn_4268 = nil }; var arg_4269 any = c__4; var arg_4270 any = t.F_opts; if linked_4267 == nil { arg_4264 = ifn_4268.Invoke_O_O__O(arg_4269, arg_4270) } else { arg_4264 = linked_4267.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4266, arg_4269, arg_4270) }; var arg_4265 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000488); var tmp7 any; var root_4271 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_4272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4271, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4273 lang.IFn; if linked_4272 == nil { ifn_4273 = lang.IFn_Cast(root_4271) } else { ifn_4273 = nil }; var arg_4274 any = s__1685000489__3; if linked_4272 == nil { tmp7 = ifn_4273.Invoke_O__O(arg_4274) } else { tmp7 = linked_4272.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4271, arg_4274) }; arg_4265 = tmp6.Invoke_O__O(tmp7); if linked_4262 == nil { return ifn_4263.Invoke_O_O__O(arg_4264, arg_4265) } else { return linked_4262.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4261, arg_4264, arg_4265) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :645:1
func A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :645:1
func (t *A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A) Ctor_O_O_I_O(c__opts, c__b__1685000491 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_opts = c__opts; t.F_b__1685000491 = c__b__1685000491; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :645:1
func (t *A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A) Invoke_O__O(self any) any { { var i__1685000490__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000490__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000490__1)); var root_4224 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_4225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4224, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4226 lang.IFn; if linked_4225 == nil { ifn_4226 = lang.IFn_Cast(root_4224) } else { ifn_4226 = nil }; var arg_4227 any = t.F_b__1685000491; var arg_4228 any; var root_4229 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4229, A_arbace_go_check_annotations_A_fn_class); var ifn_4231 lang.IFn; if linked_4230 == nil { ifn_4231 = lang.IFn_Cast(root_4229) } else { ifn_4231 = nil }; var arg_4232 any = c__2; var arg_4233 any = t.F_opts; if linked_4230 == nil { arg_4228 = ifn_4231.Invoke_O_O__O(arg_4232, arg_4233) } else { arg_4228 = linked_4230.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4229, arg_4232, arg_4233) }; if linked_4225 == nil { ifn_4226.Invoke_O_O__O(arg_4227, arg_4228) } else { linked_4225.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4224, arg_4227, arg_4228) }; i__1685000490__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000490__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
































































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Keyword

var A_arbace_go_check_A_const_55 *lang.Var

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Keyword

var A_arbace_go_check_A_const_61 *lang.Var

var A_arbace_go_check_A_const_62 *lang.Keyword

var A_arbace_go_check_A_const_63 *lang.Var

var A_arbace_go_check_A_const_64 *lang.Keyword

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Var

var A_arbace_go_check_A_const_67 *lang.Keyword

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Var

var A_arbace_go_check_A_const_73 *lang.Keyword

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Var

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 any

var A_arbace_go_check_A_const_78 *lang.Keyword

var A_arbace_go_check_A_const_79 *lang.Var

var A_arbace_go_check_A_const_80 *lang.Keyword

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Var

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Keyword

var A_arbace_go_check_A_const_90 *lang.Var

var A_arbace_go_check_A_const_91 *lang.Keyword

var A_arbace_go_check_A_const_92 *lang.Var

var A_arbace_go_check_A_const_93 *lang.Keyword

var A_arbace_go_check_A_const_94 any

var A_arbace_go_check_A_const_95 *lang.Keyword

var A_arbace_go_check_A_const_96 *lang.Var

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 any

var A_arbace_go_check_A_const_99 *lang.Keyword

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Var

var A_arbace_go_check_A_const_102 *lang.Var

var A_arbace_go_check_A_const_103 *lang.Var

var A_arbace_go_check_A_const_104 *lang.Var

var A_arbace_go_check_A_const_105 *lang.Var

var A_arbace_go_check_A_const_106 *lang.Keyword

var A_arbace_go_check_A_const_107 *lang.Var

var A_arbace_go_check_A_const_108 *lang.Keyword

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Keyword

var A_arbace_go_check_A_const_113 *lang.Keyword

var A_arbace_go_check_A_const_114 *lang.Keyword

var A_arbace_go_check_A_const_115 *lang.Keyword

var A_arbace_go_check_A_const_116 *lang.Keyword

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Keyword

var A_arbace_go_check_A_const_119 *lang.Var

var A_arbace_go_check_A_const_120 *lang.Var

var A_arbace_go_check_A_const_121 *lang.Keyword

var A_arbace_go_check_A_const_122 *lang.Var

var A_arbace_go_check_A_const_123 *lang.Var

var A_arbace_go_check_A_const_124 *lang.Keyword

var A_arbace_go_check_A_const_125 *lang.Var

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Var

var A_arbace_go_check_A_const_128 *lang.Var

var A_arbace_go_check_A_const_129 any

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Var

var A_arbace_go_check_A_const_133 any

var A_arbace_go_check_A_const_134 any

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 *lang.Keyword

var A_arbace_go_check_A_const_138 *lang.Keyword

var A_arbace_go_check_A_const_139 any

var A_arbace_go_check_A_const_140 *lang.Var

var A_arbace_go_check_A_const_141 *lang.Var

var A_arbace_go_check_A_const_142 *lang.Keyword

var A_arbace_go_check_A_const_143 *lang.Keyword

var A_arbace_go_check_A_const_144 *lang.Var

var A_arbace_go_check_A_const_145 *lang.Var

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Keyword

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Keyword

var A_arbace_go_check_A_const_151 *lang.Var

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Keyword

var A_arbace_go_check_A_const_154 *lang.Keyword

var A_arbace_go_check_A_const_155 *lang.Var

var A_arbace_go_check_A_const_156 *lang.Var

var A_arbace_go_check_A_const_157 *lang.Var

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Keyword

var A_arbace_go_check_A_const_162 *lang.Keyword

var A_arbace_go_check_A_const_163 *lang.Keyword

var A_arbace_go_check_A_const_164 *lang.Keyword

var A_arbace_go_check_A_const_165 *lang.Var

var A_arbace_go_check_A_const_166 *lang.Var

var A_arbace_go_check_A_const_167 *lang.Var

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Keyword

var A_arbace_go_check_A_const_192 *lang.Keyword

var A_arbace_go_check_A_const_193 *lang.Keyword

var A_arbace_go_check_A_const_194 *lang.Keyword

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Var

var A_arbace_go_check_A_const_197 *lang.Var

var A_arbace_go_check_A_const_198 *lang.Var

var A_arbace_go_check_A_const_199 *lang.Var

var A_arbace_go_check_A_const_200 *lang.Var

var A_arbace_go_check_A_const_201 *lang.Keyword

var A_arbace_go_check_A_const_202 *lang.Var

var A_arbace_go_check_A_const_203 *lang.Keyword

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Var

var A_arbace_go_check_A_const_206 *lang.Keyword

var A_arbace_go_check_A_const_207 *lang.Keyword

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Keyword

var A_arbace_go_check_A_const_210 *lang.Var

var A_arbace_go_check_A_const_211 *lang.Var

var A_arbace_go_check_A_const_212 *lang.Var

var A_arbace_go_check_A_const_213 *lang.Var

var A_arbace_go_check_A_const_214 *lang.Keyword

var A_arbace_go_check_A_const_215 *lang.Var

var A_arbace_go_check_A_const_216 *lang.Var

var A_arbace_go_check_A_const_217 *lang.Var

var A_arbace_go_check_A_const_218 *lang.Var

var A_arbace_go_check_A_const_219 *lang.Keyword

var A_arbace_go_check_A_const_220 *lang.Keyword

var A_arbace_go_check_A_const_221 *lang.Keyword

var A_arbace_go_check_A_const_222 *lang.Var

var A_arbace_go_check_A_const_223 *lang.Var

var A_arbace_go_check_A_const_224 *lang.Keyword

var A_arbace_go_check_A_const_225 *lang.Keyword

var A_arbace_go_check_A_const_226 *lang.Var

var A_arbace_go_check_A_const_227 *lang.Var

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Keyword

var A_arbace_go_check_A_const_230 *lang.Keyword

var A_arbace_go_check_A_const_231 *lang.Keyword

var A_arbace_go_check_A_const_232 *lang.Var

var A_arbace_go_check_A_const_233 any

var A_arbace_go_check_A_const_234 any

var A_arbace_go_check_A_const_235 *lang.Keyword

var A_arbace_go_check_A_const_236 *lang.Keyword

var A_arbace_go_check_A_const_237 *lang.Keyword

var A_arbace_go_check_A_const_238 *lang.Keyword

var A_arbace_go_check_A_const_239 *lang.Var

var A_arbace_go_check_A_const_240 *lang.Keyword

var A_arbace_go_check_A_const_241 *lang.Keyword

var A_arbace_go_check_A_const_242 *lang.Keyword

var A_arbace_go_check_A_const_243 *lang.Keyword

var A_arbace_go_check_A_const_244 *lang.Keyword

var A_arbace_go_check_A_const_245 *lang.Keyword

var A_arbace_go_check_A_const_246 *lang.Var

var A_arbace_go_check_A_const_247 *lang.Var

var A_arbace_go_check_A_const_248 *lang.Keyword

var A_arbace_go_check_A_const_249 *lang.Var

var A_arbace_go_check_A_const_250 *lang.Var

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 *lang.Keyword

var A_arbace_go_check_A_const_253 *lang.Var

var A_arbace_go_check_A_const_254 *lang.Var

var A_arbace_go_check_A_const_255 *lang.Var

var A_arbace_go_check_A_const_256 any

var A_arbace_go_check_A_const_257 *lang.Keyword

var A_arbace_go_check_A_const_258 *lang.Var

var A_arbace_go_check_A_const_259 *lang.Var

var A_arbace_go_check_A_const_260 *lang.Var

var A_arbace_go_check_A_const_261 *lang.Var

var A_arbace_go_check_A_const_262 *lang.Var

var A_arbace_go_check_A_const_263 *lang.Var

var A_arbace_go_check_A_const_264 *lang.Keyword

var A_arbace_go_check_A_const_265 *lang.Keyword

var A_arbace_go_check_A_const_266 *lang.Var

var A_arbace_go_check_A_const_267 *lang.Keyword

var A_arbace_go_check_A_const_268 *lang.Keyword

var A_arbace_go_check_A_const_269 *lang.Keyword

var A_arbace_go_check_A_const_270 *lang.Var

var A_arbace_go_check_A_const_271 *lang.Keyword

var A_arbace_go_check_A_const_272 any

var A_arbace_go_check_A_const_273 *lang.Keyword

var A_arbace_go_check_A_const_274 any

var A_arbace_go_check_A_const_275 any

var A_arbace_go_check_A_const_276 any

var A_arbace_go_check_A_const_277 *lang.Keyword

var A_arbace_go_check_A_const_278 *lang.Keyword

var A_arbace_go_check_A_const_279 any

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Var

var A_arbace_go_check_A_const_283 *lang.Var

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 any

var A_arbace_go_check_A_const_286 *lang.Var

var A_arbace_go_check_A_const_287 *lang.Keyword

var A_arbace_go_check_A_const_288 *lang.Keyword

var A_arbace_go_check_A_const_289 *lang.Keyword

var A_arbace_go_check_A_const_290 *lang.Keyword

var A_arbace_go_check_A_const_291 *lang.Var

var A_arbace_go_check_A_const_292 *lang.Var

var A_arbace_go_check_A_const_293 *lang.Var

var A_arbace_go_check_A_const_294 *lang.Var

var A_arbace_go_check_A_const_295 *lang.Var

var A_arbace_go_check_A_const_296 *lang.Var

var A_arbace_go_check_A_const_297 *lang.Keyword

var A_arbace_go_check_A_const_298 *lang.Var

var A_arbace_go_check_A_const_299 *lang.Var

var A_arbace_go_check_A_const_300 *lang.Var

var A_arbace_go_check_A_const_301 *lang.Var

var A_arbace_go_check_A_const_302 any

var A_arbace_go_check_A_const_303 *lang.Var

var A_arbace_go_check_A_const_304 any

var A_arbace_go_check_A_const_305 any

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Keyword

var A_arbace_go_check_A_const_308 *lang.Keyword

var A_arbace_go_check_A_const_309 *lang.Keyword

var A_arbace_go_check_A_const_310 *lang.Keyword

var A_arbace_go_check_A_const_311 *lang.Keyword

var A_arbace_go_check_A_const_312 *lang.Var

var A_arbace_go_check_A_const_313 *lang.Keyword

var A_arbace_go_check_A_const_314 *lang.Keyword

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Keyword

var A_arbace_go_check_A_const_317 any

var A_arbace_go_check_A_const_318 *lang.Keyword

var A_arbace_go_check_A_const_319 *lang.Keyword

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 any

var A_arbace_go_check_A_const_322 any

var A_arbace_go_check_A_const_323 *lang.Var

var A_arbace_go_check_A_const_324 *lang.Var

var A_arbace_go_check_A_const_325 any

var A_arbace_go_check_A_const_326 *lang.Var

var A_arbace_go_check_A_const_327 any

var A_arbace_go_check_A_const_328 *lang.Var

var A_arbace_go_check_A_const_329 *lang.Var

var A_arbace_go_check_A_const_330 *lang.Var

var A_arbace_go_check_A_const_331 *lang.Var

var A_arbace_go_check_A_const_332 *lang.Var

var A_arbace_go_check_A_const_333 *lang.Var

var A_arbace_go_check_A_const_334 *lang.Var

var A_arbace_go_check_A_const_335 *lang.Var

var A_arbace_go_check_A_const_336 *lang.Var

var A_arbace_go_check_A_const_337 *lang.Var

var A_arbace_go_check_A_const_338 *lang.Var

var A_arbace_go_check_A_const_339 *lang.Keyword

var A_arbace_go_check_A_const_340 *lang.Keyword

var A_arbace_go_check_A_const_341 *lang.Keyword

var A_arbace_go_check_A_const_342 *lang.Var

var A_arbace_go_check_A_const_343 *lang.Var

var A_arbace_go_check_A_const_344 *jrt.Class

var A_arbace_go_check_A_const_345 *lang.Var

var A_arbace_go_check_A_const_346 *lang.Var

var A_arbace_go_check_A_const_347 *lang.Var

var A_arbace_go_check_A_const_348 any

var A_arbace_go_check_A_const_349 any

var A_arbace_go_check_A_const_350 any

var A_arbace_go_check_A_const_351 *lang.Keyword

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 *lang.Keyword

var A_arbace_go_check_A_const_354 *lang.Keyword

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 any

var A_arbace_go_check_A_const_358 any

var A_arbace_go_check_A_const_359 any

var A_arbace_go_check_A_const_360 any

var A_arbace_go_check_A_const_361 any

var A_arbace_go_check_A_const_362 any

var A_arbace_go_check_A_const_363 *lang.Var

var A_arbace_go_check_A_const_364 any

var A_arbace_go_check_A_const_365 any

var A_arbace_go_check_A_const_366 any

var A_arbace_go_check_A_const_367 any

var A_arbace_go_check_A_const_368 *lang.Keyword

var A_arbace_go_check_A_const_369 *lang.Var

var A_arbace_go_check_A_const_370 *lang.Var

var A_arbace_go_check_A_const_371 *lang.Var

var A_arbace_go_check_A_const_372 *lang.Var

var A_arbace_go_check_A_const_373 *lang.Var

var A_arbace_go_check_A_const_374 *lang.Var

var A_arbace_go_check_A_const_375 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29(); A_arbace_go_check_A_clinit_p30() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 549); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[173]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[174]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[175]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[176]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[177]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[178]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[179]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[180]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[181]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[182]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[183]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[184]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[185]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[186]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[187]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[188]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[189]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[190]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[191]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[192]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[193]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[194]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[195]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[196]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[200]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[203]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[204]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[205]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[207]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[208]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[209]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[210] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[211]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[213]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[214]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[216]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[220]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[221]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[222]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[223]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[224]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[226]); A_arbace_go_check_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_55 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[231]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[232]); A_arbace_go_check_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[233]); A_arbace_go_check_A_const_61 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_66 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_72 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[245]); A_arbace_go_check_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[247]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_77 = A_arbace_go_check_A_const_pool.A[250]; A_arbace_go_check_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_79 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[257]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_86 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[259]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[260]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_90 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_92 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_94 = A_arbace_go_check_A_const_pool.A[267]; A_arbace_go_check_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_96 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[269]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_98 = A_arbace_go_check_A_const_pool.A[271] }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_101 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_102 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_103 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[276]); A_arbace_go_check_A_const_104 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_105 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_107 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[281]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[282]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[283]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[285]); A_arbace_go_check_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[290]); A_arbace_go_check_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_119 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_120 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[293]); A_arbace_go_check_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_122 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[295]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_124 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_125 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_127 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_128 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_129 = A_arbace_go_check_A_const_pool.A[302]; A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_132 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[305]); A_arbace_go_check_A_const_133 = A_arbace_go_check_A_const_pool.A[306]; A_arbace_go_check_A_const_134 = A_arbace_go_check_A_const_pool.A[307] }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_137 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_138 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_139 = A_arbace_go_check_A_const_pool.A[312]; A_arbace_go_check_A_const_140 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_141 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_142 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[316]); A_arbace_go_check_A_const_144 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[317]); A_arbace_go_check_A_const_145 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[319]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[320]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[321]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_150 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_151 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[324]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_153 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_154 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_155 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_156 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[329]); A_arbace_go_check_A_const_157 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_161 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_162 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_163 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_164 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_165 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_166 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_167 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_191 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_192 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[365]); A_arbace_go_check_A_const_193 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_194 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[367]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_196 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_197 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_198 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_199 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]); A_arbace_go_check_A_const_200 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_201 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_202 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_203 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[377]); A_arbace_go_check_A_const_205 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_206 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[379]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_209 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_210 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_211 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_212 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_213 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_215 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_216 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]); A_arbace_go_check_A_const_217 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_218 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[391]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_221 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_222 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_223 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_224 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_226 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_227 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[401]); A_arbace_go_check_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_230 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[403]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_232 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_233 = A_arbace_go_check_A_const_pool.A[406]; A_arbace_go_check_A_const_234 = A_arbace_go_check_A_const_pool.A[407]; A_arbace_go_check_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_239 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[413]); A_arbace_go_check_A_const_241 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_244 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_245 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_246 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_247 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_248 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_249 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_250 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[424]); A_arbace_go_check_A_const_252 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[425]); A_arbace_go_check_A_const_253 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_254 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[427]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_255 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[428]); A_arbace_go_check_A_const_256 = A_arbace_go_check_A_const_pool.A[429]; A_arbace_go_check_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[430]); A_arbace_go_check_A_const_258 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_259 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_260 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[433]); A_arbace_go_check_A_const_261 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_262 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[435]); A_arbace_go_check_A_const_263 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[436]); A_arbace_go_check_A_const_264 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_265 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]); A_arbace_go_check_A_const_266 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[439]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_267 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_268 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_269 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_270 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_271 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_272 = A_arbace_go_check_A_const_pool.A[445]; A_arbace_go_check_A_const_273 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_274 = A_arbace_go_check_A_const_pool.A[447]; A_arbace_go_check_A_const_275 = A_arbace_go_check_A_const_pool.A[448]; A_arbace_go_check_A_const_276 = A_arbace_go_check_A_const_pool.A[449]; A_arbace_go_check_A_const_277 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[450]); A_arbace_go_check_A_const_278 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[451]); A_arbace_go_check_A_const_279 = A_arbace_go_check_A_const_pool.A[452] }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_282 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_283 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[457]); A_arbace_go_check_A_const_285 = A_arbace_go_check_A_const_pool.A[458]; A_arbace_go_check_A_const_286 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_287 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_288 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_289 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[462]); A_arbace_go_check_A_const_290 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_291 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[464]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_293 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_294 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_295 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_296 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_297 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_298 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[471]); A_arbace_go_check_A_const_299 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[472]); A_arbace_go_check_A_const_300 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[473]); A_arbace_go_check_A_const_301 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[474]); A_arbace_go_check_A_const_302 = A_arbace_go_check_A_const_pool.A[475]; A_arbace_go_check_A_const_303 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[476]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_304 = A_arbace_go_check_A_const_pool.A[477]; A_arbace_go_check_A_const_305 = A_arbace_go_check_A_const_pool.A[478]; A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[479]); A_arbace_go_check_A_const_307 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[480]); A_arbace_go_check_A_const_308 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[481]); A_arbace_go_check_A_const_309 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[482]); A_arbace_go_check_A_const_310 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[483]); A_arbace_go_check_A_const_311 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[484]); A_arbace_go_check_A_const_312 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_313 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[486]); A_arbace_go_check_A_const_314 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[487]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[488]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_316 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_317 = A_arbace_go_check_A_const_pool.A[490]; A_arbace_go_check_A_const_318 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_319 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_321 = A_arbace_go_check_A_const_pool.A[494]; A_arbace_go_check_A_const_322 = A_arbace_go_check_A_const_pool.A[495]; A_arbace_go_check_A_const_323 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_324 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_325 = A_arbace_go_check_A_const_pool.A[498]; A_arbace_go_check_A_const_326 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_327 = A_arbace_go_check_A_const_pool.A[500]; A_arbace_go_check_A_const_328 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]) }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_329 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_330 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_331 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_332 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_333 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[506]); A_arbace_go_check_A_const_334 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[507]); A_arbace_go_check_A_const_335 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[508]); A_arbace_go_check_A_const_336 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[509]); A_arbace_go_check_A_const_337 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[510]); A_arbace_go_check_A_const_338 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[511]); A_arbace_go_check_A_const_339 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[512]); A_arbace_go_check_A_const_340 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[513]) }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_341 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[514]); A_arbace_go_check_A_const_342 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[515]); A_arbace_go_check_A_const_343 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[516]); A_arbace_go_check_A_const_344 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_345 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_346 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_347 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_348 = A_arbace_go_check_A_const_pool.A[521]; A_arbace_go_check_A_const_349 = A_arbace_go_check_A_const_pool.A[522]; A_arbace_go_check_A_const_350 = A_arbace_go_check_A_const_pool.A[523]; A_arbace_go_check_A_const_351 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[524]); A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[525]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_353 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[526]); A_arbace_go_check_A_const_354 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[527]); A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[528]); A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[529]); A_arbace_go_check_A_const_357 = A_arbace_go_check_A_const_pool.A[530]; A_arbace_go_check_A_const_358 = A_arbace_go_check_A_const_pool.A[531]; A_arbace_go_check_A_const_359 = A_arbace_go_check_A_const_pool.A[532]; A_arbace_go_check_A_const_360 = A_arbace_go_check_A_const_pool.A[533]; A_arbace_go_check_A_const_361 = A_arbace_go_check_A_const_pool.A[534]; A_arbace_go_check_A_const_362 = A_arbace_go_check_A_const_pool.A[535]; A_arbace_go_check_A_const_363 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[536]); A_arbace_go_check_A_const_364 = A_arbace_go_check_A_const_pool.A[537]; A_arbace_go_check_A_const_365 = A_arbace_go_check_A_const_pool.A[538]; A_arbace_go_check_A_const_366 = A_arbace_go_check_A_const_pool.A[539] }

func A_arbace_go_check_A_clinit_p30() { A_arbace_go_check_A_const_367 = A_arbace_go_check_A_const_pool.A[540]; A_arbace_go_check_A_const_368 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[541]); A_arbace_go_check_A_const_369 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[542]); A_arbace_go_check_A_const_370 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[543]); A_arbace_go_check_A_const_371 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[544]); A_arbace_go_check_A_const_372 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[545]); A_arbace_go_check_A_const_373 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[546]); A_arbace_go_check_A_const_374 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[547]); A_arbace_go_check_A_const_375 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[548]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000485_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000485_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000488__1685000492_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_iter__1685000488__1685000492_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A struct{ j2g_header uint64; F_opts, F_s__1685000489, F_iter__1685000488 any }

var A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A struct{ j2g_header uint64; F_opts, F_b__1685000491 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_iter__1685000488__1685000492_fn__1685000493_fn__1685000494_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000460__1685000466_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000460__1685000466_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A struct{ j2g_header uint64; F_s__1685000461, F_iter__1685000460 any }

var A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A struct{ j2g_header uint64; F_r, F_s__1685000463, F_iter__1685000462 any }

var A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A struct{ j2g_header uint64; F_b__1685000465, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_annotations_iter__1685000460__1685000466_fn__1685000467_iter__1685000462__1685000468_fn__1685000469_fn__1685000470_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000340_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000340_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000344_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000348_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000348_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000354_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000368_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000354_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A struct{ j2g_header uint64; F_iter__1685000358, F_s__1685000359 any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1685000361, F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000358__1685000362_fn__1685000363_fn__1685000364_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A struct{ j2g_header uint64; F_dir, F_s__1685000373, F_tdir, F_ts, F_iter__1685000372 any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000375 any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000378_fn__1685000382_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000354_iter__1685000372__1685000376_fn__1685000377_fn__1685000388_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000330__1685000334_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A struct{ j2g_header uint64; F_s__1685000331, F_iter__1685000330 any }

var A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A struct{ j2g_header uint64; F_b__1685000333 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_iter__1685000330__1685000334_fn__1685000335_fn__1685000336_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000129_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000129_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000131_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000131_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000175_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000175_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000182_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000182_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000189_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000189_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000199_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000199_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000201_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000201_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000219_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000219_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000221_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000221_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000227_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000227_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000230_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000234_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000236_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000238_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000240_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000242_fn__1685000243_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000262_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000264_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000266_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000230_fn__1685000268_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A struct{ j2g_header uint64; F_s__1685000247, F_iter__1685000246, F_verified any }

var A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A struct{ j2g_header uint64; F_b__1685000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1685000230_iter__1685000246__1685000250_fn__1685000251_fn__1685000252_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000275_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000275_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000211_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000211_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000211_one__1685000212_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000277__1685000281_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000277__1685000281_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A struct{ j2g_header uint64; F_s__1685000278, F_iter__1685000277 any }

var A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A struct{ j2g_header uint64; F_b__1685000280 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000277__1685000281_fn__1685000282_fn__1685000283_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000215_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000215_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000215_fn__1685000216_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000293_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000293_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000437_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000437_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000439__1685000443_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000439__1685000443_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A struct{ j2g_header uint64; F_iter__1685000439, F_s__1685000440 any }

var A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A struct{ j2g_header uint64; F_b__1685000442 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000439__1685000443_fn__1685000444_fn__1685000445_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000417__1685000423_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000417__1685000423_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A struct{ j2g_header uint64; F_iter__1685000417, F_s__1685000418 any }

var A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A struct{ j2g_header uint64; F_iter__1685000419, F_r, F_s__1685000420 any }

var A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A struct{ j2g_header uint64; F_b__1685000422, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_report_errors_iter__1685000417__1685000423_fn__1685000424_iter__1685000419__1685000425_fn__1685000426_fn__1685000427_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000290_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000290_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000308__1685000312_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A struct{ j2g_header uint64; F_s__1685000309, F_f, F_iter__1685000308, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A struct{ j2g_header uint64; F_b__1685000311, F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000314_fn__1685000315_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000308__1685000312_fn__1685000313_fn__1685000318_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000303_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000303_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000303_fn__1685000304_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000404_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000404_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000406_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000406_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000408_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000408_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000410_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000410_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000412_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000412_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000414_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000414_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000402_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000402_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000400_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000400_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000453_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000453_A_fn_class *jrt.Class
