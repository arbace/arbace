//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_117)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__7, A_arbace_go_check_A_const_54.Invoke_O__O(n__6))).Ref() } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_262 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_go_check_A_const_24; var arg_266 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_268 == nil { tmp2 = ifn_269.Invoke_O__O(arg_270) } else { tmp2 = linked_268.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_267, arg_270) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_271 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_275 any = Lit_156; var arg_276 any; var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_280 == nil { arg_276 = ifn_281.Invoke_O__O(arg_282) } else { arg_276 = linked_280.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_279, arg_282) }; var arg_277 any; var root_283 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_285 lang.IFn
							if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = want__7; if linked_284 == nil { arg_277 = ifn_285.Invoke_O__O(arg_286) } else { arg_277 = linked_284.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_283, arg_286) }
//line :93:1
							var arg_278 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_289 lang.IFn
							if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_288 == nil { arg_278 = ifn_289.Invoke_O__O(arg_290) } else { arg_278 = linked_288.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_287, arg_290) }
//line :93:1
							if linked_272 == nil { ifn_273.Invoke_O_O_O_O_O__O(arg_274, arg_275, arg_276, arg_277, arg_278) } else { linked_272.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_271, arg_274, arg_275, arg_276, arg_277, arg_278) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_291 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_293 lang.IFn
									if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_292 == nil { and__1927000168__auto____11 = ifn_293.Invoke_O__O(arg_294) } else { and__1927000168__auto____11 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_295 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_67; var arg_299 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_300 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); var arg_304 any = Lit_156; var arg_305 any; var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); if linked_309 == nil { arg_305 = ifn_310.Invoke_O__O(arg_311) } else { arg_305 = linked_309.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_308, arg_311) }; var arg_306 any = Lit_157; var arg_307 any; var root_312 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_313 == nil { arg_307 = ifn_314.Invoke_O__O(arg_315) } else { arg_307 = linked_313.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_312, arg_315) }; if linked_301 == nil { ifn_302.Invoke_O_O_O_O_O__O(arg_303, arg_304, arg_305, arg_306, arg_307) } else { linked_301.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_300, arg_303, arg_304, arg_305, arg_306, arg_307) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1685000042__7; if linked_317 == nil { tmp8 = ifn_318.Invoke_O__O(arg_319) } else { tmp8 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_316, arg_319) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__9, A_arbace_go_check_A_const_54.Invoke_O__O(n__8))).Ref() } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_320 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_24; var arg_324 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_321 == nil { ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { linked_321.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_325 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_326 == nil { tmp10 = ifn_327.Invoke_O__O(arg_328) } else { tmp10 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_325, arg_328) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_329 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_333 any = Lit_156; var arg_334 any; var root_337 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_338 == nil { arg_334 = ifn_339.Invoke_O__O(arg_340) } else { arg_334 = linked_338.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_337, arg_340) }; var arg_335 any; var root_341 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_343 lang.IFn
								if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = want__9; if linked_342 == nil { arg_335 = ifn_343.Invoke_O__O(arg_344) } else { arg_335 = linked_342.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_341, arg_344) }
//line :93:1
								var arg_336 any; var root_345 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_347 lang.IFn
								if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_346 == nil { arg_336 = ifn_347.Invoke_O__O(arg_348) } else { arg_336 = linked_346.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_345, arg_348) }
//line :93:1
								if linked_330 == nil { ifn_331.Invoke_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336) } else { linked_330.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_349 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_351 lang.IFn
										if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_350 == nil { and__1927000168__auto____13 = ifn_351.Invoke_O__O(arg_352) } else { and__1927000168__auto____13 = linked_350.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_353 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_go_check_A_const_67; var arg_357 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_354 == nil { tmp11 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp11 = linked_354.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_358 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); var arg_362 any = Lit_156; var arg_363 any; var root_366 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); if linked_367 == nil { arg_363 = ifn_368.Invoke_O__O(arg_369) } else { arg_363 = linked_367.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_366, arg_369) }; var arg_364 any = Lit_157; var arg_365 any; var root_370 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_371 == nil { arg_365 = ifn_372.Invoke_O__O(arg_373) } else { arg_365 = linked_371.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_370, arg_373) }; if linked_359 == nil { ifn_360.Invoke_O_O_O_O_O__O(arg_361, arg_362, arg_363, arg_364, arg_365) } else { linked_359.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_358, arg_361, arg_362, arg_363, arg_364, arg_365) } } }
//line :86:1
				var tmp15 any; var root_374 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1685000042__7; if linked_375 == nil { tmp15 = ifn_376.Invoke_O__O(arg_377) } else { tmp15 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_70; var tmp2 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_71; var tmp4 any; var root_378 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_380 lang.IFn; if
													linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = pkg_scope__0; var arg_382 any = A_arbace_go_check_A_const_73; if linked_379 == nil { tmp4 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp4 = linked_379.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_74; var tmp7 any; var root_383 any = /*line :101:1*/A_arbace_go_check_A_const_75.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_385 lang.IFn; if


	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var or__1927000174__auto____4 any; var root_387 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = fi__1; var arg_391 any = A_arbace_go_check_A_const_77; if linked_388 == nil { or__1927000174__auto____4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { or__1927000174__auto____4 = linked_388.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_386 = or__1927000174__auto____4 } else { arg_386 = A_arbace_go_check_A_const_74.Invoke_O__O(config__2) }; if linked_384 == nil { tmp7 = ifn_385.Invoke_O__O(arg_386) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_384.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_383, arg_386)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_78; var tmp10 any; var root_392 any = /*line :101:1*/A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_394 lang.IFn; if



	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_go_check_A_const_73.Invoke_O__O(fi__1); if linked_393 == nil { tmp10 = ifn_394.Invoke_O__O(arg_395) } else { tmp10 = linked_393.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_392, arg_395) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_80; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_80; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_81.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_82; var tmp16 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_83; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_84; var tmp20 any; var root_396 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_398 lang.IFn; if





	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.PersistentVector_EMPTY.Ref(); if linked_397 == nil { tmp20 = ifn_398.Invoke_O__O(arg_399) } else { tmp20 = linked_397.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_396, arg_399) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_85; var tmp23 any; var root_400 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_402 lang.IFn; if





	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.PersistentVector_EMPTY.Ref(); if linked_401 == nil { tmp23 = ifn_402.Invoke_O__O(arg_403) } else { tmp23 = linked_401.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_400, arg_403) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__502d; tmp1 = fncls__502d } else { tmp1 = fncls__502 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_503 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_A_const_84.Invoke_O__O(fi__0); if linked_508 == nil { arg_506 = ifn_509.Invoke_O__O(arg_510) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_507, arg_510) }; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__561d; tmp3 = fncls__561d } else { tmp3 = fncls__561 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_404 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_406 lang.IFn
	if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = f__1; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_404, arg_407) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_408 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = f__1; if linked_409 == nil { temp__1927000414__auto____2 = ifn_410.Invoke_O__O(arg_411) } else { temp__1927000414__auto____2 = linked_409.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_470 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_472 lang.IFn
			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_go_check_A_const_71.Invoke_O__O(t.F_fi); var arg_474 any = q__3; if linked_471 == nil { temp__1927000414__auto____4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { temp__1927000414__auto____4 = linked_471.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_91; var tmp3 any; var root_475 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_477 lang.IFn
				if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__5; var arg_479 any = A_arbace_go_check_A_const_93; if linked_476 == nil { tmp3 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp3 = linked_476.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_480 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = x__5; var arg_484 any = A_arbace_go_check_A_const_89; var arg_485 any = jrt.Boolean_TRUE.Ref(); if linked_481 == nil { ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp5 any; var root_412 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_414 lang.IFn


			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; if linked_413 == nil { tmp5 = ifn_414.Invoke_O__O(arg_415) } else { tmp5 = linked_413.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_412, arg_415) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_416 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_418 lang.IFn; _ = ___6; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = imp__7; var arg_420 any = A_arbace_go_check_A_const_89; var arg_421 any = jrt.Boolean_TRUE.Ref(); if linked_417 == nil { ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { linked_417.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } } } else {
//line :113:1
				var tmp6 any; var root_422 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_424 lang.IFn




				if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp6 = ifn_424.Invoke_O__O(arg_425) } else { tmp6 = linked_423.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_422, arg_425) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_426 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn




					if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = f__1; if linked_427 == nil { seq_1685000052__2 = ifn_428.Invoke_O__O(arg_429) } else { seq_1685000052__2 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1685000052__2; if linked_431 == nil { temp__1927000414__auto____6 = ifn_432.Invoke_O__O(arg_433) } else { temp__1927000414__auto____6 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1685000052__7; if linked_435 == nil { tmp7 = ifn_436.Invoke_O__O(arg_437) } else { tmp7 = linked_435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_1685000052__7; if linked_439 == nil { c__1927000678__auto____8 = ifn_440.Invoke_O__O(arg_441) } else { c__1927000678__auto____8 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_438, arg_441) }; var tmp8 any; var root_486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1685000052__7; if linked_487 == nil { tmp8 = ifn_488.Invoke_O__O(arg_489) } else { tmp8 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1685000052__7; if linked_443 == nil { x__8 = ifn_444.Invoke_O__O(arg_445) } else { x__8 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_1685000052__7; if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_490, arg_493) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_446 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_448 lang.IFn





							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; if linked_447 == nil { tmp10 = ifn_448.Invoke_O__O(arg_449) } else { tmp10 = linked_447.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_446, arg_449) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_450 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn





								if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = f__1; if linked_451 == nil { seq_1685000056__2 = ifn_452.Invoke_O__O(arg_453) } else { seq_1685000056__2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1685000056__2; if linked_455 == nil { temp__1927000414__auto____6_2 = ifn_456.Invoke_O__O(arg_457) } else { temp__1927000414__auto____6_2 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_458 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1685000056__7; if linked_459 == nil { tmp11 = ifn_460.Invoke_O__O(arg_461) } else { tmp11 = linked_459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_462 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1685000056__7; if linked_463 == nil { c__1927000678__auto____8_2 = ifn_464.Invoke_O__O(arg_465) } else { c__1927000678__auto____8_2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_462, arg_465) }; var tmp12 any; var root_494 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1685000056__7; if linked_495 == nil { tmp12 = ifn_496.Invoke_O__O(arg_497) } else { tmp12 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_466 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1685000056__7; if linked_467 == nil { x__8_2 = ifn_468.Invoke_O__O(arg_469) } else { x__8_2 = linked_467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_466, arg_469) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1685000056__7; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_511 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_513 lang.IFn
		if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = f__1; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp3 any; var root_515 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn
			if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__1; if linked_516 == nil { tmp3 = ifn_517.Invoke_O__O(arg_518) } else { tmp3 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_521 lang.IFn; _ = ___4; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = imp__5; var arg_523 any = A_arbace_go_check_A_const_89; var arg_524 any = jrt.Boolean_TRUE.Ref(); if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_525 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_527 lang.IFn

				if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { or__1927000174__auto____2 = ifn_527.Invoke_O__O(arg_528) } else { or__1927000174__auto____2 = linked_526.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_529 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_529, arg_532) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__1; if linked_534 == nil { seq_1685000065__2 = ifn_535.Invoke_O__O(arg_536) } else { seq_1685000065__2 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1685000065__2; if linked_538 == nil { temp__1927000414__auto____6 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000414__auto____6 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1685000065__7; if linked_542 == nil { tmp5 = ifn_543.Invoke_O__O(arg_544) } else { tmp5 = linked_542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_541, arg_544) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = seq_1685000065__7; if linked_546 == nil { c__1927000678__auto____8 = ifn_547.Invoke_O__O(arg_548) } else { c__1927000678__auto____8 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_545, arg_548) }; var tmp6 any; var root_553 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = seq_1685000065__7; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1685000065__7; if linked_550 == nil { x__8 = ifn_551.Invoke_O__O(arg_552) } else { x__8 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_557 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1685000065__7; if linked_558 == nil { tmp7 = ifn_559.Invoke_O__O(arg_560) } else { tmp7 = linked_558.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_557, arg_560) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_98); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp6 any; var root_682 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = d__0; if linked_683 == nil { tmp6 = ifn_684.Invoke_O__O(arg_685) } else { tmp6 = linked_683.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_99; var tmp8 any; var root_674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { tmp8 = ifn_676.Invoke_O__O(arg_677) } else { tmp8 = linked_675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_674, arg_677) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp10 any; var root_678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = d__0; if linked_679 == nil { tmp10 = ifn_680.Invoke_O__O(arg_681) } else { tmp10 = linked_679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_678, arg_681) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_564 lang.IFn
		if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = f__1; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_566 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = f__1; if linked_567 == nil { tmp2 = ifn_568.Invoke_O__O(arg_569) } else { tmp2 = linked_567.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_566, arg_569) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_572 lang.IFn

			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = t.F_pkg_scope; var arg_574 any; var root_575 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = f__1; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_575, arg_578) }; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_94); var tmp4 any; var root_634 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_636 lang.IFn
				if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__3; var arg_638 any = A_arbace_go_check_A_const_93; if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp4 = linked_635.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_579 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_583 any = A_arbace_go_check_A_const_95; var arg_584 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_585 any = x__3; if linked_580 == nil { tmp6 = ifn_581.Invoke_O_O_O_O__O(arg_582, arg_583, arg_584, arg_585) } else { tmp6 = linked_580.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_579, arg_582, arg_583, arg_584, arg_585) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_586 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_588 lang.IFn




								if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = f__1; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_586, arg_589) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_639 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_641 lang.IFn




									if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = f__1; if linked_640 == nil { temp__1927000414__auto____2_2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2_2 = linked_640.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_643 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_645 lang.IFn
										if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = h__3; var arg_647 any = Lit_137; if linked_644 == nil { and__1927000168__auto____4 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { and__1927000168__auto____4 = linked_644.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_648 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = h__3; var arg_656 any = Lit_155; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { and__1927000168__auto____5 = ifn_650.Invoke_O__O(arg_651) } else { and__1927000168__auto____5 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn








									if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { seq_1685000072__2 = ifn_592.Invoke_O__O(arg_593) } else { seq_1685000072__2 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_1685000072__2; if linked_595 == nil { temp__1927000414__auto____6 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____6 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_1685000072__7; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_1685000072__7; if linked_603 == nil { c__1927000678__auto____8 = ifn_604.Invoke_O__O(arg_605) } else { c__1927000678__auto____8 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_602, arg_605) }; var tmp10 any; var root_657 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1685000072__7; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_657, arg_660) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1685000072__7; if linked_607 == nil { x__8 = ifn_608.Invoke_O__O(arg_609) } else { x__8 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_661 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1685000072__7; if linked_662 == nil { tmp11 = ifn_663.Invoke_O__O(arg_664) } else { tmp11 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_610 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_612 lang.IFn









											if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = f__1; if linked_611 == nil { tmp12 = ifn_612.Invoke_O__O(arg_613) } else { tmp12 = linked_611.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_610, arg_613) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_614 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn









												if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = f__1; if linked_615 == nil { seq_1685000076__2 = ifn_616.Invoke_O__O(arg_617) } else { seq_1685000076__2 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_1685000076__2; if linked_619 == nil { temp__1927000414__auto____6_2 = ifn_620.Invoke_O__O(arg_621) } else { temp__1927000414__auto____6_2 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_622 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_1685000076__7; if linked_623 == nil { tmp13 = ifn_624.Invoke_O__O(arg_625) } else { tmp13 = linked_623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_626 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = seq_1685000076__7; if linked_627 == nil { c__1927000678__auto____8_2 = ifn_628.Invoke_O__O(arg_629) } else { c__1927000678__auto____8_2 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any; var root_665 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1685000076__7; if linked_666 == nil { tmp14 = ifn_667.Invoke_O__O(arg_668) } else { tmp14 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_630 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1685000076__7; if linked_631 == nil { x__8_2 = ifn_632.Invoke_O__O(arg_633) } else { x__8_2 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_669 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = seq_1685000076__7; if linked_670 == nil { tmp15 = ifn_671.Invoke_O__O(arg_672) } else { tmp15 = linked_670.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_669, arg_672) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_number_local_types_BANG__A_New() *A_arbace_go_check_number_local_types_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Invoke_O_O__O(self, lts__0 any) any { { var sorted__2 any; var root_686 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_688 lang.IFn





	if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any; var tmp1 any = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New(); var tmp2 *jrt.Class; var fncls__691 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class; if fncls__691 == nil { var fncls__691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class = fncls__691d; tmp2 = fncls__691d } else { tmp2 = fncls__691 }; arg_689 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_690 any; var root_692 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any; var tmp3 any = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New(); var tmp4 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class = fncls__697d; tmp4 = fncls__697d } else { tmp4 = fncls__697 }; arg_695 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_696 any = lts__0; if linked_693 == nil { arg_690 = ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { arg_690 = linked_693.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }; if linked_687 == nil { sorted__2 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { sorted__2 = linked_687.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }
//line :151:1
	var seq_1685000094__3 any; var root_698 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_700 lang.IFn






	if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any; var root_702 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var arg_706 any = sorted__2; if linked_703 == nil { arg_701 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_699 == nil { seq_1685000094__3 = ifn_700.Invoke_O__O(arg_701) } else { seq_1685000094__3 = linked_699.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_698, arg_701) }
//line :151:1
	var chunk_1685000095__4 any; var count_1685000096__5 int64 = 0; var i_1685000097__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000097__6, count_1685000096__5) { var vec__1685000098__7 any = lang.Indexed_Cast(chunk_1685000095__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000097__6)); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000101__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_104.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var tmp7 any = A_arbace_go_check_A_const_106; var tmp8 jrt.Number_I; var na_730 any = n__8; _ = ___10
			if jrt.Long_InstanceOf(na_730) { var n0_731 int64 = jrt.NN(jrt.Long_Cast(na_730)).LongValue__J(); if n0_731 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_730) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_731 + 1)) } } else { if jrt.Double_InstanceOf(na_730) { var n0_731_2 float64 = jrt.NN(jrt.Double_Cast(na_730)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_731_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_730) } }; tmp5.Invoke_O_O_O_O__O(nt__11, tmp6, tmp7, tmp8)
//line :158:1
			seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000097__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_707 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = seq_1685000094__3; if linked_708 == nil { temp__1927000414__auto____7 = ifn_709.Invoke_O__O(arg_710) } else { temp__1927000414__auto____7 = linked_708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_707, arg_710) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000094__8 any = temp__1927000414__auto____7; var tmp9 any; var root_711 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = seq_1685000094__8; if linked_712 == nil { tmp9 = ifn_713.Invoke_O__O(arg_714) } else { tmp9 = linked_712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____9 any; var root_715 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = seq_1685000094__8; if linked_716 == nil { c__1927000678__auto____9 = ifn_717.Invoke_O__O(arg_718) } else { c__1927000678__auto____9 = linked_716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_715, arg_718) }; var tmp10 any; var root_732 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = seq_1685000094__8; if linked_733 == nil { tmp10 = ifn_734.Invoke_O__O(arg_735) } else { tmp10 = linked_733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_732, arg_735) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp10, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000104__9 any; var root_719 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = seq_1685000094__8; if linked_720 == nil { vec__1685000104__9 = ifn_721.Invoke_O__O(arg_722) } else { vec__1685000104__9 = linked_720.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_719, arg_722) }; var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000107__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(1), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_104.GetRawRoot__O()); var tmp12 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var tmp13 any = A_arbace_go_check_A_const_106; var tmp14 jrt.Number_I; var na_743 any = n__10; _ = ___12
				if jrt.Long_InstanceOf(na_743) { var n0_744 int64 = jrt.NN(jrt.Long_Cast(na_743)).LongValue__J(); if n0_744 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_743) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_744 + 1)) } } else { if jrt.Double_InstanceOf(na_743) { var n0_744_2 float64 = jrt.NN(jrt.Double_Cast(na_743)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_744_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_743) } }; tmp11.Invoke_O_O_O_O__O(nt__13, tmp12, tmp13, tmp14)
//line :158:1
				var tmp15 any; var root_745 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = seq_1685000094__8; if linked_746 == nil { tmp15 = ifn_747.Invoke_O__O(arg_748) } else { tmp15 = linked_746.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_745, arg_748) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :151:1*/panic("j2g: unreachable") }





func A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000083_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Invoke_O_O__O(self, p__1685000082__1 any) any { var vec__1685000084__2 any = p__1685000082__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(id__3, k__5) }
//line :157:1
func A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000089_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Invoke_O_O_O__O(self, k__1, p__1685000088__2 any) any { var vec__1685000090__3 any = p__1685000088__2; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(id__4, nt__5, k__1) }



func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000126__2 any) any { var map__1685000127__4 any = p__1685000126__2; var map__1685000127__5 any; if lang.ISeq_InstanceOf(map__1685000127__4) { var tmp1 any; var root_749 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = map__1685000127__4; if linked_750 == nil { tmp1 = ifn_751.Invoke_O__O(arg_752) } else { tmp1 = linked_750.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_753 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = map__1685000127__4; if linked_754 == nil { tmp2 = ifn_755.Invoke_O__O(arg_756) } else { tmp2 = linked_754.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_753, arg_756) }; map__1685000127__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_757 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = map__1685000127__4; if linked_758 == nil { tmp3 = ifn_759.Invoke_O__O(arg_760) } else { tmp3 = linked_758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_757, arg_760) }; if jrt.J2g_Truth(tmp3) { var root_761 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = map__1685000127__4; if linked_762 == nil { map__1685000127__5 = ifn_763.Invoke_O__O(arg_764) } else { map__1685000127__5 = linked_762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_761, arg_764) } } else { map__1685000127__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000127__5 = map__1685000127__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000127__5, A_arbace_go_check_A_const_108); var pkg_scope__7 any; var root_765 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_767 lang.IFn; if




	linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var arg_769 any = A_arbace_go_check_A_const_109; if linked_766 == nil { pkg_scope__7 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { pkg_scope__7 = linked_766.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; var pkg__8 any; var root_770 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_772 lang.IFn; if





	linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var tmp4 any = A_arbace_go_check_A_const_110; var tmp5 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_70; var tmp7 any = A_arbace_go_check_A_const_70.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_71; var tmp9 any = A_arbace_go_check_A_const_111; var tmp10 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp11 any = A_arbace_go_check_A_const_112; var tmp12 any; var root_774 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_776 lang.IFn; if
	linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = lang.PersistentVector_EMPTY.Ref(); if linked_775 == nil { tmp12 = ifn_776.Invoke_O__O(arg_777) } else { tmp12 = linked_775.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_774, arg_777) }; arg_773 = /*line :167:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, tmp10, tmp11, tmp12)); if linked_771 == nil { pkg__8 = ifn_772.Invoke_O__O(arg_773) } else { pkg__8 = linked_771.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_770, arg_773) }; var errors__9 any; var root_778 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_780 lang.IFn; if







	linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = lang.PersistentVector_EMPTY.Ref(); if linked_779 == nil { errors__9 = ifn_780.Invoke_O__O(arg_781) } else { errors__9 = linked_779.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_778, arg_781) }; var resolving__10 any; var root_782 any = /*line :161:1*/A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_784 lang.IFn; if










	linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_783 == nil { resolving__10 = ifn_784.Invoke_O__O(arg_785) } else { resolving__10 = linked_783.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_782, arg_785) }; var annotated__11 any; var and__1927000168__auto____11 any; var root_786 any = /*line :161:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_788 lang.IFn; if











	linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = A_arbace_go_check_A_const_81.Invoke_O__O(src__0); var arg_790 any = A_arbace_go_check_A_const_115; if linked_787 == nil { and__1927000168__auto____11 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { and__1927000168__auto____11 = linked_787.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_791 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = resolving__10; if linked_792 == nil { annotated__11 = ifn_793.Invoke_O__O(arg_794) } else { annotated__11 = linked_792.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_791, arg_794) } } else { annotated__11 = and__1927000168__auto____11 }; var ctx__12 any; var tmp13 any = A_arbace_go_check_A_const_116; var tmp14 any; var root_795 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_797 lang.IFn; if












	linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = lang.PersistentVector_EMPTY.Ref(); if linked_796 == nil { tmp14 = ifn_797.Invoke_O__O(arg_798) } else { tmp14 = linked_796.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_795, arg_798) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_117; var tmp17 any; var root_799 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_801 lang.IFn; if












	linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_800 == nil { tmp17 = ifn_801.Invoke_O__O(arg_802) } else { tmp17 = linked_800.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_799, arg_802) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_118; var tmp20 any; var root_803 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_805 lang.IFn; if












	linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = lang.PersistentVector_EMPTY.Ref(); if linked_804 == nil { tmp20 = ifn_805.Invoke_O__O(arg_806) } else { tmp20 = linked_804.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_803, arg_806) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_119; var tmp23 any; var root_807 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_809 lang.IFn; if












	linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = lang.PersistentVector_EMPTY.Ref(); if linked_808 == nil { tmp23 = ifn_809.Invoke_O__O(arg_810) } else { tmp23 = linked_808.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_807, arg_810) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_go_check_A_const_120; ctx__12 = /*line :161:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__11, A_arbace_go_check_A_const_121, resolving__10)))); var fis__13 any; var root_811 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_813 lang.IFn; if














	linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any; var tmp26 any = A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(src__0, pkg_scope__7); var tmp27 *jrt.Class; var fncls__822 *jrt.Class = A_arbace_go_check_check_package_fn__1685000129_A_fn_class; if fncls__822 == nil { var fncls__822d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000129_A_fn_class = fncls__822d; tmp27 = fncls__822d } else { tmp27 = fncls__822 }; arg_814 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_815 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__0); if linked_812 == nil { fis__13 = ifn_813.Invoke_O_O__O(arg_814, arg_815) } else { fis__13 = linked_812.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_811, arg_814, arg_815) }; var root_1280 any =
	A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp29 any = A_arbace_go_check_A_const_170; var tmp30 any = A_arbace_go_check_A_const_171; var tmp31 any = A_arbace_go_check_A_const_172; var tmp32 any = jrt.IdentityHashMap_New(); var tmp33 any = A_arbace_go_check_A_const_173; var tmp34 any = A_arbace_go_check_A_const_174; var tmp35 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); var tmp36 any = A_arbace_go_check_A_const_175; var tmp37 any = A_arbace_go_check_A_const_61; var tmp38 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__11, A_arbace_go_check_A_const_121, resolving__10)); var tmp39 any = A_arbace_go_check_A_const_176; var tmp40 any = A_arbace_go_check_A_const_177.GetRawRoot__O(); var tmp41 any = A_arbace_go_check_A_const_178; var tmp42 any = A_arbace_go_check_A_const_179.GetRawRoot__O(); var tmp43 any = A_arbace_go_check_A_const_180; var tmp44 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp45 any = A_arbace_go_check_A_const_181; var tmp46 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var tmp47 any = A_arbace_go_check_A_const_183; var tmp48 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var tmp49 any = A_arbace_go_check_A_const_185; var tmp50 any = A_arbace_go_check_A_const_186.GetRawRoot__O(); var tmp51 any = A_arbace_go_check_A_const_187; var tmp52 any = A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp53 *jrt.Class; var fncls__1288 *jrt.Class = A_arbace_go_check_check_package_fn__1685000131_A_fn_class; if












	fncls__1288 == nil { var fncls__1288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000131_A_fn_class = fncls__1288d; tmp53 = fncls__1288d } else { tmp53 = fncls__1288 }; var tmp54 any = /*line :177:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var tmp55 any = A_arbace_go_check_A_const_189; var tmp56 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var tmp57 any = A_arbace_go_check_A_const_191; var tmp58 any = A_arbace_go_check_A_const_192.GetRawRoot__O(); var tmp59 any = A_arbace_go_check_A_const_193; var tmp60 any = A_arbace_go_check_A_const_194.GetRawRoot__O(); var tmp61 any = A_arbace_go_check_A_const_195; var tmp62 any; var root_1289 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1291 lang.IFn; if

















	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.PersistentVector_EMPTY.Ref(); if linked_1290 == nil { tmp62 = ifn_1291.Invoke_O__O(arg_1292) } else { tmp62 = linked_1290.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1289, arg_1292) }; var tmp63 any = tmp62; var tmp64 any = A_arbace_go_check_A_const_196; var tmp65 any; var root_1293 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1295 lang.IFn; if


















	linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_197, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_198, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_199, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_200, lang.PersistentArrayMap_EMPTY.Ref())); if linked_1294 == nil { tmp65 = ifn_1295.Invoke_O__O(arg_1296) } else { tmp65 = linked_1294.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1293, arg_1296) }; var tmp66 any = tmp65; var tmp67 any = A_arbace_go_check_A_const_201; var tmp68 any; var root_1297 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1299 lang.IFn; if



















	linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = lang.PersistentVector_EMPTY.Ref(); if linked_1298 == nil { tmp68 = ifn_1299.Invoke_O__O(arg_1300) } else { tmp68 = linked_1298.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1297, arg_1300) }; arg_1283 = /*line :177:1*/tmp28.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp29, pkg__8, tmp30, errors__9, tmp31, tmp32, tmp33, ctx__12, tmp34, tmp35, tmp36, resolving__10, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp63, tmp64, tmp66, tmp67, tmp68)))); if linked_1281 == nil { ifn_1282.Invoke_O__O(arg_1283) } else { linked_1281.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1280, arg_1283) }; var tmp69 any; tmp332 := /*line :161:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





































		if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, A_arbace_go_check_A_const_70.Invoke_O__O(src__0)) { var seq_1685000133__16 any; var root_1301 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1303 lang.IFn
			if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = fis__13; if linked_1302 == nil { seq_1685000133__16 = ifn_1303.Invoke_O__O(arg_1304) } else { seq_1685000133__16 = linked_1302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1301, arg_1304) }
//line :199:1
			var chunk_1685000134__17 any; var count_1685000135__18 int64 = 0; var i_1685000136__19 int64 = 0; L1: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000136__19, count_1685000135__18) { var fi__20 any = lang.Indexed_Cast(chunk_1685000134__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000136__19)); var root_1384 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__20); var arg_1388 any; var or__1927000174__auto____21 any = A_arbace_go_check_A_const_78.Invoke_O__O(fi__20); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_1388 = or__1927000174__auto____21 } else { arg_1388 = A_arbace_go_check_A_const_43 }; var arg_1389 any = A_arbace_go_check_A_const_204; var arg_1390 any = Lit_58; if linked_1385 == nil { ifn_1386.Invoke_O_O_O_O__O(arg_1387, arg_1388, arg_1389, arg_1390) } else { linked_1385.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1384, arg_1387, arg_1388, arg_1389, arg_1390) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000136__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_1305 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = seq_1685000133__16; if linked_1306 == nil { temp__1927000414__auto____20 = ifn_1307.Invoke_O__O(arg_1308) } else { temp__1927000414__auto____20 = linked_1306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1305, arg_1308) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000133__21 any = temp__1927000414__auto____20; var tmp70 any; var root_1309 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = seq_1685000133__21; if linked_1310 == nil { tmp70 = ifn_1311.Invoke_O__O(arg_1312) } else { tmp70 = linked_1310.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1309, arg_1312) }; if jrt.J2g_Truth(tmp70) { var c__1927000678__auto____22 any; var root_1313 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = seq_1685000133__21; if linked_1314 == nil { c__1927000678__auto____22 = ifn_1315.Invoke_O__O(arg_1316) } else { c__1927000678__auto____22 = linked_1314.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1313, arg_1316) }; var tmp71 any; var root_1391 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = seq_1685000133__21; if linked_1392 == nil { tmp71 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp71 = linked_1392.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1391, arg_1394) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp71, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__22 any; var root_1317 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = seq_1685000133__21; if linked_1318 == nil { fi__22 = ifn_1319.Invoke_O__O(arg_1320) } else { fi__22 = linked_1318.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1317, arg_1320) }; var root_1395 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__22); var arg_1399 any; var or__1927000174__auto____23 any = A_arbace_go_check_A_const_78.Invoke_O__O(fi__22); if jrt.J2g_Truth(or__1927000174__auto____23) { arg_1399 = or__1927000174__auto____23 } else { arg_1399 = A_arbace_go_check_A_const_43 }; var arg_1400 any = A_arbace_go_check_A_const_204; var arg_1401 any = Lit_58; if linked_1396 == nil { ifn_1397.Invoke_O_O_O_O__O(arg_1398, arg_1399, arg_1400, arg_1401) } else { linked_1396.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1395, arg_1398, arg_1399, arg_1400, arg_1401) }; var tmp72 any; var root_1402 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = seq_1685000133__21; if linked_1403 == nil { tmp72 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp72 = linked_1403.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1402, arg_1405) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp72, nil, 0, 0; continue L1 } } }
//line :199:1
				break L1 } }
//line :161:1
		{ var seq_1685000137__16 any; var root_1321 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1323 lang.IFn







































			if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = fis__13; if linked_1322 == nil { seq_1685000137__16 = ifn_1323.Invoke_O__O(arg_1324) } else { seq_1685000137__16 = linked_1322.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1321, arg_1324) }
//line :161:1
			var chunk_1685000138__17 any; var count_1685000139__18 int64 = 0; var i_1685000140__19 int64 = 0; L2: for {







































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000140__19, count_1685000139__18) { var fi__20_2 any = lang.Indexed_Cast(chunk_1685000138__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000140__19)); var root_1406 any = A_arbace_go_check_A_const_205.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = fi__20_2; var arg_1410 any = resolve__1; if linked_1407 == nil { ifn_1408.Invoke_O_O__O(arg_1409, arg_1410) } else { linked_1407.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1406, arg_1409, arg_1410) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000140__19); continue L2 } else { var temp__1927000414__auto____20_2 any; var root_1325 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = seq_1685000137__16; if linked_1326 == nil { temp__1927000414__auto____20_2 = ifn_1327.Invoke_O__O(arg_1328) } else { temp__1927000414__auto____20_2 = linked_1326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1325, arg_1328) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000137__21 any = temp__1927000414__auto____20_2; var tmp73 any; var root_1329 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = seq_1685000137__21; if linked_1330 == nil { tmp73 = ifn_1331.Invoke_O__O(arg_1332) } else { tmp73 = linked_1330.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1329, arg_1332) }; if jrt.J2g_Truth(tmp73) { var c__1927000678__auto____22_2 any; var root_1333 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = seq_1685000137__21; if linked_1334 == nil { c__1927000678__auto____22_2 = ifn_1335.Invoke_O__O(arg_1336) } else { c__1927000678__auto____22_2 = linked_1334.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1333, arg_1336) }; var tmp74 any; var root_1411 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = seq_1685000137__21; if linked_1412 == nil { tmp74 = ifn_1413.Invoke_O__O(arg_1414) } else { tmp74 = linked_1412.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1411, arg_1414) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp74, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__22_2 any; var root_1337 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = seq_1685000137__21; if linked_1338 == nil { fi__22_2 = ifn_1339.Invoke_O__O(arg_1340) } else { fi__22_2 = linked_1338.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1337, arg_1340) }; var root_1415 any = A_arbace_go_check_A_const_205.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = fi__22_2; var arg_1419 any = resolve__1; if linked_1416 == nil { ifn_1417.Invoke_O_O__O(arg_1418, arg_1419) } else { linked_1416.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1415, arg_1418, arg_1419) }; var tmp75 any; var root_1420 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = seq_1685000137__21; if linked_1421 == nil { tmp75 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp75 = linked_1421.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1420, arg_1423) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp75, nil, 0, 0; continue L2 } } }
//line :161:1
				break L2 }; var seq_1685000141__16 any; var root_1341 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1343 lang.IFn








































			if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = fis__13; if linked_1342 == nil { seq_1685000141__16 = ifn_1343.Invoke_O__O(arg_1344) } else { seq_1685000141__16 = linked_1342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1341, arg_1344) }
//line :161:1
			var chunk_1685000142__17 any; var count_1685000143__18 int64 = 0; var i_1685000144__19 int64 = 0; L3: for {








































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000144__19, count_1685000143__18) { var fi__20_3 any = lang.Indexed_Cast(chunk_1685000142__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000144__19)); var root_1424 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = fi__20_3; if linked_1425 == nil { ifn_1426.Invoke_O__O(arg_1427) } else { linked_1425.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1424, arg_1427) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000144__19); continue L3 } else { var temp__1927000414__auto____20_3 any; var root_1345 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = seq_1685000141__16; if linked_1346 == nil { temp__1927000414__auto____20_3 = ifn_1347.Invoke_O__O(arg_1348) } else { temp__1927000414__auto____20_3 = linked_1346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1345, arg_1348) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000141__21 any = temp__1927000414__auto____20_3; var tmp76 any; var root_1349 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = seq_1685000141__21; if linked_1350 == nil { tmp76 = ifn_1351.Invoke_O__O(arg_1352) } else { tmp76 = linked_1350.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1349, arg_1352) }; if jrt.J2g_Truth(tmp76) { var c__1927000678__auto____22_3 any; var root_1353 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = seq_1685000141__21; if linked_1354 == nil { c__1927000678__auto____22_3 = ifn_1355.Invoke_O__O(arg_1356) } else { c__1927000678__auto____22_3 = linked_1354.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1353, arg_1356) }; var tmp77 any; var root_1428 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = seq_1685000141__21; if linked_1429 == nil { tmp77 = ifn_1430.Invoke_O__O(arg_1431) } else { tmp77 = linked_1429.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1428, arg_1431) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp77, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__22_3 any; var root_1357 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = seq_1685000141__21; if linked_1358 == nil { fi__22_3 = ifn_1359.Invoke_O__O(arg_1360) } else { fi__22_3 = linked_1358.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1357, arg_1360) }; var root_1432 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = fi__22_3; if linked_1433 == nil { ifn_1434.Invoke_O__O(arg_1435) } else { linked_1433.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1432, arg_1435) }; var tmp78 any; var root_1436 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = seq_1685000141__21; if linked_1437 == nil { tmp78 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp78 = linked_1437.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1436, arg_1439) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp78, nil, 0, 0; continue L3 } } }
//line :161:1
				break L3 }; var seq_1685000145__16 any; var root_1361 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1363 lang.IFn









































			if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = fis__13; if linked_1362 == nil { seq_1685000145__16 = ifn_1363.Invoke_O__O(arg_1364) } else { seq_1685000145__16 = linked_1362.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1361, arg_1364) }
//line :161:1
			var chunk_1685000146__17 any; var count_1685000147__18 int64 = 0; var i_1685000148__19 int64 = 0; L4: for {









































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000148__19, count_1685000147__18) { var fi__20_4 any = lang.Indexed_Cast(chunk_1685000146__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000148__19)); var root_1440 any = A_arbace_go_check_A_const_207.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = fi__20_4; if linked_1441 == nil { ifn_1442.Invoke_O__O(arg_1443) } else { linked_1441.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1440, arg_1443) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000148__19); continue L4 } else { var temp__1927000414__auto____20_4 any; var root_1365 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = seq_1685000145__16; if linked_1366 == nil { temp__1927000414__auto____20_4 = ifn_1367.Invoke_O__O(arg_1368) } else { temp__1927000414__auto____20_4 = linked_1366.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1365, arg_1368) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000145__21 any = temp__1927000414__auto____20_4; var tmp79 any; var root_1369 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = seq_1685000145__21; if linked_1370 == nil { tmp79 = ifn_1371.Invoke_O__O(arg_1372) } else { tmp79 = linked_1370.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1369, arg_1372) }; if jrt.J2g_Truth(tmp79) { var c__1927000678__auto____22_4 any; var root_1373 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = seq_1685000145__21; if linked_1374 == nil { c__1927000678__auto____22_4 = ifn_1375.Invoke_O__O(arg_1376) } else { c__1927000678__auto____22_4 = linked_1374.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1373, arg_1376) }; var tmp80 any; var root_1444 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = seq_1685000145__21; if linked_1445 == nil { tmp80 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp80 = linked_1445.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1444, arg_1447) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp80, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var fi__22_4 any; var root_1377 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = seq_1685000145__21; if linked_1378 == nil { fi__22_4 = ifn_1379.Invoke_O__O(arg_1380) } else { fi__22_4 = linked_1378.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1377, arg_1380) }; var root_1448 any = A_arbace_go_check_A_const_207.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = fi__22_4; if linked_1449 == nil { ifn_1450.Invoke_O__O(arg_1451) } else { linked_1449.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1448, arg_1451) }; var tmp81 any; var root_1452 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = seq_1685000145__21; if linked_1453 == nil { tmp81 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp81 = linked_1453.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1452, arg_1455) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp81, nil, 0, 0; continue L4 } } }
//line :161:1
				break L4
			}









































			var root_1381 any = A_arbace_go_check_A_const_202.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; if linked_1382 == nil { ifn_1383.Invoke__O() } else { linked_1382.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1381) }
//line :161:1
			var objs__16 any; var root_823 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_825 lang.IFn











































			if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = A_arbace_go_check_A_const_116.Invoke_O__O(ctx__12); if linked_824 == nil { objs__16 = ifn_825.Invoke_O__O(arg_826) } else { objs__16 = linked_824.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_823, arg_826) }
//line :161:1
			var seq_1685000149__17 any; var root_1456 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1458 lang.IFn












































			if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any; var root_1460 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var arg_1464 any = objs__16; if linked_1461 == nil { arg_1459 = ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { arg_1459 = linked_1461.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) }; if linked_1457 == nil { seq_1685000149__17 = ifn_1458.Invoke_O__O(arg_1459) } else { seq_1685000149__17 = linked_1457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1456, arg_1459) }
//line :161:1
			var chunk_1685000150__18 any; var count_1685000151__19 int64 = 0; var i_1685000152__20 int64 = 0; L5: for {












































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000152__20, count_1685000151__19) { var vec__1685000153__21 any = lang.Indexed_Cast(chunk_1685000150__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000152__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000153__21, lang.RT_IntCast_J__I_NoInit(0), nil); var x__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000153__21, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1658 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = x__23; var arg_1662 any = A_arbace_go_check_A_const_211; var arg_1663 any = i__22; if linked_1659 == nil { ifn_1660.Invoke_O_O_O__O(arg_1661, arg_1662, arg_1663) } else { linked_1659.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1658, arg_1661, arg_1662, arg_1663) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000152__20); continue L5 } else { var temp__1927000414__auto____21 any; var root_1465 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = seq_1685000149__17; if linked_1466 == nil { temp__1927000414__auto____21 = ifn_1467.Invoke_O__O(arg_1468) } else { temp__1927000414__auto____21 = linked_1466.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1465, arg_1468) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000149__22 any = temp__1927000414__auto____21; var tmp82 any; var root_1469 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = seq_1685000149__22; if linked_1470 == nil { tmp82 = ifn_1471.Invoke_O__O(arg_1472) } else { tmp82 = linked_1470.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1469, arg_1472) }; if jrt.J2g_Truth(tmp82) { var c__1927000678__auto____23 any; var root_1473 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = seq_1685000149__22; if linked_1474 == nil { c__1927000678__auto____23 = ifn_1475.Invoke_O__O(arg_1476) } else { c__1927000678__auto____23 = linked_1474.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1473, arg_1476) }; var tmp83 any; var root_1664 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = seq_1685000149__22; if linked_1665 == nil { tmp83 = ifn_1666.Invoke_O__O(arg_1667) } else { tmp83 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1664, arg_1667) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = tmp83, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1685000156__23 any; var root_1477 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = seq_1685000149__22; if linked_1478 == nil { vec__1685000156__23 = ifn_1479.Invoke_O__O(arg_1480) } else { vec__1685000156__23 = linked_1478.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1477, arg_1480) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000156__23, lang.RT_IntCast_J__I_NoInit(0), nil); var x__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000156__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1668 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = x__25; var arg_1672 any = A_arbace_go_check_A_const_211; var arg_1673 any = i__24; if linked_1669 == nil { ifn_1670.Invoke_O_O_O__O(arg_1671, arg_1672, arg_1673) } else { linked_1669.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1668, arg_1671, arg_1672, arg_1673) }; var tmp84 any; var root_1674 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = seq_1685000149__22; if linked_1675 == nil { tmp84 = ifn_1676.Invoke_O__O(arg_1677) } else { tmp84 = linked_1675.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1674, arg_1677) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = tmp84, nil, 0, 0; continue L5 } } }
//line :161:1
				break L5
			}













































			var root_1481 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = objs__16; if linked_1482 == nil { ifn_1483.Invoke_O__O(arg_1484) } else { linked_1482.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A).Invoke_O_O__O(root_1481, arg_1484) }
//line :161:1
			var seq_1685000159__17 any; var root_1485 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1487 lang.IFn
















































			if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = objs__16; if linked_1486 == nil { seq_1685000159__17 = ifn_1487.Invoke_O__O(arg_1488) } else { seq_1685000159__17 = linked_1486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1485, arg_1488) }
//line :161:1
			var chunk_1685000160__18 any; var count_1685000161__19 int64 = 0; var i_1685000162__20 int64 = 0; L6: for {
















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000162__20, count_1685000161__19) { var x__21 any = lang.Indexed_Cast(chunk_1685000160__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000162__20)); var tmp85 any; var and__1927000168__auto____22 bool; var tmp86 any = A_arbace_go_check_A_const_54; var tmp87 any; var root_1489 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = x__21; var arg_1493 any = A_arbace_go_check_A_const_93; if linked_1490 == nil { tmp87 = ifn_1491.Invoke_O_O__O(arg_1492, arg_1493) } else { tmp87 = linked_1490.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1489, arg_1492, arg_1493) }; and__1927000168__auto____22 = lang.Util_Equiv_O_O__Z_NoInit(tmp86, tmp87); if and__1927000168__auto____22 { var root_1494 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any; var root_1498 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = x__21; var arg_1502 any = A_arbace_go_check_A_const_209; if linked_1499 == nil { arg_1497 = ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { arg_1497 = linked_1499.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) }; if linked_1495 == nil { tmp85 = ifn_1496.Invoke_O__O(arg_1497) } else { tmp85 = linked_1495.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1494, arg_1497) } } else { tmp85 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22).Ref() }; if jrt.J2g_Truth(tmp85) { var root_1678 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = x__21; if linked_1679 == nil { ifn_1680.Invoke_O__O(arg_1681) } else { linked_1679.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1678, arg_1681) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } else { seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } } else { var temp__1927000414__auto____21_2 any; var root_1503 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = seq_1685000159__17; if linked_1504 == nil { temp__1927000414__auto____21_2 = ifn_1505.Invoke_O__O(arg_1506) } else { temp__1927000414__auto____21_2 = linked_1504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1503, arg_1506) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000159__22 any = temp__1927000414__auto____21_2; var tmp88 any; var root_1507 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = seq_1685000159__22; if linked_1508 == nil { tmp88 = ifn_1509.Invoke_O__O(arg_1510) } else { tmp88 = linked_1508.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1507, arg_1510) }; if jrt.J2g_Truth(tmp88) { var c__1927000678__auto____23_2 any; var root_1511 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = seq_1685000159__22; if linked_1512 == nil { c__1927000678__auto____23_2 = ifn_1513.Invoke_O__O(arg_1514) } else { c__1927000678__auto____23_2 = linked_1512.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1511, arg_1514) }; var tmp89 any; var root_1682 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = seq_1685000159__22; if linked_1683 == nil { tmp89 = ifn_1684.Invoke_O__O(arg_1685) } else { tmp89 = linked_1683.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1682, arg_1685) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp89, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__23_2 any; var root_1515 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = seq_1685000159__22; if linked_1516 == nil { x__23_2 = ifn_1517.Invoke_O__O(arg_1518) } else { x__23_2 = linked_1516.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1515, arg_1518) }; var tmp90 any; var and__1927000168__auto____24 bool; var tmp91 any = A_arbace_go_check_A_const_54; var tmp92 any; var root_1519 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1519, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = x__23_2; var arg_1523 any = A_arbace_go_check_A_const_93; if linked_1520 == nil { tmp92 = ifn_1521.Invoke_O_O__O(arg_1522, arg_1523) } else { tmp92 = linked_1520.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1519, arg_1522, arg_1523) }; and__1927000168__auto____24 = lang.Util_Equiv_O_O__Z_NoInit(tmp91, tmp92); if and__1927000168__auto____24 { var root_1524 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any; var root_1528 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = x__23_2; var arg_1532 any = A_arbace_go_check_A_const_209; if linked_1529 == nil { arg_1527 = ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { arg_1527 = linked_1529.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532) }; if linked_1525 == nil { tmp90 = ifn_1526.Invoke_O__O(arg_1527) } else { tmp90 = linked_1525.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1524, arg_1527) } } else { tmp90 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24).Ref() }; if jrt.J2g_Truth(tmp90) { var root_1686 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = x__23_2; if linked_1687 == nil { ifn_1688.Invoke_O__O(arg_1689) } else { linked_1687.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1686, arg_1689) }; var tmp93 any; var root_1690 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = seq_1685000159__22; if linked_1691 == nil { tmp93 = ifn_1692.Invoke_O__O(arg_1693) } else { tmp93 = linked_1691.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1690, arg_1693) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp93, nil, 0, 0; continue L6 } else { var tmp94 any; var root_1694 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = seq_1685000159__22; if linked_1695 == nil { tmp94 = ifn_1696.Invoke_O__O(arg_1697) } else { tmp94 = linked_1695.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1694, arg_1697) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp94, nil, 0, 0; continue L6 } } } }
//line :161:1
				break L6 }; var seq_1685000163__17 any; var root_1533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1535 lang.IFn

















































			if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = objs__16; if linked_1534 == nil { seq_1685000163__17 = ifn_1535.Invoke_O__O(arg_1536) } else { seq_1685000163__17 = linked_1534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1533, arg_1536) }
//line :161:1
			var chunk_1685000164__18 any; var count_1685000165__19 int64 = 0; var i_1685000166__20 int64 = 0; L7: for {

















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000166__20, count_1685000165__19) { var x__21_2 any = lang.Indexed_Cast(chunk_1685000164__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000166__20)); var tmp95 any; var and__1927000168__auto____22_2 bool; var tmp96 any = A_arbace_go_check_A_const_54; var tmp97 any; var root_1537 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = x__21_2; var arg_1541 any = A_arbace_go_check_A_const_93; if linked_1538 == nil { tmp97 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { tmp97 = linked_1538.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; and__1927000168__auto____22_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp96, tmp97); if and__1927000168__auto____22_2 { var root_1542 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = x__21_2; var arg_1546 any = A_arbace_go_check_A_const_209; if linked_1543 == nil { tmp95 = ifn_1544.Invoke_O_O__O(arg_1545, arg_1546) } else { tmp95 = linked_1543.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1542, arg_1545, arg_1546) } } else { tmp95 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22_2).Ref() }; if jrt.J2g_Truth(tmp95) { var root_1698 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1700 lang.IFn; if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any = x__21_2; if linked_1699 == nil { ifn_1700.Invoke_O__O(arg_1701) } else { linked_1699.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1698, arg_1701) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } else { seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } } else { var temp__1927000414__auto____21_3 any; var root_1547 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = seq_1685000163__17; if linked_1548 == nil { temp__1927000414__auto____21_3 = ifn_1549.Invoke_O__O(arg_1550) } else { temp__1927000414__auto____21_3 = linked_1548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1547, arg_1550) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000163__22 any = temp__1927000414__auto____21_3; var tmp98 any; var root_1551 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = seq_1685000163__22; if linked_1552 == nil { tmp98 = ifn_1553.Invoke_O__O(arg_1554) } else { tmp98 = linked_1552.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1551, arg_1554) }; if jrt.J2g_Truth(tmp98) { var c__1927000678__auto____23_3 any; var root_1555 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = seq_1685000163__22; if linked_1556 == nil { c__1927000678__auto____23_3 = ifn_1557.Invoke_O__O(arg_1558) } else { c__1927000678__auto____23_3 = linked_1556.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1555, arg_1558) }; var tmp99 any; var root_1702 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1704 lang.IFn; if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = seq_1685000163__22; if linked_1703 == nil { tmp99 = ifn_1704.Invoke_O__O(arg_1705) } else { tmp99 = linked_1703.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1702, arg_1705) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp99, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__23_3 any; var root_1559 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = seq_1685000163__22; if linked_1560 == nil { x__23_3 = ifn_1561.Invoke_O__O(arg_1562) } else { x__23_3 = linked_1560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1559, arg_1562) }; var tmp100 any; var and__1927000168__auto____24_2 bool; var tmp101 any = A_arbace_go_check_A_const_54; var tmp102 any; var root_1563 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = x__23_3; var arg_1567 any = A_arbace_go_check_A_const_93; if linked_1564 == nil { tmp102 = ifn_1565.Invoke_O_O__O(arg_1566, arg_1567) } else { tmp102 = linked_1564.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1563, arg_1566, arg_1567) }; and__1927000168__auto____24_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp101, tmp102); if and__1927000168__auto____24_2 { var root_1568 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = x__23_3; var arg_1572 any = A_arbace_go_check_A_const_209; if linked_1569 == nil { tmp100 = ifn_1570.Invoke_O_O__O(arg_1571, arg_1572) } else { tmp100 = linked_1569.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1568, arg_1571, arg_1572) } } else { tmp100 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24_2).Ref() }; if jrt.J2g_Truth(tmp100) { var root_1706 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = x__23_3; if linked_1707 == nil { ifn_1708.Invoke_O__O(arg_1709) } else { linked_1707.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1706, arg_1709) }; var tmp103 any; var root_1710 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = seq_1685000163__22; if linked_1711 == nil { tmp103 = ifn_1712.Invoke_O__O(arg_1713) } else { tmp103 = linked_1711.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1710, arg_1713) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp103, nil, 0, 0; continue L7 } else { var tmp104 any; var root_1714 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = seq_1685000163__22; if linked_1715 == nil { tmp104 = ifn_1716.Invoke_O__O(arg_1717) } else { tmp104 = linked_1715.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1714, arg_1717) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp104, nil, 0, 0; continue L7 } } } }
//line :161:1
				break L7 }; var seq_1685000167__17 any; var root_1573 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1575 lang.IFn


















































			if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = objs__16; if linked_1574 == nil { seq_1685000167__17 = ifn_1575.Invoke_O__O(arg_1576) } else { seq_1685000167__17 = linked_1574.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1573, arg_1576) }
//line :161:1
			var chunk_1685000168__18 any; var count_1685000169__19 int64 = 0; var i_1685000170__20 int64 = 0; L8: for {


















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000170__20, count_1685000169__19) { var x__21_3 any = lang.Indexed_Cast(chunk_1685000168__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000170__20)); var tmp105 any; var root_1577 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = A_arbace_go_check_A_const_54; var arg_1581 any; var root_1582 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = x__21_3; var arg_1586 any = A_arbace_go_check_A_const_93; if linked_1583 == nil { arg_1581 = ifn_1584.Invoke_O_O__O(arg_1585, arg_1586) } else { arg_1581 = linked_1583.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1582, arg_1585, arg_1586) }; if linked_1578 == nil { tmp105 = ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { tmp105 = linked_1578.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) }; if jrt.J2g_Truth(tmp105) { var root_1718 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = x__21_3; if linked_1719 == nil { ifn_1720.Invoke_O__O(arg_1721) } else { linked_1719.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1718, arg_1721) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } else { seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } } else { var temp__1927000414__auto____21_4 any; var root_1587 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = seq_1685000167__17; if linked_1588 == nil { temp__1927000414__auto____21_4 = ifn_1589.Invoke_O__O(arg_1590) } else { temp__1927000414__auto____21_4 = linked_1588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1587, arg_1590) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000167__22 any = temp__1927000414__auto____21_4; var tmp106 any; var root_1591 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = seq_1685000167__22; if linked_1592 == nil { tmp106 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp106 = linked_1592.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1591, arg_1594) }; if jrt.J2g_Truth(tmp106) { var c__1927000678__auto____23_4 any; var root_1595 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = seq_1685000167__22; if linked_1596 == nil { c__1927000678__auto____23_4 = ifn_1597.Invoke_O__O(arg_1598) } else { c__1927000678__auto____23_4 = linked_1596.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1595, arg_1598) }; var tmp107 any; var root_1722 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1724 lang.IFn; if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = seq_1685000167__22; if linked_1723 == nil { tmp107 = ifn_1724.Invoke_O__O(arg_1725) } else { tmp107 = linked_1723.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1722, arg_1725) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp107, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__23_4 any; var root_1599 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = seq_1685000167__22; if linked_1600 == nil { x__23_4 = ifn_1601.Invoke_O__O(arg_1602) } else { x__23_4 = linked_1600.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1599, arg_1602) }; var tmp108 any; var root_1603 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = A_arbace_go_check_A_const_54; var arg_1607 any; var root_1608 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = x__23_4; var arg_1612 any = A_arbace_go_check_A_const_93; if linked_1609 == nil { arg_1607 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { arg_1607 = linked_1609.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; if linked_1604 == nil { tmp108 = ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { tmp108 = linked_1604.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) }; if jrt.J2g_Truth(tmp108) { var root_1726 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = x__23_4; if linked_1727 == nil { ifn_1728.Invoke_O__O(arg_1729) } else { linked_1727.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1726, arg_1729) }; var tmp109 any; var root_1730 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = seq_1685000167__22; if linked_1731 == nil { tmp109 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp109 = linked_1731.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1730, arg_1733) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp109, nil, 0, 0; continue L8 } else { var tmp110 any; var root_1734 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = seq_1685000167__22; if linked_1735 == nil { tmp110 = ifn_1736.Invoke_O__O(arg_1737) } else { tmp110 = linked_1735.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1734, arg_1737) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp110, nil, 0, 0; continue L8 } } } }
//line :161:1
				break L8 }; var seq_1685000171__17 any; var root_1613 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1615 lang.IFn




















































			if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any; var root_1617 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = A_arbace_go_check_A_const_118.Invoke_O__O(ctx__12); if linked_1618 == nil { arg_1616 = ifn_1619.Invoke_O__O(arg_1620) } else { arg_1616 = linked_1618.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1617, arg_1620) }; if linked_1614 == nil { seq_1685000171__17 = ifn_1615.Invoke_O__O(arg_1616) } else { seq_1685000171__17 = linked_1614.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1613, arg_1616) }
//line :161:1
			var chunk_1685000172__18 any; var count_1685000173__19 int64 = 0; var i_1685000174__20 int64 = 0; L9: for {




















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000174__20, count_1685000173__19) { var x__21_4 any = lang.Indexed_Cast(chunk_1685000172__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000174__20)); var root_1738 any = A_arbace_go_check_A_const_212.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = x__21_4; if linked_1739 == nil { ifn_1740.Invoke_O__O(arg_1741) } else { linked_1739.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1738, arg_1741) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000174__20); continue L9 } else { var temp__1927000414__auto____21_5 any; var root_1621 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = seq_1685000171__17; if linked_1622 == nil { temp__1927000414__auto____21_5 = ifn_1623.Invoke_O__O(arg_1624) } else { temp__1927000414__auto____21_5 = linked_1622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1621, arg_1624) }; if jrt.J2g_Truth(temp__1927000414__auto____21_5) { var seq_1685000171__22 any = temp__1927000414__auto____21_5; var tmp111 any; var root_1625 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = seq_1685000171__22; if linked_1626 == nil { tmp111 = ifn_1627.Invoke_O__O(arg_1628) } else { tmp111 = linked_1626.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1625, arg_1628) }; if jrt.J2g_Truth(tmp111) { var c__1927000678__auto____23_5 any; var root_1629 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = seq_1685000171__22; if linked_1630 == nil { c__1927000678__auto____23_5 = ifn_1631.Invoke_O__O(arg_1632) } else { c__1927000678__auto____23_5 = linked_1630.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1629, arg_1632) }; var tmp112 any; var root_1742 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = seq_1685000171__22; if linked_1743 == nil { tmp112 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp112 = linked_1743.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1742, arg_1745) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp112, c__1927000678__auto____23_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L9 } else { var x__23_5 any; var root_1633 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = seq_1685000171__22; if linked_1634 == nil { x__23_5 = ifn_1635.Invoke_O__O(arg_1636) } else { x__23_5 = linked_1634.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1633, arg_1636) }; var root_1746 any = A_arbace_go_check_A_const_212.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = x__23_5; if linked_1747 == nil { ifn_1748.Invoke_O__O(arg_1749) } else { linked_1747.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1746, arg_1749) }; var tmp113 any; var root_1750 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = seq_1685000171__22; if linked_1751 == nil { tmp113 = ifn_1752.Invoke_O__O(arg_1753) } else { tmp113 = linked_1751.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1750, arg_1753) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp113, nil, 0, 0; continue L9 } } }
//line :161:1
				break L9 }; L10: for { var vs__17 any; var root_1637 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1639 lang.IFn























































					if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = A_arbace_go_check_A_const_195.Get__O(); if linked_1638 == nil { vs__17 = ifn_1639.Invoke_O__O(arg_1640) } else { vs__17 = linked_1638.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1637, arg_1640) }
					var tmp114 any; var root_1641 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = vs__17; if linked_1642 == nil { tmp114 = ifn_1643.Invoke_O__O(arg_1644) } else { tmp114 = linked_1642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1641, arg_1644) }; if jrt.J2g_Truth(tmp114) {
						var root_1754 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = A_arbace_go_check_A_const_195.Get__O(); var arg_1758 any = lang.PersistentVector_EMPTY.Ref(); if linked_1755 == nil { ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { linked_1755.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) }
//line :218:1
						var seq_1685000175__18 any; var root_1759 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1761 lang.IFn

						if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = vs__17; if linked_1760 == nil { seq_1685000175__18 = ifn_1761.Invoke_O__O(arg_1762) } else { seq_1685000175__18 = linked_1760.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1759, arg_1762) }
//line :218:1
						var chunk_1685000176__19 any; var count_1685000177__20 int64 = 0; var i_1685000178__21 int64 = 0; L11: for {

							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000178__21, count_1685000177__20) { var v__22 any = lang.Indexed_Cast(chunk_1685000176__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000178__21)); lang.IFn_Cast(v__22).Invoke__O(); seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000178__21); continue L11 } else { var temp__1927000414__auto____22 any; var root_1763 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = seq_1685000175__18; if linked_1764 == nil { temp__1927000414__auto____22 = ifn_1765.Invoke_O__O(arg_1766) } else { temp__1927000414__auto____22 = linked_1764.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1763, arg_1766) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1685000175__23 any = temp__1927000414__auto____22; var tmp115 any; var root_1767 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1769 lang.IFn; if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = seq_1685000175__23; if linked_1768 == nil { tmp115 = ifn_1769.Invoke_O__O(arg_1770) } else { tmp115 = linked_1768.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1767, arg_1770) }; if jrt.J2g_Truth(tmp115) { var c__1927000678__auto____24 any; var root_1771 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = seq_1685000175__23; if linked_1772 == nil { c__1927000678__auto____24 = ifn_1773.Invoke_O__O(arg_1774) } else { c__1927000678__auto____24 = linked_1772.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1771, arg_1774) }; var tmp116 any; var root_1779 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = seq_1685000175__23; if linked_1780 == nil { tmp116 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp116 = linked_1780.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1779, arg_1782) }; seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = tmp116, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var v__24 any; var root_1775 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = seq_1685000175__23; if linked_1776 == nil { v__24 = ifn_1777.Invoke_O__O(arg_1778) } else { v__24 = linked_1776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1775, arg_1778) }; lang.IFn_Cast(v__24).Invoke__O(); var tmp117 any; var root_1783 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = seq_1685000175__23; if linked_1784 == nil { tmp117 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp117 = linked_1784.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1783, arg_1786) }; seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = tmp117, nil, 0, 0; continue L11 } } }
//line :218:1
							break L11
						}

						continue L10 }
//line :161:1
					break L10
				}



























































			var root_1645 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, A_arbace_go_check_number_local_types_BANG__A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any; var root_1649 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any; var root_1653 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = pkg__8; var arg_1657 any = A_arbace_go_check_A_const_112; if linked_1654 == nil { arg_1652 = ifn_1655.Invoke_O_O__O(arg_1656, arg_1657) } else { arg_1652 = linked_1654.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1653, arg_1656, arg_1657) }; if linked_1650 == nil { arg_1648 = ifn_1651.Invoke_O__O(arg_1652) } else { arg_1648 = linked_1650.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1649, arg_1652) }; if linked_1646 == nil { ifn_1647.Invoke_O__O(arg_1648) } else { linked_1646.(*A_arbace_go_check_number_local_types_BANG__A).Invoke_O_O__O(root_1645, arg_1648) }
//line :161:1
			var decls__17 any; var root_827 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_829 lang.IFn





























































			if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any; var root_831 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var tmp118 any = A_arbace_go_check_check_package_fn__1685000179_A_New(); var tmp119 *jrt.Class; var fncls__841 *jrt.Class = A_arbace_go_check_check_package_fn__1685000179_A_fn_class; if fncls__841 == nil { var fncls__841d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_check_package_fn__1685000179_A_fn_class = fncls__841d; tmp119 = fncls__841d } else { tmp119 = fncls__841 }; arg_834 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp118, tmp119, nil); var arg_835 any = objs__16; if linked_832 == nil { arg_830 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { arg_830 = linked_832.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) }; if linked_828 == nil { decls__17 = ifn_829.Invoke_O__O(arg_830) } else { decls__17 = linked_828.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_827, arg_830) }
//line :161:1
			var seq_1685000181__18 any; var root_1787 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1789 lang.IFn






























































			if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = decls__17; if linked_1788 == nil { seq_1685000181__18 = ifn_1789.Invoke_O__O(arg_1790) } else { seq_1685000181__18 = linked_1788.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1787, arg_1790) }
//line :161:1
			var chunk_1685000182__19 any; var count_1685000183__20 int64 = 0; var i_1685000184__21 int64 = 0; L12: for {






























































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000184__21, count_1685000183__20) { var d__22 any = lang.Indexed_Cast(chunk_1685000182__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000184__21)); L13: for { var ls__23 any; var tmp120 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp121 any; var root_1911 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1913 lang.IFn

					if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = d__22; if linked_1912 == nil { tmp121 = ifn_1913.Invoke_O__O(arg_1914) } else { tmp121 = linked_1912.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1911, arg_1914) }; ls__23 = tmp120.Invoke_O__O(tmp121)
					var tmp122 any; var root_1915 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = ls__23; if linked_1916 == nil { tmp122 = ifn_1917.Invoke_O__O(arg_1918) } else { tmp122 = linked_1916.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1915, arg_1918) }; if jrt.J2g_Truth(tmp122) {
						var tmp123 *lang.Volatile = lang.Volatile_Cast(d__22); var tmp124 any; var root_1919 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = jrt.NN(lang.Volatile_Cast(d__22)).Deref__O(); var arg_1923 any = A_arbace_go_check_A_const_215; var arg_1924 any = lang.PersistentVector_EMPTY.Ref(); if linked_1920 == nil { tmp124 = ifn_1921.Invoke_O_O_O__O(arg_1922, arg_1923, arg_1924) } else { tmp124 = linked_1920.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1919, arg_1922, arg_1923, arg_1924) }; jrt.NN(tmp123).Reset_O__O(tmp124)
						var root_1971 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any; var tmp125 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp126 any = A_arbace_go_check_A_const_219; var tmp127 any = A_arbace_go_check_A_const_220; var tmp128 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp129 any; var root_1984 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = d__22; if linked_1985 == nil { tmp129 = ifn_1986.Invoke_O__O(arg_1987) } else { tmp129 = linked_1985.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1984, arg_1987) }; var tmp130 any = tmp128.Invoke_O__O(tmp129); var tmp131 any = A_arbace_go_check_A_const_221; var tmp132 any; var G__1685000185__24_ any; var tmp133 *lang.Keyword = A_arbace_go_check_A_const_222; var tmp134 any; var root_1988 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1988, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1990 lang.IFn; if linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = d__22; if linked_1989 == nil { tmp134 = ifn_1990.Invoke_O__O(arg_1991) } else { tmp134 = linked_1989.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1988, arg_1991) }; G__1685000185__24_ = tmp133.Invoke_O__O(tmp134); if lang.Util_Identical_O_O__Z_NoInit(G__1685000185__24_, nil) { tmp132 = nil } else { var root_1992 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1994 lang.IFn; if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = G__1685000185__24_; var arg_1996 any = A_arbace_go_check_A_const_78; if linked_1993 == nil { tmp132 = ifn_1994.Invoke_O_O__O(arg_1995, arg_1996) } else { tmp132 = linked_1993.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1992, arg_1995, arg_1996) } }; arg_1974 = tmp125.Invoke_O_O_O_O_O_O__O(tmp126, d__22, tmp127, tmp130, tmp131, tmp132); if linked_1972 == nil { ifn_1973.Invoke_O__O(arg_1974) } else { linked_1972.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1971, arg_1974) }; var tmp135 any = A_arbace_go_check_check_package_fn__1685000186_A_New_O_O(d__22, ls__23); var tmp136 *jrt.Class; var fncls__1970 *jrt.Class = A_arbace_go_check_check_package_fn__1685000186_A_fn_class; if fncls__1970 == nil { var fncls__1970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_fn__1685000186_A_fn_class = fncls__1970d; tmp136 = fncls__1970d } else { tmp136 = fncls__1970 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp135, tmp136, nil).Invoke__O()


						continue L13 }
//line :224:1
					break L13 }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000184__21); continue L12 } else { var temp__1927000414__auto____22_2 any; var root_1791 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = seq_1685000181__18; if linked_1792 == nil { temp__1927000414__auto____22_2 = ifn_1793.Invoke_O__O(arg_1794) } else { temp__1927000414__auto____22_2 = linked_1792.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1791, arg_1794) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1685000181__23 any = temp__1927000414__auto____22_2; var tmp137 any; var root_1795 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = seq_1685000181__23; if linked_1796 == nil { tmp137 = ifn_1797.Invoke_O__O(arg_1798) } else { tmp137 = linked_1796.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1795, arg_1798) }; if jrt.J2g_Truth(tmp137) { var c__1927000678__auto____24_2 any; var root_1799 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = seq_1685000181__23; if linked_1800 == nil { c__1927000678__auto____24_2 = ifn_1801.Invoke_O__O(arg_1802) } else { c__1927000678__auto____24_2 = linked_1800.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1799, arg_1802) }; var tmp138 any; var root_1997 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = seq_1685000181__23; if linked_1998 == nil { tmp138 = ifn_1999.Invoke_O__O(arg_2000) } else { tmp138 = linked_1998.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1997, arg_2000) }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = tmp138, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__24 any; var root_1803 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = seq_1685000181__23; if linked_1804 == nil { d__24 = ifn_1805.Invoke_O__O(arg_1806) } else { d__24 = linked_1804.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1803, arg_1806) }; L14: for { var ls__25 any; var tmp139 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp140 any; var root_2001 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2003 lang.IFn

						if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = d__24; if linked_2002 == nil { tmp140 = ifn_2003.Invoke_O__O(arg_2004) } else { tmp140 = linked_2002.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2001, arg_2004) }; ls__25 = tmp139.Invoke_O__O(tmp140)
						var tmp141 any; var root_2005 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = ls__25; if linked_2006 == nil { tmp141 = ifn_2007.Invoke_O__O(arg_2008) } else { tmp141 = linked_2006.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2005, arg_2008) }; if jrt.J2g_Truth(tmp141) {
							var tmp142 *lang.Volatile = lang.Volatile_Cast(d__24); var tmp143 any; var root_2009 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = jrt.NN(lang.Volatile_Cast(d__24)).Deref__O(); var arg_2013 any = A_arbace_go_check_A_const_215; var arg_2014 any = lang.PersistentVector_EMPTY.Ref(); if linked_2010 == nil { tmp143 = ifn_2011.Invoke_O_O_O__O(arg_2012, arg_2013, arg_2014) } else { tmp143 = linked_2010.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2009, arg_2012, arg_2013, arg_2014) }; jrt.NN(tmp142).Reset_O__O(tmp143)
							var root_2061 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any; var tmp144 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp145 any = A_arbace_go_check_A_const_219; var tmp146 any = A_arbace_go_check_A_const_220; var tmp147 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp148 any; var root_2074 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = d__24; if linked_2075 == nil { tmp148 = ifn_2076.Invoke_O__O(arg_2077) } else { tmp148 = linked_2075.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2074, arg_2077) }; var tmp149 any = tmp147.Invoke_O__O(tmp148); var tmp150 any = A_arbace_go_check_A_const_221; var tmp151 any; var G__1685000192__26_ any; var tmp152 *lang.Keyword = A_arbace_go_check_A_const_222; var tmp153 any; var root_2078 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = d__24; if linked_2079 == nil { tmp153 = ifn_2080.Invoke_O__O(arg_2081) } else { tmp153 = linked_2079.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2078, arg_2081) }; G__1685000192__26_ = tmp152.Invoke_O__O(tmp153); if lang.Util_Identical_O_O__Z_NoInit(G__1685000192__26_, nil) { tmp151 = nil } else { var root_2082 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = G__1685000192__26_; var arg_2086 any = A_arbace_go_check_A_const_78; if linked_2083 == nil { tmp151 = ifn_2084.Invoke_O_O__O(arg_2085, arg_2086) } else { tmp151 = linked_2083.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2082, arg_2085, arg_2086) } }; arg_2064 = tmp144.Invoke_O_O_O_O_O_O__O(tmp145, d__24, tmp146, tmp149, tmp150, tmp151); if linked_2062 == nil { ifn_2063.Invoke_O__O(arg_2064) } else { linked_2062.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2061, arg_2064) }; var tmp154 any = A_arbace_go_check_check_package_fn__1685000193_A_New_O_O(d__24, ls__25); var tmp155 *jrt.Class; var fncls__2060 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_A_fn_class; if fncls__2060 == nil { var fncls__2060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_check_check_package_fn__1685000193_A_fn_class = fncls__2060d; tmp155 = fncls__2060d } else { tmp155 = fncls__2060 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp154, tmp155, nil).Invoke__O()


							continue L14 }
//line :224:1
						break L14 }; var tmp156 any; var root_2087 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = seq_1685000181__23; if linked_2088 == nil { tmp156 = ifn_2089.Invoke_O__O(arg_2090) } else { tmp156 = linked_2088.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2087, arg_2090) }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = tmp156, nil, 0, 0; continue L12 } } }
//line :161:1
				break L12 }; var seq_1685000199__18 any; var root_1807 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1809 lang.IFn








































































			if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = decls__17; if linked_1808 == nil { seq_1685000199__18 = ifn_1809.Invoke_O__O(arg_1810) } else { seq_1685000199__18 = linked_1808.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1807, arg_1810) }
//line :161:1
			var chunk_1685000200__19 any; var count_1685000201__20 int64 = 0; var i_1685000202__21 int64 = 0; L15: for {








































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000202__21, count_1685000201__20) { var d__22_2 any = lang.Indexed_Cast(chunk_1685000200__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000202__21)); var tmp157 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp158 any; var root_1811 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = d__22_2; if linked_1812 == nil { tmp158 = ifn_1813.Invoke_O__O(arg_1814) } else { tmp158 = linked_1812.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1811, arg_1814) }; if jrt.J2g_Truth(tmp157.Invoke_O__O(tmp158)) {
					var root_2103 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any; var tmp159 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp160 any = A_arbace_go_check_A_const_219; var tmp161 any = A_arbace_go_check_A_const_220; var tmp162 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp163 any; var root_2114 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = d__22_2; if linked_2115 == nil { tmp163 = ifn_2116.Invoke_O__O(arg_2117) } else { tmp163 = linked_2115.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2114, arg_2117) }; arg_2106 = tmp159.Invoke_O_O_O_O__O(tmp160, d__22_2, tmp161, tmp162.Invoke_O__O(tmp163)); if linked_2104 == nil { ifn_2105.Invoke_O__O(arg_2106) } else { linked_2104.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2103, arg_2106) }; var tmp164 any = A_arbace_go_check_check_package_fn__1685000203_A_New_O(d__22_2); var tmp165 *jrt.Class; var fncls__2102 *jrt.Class = A_arbace_go_check_check_package_fn__1685000203_A_fn_class; if fncls__2102 == nil { var fncls__2102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_fn__1685000203_A_fn_class = fncls__2102d; tmp165 = fncls__2102d } else { tmp165 = fncls__2102 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp164, tmp165, nil).Invoke__O()
//line :234:1
					seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000202__21); continue L15 } else { seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000202__21); continue L15 } } else { var temp__1927000414__auto____22_3 any; var root_1815 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = seq_1685000199__18; if linked_1816 == nil { temp__1927000414__auto____22_3 = ifn_1817.Invoke_O__O(arg_1818) } else { temp__1927000414__auto____22_3 = linked_1816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1815, arg_1818) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1685000199__23 any = temp__1927000414__auto____22_3; var tmp166 any; var root_1819 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = seq_1685000199__23; if linked_1820 == nil { tmp166 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp166 = linked_1820.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1819, arg_1822) }; if jrt.J2g_Truth(tmp166) { var c__1927000678__auto____24_3 any; var root_1823 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = seq_1685000199__23; if linked_1824 == nil { c__1927000678__auto____24_3 = ifn_1825.Invoke_O__O(arg_1826) } else { c__1927000678__auto____24_3 = linked_1824.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1823, arg_1826) }; var tmp167 any; var root_2118 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = seq_1685000199__23; if linked_2119 == nil { tmp167 = ifn_2120.Invoke_O__O(arg_2121) } else { tmp167 = linked_2119.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2118, arg_2121) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp167, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__24_2 any; var root_1827 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = seq_1685000199__23; if linked_1828 == nil { d__24_2 = ifn_1829.Invoke_O__O(arg_1830) } else { d__24_2 = linked_1828.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1827, arg_1830) }; var tmp168 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp169 any; var root_1831 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1833 lang.IFn; if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = d__24_2; if linked_1832 == nil { tmp169 = ifn_1833.Invoke_O__O(arg_1834) } else { tmp169 = linked_1832.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1831, arg_1834) }; if jrt.J2g_Truth(tmp168.Invoke_O__O(tmp169)) {
						var root_2134 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var tmp170 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp171 any = A_arbace_go_check_A_const_219; var tmp172 any = A_arbace_go_check_A_const_220; var tmp173 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp174 any; var root_2145 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2147 lang.IFn; if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = d__24_2; if linked_2146 == nil { tmp174 = ifn_2147.Invoke_O__O(arg_2148) } else { tmp174 = linked_2146.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2145, arg_2148) }; arg_2137 = tmp170.Invoke_O_O_O_O__O(tmp171, d__24_2, tmp172, tmp173.Invoke_O__O(tmp174)); if linked_2135 == nil { ifn_2136.Invoke_O__O(arg_2137) } else { linked_2135.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2134, arg_2137) }; var tmp175 any = A_arbace_go_check_check_package_fn__1685000205_A_New_O(d__24_2); var tmp176 *jrt.Class; var fncls__2133 *jrt.Class = A_arbace_go_check_check_package_fn__1685000205_A_fn_class; if fncls__2133 == nil { var fncls__2133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_fn__1685000205_A_fn_class = fncls__2133d; tmp176 = fncls__2133d } else { tmp176 = fncls__2133 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp175, tmp176, nil).Invoke__O()
//line :234:1
						var tmp177 any; var root_2149 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2151 lang.IFn; if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = seq_1685000199__23; if linked_2150 == nil { tmp177 = ifn_2151.Invoke_O__O(arg_2152) } else { tmp177 = linked_2150.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2149, arg_2152) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp177, nil, 0, 0; continue L15 } else { var tmp178 any; var root_2153 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = seq_1685000199__23; if linked_2154 == nil { tmp178 = ifn_2155.Invoke_O__O(arg_2156) } else { tmp178 = linked_2154.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2153, arg_2156) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp178, nil, 0, 0; continue L15 } } } }
//line :161:1
				break L15
			}












































































			if jrt.J2g_Truth(resolving__10) { var seq_1685000207__18 any; var root_1835 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1835, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1837 lang.IFn
				if linked_1836 == nil { ifn_1837 = lang.IFn_Cast(root_1835) } else { ifn_1837 = nil }; var arg_1838 any = decls__17; if linked_1836 == nil { seq_1685000207__18 = ifn_1837.Invoke_O__O(arg_1838) } else { seq_1685000207__18 = linked_1836.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1835, arg_1838) }
//line :239:1
				var chunk_1685000208__19 any; var count_1685000209__20 int64 = 0; var i_1685000210__21 int64 = 0; L16: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000210__21, count_1685000209__20) { var d__22_3 any = lang.Indexed_Cast(chunk_1685000208__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000210__21)); var tmp179 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp180 any; var root_1839 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1841 lang.IFn; if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any = d__22_3; if linked_1840 == nil { tmp180 = ifn_1841.Invoke_O__O(arg_1842) } else { tmp180 = linked_1840.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1839, arg_1842) }; if jrt.J2g_Truth(tmp179.Invoke_O__O(tmp180)) { var seq_1685000215__23 any; var root_2157 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any; var root_2161 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2163 lang.IFn
						if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any; var tmp181 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp182 any; var root_2165 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2165, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2167 lang.IFn; if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = d__22_3; if linked_2166 == nil { tmp182 = ifn_2167.Invoke_O__O(arg_2168) } else { tmp182 = linked_2166.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2165, arg_2168) }; arg_2164 = tmp181.Invoke_O__O(tmp182); if linked_2162 == nil { arg_2160 = ifn_2163.Invoke_O__O(arg_2164) } else { arg_2160 = linked_2162.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2161, arg_2164) }
//line :240:1
						if linked_2158 == nil { seq_1685000215__23 = ifn_2159.Invoke_O__O(arg_2160) } else { seq_1685000215__23 = linked_2158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2157, arg_2160) }; var chunk_1685000216__24 any; var count_1685000217__25 int64 = 0; var i_1685000218__26 int64 = 0; L17: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000218__26, count_1685000217__25) { var n__27 any = lang.Indexed_Cast(chunk_1685000216__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000218__26)); var tmp183 any; var tmp184 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____28 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp184, A_arbace_go_check_A_const_50.Invoke_O__O(n__27))

							if and__1927000168__auto____28 { tmp183 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__27)) } else { tmp183 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____28).Ref() }
//line :240:1
							if jrt.J2g_Truth(tmp183) {


								var root_2185 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__27); var arg_2189 any; var tmp185 any = A_arbace_go_check_A_const_225; var tmp186 any = A_arbace_go_check_A_const_225.Invoke_O__O(n__27); var tmp187 any = A_arbace_go_check_A_const_54; var G__1685000219__28_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp185, tmp186, tmp187, A_arbace_go_check_A_const_54.Invoke_O__O(n__27), A_arbace_go_check_A_const_226, jrt.Boolean_TRUE.Ref())); var tmp188 *lang.Keyword = A_arbace_go_check_A_const_227; if jrt.J2g_Truth(tmp188.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__27))) {

									var root_2190 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = G__1685000219__28_; var arg_2194 any = A_arbace_go_check_A_const_228; var arg_2195 any = jrt.Boolean_TRUE.Ref(); if linked_2191 == nil { arg_2189 = ifn_2192.Invoke_O_O_O__O(arg_2193, arg_2194, arg_2195) } else { arg_2189 = linked_2191.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2190, arg_2193, arg_2194, arg_2195) } } else {
//line :243:1
										arg_2189 = G__1685000219__28_ }; if linked_2186 == nil { ifn_2187.Invoke_O_O__O(arg_2188, arg_2189) } else { linked_2186.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2185, arg_2188, arg_2189) }
//line :240:1
								seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000218__26); continue L17 } else { seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000218__26); continue L17 } } else { var temp__1927000414__auto____27 any; var root_2169 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2171 lang.IFn; if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any = seq_1685000215__23; if linked_2170 == nil { temp__1927000414__auto____27 = ifn_2171.Invoke_O__O(arg_2172) } else { temp__1927000414__auto____27 = linked_2170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2169, arg_2172) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var seq_1685000215__28 any = temp__1927000414__auto____27; var tmp189 any; var root_2173 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = seq_1685000215__28; if linked_2174 == nil { tmp189 = ifn_2175.Invoke_O__O(arg_2176) } else { tmp189 = linked_2174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2173, arg_2176) }; if jrt.J2g_Truth(tmp189) { var c__1927000678__auto____29 any; var root_2177 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = seq_1685000215__28; if linked_2178 == nil { c__1927000678__auto____29 = ifn_2179.Invoke_O__O(arg_2180) } else { c__1927000678__auto____29 = linked_2178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2177, arg_2180) }; var tmp190 any; var root_2196 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2198 lang.IFn; if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = seq_1685000215__28; if linked_2197 == nil { tmp190 = ifn_2198.Invoke_O__O(arg_2199) } else { tmp190 = linked_2197.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2196, arg_2199) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp190, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L17 } else { var n__29 any; var root_2181 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = seq_1685000215__28; if linked_2182 == nil { n__29 = ifn_2183.Invoke_O__O(arg_2184) } else { n__29 = linked_2182.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2181, arg_2184) }; var tmp191 any; var tmp192 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____30 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp192, A_arbace_go_check_A_const_50.Invoke_O__O(n__29))

									if and__1927000168__auto____30 { tmp191 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__29)) } else { tmp191 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30).Ref() }
//line :240:1
									if jrt.J2g_Truth(tmp191) {


										var root_2200 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__29); var arg_2204 any; var tmp193 any = A_arbace_go_check_A_const_225; var tmp194 any = A_arbace_go_check_A_const_225.Invoke_O__O(n__29); var tmp195 any = A_arbace_go_check_A_const_54; var G__1685000220__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp193, tmp194, tmp195, A_arbace_go_check_A_const_54.Invoke_O__O(n__29), A_arbace_go_check_A_const_226, jrt.Boolean_TRUE.Ref())); var tmp196 *lang.Keyword = A_arbace_go_check_A_const_227; if jrt.J2g_Truth(tmp196.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__29))) {

											var root_2205 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2207 lang.IFn; if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any = G__1685000220__30_; var arg_2209 any = A_arbace_go_check_A_const_228; var arg_2210 any = jrt.Boolean_TRUE.Ref(); if linked_2206 == nil { arg_2204 = ifn_2207.Invoke_O_O_O__O(arg_2208, arg_2209, arg_2210) } else { arg_2204 = linked_2206.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2205, arg_2208, arg_2209, arg_2210) } } else {
//line :243:1
												arg_2204 = G__1685000220__30_ }; if linked_2201 == nil { ifn_2202.Invoke_O_O__O(arg_2203, arg_2204) } else { linked_2201.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2200, arg_2203, arg_2204) }
//line :240:1
										var tmp197 any; var root_2211 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = seq_1685000215__28; if linked_2212 == nil { tmp197 = ifn_2213.Invoke_O__O(arg_2214) } else { tmp197 = linked_2212.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2211, arg_2214) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp197, nil, 0, 0; continue L17 } else { var tmp198 any; var root_2215 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = seq_1685000215__28; if linked_2216 == nil { tmp198 = ifn_2217.Invoke_O__O(arg_2218) } else { tmp198 = linked_2216.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2215, arg_2218) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp198, nil, 0, 0; continue L17 } } } }; break L17 }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__21); continue L16 } else { seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__21); continue L16 } } else { var temp__1927000414__auto____22_4 any; var root_1843 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1843, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1845 lang.IFn; if linked_1844 == nil { ifn_1845 = lang.IFn_Cast(root_1843) } else { ifn_1845 = nil }; var arg_1846 any = seq_1685000207__18; if linked_1844 == nil { temp__1927000414__auto____22_4 = ifn_1845.Invoke_O__O(arg_1846) } else { temp__1927000414__auto____22_4 = linked_1844.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1843, arg_1846) }; if jrt.J2g_Truth(temp__1927000414__auto____22_4) { var seq_1685000207__23 any = temp__1927000414__auto____22_4; var tmp199 any; var root_1847 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = seq_1685000207__23; if linked_1848 == nil { tmp199 = ifn_1849.Invoke_O__O(arg_1850) } else { tmp199 = linked_1848.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1847, arg_1850) }; if jrt.J2g_Truth(tmp199) { var c__1927000678__auto____24_4 any; var root_1851 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = seq_1685000207__23; if linked_1852 == nil { c__1927000678__auto____24_4 = ifn_1853.Invoke_O__O(arg_1854) } else { c__1927000678__auto____24_4 = linked_1852.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1851, arg_1854) }; var tmp200 any; var root_2219 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = seq_1685000207__23; if linked_2220 == nil { tmp200 = ifn_2221.Invoke_O__O(arg_2222) } else { tmp200 = linked_2220.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2219, arg_2222) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp200, c__1927000678__auto____24_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var d__24_3 any; var root_1855 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any = seq_1685000207__23; if linked_1856 == nil { d__24_3 = ifn_1857.Invoke_O__O(arg_1858) } else { d__24_3 = linked_1856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1855, arg_1858) }; var tmp201 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp202 any; var root_1859 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1861 lang.IFn; if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any = d__24_3; if linked_1860 == nil { tmp202 = ifn_1861.Invoke_O__O(arg_1862) } else { tmp202 = linked_1860.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1859, arg_1862) }; if jrt.J2g_Truth(tmp201.Invoke_O__O(tmp202)) { var seq_1685000211__25 any; var root_2223 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any; var root_2227 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2229 lang.IFn
											if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any; var tmp203 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp204 any; var root_2231 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = d__24_3; if linked_2232 == nil { tmp204 = ifn_2233.Invoke_O__O(arg_2234) } else { tmp204 = linked_2232.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2231, arg_2234) }; arg_2230 = tmp203.Invoke_O__O(tmp204); if linked_2228 == nil { arg_2226 = ifn_2229.Invoke_O__O(arg_2230) } else { arg_2226 = linked_2228.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2227, arg_2230) }
//line :240:1
											if linked_2224 == nil { seq_1685000211__25 = ifn_2225.Invoke_O__O(arg_2226) } else { seq_1685000211__25 = linked_2224.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2223, arg_2226) }; var chunk_1685000212__26 any; var count_1685000213__27 int64 = 0; var i_1685000214__28 int64 = 0; L18: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000214__28, count_1685000213__27) { var n__29_2 any = lang.Indexed_Cast(chunk_1685000212__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000214__28)); var tmp205 any; var tmp206 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____30_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp206, A_arbace_go_check_A_const_50.Invoke_O__O(n__29_2))

												if and__1927000168__auto____30_2 { tmp205 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__29_2)) } else { tmp205 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30_2).Ref() }
//line :240:1
												if jrt.J2g_Truth(tmp205) {


													var root_2251 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2251, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__29_2); var arg_2255 any; var tmp207 any = A_arbace_go_check_A_const_225; var tmp208 any = A_arbace_go_check_A_const_225.Invoke_O__O(n__29_2); var tmp209 any = A_arbace_go_check_A_const_54; var G__1685000221__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp207, tmp208, tmp209, A_arbace_go_check_A_const_54.Invoke_O__O(n__29_2), A_arbace_go_check_A_const_226, jrt.Boolean_TRUE.Ref())); var tmp210 *lang.Keyword = A_arbace_go_check_A_const_227; if jrt.J2g_Truth(tmp210.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__29_2))) {

														var root_2256 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = G__1685000221__30_; var arg_2260 any = A_arbace_go_check_A_const_228; var arg_2261 any = jrt.Boolean_TRUE.Ref(); if linked_2257 == nil { arg_2255 = ifn_2258.Invoke_O_O_O__O(arg_2259, arg_2260, arg_2261) } else { arg_2255 = linked_2257.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2256, arg_2259, arg_2260, arg_2261) } } else {
//line :243:1
															arg_2255 = G__1685000221__30_ }; if linked_2252 == nil { ifn_2253.Invoke_O_O__O(arg_2254, arg_2255) } else { linked_2252.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2251, arg_2254, arg_2255) }
//line :240:1
													seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__28); continue L18 } else { seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__28); continue L18 } } else { var temp__1927000414__auto____29 any; var root_2235 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2237 lang.IFn; if linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = seq_1685000211__25; if linked_2236 == nil { temp__1927000414__auto____29 = ifn_2237.Invoke_O__O(arg_2238) } else { temp__1927000414__auto____29 = linked_2236.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2235, arg_2238) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1685000211__30 any = temp__1927000414__auto____29; var tmp211 any; var root_2239 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = seq_1685000211__30; if linked_2240 == nil { tmp211 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp211 = linked_2240.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2239, arg_2242) }; if jrt.J2g_Truth(tmp211) { var c__1927000678__auto____31 any; var root_2243 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = seq_1685000211__30; if linked_2244 == nil { c__1927000678__auto____31 = ifn_2245.Invoke_O__O(arg_2246) } else { c__1927000678__auto____31 = linked_2244.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2243, arg_2246) }; var tmp212 any; var root_2262 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = seq_1685000211__30; if linked_2263 == nil { tmp212 = ifn_2264.Invoke_O__O(arg_2265) } else { tmp212 = linked_2263.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2262, arg_2265) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp212, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L18 } else { var n__31 any; var root_2247 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = seq_1685000211__30; if linked_2248 == nil { n__31 = ifn_2249.Invoke_O__O(arg_2250) } else { n__31 = linked_2248.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2247, arg_2250) }; var tmp213 any; var tmp214 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____32 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp214, A_arbace_go_check_A_const_50.Invoke_O__O(n__31))

														if and__1927000168__auto____32 { tmp213 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__31)) } else { tmp213 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____32).Ref() }
//line :240:1
														if jrt.J2g_Truth(tmp213) {


															var root_2266 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__31); var arg_2270 any; var tmp215 any = A_arbace_go_check_A_const_225; var tmp216 any = A_arbace_go_check_A_const_225.Invoke_O__O(n__31); var tmp217 any = A_arbace_go_check_A_const_54; var G__1685000222__32_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp215, tmp216, tmp217, A_arbace_go_check_A_const_54.Invoke_O__O(n__31), A_arbace_go_check_A_const_226, jrt.Boolean_TRUE.Ref())); var tmp218 *lang.Keyword = A_arbace_go_check_A_const_227; if jrt.J2g_Truth(tmp218.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__31))) {

																var root_2271 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = G__1685000222__32_; var arg_2275 any = A_arbace_go_check_A_const_228; var arg_2276 any = jrt.Boolean_TRUE.Ref(); if linked_2272 == nil { arg_2270 = ifn_2273.Invoke_O_O_O__O(arg_2274, arg_2275, arg_2276) } else { arg_2270 = linked_2272.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2271, arg_2274, arg_2275, arg_2276) } } else {
//line :243:1
																	arg_2270 = G__1685000222__32_ }; if linked_2267 == nil { ifn_2268.Invoke_O_O__O(arg_2269, arg_2270) } else { linked_2267.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2266, arg_2269, arg_2270) }
//line :240:1
															var tmp219 any; var root_2277 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = seq_1685000211__30; if linked_2278 == nil { tmp219 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp219 = linked_2278.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2277, arg_2280) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp219, nil, 0, 0; continue L18 } else { var tmp220 any; var root_2281 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = seq_1685000211__30; if linked_2282 == nil { tmp220 = ifn_2283.Invoke_O__O(arg_2284) } else { tmp220 = linked_2282.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2281, arg_2284) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp220, nil, 0, 0; continue L18 } } } }; break L18 }; var tmp221 any; var root_2285 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = seq_1685000207__23; if linked_2286 == nil { tmp221 = ifn_2287.Invoke_O__O(arg_2288) } else { tmp221 = linked_2286.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2285, arg_2288) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp221, nil, 0, 0; continue L16 } else { var tmp222 any; var root_2289 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = seq_1685000207__23; if linked_2290 == nil { tmp222 = ifn_2291.Invoke_O__O(arg_2292) } else { tmp222 = linked_2290.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2289, arg_2292) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp222, nil, 0, 0; continue L16 } } } }
//line :239:1
					break L16 } }
//line :161:1
			var seq_1685000223__18 any; var root_1863 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1865 lang.IFn





















































































			if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = decls__17; if linked_1864 == nil { seq_1685000223__18 = ifn_1865.Invoke_O__O(arg_1866) } else { seq_1685000223__18 = linked_1864.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1863, arg_1866) }
//line :161:1
			var chunk_1685000224__19 any; var count_1685000225__20 int64 = 0; var i_1685000226__21 int64 = 0; L19: for {





















































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000226__21, count_1685000225__20) { var d__22_4 any = lang.Indexed_Cast(chunk_1685000224__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000226__21)); var tmp223 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp224 any; var root_1867 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = d__22_4; if linked_1868 == nil { tmp224 = ifn_1869.Invoke_O__O(arg_1870) } else { tmp224 = linked_1868.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1867, arg_1870) }; if jrt.J2g_Truth(tmp223.Invoke_O__O(tmp224)) {
					var root_2293 any = A_arbace_go_check_A_const_229.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any; var tmp225 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp226 any; var root_2298 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2300 lang.IFn; if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any = d__22_4; if linked_2299 == nil { tmp226 = ifn_2300.Invoke_O__O(arg_2301) } else { tmp226 = linked_2299.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2298, arg_2301) }; arg_2296 = tmp225.Invoke_O__O(tmp226); var arg_2297 any; var tmp227 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp228 any; var root_2302 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = d__22_4; if linked_2303 == nil { tmp228 = ifn_2304.Invoke_O__O(arg_2305) } else { tmp228 = linked_2303.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2302, arg_2305) }; arg_2297 = tmp227.Invoke_O__O(tmp228); if linked_2294 == nil { ifn_2295.Invoke_O_O__O(arg_2296, arg_2297) } else { linked_2294.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2293, arg_2296, arg_2297) }
//line :247:1
					seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } else { seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } } else { var temp__1927000414__auto____22_5 any; var root_1871 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = seq_1685000223__18; if linked_1872 == nil { temp__1927000414__auto____22_5 = ifn_1873.Invoke_O__O(arg_1874) } else { temp__1927000414__auto____22_5 = linked_1872.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1871, arg_1874) }; if jrt.J2g_Truth(temp__1927000414__auto____22_5) { var seq_1685000223__23 any = temp__1927000414__auto____22_5; var tmp229 any; var root_1875 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = seq_1685000223__23; if linked_1876 == nil { tmp229 = ifn_1877.Invoke_O__O(arg_1878) } else { tmp229 = linked_1876.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1875, arg_1878) }; if jrt.J2g_Truth(tmp229) { var c__1927000678__auto____24_5 any; var root_1879 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = seq_1685000223__23; if linked_1880 == nil { c__1927000678__auto____24_5 = ifn_1881.Invoke_O__O(arg_1882) } else { c__1927000678__auto____24_5 = linked_1880.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1879, arg_1882) }; var tmp230 any; var root_2306 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = seq_1685000223__23; if linked_2307 == nil { tmp230 = ifn_2308.Invoke_O__O(arg_2309) } else { tmp230 = linked_2307.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2306, arg_2309) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp230, c__1927000678__auto____24_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L19 } else { var d__24_4 any; var root_1883 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = seq_1685000223__23; if linked_1884 == nil { d__24_4 = ifn_1885.Invoke_O__O(arg_1886) } else { d__24_4 = linked_1884.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1883, arg_1886) }; var tmp231 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp232 any; var root_1887 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = d__24_4; if linked_1888 == nil { tmp232 = ifn_1889.Invoke_O__O(arg_1890) } else { tmp232 = linked_1888.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1887, arg_1890) }; if jrt.J2g_Truth(tmp231.Invoke_O__O(tmp232)) {
						var root_2310 any = A_arbace_go_check_A_const_229.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any; var tmp233 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp234 any; var root_2315 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = d__24_4; if linked_2316 == nil { tmp234 = ifn_2317.Invoke_O__O(arg_2318) } else { tmp234 = linked_2316.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2315, arg_2318) }; arg_2313 = tmp233.Invoke_O__O(tmp234); var arg_2314 any; var tmp235 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp236 any; var root_2319 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = d__24_4; if linked_2320 == nil { tmp236 = ifn_2321.Invoke_O__O(arg_2322) } else { tmp236 = linked_2320.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2319, arg_2322) }; arg_2314 = tmp235.Invoke_O__O(tmp236); if linked_2311 == nil { ifn_2312.Invoke_O_O__O(arg_2313, arg_2314) } else { linked_2311.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2310, arg_2313, arg_2314) }
//line :247:1
						var tmp237 any; var root_2323 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2323, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2325 lang.IFn; if linked_2324 == nil { ifn_2325 = lang.IFn_Cast(root_2323) } else { ifn_2325 = nil }; var arg_2326 any = seq_1685000223__23; if linked_2324 == nil { tmp237 = ifn_2325.Invoke_O__O(arg_2326) } else { tmp237 = linked_2324.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2323, arg_2326) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp237, nil, 0, 0; continue L19 } else { var tmp238 any; var root_2327 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = seq_1685000223__23; if linked_2328 == nil { tmp238 = ifn_2329.Invoke_O__O(arg_2330) } else { tmp238 = linked_2328.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2327, arg_2330) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp238, nil, 0, 0; continue L19 } } } }
//line :161:1
				break L19 }; var seq_1685000227__18 any; var root_1891 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1893 lang.IFn























































































			if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = fis__13; if linked_1892 == nil { seq_1685000227__18 = ifn_1893.Invoke_O__O(arg_1894) } else { seq_1685000227__18 = linked_1892.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1891, arg_1894) }
//line :161:1
			var chunk_1685000228__19 any; var count_1685000229__20 int64 = 0; var i_1685000230__21 int64 = 0; L20: for {























































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000230__21, count_1685000229__20) { var fi__22_5 any = lang.Indexed_Cast(chunk_1685000228__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000230__21)); var root_2331 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = fi__22_5; if linked_2332 == nil { ifn_2333.Invoke_O__O(arg_2334) } else { linked_2332.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2331, arg_2334) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000230__21); continue L20 } else { var temp__1927000414__auto____22_6 any; var root_1895 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = seq_1685000227__18; if linked_1896 == nil { temp__1927000414__auto____22_6 = ifn_1897.Invoke_O__O(arg_1898) } else { temp__1927000414__auto____22_6 = linked_1896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1895, arg_1898) }; if jrt.J2g_Truth(temp__1927000414__auto____22_6) { var seq_1685000227__23 any = temp__1927000414__auto____22_6; var tmp239 any; var root_1899 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = seq_1685000227__23; if linked_1900 == nil { tmp239 = ifn_1901.Invoke_O__O(arg_1902) } else { tmp239 = linked_1900.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1899, arg_1902) }; if jrt.J2g_Truth(tmp239) { var c__1927000678__auto____24_6 any; var root_1903 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = seq_1685000227__23; if linked_1904 == nil { c__1927000678__auto____24_6 = ifn_1905.Invoke_O__O(arg_1906) } else { c__1927000678__auto____24_6 = linked_1904.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1903, arg_1906) }; var tmp240 any; var root_2335 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = seq_1685000227__23; if linked_2336 == nil { tmp240 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp240 = linked_2336.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2335, arg_2338) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = tmp240, c__1927000678__auto____24_6, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_6))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L20 } else { var fi__24 any; var root_1907 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = seq_1685000227__23; if linked_1908 == nil { fi__24 = ifn_1909.Invoke_O__O(arg_1910) } else { fi__24 = linked_1908.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1907, arg_1910) }; var root_2339 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = fi__24; if linked_2340 == nil { ifn_2341.Invoke_O__O(arg_2342) } else { linked_2340.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2339, arg_2342) }; var tmp241 any; var root_2343 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = seq_1685000227__23; if linked_2344 == nil { tmp241 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp241 = linked_2344.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2343, arg_2346) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = tmp241, nil, 0, 0; continue L20 } } }
//line :161:1
				break L20 }; var order__18 any; var root_842 any = A_arbace_go_check_A_const_128.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_844 lang.IFn

























































































			if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = objs__16; if linked_843 == nil { order__18 = ifn_844.Invoke_O__O(arg_845) } else { order__18 = linked_843.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_842, arg_845) }
//line :161:1
			var ___19 any; var tmp242 any; var root_846 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_848 lang.IFn; _ = ___19



























































































			if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = errors__9; if linked_851 == nil { arg_849 = ifn_852.Invoke_O__O(arg_853) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_850, arg_853) }; if linked_847 == nil { tmp242 = ifn_848.Invoke_O__O(arg_849) } else { tmp242 = linked_847.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_846, arg_849) }; if jrt.J2g_Truth(tmp242) { var root_854 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; if linked_855 == nil { ___19 = ifn_856.Invoke__O() } else { ___19 = linked_855.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A).Invoke_O__O(root_854) } } else { ___19 = nil }
//line :161:1
			var ___20 any; var tmp243 any; var root_857 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_859 lang.IFn; _ = ___20





























































































			if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = errors__9; if linked_862 == nil { arg_860 = ifn_863.Invoke_O__O(arg_864) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_861, arg_864) }; if linked_858 == nil { tmp243 = ifn_859.Invoke_O__O(arg_860) } else { tmp243 = linked_858.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(tmp243) { var root_865 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; if linked_866 == nil { ___20 = ifn_867.Invoke__O() } else { ___20 = linked_866.(*aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A).Invoke_O__O(root_865) } } else { ___20 = nil }
//line :161:1
			var say__21 any; var root_868 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_870 lang.IFn






























































































			if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = src__0; var arg_872 any = A_arbace_go_check_A_const_132; if linked_869 == nil { say__21 = ifn_870.Invoke_O_O__O(arg_871, arg_872) } else { say__21 = linked_869.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_868, arg_871, arg_872) }
//line :161:1
			var init_entry__22 any; var tmp244 any = A_arbace_go_check_check_package_init_entry__1685000231_A_New(); var tmp245 *jrt.Class
			var fncls__913 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class































































































			if fncls__913 == nil { var fncls__913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class = fncls__913d; tmp245 = fncls__913d } else { tmp245 = fncls__913 }; init_entry__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp244, tmp245, nil)
//line :161:1
			var have__23 any; var root_914 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_916 lang.IFn


































































































			if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = init_entry__22; var arg_918 any = order__18; if linked_915 == nil { have__23 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { have__23 = linked_915.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }
//line :161:1
			var norm__24 any; var tmp246 any = A_arbace_go_check_check_package_norm__1685000235_A_New(); var tmp247 *jrt.Class
			var fncls__947 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000235_A_fn_class




































































































			if fncls__947 == nil { var fncls__947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_norm__1685000235_A_fn_class = fncls__947d; tmp247 = fncls__947d } else { tmp247 = fncls__947 }; norm__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp246, tmp247, nil)
//line :161:1
			var init_result__25 any; var tmp248 any; var root_948 any = A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_950 lang.IFn









































































































			if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = say__21; if linked_949 == nil { tmp248 = ifn_950.Invoke_O__O(arg_951) } else { tmp248 = linked_949.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_948, arg_951) }; if jrt.J2g_Truth(tmp248) {
				var tmp249 any; var root_952 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = norm__24; var arg_956 any = say__21; if linked_953 == nil { tmp249 = ifn_954.Invoke_O_O__O(arg_955, arg_956) } else { tmp249 = linked_953.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_952, arg_955, arg_956) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp249, have__23) { var tmp250 any = A_arbace_go_check_A_const_139; var tmp251 any = jrt.Boolean_TRUE.Ref(); var tmp252 any = A_arbace_go_check_A_const_140; init_result__25 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp250, tmp251, tmp252, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__21)).Ref())) } else {

					var root_2347 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_231.Invoke_O__O(src__0)) { arg_2350 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_231.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp253 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp254 any; var root_2354 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2354, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2356 lang.IFn; if linked_2355 == nil { ifn_2356 = lang.IFn_Cast(root_2354) } else { ifn_2356 = nil }; var arg_2357 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__0); if linked_2355 == nil { tmp254 = ifn_2356.Invoke_O__O(arg_2357) } else { tmp254 = linked_2355.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2354, arg_2357) }; arg_2350 = tmp253.Invoke_O__O(tmp254) }; var arg_2351 any; var or__1927000174__auto____25 any = A_arbace_go_check_A_const_232.Invoke_O__O(src__0)
					if jrt.J2g_Truth(or__1927000174__auto____25) { arg_2351 = or__1927000174__auto____25 } else { arg_2351 = A_arbace_go_check_A_const_22 }
//line :270:1
					var arg_2352 any = A_arbace_go_check_A_const_233; var arg_2353 any = lang.IFn_Cast(A_arbace_go_check_A_const_234.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_66, A_arbace_go_check_A_const_110.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()).Invoke_O__O(say__21), lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()).Invoke_O__O(have__23)); if linked_2348 == nil { ifn_2349.Invoke_O_O_O_O__O(arg_2350, arg_2351, arg_2352, arg_2353) } else { linked_2348.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_2347, arg_2350, arg_2351, arg_2352, arg_2353) }
//line :268:1
					init_result__25 = A_arbace_go_check_A_const_141 } } else {
//line :267:1
						init_result__25 = nil }
//line :161:1
			var generic_ids__26 any; var root_957 any = A_arbace_go_check_A_const_142.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_959 lang.IFn


















































































































			if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any; var root_961 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any; var tmp255 any = A_arbace_go_check_check_package_fn__1685000239_A_New(); var tmp256 *jrt.Class; var fncls__974 *jrt.Class = A_arbace_go_check_check_package_fn__1685000239_A_fn_class; if fncls__974 == nil { var fncls__974d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_fn__1685000239_A_fn_class = fncls__974d; tmp256 = fncls__974d } else { tmp256 = fncls__974 }; arg_964 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp255, tmp256, nil); var arg_965 any = decls__17; if linked_962 == nil { arg_960 = ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { arg_960 = linked_962.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_961, arg_964, arg_965) }; if linked_958 == nil { generic_ids__26 = ifn_959.Invoke_O__O(arg_960) } else { generic_ids__26 = linked_958.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_957, arg_960) }
//line :161:1
			var errs__27 any; var root_975 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_977 lang.IFn

























































































			if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = errors__9; if linked_976 == nil { errs__27 = ifn_977.Invoke_O__O(arg_978) } else { errs__27 = linked_976.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_975, arg_978) }
//line :161:1
			var counted__28 any; var root_979 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_981 lang.IFn




















































































































			if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var tmp257 any = A_arbace_go_check_check_package_fn__1685000241_A_New_O(generic_ids__26); var tmp258 *jrt.Class; var fncls__989 *jrt.Class = A_arbace_go_check_check_package_fn__1685000241_A_fn_class; if fncls__989 == nil { var fncls__989d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000241_A_fn_class = fncls__989d; tmp258 = fncls__989d } else { tmp258 = fncls__989 }; arg_982 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp257, tmp258, nil); var arg_983 any = errs__27; if linked_980 == nil { counted__28 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { counted__28 = linked_980.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }
//line :161:1
			var forms__29 any; var m__29 any = jrt.IdentityHashMap_New(); var order__30 any = jrt.ArrayList_New(); var seq_1685000243__31 any; var root_2373 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2375 lang.IFn
























































































































			if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = decls__17; if linked_2374 == nil { seq_1685000243__31 = ifn_2375.Invoke_O__O(arg_2376) } else { seq_1685000243__31 = linked_2374.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2373, arg_2376) }
//line :161:1
			var chunk_1685000244__32 any; var count_1685000245__33 int64 = 0; var i_1685000246__34 int64 = 0; L21: for {
























































































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000246__34, count_1685000245__33) { var d__35 any = lang.Indexed_Cast(chunk_1685000244__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000246__34)); var f__36 any; var tmp259 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp260 any; var root_2393 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2395 lang.IFn
					if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = d__35; if linked_2394 == nil { tmp260 = ifn_2395.Invoke_O__O(arg_2396) } else { tmp260 = linked_2394.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2393, arg_2396) }; f__36 = tmp259.Invoke_O__O(tmp260)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__29)).ContainsKey_O__Z(f__36) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__30)).Add_O__Z(f__36)); jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Put_O_O__O(f__36, lang.PersistentVector_EMPTY.Ref()) }
					var tmp261 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__29); var tmp262 any; var root_2397 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Get_O__O(f__36); var arg_2401 any = d__35; if linked_2398 == nil { tmp262 = ifn_2399.Invoke_O_O__O(arg_2400, arg_2401) } else { tmp262 = linked_2398.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2397, arg_2400, arg_2401) }; jrt.NN(tmp261).Put_O_O__O(f__36, tmp262)
//line :282:1
					seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000246__34); continue L21 } else { var temp__1927000414__auto____35 any; var root_2377 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2377, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2379 lang.IFn; if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any = seq_1685000243__31; if linked_2378 == nil { temp__1927000414__auto____35 = ifn_2379.Invoke_O__O(arg_2380) } else { temp__1927000414__auto____35 = linked_2378.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2377, arg_2380) }; if jrt.J2g_Truth(temp__1927000414__auto____35) { var seq_1685000243__36 any = temp__1927000414__auto____35; var tmp263 any; var root_2381 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = seq_1685000243__36; if linked_2382 == nil { tmp263 = ifn_2383.Invoke_O__O(arg_2384) } else { tmp263 = linked_2382.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2381, arg_2384) }; if jrt.J2g_Truth(tmp263) { var c__1927000678__auto____37 any; var root_2385 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any = seq_1685000243__36; if linked_2386 == nil { c__1927000678__auto____37 = ifn_2387.Invoke_O__O(arg_2388) } else { c__1927000678__auto____37 = linked_2386.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2385, arg_2388) }; var tmp264 any; var root_2402 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any = seq_1685000243__36; if linked_2403 == nil { tmp264 = ifn_2404.Invoke_O__O(arg_2405) } else { tmp264 = linked_2403.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2402, arg_2405) }; seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = tmp264, c__1927000678__auto____37, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L21 } else { var d__37 any; var root_2389 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = seq_1685000243__36; if linked_2390 == nil { d__37 = ifn_2391.Invoke_O__O(arg_2392) } else { d__37 = linked_2390.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2389, arg_2392) }; var f__38 any; var tmp265 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp266 any; var root_2406 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2408 lang.IFn
						if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any = d__37; if linked_2407 == nil { tmp266 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp266 = linked_2407.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2406, arg_2409) }; f__38 = tmp265.Invoke_O__O(tmp266)
						if jrt.NN(jrt.IdentityHashMap_Cast(m__29)).ContainsKey_O__Z(f__38) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__30)).Add_O__Z(f__38)); jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Put_O_O__O(f__38, lang.PersistentVector_EMPTY.Ref()) }
						var tmp267 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__29); var tmp268 any; var root_2410 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2410, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2412 lang.IFn; if linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var arg_2413 any = jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Get_O__O(f__38); var arg_2414 any = d__37; if linked_2411 == nil { tmp268 = ifn_2412.Invoke_O_O__O(arg_2413, arg_2414) } else { tmp268 = linked_2411.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2410, arg_2413, arg_2414) }; jrt.NN(tmp267).Put_O_O__O(f__38, tmp268)
//line :282:1
						var tmp269 any; var root_2415 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = seq_1685000243__36; if linked_2416 == nil { tmp269 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp269 = linked_2416.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2415, arg_2418) }; seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = tmp269, nil, 0, 0; continue L21 } } }
//line :161:1
				break L21
			}



























































































































			var root_990 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any; var tmp270 any = A_arbace_go_check_check_package_fn__1685000247_A_New_O(m__29); var tmp271 *jrt.Class; var fncls__995 *jrt.Class = A_arbace_go_check_check_package_fn__1685000247_A_fn_class; if fncls__995 == nil { var fncls__995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000247_A_fn_class = fncls__995d; tmp271 = fncls__995d } else { tmp271 = fncls__995 }; arg_993 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp270, tmp271, nil); var arg_994 any = order__30; if linked_991 == nil { forms__29 = ifn_992.Invoke_O_O__O(arg_993, arg_994) } else { forms__29 = linked_991.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_990, arg_993, arg_994) }
//line :161:1
			var stats__30 any; var root_996 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_998 lang.IFn





























































































































			if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var tmp272 any = A_arbace_go_check_check_package_fn__1685000250_A_New_O(resolving__10); var tmp273 *jrt.Class; var fncls__1276 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_A_fn_class
			if fncls__1276 == nil { var fncls__1276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_fn__1685000250_A_fn_class = fncls__1276d; tmp273 = fncls__1276d } else { tmp273 = fncls__1276 }; arg_999 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp272, tmp273, nil)
//line :287:1
			var arg_1000 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_163, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_154, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_164, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_139, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_156, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_166, lang.PersistentVector_EMPTY.Ref())); var arg_1001 any = forms__29; if linked_997 == nil { stats__30 = ifn_998.Invoke_O_O_O__O(arg_999, arg_1000, arg_1001) } else { stats__30 = linked_997.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_996, arg_999, arg_1000, arg_1001)
			}




























			var tmp274 any
			var and__1927000168__auto____31 any = resolving__10

			if jrt.J2g_Truth(and__1927000168__auto____31) { var root_2419 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = keep_trees__6; if linked_2420 == nil { tmp274 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp274 = linked_2420.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2419, arg_2422) } } else { tmp274 = and__1927000168__auto____31 }
//line :317:1
			if jrt.J2g_Truth(tmp274) { var seq_1685000291__31 any; var root_2423 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2425 lang.IFn



				if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = decls__17; if linked_2424 == nil { seq_1685000291__31 = ifn_2425.Invoke_O__O(arg_2426) } else { seq_1685000291__31 = linked_2424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2423, arg_2426) }
//line :317:1
				var chunk_1685000292__32 any; var count_1685000293__33 int64 = 0; var i_1685000294__34 int64 = 0; L22: for {



					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000294__34, count_1685000293__33) { var d__35_2 any = lang.Indexed_Cast(chunk_1685000292__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000294__34)); var root_2622 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = d__35_2; var arg_2626 any; var root_2627 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2627, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2629 lang.IFn; if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any; var root_2632 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = d__35_2; if linked_2633 == nil { arg_2630 = ifn_2634.Invoke_O__O(arg_2635) } else { arg_2630 = linked_2633.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2632, arg_2635) }; var arg_2631 any = A_arbace_go_check_A_const_251; if linked_2628 == nil { arg_2626 = ifn_2629.Invoke_O_O__O(arg_2630, arg_2631) } else { arg_2626 = linked_2628.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2627, arg_2630, arg_2631) }; if linked_2623 == nil { ifn_2624.Invoke_O_O__O(arg_2625, arg_2626) } else { linked_2623.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2622, arg_2625, arg_2626) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000294__34); continue L22 } else { var temp__1927000414__auto____35_2 any; var root_2427 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2429 lang.IFn; if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = seq_1685000291__31; if linked_2428 == nil { temp__1927000414__auto____35_2 = ifn_2429.Invoke_O__O(arg_2430) } else { temp__1927000414__auto____35_2 = linked_2428.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2427, arg_2430) }; if jrt.J2g_Truth(temp__1927000414__auto____35_2) { var seq_1685000291__36 any = temp__1927000414__auto____35_2; var tmp275 any; var root_2431 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2433 lang.IFn; if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = seq_1685000291__36; if linked_2432 == nil { tmp275 = ifn_2433.Invoke_O__O(arg_2434) } else { tmp275 = linked_2432.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2431, arg_2434) }; if jrt.J2g_Truth(tmp275) { var c__1927000678__auto____37_2 any; var root_2435 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = seq_1685000291__36; if linked_2436 == nil { c__1927000678__auto____37_2 = ifn_2437.Invoke_O__O(arg_2438) } else { c__1927000678__auto____37_2 = linked_2436.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2435, arg_2438) }; var tmp276 any; var root_2636 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = seq_1685000291__36; if linked_2637 == nil { tmp276 = ifn_2638.Invoke_O__O(arg_2639) } else { tmp276 = linked_2637.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2636, arg_2639) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp276, c__1927000678__auto____37_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L22 } else { var d__37_2 any; var root_2439 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = seq_1685000291__36; if linked_2440 == nil { d__37_2 = ifn_2441.Invoke_O__O(arg_2442) } else { d__37_2 = linked_2440.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2439, arg_2442) }; var root_2640 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = d__37_2; var arg_2644 any; var root_2645 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2647 lang.IFn; if linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any; var root_2650 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2650, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2652 lang.IFn; if linked_2651 == nil { ifn_2652 = lang.IFn_Cast(root_2650) } else { ifn_2652 = nil }; var arg_2653 any = d__37_2; if linked_2651 == nil { arg_2648 = ifn_2652.Invoke_O__O(arg_2653) } else { arg_2648 = linked_2651.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2650, arg_2653) }; var arg_2649 any = A_arbace_go_check_A_const_252; if linked_2646 == nil { arg_2644 = ifn_2647.Invoke_O_O__O(arg_2648, arg_2649) } else { arg_2644 = linked_2646.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2645, arg_2648, arg_2649) }; if linked_2641 == nil { ifn_2642.Invoke_O_O__O(arg_2643, arg_2644) } else { linked_2641.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2640, arg_2643, arg_2644) }; var tmp277 any; var root_2654 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var arg_2657 any = seq_1685000291__36; if linked_2655 == nil { tmp277 = ifn_2656.Invoke_O__O(arg_2657) } else { tmp277 = linked_2655.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2654, arg_2657) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp277, nil, 0, 0; continue L22 } } }
//line :317:1
					break L22 } } else { var tmp278 any; var root_2443 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2445 lang.IFn




						if linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any = keep_trees__6; if linked_2444 == nil { tmp278 = ifn_2445.Invoke_O__O(arg_2446) } else { tmp278 = linked_2444.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2443, arg_2446) }
//line :317:1
						if jrt.J2g_Truth(tmp278) { var seq_1685000295__31 any; var root_2447 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2449 lang.IFn





							if linked_2448 == nil { ifn_2449 = lang.IFn_Cast(root_2447) } else { ifn_2449 = nil }; var arg_2450 any = decls__17; if linked_2448 == nil { seq_1685000295__31 = ifn_2449.Invoke_O__O(arg_2450) } else { seq_1685000295__31 = linked_2448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2447, arg_2450) }
//line :317:1
							var chunk_1685000296__32 any; var count_1685000297__33 int64 = 0; var i_1685000298__34 int64 = 0; L23: for {





								if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000298__34, count_1685000297__33) { var d__35_3 any = lang.Indexed_Cast(chunk_1685000296__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000298__34)); var tmp279 any; var and__1927000168__auto____36 bool; var tmp280 any = A_arbace_go_check_A_const_253; var tmp281 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp282 any; var root_2658 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2660 lang.IFn
									if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = d__35_3; if linked_2659 == nil { tmp282 = ifn_2660.Invoke_O__O(arg_2661) } else { tmp282 = linked_2659.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2658, arg_2661) }; and__1927000168__auto____36 = lang.Util_Equiv_O_O__Z_NoInit(tmp280, tmp281.Invoke_O__O(tmp282)); if and__1927000168__auto____36 { var or__1927000174__auto____37 any; var root_2662 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any; var root_2666 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2666, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2668 lang.IFn; if linked_2667 == nil { ifn_2668 = lang.IFn_Cast(root_2666) } else { ifn_2668 = nil }; var arg_2669 any; var tmp283 *lang.Keyword = A_arbace_go_check_A_const_222; var tmp284 any; var root_2671 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2671, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2673 lang.IFn; if linked_2672 == nil { ifn_2673 = lang.IFn_Cast(root_2671) } else { ifn_2673 = nil }; var arg_2674 any = d__35_3; if linked_2672 == nil { tmp284 = ifn_2673.Invoke_O__O(arg_2674) } else { tmp284 = linked_2672.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2671, arg_2674) }; arg_2669 = tmp283.Invoke_O__O(tmp284); var arg_2670 any = A_arbace_go_check_A_const_254; if linked_2667 == nil { arg_2665 = ifn_2668.Invoke_O_O__O(arg_2669, arg_2670) } else { arg_2665 = linked_2667.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2666, arg_2669, arg_2670) }; if linked_2663 == nil { or__1927000174__auto____37 = ifn_2664.Invoke_O__O(arg_2665) } else { or__1927000174__auto____37 = linked_2663.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2662, arg_2665) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp279 = or__1927000174__auto____37 } else { var root_2675 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any; var root_2679 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any; var tmp285 *lang.Keyword = A_arbace_go_check_A_const_222; var tmp286 any; var root_2684 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = d__35_3; if linked_2685 == nil { tmp286 = ifn_2686.Invoke_O__O(arg_2687) } else { tmp286 = linked_2685.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2684, arg_2687) }; arg_2682 = tmp285.Invoke_O__O(tmp286); var arg_2683 any = A_arbace_go_check_A_const_255; if linked_2680 == nil { arg_2678 = ifn_2681.Invoke_O_O__O(arg_2682, arg_2683) } else { arg_2678 = linked_2680.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2679, arg_2682, arg_2683) }; if linked_2676 == nil { tmp279 = ifn_2677.Invoke_O__O(arg_2678) } else { tmp279 = linked_2676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2675, arg_2678) } } } else { tmp279 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____36).Ref() }; if jrt.J2g_Truth(tmp279) {
										jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_256.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_257, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259)) } else {
											jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_256.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_214, A_arbace_go_check_A_const_257, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259)) }
//line :323:1
									seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000298__34); continue L23 } else { var temp__1927000414__auto____35_3 any; var root_2451 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = seq_1685000295__31; if linked_2452 == nil { temp__1927000414__auto____35_3 = ifn_2453.Invoke_O__O(arg_2454) } else { temp__1927000414__auto____35_3 = linked_2452.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2451, arg_2454) }; if jrt.J2g_Truth(temp__1927000414__auto____35_3) { var seq_1685000295__36 any = temp__1927000414__auto____35_3; var tmp287 any; var root_2455 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2455, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2457 lang.IFn; if linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = seq_1685000295__36; if linked_2456 == nil { tmp287 = ifn_2457.Invoke_O__O(arg_2458) } else { tmp287 = linked_2456.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2455, arg_2458) }; if jrt.J2g_Truth(tmp287) { var c__1927000678__auto____37_3 any; var root_2459 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = seq_1685000295__36; if linked_2460 == nil { c__1927000678__auto____37_3 = ifn_2461.Invoke_O__O(arg_2462) } else { c__1927000678__auto____37_3 = linked_2460.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2459, arg_2462) }; var tmp288 any; var root_2703 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = seq_1685000295__36; if linked_2704 == nil { tmp288 = ifn_2705.Invoke_O__O(arg_2706) } else { tmp288 = linked_2704.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2703, arg_2706) }; seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = tmp288, c__1927000678__auto____37_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L23 } else { var d__37_3 any; var root_2463 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = seq_1685000295__36; if linked_2464 == nil { d__37_3 = ifn_2465.Invoke_O__O(arg_2466) } else { d__37_3 = linked_2464.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2463, arg_2466) }
										var tmp289 any; var and__1927000168__auto____38 bool; var tmp290 any = A_arbace_go_check_A_const_253; var tmp291 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp292 any; var root_2707 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = d__37_3; if linked_2708 == nil { tmp292 = ifn_2709.Invoke_O__O(arg_2710) } else { tmp292 = linked_2708.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2707, arg_2710) }; and__1927000168__auto____38 = lang.Util_Equiv_O_O__Z_NoInit(tmp290, tmp291.Invoke_O__O(tmp292)); if and__1927000168__auto____38 { var or__1927000174__auto____39 any; var root_2711 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any; var root_2715 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; var arg_2718 any; var tmp293 *lang.Keyword = A_arbace_go_check_A_const_222; var tmp294 any; var root_2720 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2720, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2722 lang.IFn; if linked_2721 == nil { ifn_2722 = lang.IFn_Cast(root_2720) } else { ifn_2722 = nil }; var arg_2723 any = d__37_3; if linked_2721 == nil { tmp294 = ifn_2722.Invoke_O__O(arg_2723) } else { tmp294 = linked_2721.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2720, arg_2723) }; arg_2718 = tmp293.Invoke_O__O(tmp294); var arg_2719 any = A_arbace_go_check_A_const_254; if linked_2716 == nil { arg_2714 = ifn_2717.Invoke_O_O__O(arg_2718, arg_2719) } else { arg_2714 = linked_2716.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2715, arg_2718, arg_2719) }; if linked_2712 == nil { or__1927000174__auto____39 = ifn_2713.Invoke_O__O(arg_2714) } else { or__1927000174__auto____39 = linked_2712.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2711, arg_2714) }; if jrt.J2g_Truth(or__1927000174__auto____39) { tmp289 = or__1927000174__auto____39 } else { var root_2724 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any; var root_2728 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any; var tmp295 *lang.Keyword = A_arbace_go_check_A_const_222; var tmp296 any; var root_2733 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2733, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2735 lang.IFn; if linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var arg_2736 any = d__37_3; if linked_2734 == nil { tmp296 = ifn_2735.Invoke_O__O(arg_2736) } else { tmp296 = linked_2734.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2733, arg_2736) }; arg_2731 = tmp295.Invoke_O__O(tmp296); var arg_2732 any = A_arbace_go_check_A_const_255; if linked_2729 == nil { arg_2727 = ifn_2730.Invoke_O_O__O(arg_2731, arg_2732) } else { arg_2727 = linked_2729.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2728, arg_2731, arg_2732) }; if linked_2725 == nil { tmp289 = ifn_2726.Invoke_O__O(arg_2727) } else { tmp289 = linked_2725.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2724, arg_2727) } } } else { tmp289 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____38).Ref() }; if jrt.J2g_Truth(tmp289) {
											jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_256.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_257, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259)) } else {
												jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_256.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_214, A_arbace_go_check_A_const_257, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259)) }
//line :323:1
										var tmp297 any; var root_2752 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = seq_1685000295__36; if linked_2753 == nil { tmp297 = ifn_2754.Invoke_O__O(arg_2755) } else { tmp297 = linked_2753.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2752, arg_2755) }; seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = tmp297, nil, 0, 0; continue L23 } } }
//line :317:1
								break L23
							}
						}
					}






			var tmp298 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp299 any; var root_2467 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2471 any = A_arbace_go_check_A_const_236; var arg_2472 any; var tmp300 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp301 any = A_arbace_go_check_A_const_110; var tmp302 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp303 any = A_arbace_go_check_A_const_237; var tmp304 any; var root_2473 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2475 lang.IFn


			if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any; var root_2477 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any; var root_2482 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2484 lang.IFn; if linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any = A_arbace_go_check_A_const_73; var arg_2486 any = A_arbace_go_check_A_const_78; if linked_2483 == nil { arg_2480 = ifn_2484.Invoke_O_O__O(arg_2485, arg_2486) } else { arg_2480 = linked_2483.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2482, arg_2485, arg_2486) }; var arg_2481 any = counted__28; if linked_2478 == nil { arg_2476 = ifn_2479.Invoke_O_O__O(arg_2480, arg_2481) } else { arg_2476 = linked_2478.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2477, arg_2480, arg_2481) }; if linked_2474 == nil { tmp304 = ifn_2475.Invoke_O__O(arg_2476) } else { tmp304 = linked_2474.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2473, arg_2476) }
//line :328:1
			var tmp305 any = tmp304; var tmp306 any = A_arbace_go_check_A_const_240; var tmp307 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__27)), int64(lang.RT_Count_O__I_NoInit(counted__28)))).Ref(); var tmp308 any = A_arbace_go_check_A_const_241; var tmp309 any = A_arbace_go_check_A_const_242; var tmp310 any




			if jrt.J2g_Truth(keep_trees__6) { var root_2487 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_2488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2487, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2489 lang.IFn; if linked_2488 == nil { ifn_2489 = lang.IFn_Cast(root_2487) } else { ifn_2489 = nil }; var arg_2490 any; var root_2491 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_2492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2491, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2493 lang.IFn; if linked_2492 == nil { ifn_2493 = lang.IFn_Cast(root_2491) } else { ifn_2493 = nil }; var arg_2494 any; var tmp311 any = A_arbace_go_check_check_package_fn__1685000299_A_New(); var tmp312 *jrt.Class; var fncls__2500 *jrt.Class = A_arbace_go_check_check_package_fn__1685000299_A_fn_class; if fncls__2500 == nil { var fncls__2500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000299_A_fn_class = fncls__2500d; tmp312 = fncls__2500d } else { tmp312 = fncls__2500 }; arg_2494 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp311, tmp312, nil); var arg_2495 any = decls__17; if linked_2492 == nil { arg_2490 = ifn_2493.Invoke_O_O__O(arg_2494, arg_2495) } else { arg_2490 = linked_2492.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2491, arg_2494, arg_2495) }; if linked_2488 == nil { tmp310 = ifn_2489.Invoke_O__O(arg_2490) } else { tmp310 = linked_2488.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2487, arg_2490) } } else { tmp310 = nil }
//line :328:1
			var tmp313 any = tmp310; var tmp314 any = A_arbace_go_check_A_const_243; var tmp315 any







			if jrt.J2g_Truth(keep_trees__6) {
				var root_2501 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2503 lang.IFn; if linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any; var iter__1927001039__auto____31 any; var tmp316 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_A_New(); var tmp317 *jrt.Class; var fncls__2581 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class; if fncls__2581 == nil { var fncls__2581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class = fncls__2581d; tmp317 = fncls__2581d } else { tmp317 = fncls__2581 }; iter__1927001039__auto____31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp316, tmp317, nil); arg_2504 = lang.IFn_Cast(iter__1927001039__auto____31).Invoke_O__O(decls__17); if linked_2502 == nil { tmp315 = ifn_2503.Invoke_O__O(arg_2504) } else { tmp315 = linked_2502.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2501, arg_2504) } } else {
//line :336:1
					tmp315 = nil }
//line :328:1
			var tmp318 any = tmp315; var tmp319 any = A_arbace_go_check_A_const_247; var tmp320 any











			if jrt.J2g_Truth(keep_trees__6) { tmp320 = order__18 } else { tmp320 = nil }
//line :328:1
			var tmp321 any = tmp320; var tmp322 any = A_arbace_go_check_A_const_248; var tmp323 any













			if jrt.J2g_Truth(resolving__10) {
				var root_2582 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2582, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2584 lang.IFn; if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any; var tmp324 any = A_arbace_go_check_check_package_fn__1685000311_A_New(); var tmp325 *jrt.Class; var fncls__2617 *jrt.Class = A_arbace_go_check_check_package_fn__1685000311_A_fn_class; if fncls__2617 == nil { var fncls__2617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000311_A_fn_class = fncls__2617d; tmp325 = fncls__2617d } else { tmp325 = fncls__2617 }; arg_2585 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp324, tmp325, nil); var arg_2586 any = order__18; if linked_2583 == nil { tmp323 = ifn_2584.Invoke_O_O__O(arg_2585, arg_2586) } else { tmp323 = linked_2583.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2582, arg_2585, arg_2586) } } else {
//line :342:1
					tmp323 = nil }
//line :328:1
			var tmp326 any = tmp323; var tmp327 any = A_arbace_go_check_A_const_71; var tmp328 any
















			if jrt.J2g_Truth(keep_trees__6) { tmp328 = pkg_scope__7 } else { tmp328 = nil }
//line :328:1
			var tmp329 any = tmp328; var tmp330 any = A_arbace_go_check_A_const_119; var tmp331 any

















			if jrt.J2g_Truth(keep_trees__6) { var root_2618 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2620 lang.IFn; if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = A_arbace_go_check_A_const_119.Invoke_O__O(ctx__12); if linked_2619 == nil { tmp331 = ifn_2620.Invoke_O__O(arg_2621) } else { tmp331 = linked_2619.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2618, arg_2621) } } else { tmp331 = nil }
//line :328:1
			arg_2472 = tmp300.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, stats__30, tmp301, tmp302, tmp303, tmp305, tmp306, tmp307, tmp308, init_result__25, tmp309, tmp313, tmp314, tmp318, tmp319, tmp321, tmp322, tmp326, tmp327, tmp329, tmp330, tmp331))))
//line :327:1
			if linked_2468 == nil { tmp299 = ifn_2469.Invoke_O_O_O__O(arg_2470, arg_2471, arg_2472) } else { tmp299 = linked_2468.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2467, arg_2470, arg_2471, arg_2472) }; jrt.NN(tmp298).Reset_O__O(tmp299)
//line :161:1
			tmp69 = pkg__8 }; return nil }(); var root_1277 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1279 lang.IFn; if















	linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; if linked_1278 == nil { ifn_1279.Invoke__O() } else { linked_1278.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1277) }; if /*line :161:1*/ tmp332 != nil { panic(tmp332) }; return tmp69 }














func A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000129_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Invoke_O_O__O(self, p1__1685000111_SHARP___1 any) any { var root_816 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_go_check_file_info_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = t.F_pkg_scope; var arg_820 any = p1__1685000111_SHARP___1; var arg_821 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src); if linked_817 == nil { return ifn_818.Invoke_O_O_O__O(arg_819, arg_820, arg_821) } else { return linked_817.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_816, arg_819, arg_820, arg_821) } }













func A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000131_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1284 any = A_arbace_go_check_A_const_188.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = A_arbace_go_check_A_const_110.Invoke_O__O(t.F_src); if linked_1285 == nil { tmp1 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp1 = linked_1285.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1284, arg_1287) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :190:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }
































func A_arbace_go_check_check_package_fn__1685000179_A_New() *A_arbace_go_check_check_package_fn__1685000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000179_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Invoke_O_O__O(self, p1__1685000112_SHARP___1 any) any { var root_836 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = p1__1685000112_SHARP___1; var arg_840 any = A_arbace_go_check_A_const_127; if linked_837 == nil { return ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { return linked_837.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) } }





func A_arbace_go_check_check_package_fn__1685000186_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000186_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000187__5 any; var root_1925 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1927 lang.IFn
											if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1928 = t_; if linked_1926 == nil { seq_1685000187__5 = ifn_1927.Invoke_O__O(arg_1928) } else { seq_1685000187__5 = linked_1926.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1925, arg_1928) }
//line :229:1
	var chunk_1685000188__6 any; var count_1685000189__7 int64 = 0; var i_1685000190__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000190__8, count_1685000189__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000188__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000190__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000190__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1929 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = seq_1685000187__5; if linked_1930 == nil { temp__1927000414__auto____9 = ifn_1931.Invoke_O__O(arg_1932) } else { temp__1927000414__auto____9 = linked_1930.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1929, arg_1932) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000187__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1933 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = seq_1685000187__10; if linked_1934 == nil { tmp2 = ifn_1935.Invoke_O__O(arg_1936) } else { tmp2 = linked_1934.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1933, arg_1936) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1937 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = seq_1685000187__10; if linked_1938 == nil { c__1927000678__auto____11 = ifn_1939.Invoke_O__O(arg_1940) } else { c__1927000678__auto____11 = linked_1938.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1937, arg_1940) }; var tmp3 any; var root_1948 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = seq_1685000187__10; if linked_1949 == nil { tmp3 = ifn_1950.Invoke_O__O(arg_1951) } else { tmp3 = linked_1949.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1948, arg_1951) }; seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1941 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = seq_1685000187__10; if linked_1942 == nil { l__11 = ifn_1943.Invoke_O__O(arg_1944) } else { l__11 = linked_1942.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1941, arg_1944) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1952 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = seq_1685000187__10; if linked_1953 == nil { tmp4 = ifn_1954.Invoke_O__O(arg_1955) } else { tmp4 = linked_1953.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1952, arg_1955) }; seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1956 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1958 lang.IFn

			if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = ex__5; if linked_1957 == nil { tmp6 = ifn_1958.Invoke_O__O(arg_1959) } else { tmp6 = linked_1957.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1956, arg_1959) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1960 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1963 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1964 any = A_arbace_go_check_A_const_144; var arg_1965 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp11 any; var root_1966 any = A_arbace_go_check_A_const_218.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = ex__5; if linked_1967 == nil { tmp11 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp11 = linked_1967.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1966, arg_1969) }; arg_1965 = tmp10.Invoke_O__O(tmp11); if linked_1961 == nil { tmp8 = ifn_1962.Invoke_O_O_O__O(arg_1963, arg_1964, arg_1965) } else { tmp8 = linked_1961.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1960, arg_1963, arg_1964, arg_1965) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_1945 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; if linked_1946 == nil { ifn_1947.Invoke__O() } else { linked_1946.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1945) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :229:1
func A_arbace_go_check_check_package_fn__1685000193_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000193_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000194__5 any; var root_2015 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2017 lang.IFn
											if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any; var t_ any = t.F_ls; t.F_ls = nil; arg_2018 = t_; if linked_2016 == nil { seq_1685000194__5 = ifn_2017.Invoke_O__O(arg_2018) } else { seq_1685000194__5 = linked_2016.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2015, arg_2018) }
//line :229:1
	var chunk_1685000195__6 any; var count_1685000196__7 int64 = 0; var i_1685000197__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000197__8, count_1685000196__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000195__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000197__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000197__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_2019 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = seq_1685000194__5; if linked_2020 == nil { temp__1927000414__auto____9 = ifn_2021.Invoke_O__O(arg_2022) } else { temp__1927000414__auto____9 = linked_2020.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2019, arg_2022) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000194__10 any = temp__1927000414__auto____9; var tmp2 any; var root_2023 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2023, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2025 lang.IFn; if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any = seq_1685000194__10; if linked_2024 == nil { tmp2 = ifn_2025.Invoke_O__O(arg_2026) } else { tmp2 = linked_2024.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2023, arg_2026) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_2027 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = seq_1685000194__10; if linked_2028 == nil { c__1927000678__auto____11 = ifn_2029.Invoke_O__O(arg_2030) } else { c__1927000678__auto____11 = linked_2028.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2027, arg_2030) }; var tmp3 any; var root_2038 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = seq_1685000194__10; if linked_2039 == nil { tmp3 = ifn_2040.Invoke_O__O(arg_2041) } else { tmp3 = linked_2039.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2038, arg_2041) }; seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_2031 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = seq_1685000194__10; if linked_2032 == nil { l__11 = ifn_2033.Invoke_O__O(arg_2034) } else { l__11 = linked_2032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2031, arg_2034) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_2042 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = seq_1685000194__10; if linked_2043 == nil { tmp4 = ifn_2044.Invoke_O__O(arg_2045) } else { tmp4 = linked_2043.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2042, arg_2045) }; seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_2046 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2048 lang.IFn

			if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = ex__5; if linked_2047 == nil { tmp6 = ifn_2048.Invoke_O__O(arg_2049) } else { tmp6 = linked_2047.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_2046, arg_2049) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2050 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2053 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2054 any = A_arbace_go_check_A_const_144; var arg_2055 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp11 any; var root_2056 any = A_arbace_go_check_A_const_218.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2058 lang.IFn; if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = ex__5; if linked_2057 == nil { tmp11 = ifn_2058.Invoke_O__O(arg_2059) } else { tmp11 = linked_2057.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2056, arg_2059) }; arg_2055 = tmp10.Invoke_O__O(tmp11); if linked_2051 == nil { tmp8 = ifn_2052.Invoke_O_O_O__O(arg_2053, arg_2054, arg_2055) } else { tmp8 = linked_2051.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2050, arg_2053, arg_2054, arg_2055) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_2035 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; if linked_2036 == nil { ifn_2037.Invoke__O() } else { linked_2036.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2035) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000203_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000203_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000203_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000203_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000203_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2091 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp3 any; var root_2095 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any; var t_ any = t.F_d; t.F_d = nil; arg_2098 = t_; if linked_2096 == nil { tmp3 = ifn_2097.Invoke_O__O(arg_2098) } else { tmp3 = linked_2096.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2095, arg_2098) }; arg_2094 = tmp2.Invoke_O__O(tmp3); if linked_2092 == nil { tmp1 = ifn_2093.Invoke_O__O(arg_2094) } else { tmp1 = linked_2092.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2091, arg_2094) } }
//line :235:1
	return nil }(); var root_2099 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; if linked_2100 == nil { ifn_2101.Invoke__O() } else { linked_2100.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2099) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :235:1
func A_arbace_go_check_check_package_fn__1685000205_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000205_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000205_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000205_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000205_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2122 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp3 any; var root_2126 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any; var t_ any = t.F_d; t.F_d = nil; arg_2129 = t_; if linked_2127 == nil { tmp3 = ifn_2128.Invoke_O__O(arg_2129) } else { tmp3 = linked_2127.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2126, arg_2129) }; arg_2125 = tmp2.Invoke_O__O(tmp3); if linked_2123 == nil { tmp1 = ifn_2124.Invoke_O__O(arg_2125) } else { tmp1 = linked_2123.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2122, arg_2125) } }
//line :235:1
	return nil }(); var root_2130 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; if linked_2131 == nil { ifn_2132.Invoke__O() } else { linked_2131.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2130) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_go_check_check_package_init_entry__1685000231_A_New() *A_arbace_go_check_check_package_init_entry__1685000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000231_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_New(); var tmp2 *jrt.Class; var fncls__897 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class; if
													fncls__897 == nil { var fncls__897d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class = fncls__897d; tmp2 = fncls__897d } else { tmp2 = fncls__897 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_909 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = lhs__1; if linked_910 == nil { tmp4 = ifn_911.Invoke_O__O(arg_912) } else { tmp4 = linked_910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_909, arg_912) }; return tmp3.Invoke_O__O(tmp4) } else { var root_898 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var arg_902 any = A_arbace_go_check_A_const_136; var arg_903 any; var root_904 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = one__2; var arg_908 any = lhs__1; if linked_905 == nil { arg_903 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { arg_903 = linked_905.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; if linked_899 == nil { return ifn_900.Invoke_O_O_O__O(arg_901, arg_902, arg_903) } else { return linked_899.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_898, arg_901, arg_902, arg_903) } } }
//line :258:1
func A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_New() *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_873 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = v__1; var arg_877 any = A_arbace_go_check_A_const_70; if linked_874 == nil { tmp1 = ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { tmp1 = linked_874.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, tmp1) { var tmp2 any; var root_887 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = v__1; var arg_891 any = A_arbace_go_check_A_const_73; if linked_888 == nil { tmp2 = ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { tmp2 = linked_888.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_887, arg_890, arg_891) }; var tmp3 any = tmp2; var tmp4 any; var root_892 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = v__1; var arg_896 any = A_arbace_go_check_A_const_78; if linked_893 == nil { tmp4 = ifn_894.Invoke_O_O__O(arg_895, arg_896) } else { tmp4 = linked_893.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_892, arg_895, arg_896) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_878 any = A_arbace_go_check_A_const_133.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any; var root_882 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = v__1; var arg_886 any = A_arbace_go_check_A_const_70; if linked_883 == nil { arg_881 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { arg_881 = linked_883.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }; if linked_879 == nil { return ifn_880.Invoke_O__O(arg_881) } else { return linked_879.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_878, arg_881) } } }



func A_arbace_go_check_check_package_norm__1685000235_A_New() *A_arbace_go_check_check_package_norm__1685000235_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000235_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1685000235_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1685000235_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_919 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_921 lang.IFn; if
												linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = x__1; if linked_920 == nil { tmp1 = ifn_921.Invoke_O__O(arg_922) } else { tmp1 = linked_920.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_919, arg_922) }; if /*line :262:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_923 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_925 lang.IFn

		if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = x__1; if linked_924 == nil { tmp2 = ifn_925.Invoke_O__O(arg_926) } else { tmp2 = linked_924.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_923, arg_926) }
//line :262:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_91, tmp2) {


			var root_927 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var arg_931 any = A_arbace_go_check_A_const_137; var arg_932 any; var root_933 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_New(); var tmp4 *jrt.Class; var fncls__942 *jrt.Class = A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class; if fncls__942 == nil { var fncls__942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class = fncls__942d; tmp4 = fncls__942d } else { tmp4 = fncls__942 }; arg_936 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_937 any; var root_943 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = x__1; if linked_944 == nil { arg_937 = ifn_945.Invoke_O__O(arg_946) } else { arg_937 = linked_944.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_943, arg_946) }; if linked_934 == nil { arg_932 = ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { arg_932 = linked_934.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) }; if linked_928 == nil { return ifn_929.Invoke_O_O_O__O(arg_930, arg_931, arg_932) } else { return linked_928.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_927, arg_930, arg_931, arg_932) } } else {
//line :262:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_New() *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A) Ctor() {}
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A) Invoke_O_O__O(self, p1__1685000113_SHARP___1 any) any { var tmp1 any; var root_938 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = p1__1685000113_SHARP___1; if linked_939 == nil { tmp1 = ifn_940.Invoke_O__O(arg_941) } else { tmp1 = linked_939.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_938, arg_941) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000113_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000239_A_New() *A_arbace_go_check_check_package_fn__1685000239_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000239_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_go_check_check_package_fn__1685000239_A) Ctor() {}
//line :276:1
func (t *A_arbace_go_check_check_package_fn__1685000239_A) Invoke_O_O__O(self, p1__1685000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp2 any; var root_966 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = p1__1685000114_SHARP___1; if linked_967 == nil { tmp2 = ifn_968.Invoke_O__O(arg_969) } else { tmp2 = linked_967.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_966, arg_969) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp4 any; var root_970 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = p1__1685000114_SHARP___1; if linked_971 == nil { tmp4 = ifn_972.Invoke_O__O(arg_973) } else { tmp4 = linked_971.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_970, arg_973) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000241_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000241_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000241_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_go_check_check_package_fn__1685000241_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :278:1
func (t *A_arbace_go_check_check_package_fn__1685000241_A) Invoke_O_O__O(self, p1__1685000115_SHARP___1 any) any { var root_984 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = t.F_generic_ids; var arg_988 any = A_arbace_go_check_A_const_127.Invoke_O__O(p1__1685000115_SHARP___1); if linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } }







func A_arbace_go_check_check_package_fn__1685000247_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000247_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000247_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000247_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000247_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000250_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000250_A) Ctor_O(c__resolving any) { t.F_resolving = c__resolving }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000250_A) Invoke_O_O_O__O(self, acc__1, p__1685000249__2 any) any { var vec__1685000251__3 any = p__1685000249__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000251__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000251__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_1002 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1004 lang.IFn; if
															linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_New(); var tmp2 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class = fncls__1011d; tmp2 = fncls__1011d } else { tmp2 = fncls__1011 }; arg_1005 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1006 any = ds__5; if linked_1003 == nil { gen__6 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { gen__6 = linked_1003.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }; var uses_generics__7 any; var root_1012 any = /*line :288:1*/A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1014 lang.IFn; if

	linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_New(); var tmp4 *jrt.Class; var fncls__1021 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class; if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class = fncls__1021d; tmp4 = fncls__1021d } else { tmp4 = fncls__1021 }; arg_1015 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1016 any = ds__5; if linked_1013 == nil { uses_generics__7 = ifn_1014.Invoke_O_O__O(arg_1015, arg_1016) } else { uses_generics__7 = linked_1013.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1012, arg_1015, arg_1016) }; var present__8 any; if
	jrt.J2g_Truth(t.F_resolving) { present__8 = lang.PersistentArrayMap_EMPTY.Ref() } else { var root_1022 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_check_annotations_present_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = form__4; if linked_1023 == nil { present__8 = ifn_1024.Invoke_O__O(arg_1025) } else { present__8 = linked_1023.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_1022, arg_1025) } }; var verified__9 any; var root_1026 any = /*line :288:1*/A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1028 lang.IFn; if



	linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var arg_1030 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1031 any; var root_1032 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_New(); var tmp6 *jrt.Class; var fncls__1041 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class; if fncls__1041 == nil { var fncls__1041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class = fncls__1041d; tmp6 = fncls__1041d } else { tmp6 = fncls__1041 }; arg_1035 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1036 any = ds__5; if linked_1033 == nil { arg_1031 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { arg_1031 = linked_1033.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }; if linked_1027 == nil { verified__9 = ifn_1028.Invoke_O_O_O__O(arg_1029, arg_1030, arg_1031) } else { verified__9 = linked_1027.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1026, arg_1029, arg_1030, arg_1031) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_1042 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var root_1049 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = acc__1; var arg_1053 any = A_arbace_go_check_A_const_152; var arg_1054 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); if linked_1050 == nil { arg_1045 = ifn_1051.Invoke_O_O_O__O(arg_1052, arg_1053, arg_1054) } else { arg_1045 = linked_1050.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1049, arg_1052, arg_1053, arg_1054) }; var arg_1046 any = A_arbace_go_check_A_const_154; var arg_1047 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1048 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1043 == nil { acc__10 = ifn_1044.Invoke_O_O_O_O__O(arg_1045, arg_1046, arg_1047, arg_1048) } else { acc__10 = linked_1043.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1042, arg_1045, arg_1046, arg_1047, arg_1048) } } else {
//line :293:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_1055 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any; var root_1061 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1063 lang.IFn
//line :299:1
		if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1067 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1069 lang.IFn
//line :298:1
		if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = acc__10; var arg_1071 any = A_arbace_go_check_A_const_155; var arg_1072 any; var root_1073 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); var arg_1077 any = A_arbace_go_check_A_const_22; if linked_1074 == nil { arg_1072 = ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { arg_1072 = linked_1074.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) }; if linked_1068 == nil { arg_1064 = ifn_1069.Invoke_O_O_O__O(arg_1070, arg_1071, arg_1072) } else { arg_1064 = linked_1068.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1067, arg_1070, arg_1071, arg_1072) }
		var arg_1065 any = A_arbace_go_check_A_const_156; var arg_1066 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_New_O(present__8); var tmp8 *jrt.Class; var fncls__1084 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class; if fncls__1084 == nil { var fncls__1084d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class = fncls__1084d; tmp8 = fncls__1084d } else { tmp8 = fncls__1084 }; arg_1066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_1062 == nil { arg_1058 = ifn_1063.Invoke_O_O_O__O(arg_1064, arg_1065, arg_1066) } else { arg_1058 = linked_1062.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1061, arg_1064, arg_1065, arg_1066) }
		var arg_1059 any = A_arbace_go_check_A_const_144; var arg_1060 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_New_O(ds__5); var tmp10 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class = fncls__1107d; tmp10 = fncls__1107d } else { tmp10 = fncls__1107 }; arg_1060 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1056 == nil { return ifn_1057.Invoke_O_O_O__O(arg_1058, arg_1059, arg_1060) } else { return linked_1056.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1055, arg_1058, arg_1059, arg_1060) } } else {
//line :296:1
			var unver__11 any; var root_1108 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1110 lang.IFn




			if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1112 any; var iter__1927001039__auto____11 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_New_O(verified__9); var tmp12 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class = fncls__1195d; tmp12 = fncls__1195d } else { tmp12 = fncls__1195 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1112 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1109 == nil { unver__11 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { unver__11 = linked_1109.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112)
			}








			var root_1196 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any; var root_1202 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1204 lang.IFn
//line :310:1
			if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any; var root_1208 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1210 lang.IFn
//line :309:1
			if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1214 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1216 lang.IFn
//line :308:1
			if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any; var root_1220 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1222 lang.IFn
//line :307:1
			if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var root_1227 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1229 lang.IFn
//line :306:1
			if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = acc__10; var arg_1231 any = A_arbace_go_check_A_const_163; var arg_1232 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); if linked_1228 == nil { arg_1223 = ifn_1229.Invoke_O_O_O__O(arg_1230, arg_1231, arg_1232) } else { arg_1223 = linked_1228.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1227, arg_1230, arg_1231, arg_1232) }
			var arg_1224 any = A_arbace_go_check_A_const_82; var arg_1225 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1226 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1221 == nil { arg_1217 = ifn_1222.Invoke_O_O_O_O__O(arg_1223, arg_1224, arg_1225, arg_1226) } else { arg_1217 = linked_1221.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1220, arg_1223, arg_1224, arg_1225, arg_1226) }
			var arg_1218 any = A_arbace_go_check_A_const_164; var arg_1219 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_New_O(present__8); var tmp14 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class; if fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class = fncls__1239d; tmp14 = fncls__1239d } else { tmp14 = fncls__1239 }; arg_1219 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1215 == nil { arg_1211 = ifn_1216.Invoke_O_O_O__O(arg_1217, arg_1218, arg_1219) } else { arg_1211 = linked_1215.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1214, arg_1217, arg_1218, arg_1219) }
			var arg_1212 any = A_arbace_go_check_A_const_139; var arg_1213 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_New_O(verified__9); var tmp16 *jrt.Class; var fncls__1246 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class; if fncls__1246 == nil { var fncls__1246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class = fncls__1246d; tmp16 = fncls__1246d } else { tmp16 = fncls__1246 }; arg_1213 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1209 == nil { arg_1205 = ifn_1210.Invoke_O_O_O__O(arg_1211, arg_1212, arg_1213) } else { arg_1205 = linked_1209.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1208, arg_1211, arg_1212, arg_1213) }
			var arg_1206 any = A_arbace_go_check_A_const_165; var arg_1207 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_New_O(unver__11); var tmp18 *jrt.Class; var fncls__1253 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class; if fncls__1253 == nil { var fncls__1253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class = fncls__1253d; tmp18 = fncls__1253d } else { tmp18 = fncls__1253 }; arg_1207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1203 == nil { arg_1199 = ifn_1204.Invoke_O_O_O__O(arg_1205, arg_1206, arg_1207) } else { arg_1199 = linked_1203.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1202, arg_1205, arg_1206, arg_1207) }
			var arg_1200 any = A_arbace_go_check_A_const_166; var arg_1201 any; var tmp19 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_New_O_O_O(form__4, ds__5, unver__11); var tmp20 *jrt.Class; var fncls__1275 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class; if fncls__1275 == nil { var fncls__1275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class = fncls__1275d; tmp20 = fncls__1275d } else { tmp20 = fncls__1275 }; arg_1201 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); if linked_1197 == nil { return ifn_1198.Invoke_O_O_O__O(arg_1199, arg_1200, arg_1201) } else { return linked_1197.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1196, arg_1199, arg_1200, arg_1201) } } }
//line :289:1
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A) Ctor() {}
//line :289:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A) Invoke_O_O__O(self, p1__1685000116_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp2 any; var root_1007 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = p1__1685000116_SHARP___1; if linked_1008 == nil { tmp2 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp2 = linked_1008.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1007, arg_1010) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A) Ctor() {}
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A) Invoke_O_O__O(self, p1__1685000117_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_149; var tmp2 any; var root_1017 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = p1__1685000117_SHARP___1; if linked_1018 == nil { tmp2 = ifn_1019.Invoke_O__O(arg_1020) } else { tmp2 = linked_1018.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1017, arg_1020) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A) Ctor() {}
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A) Invoke_O_O__O(self, p1__1685000118_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_139; var tmp2 any; var root_1037 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = p1__1685000118_SHARP___1; if linked_1038 == nil { tmp2 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp2 = linked_1038.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1037, arg_1040) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :299:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A) Invoke_O_O__O(self, p1__1685000119_SHARP___1 any) any { var root_1078 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1082 any = p1__1685000119_SHARP___1; var arg_1083 any = t.F_present; if linked_1079 == nil { return ifn_1080.Invoke_O_O_O__O(arg_1081, arg_1082, arg_1083) } else { return linked_1079.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1078, arg_1081, arg_1082, arg_1083) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A) Invoke_O_O__O(self, p1__1685000120_SHARP___1 any) any { var root_1085 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_New(); var tmp2 *jrt.Class; var fncls__1106 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class; if fncls__1106 == nil { var fncls__1106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class = fncls__1106d; tmp2 = fncls__1106d } else { tmp2 = fncls__1106 }; arg_1088 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1089 any = p1__1685000120_SHARP___1; var arg_1090 any = t.F_ds; if linked_1086 == nil { return ifn_1087.Invoke_O_O_O__O(arg_1088, arg_1089, arg_1090) } else { return linked_1086.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1085, arg_1088, arg_1089, arg_1090) } }
//line :300:1
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp2 any; var root_1091 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = d__2; if linked_1092 == nil { tmp2 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp2 = linked_1092.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1091, arg_1094) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_1095 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = m__1; var arg_1099 any = u__4; var arg_1100 any; var root_1101 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); var arg_1105 any = A_arbace_go_check_A_const_22; if linked_1102 == nil { arg_1100 = ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { arg_1100 = linked_1102.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }; if linked_1096 == nil { return ifn_1097.Invoke_O_O_O__O(arg_1098, arg_1099, arg_1100) } else { return linked_1096.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1095, arg_1098, arg_1099, arg_1100) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A) Invoke_O_O__O(self, s__1685000267__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_New_O_O_O(s__1685000267__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1194 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class; if fncls__1194 == nil { var fncls__1194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class = fncls__1194d; tmp2 = fncls__1194d } else { tmp2 = fncls__1194 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :301:1
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A) Ctor_O_O_O(c__s__1685000267, c__iter__1685000266, c__verified any) { t.F_s__1685000267 = c__s__1685000267; t.F_iter__1685000266 = c__iter__1685000266; t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A) Invoke_O__O(self any) any { { var s__1685000267__1 any; var t_ any = t.F_s__1685000267; t.F_s__1685000267 = nil; s__1685000267__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1113 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = s__1685000267__1; if linked_1114 == nil { temp__1927000414__auto____2 = ifn_1115.Invoke_O__O(arg_1116) } else { temp__1927000414__auto____2 = linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000267__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1117 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = s__1685000267__3; if linked_1118 == nil { tmp1 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp1 = linked_1118.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1117, arg_1120) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1121 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__1685000267__3; if linked_1122 == nil { c__1927001037__auto____4 = ifn_1123.Invoke_O__O(arg_1124) } else { c__1927001037__auto____4 = linked_1122.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1121, arg_1124) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000269__6 any; var root_1125 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1126 == nil { b__1685000269__6 = ifn_1127.Invoke_O__O(arg_1128) } else { b__1685000269__6 = linked_1126.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_New_O_I_O_O(b__1685000269__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class; if fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class = fncls__1144d; tmp3 = fncls__1144d } else { tmp3 = fncls__1144 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1145 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any; var root_1150 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = b__1685000269__6; if linked_1151 == nil { arg_1148 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1148 = linked_1151.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1150, arg_1153) }; var arg_1149 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000266); var tmp5 any; var root_1154 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = s__1685000267__3; if linked_1155 == nil { tmp5 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp5 = linked_1155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1154, arg_1157) }; arg_1149 = tmp4.Invoke_O__O(tmp5); if linked_1146 == nil { return ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { return linked_1146.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) } } else { var root_1158 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var root_1163 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = b__1685000269__6; if linked_1164 == nil { arg_1161 = ifn_1165.Invoke_O__O(arg_1166) } else { arg_1161 = linked_1164.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1163, arg_1166) }; var arg_1162 any; if linked_1159 == nil { return ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { return linked_1159.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } } } else { var vec__1685000277__4 any; var root_1167 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = s__1685000267__3; if linked_1168 == nil { vec__1685000277__4 = ifn_1169.Invoke_O__O(arg_1170) } else { vec__1685000277__4 = linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000277__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000277__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1171 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1173 lang.IFn

	if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = n__6; var arg_1175 any = v__7; if linked_1172 == nil { tmp6 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { tmp6 = linked_1172.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }
//line :301:1
	if jrt.J2g_Truth(tmp6) { var root_1176 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var tmp7 jrt.Number_I; var na_1181 any = n__6; var na_1182 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1181); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1182) }; tmp8 = tmp9; if tmp8 { var n0_1183 int64 = jrt.NN(jrt.Long_Cast(na_1181)).LongValue__J(); var n1_1184 int64 = jrt.NN(jrt.Long_Cast(na_1182)).LongValue__J(); var nr_1185 int64 = n0_1183 - n1_1184; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1184 == -9223372036854775808); if tmp11 { tmp11 = (n0_1183^n1_1184)&(n0_1183^nr_1185) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1185)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1181, na_1182) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1181); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1182) }; tmp12 = tmp13; if tmp12 { var n0_1183_2 float64 = jrt.NN(jrt.Double_Cast(na_1181)).DoubleValue__D(); var n1_1184_2 float64 = jrt.NN(jrt.Double_Cast(na_1182)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1183_2 + -n1_1184_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1181, na_1182) } }
//line :301:1
		arg_1179 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1180 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000266); var tmp15 any; var root_1186 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = s__1685000267__3; if linked_1187 == nil { tmp15 = ifn_1188.Invoke_O__O(arg_1189) } else { tmp15 = linked_1187.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1186, arg_1189) }; arg_1180 = tmp14.Invoke_O__O(tmp15); if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } } else { var tmp16 any; var root_1190 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = s__1685000267__3; if linked_1191 == nil { tmp16 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp16 = linked_1191.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1190, arg_1193) }; s__1685000267__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :301:1
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A) Ctor_O_I_O_O(c__b__1685000269 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1685000269 = c__b__1685000269; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A) Invoke_O__O(self any) any { { var i__1685000268__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000268__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000273__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000268__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1129 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1131 lang.IFn

	if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = n__4; var arg_1133 any = v__5; if linked_1130 == nil { tmp2 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp2 = linked_1130.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }
//line :301:1
	if jrt.J2g_Truth(tmp2) { var root_1134 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = t.F_b__1685000269; var arg_1138 any; var tmp3 jrt.Number_I; var na_1139 any = n__4; var na_1140 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1139); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1140) }; tmp4 = tmp5; if tmp4 { var n0_1141 int64 = jrt.NN(jrt.Long_Cast(na_1139)).LongValue__J(); var n1_1142 int64 = jrt.NN(jrt.Long_Cast(na_1140)).LongValue__J(); var nr_1143 int64 = n0_1141 - n1_1142; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1142 == -9223372036854775808); if tmp7 { tmp7 = (n0_1141^n1_1142)&(n0_1141^nr_1143) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1143)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1139, na_1140) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1139); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1140) }; tmp8 = tmp9; if tmp8 { var n0_1141_2 float64 = jrt.NN(jrt.Double_Cast(na_1139)).DoubleValue__D(); var n1_1142_2 float64 = jrt.NN(jrt.Double_Cast(na_1140)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1141_2 + -n1_1142_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1139, na_1140) } }
//line :301:1
		arg_1138 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1135 == nil { ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { linked_1135.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; i__1685000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000268__1); continue L1 } else { i__1685000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000268__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :308:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A) Invoke_O_O__O(self, p1__1685000121_SHARP___1 any) any { var root_1233 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1237 any = p1__1685000121_SHARP___1; var arg_1238 any = t.F_present; if linked_1234 == nil { return ifn_1235.Invoke_O_O_O__O(arg_1236, arg_1237, arg_1238) } else { return linked_1234.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1233, arg_1236, arg_1237, arg_1238) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :309:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A) Invoke_O_O__O(self, p1__1685000122_SHARP___1 any) any { var root_1240 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1244 any = p1__1685000122_SHARP___1; var arg_1245 any = t.F_verified; if linked_1241 == nil { return ifn_1242.Invoke_O_O_O__O(arg_1243, arg_1244, arg_1245) } else { return linked_1241.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1240, arg_1243, arg_1244, arg_1245) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A) Invoke_O_O__O(self, p1__1685000123_SHARP___1 any) any { var root_1247 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1251 any = p1__1685000123_SHARP___1; var arg_1252 any = t.F_unver; if linked_1248 == nil { return ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { return linked_1248.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :311:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :311:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A) Invoke_O_O__O(self, p1__1685000124_SHARP___1 any) any { var tmp1 any; var root_1254 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = t.F_unver; if linked_1255 == nil { tmp1 = ifn_1256.Invoke_O__O(arg_1257) } else { tmp1 = linked_1255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1254, arg_1257) }; if jrt.J2g_Truth(tmp1) { var root_1258 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = p1__1685000124_SHARP___1; var arg_1262 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp4 any; var root_1263 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any; var root_1267 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = t.F_ds; if linked_1268 == nil { arg_1266 = ifn_1269.Invoke_O__O(arg_1270) } else { arg_1266 = linked_1268.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1267, arg_1270) }; if linked_1264 == nil { tmp4 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp4 = linked_1264.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1263, arg_1266) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1271 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = t.F_form; if linked_1272 == nil { tmp6 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp6 = linked_1272.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1271, arg_1274) }; arg_1262 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1259 == nil { return ifn_1260.Invoke_O_O__O(arg_1261, arg_1262) } else { return linked_1259.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1258, arg_1261, arg_1262) } } else { return p1__1685000124_SHARP___1 } }





















func A_arbace_go_check_check_package_fn__1685000299_A_New() *A_arbace_go_check_check_package_fn__1685000299_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000299_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_go_check_check_package_fn__1685000299_A) Ctor() {}
//line :333:1
func (t *A_arbace_go_check_check_package_fn__1685000299_A) Invoke_O_O__O(self, p1__1685000125_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_214; var tmp2 any; var root_2496 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2498 lang.IFn; if linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any = p1__1685000125_SHARP___1; if linked_2497 == nil { tmp2 = ifn_2498.Invoke_O__O(arg_2499) } else { tmp2 = linked_2497.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2496, arg_2499) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000301__1685000305_A_New() *A_arbace_go_check_check_package_iter__1685000301__1685000305_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_A) Ctor() {}
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_A) Invoke_O_O__O(self, s__1685000302__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_New_O_O(s__1685000302__1, self); var tmp2 *jrt.Class; var fncls__2580 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class; if fncls__2580 == nil { var fncls__2580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class = fncls__2580d; tmp2 = fncls__2580d } else { tmp2 = fncls__2580 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A) Ctor_O_O(c__s__1685000302, c__iter__1685000301 any) { t.F_s__1685000302 = c__s__1685000302; t.F_iter__1685000301 = c__iter__1685000301 }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A) Invoke_O__O(self any) any { { var s__1685000302__1 any; var t_ any = t.F_s__1685000302; t.F_s__1685000302 = nil; s__1685000302__1 = t_; for { var temp__1927000414__auto____2 any; var root_2505 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2505, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2507 lang.IFn; if linked_2506 == nil { ifn_2507 = lang.IFn_Cast(root_2505) } else { ifn_2507 = nil }; var arg_2508 any = s__1685000302__1; if linked_2506 == nil { temp__1927000414__auto____2 = ifn_2507.Invoke_O__O(arg_2508) } else { temp__1927000414__auto____2 = linked_2506.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2505, arg_2508) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000302__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2509 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2509, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2511 lang.IFn; if linked_2510 == nil { ifn_2511 = lang.IFn_Cast(root_2509) } else { ifn_2511 = nil }; var arg_2512 any = s__1685000302__3; if linked_2510 == nil { tmp1 = ifn_2511.Invoke_O__O(arg_2512) } else { tmp1 = linked_2510.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2509, arg_2512) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2513 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2513, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2515 lang.IFn; if linked_2514 == nil { ifn_2515 = lang.IFn_Cast(root_2513) } else { ifn_2515 = nil }; var arg_2516 any = s__1685000302__3; if linked_2514 == nil { c__1927001037__auto____4 = ifn_2515.Invoke_O__O(arg_2516) } else { c__1927001037__auto____4 = linked_2514.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2513, arg_2516) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000304__6 any; var root_2517 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2518 == nil { b__1685000304__6 = ifn_2519.Invoke_O__O(arg_2520) } else { b__1685000304__6 = linked_2518.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2517, arg_2520) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_New_O_I_O(b__1685000304__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2535 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class; if fncls__2535 == nil { var fncls__2535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class = fncls__2535d; tmp3 = fncls__2535d } else { tmp3 = fncls__2535 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2536 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any; var root_2541 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any = b__1685000304__6; if linked_2542 == nil { arg_2539 = ifn_2543.Invoke_O__O(arg_2544) } else { arg_2539 = linked_2542.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2541, arg_2544) }; var arg_2540 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000301); var tmp5 any; var root_2545 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = s__1685000302__3; if linked_2546 == nil { tmp5 = ifn_2547.Invoke_O__O(arg_2548) } else { tmp5 = linked_2546.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2545, arg_2548) }; arg_2540 = tmp4.Invoke_O__O(tmp5); if linked_2537 == nil { return ifn_2538.Invoke_O_O__O(arg_2539, arg_2540) } else { return linked_2537.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2536, arg_2539, arg_2540) } } else { var root_2549 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2551 lang.IFn; if linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any; var root_2554 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2554, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2556 lang.IFn; if linked_2555 == nil { ifn_2556 = lang.IFn_Cast(root_2554) } else { ifn_2556 = nil }; var arg_2557 any = b__1685000304__6; if linked_2555 == nil { arg_2552 = ifn_2556.Invoke_O__O(arg_2557) } else { arg_2552 = linked_2555.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2554, arg_2557) }; var arg_2553 any; if linked_2550 == nil { return ifn_2551.Invoke_O_O__O(arg_2552, arg_2553) } else { return linked_2550.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2549, arg_2552, arg_2553) } } } else { var d__4 any; var root_2558 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2560 lang.IFn; if linked_2559 == nil { ifn_2560 = lang.IFn_Cast(root_2558) } else { ifn_2560 = nil }; var arg_2561 any = s__1685000302__3; if linked_2559 == nil { d__4 = ifn_2560.Invoke_O__O(arg_2561) } else { d__4 = linked_2559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2558, arg_2561) }; var root_2562 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2562, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2564 lang.IFn; if linked_2563 == nil { ifn_2564 = lang.IFn_Cast(root_2562) } else { ifn_2564 = nil }; var arg_2565 any; var root_2567 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2569 lang.IFn
															if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any; var root_2572 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = d__4; if linked_2573 == nil { arg_2570 = ifn_2574.Invoke_O__O(arg_2575) } else { arg_2570 = linked_2573.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2572, arg_2575) }; var arg_2571 any = A_arbace_go_check_A_const_246; if linked_2568 == nil { arg_2565 = ifn_2569.Invoke_O_O__O(arg_2570, arg_2571) } else { arg_2565 = linked_2568.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2567, arg_2570, arg_2571) }
//line :337:1
	var arg_2566 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000301); var tmp7 any; var root_2576 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = s__1685000302__3; if linked_2577 == nil { tmp7 = ifn_2578.Invoke_O__O(arg_2579) } else { tmp7 = linked_2577.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2576, arg_2579) }; arg_2566 = tmp6.Invoke_O__O(tmp7); if linked_2563 == nil { return ifn_2564.Invoke_O_O__O(arg_2565, arg_2566) } else { return linked_2563.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2562, arg_2565, arg_2566) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A) Ctor_O_I_O(c__b__1685000304 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000304 = c__b__1685000304; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A) Invoke_O__O(self any) any { { var i__1685000303__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000303__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000303__1)); var root_2521 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = t.F_b__1685000304; var arg_2525 any; var root_2526 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2528 lang.IFn
																	if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any; var root_2531 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = d__2; if linked_2532 == nil { arg_2529 = ifn_2533.Invoke_O__O(arg_2534) } else { arg_2529 = linked_2532.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2531, arg_2534) }; var arg_2530 any = A_arbace_go_check_A_const_245; if linked_2527 == nil { arg_2525 = ifn_2528.Invoke_O_O__O(arg_2529, arg_2530) } else { arg_2525 = linked_2527.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2526, arg_2529, arg_2530) }
//line :337:1
	if linked_2522 == nil { ifn_2523.Invoke_O_O__O(arg_2524, arg_2525) } else { linked_2522.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2521, arg_2524, arg_2525) }; i__1685000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000303__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_check_package_fn__1685000311_A_New() *A_arbace_go_check_check_package_fn__1685000311_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000311_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_A) Invoke_O_O__O(self, lhs__1 any) any { var root_2587 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2589 lang.IFn; if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_New(); var tmp2 *jrt.Class; var fncls__2616 *jrt.Class = A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class; if fncls__2616 == nil { var fncls__2616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class = fncls__2616d; tmp2 = fncls__2616d } else { tmp2 = fncls__2616 }; arg_2590 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2591 any = lhs__1; if linked_2588 == nil { return ifn_2589.Invoke_O_O__O(arg_2590, arg_2591) } else { return linked_2588.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2587, arg_2590, arg_2591) } }
//line :343:1
func A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_New() *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_2592 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = v__1; var arg_2596 any = A_arbace_go_check_A_const_70; if linked_2593 == nil { tmp1 = ifn_2594.Invoke_O_O__O(arg_2595, arg_2596) } else { tmp1 = linked_2593.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2592, arg_2595, arg_2596) }; var tmp2 any = tmp1; var tmp3 any; var root_2597 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2597, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any = v__1; var arg_2601 any = A_arbace_go_check_A_const_73; if linked_2598 == nil { tmp3 = ifn_2599.Invoke_O_O__O(arg_2600, arg_2601) } else { tmp3 = linked_2598.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2597, arg_2600, arg_2601) }; var tmp4 any = tmp3; var tmp5 any; var root_2602 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2602, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = v__1; var arg_2606 any = A_arbace_go_check_A_const_78; if linked_2603 == nil { tmp5 = ifn_2604.Invoke_O_O__O(arg_2605, arg_2606) } else { tmp5 = linked_2603.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2602, arg_2605, arg_2606) }; var tmp6 any = tmp5; var tmp7 any; var root_2607 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any; var root_2611 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2611, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2613 lang.IFn; if linked_2612 == nil { ifn_2613 = lang.IFn_Cast(root_2611) } else { ifn_2613 = nil }; var arg_2614 any = v__1; var arg_2615 any = A_arbace_go_check_A_const_250; if linked_2612 == nil { arg_2610 = ifn_2613.Invoke_O_O__O(arg_2614, arg_2615) } else { arg_2610 = linked_2612.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2611, arg_2614, arg_2615) }; if linked_2608 == nil { tmp7 = ifn_2609.Invoke_O__O(arg_2610) } else { tmp7 = linked_2608.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2607, arg_2610) }; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :351:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_260; var tmp2 any = A_arbace_go_check_A_const_261; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_262; var tmp5 any; var root_2756 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2758 lang.IFn; if



	linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2757 == nil { tmp5 = ifn_2758.Invoke_O__O(arg_2759) } else { tmp5 = linked_2757.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2756, arg_2759) }; return /*line :351:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2760 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2762 lang.IFn; if



	linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any = A_arbace_go_check_A_const_262.Invoke_O__O(s__0); if linked_2761 == nil { tmp1 = ifn_2762.Invoke_O__O(arg_2763) } else { tmp1 = linked_2761.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2760, arg_2763) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_261.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2764 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = p__5; if linked_2765 == nil { tmp2 = ifn_2766.Invoke_O__O(arg_2767) } else { tmp2 = linked_2765.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2764, arg_2767) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2768 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2768, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2770 lang.IFn; if linked_2769 == nil { ifn_2770 = lang.IFn_Cast(root_2768) } else { ifn_2770 = nil }; var arg_2771 any = p__5; if linked_2769 == nil { or__1927000174__auto____3 = ifn_2770.Invoke_O__O(arg_2771) } else { or__1927000174__auto____3 = linked_2769.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2768, arg_2771) } } else { or__1927000174__auto____3 = nil } } else {
//line :363:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_265.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2772 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, A_arbace_go_check_ns_package_A_fn_class); var ifn_2774 lang.IFn; if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = d__5; var arg_2776 any = ns_name__1; if linked_2773 == nil { return ifn_2774.Invoke_O_O__O(arg_2775, arg_2776) } else { return linked_2773.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2772, arg_2775, arg_2776) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000318_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2820 *jrt.Class = A_arbace_go_check_resolver_fn__1685000318_A_fn_class; _ = deps__4; if




	fncls__2820 == nil { var fncls__2820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_resolver_fn__1685000318_A_fn_class = fncls__2820d; tmp2 = fncls__2820d } else { tmp2 = fncls__2820 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :373:1
func A_arbace_go_check_resolver_fn__1685000318_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000318_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000318_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_136, path__1) { return A_arbace_go_check_A_const_267.GetRawRoot__O() } else { var lp__3 any; var root_2777 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2779 lang.IFn

		if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any = t.F_src; var arg_2781 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_81, A_arbace_go_check_A_const_268, path__1); var arg_2782 any = path__1; if linked_2778 == nil { lp__3 = ifn_2779.Invoke_O_O_O__O(arg_2780, arg_2781, arg_2782) } else { lp__3 = linked_2778.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2777, arg_2780, arg_2781, arg_2782) }
//line :376:1
		var why__4 any; var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_269.Invoke_O__O(t.F_s)



		if jrt.J2g_Truth(temp__1927000414__auto____4) { var rf__5 any = temp__1927000414__auto____4; why__4 = lang.IFn_Cast(rf__5).Invoke_O_O__O(lp__3, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_src)) } else { why__4 = nil }
//line :376:1
		var p__5 any
		var or__1927000174__auto____5 any = why__4




		if jrt.J2g_Truth(or__1927000174__auto____5) { p__5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_2783 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2785 lang.IFn
			if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any = t.F_s; var arg_2787 any = lp__3; var arg_2788 any = t.F_src; var arg_2789 any = t.F_chain; if linked_2784 == nil { or__1927000174__auto____6 = ifn_2785.Invoke_O_O_O_O__O(arg_2786, arg_2787, arg_2788, arg_2789) } else { or__1927000174__auto____6 = linked_2784.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2783, arg_2786, arg_2787, arg_2788, arg_2789) }
//line :382:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { p__5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 any; var and__1927000168__auto____7 any; var root_2790 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2792 lang.IFn

				if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any; var root_2794 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any; var root_2799 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2799, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2801 lang.IFn; if linked_2800 == nil { ifn_2801 = lang.IFn_Cast(root_2799) } else { ifn_2801 = nil }; var arg_2802 any; var root_2803 any = A_arbace_go_check_A_const_272.GetRawRoot__O(); var linked_2804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2803, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2805 lang.IFn; if linked_2804 == nil { ifn_2805 = lang.IFn_Cast(root_2803) } else { ifn_2805 = nil }; var arg_2806 any = lp__3; var arg_2807 any = A_arbace_go_check_A_const_273; if linked_2804 == nil { arg_2802 = ifn_2805.Invoke_O_O__O(arg_2806, arg_2807) } else { arg_2802 = linked_2804.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2803, arg_2806, arg_2807) }; if linked_2800 == nil { arg_2797 = ifn_2801.Invoke_O__O(arg_2802) } else { arg_2797 = linked_2800.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2799, arg_2802) }; var arg_2798 any = Lit_137; if linked_2795 == nil { arg_2793 = ifn_2796.Invoke_O_O__O(arg_2797, arg_2798) } else { arg_2793 = linked_2795.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2794, arg_2797, arg_2798) }; if linked_2791 == nil { and__1927000168__auto____7 = ifn_2792.Invoke_O__O(arg_2793) } else { and__1927000168__auto____7 = linked_2791.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2790, arg_2793) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____7 = nil } else { or__1927000174__auto____7 = nil }
//line :382:1
				if jrt.J2g_Truth(or__1927000174__auto____7) { p__5 = or__1927000174__auto____7 } else {


					var root_2808 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_2809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2808, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2810 lang.IFn; if linked_2809 == nil { ifn_2810 = lang.IFn_Cast(root_2808) } else { ifn_2810 = nil }; var arg_2811 any = t.F_s; var arg_2812 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2813 any = t.F_src; var arg_2814 any = t.F_chain; if linked_2809 == nil { p__5 = ifn_2810.Invoke_O_O_O_O__O(arg_2811, arg_2812, arg_2813, arg_2814) } else { p__5 = linked_2809.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2808, arg_2811, arg_2812, arg_2813, arg_2814) } } } }
//line :376:1
		return p__5 } }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2815 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, A_arbace_go_check_ns_package_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = t.F_s; var arg_2819 any = ns_name__1; if linked_2816 == nil { return ifn_2817.Invoke_O_O__O(arg_2818, arg_2819) } else { return linked_2816.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2815, arg_2818, arg_2819)
	}
}











func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :388:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2902 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2904 lang.IFn; if linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2906 any = chain__3; if linked_2903 == nil { tmp1 = ifn_2904.Invoke_O_O__O(arg_2905, arg_2906) } else { tmp1 = linked_2903.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2902, arg_2905, arg_2906) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2907 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2907, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2909 lang.IFn
		if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_110, nil); var tmp4 any; var root_2912 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2912, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2914 lang.IFn; if linked_2913 == nil { ifn_2914 = lang.IFn_Cast(root_2912) } else { ifn_2914 = nil }; var arg_2915 any = Lit_111; var arg_2916 any; var root_2917 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2917, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2919 lang.IFn; if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any = chain__3; var arg_2921 any = path__1; if linked_2918 == nil { arg_2916 = ifn_2919.Invoke_O_O__O(arg_2920, arg_2921) } else { arg_2916 = linked_2918.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2917, arg_2920, arg_2921) }; if linked_2913 == nil { tmp4 = ifn_2914.Invoke_O_O__O(arg_2915, arg_2916) } else { tmp4 = linked_2913.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2912, arg_2915, arg_2916) }; arg_2910 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2911 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110, path__1)); if linked_2908 == nil { tmp2 = ifn_2909.Invoke_O_O__O(arg_2910, arg_2911) } else { tmp2 = linked_2908.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2907, arg_2910, arg_2911) }
//line :391:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :388:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_265.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2821 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2823 lang.IFn; if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any = lang.IFn_Cast(A_arbace_go_check_A_const_274.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2822 == nil { and__1927000168__auto____6 = ifn_2823.Invoke_O__O(arg_2824) } else { and__1927000168__auto____6 = linked_2822.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2821, arg_2824) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_265.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2825 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2827 lang.IFn

		if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = d__6; var arg_2829 any = path__1; var arg_2830 any = importer__2; var arg_2831 any = chain__3; if linked_2826 == nil { return ifn_2827.Invoke_O_O_O_O__O(arg_2828, arg_2829, arg_2830, arg_2831) } else { return linked_2826.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2825, arg_2828, arg_2829, arg_2830, arg_2831) } } else {
//line :393:1
			var cache__6 any = A_arbace_go_check_A_const_261.Invoke_O__O(s__0); var p__7 any; var root_2832 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2832, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2834 lang.IFn



			if linked_2833 == nil { ifn_2834 = lang.IFn_Cast(root_2832) } else { ifn_2834 = nil }; if linked_2833 == nil { p__7 = ifn_2834.Invoke__O() } else { p__7 = linked_2833.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2832) }
//line :393:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2835 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2837 lang.IFn; if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = prev__8; if linked_2836 == nil { return ifn_2837.Invoke_O__O(arg_2838) } else { return linked_2836.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2835, arg_2838) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_260.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2839 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2839, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__9); if linked_2840 == nil { tmp5 = ifn_2841.Invoke_O__O(arg_2842) } else { tmp5 = linked_2840.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2839, arg_2842) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000321_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2901 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class; if fncls__2901 == nil { var fncls__2901d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class = fncls__2901d; tmp7 = fncls__2901d } else { tmp7 = fncls__2901 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :402:1
						pkg__10 = nil
					}






				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2922 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2923 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2922, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2924 lang.IFn; if linked_2923 == nil { ifn_2924 = lang.IFn_Cast(root_2922) } else { ifn_2924 = nil }; var arg_2925 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2926 any = A_arbace_go_check_A_const_281; var arg_2927 any; var root_2928 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_2929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2928, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2930 lang.IFn; if linked_2929 == nil { ifn_2930 = lang.IFn_Cast(root_2928) } else { ifn_2930 = nil }; var arg_2931 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2932 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_282; var tmp11 any; var root_2933 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2933, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2935 lang.IFn; if linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = pkg__10; var arg_2937 any = A_arbace_go_check_A_const_71; if linked_2934 == nil { tmp11 = ifn_2935.Invoke_O_O__O(arg_2936, arg_2937) } else { tmp11 = linked_2934.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2933, arg_2936, arg_2937) }; arg_2932 = tmp10.Invoke_O__O(tmp11); if linked_2929 == nil { arg_2927 = ifn_2930.Invoke_O_O__O(arg_2931, arg_2932) } else { arg_2927 = linked_2929.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2928, arg_2931, arg_2932) }; if linked_2923 == nil { tmp9 = ifn_2924.Invoke_O_O_O__O(arg_2925, arg_2926, arg_2927) } else { tmp9 = linked_2923.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2922, arg_2925, arg_2926, arg_2927) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2938 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_2939 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2938, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2940 lang.IFn; if linked_2939 == nil { ifn_2940 = lang.IFn_Cast(root_2938) } else { ifn_2940 = nil }; var arg_2941 any = A_arbace_go_check_A_const_262.Invoke_O__O(s__0); var arg_2942 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var arg_2943 any; var root_2945 any = A_arbace_go_check_A_const_188.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2945, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_2947 lang.IFn; if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any = path__1; if linked_2946 == nil { arg_2943 = ifn_2947.Invoke_O__O(arg_2948) } else { arg_2943 = linked_2946.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2945, arg_2948) }; var arg_2944 any = path__1; if linked_2939 == nil { ifn_2940.Invoke_O_O_O_O__O(arg_2941, arg_2942, arg_2943, arg_2944) } else { linked_2939.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2938, arg_2941, arg_2942, arg_2943, arg_2944) }
				var root_2949 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2951 lang.IFn; if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any = p__7; var arg_2953 any = pkg__10; if linked_2950 == nil { ifn_2951.Invoke_O_O__O(arg_2952, arg_2953) } else { linked_2950.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2949, arg_2952, arg_2953) }
//line :399:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000321_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000321_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000321_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :403:1
func (t *A_arbace_go_check_ensure_package_fn__1685000321_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :403:1
func (t *A_arbace_go_check_ensure_package_fn__1685000321_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var G__1685000322__3_ any = A_arbace_go_check_A_const_108.Invoke_O__O(t.F_s); if lang.Util_Identical_O_O__Z_NoInit(G__1685000322__3_, nil) { tmp2 = nil } else { var root_2843 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any = G__1685000322__3_; var arg_2847 any = lang.Tuple_Create_O__IPersistentVector(t.F_path); if linked_2844 == nil { tmp2 = ifn_2845.Invoke_O_O__O(arg_2846, arg_2847) } else { tmp2 = linked_2844.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2843, arg_2846, arg_2847) } }; if jrt.J2g_Truth(tmp2) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_276.GetRawRoot__O()); var tmp4 any = t.F_src; var tmp5 any; var root_2855 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, A_arbace_go_check_resolver_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any; var t_ any = t.F_s; t.F_s = nil; arg_2858 = t_; var arg_2859 any; var t__2 any = t.F_src; t.F_src = nil; arg_2859 = t__2; var arg_2860 any; var root_2861 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2861, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any; var root_2866 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_2867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2866, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2868 lang.IFn; if linked_2867 == nil { ifn_2868 = lang.IFn_Cast(root_2866) } else { ifn_2868 = nil }; var arg_2869 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2869 = t__3; if linked_2867 == nil { arg_2864 = ifn_2868.Invoke_O__O(arg_2869) } else { arg_2864 = linked_2867.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2866, arg_2869) }; var arg_2865 any = t.F_path; if linked_2862 == nil { arg_2860 = ifn_2863.Invoke_O_O__O(arg_2864, arg_2865) } else { arg_2860 = linked_2862.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2861, arg_2864, arg_2865) }; if linked_2856 == nil { tmp5 = ifn_2857.Invoke_O_O_O__O(arg_2858, arg_2859, arg_2860) } else { tmp5 = linked_2856.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2855, arg_2858, arg_2859, arg_2860) }; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, A_arbace_go_check_A_const_108, jrt.Boolean_TRUE.Ref()) } else {
													var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_276.GetRawRoot__O()); var tmp7 any = t.F_src; var tmp8 any; var root_2875 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2875, A_arbace_go_check_resolver_A_fn_class); var ifn_2877 lang.IFn; if linked_2876 == nil { ifn_2877 = lang.IFn_Cast(root_2875) } else { ifn_2877 = nil }; var arg_2878 any; var t__4 any = t.F_s; t.F_s = nil; arg_2878 = t__4; var arg_2879 any; var t__5 any = t.F_src; t.F_src = nil; arg_2879 = t__5; var arg_2880 any; var root_2881 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var arg_2884 any; var root_2886 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any; var t__6 any = t.F_chain; t.F_chain = nil; arg_2889 = t__6; if linked_2887 == nil { arg_2884 = ifn_2888.Invoke_O__O(arg_2889) } else { arg_2884 = linked_2887.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2886, arg_2889) }; var arg_2885 any = t.F_path; if linked_2882 == nil { arg_2880 = ifn_2883.Invoke_O_O__O(arg_2884, arg_2885) } else { arg_2880 = linked_2882.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2881, arg_2884, arg_2885) }; if linked_2876 == nil { tmp8 = ifn_2877.Invoke_O_O_O__O(arg_2878, arg_2879, arg_2880) } else { tmp8 = linked_2876.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2875, arg_2878, arg_2879, arg_2880) }; tmp1 = tmp6.Invoke_O_O__O(tmp7, tmp8) } }
//line :403:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_2896 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2898 lang.IFn




		if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any; var t__7 any = t.F_p; t.F_p = nil; arg_2899 = t__7; var arg_2900 any; if linked_2897 == nil { ifn_2898.Invoke_O_O__O(arg_2899, arg_2900) } else { linked_2897.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2896, arg_2899, arg_2900) }
//line :403:1
		var tmp10 any; var root_2890 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2890, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2892 lang.IFn





		if linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var tmp11 any = t.F_path; var arg_2893 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2894 any; var tmp12 any = A_arbace_go_check_A_const_110; var tmp13 any; var t__8 any = t.F_path; t.F_path = nil; tmp13 = t__8; arg_2894 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); var arg_2895 any = ex__3; if linked_2891 == nil { tmp10 = ifn_2892.Invoke_O_O_O__O(arg_2893, arg_2894, arg_2895) } else { tmp10 = linked_2891.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2890, arg_2893, arg_2894, arg_2895) }
//line :403:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) } }; return tmp1 }











func A_arbace_go_check_check_src_A_New() *A_arbace_go_check_check_src_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_src_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_go_check_check_src_A) Ctor() {}
//line :415:1
func (t *A_arbace_go_check_check_src_A) Invoke_O_O_O__O(self, s__0, src__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_276.GetRawRoot__O()); var tmp2 any; var root_2959 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, A_arbace_go_check_resolver_A_fn_class); var ifn_2961 lang.IFn; if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = s__0; var arg_2963 any = src__1; var arg_2964 any = lang.PersistentVector_EMPTY.Ref(); if linked_2960 == nil { tmp2 = ifn_2961.Invoke_O_O_O__O(arg_2962, arg_2963, arg_2964) } else { tmp2 = linked_2960.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2959, arg_2962, arg_2963, arg_2964) }; return tmp1.Invoke_O_O__O(src__1, tmp2)
}










func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :430:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var temp__1927000408__auto____2 any = A_arbace_go_check_A_const_284.Get__O(); if
											jrt.J2g_Truth(temp__1927000408__auto____2) { var f__3 any = temp__1927000408__auto____2; var G__1685000326__4_ any = corpus__0
												switch lang.Util_Hash_O__I_NoInit(G__1685000326__4_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_93) { var tmp1 any = A_arbace_go_check_A_const_285; var tmp2 any = A_arbace_go_check_A_const_287; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_286; var tmp5 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_288, Lit_96)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_289)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_97) { var tmp6 any = A_arbace_go_check_A_const_285; var tmp7 any = A_arbace_go_check_A_const_287; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_290; var tmp10 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_288, Lit_96)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_291)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_54) { var tmp11 any = A_arbace_go_check_A_const_285; var tmp12 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_99), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_292)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_100) { var tmp13 any = A_arbace_go_check_A_const_285; var tmp14 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_101), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_293)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_102) { var tmp15 any = A_arbace_go_check_A_const_285; var tmp16 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_300)) }; default:}; var tmp17 any; var root_2966 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2968 lang.IFn







		if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2970 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_294, corpus__0)); if linked_2967 == nil { tmp17 = ifn_2968.Invoke_O_O__O(arg_2969, arg_2970) } else { tmp17 = linked_2967.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2966, arg_2969, arg_2970) }
//line :432:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) } else {
//line :431:1
			var G__1685000327__3_ any = corpus__0









			switch lang.Util_Hash_O__I_NoInit(G__1685000327__3_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_93) { var tmp18 any = A_arbace_go_check_A_const_285; var tmp19 any = A_arbace_go_check_A_const_287; var tmp20 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref()))); var tmp21 any = A_arbace_go_check_A_const_286; var tmp22 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp20, tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_288, Lit_96)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_296)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_97) { var tmp23 any = A_arbace_go_check_A_const_285; var tmp24 any = A_arbace_go_check_A_const_287; var tmp25 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref()))); var tmp26 any = A_arbace_go_check_A_const_290; var tmp27 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp25, tmp26, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_106), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_288, Lit_96)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_297)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_54) { var tmp28 any = A_arbace_go_check_A_const_285; var tmp29 any = A_arbace_go_check_A_const_287; var tmp30 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref(); var tmp31 any = A_arbace_go_check_A_const_301; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_298)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_100) { var tmp32 any = A_arbace_go_check_A_const_285; var tmp33 any = A_arbace_go_check_A_const_287; var tmp34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref(); var tmp35 any = A_arbace_go_check_A_const_301; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_109), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_299)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_102) { var tmp36 any = A_arbace_go_check_A_const_285; var tmp37 any = A_arbace_go_check_A_const_287; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp36, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_302)) }; default:}; var tmp38 any; var root_2972 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2972, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2974 lang.IFn












			if linked_2973 == nil { ifn_2974 = lang.IFn_Cast(root_2972) } else { ifn_2974 = nil }; var arg_2975 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2976 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_294, corpus__0)); if linked_2973 == nil { tmp38 = ifn_2974.Invoke_O_O__O(arg_2975, arg_2976) } else { tmp38 = linked_2973.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2972, arg_2975, arg_2976) }
//line :441:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp38))) } }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :456:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :456:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000330__0 any) any { var map__1685000331__2 any = p__1685000330__0; var map__1685000331__3 any; if lang.ISeq_InstanceOf(map__1685000331__2) { var tmp1 any; var root_2977 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = map__1685000331__2; if linked_2978 == nil { tmp1 = ifn_2979.Invoke_O__O(arg_2980) } else { tmp1 = linked_2978.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2977, arg_2980) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2981 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any = map__1685000331__2; if linked_2982 == nil { tmp2 = ifn_2983.Invoke_O__O(arg_2984) } else { tmp2 = linked_2982.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2981, arg_2984) }; map__1685000331__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2985 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2985, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2987 lang.IFn; if linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 any = map__1685000331__2; if linked_2986 == nil { tmp3 = ifn_2987.Invoke_O__O(arg_2988) } else { tmp3 = linked_2986.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2985, arg_2988) }; if jrt.J2g_Truth(tmp3) { var root_2989 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2989, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2991 lang.IFn; if linked_2990 == nil { ifn_2991 = lang.IFn_Cast(root_2989) } else { ifn_2991 = nil }; var arg_2992 any = map__1685000331__2; if linked_2990 == nil { map__1685000331__3 = ifn_2991.Invoke_O__O(arg_2992) } else { map__1685000331__3 = linked_2990.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2989, arg_2992) } } else { map__1685000331__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000331__3 = map__1685000331__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000331__3, A_arbace_go_check_A_const_285); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000331__3, A_arbace_go_check_A_const_111); var root_2993 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_2994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2993, A_arbace_go_check_session_A_fn_class); var ifn_2995 lang.IFn; if
											linked_2994 == nil { ifn_2995 = lang.IFn_Cast(root_2993) } else { ifn_2995 = nil }; var arg_2996 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000333_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__3009 *jrt.Class = A_arbace_go_check_std_session_fn__1685000333_A_fn_class; if fncls__3009 == nil { var fncls__3009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_go_check_std_session_fn__1685000333_A_fn_class = fncls__3009d; tmp5 = fncls__3009d } else { tmp5 = fncls__3009 }; arg_2996 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_2994 == nil { return ifn_2995.Invoke_O__O(arg_2996) } else { return linked_2994.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2993, arg_2996) } }
//line :457:1
func A_arbace_go_check_std_session_fn__1685000333_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000333_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000333_A{}; t.Ctor_O_O(p0, p1); return t }
//line :457:1
func (t *A_arbace_go_check_std_session_fn__1685000333_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :457:1
func (t *A_arbace_go_check_std_session_fn__1685000333_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_2997 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__3008 *jrt.Class = A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class; if fncls__3008 == nil { var fncls__3008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class = fncls__3008d; tmp2 = fncls__3008d } else { tmp2 = fncls__3008 }; arg_3000 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3001 any = t.F_roots; if linked_2998 == nil { return ifn_2999.Invoke_O_O__O(arg_3000, arg_3001) } else { return linked_2998.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2997, arg_3000, arg_3001) } }
//line :458:1
func A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :458:1
func (t *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :458:1
func (t *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A) Invoke_O_O__O(self, p1__1685000329_SHARP___1 any) any { var root_3002 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3002, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3004 lang.IFn; if linked_3003 == nil { ifn_3004 = lang.IFn_Cast(root_3002) } else { ifn_3004 = nil }; var arg_3005 any = p1__1685000329_SHARP___1; var arg_3006 any = t.F_path; var arg_3007 any = t.F_config; if linked_3003 == nil { return ifn_3004.Invoke_O_O_O__O(arg_3005, arg_3006, arg_3007) } else { return linked_3003.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_3002, arg_3005, arg_3006, arg_3007) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :464:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_3010 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3012 lang.IFn; if


	linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any = xs__2; if linked_3011 == nil { xs__4 = ifn_3012.Invoke_O__O(arg_3013) } else { xs__4 = linked_3011.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3010, arg_3013) }; var q__5 any = /*line :464:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_3014 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3014, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3016 lang.IFn; if





	linked_3015 == nil { ifn_3016 = lang.IFn_Cast(root_3014) } else { ifn_3016 = nil }; var arg_3017 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__3086 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class; if fncls__3086 == nil { var fncls__3086d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class = fncls__3086d; tmp2 = fncls__3086d } else { tmp2 = fncls__3086 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_3087 any = A_arbace_go_check_A_const_309.GetRawRoot__O(); var linked_3088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3087, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3089 lang.IFn; if linked_3088 == nil { ifn_3089 = lang.IFn_Cast(root_3087) } else { ifn_3089 = nil }; var arg_3090 any = n__0; if linked_3088 == nil { tmp4 = ifn_3089.Invoke_O__O(arg_3090) } else { tmp4 = linked_3088.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3087, arg_3090) }; arg_3017 = tmp3.Invoke_O__O(tmp4); if linked_3015 == nil { workers__7 = ifn_3016.Invoke_O__O(arg_3017) } else { workers__7 = linked_3015.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3014, arg_3017) }; var seq_1685000352__8 any; var root_3095 any = /*line :464:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3097 lang.IFn; if















	linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any = workers__7; if linked_3096 == nil { seq_1685000352__8 = ifn_3097.Invoke_O__O(arg_3098) } else { seq_1685000352__8 = linked_3096.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3095, arg_3098) }; var chunk_1685000353__9 any; var count_1685000354__10 int64 = 0; var i_1685000355__11 int64 = 0; L1:
//line :464:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000355__11, count_1685000354__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000353__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000355__11)); var root_3115 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3115, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3117 lang.IFn; if linked_3116 == nil { ifn_3117 = lang.IFn_Cast(root_3115) } else { ifn_3117 = nil }; var arg_3118 any = w__12; if linked_3116 == nil { ifn_3117.Invoke_O__O(arg_3118) } else { linked_3116.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3115, arg_3118) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000355__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_3099 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = seq_1685000352__8; if linked_3100 == nil { temp__1927000414__auto____12 = ifn_3101.Invoke_O__O(arg_3102) } else { temp__1927000414__auto____12 = linked_3100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3099, arg_3102) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000352__13 any = temp__1927000414__auto____12; var tmp5 any; var root_3103 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3105 lang.IFn; if linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; var arg_3106 any = seq_1685000352__13; if linked_3104 == nil { tmp5 = ifn_3105.Invoke_O__O(arg_3106) } else { tmp5 = linked_3104.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3103, arg_3106) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_3107 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3107, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3109 lang.IFn; if linked_3108 == nil { ifn_3109 = lang.IFn_Cast(root_3107) } else { ifn_3109 = nil }; var arg_3110 any = seq_1685000352__13; if linked_3108 == nil { c__1927000678__auto____14 = ifn_3109.Invoke_O__O(arg_3110) } else { c__1927000678__auto____14 = linked_3108.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3107, arg_3110) }; var tmp6 any; var root_3119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any = seq_1685000352__13; if linked_3120 == nil { tmp6 = ifn_3121.Invoke_O__O(arg_3122) } else { tmp6 = linked_3120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3119, arg_3122) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_3111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3113 lang.IFn; if linked_3112 == nil { ifn_3113 = lang.IFn_Cast(root_3111) } else { ifn_3113 = nil }; var arg_3114 any = seq_1685000352__13; if linked_3112 == nil { w__14 = ifn_3113.Invoke_O__O(arg_3114) } else { w__14 = linked_3112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3111, arg_3114) }; var root_3123 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3125 lang.IFn; if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = w__14; if linked_3124 == nil { ifn_3125.Invoke_O__O(arg_3126) } else { linked_3124.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3123, arg_3126) }; var tmp7 any; var root_3127 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3127, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3129 lang.IFn; if linked_3128 == nil { ifn_3129 = lang.IFn_Cast(root_3127) } else { ifn_3129 = nil }; var arg_3130 any = seq_1685000352__13; if linked_3128 == nil { tmp7 = ifn_3129.Invoke_O__O(arg_3130) } else { tmp7 = linked_3128.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3127, arg_3130) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :464:1
		break L1 }; var root_3091 any =
















	A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3091, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3093 lang.IFn; if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = out__6; if linked_3092 == nil { return ifn_3093.Invoke_O__O(arg_3094) } else { return linked_3092.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3091, arg_3094) } }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A) Invoke_O_O__O(self, s__1685000339__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O_O(self, t.F_f, t.F_out, t.F_q, t.F_xs, s__1685000339__1); var tmp2 *jrt.Class; var fncls__3085 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class; if fncls__3085 == nil { var fncls__3085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class = fncls__3085d; tmp2 = fncls__3085d } else { tmp2 = fncls__3085 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A) Ctor_O_O_O_O_O_O(c__iter__1685000338, c__f, c__out, c__q, c__xs, c__s__1685000339 any) { t.F_iter__1685000338 = c__iter__1685000338; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_s__1685000339 = c__s__1685000339 }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A) Invoke_O__O(self any) any { { var s__1685000339__1 any; var t_ any = t.F_s__1685000339; t.F_s__1685000339 = nil; s__1685000339__1 = t_; for { var temp__1927000414__auto____2 any; var root_3018 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3018, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3020 lang.IFn; if linked_3019 == nil { ifn_3020 = lang.IFn_Cast(root_3018) } else { ifn_3020 = nil }; var arg_3021 any = s__1685000339__1; if linked_3019 == nil { temp__1927000414__auto____2 = ifn_3020.Invoke_O__O(arg_3021) } else { temp__1927000414__auto____2 = linked_3019.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3018, arg_3021) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000339__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3022 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3022, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3024 lang.IFn; if linked_3023 == nil { ifn_3024 = lang.IFn_Cast(root_3022) } else { ifn_3024 = nil }; var arg_3025 any = s__1685000339__3; if linked_3023 == nil { tmp1 = ifn_3024.Invoke_O__O(arg_3025) } else { tmp1 = linked_3023.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3022, arg_3025) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3026 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3026, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3028 lang.IFn; if linked_3027 == nil { ifn_3028 = lang.IFn_Cast(root_3026) } else { ifn_3028 = nil }; var arg_3029 any = s__1685000339__3; if linked_3027 == nil { c__1927001037__auto____4 = ifn_3028.Invoke_O__O(arg_3029) } else { c__1927001037__auto____4 = linked_3027.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3026, arg_3029) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000341__6 any; var root_3030 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3030, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3032 lang.IFn; if linked_3031 == nil { ifn_3032 = lang.IFn_Cast(root_3030) } else { ifn_3032 = nil }; var arg_3033 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3031 == nil { b__1685000341__6 = ifn_3032.Invoke_O__O(arg_3033) } else { b__1685000341__6 = linked_3031.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3030, arg_3033) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_O_I_O_O(t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, b__1685000341__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3044 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class; if fncls__3044 == nil { var fncls__3044d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class = fncls__3044d; tmp3 = fncls__3044d } else { tmp3 = fncls__3044 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3045 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3047 lang.IFn; if linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any; var root_3050 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3052 lang.IFn; if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = b__1685000341__6; if linked_3051 == nil { arg_3048 = ifn_3052.Invoke_O__O(arg_3053) } else { arg_3048 = linked_3051.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3050, arg_3053) }; var arg_3049 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp5 any; var root_3054 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3056 lang.IFn; if linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any = s__1685000339__3; if linked_3055 == nil { tmp5 = ifn_3056.Invoke_O__O(arg_3057) } else { tmp5 = linked_3055.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3054, arg_3057) }; arg_3049 = tmp4.Invoke_O__O(tmp5); if linked_3046 == nil { return ifn_3047.Invoke_O_O__O(arg_3048, arg_3049) } else { return linked_3046.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3045, arg_3048, arg_3049) } } else { var root_3058 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3060 lang.IFn; if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any; var root_3063 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3063, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3065 lang.IFn; if linked_3064 == nil { ifn_3065 = lang.IFn_Cast(root_3063) } else { ifn_3065 = nil }; var arg_3066 any = b__1685000341__6; if linked_3064 == nil { arg_3061 = ifn_3065.Invoke_O__O(arg_3066) } else { arg_3061 = linked_3064.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3063, arg_3066) }; var arg_3062 any; if linked_3059 == nil { return ifn_3060.Invoke_O_O__O(arg_3061, arg_3062) } else { return linked_3059.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3058, arg_3061, arg_3062) } } } else { var ___4 any; var root_3067 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3069 lang.IFn; _ = ___4; if linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any = s__1685000339__3; if linked_3068 == nil { ___4 = ifn_3069.Invoke_O__O(arg_3070) } else { ___4 = linked_3068.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3067, arg_3070) }; var root_3071 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3073 lang.IFn; if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any; var root_3076 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3078 lang.IFn
															if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__3080 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class; if fncls__3080 == nil { var fncls__3080d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class = fncls__3080d; tmp7 = fncls__3080d } else { tmp7 = fncls__3080 }; arg_3079 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3077 == nil { arg_3074 = ifn_3078.Invoke_O__O(arg_3079) } else { arg_3074 = linked_3077.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3076, arg_3079) }
//line :470:1
	var arg_3075 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp9 any; var root_3081 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = s__1685000339__3; if linked_3082 == nil { tmp9 = ifn_3083.Invoke_O__O(arg_3084) } else { tmp9 = linked_3082.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3081, arg_3084) }; arg_3075 = tmp8.Invoke_O__O(tmp9); if linked_3072 == nil { return ifn_3073.Invoke_O_O__O(arg_3074, arg_3075) } else { return linked_3072.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3071, arg_3074, arg_3075) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Ctor_O_O_O_O_I_O_O(c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__b__1685000341, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000341 = c__b__1685000341; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Invoke_O__O(self any) any { { var i__1685000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000340__1)); var root_3034 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3036 lang.IFn; _ = ___2; if linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any = t.F_b__1685000341; var arg_3038 any; var root_3039 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3041 lang.IFn
																if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__3043 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class; if fncls__3043 == nil { var fncls__3043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class = fncls__3043d; tmp3 = fncls__3043d } else { tmp3 = fncls__3043 }; arg_3042 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_3040 == nil { arg_3038 = ifn_3041.Invoke_O__O(arg_3042) } else { arg_3038 = linked_3040.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3039, arg_3042) }
//line :470:1
	if linked_3035 == nil { ifn_3036.Invoke_O_O__O(arg_3037, arg_3038) } else { linked_3035.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3034, arg_3037, arg_3038) }; i__1685000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_307.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_307.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_308) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_307.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_307.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :471:1*/panic("j2g: unreachable") }
//line :471:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_307.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_307.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_308) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_307.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_307.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :471:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :483:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_3131 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3131, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3133 lang.IFn; if linked_3132 == nil { ifn_3133 = lang.IFn_Cast(root_3131) } else { ifn_3133 = nil }; var arg_3134 any = pkg__0; var arg_3135 any = A_arbace_go_check_A_const_236; if linked_3132 == nil { return ifn_3133.Invoke_O_O__O(arg_3134, arg_3135) } else { return linked_3132.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3131, arg_3134, arg_3135) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :485:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :485:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_110; var tmp2 any = A_arbace_go_check_A_const_237; var tmp3 any = A_arbace_go_check_A_const_73; var tmp4 any = A_arbace_go_check_A_const_78; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_311; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_115, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :485:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_312, A_arbace_go_check_A_const_313))), A_arbace_go_check_A_const_163, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_154, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_164, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_139, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_156, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_310, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :492:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_3136 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3138 lang.IFn; if


	linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = corpus__0; if linked_3137 == nil { cc__3 = ifn_3138.Invoke_O__O(arg_3139) } else { cc__3 = linked_3137.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3136, arg_3139) }; var s__4 any; var root_3140 any = /*line :492:1*/A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3140, A_arbace_go_check_std_session_A_fn_class); var ifn_3142 lang.IFn; if



	linked_3141 == nil { ifn_3142 = lang.IFn_Cast(root_3140) } else { ifn_3142 = nil }; var arg_3143 any = cc__3; if linked_3141 == nil { s__4 = ifn_3142.Invoke_O__O(arg_3143) } else { s__4 = linked_3141.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3140, arg_3143) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :492:1*/A_arbace_go_check_A_const_290.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_286.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_3144 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3146 lang.IFn
		if linked_3145 == nil { ifn_3146 = lang.IFn_Cast(root_3144) } else { ifn_3146 = nil }; var arg_3147 any = A_arbace_go_check_A_const_285.Invoke_O__O(cc__3); if linked_3145 == nil { root__5 = ifn_3146.Invoke_O__O(arg_3147) } else { root__5 = linked_3145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3144, arg_3147) }
		var root_3148 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3150 lang.IFn; if linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_New(); var tmp3 *jrt.Class; var fncls__3218 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class; if fncls__3218 == nil { var fncls__3218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class = fncls__3218d; tmp3 = fncls__3218d } else { tmp3 = fncls__3218 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_3219 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3219, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3221 lang.IFn; if linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = root__5; var arg_3223 any = Lit_36; if linked_3220 == nil { tmp5 = ifn_3221.Invoke_O_O__O(arg_3222, arg_3223) } else { tmp5 = linked_3220.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3219, arg_3222, arg_3223) }; arg_3151 = tmp4.Invoke_O__O(tmp5); if linked_3149 == nil { std_pkgs__5 = ifn_3150.Invoke_O__O(arg_3151) } else { std_pkgs__5 = linked_3149.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3148, arg_3151) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_3224 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3224, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3226 lang.IFn; if linked_3225 == nil { ifn_3226 = lang.IFn_Cast(root_3224) } else { ifn_3226 = nil }; var arg_3227 any = jobs__1; var arg_3228 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000370_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__3246 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class
		if fncls__3246 == nil { var fncls__3246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class = fncls__3246d; tmp7 = fncls__3246d } else { tmp7 = fncls__3246 }; arg_3228 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :504:1
		var arg_3229 any = std_pkgs__5; if linked_3225 == nil { return ifn_3226.Invoke_O_O_O__O(arg_3227, arg_3228, arg_3229) } else { return linked_3225.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3224, arg_3227, arg_3228, arg_3229) } } else {
//line :502:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_290.Invoke_O__O(cc__3)) { var map__1685000372__6 any = A_arbace_go_check_A_const_290.Invoke_O__O(cc__3); var map__1685000372__7 any








				if lang.ISeq_InstanceOf(map__1685000372__6) { var tmp8 any; var root_3247 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3247, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3249 lang.IFn; if linked_3248 == nil { ifn_3249 = lang.IFn_Cast(root_3247) } else { ifn_3249 = nil }; var arg_3250 any = map__1685000372__6; if linked_3248 == nil { tmp8 = ifn_3249.Invoke_O__O(arg_3250) } else { tmp8 = linked_3248.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3247, arg_3250) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_3251 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3253 lang.IFn; if linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any = map__1685000372__6; if linked_3252 == nil { tmp9 = ifn_3253.Invoke_O__O(arg_3254) } else { tmp9 = linked_3252.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3251, arg_3254) }; map__1685000372__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_3255 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3257 lang.IFn; if linked_3256 == nil { ifn_3257 = lang.IFn_Cast(root_3255) } else { ifn_3257 = nil }; var arg_3258 any = map__1685000372__6; if linked_3256 == nil { tmp10 = ifn_3257.Invoke_O__O(arg_3258) } else { tmp10 = linked_3256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3255, arg_3258) }; if jrt.J2g_Truth(tmp10) { var root_3259 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3261 lang.IFn; if linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; var arg_3262 any = map__1685000372__6; if linked_3260 == nil { map__1685000372__7 = ifn_3261.Invoke_O__O(arg_3262) } else { map__1685000372__7 = linked_3260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3259, arg_3262) } } else { map__1685000372__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000372__7 = map__1685000372__6 }
//line :502:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_287); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_288); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_287, dir__8)); var root_3263 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3263, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3265 lang.IFn










				if linked_3264 == nil { ifn_3265 = lang.IFn_Cast(root_3263) } else { ifn_3265 = nil }; var arg_3266 any = jobs__1; var arg_3267 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000374_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__3311 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class
				if fncls__3311 == nil { var fncls__3311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class = fncls__3311d; tmp12 = fncls__3311d } else { tmp12 = fncls__3311 }; arg_3267 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :513:1
				var arg_3268 any; var root_3312 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3312, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3314 lang.IFn








				if linked_3313 == nil { ifn_3314 = lang.IFn_Cast(root_3312) } else { ifn_3314 = nil }; var arg_3315 any = root__10; var arg_3316 any = sub__9; if linked_3313 == nil { arg_3268 = ifn_3314.Invoke_O_O__O(arg_3315, arg_3316) } else { arg_3268 = linked_3313.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3312, arg_3315, arg_3316) }
//line :513:1
				if linked_3264 == nil { return ifn_3265.Invoke_O_O_O__O(arg_3266, arg_3267, arg_3268) } else { return linked_3264.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3263, arg_3266, arg_3267, arg_3268) } } else {
//line :502:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_286.Invoke_O__O(cc__3)) { var map__1685000376__6 any = A_arbace_go_check_A_const_286.Invoke_O__O(cc__3); var map__1685000376__7 any





















						if lang.ISeq_InstanceOf(map__1685000376__6) { var tmp13 any; var root_3317 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3317, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3319 lang.IFn; if linked_3318 == nil { ifn_3319 = lang.IFn_Cast(root_3317) } else { ifn_3319 = nil }; var arg_3320 any = map__1685000376__6; if linked_3318 == nil { tmp13 = ifn_3319.Invoke_O__O(arg_3320) } else { tmp13 = linked_3318.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3317, arg_3320) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_3321 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3321, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3323 lang.IFn; if linked_3322 == nil { ifn_3323 = lang.IFn_Cast(root_3321) } else { ifn_3323 = nil }; var arg_3324 any = map__1685000376__6; if linked_3322 == nil { tmp14 = ifn_3323.Invoke_O__O(arg_3324) } else { tmp14 = linked_3322.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3321, arg_3324) }; map__1685000376__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp14, jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 any; var root_3325 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3327 lang.IFn; if linked_3326 == nil { ifn_3327 = lang.IFn_Cast(root_3325) } else { ifn_3327 = nil }; var arg_3328 any = map__1685000376__6; if linked_3326 == nil { tmp15 = ifn_3327.Invoke_O__O(arg_3328) } else { tmp15 = linked_3326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3325, arg_3328) }; if jrt.J2g_Truth(tmp15) { var root_3329 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3329, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3331 lang.IFn; if linked_3330 == nil { ifn_3331 = lang.IFn_Cast(root_3329) } else { ifn_3331 = nil }; var arg_3332 any = map__1685000376__6; if linked_3330 == nil { map__1685000376__7 = ifn_3331.Invoke_O__O(arg_3332) } else { map__1685000376__7 = linked_3330.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3329, arg_3332) } } else { map__1685000376__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000376__7 = map__1685000376__6 }
//line :502:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000376__7, A_arbace_go_check_A_const_287); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000376__7, A_arbace_go_check_A_const_288); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_287, dir__8_2)); var pfs__11 any; var root_3333 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3333, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3335 lang.IFn























						if linked_3334 == nil { ifn_3335 = lang.IFn_Cast(root_3333) } else { ifn_3335 = nil }; var arg_3336 any = root__10_2; var arg_3337 any = sub__9_2; if linked_3334 == nil { pfs__11 = ifn_3335.Invoke_O_O__O(arg_3336, arg_3337) } else { pfs__11 = linked_3334.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3333, arg_3336, arg_3337) }
//line :502:1
						var tests__12 any; var root_3338 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3338, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3340 lang.IFn

























						if linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var arg_3341 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000378_A_New(); var tmp17 *jrt.Class; var fncls__3348 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class; if fncls__3348 == nil { var fncls__3348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class = fncls__3348d; tmp17 = fncls__3348d } else { tmp17 = fncls__3348 }; arg_3341 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3342 any = pfs__11; if linked_3339 == nil { tests__12 = ifn_3340.Invoke_O_O__O(arg_3341, arg_3342) } else { tests__12 = linked_3339.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3338, arg_3341, arg_3342)
						}


						var root_3349 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3349, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3351 lang.IFn; if linked_3350 == nil { ifn_3351 = lang.IFn_Cast(root_3349) } else { ifn_3351 = nil }; var arg_3352 any; var root_3353 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3353, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var arg_3357 any; var root_3358 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3360 lang.IFn
						if linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = jobs__1; var arg_3362 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000384_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__3591 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class
						if fncls__3591 == nil { var fncls__3591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class = fncls__3591d; tmp19 = fncls__3591d } else { tmp19 = fncls__3591 }; arg_3362 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :533:1
						var arg_3363 any; var root_3592 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3592, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3594 lang.IFn














						if linked_3593 == nil { ifn_3594 = lang.IFn_Cast(root_3592) } else { ifn_3594 = nil }; var arg_3595 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var arg_3596 any = tests__12; if linked_3593 == nil { arg_3363 = ifn_3594.Invoke_O_O__O(arg_3595, arg_3596) } else { arg_3363 = linked_3593.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3592, arg_3595, arg_3596) }
//line :533:1
						if linked_3359 == nil { arg_3357 = ifn_3360.Invoke_O_O_O__O(arg_3361, arg_3362, arg_3363) } else { arg_3357 = linked_3359.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3358, arg_3361, arg_3362, arg_3363) }
//line :532:1
						if linked_3354 == nil { arg_3352 = ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { arg_3352 = linked_3354.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) }; if linked_3350 == nil { return ifn_3351.Invoke_O__O(arg_3352) } else { return linked_3350.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3349, arg_3352) } } else {
//line :502:1
							return nil } } } }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_New() *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A) Ctor() {}
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A) Invoke_O_O__O(self, s__1685000361__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_New_O_O(s__1685000361__1, self); var tmp2 *jrt.Class; var fncls__3217 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class; if fncls__3217 == nil { var fncls__3217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class = fncls__3217d; tmp2 = fncls__3217d } else { tmp2 = fncls__3217 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A{}; t.Ctor_O_O(p0, p1); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A) Ctor_O_O(c__s__1685000361, c__iter__1685000360 any) { t.F_s__1685000361 = c__s__1685000361; t.F_iter__1685000360 = c__iter__1685000360 }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A) Invoke_O__O(self any) any { { var s__1685000361__1 any; var t_ any = t.F_s__1685000361; t.F_s__1685000361 = nil; s__1685000361__1 = t_; for { var temp__1927000414__auto____2 any; var root_3152 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3152, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3154 lang.IFn; if linked_3153 == nil { ifn_3154 = lang.IFn_Cast(root_3152) } else { ifn_3154 = nil }; var arg_3155 any = s__1685000361__1; if linked_3153 == nil { temp__1927000414__auto____2 = ifn_3154.Invoke_O__O(arg_3155) } else { temp__1927000414__auto____2 = linked_3153.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3152, arg_3155) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000361__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3156 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3158 lang.IFn; if linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any = s__1685000361__3; if linked_3157 == nil { tmp1 = ifn_3158.Invoke_O__O(arg_3159) } else { tmp1 = linked_3157.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3156, arg_3159) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3160 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3160, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3162 lang.IFn; if linked_3161 == nil { ifn_3162 = lang.IFn_Cast(root_3160) } else { ifn_3162 = nil }; var arg_3163 any = s__1685000361__3; if linked_3161 == nil { c__1927001037__auto____4 = ifn_3162.Invoke_O__O(arg_3163) } else { c__1927001037__auto____4 = linked_3161.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3160, arg_3163) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000363__6 any; var root_3164 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3164, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3166 lang.IFn; if linked_3165 == nil { ifn_3166 = lang.IFn_Cast(root_3164) } else { ifn_3166 = nil }; var arg_3167 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3165 == nil { b__1685000363__6 = ifn_3166.Invoke_O__O(arg_3167) } else { b__1685000363__6 = linked_3165.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3164, arg_3167) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1685000363__6); var tmp3 *jrt.Class; var fncls__3177 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class; if fncls__3177 == nil { var fncls__3177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class = fncls__3177d; tmp3 = fncls__3177d } else { tmp3 = fncls__3177 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3178 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3178, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3180 lang.IFn; if linked_3179 == nil { ifn_3180 = lang.IFn_Cast(root_3178) } else { ifn_3180 = nil }; var arg_3181 any; var root_3183 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3183, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3185 lang.IFn; if linked_3184 == nil { ifn_3185 = lang.IFn_Cast(root_3183) } else { ifn_3185 = nil }; var arg_3186 any = b__1685000363__6; if linked_3184 == nil { arg_3181 = ifn_3185.Invoke_O__O(arg_3186) } else { arg_3181 = linked_3184.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3183, arg_3186) }; var arg_3182 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000360); var tmp5 any; var root_3187 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3187, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3189 lang.IFn; if linked_3188 == nil { ifn_3189 = lang.IFn_Cast(root_3187) } else { ifn_3189 = nil }; var arg_3190 any = s__1685000361__3; if linked_3188 == nil { tmp5 = ifn_3189.Invoke_O__O(arg_3190) } else { tmp5 = linked_3188.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3187, arg_3190) }; arg_3182 = tmp4.Invoke_O__O(tmp5); if linked_3179 == nil { return ifn_3180.Invoke_O_O__O(arg_3181, arg_3182) } else { return linked_3179.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3178, arg_3181, arg_3182) } } else { var root_3191 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3193 lang.IFn; if linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any; var root_3196 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3198 lang.IFn; if linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; var arg_3199 any = b__1685000363__6; if linked_3197 == nil { arg_3194 = ifn_3198.Invoke_O__O(arg_3199) } else { arg_3194 = linked_3197.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3196, arg_3199) }; var arg_3195 any; if linked_3192 == nil { return ifn_3193.Invoke_O_O__O(arg_3194, arg_3195) } else { return linked_3192.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3191, arg_3194, arg_3195) } } } else { var pf__4 any; var root_3200 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3202 lang.IFn; if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any = s__1685000361__3; if linked_3201 == nil { pf__4 = ifn_3202.Invoke_O__O(arg_3203) } else { pf__4 = linked_3201.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3200, arg_3203) }; var root_3204 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3204, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3206 lang.IFn; if linked_3205 == nil { ifn_3206 = lang.IFn_Cast(root_3204) } else { ifn_3206 = nil }; var arg_3207 any; var root_3209 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3211 lang.IFn
															if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any = pf__4; if linked_3210 == nil { arg_3207 = ifn_3211.Invoke_O__O(arg_3212) } else { arg_3207 = linked_3210.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3209, arg_3212) }
//line :500:1
	var arg_3208 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000360); var tmp7 any; var root_3213 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = s__1685000361__3; if linked_3214 == nil { tmp7 = ifn_3215.Invoke_O__O(arg_3216) } else { tmp7 = linked_3214.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3213, arg_3216) }; arg_3208 = tmp6.Invoke_O__O(tmp7); if linked_3205 == nil { return ifn_3206.Invoke_O_O__O(arg_3207, arg_3208) } else { return linked_3205.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3204, arg_3207, arg_3208) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000363 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000363 = c__b__1685000363 }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A) Invoke_O__O(self any) any { { var i__1685000362__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000362__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000362__1)); var root_3168 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3168, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3170 lang.IFn; if linked_3169 == nil { ifn_3170 = lang.IFn_Cast(root_3168) } else { ifn_3170 = nil }; var arg_3171 any = t.F_b__1685000363; var arg_3172 any; var root_3173 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3175 lang.IFn
																if linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any = pf__2; if linked_3174 == nil { arg_3172 = ifn_3175.Invoke_O__O(arg_3176) } else { arg_3172 = linked_3174.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3173, arg_3176) }
//line :500:1
	if linked_3169 == nil { ifn_3170.Invoke_O_O__O(arg_3171, arg_3172) } else { linked_3169.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3168, arg_3171, arg_3172) }; i__1685000362__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000362__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000370_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000370_A{}; t.Ctor_O(p0); return t }
//line :505:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :505:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_3230 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3230, A_arbace_go_check_result_of_A_fn_class); var ifn_3232 lang.IFn
												if linked_3231 == nil { ifn_3232 = lang.IFn_Cast(root_3230) } else { ifn_3232 = nil }; var arg_3233 any; var root_3234 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3236 lang.IFn; if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = t.F_s; var arg_3238 any = path__1; var arg_3239 any; var arg_3240 any = lang.PersistentVector_EMPTY.Ref(); if linked_3235 == nil { arg_3233 = ifn_3236.Invoke_O_O_O_O__O(arg_3237, arg_3238, arg_3239, arg_3240) } else { arg_3233 = linked_3235.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3234, arg_3237, arg_3238, arg_3239, arg_3240) }; if linked_3231 == nil { or__1927000174__auto____4 = ifn_3232.Invoke_O__O(arg_3233) } else { or__1927000174__auto____4 = linked_3231.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3230, arg_3233) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110, path__1, A_arbace_go_check_A_const_320, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :505:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_3241 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, A_arbace_go_check_error_result_A_fn_class); var ifn_3243 lang.IFn


		if linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any = path__1; var arg_3245 any = ex__4; if linked_3242 == nil { tmp1 = ifn_3243.Invoke_O_O__O(arg_3244, arg_3245) } else { tmp1 = linked_3242.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3241, arg_3244, arg_3245) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000374_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000374_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :514:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :514:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_3269 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3269, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3271 lang.IFn

	if linked_3270 == nil { ifn_3271 = lang.IFn_Cast(root_3269) } else { ifn_3271 = nil }; var arg_3272 any = t.F_root; var arg_3273 any; var arg_3274 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_cc); var arg_3275 any = pf__1; if linked_3270 == nil { src__4 = ifn_3271.Invoke_O_O_O_O__O(arg_3272, arg_3273, arg_3274, arg_3275) } else { src__4 = linked_3270.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3269, arg_3272, arg_3273, arg_3274, arg_3275) }
	var tmp2 any; var root_3276 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__4); if linked_3277 == nil { tmp2 = ifn_3278.Invoke_O__O(arg_3279) } else { tmp2 = linked_3277.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3276, arg_3279) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_110; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_320, jrt.Boolean_TRUE.Ref())) } else {

		var root_3280 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3280, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3282 lang.IFn; if linked_3281 == nil { ifn_3282 = lang.IFn_Cast(root_3280) } else { ifn_3282 = nil }; var arg_3283 any; var root_3286 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3286, A_arbace_go_check_result_of_A_fn_class); var ifn_3288 lang.IFn; if linked_3287 == nil { ifn_3288 = lang.IFn_Cast(root_3286) } else { ifn_3288 = nil }; var arg_3289 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_276.GetRawRoot__O()); var tmp5 any; var root_3295 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_3296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3295, A_arbace_go_check_resolver_A_fn_class); var ifn_3297 lang.IFn; if linked_3296 == nil { ifn_3297 = lang.IFn_Cast(root_3295) } else { ifn_3297 = nil }; var arg_3298 any = t.F_s; var arg_3299 any = src__4; var arg_3300 any = lang.PersistentVector_EMPTY.Ref(); if linked_3296 == nil { tmp5 = ifn_3297.Invoke_O_O_O__O(arg_3298, arg_3299, arg_3300) } else { tmp5 = linked_3296.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3295, arg_3298, arg_3299, arg_3300) }; arg_3289 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_3287 == nil { arg_3283 = ifn_3288.Invoke_O__O(arg_3289) } else { arg_3283 = linked_3287.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3286, arg_3289) }; var arg_3284 any = A_arbace_go_check_A_const_110; var arg_3285 any; var root_3301 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3301, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3303 lang.IFn
		if linked_3302 == nil { ifn_3303 = lang.IFn_Cast(root_3301) } else { ifn_3303 = nil }; var arg_3304 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3305 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_3302 == nil { arg_3285 = ifn_3303.Invoke_O_O__O(arg_3304, arg_3305) } else { arg_3285 = linked_3302.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3301, arg_3304, arg_3305) }
//line :519:1
		if linked_3281 == nil { tmp1 = ifn_3282.Invoke_O_O_O__O(arg_3283, arg_3284, arg_3285) } else { tmp1 = linked_3281.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3280, arg_3283, arg_3284, arg_3285) } } }; return nil }(); if /*line :514:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_3306 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3306, A_arbace_go_check_error_result_A_fn_class); var ifn_3308 lang.IFn






			if linked_3307 == nil { ifn_3308 = lang.IFn_Cast(root_3306) } else { ifn_3308 = nil }; var arg_3309 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3310 any = ex__4; if linked_3307 == nil { tmp1 = ifn_3308.Invoke_O_O__O(arg_3309, arg_3310) } else { tmp1 = linked_3307.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3306, arg_3309, arg_3310) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000378_A_New() *A_arbace_go_check_check_corpus_fn__1685000378_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000378_A{}; t.Ctor(); return t }
//line :528:1
func (t *A_arbace_go_check_check_corpus_fn__1685000378_A) Ctor() {}
//line :528:1
func (t *A_arbace_go_check_check_corpus_fn__1685000378_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_3343 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3345 lang.IFn; if

	linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = A_arbace_go_check_A_const_325; var arg_3347 any = p__2; if linked_3344 == nil { temp__1927000408__auto____3 = ifn_3345.Invoke_O_O__O(arg_3346, arg_3347) } else { temp__1927000408__auto____3 = linked_3344.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3343, arg_3346, arg_3347) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000379__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000384_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_A) Invoke_O_O__O(self, p__1685000383__1 any) any { var vec__1685000385__2 any = p__1685000383__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_3364 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3364, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3366 lang.IFn

	if linked_3365 == nil { ifn_3366 = lang.IFn_Cast(root_3364) } else { ifn_3366 = nil }; var arg_3367 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3368 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_New(); var tmp3 *jrt.Class; var fncls__3435 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class; if fncls__3435 == nil { var fncls__3435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class = fncls__3435d; tmp3 = fncls__3435d } else { tmp3 = fncls__3435 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_3368 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_3365 == nil { by_path__7 = ifn_3366.Invoke_O_O__O(arg_3367, arg_3368) } else { by_path__7 = linked_3365.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3364, arg_3367, arg_3368) }
//line :534:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp5 any; var root_3444 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_3445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3444, A_arbace_go_check_session_A_fn_class); var ifn_3446 lang.IFn



	if linked_3445 == nil { ifn_3446 = lang.IFn_Cast(root_3444) } else { ifn_3446 = nil }; var arg_3447 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__3455 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class; if fncls__3455 == nil { var fncls__3455d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class = fncls__3455d; tmp7 = fncls__3455d } else { tmp7 = fncls__3455 }; arg_3447 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3445 == nil { tmp5 = ifn_3446.Invoke_O__O(arg_3447) } else { tmp5 = linked_3445.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3444, arg_3447) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_265; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_274; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__3461 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class; if fncls__3461 == nil { var fncls__3461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class = fncls__3461d; tmp13 = fncls__3461d } else { tmp13 = fncls__3461 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_3462 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3462, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3464 lang.IFn; if linked_3463 == nil { ifn_3464 = lang.IFn_Cast(root_3462) } else { ifn_3464 = nil }; var arg_3465 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__3580 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class; if fncls__3580 == nil { var fncls__3580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class = fncls__3580d; tmp15 = fncls__3580d } else { tmp15 = fncls__3580 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_3581 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3581, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3583 lang.IFn; if linked_3582 == nil { ifn_3583 = lang.IFn_Cast(root_3581) } else { ifn_3583 = nil }; var arg_3584 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var arg_3585 any = by_path__7; if linked_3582 == nil { tmp17 = ifn_3583.Invoke_O_O__O(arg_3584, arg_3585) } else { tmp17 = linked_3582.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3581, arg_3584, arg_3585) }; arg_3465 = tmp16.Invoke_O__O(tmp17); if linked_3463 == nil { tmp1 = ifn_3464.Invoke_O__O(arg_3465) } else { tmp1 = linked_3463.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3462, arg_3465) } }; return nil }(); if /*line :534:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_3586 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3586, A_arbace_go_check_error_result_A_fn_class); var ifn_3588 lang.IFn












		if linked_3587 == nil { ifn_3588 = lang.IFn_Cast(root_3586) } else { ifn_3588 = nil }; var arg_3589 any = tdir__3; var arg_3590 any = ex__7; if linked_3587 == nil { tmp19 = ifn_3588.Invoke_O_O__O(arg_3589, arg_3590) } else { tmp19 = linked_3587.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3586, arg_3589, arg_3590) }
//line :534:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_New() *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A) Ctor() {}
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A) Invoke_O_O__O(self, s__1685000389__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_New_O_O(s__1685000389__1, self); var tmp2 *jrt.Class; var fncls__3434 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class; if fncls__3434 == nil { var fncls__3434d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class = fncls__3434d; tmp2 = fncls__3434d } else { tmp2 = fncls__3434 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :536:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A) Ctor_O_O(c__s__1685000389, c__iter__1685000388 any) { t.F_s__1685000389 = c__s__1685000389; t.F_iter__1685000388 = c__iter__1685000388 }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A) Invoke_O__O(self any) any { { var s__1685000389__1 any; var t_ any = t.F_s__1685000389; t.F_s__1685000389 = nil; s__1685000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_3369 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3369, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3371 lang.IFn; if linked_3370 == nil { ifn_3371 = lang.IFn_Cast(root_3369) } else { ifn_3371 = nil }; var arg_3372 any = s__1685000389__1; if linked_3370 == nil { temp__1927000414__auto____2 = ifn_3371.Invoke_O__O(arg_3372) } else { temp__1927000414__auto____2 = linked_3370.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3369, arg_3372) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3373 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3373, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3375 lang.IFn; if linked_3374 == nil { ifn_3375 = lang.IFn_Cast(root_3373) } else { ifn_3375 = nil }; var arg_3376 any = s__1685000389__3; if linked_3374 == nil { tmp1 = ifn_3375.Invoke_O__O(arg_3376) } else { tmp1 = linked_3374.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3373, arg_3376) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3377 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3377, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3379 lang.IFn; if linked_3378 == nil { ifn_3379 = lang.IFn_Cast(root_3377) } else { ifn_3379 = nil }; var arg_3380 any = s__1685000389__3; if linked_3378 == nil { c__1927001037__auto____4 = ifn_3379.Invoke_O__O(arg_3380) } else { c__1927001037__auto____4 = linked_3378.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3377, arg_3380) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000391__6 any; var root_3381 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3381, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3383 lang.IFn; if linked_3382 == nil { ifn_3383 = lang.IFn_Cast(root_3381) } else { ifn_3383 = nil }; var arg_3384 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3382 == nil { b__1685000391__6 = ifn_3383.Invoke_O__O(arg_3384) } else { b__1685000391__6 = linked_3382.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3381, arg_3384) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_New_O_I_O(b__1685000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3394 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class; if fncls__3394 == nil { var fncls__3394d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class = fncls__3394d; tmp3 = fncls__3394d } else { tmp3 = fncls__3394 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3395 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any; var root_3400 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = b__1685000391__6; if linked_3401 == nil { arg_3398 = ifn_3402.Invoke_O__O(arg_3403) } else { arg_3398 = linked_3401.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3400, arg_3403) }; var arg_3399 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000388); var tmp5 any; var root_3404 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3406 lang.IFn; if linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var arg_3407 any = s__1685000389__3; if linked_3405 == nil { tmp5 = ifn_3406.Invoke_O__O(arg_3407) } else { tmp5 = linked_3405.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3404, arg_3407) }; arg_3399 = tmp4.Invoke_O__O(tmp5); if linked_3396 == nil { return ifn_3397.Invoke_O_O__O(arg_3398, arg_3399) } else { return linked_3396.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3395, arg_3398, arg_3399) } } else { var root_3408 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3408, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3410 lang.IFn; if linked_3409 == nil { ifn_3410 = lang.IFn_Cast(root_3408) } else { ifn_3410 = nil }; var arg_3411 any; var root_3413 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3413, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = b__1685000391__6; if linked_3414 == nil { arg_3411 = ifn_3415.Invoke_O__O(arg_3416) } else { arg_3411 = linked_3414.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3413, arg_3416) }; var arg_3412 any; if linked_3409 == nil { return ifn_3410.Invoke_O_O__O(arg_3411, arg_3412) } else { return linked_3409.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3408, arg_3411, arg_3412) } } } else { var pf__4 any; var root_3417 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3419 lang.IFn; if linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = s__1685000389__3; if linked_3418 == nil { pf__4 = ifn_3419.Invoke_O__O(arg_3420) } else { pf__4 = linked_3418.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3417, arg_3420) }; var root_3421 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any; var tmp6 any; var root_3426 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3428 lang.IFn; if linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any = pf__4; if linked_3427 == nil { tmp6 = ifn_3428.Invoke_O__O(arg_3429) } else { tmp6 = linked_3427.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3426, arg_3429) }; arg_3424 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_3425 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000388); var tmp8 any; var root_3430 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3430, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3432 lang.IFn; if linked_3431 == nil { ifn_3432 = lang.IFn_Cast(root_3430) } else { ifn_3432 = nil }; var arg_3433 any = s__1685000389__3; if linked_3431 == nil { tmp8 = ifn_3432.Invoke_O__O(arg_3433) } else { tmp8 = linked_3431.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3430, arg_3433) }; arg_3425 = tmp7.Invoke_O__O(tmp8); if linked_3422 == nil { return ifn_3423.Invoke_O_O__O(arg_3424, arg_3425) } else { return linked_3422.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3421, arg_3424, arg_3425) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :536:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A) Ctor_O_I_O(c__b__1685000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000391 = c__b__1685000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A) Invoke_O__O(self any) any { { var i__1685000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000390__1)); var root_3385 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3385, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3387 lang.IFn; if linked_3386 == nil { ifn_3387 = lang.IFn_Cast(root_3385) } else { ifn_3387 = nil }; var arg_3388 any = t.F_b__1685000391; var arg_3389 any; var tmp2 any; var root_3390 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3390, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3392 lang.IFn; if linked_3391 == nil { ifn_3392 = lang.IFn_Cast(root_3390) } else { ifn_3392 = nil }; var arg_3393 any = pf__2; if linked_3391 == nil { tmp2 = ifn_3392.Invoke_O__O(arg_3393) } else { tmp2 = linked_3391.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3390, arg_3393) }; arg_3389 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_3386 == nil { ifn_3387.Invoke_O_O__O(arg_3388, arg_3389) } else { linked_3386.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3385, arg_3388, arg_3389) }; i__1685000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_3448 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3448, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3450 lang.IFn
																	if linked_3449 == nil { ifn_3450 = lang.IFn_Cast(root_3448) } else { ifn_3450 = nil }; var arg_3451 any = t.F_root; var arg_3452 any = path__1; var arg_3453 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_cc); var arg_3454 any = pf__4; if linked_3449 == nil { return ifn_3450.Invoke_O_O_O_O__O(arg_3451, arg_3452, arg_3453, arg_3454) } else { return linked_3449.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3448, arg_3451, arg_3452, arg_3453, arg_3454) } } else {
//line :539:1
			return nil } }
//line :538:1
func A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A{}; t.Ctor_O(p0); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A) Invoke_O_O__O(self, p1__1685000359_SHARP___1 any) any {


	var root_3456 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_3457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3456, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3458 lang.IFn; if linked_3457 == nil { ifn_3458 = lang.IFn_Cast(root_3456) } else { ifn_3458 = nil }; var arg_3459 any = t.F_by_path; var arg_3460 any = p1__1685000359_SHARP___1; if linked_3457 == nil { return ifn_3458.Invoke_O_O__O(arg_3459, arg_3460) } else { return linked_3457.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3456, arg_3459, arg_3460) } }
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A) Invoke_O_O__O(self, s__1685000403__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_New_O_O_O_O_O(self, t.F_dir, t.F_tdir, t.F_ts, s__1685000403__1); var tmp2 *jrt.Class; var fncls__3579 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class; if fncls__3579 == nil { var fncls__3579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class = fncls__3579d; tmp2 = fncls__3579d } else { tmp2 = fncls__3579 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A) Ctor_O_O_O_O_O(c__iter__1685000402, c__dir, c__tdir, c__ts, c__s__1685000403 any) { t.F_iter__1685000402 = c__iter__1685000402; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1685000403 = c__s__1685000403 }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A) Invoke_O__O(self any) any { { var s__1685000403__1 any; var t_ any = t.F_s__1685000403; t.F_s__1685000403 = nil; s__1685000403__1 = t_; for { var temp__1927000414__auto____2 any; var root_3466 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3468 lang.IFn; if linked_3467 == nil { ifn_3468 = lang.IFn_Cast(root_3466) } else { ifn_3468 = nil }; var arg_3469 any = s__1685000403__1; if linked_3467 == nil { temp__1927000414__auto____2 = ifn_3468.Invoke_O__O(arg_3469) } else { temp__1927000414__auto____2 = linked_3467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3466, arg_3469) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000403__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3470 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3470, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3472 lang.IFn; if linked_3471 == nil { ifn_3472 = lang.IFn_Cast(root_3470) } else { ifn_3472 = nil }; var arg_3473 any = s__1685000403__3; if linked_3471 == nil { tmp1 = ifn_3472.Invoke_O__O(arg_3473) } else { tmp1 = linked_3471.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3470, arg_3473) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3474 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any = s__1685000403__3; if linked_3475 == nil { c__1927001037__auto____4 = ifn_3476.Invoke_O__O(arg_3477) } else { c__1927001037__auto____4 = linked_3475.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3474, arg_3477) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000405__6 any; var root_3478 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3478, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3480 lang.IFn; if linked_3479 == nil { ifn_3480 = lang.IFn_Cast(root_3478) } else { ifn_3480 = nil }; var arg_3481 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3479 == nil { b__1685000405__6 = ifn_3480.Invoke_O__O(arg_3481) } else { b__1685000405__6 = linked_3479.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3478, arg_3481) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_New_O_O_O_O_I_O(t.F_dir, b__1685000405__6, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3515 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class; if fncls__3515 == nil { var fncls__3515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class = fncls__3515d; tmp3 = fncls__3515d } else { tmp3 = fncls__3515 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3516 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3516, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3518 lang.IFn; if linked_3517 == nil { ifn_3518 = lang.IFn_Cast(root_3516) } else { ifn_3518 = nil }; var arg_3519 any; var root_3521 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3521, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3523 lang.IFn; if linked_3522 == nil { ifn_3523 = lang.IFn_Cast(root_3521) } else { ifn_3523 = nil }; var arg_3524 any = b__1685000405__6; if linked_3522 == nil { arg_3519 = ifn_3523.Invoke_O__O(arg_3524) } else { arg_3519 = linked_3522.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3521, arg_3524) }; var arg_3520 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000402); var tmp5 any; var root_3525 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3527 lang.IFn; if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any = s__1685000403__3; if linked_3526 == nil { tmp5 = ifn_3527.Invoke_O__O(arg_3528) } else { tmp5 = linked_3526.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3525, arg_3528) }; arg_3520 = tmp4.Invoke_O__O(tmp5); if linked_3517 == nil { return ifn_3518.Invoke_O_O__O(arg_3519, arg_3520) } else { return linked_3517.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3516, arg_3519, arg_3520) } } else { var root_3529 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3529, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3531 lang.IFn; if linked_3530 == nil { ifn_3531 = lang.IFn_Cast(root_3529) } else { ifn_3531 = nil }; var arg_3532 any; var root_3534 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any = b__1685000405__6; if linked_3535 == nil { arg_3532 = ifn_3536.Invoke_O__O(arg_3537) } else { arg_3532 = linked_3535.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3534, arg_3537) }; var arg_3533 any; if linked_3530 == nil { return ifn_3531.Invoke_O_O__O(arg_3532, arg_3533) } else { return linked_3530.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3529, arg_3532, arg_3533) } } } else { var vec__1685000415__4 any; var root_3538 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3538, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3540 lang.IFn; if linked_3539 == nil { ifn_3540 = lang.IFn_Cast(root_3538) } else { ifn_3540 = nil }; var arg_3541 any = s__1685000403__3; if linked_3539 == nil { vec__1685000415__4 = ifn_3540.Invoke_O__O(arg_3541) } else { vec__1685000415__4 = linked_3539.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3538, arg_3541) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000415__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000415__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3542 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3542, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3544 lang.IFn; _ = pf__6; if linked_3543 == nil { ifn_3544 = lang.IFn_Cast(root_3542) } else { ifn_3544 = nil }; var arg_3545 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3574 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class
																if fncls__3574 == nil { var fncls__3574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class = fncls__3574d; tmp7 = fncls__3574d } else { tmp7 = fncls__3574 }; arg_3545 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :542:1
	var arg_3546 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000402); var tmp9 any; var root_3575 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3575, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3577 lang.IFn; if linked_3576 == nil { ifn_3577 = lang.IFn_Cast(root_3575) } else { ifn_3577 = nil }; var arg_3578 any = s__1685000403__3; if linked_3576 == nil { tmp9 = ifn_3577.Invoke_O__O(arg_3578) } else { tmp9 = linked_3576.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3575, arg_3578) }; arg_3546 = tmp8.Invoke_O__O(tmp9); if linked_3543 == nil { return ifn_3544.Invoke_O_O__O(arg_3545, arg_3546) } else { return linked_3543.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3542, arg_3545, arg_3546) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A) Ctor_O_O_O_O_I_O(c__dir, c__b__1685000405, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__1685000405 = c__b__1685000405; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A) Invoke_O__O(self any) any { { var i__1685000404__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000404__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000409__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000404__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000409__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000409__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3482 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3482, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3484 lang.IFn; _ = pf__4; if linked_3483 == nil { ifn_3484 = lang.IFn_Cast(root_3482) } else { ifn_3484 = nil }; var arg_3485 any = t.F_b__1685000405; var arg_3486 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3514 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class
																		if fncls__3514 == nil { var fncls__3514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class = fncls__3514d; tmp3 = fncls__3514d } else { tmp3 = fncls__3514 }; arg_3486 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :542:1
	if linked_3483 == nil { ifn_3484.Invoke_O_O__O(arg_3485, arg_3486) } else { linked_3483.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3482, arg_3485, arg_3486) }; i__1685000404__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000404__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_3487 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3488 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3487, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3489 lang.IFn; if linked_3488 == nil { ifn_3489 = lang.IFn_Cast(root_3487) } else { ifn_3489 = nil }; var arg_3490 any; var or__1927000174__auto____3 any; var root_3493 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, A_arbace_go_check_result_of_A_fn_class); var ifn_3495 lang.IFn; if linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any; var root_3497 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_3498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3497, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3499 lang.IFn; if linked_3498 == nil { ifn_3499 = lang.IFn_Cast(root_3497) } else { ifn_3499 = nil }; var arg_3500 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3500 = t_; var arg_3501 any = t.F_path; var arg_3502 any; var arg_3503 any = lang.PersistentVector_EMPTY.Ref(); if linked_3498 == nil { arg_3496 = ifn_3499.Invoke_O_O_O_O__O(arg_3500, arg_3501, arg_3502, arg_3503) } else { arg_3496 = linked_3498.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3497, arg_3500, arg_3501, arg_3502, arg_3503) }; if linked_3494 == nil { or__1927000174__auto____3 = ifn_3495.Invoke_O__O(arg_3496) } else { or__1927000174__auto____3 = linked_3494.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3493, arg_3496) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3490 = or__1927000174__auto____3 } else { arg_3490 = A_arbace_go_check_A_const_327 }; var arg_3491 any = A_arbace_go_check_A_const_110; var arg_3492 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3504 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3504, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3506 lang.IFn
																					if linked_3505 == nil { ifn_3506 = lang.IFn_Cast(root_3504) } else { ifn_3506 = nil }; var arg_3507 any = t.F_tdir; var arg_3508 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3508 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3505 == nil { tmp3 = ifn_3506.Invoke_O_O__O(arg_3507, arg_3508) } else { tmp3 = linked_3505.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3504, arg_3507, arg_3508) }; arg_3492 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :544:1
		if linked_3488 == nil { tmp1 = ifn_3489.Invoke_O_O_O__O(arg_3490, arg_3491, arg_3492) } else { tmp1 = linked_3488.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3487, arg_3490, arg_3491, arg_3492) } }
//line :543:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3509 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, A_arbace_go_check_error_result_A_fn_class); var ifn_3511 lang.IFn


		if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3512 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3513 any = ex__3; if linked_3510 == nil { tmp1 = ifn_3511.Invoke_O_O__O(arg_3512, arg_3513) } else { tmp1 = linked_3510.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3509, arg_3512, arg_3513) } } }; return tmp1 }
//line :543:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3547 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3548 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3547, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3549 lang.IFn; if linked_3548 == nil { ifn_3549 = lang.IFn_Cast(root_3547) } else { ifn_3549 = nil }; var arg_3550 any; var or__1927000174__auto____3 any; var root_3553 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3553, A_arbace_go_check_result_of_A_fn_class); var ifn_3555 lang.IFn; if linked_3554 == nil { ifn_3555 = lang.IFn_Cast(root_3553) } else { ifn_3555 = nil }; var arg_3556 any; var root_3557 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3560 = t_; var arg_3561 any = t.F_path; var arg_3562 any; var arg_3563 any = lang.PersistentVector_EMPTY.Ref(); if linked_3558 == nil { arg_3556 = ifn_3559.Invoke_O_O_O_O__O(arg_3560, arg_3561, arg_3562, arg_3563) } else { arg_3556 = linked_3558.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3557, arg_3560, arg_3561, arg_3562, arg_3563) }; if linked_3554 == nil { or__1927000174__auto____3 = ifn_3555.Invoke_O__O(arg_3556) } else { or__1927000174__auto____3 = linked_3554.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3553, arg_3556) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3550 = or__1927000174__auto____3 } else { arg_3550 = A_arbace_go_check_A_const_328 }; var arg_3551 any = A_arbace_go_check_A_const_110; var arg_3552 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3564 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3564, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3566 lang.IFn
																			if linked_3565 == nil { ifn_3566 = lang.IFn_Cast(root_3564) } else { ifn_3566 = nil }; var arg_3567 any = t.F_tdir; var arg_3568 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3568 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3565 == nil { tmp3 = ifn_3566.Invoke_O_O__O(arg_3567, arg_3568) } else { tmp3 = linked_3565.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3564, arg_3567, arg_3568) }; arg_3552 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :544:1
		if linked_3548 == nil { tmp1 = ifn_3549.Invoke_O_O_O__O(arg_3550, arg_3551, arg_3552) } else { tmp1 = linked_3548.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3547, arg_3550, arg_3551, arg_3552) } }
//line :543:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3569 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3569, A_arbace_go_check_error_result_A_fn_class); var ifn_3571 lang.IFn


		if linked_3570 == nil { ifn_3571 = lang.IFn_Cast(root_3569) } else { ifn_3571 = nil }; var arg_3572 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3572 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3573 any = ex__3; if linked_3570 == nil { tmp1 = ifn_3571.Invoke_O_O__O(arg_3572, arg_3573) } else { tmp1 = linked_3570.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3569, arg_3572, arg_3573) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :550:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :550:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3597 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3597, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3599 lang.IFn; if


	linked_3598 == nil { ifn_3599 = lang.IFn_Cast(root_3597) } else { ifn_3599 = nil }; var arg_3600 any = A_arbace_go_check_A_const_320; var arg_3601 any = results__1; if linked_3598 == nil { rs__3 = ifn_3599.Invoke_O_O__O(arg_3600, arg_3601) } else { rs__3 = linked_3598.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3597, arg_3600, arg_3601) }; var sum__4 any; var tmp1 any = /*line :550:1*/A_arbace_go_check_summarize_sum__1685000430_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3613 *jrt.Class = A_arbace_go_check_summarize_sum__1685000430_A_fn_class; if



	fncls__3613 == nil { var fncls__3613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_go_check_summarize_sum__1685000430_A_fn_class = fncls__3613d; tmp2 = fncls__3613d } else { tmp2 = fncls__3613 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :550:1*/A_arbace_go_check_summarize_msum__1685000432_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__3626 *jrt.Class = A_arbace_go_check_summarize_msum__1685000432_A_fn_class; if




	fncls__3626 == nil { var fncls__3626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_check_summarize_msum__1685000432_A_fn_class = fncls__3626d; tmp4 = fncls__3626d } else { tmp4 = fncls__3626 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_294; var tmp6 any = A_arbace_go_check_A_const_330; var tmp7 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_331; var tmp9 any = A_arbace_go_check_A_const_332; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_82); var tmp11 any = A_arbace_go_check_A_const_163; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_163); var tmp13 any = A_arbace_go_check_A_const_149; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_154); var tmp15 any = A_arbace_go_check_A_const_152; var tmp16 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_152); var tmp17 any = A_arbace_go_check_A_const_144; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_155))); var tmp19 any = A_arbace_go_check_A_const_237; var tmp20 lang.IFn = lang.IFn_Cast(sum__4); var tmp21 any = A_arbace_go_check_summarize_fn__1685000434_A_New(); var tmp22 *jrt.Class; var fncls__3709 *jrt.Class = A_arbace_go_check_summarize_fn__1685000434_A_fn_class; if












	fncls__3709 == nil { var fncls__3709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_go_check_summarize_fn__1685000434_A_fn_class = fncls__3709d; tmp22 = fncls__3709d } else { tmp22 = fncls__3709 }; var tmp23 any = /*line :550:1*/tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)); var tmp24 any = A_arbace_go_check_A_const_333; var tmp25 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_240); var tmp26 any = A_arbace_go_check_A_const_334; var tmp27 any; var root_3627 any = A_arbace_go_check_A_const_335.GetRawRoot__O(); var linked_3628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3627, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3629 lang.IFn; if














	linked_3628 == nil { ifn_3629 = lang.IFn_Cast(root_3627) } else { ifn_3629 = nil }; var arg_3630 any; var tmp28 any = A_arbace_go_check_summarize_fn__1685000436_A_New(); var tmp29 *jrt.Class; var fncls__3632 *jrt.Class = A_arbace_go_check_summarize_fn__1685000436_A_fn_class; if fncls__3632 == nil { var fncls__3632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_go_check_summarize_fn__1685000436_A_fn_class = fncls__3632d; tmp29 = fncls__3632d } else { tmp29 = fncls__3632 }; arg_3630 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_3631 any = rs__3; if linked_3628 == nil { tmp27 = ifn_3629.Invoke_O_O__O(arg_3630, arg_3631) } else { tmp27 = linked_3628.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3627, arg_3630, arg_3631) }; var tmp30 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref(); var tmp31 any = A_arbace_go_check_A_const_336; var tmp32 any; var root_3633 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3633, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3635 lang.IFn; if















	linked_3634 == nil { ifn_3635 = lang.IFn_Cast(root_3633) } else { ifn_3635 = nil }; var arg_3636 any; var root_3637 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_3638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3637, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3639 lang.IFn; if linked_3638 == nil { ifn_3639 = lang.IFn_Cast(root_3637) } else { ifn_3639 = nil }; var arg_3640 any; var tmp33 any = A_arbace_go_check_summarize_fn__1685000438_A_New(); var tmp34 *jrt.Class; var fncls__3642 *jrt.Class = A_arbace_go_check_summarize_fn__1685000438_A_fn_class; if fncls__3642 == nil { var fncls__3642d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_go_check_summarize_fn__1685000438_A_fn_class = fncls__3642d; tmp34 = fncls__3642d } else { tmp34 = fncls__3642 }; arg_3640 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3641 any = rs__3; if linked_3638 == nil { arg_3636 = ifn_3639.Invoke_O_O__O(arg_3640, arg_3641) } else { arg_3636 = linked_3638.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3637, arg_3640, arg_3641) }; if linked_3634 == nil { tmp32 = ifn_3635.Invoke_O__O(arg_3636) } else { tmp32 = linked_3634.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3633, arg_3636) }; var tmp35 any = tmp32; var tmp36 any = A_arbace_go_check_A_const_337; var tmp37 any = A_arbace_go_check_A_const_139; var tmp38 any; var root_3643 any = /*line :550:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3645 lang.IFn; if
















	linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = lang.IFn_Cast(A_arbace_go_check_A_const_338.GetRawRoot__O()).Invoke__O(); var arg_3647 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_139); if linked_3644 == nil { tmp38 = ifn_3645.Invoke_O_O__O(arg_3646, arg_3647) } else { tmp38 = linked_3644.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3643, arg_3646, arg_3647) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_go_check_A_const_164; var tmp41 any; var root_3651 any = /*line :550:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3651, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3653 lang.IFn; if

















	linked_3652 == nil { ifn_3653 = lang.IFn_Cast(root_3651) } else { ifn_3653 = nil }; var arg_3654 any = lang.IFn_Cast(A_arbace_go_check_A_const_338.GetRawRoot__O()).Invoke__O(); var arg_3655 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_164); if linked_3652 == nil { tmp41 = ifn_3653.Invoke_O_O__O(arg_3654, arg_3655) } else { tmp41 = linked_3652.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3651, arg_3654, arg_3655) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_go_check_A_const_165; var tmp44 any; var root_3659 any = /*line :550:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3659, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3661 lang.IFn; if


















	linked_3660 == nil { ifn_3661 = lang.IFn_Cast(root_3659) } else { ifn_3661 = nil }; var arg_3662 any = lang.IFn_Cast(A_arbace_go_check_A_const_338.GetRawRoot__O()).Invoke__O(); var arg_3663 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_165); if linked_3660 == nil { tmp44 = ifn_3661.Invoke_O_O__O(arg_3662, arg_3663) } else { tmp44 = linked_3660.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3659, arg_3662, arg_3663) }; var tmp45 any = tmp44; var tmp46 any = A_arbace_go_check_A_const_339; var tmp47 any; var root_3667 any = /*line :550:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3667, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3669 lang.IFn; if



















	linked_3668 == nil { ifn_3669 = lang.IFn_Cast(root_3667) } else { ifn_3669 = nil }; var arg_3670 any = lang.IFn_Cast(A_arbace_go_check_A_const_338.GetRawRoot__O()).Invoke__O(); var arg_3671 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_156); if linked_3668 == nil { tmp47 = ifn_3669.Invoke_O_O__O(arg_3670, arg_3671) } else { tmp47 = linked_3668.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3667, arg_3670, arg_3671) }; var tmp48 any = tmp47; var tmp49 any = A_arbace_go_check_A_const_241; var tmp50 any = A_arbace_go_check_A_const_330; var tmp51 any; var root_3675 any = /*line :550:1*/A_arbace_go_check_A_const_335.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3677 lang.IFn; if




















	linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any; var tmp52 any = A_arbace_go_check_summarize_fn__1685000440_A_New(); var tmp53 *jrt.Class; var fncls__3685 *jrt.Class = A_arbace_go_check_summarize_fn__1685000440_A_fn_class; if fncls__3685 == nil { var fncls__3685d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_go_check_summarize_fn__1685000440_A_fn_class = fncls__3685d; tmp53 = fncls__3685d } else { tmp53 = fncls__3685 }; arg_3678 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var arg_3679 any = rs__3; if linked_3676 == nil { tmp51 = ifn_3677.Invoke_O_O__O(arg_3678, arg_3679) } else { tmp51 = linked_3676.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3675, arg_3678, arg_3679) }; var tmp54 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp51)).Ref(); var tmp55 any = A_arbace_go_check_A_const_341; var tmp56 lang.IFn = lang.IFn_Cast(sum__4); var tmp57 any = A_arbace_go_check_summarize_fn__1685000442_A_New(); var tmp58 *jrt.Class; var fncls__3716 *jrt.Class = A_arbace_go_check_summarize_fn__1685000442_A_fn_class; if





















	fncls__3716 == nil { var fncls__3716d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_go_check_summarize_fn__1685000442_A_fn_class = fncls__3716d; tmp58 = fncls__3716d } else { tmp58 = fncls__3716 }; var tmp59 any = /*line :550:1*/tmp56.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil)); var tmp60 any = A_arbace_go_check_A_const_342; var tmp61 any; var root_3686 any = A_arbace_go_check_A_const_335.GetRawRoot__O(); var linked_3687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3686, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3688 lang.IFn; if






















	linked_3687 == nil { ifn_3688 = lang.IFn_Cast(root_3686) } else { ifn_3688 = nil }; var arg_3689 any; var tmp62 any = A_arbace_go_check_summarize_fn__1685000444_A_New(); var tmp63 *jrt.Class; var fncls__3700 *jrt.Class = A_arbace_go_check_summarize_fn__1685000444_A_fn_class; if fncls__3700 == nil { var fncls__3700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_check_summarize_fn__1685000444_A_fn_class = fncls__3700d; tmp63 = fncls__3700d } else { tmp63 = fncls__3700 }; arg_3689 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil); var arg_3690 any = rs__3; if linked_3687 == nil { tmp61 = ifn_3688.Invoke_O_O__O(arg_3689, arg_3690) } else { tmp61 = linked_3687.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3686, arg_3689, arg_3690) }; var tmp64 any = /*line :550:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, tmp40, tmp42, tmp43, tmp45, tmp46, tmp48, tmp49, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp54, tmp55, tmp59, tmp60, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp61)).Ref())))); var tmp65 any = A_arbace_go_check_A_const_144; var tmp66 any; var root_3701 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3701, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3703 lang.IFn; if























	linked_3702 == nil { ifn_3703 = lang.IFn_Cast(root_3701) } else { ifn_3703 = nil }; var arg_3704 any = lang.IFn_Cast(A_arbace_go_check_A_const_338.GetRawRoot__O()).Invoke__O(); var arg_3705 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_144); if linked_3702 == nil { tmp66 = ifn_3703.Invoke_O_O__O(arg_3704, arg_3705) } else { tmp66 = linked_3702.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3701, arg_3704, arg_3705) }; return /*line :550:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp18, tmp19, tmp23, tmp24, tmp25, tmp26, tmp30, tmp31, tmp35, tmp36, tmp64, tmp65, tmp66)) }



func A_arbace_go_check_summarize_sum__1685000430_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000430_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000430_A{}; t.Ctor_O(p0); return t }
//line :554:1
func (t *A_arbace_go_check_summarize_sum__1685000430_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :554:1
func (t *A_arbace_go_check_summarize_sum__1685000430_A) Invoke_O_O__O(self, k__1 any) any { var root_3602 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3602, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3604 lang.IFn; if linked_3603 == nil { ifn_3604 = lang.IFn_Cast(root_3602) } else { ifn_3604 = nil }; var arg_3605 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3606 any = A_arbace_go_check_A_const_22; var arg_3607 any; var root_3608 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = k__1; var arg_3612 any = t.F_rs; if linked_3609 == nil { arg_3607 = ifn_3610.Invoke_O_O__O(arg_3611, arg_3612) } else { arg_3607 = linked_3609.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3608, arg_3611, arg_3612) }; if linked_3603 == nil { return ifn_3604.Invoke_O_O_O__O(arg_3605, arg_3606, arg_3607) } else { return linked_3603.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3602, arg_3605, arg_3606, arg_3607) } }
func A_arbace_go_check_summarize_msum__1685000432_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000432_A{}; t.Ctor_O(p0); return t }
//line :555:1
func (t *A_arbace_go_check_summarize_msum__1685000432_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :555:1
func (t *A_arbace_go_check_summarize_msum__1685000432_A) Invoke_O_O__O(self, k__1 any) any { var root_3614 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_3615 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3614, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3616 lang.IFn; if linked_3615 == nil { ifn_3616 = lang.IFn_Cast(root_3614) } else { ifn_3616 = nil }; var arg_3617 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var arg_3618 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3619 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3620 any; var root_3621 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3621, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3623 lang.IFn; if linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any = k__1; var arg_3625 any = t.F_rs; if linked_3622 == nil { arg_3620 = ifn_3623.Invoke_O_O__O(arg_3624, arg_3625) } else { arg_3620 = linked_3622.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3621, arg_3624, arg_3625) }; if linked_3615 == nil { return ifn_3616.Invoke_O_O_O_O__O(arg_3617, arg_3618, arg_3619, arg_3620) } else { return linked_3615.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3614, arg_3617, arg_3618, arg_3619, arg_3620) } }







func A_arbace_go_check_summarize_fn__1685000434_A_New() *A_arbace_go_check_summarize_fn__1685000434_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000434_A{}; t.Ctor(); return t }
//line :563:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Ctor() {}
//line :563:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Invoke_O_O__O(self, p1__1685000424_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_237.Invoke_O__O(p1__1685000424_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000436_A_New() *A_arbace_go_check_summarize_fn__1685000436_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000436_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Ctor() {}
//line :565:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Invoke_O_O__O(self, p1__1685000425_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_310.Invoke_O__O(p1__1685000425_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000425_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000438_A_New() *A_arbace_go_check_summarize_fn__1685000438_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000438_A{}; t.Ctor(); return t }
//line :566:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Ctor() {}
//line :566:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Invoke_O_O__O(self, p1__1685000426_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_310.Invoke_O__O(p1__1685000426_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000426_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_110.Invoke_O__O(p1__1685000426_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000440_A_New() *A_arbace_go_check_summarize_fn__1685000440_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000440_A{}; t.Ctor(); return t }
//line :571:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Ctor() {}
//line :571:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Invoke_O_O__O(self, p1__1685000427_SHARP___1 any) any { var root_3680 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3680, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3682 lang.IFn; if linked_3681 == nil { ifn_3682 = lang.IFn_Cast(root_3680) } else { ifn_3682 = nil }; var arg_3683 any = p1__1685000427_SHARP___1; var arg_3684 any = A_arbace_go_check_A_const_340; if linked_3681 == nil { return ifn_3682.Invoke_O_O__O(arg_3683, arg_3684) } else { return linked_3681.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3680, arg_3683, arg_3684) } }
func A_arbace_go_check_summarize_fn__1685000442_A_New() *A_arbace_go_check_summarize_fn__1685000442_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000442_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_go_check_summarize_fn__1685000442_A) Ctor() {}
//line :572:1
func (t *A_arbace_go_check_summarize_fn__1685000442_A) Invoke_O_O__O(self, p1__1685000428_SHARP___1 any) any { var root_3710 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3710, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3712 lang.IFn; if linked_3711 == nil { ifn_3712 = lang.IFn_Cast(root_3710) } else { ifn_3712 = nil }; var arg_3713 any = p1__1685000428_SHARP___1; var arg_3714 any = A_arbace_go_check_A_const_345; var arg_3715 any = A_arbace_go_check_A_const_22; if linked_3711 == nil { return ifn_3712.Invoke_O_O_O__O(arg_3713, arg_3714, arg_3715) } else { return linked_3711.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3710, arg_3713, arg_3714, arg_3715) } }
func A_arbace_go_check_summarize_fn__1685000444_A_New() *A_arbace_go_check_summarize_fn__1685000444_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000444_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_summarize_fn__1685000444_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_summarize_fn__1685000444_A) Invoke_O_O__O(self, p1__1685000429_SHARP___1 any) any { var root_3691 any = A_arbace_go_check_A_const_343.GetRawRoot__O(); var linked_3692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3691, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3693 lang.IFn; if linked_3692 == nil { ifn_3693 = lang.IFn_Cast(root_3691) } else { ifn_3693 = nil }; var arg_3694 any; var root_3695 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3695, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3697 lang.IFn; if linked_3696 == nil { ifn_3697 = lang.IFn_Cast(root_3695) } else { ifn_3697 = nil }; var arg_3698 any = p1__1685000429_SHARP___1; var arg_3699 any = A_arbace_go_check_A_const_344; if linked_3696 == nil { arg_3694 = ifn_3697.Invoke_O_O__O(arg_3698, arg_3699) } else { arg_3694 = linked_3696.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3695, arg_3698, arg_3699) }; if linked_3692 == nil { return ifn_3693.Invoke_O__O(arg_3694) } else { return linked_3692.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3691, arg_3694) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :576:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_New(); var tmp2 *jrt.Class; var fncls__3802 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class; if


	fncls__3802 == nil { var fncls__3802d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class = fncls__3802d; tmp2 = fncls__3802d } else { tmp2 = fncls__3802 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_New() *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_A{}; t.Ctor(); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A) Ctor() {}
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A) Invoke_O_O__O(self, s__1685000448__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_New_O_O(self, s__1685000448__1); var tmp2 *jrt.Class; var fncls__3801 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class; if fncls__3801 == nil { var fncls__3801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class = fncls__3801d; tmp2 = fncls__3801d } else { tmp2 = fncls__3801 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A{}; t.Ctor_O_O(p0, p1); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A) Ctor_O_O(c__iter__1685000447, c__s__1685000448 any) { t.F_iter__1685000447 = c__iter__1685000447; t.F_s__1685000448 = c__s__1685000448 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A) Invoke_O__O(self any) any { { var s__1685000448__1 any; var t_ any = t.F_s__1685000448; t.F_s__1685000448 = nil; s__1685000448__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3717 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3717, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3719 lang.IFn; if linked_3718 == nil { ifn_3719 = lang.IFn_Cast(root_3717) } else { ifn_3719 = nil }; var arg_3720 any = s__1685000448__1; if linked_3718 == nil { temp__1927000414__auto____2 = ifn_3719.Invoke_O__O(arg_3720) } else { temp__1927000414__auto____2 = linked_3718.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3717, arg_3720) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3721 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3721, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3723 lang.IFn; if linked_3722 == nil { ifn_3723 = lang.IFn_Cast(root_3721) } else { ifn_3723 = nil }; var arg_3724 any = xs__1927001018__auto____3; if linked_3722 == nil { r__4 = ifn_3723.Invoke_O__O(arg_3724) } else { r__4 = linked_3722.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3721, arg_3724) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3783 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class; if fncls__3783 == nil { var fncls__3783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class = fncls__3783d; tmp2 = fncls__3783d } else { tmp2 = fncls__3783 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3784 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3784, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3786 lang.IFn; if linked_3785 == nil { ifn_3786 = lang.IFn_Cast(root_3784) } else { ifn_3786 = nil }; var arg_3787 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_237.Invoke_O__O(r__4)); if linked_3785 == nil { fs__1927001036__auto____6 = ifn_3786.Invoke_O__O(arg_3787) } else { fs__1927001036__auto____6 = linked_3785.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3784, arg_3787) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3788 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var linked_3789 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3788, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3790 lang.IFn; if linked_3789 == nil { ifn_3790 = lang.IFn_Cast(root_3788) } else { ifn_3790 = nil }; var arg_3791 any = fs__1927001036__auto____6; var arg_3792 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000447); var tmp4 any; var root_3793 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3793, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3795 lang.IFn; if linked_3794 == nil { ifn_3795 = lang.IFn_Cast(root_3793) } else { ifn_3795 = nil }; var arg_3796 any = s__1685000448__1; if linked_3794 == nil { tmp4 = ifn_3795.Invoke_O__O(arg_3796) } else { tmp4 = linked_3794.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3793, arg_3796) }; arg_3792 = tmp3.Invoke_O__O(tmp4); if linked_3789 == nil { return ifn_3790.Invoke_O_O__O(arg_3791, arg_3792) } else { return linked_3789.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3788, arg_3791, arg_3792) } } else { var tmp5 any; var root_3797 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3797, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3799 lang.IFn; if linked_3798 == nil { ifn_3799 = lang.IFn_Cast(root_3797) } else { ifn_3799 = nil }; var arg_3800 any = s__1685000448__1; if linked_3798 == nil { tmp5 = ifn_3799.Invoke_O__O(arg_3800) } else { tmp5 = linked_3798.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3797, arg_3800) }; s__1685000448__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A{}; t.Ctor_O(p0); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A) Invoke_O_O__O(self, s__1685000450__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_New_O_O_O(self, t.F_r, s__1685000450__1); var tmp2 *jrt.Class; var fncls__3782 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class; if fncls__3782 == nil { var fncls__3782d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class = fncls__3782d; tmp2 = fncls__3782d } else { tmp2 = fncls__3782 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A) Ctor_O_O_O(c__iter__1685000449, c__r, c__s__1685000450 any) { t.F_iter__1685000449 = c__iter__1685000449; t.F_r = c__r; t.F_s__1685000450 = c__s__1685000450 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A) Invoke_O__O(self any) any { { var s__1685000450__1 any; var t_ any = t.F_s__1685000450; t.F_s__1685000450 = nil; s__1685000450__1 = t_; for { var temp__1927000414__auto____2 any; var root_3725 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3727 lang.IFn; if linked_3726 == nil { ifn_3727 = lang.IFn_Cast(root_3725) } else { ifn_3727 = nil }; var arg_3728 any = s__1685000450__1; if linked_3726 == nil { temp__1927000414__auto____2 = ifn_3727.Invoke_O__O(arg_3728) } else { temp__1927000414__auto____2 = linked_3726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3725, arg_3728) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000450__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3729 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3729, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3731 lang.IFn; if linked_3730 == nil { ifn_3731 = lang.IFn_Cast(root_3729) } else { ifn_3731 = nil }; var arg_3732 any = s__1685000450__3; if linked_3730 == nil { tmp1 = ifn_3731.Invoke_O__O(arg_3732) } else { tmp1 = linked_3730.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3729, arg_3732) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3733 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3733, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3735 lang.IFn; if linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any = s__1685000450__3; if linked_3734 == nil { c__1927001037__auto____4 = ifn_3735.Invoke_O__O(arg_3736) } else { c__1927001037__auto____4 = linked_3734.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3733, arg_3736) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000452__6 any; var root_3737 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3737, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3739 lang.IFn; if linked_3738 == nil { ifn_3739 = lang.IFn_Cast(root_3737) } else { ifn_3739 = nil }; var arg_3740 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3738 == nil { b__1685000452__6 = ifn_3739.Invoke_O__O(arg_3740) } else { b__1685000452__6 = linked_3738.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3737, arg_3740) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000452__6); var tmp3 *jrt.Class; var fncls__3746 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class; if fncls__3746 == nil { var fncls__3746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class = fncls__3746d; tmp3 = fncls__3746d } else { tmp3 = fncls__3746 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3747 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3747, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3749 lang.IFn; if linked_3748 == nil { ifn_3749 = lang.IFn_Cast(root_3747) } else { ifn_3749 = nil }; var arg_3750 any; var root_3752 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3752, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3754 lang.IFn; if linked_3753 == nil { ifn_3754 = lang.IFn_Cast(root_3752) } else { ifn_3754 = nil }; var arg_3755 any = b__1685000452__6; if linked_3753 == nil { arg_3750 = ifn_3754.Invoke_O__O(arg_3755) } else { arg_3750 = linked_3753.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3752, arg_3755) }; var arg_3751 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000449); var tmp5 any; var root_3756 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3756, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3758 lang.IFn; if linked_3757 == nil { ifn_3758 = lang.IFn_Cast(root_3756) } else { ifn_3758 = nil }; var arg_3759 any = s__1685000450__3; if linked_3757 == nil { tmp5 = ifn_3758.Invoke_O__O(arg_3759) } else { tmp5 = linked_3757.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3756, arg_3759) }; arg_3751 = tmp4.Invoke_O__O(tmp5); if linked_3748 == nil { return ifn_3749.Invoke_O_O__O(arg_3750, arg_3751) } else { return linked_3748.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3747, arg_3750, arg_3751) } } else { var root_3760 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3760, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3762 lang.IFn; if linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any; var root_3765 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3765, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3767 lang.IFn; if linked_3766 == nil { ifn_3767 = lang.IFn_Cast(root_3765) } else { ifn_3767 = nil }; var arg_3768 any = b__1685000452__6; if linked_3766 == nil { arg_3763 = ifn_3767.Invoke_O__O(arg_3768) } else { arg_3763 = linked_3766.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3765, arg_3768) }; var arg_3764 any; if linked_3761 == nil { return ifn_3762.Invoke_O_O__O(arg_3763, arg_3764) } else { return linked_3761.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3760, arg_3763, arg_3764) } } } else { var e__4 any; var root_3769 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3771 lang.IFn; if linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any = s__1685000450__3; if linked_3770 == nil { e__4 = ifn_3771.Invoke_O__O(arg_3772) } else { e__4 = linked_3770.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3769, arg_3772) }; var root_3773 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3775 lang.IFn; if linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_311.Invoke_O__O(e__4))).Ref(); var arg_3777 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000449); var tmp7 any; var root_3778 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3780 lang.IFn; if linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any = s__1685000450__3; if linked_3779 == nil { tmp7 = ifn_3780.Invoke_O__O(arg_3781) } else { tmp7 = linked_3779.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3778, arg_3781) }; arg_3777 = tmp6.Invoke_O__O(tmp7); if linked_3774 == nil { return ifn_3775.Invoke_O_O__O(arg_3776, arg_3777) } else { return linked_3774.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3773, arg_3776, arg_3777) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000452 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000452 = c__b__1685000452 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A) Invoke_O__O(self any) any { { var i__1685000451__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000451__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000451__1)); var root_3741 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3741, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3743 lang.IFn; if linked_3742 == nil { ifn_3743 = lang.IFn_Cast(root_3741) } else { ifn_3743 = nil }; var arg_3744 any = t.F_b__1685000452; var arg_3745 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_311.Invoke_O__O(e__2))).Ref(); if linked_3742 == nil { ifn_3743.Invoke_O_O__O(arg_3744, arg_3745) } else { linked_3742.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3741, arg_3744, arg_3745) }; i__1685000451__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000451__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :584:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000465__3 any; var root_3803 any = A_arbace_go_check_A_const_346.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3803, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3805 lang.IFn; if



	linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; var arg_3806 any = forms__0; if linked_3804 == nil { map__1685000465__3 = ifn_3805.Invoke_O__O(arg_3806) } else { map__1685000465__3 = linked_3804.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3803, arg_3806) }; var map__1685000465__4 any; if lang.ISeq_InstanceOf(map__1685000465__3) { var tmp1 any; var root_3807 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = map__1685000465__3; if linked_3808 == nil { tmp1 = ifn_3809.Invoke_O__O(arg_3810) } else { tmp1 = linked_3808.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3807, arg_3810) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3811 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = map__1685000465__3; if linked_3812 == nil { tmp2 = ifn_3813.Invoke_O__O(arg_3814) } else { tmp2 = linked_3812.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3811, arg_3814) }; map__1685000465__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3815 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3817 lang.IFn; if linked_3816 == nil { ifn_3817 = lang.IFn_Cast(root_3815) } else { ifn_3817 = nil }; var arg_3818 any = map__1685000465__3; if linked_3816 == nil { tmp3 = ifn_3817.Invoke_O__O(arg_3818) } else { tmp3 = linked_3816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3815, arg_3818) }; if jrt.J2g_Truth(tmp3) { var root_3819 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3819, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3821 lang.IFn; if linked_3820 == nil { ifn_3821 = lang.IFn_Cast(root_3819) } else { ifn_3821 = nil }; var arg_3822 any = map__1685000465__3; if linked_3820 == nil { map__1685000465__4 = ifn_3821.Invoke_O__O(arg_3822) } else { map__1685000465__4 = linked_3820.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3819, arg_3822) } } else { map__1685000465__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000465__4 = map__1685000465__3 }; var package__5 any = /*line :584:1*/lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_109); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_70); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_124); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_347.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_348; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_111.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_110; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_110.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_118 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_70; var tmp10 any; var root_3829 any = /*line :584:1*/A_arbace_go_check_A_const_349.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3829, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3831 lang.IFn; if





	linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any = name__6; if linked_3830 == nil { tmp10 = ifn_3831.Invoke_O__O(arg_3832) } else { tmp10 = linked_3830.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3829, arg_3832) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_111; var tmp13 any = A_arbace_go_check_A_const_81; var tmp14 any = A_arbace_go_check_A_const_232; var tmp15 any; var root_3833 any = /*line :584:1*/A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3833, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3835 lang.IFn; if






	linked_3834 == nil { ifn_3835 = lang.IFn_Cast(root_3833) } else { ifn_3835 = nil }; var arg_3836 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000467_A_New(); var tmp17 *jrt.Class; var fncls__3850 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000467_A_fn_class; if fncls__3850 == nil { var fncls__3850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_forms_source_fn__1685000467_A_fn_class = fncls__3850d; tmp17 = fncls__3850d } else { tmp17 = fncls__3850 }; arg_3836 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3837 any = forms__0; if linked_3834 == nil { tmp15 = ifn_3835.Invoke_O_O__O(arg_3836, arg_3837) } else { tmp15 = linked_3834.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3833, arg_3836, arg_3837) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_124; var tmp20 any; var root_3851 any = /*line :584:1*/A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_3852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3851, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3853 lang.IFn; if







	linked_3852 == nil { ifn_3853 = lang.IFn_Cast(root_3851) } else { ifn_3853 = nil }; var arg_3854 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_New(); var tmp22 *jrt.Class; var fncls__3925 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class; if fncls__3925 == nil { var fncls__3925d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class = fncls__3925d; tmp22 = fncls__3925d } else { tmp22 = fncls__3925 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3854 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3852 == nil { tmp20 = ifn_3853.Invoke_O__O(arg_3854) } else { tmp20 = linked_3852.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3851, arg_3854) }; return /*line :584:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000467_A_New() *A_arbace_go_check_forms_source_fn__1685000467_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000467_A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_go_check_forms_source_fn__1685000467_A) Ctor() {}
//line :591:1
func (t *A_arbace_go_check_forms_source_fn__1685000467_A) Invoke_O_O__O(self, p1__1685000464_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3838 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3838, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3840 lang.IFn; if linked_3839 == nil { ifn_3840 = lang.IFn_Cast(root_3838) } else { ifn_3840 = nil }; var arg_3841 any = p1__1685000464_SHARP___1; if linked_3839 == nil { and__1927000168__auto____2 = ifn_3840.Invoke_O__O(arg_3841) } else { and__1927000168__auto____2 = linked_3839.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3838, arg_3841) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_350; var tmp3 any; var root_3842 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3842, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3844 lang.IFn; if linked_3843 == nil { ifn_3844 = lang.IFn_Cast(root_3842) } else { ifn_3844 = nil }; var arg_3845 any = p1__1685000464_SHARP___1; if linked_3843 == nil { tmp3 = ifn_3844.Invoke_O__O(arg_3845) } else { tmp3 = linked_3843.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3842, arg_3845) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3846 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_3847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3846, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3848 lang.IFn; if linked_3847 == nil { ifn_3848 = lang.IFn_Cast(root_3846) } else { ifn_3848 = nil }; var arg_3849 any = p1__1685000464_SHARP___1; if linked_3847 == nil { return ifn_3848.Invoke_O__O(arg_3849) } else { return linked_3847.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3846, arg_3849) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_New() *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_A{}; t.Ctor(); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A) Ctor() {}
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A) Invoke_O_O__O(self, s__1685000470__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_New_O_O(self, s__1685000470__1); var tmp2 *jrt.Class; var fncls__3924 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class; if fncls__3924 == nil { var fncls__3924d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class = fncls__3924d; tmp2 = fncls__3924d } else { tmp2 = fncls__3924 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :592:1
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A{}; t.Ctor_O_O(p0, p1); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A) Ctor_O_O(c__iter__1685000469, c__s__1685000470 any) { t.F_iter__1685000469 = c__iter__1685000469; t.F_s__1685000470 = c__s__1685000470 }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A) Invoke_O__O(self any) any { { var s__1685000470__1 any; var t_ any = t.F_s__1685000470; t.F_s__1685000470 = nil; s__1685000470__1 = t_; for { var temp__1927000414__auto____2 any; var root_3855 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3855, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3857 lang.IFn; if linked_3856 == nil { ifn_3857 = lang.IFn_Cast(root_3855) } else { ifn_3857 = nil }; var arg_3858 any = s__1685000470__1; if linked_3856 == nil { temp__1927000414__auto____2 = ifn_3857.Invoke_O__O(arg_3858) } else { temp__1927000414__auto____2 = linked_3856.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3855, arg_3858) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000470__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3859 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3859, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3861 lang.IFn; if linked_3860 == nil { ifn_3861 = lang.IFn_Cast(root_3859) } else { ifn_3861 = nil }; var arg_3862 any = s__1685000470__3; if linked_3860 == nil { tmp1 = ifn_3861.Invoke_O__O(arg_3862) } else { tmp1 = linked_3860.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3859, arg_3862) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3863 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3863, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3865 lang.IFn; if linked_3864 == nil { ifn_3865 = lang.IFn_Cast(root_3863) } else { ifn_3865 = nil }; var arg_3866 any = s__1685000470__3; if linked_3864 == nil { c__1927001037__auto____4 = ifn_3865.Invoke_O__O(arg_3866) } else { c__1927001037__auto____4 = linked_3864.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3863, arg_3866) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000472__6 any; var root_3867 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3867, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3869 lang.IFn; if linked_3868 == nil { ifn_3869 = lang.IFn_Cast(root_3867) } else { ifn_3869 = nil }; var arg_3870 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3868 == nil { b__1685000472__6 = ifn_3869.Invoke_O__O(arg_3870) } else { b__1685000472__6 = linked_3868.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3867, arg_3870) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_New_I_O_O(size__1927001038__auto____5, b__1685000472__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3882 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class; if fncls__3882 == nil { var fncls__3882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class = fncls__3882d; tmp3 = fncls__3882d } else { tmp3 = fncls__3882 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3883 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3883, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3885 lang.IFn; if linked_3884 == nil { ifn_3885 = lang.IFn_Cast(root_3883) } else { ifn_3885 = nil }; var arg_3886 any; var root_3888 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3888, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3890 lang.IFn; if linked_3889 == nil { ifn_3890 = lang.IFn_Cast(root_3888) } else { ifn_3890 = nil }; var arg_3891 any = b__1685000472__6; if linked_3889 == nil { arg_3886 = ifn_3890.Invoke_O__O(arg_3891) } else { arg_3886 = linked_3889.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3888, arg_3891) }; var arg_3887 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000469); var tmp5 any; var root_3892 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3892, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3894 lang.IFn; if linked_3893 == nil { ifn_3894 = lang.IFn_Cast(root_3892) } else { ifn_3894 = nil }; var arg_3895 any = s__1685000470__3; if linked_3893 == nil { tmp5 = ifn_3894.Invoke_O__O(arg_3895) } else { tmp5 = linked_3893.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3892, arg_3895) }; arg_3887 = tmp4.Invoke_O__O(tmp5); if linked_3884 == nil { return ifn_3885.Invoke_O_O__O(arg_3886, arg_3887) } else { return linked_3884.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3883, arg_3886, arg_3887) } } else { var root_3896 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3896, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3898 lang.IFn; if linked_3897 == nil { ifn_3898 = lang.IFn_Cast(root_3896) } else { ifn_3898 = nil }; var arg_3899 any; var root_3901 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3901, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3903 lang.IFn; if linked_3902 == nil { ifn_3903 = lang.IFn_Cast(root_3901) } else { ifn_3903 = nil }; var arg_3904 any = b__1685000472__6; if linked_3902 == nil { arg_3899 = ifn_3903.Invoke_O__O(arg_3904) } else { arg_3899 = linked_3902.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3901, arg_3904) }; var arg_3900 any; if linked_3897 == nil { return ifn_3898.Invoke_O_O__O(arg_3899, arg_3900) } else { return linked_3897.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3896, arg_3899, arg_3900) } } } else { var fi__4 any; var root_3905 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3905, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3907 lang.IFn; if linked_3906 == nil { ifn_3907 = lang.IFn_Cast(root_3905) } else { ifn_3907 = nil }; var arg_3908 any = s__1685000470__3; if linked_3906 == nil { fi__4 = ifn_3907.Invoke_O__O(arg_3908) } else { fi__4 = linked_3906.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3905, arg_3908) }; var root_3909 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3909, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3911 lang.IFn; if linked_3910 == nil { ifn_3911 = lang.IFn_Cast(root_3909) } else { ifn_3911 = nil }; var arg_3912 any; var root_3914 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3914, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3916 lang.IFn; if linked_3915 == nil { ifn_3916 = lang.IFn_Cast(root_3914) } else { ifn_3916 = nil }; var arg_3917 any = fi__4; var arg_3918 any = A_arbace_go_check_A_const_81; var arg_3919 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__4); if linked_3915 == nil { arg_3912 = ifn_3916.Invoke_O_O_O__O(arg_3917, arg_3918, arg_3919) } else { arg_3912 = linked_3915.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3914, arg_3917, arg_3918, arg_3919) }; var arg_3913 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000469); var tmp7 any; var root_3920 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3920, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3922 lang.IFn; if linked_3921 == nil { ifn_3922 = lang.IFn_Cast(root_3920) } else { ifn_3922 = nil }; var arg_3923 any = s__1685000470__3; if linked_3921 == nil { tmp7 = ifn_3922.Invoke_O__O(arg_3923) } else { tmp7 = linked_3921.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3920, arg_3923) }; arg_3913 = tmp6.Invoke_O__O(tmp7); if linked_3910 == nil { return ifn_3911.Invoke_O_O__O(arg_3912, arg_3913) } else { return linked_3910.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3909, arg_3912, arg_3913) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :592:1
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1685000472, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000472 = c__b__1685000472; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A) Invoke_O__O(self any) any { { var i__1685000471__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000471__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000471__1)); var root_3871 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3871, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3873 lang.IFn; if linked_3872 == nil { ifn_3873 = lang.IFn_Cast(root_3871) } else { ifn_3873 = nil }; var arg_3874 any = t.F_b__1685000472; var arg_3875 any; var root_3876 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = fi__2; var arg_3880 any = A_arbace_go_check_A_const_81; var arg_3881 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__2); if linked_3877 == nil { arg_3875 = ifn_3878.Invoke_O_O_O__O(arg_3879, arg_3880, arg_3881) } else { arg_3875 = linked_3877.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3876, arg_3879, arg_3880, arg_3881) }; if linked_3872 == nil { ifn_3873.Invoke_O_O__O(arg_3874, arg_3875) } else { linked_3872.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3871, arg_3874, arg_3875) }; i__1685000471__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000471__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :594:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3935 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3935, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3937 lang.IFn; if




	linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; var arg_3938 any = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_352, jrt.Boolean_FALSE.Ref()); if linked_3936 == nil { ifn_3937.Invoke_O__O(arg_3938) } else { linked_3936.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3935, arg_3938) }; var tmp1 any; tmp3 := /*line :594:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3926 any = A_arbace_go_check_A_const_351.GetRawRoot__O(); var linked_3927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3926, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3928 lang.IFn






		if linked_3927 == nil { ifn_3928 = lang.IFn_Cast(root_3926) } else { ifn_3928 = nil }; var arg_3929 any = r__2; var arg_3930 any = jrt.Boolean_FALSE.Ref(); var arg_3931 any = eof__3; if linked_3927 == nil { f__7 = ifn_3928.Invoke_O_O_O__O(arg_3929, arg_3930, arg_3931) } else { f__7 = linked_3927.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3926, arg_3929, arg_3930, arg_3931) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3944 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3945 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3944, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3946 lang.IFn; if linked_3945 == nil { ifn_3946 = lang.IFn_Cast(root_3944) } else { ifn_3946 = nil }; var arg_3947 any = acc__6; var arg_3948 any = f__7; if linked_3945 == nil { tmp2 = ifn_3946.Invoke_O_O__O(arg_3947, arg_3948) } else { tmp2 = linked_3945.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3944, arg_3947, arg_3948) }; acc__6 = tmp2; continue L1 }
//line :594:1
		break L1 } }; return nil }(); var root_3932 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_3933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3932, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3934 lang.IFn; if




	linked_3933 == nil { ifn_3934 = lang.IFn_Cast(root_3932) } else { ifn_3934 = nil }; if linked_3933 == nil { ifn_3934.Invoke__O() } else { linked_3933.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3932) }; if /*line :594:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :606:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :606:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3949 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3949, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3951 lang.IFn; if


	linked_3950 == nil { ifn_3951 = lang.IFn_Cast(root_3949) } else { ifn_3951 = nil }; var arg_3952 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); if linked_3950 == nil { tmp1 = ifn_3951.Invoke_O__O(arg_3952) } else { tmp1 = linked_3950.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3949, arg_3952) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3953 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3953, A_arbace_go_check_std_session_A_fn_class); var ifn_3955 lang.IFn
		if linked_3954 == nil { ifn_3955 = lang.IFn_Cast(root_3953) } else { ifn_3955 = nil }; var arg_3956 any; var root_3957 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3957, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3959 lang.IFn; if linked_3958 == nil { ifn_3959 = lang.IFn_Cast(root_3957) } else { ifn_3959 = nil }; var arg_3960 any = corpus__0; if linked_3958 == nil { arg_3956 = ifn_3959.Invoke_O__O(arg_3960) } else { arg_3956 = linked_3958.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3957, arg_3960) }; if linked_3954 == nil { s__3 = ifn_3955.Invoke_O__O(arg_3956) } else { s__3 = linked_3954.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3953, arg_3956) }
		var root_3961 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_3962 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3961, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3963 lang.IFn; if linked_3962 == nil { ifn_3963 = lang.IFn_Cast(root_3961) } else { ifn_3963 = nil }; var arg_3964 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); var arg_3965 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var arg_3966 any = corpus__0; var arg_3967 any = s__3; if linked_3962 == nil { ifn_3963.Invoke_O_O_O_O__O(arg_3964, arg_3965, arg_3966, arg_3967) } else { linked_3962.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3961, arg_3964, arg_3965, arg_3966, arg_3967) }
//line :609:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3968 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); var linked_3969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3968, A_arbace_go_check_std_A_fn_class); var ifn_3970 lang.IFn; if




	linked_3969 == nil { ifn_3970 = lang.IFn_Cast(root_3968) } else { ifn_3970 = nil }; var arg_3971 any = corpus__1; if linked_3969 == nil { s__4 = ifn_3970.Invoke_O__O(arg_3971) } else { s__4 = linked_3969.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3968, arg_3971) }; var src__5 any; var root_3972 any = /*line :614:1*/A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_3973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3972, A_arbace_go_check_forms_source_A_fn_class); var ifn_3974 lang.IFn; if





	linked_3973 == nil { ifn_3974 = lang.IFn_Cast(root_3972) } else { ifn_3974 = nil }; var arg_3975 any = forms__0; var arg_3976 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_111; var tmp2 any; var root_3977 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3977, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3979 lang.IFn; if linked_3978 == nil { ifn_3979 = lang.IFn_Cast(root_3977) } else { ifn_3979 = nil }; var arg_3980 any = corpus__1; if linked_3978 == nil { tmp2 = ifn_3979.Invoke_O__O(arg_3980) } else { tmp2 = linked_3978.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3977, arg_3980) }; arg_3976 = tmp1.Invoke_O__O(tmp2); if linked_3973 == nil { src__5 = ifn_3974.Invoke_O_O__O(arg_3975, arg_3976) } else { src__5 = linked_3973.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3972, arg_3975, arg_3976) }; var pkg__6 any; var tmp3 lang.IFn = /*line :614:1*/lang.IFn_Cast(A_arbace_go_check_A_const_276.GetRawRoot__O()); var tmp4 any; var root_3988 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_3989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3988, A_arbace_go_check_resolver_A_fn_class); var ifn_3990 lang.IFn; if






	linked_3989 == nil { ifn_3990 = lang.IFn_Cast(root_3988) } else { ifn_3990 = nil }; var arg_3991 any = s__4; var arg_3992 any = src__5; var arg_3993 any = lang.PersistentVector_EMPTY.Ref(); if linked_3989 == nil { tmp4 = ifn_3990.Invoke_O_O_O__O(arg_3991, arg_3992, arg_3993) } else { tmp4 = linked_3989.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3988, arg_3991, arg_3992, arg_3993) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_108; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_108.Invoke_O__O(opts__2)); var root_3994 any =
	A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = pkg__6; var arg_3998 any = A_arbace_go_check_A_const_236; if linked_3995 == nil { return ifn_3996.Invoke_O_O__O(arg_3997, arg_3998) } else { return linked_3995.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3994, arg_3997, arg_3998) } }
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_3999 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_4000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3999, A_arbace_go_check_check_forms_A_fn_class); var ifn_4001 lang.IFn; if linked_4000 == nil { ifn_4001 = lang.IFn_Cast(root_3999) } else { ifn_4001 = nil }; var arg_4002 any = forms__0; var arg_4003 any = Lit_54; var arg_4004 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4000 == nil { return ifn_4001.Invoke_O_O_O__O(arg_4002, arg_4003, arg_4004) } else { return linked_4000.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_3999, arg_4002, arg_4003, arg_4004)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :630:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_361.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_357.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_4022 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4022, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4024 lang.IFn; if linked_4023 == nil { ifn_4024 = lang.IFn_Cast(root_4022) } else { ifn_4024 = nil }; var arg_4025 any = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_360, s__1927001093__auto____3); if linked_4023 == nil { ifn_4024.Invoke_O__O(arg_4025) } else { linked_4023.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4022, arg_4025) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000483_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__4021 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000483_A_fn_class; if fncls__4021 == nil { var fncls__4021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_go_check_write_edn_fn__1685000483_A_fn_class = fncls__4021d; tmp4 = fncls__4021d } else { tmp4 = fncls__4021 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :632:1
func A_arbace_go_check_write_edn_fn__1685000483_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000483_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000483_A{}; t.Ctor_O_O(p0, p1); return t }
//line :632:1
func (t *A_arbace_go_check_write_edn_fn__1685000483_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :632:1
func (t *A_arbace_go_check_write_edn_fn__1685000483_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4017 any = A_arbace_go_check_A_const_359.GetRawRoot__O(); var linked_4018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4017, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_4019 lang.IFn; if linked_4018 == nil { ifn_4019 = lang.IFn_Cast(root_4017) } else { ifn_4019 = nil }; var arg_4020 any; var t_ any = t.F_x; t.F_x = nil; arg_4020 = t_; if linked_4018 == nil { ifn_4019.Invoke_O__O(arg_4020) } else { linked_4018.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_4017, arg_4020) }; var root_4010 any = A_arbace_go_check_A_const_358.GetRawRoot__O(); var linked_4011 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4010, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4012 lang.IFn; if linked_4011 == nil { ifn_4012 = lang.IFn_Cast(root_4010) } else { ifn_4012 = nil }; var arg_4013 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_4013 = t__2; if linked_4011 == nil { tmp1 = ifn_4012.Invoke_O__O(arg_4013) } else { tmp1 = linked_4011.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4010, arg_4013) } }; return nil }(); var root_4014 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_4015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4014, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4016 lang.IFn; if linked_4015 == nil { ifn_4016 = lang.IFn_Cast(root_4014) } else { ifn_4016 = nil }; if linked_4015 == nil { ifn_4016.Invoke__O() } else { linked_4015.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4014) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }






func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :639:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :639:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any {
	if jrt.J2g_Truth(A_arbace_go_check_A_const_362.Get__O()) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_362.Get__O(), nil, corpus__0, nil)).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil, Lit_129), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil, corpus__0, nil)).Ref()
		} }
func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :644:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000487__1 any) any { var map__1685000488__3 any = p__1685000487__1; var map__1685000488__4 any; if lang.ISeq_InstanceOf(map__1685000488__3) { var tmp1 any; var root_4035 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4035, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4037 lang.IFn; if linked_4036 == nil { ifn_4037 = lang.IFn_Cast(root_4035) } else { ifn_4037 = nil }; var arg_4038 any = map__1685000488__3; if linked_4036 == nil { tmp1 = ifn_4037.Invoke_O__O(arg_4038) } else { tmp1 = linked_4036.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4035, arg_4038) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_4039 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_4040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4039, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4041 lang.IFn; if linked_4040 == nil { ifn_4041 = lang.IFn_Cast(root_4039) } else { ifn_4041 = nil }; var arg_4042 any = map__1685000488__3; if linked_4040 == nil { tmp2 = ifn_4041.Invoke_O__O(arg_4042) } else { tmp2 = linked_4040.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4039, arg_4042) }; map__1685000488__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_4043 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4043, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4045 lang.IFn; if linked_4044 == nil { ifn_4045 = lang.IFn_Cast(root_4043) } else { ifn_4045 = nil }; var arg_4046 any = map__1685000488__3; if linked_4044 == nil { tmp3 = ifn_4045.Invoke_O__O(arg_4046) } else { tmp3 = linked_4044.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4043, arg_4046) }; if jrt.J2g_Truth(tmp3) { var root_4047 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4047, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4049 lang.IFn; if linked_4048 == nil { ifn_4049 = lang.IFn_Cast(root_4047) } else { ifn_4049 = nil }; var arg_4050 any = map__1685000488__3; if linked_4048 == nil { map__1685000488__4 = ifn_4049.Invoke_O__O(arg_4050) } else { map__1685000488__4 = linked_4048.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4047, arg_4050) } } else { map__1685000488__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000488__4 = map__1685000488__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_363); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_364); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_365); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_4051 any = A_arbace_go_check_A_const_366.GetRawRoot__O(); var linked_4052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4051, A_arbace_go_check_check_corpus_A_fn_class); var ifn_4053 lang.IFn; if






	linked_4052 == nil { ifn_4053 = lang.IFn_Cast(root_4051) } else { ifn_4053 = nil }; var arg_4054 any = corpus__0; var arg_4055 any = jobs__5; if linked_4052 == nil { rs__9 = ifn_4053.Invoke_O_O__O(arg_4054, arg_4055) } else { rs__9 = linked_4052.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_4051, arg_4054, arg_4055) }; var sm__10 any; var root_4056 any = /*line :644:1*/A_arbace_go_check_A_const_367.GetRawRoot__O(); var linked_4057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4056, A_arbace_go_check_summarize_A_fn_class); var ifn_4058 lang.IFn; if







	linked_4057 == nil { ifn_4058 = lang.IFn_Cast(root_4056) } else { ifn_4058 = nil }; var arg_4059 any = corpus__0; var arg_4060 any = rs__9; if linked_4057 == nil { sm__10 = ifn_4058.Invoke_O_O__O(arg_4059, arg_4060) } else { sm__10 = linked_4057.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_4056, arg_4059, arg_4060) }; var secs__11 float64 = /*line :644:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_368; var tmp5 any; var root_4061 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4061, A_arbace_go_check_reference_path_A_fn_class); var ifn_4063 lang.IFn; if









	linked_4062 == nil { ifn_4063 = lang.IFn_Cast(root_4061) } else { ifn_4063 = nil }; var arg_4064 any = corpus__0; if linked_4062 == nil { tmp5 = ifn_4063.Invoke_O__O(arg_4064) } else { tmp5 = linked_4062.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4061, arg_4064) }; ref_file__12 = /*line :644:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var r__13 any; var root_4065 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4065, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_4067 lang.IFn
		if linked_4066 == nil { ifn_4067 = lang.IFn_Cast(root_4065) } else { ifn_4067 = nil }; var arg_4068 any = lang.IFn_Cast(A_arbace_go_check_A_const_371.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_4066 == nil { r__13 = ifn_4067.Invoke_O__O(arg_4068) } else { r__13 = linked_4066.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_4065, arg_4068) }; if jrt.J2g_Truth(A_arbace_go_check_A_const_362.Get__O()) { var root_4073 any = A_arbace_go_check_A_const_256.GetRawRoot__O(); var linked_4074 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4073, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4075 lang.IFn; if linked_4074 == nil { ifn_4075 = lang.IFn_Cast(root_4073) } else { ifn_4075 = nil }; var arg_4076 any = A_arbace_go_check_A_const_372.Invoke_O__O(r__13); var arg_4077 any = A_arbace_go_check_A_const_336; if linked_4074 == nil { ref__13 = ifn_4075.Invoke_O_O__O(arg_4076, arg_4077) } else { ref__13 = linked_4074.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4073, arg_4076, arg_4077) } } else { ref__13 = r__13 } } else {
//line :655:1
			ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_4078 any = /*line :644:1*/A_arbace_go_check_A_const_237.Invoke_O__O(sm__10); if












	jrt.Long_InstanceOf(na_4078) { var n0_4079 int64 = jrt.NN(jrt.Long_Cast(na_4078)).LongValue__J(); and__1927000168__auto____14 = n0_4079 == 0 } else { if jrt.Double_InstanceOf(na_4078) { var n0_4079_2 float64 = jrt.NN(jrt.Double_Cast(na_4078)).DoubleValue__D(); and__1927000168__auto____14 = n0_4079_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_4078) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_4080 any = A_arbace_go_check_A_const_334.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_4080) { var n0_4081 int64 = jrt.NN(jrt.Long_Cast(na_4080)).LongValue__J(); and__1927000168__auto____15 = n0_4081 == 0 } else { if jrt.Double_InstanceOf(na_4080) { var n0_4081_2 float64 = jrt.NN(jrt.Double_Cast(na_4080)).DoubleValue__D(); and__1927000168__auto____15 = n0_4081_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_4080) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_4082 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_4083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4082, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4084 lang.IFn; if linked_4083 == nil { ifn_4084 = lang.IFn_Cast(root_4082) } else { ifn_4084 = nil }; var arg_4085 any; var root_4086 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4086, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4088 lang.IFn; if linked_4087 == nil { ifn_4088 = lang.IFn_Cast(root_4086) } else { ifn_4088 = nil }; var arg_4089 any = sm__10; var arg_4090 any = A_arbace_go_check_A_const_373; if linked_4087 == nil { arg_4085 = ifn_4088.Invoke_O_O__O(arg_4089, arg_4090) } else { arg_4085 = linked_4087.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4086, arg_4089, arg_4090) }; if linked_4083 == nil { and__1927000168__auto____16 = ifn_4084.Invoke_O__O(arg_4085) } else { and__1927000168__auto____16 = linked_4083.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4082, arg_4085) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_4091 any; var root_4092 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4092, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4094 lang.IFn
		if linked_4093 == nil { ifn_4094 = lang.IFn_Cast(root_4092) } else { ifn_4094 = nil }; var arg_4095 any = sm__10; var arg_4096 any = A_arbace_go_check_A_const_374; if linked_4093 == nil { na_4091 = ifn_4094.Invoke_O_O__O(arg_4095, arg_4096) } else { na_4091 = linked_4093.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4092, arg_4095, arg_4096) }; if jrt.Long_InstanceOf(na_4091) { var n0_4097 int64 = jrt.NN(jrt.Long_Cast(na_4091)).LongValue__J(); and__1927000168__auto____17 = n0_4097 == 0 } else { if jrt.Double_InstanceOf(na_4091) { var n0_4097_2 float64 = jrt.NN(jrt.Double_Cast(na_4091)).DoubleValue__D(); and__1927000168__auto____17 = n0_4097_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_4091) } }
//line :657:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_4098 any; var root_4099 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4099, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4101 lang.IFn; if linked_4100 == nil { ifn_4101 = lang.IFn_Cast(root_4099) } else { ifn_4101 = nil }; var arg_4102 any = sm__10; var arg_4103 any = A_arbace_go_check_A_const_375; if linked_4100 == nil { na_4098 = ifn_4101.Invoke_O_O__O(arg_4102, arg_4103) } else { na_4098 = linked_4100.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4099, arg_4102, arg_4103) }; if jrt.Long_InstanceOf(na_4098) { var n0_4104 int64 = jrt.NN(jrt.Long_Cast(na_4098)).LongValue__J(); tmp6 = n0_4104 == 0 } else { if jrt.Double_InstanceOf(na_4098) { var n0_4104_2 float64 = jrt.NN(jrt.Double_Cast(na_4098)).DoubleValue__D(); tmp6 = n0_4104_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_4098) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :657:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_4105 any = /*line :644:1*/A_arbace_go_check_A_const_256.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4105, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4107 lang.IFn; if















	linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any = ref__13; var arg_4109 any = A_arbace_go_check_A_const_376; if linked_4106 == nil { tmp7 = ifn_4107.Invoke_O_O__O(arg_4108, arg_4109) } else { tmp7 = linked_4106.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4105, arg_4108, arg_4109) }; var tmp8 any = tmp7; var tmp9 any; var root_4110 any = A_arbace_go_check_A_const_256.GetRawRoot__O(); var linked_4111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4110, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4112 lang.IFn; if linked_4111 == nil { ifn_4112 = lang.IFn_Cast(root_4110) } else { ifn_4112 = nil }; var arg_4113 any = sm__10; var arg_4114 any = A_arbace_go_check_A_const_336; if linked_4111 == nil { tmp9 = ifn_4112.Invoke_O_O__O(arg_4113, arg_4114) } else { tmp9 = linked_4111.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4110, arg_4113, arg_4114) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_4123 any =
	A_arbace_go_check_A_const_377.GetRawRoot__O(); var linked_4124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4123, A_arbace_go_check_write_edn_A_fn_class); var ifn_4125 lang.IFn; if linked_4124 == nil { ifn_4125 = lang.IFn_Cast(root_4123) } else { ifn_4125 = nil }; var arg_4126 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_4127 any; var tmp10 any = A_arbace_go_check_A_const_372; var tmp11 any = A_arbace_go_check_A_const_378; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_237; var tmp14 any; var root_4128 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_4129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4128, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4130 lang.IFn; if

	linked_4129 == nil { ifn_4130 = lang.IFn_Cast(root_4128) } else { ifn_4130 = nil }; var arg_4131 any; var root_4132 any = A_arbace_go_check_A_const_379.GetRawRoot__O(); var linked_4133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4132, A_arbace_go_check_report_errors_A_fn_class); var ifn_4134 lang.IFn; if linked_4133 == nil { ifn_4134 = lang.IFn_Cast(root_4132) } else { ifn_4134 = nil }; var arg_4135 any = rs__9; if linked_4133 == nil { arg_4131 = ifn_4134.Invoke_O__O(arg_4135) } else { arg_4131 = linked_4133.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4132, arg_4135) }; if linked_4129 == nil { tmp14 = ifn_4130.Invoke_O__O(arg_4131) } else { tmp14 = linked_4129.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4128, arg_4131) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_165; var tmp17 any; var root_4136 any = /*line :661:1*/A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_4137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4136, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4138 lang.IFn; if


	linked_4137 == nil { ifn_4138 = lang.IFn_Cast(root_4136) } else { ifn_4138 = nil }; var arg_4139 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_A_New(); var tmp19 *jrt.Class; var fncls__4225 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class; if fncls__4225 == nil { var fncls__4225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class = fncls__4225d; tmp19 = fncls__4225d } else { tmp19 = fncls__4225 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_4139 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_4137 == nil { tmp17 = ifn_4138.Invoke_O__O(arg_4139) } else { tmp17 = linked_4137.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4136, arg_4139) }; arg_4127 = /*line :661:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_4124 == nil { ifn_4125.Invoke_O_O__O(arg_4126, arg_4127) } else { linked_4124.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4123, arg_4126, arg_4127) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_234.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_330.Invoke_O__O(sm__10); var tmp23 any; var root_4244 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4244, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4246 lang.IFn; if
	linked_4245 == nil { ifn_4246 = lang.IFn_Cast(root_4244) } else { ifn_4246 = nil }; var arg_4247 any = sm__10; var arg_4248 any = A_arbace_go_check_A_const_381; if linked_4245 == nil { tmp23 = ifn_4246.Invoke_O_O__O(arg_4247, arg_4248) } else { tmp23 = linked_4245.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4244, arg_4247, arg_4248) }; var tmp24 any = tmp23; var tmp25 any; var root_4249 any = /*line :665:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4249, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4251 lang.IFn; if
	linked_4250 == nil { ifn_4251 = lang.IFn_Cast(root_4249) } else { ifn_4251 = nil }; var arg_4252 any = sm__10; var arg_4253 any = A_arbace_go_check_A_const_382; if linked_4250 == nil { tmp25 = ifn_4251.Invoke_O_O__O(arg_4252, arg_4253) } else { tmp25 = linked_4250.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4249, arg_4252, arg_4253) }; var tmp26 any = tmp25; var tmp27 any; var root_4254 any = /*line :665:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4254, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4256 lang.IFn; if

	linked_4255 == nil { ifn_4256 = lang.IFn_Cast(root_4254) } else { ifn_4256 = nil }; var arg_4257 any = sm__10; var arg_4258 any = A_arbace_go_check_A_const_383; if linked_4255 == nil { tmp27 = ifn_4256.Invoke_O_O__O(arg_4257, arg_4258) } else { tmp27 = linked_4255.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4254, arg_4257, arg_4258) }; var tmp28 any = tmp27; var tmp29 any = /*line :665:1*/A_arbace_go_check_A_const_237.Invoke_O__O(sm__10); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()); var tmp31 any; var root_4263 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4263, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4265 lang.IFn; if


	linked_4264 == nil { ifn_4265 = lang.IFn_Cast(root_4263) } else { ifn_4265 = nil }; var arg_4266 any = sm__10; var arg_4267 any = A_arbace_go_check_A_const_384; if linked_4264 == nil { tmp31 = ifn_4265.Invoke_O_O__O(arg_4266, arg_4267) } else { tmp31 = linked_4264.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4263, arg_4266, arg_4267) }; var tmp32 any = /*line :665:1*/tmp30.Invoke_O__O(tmp31); var tmp33 any; var root_4268 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4268, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4270 lang.IFn; if



	linked_4269 == nil { ifn_4270 = lang.IFn_Cast(root_4268) } else { ifn_4270 = nil }; var arg_4271 any = sm__10; var arg_4272 any = A_arbace_go_check_A_const_385; if linked_4269 == nil { tmp33 = ifn_4270.Invoke_O_O__O(arg_4271, arg_4272) } else { tmp33 = linked_4269.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4268, arg_4271, arg_4272) }; var tmp34 any = tmp33; var tmp35 any; var root_4273 any = /*line :665:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4273, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4275 lang.IFn; if



	linked_4274 == nil { ifn_4275 = lang.IFn_Cast(root_4273) } else { ifn_4275 = nil }; var arg_4276 any = sm__10; var arg_4277 any = A_arbace_go_check_A_const_386; if linked_4274 == nil { tmp35 = ifn_4275.Invoke_O_O__O(arg_4276, arg_4277) } else { tmp35 = linked_4274.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4273, arg_4276, arg_4277) }; /*line :665:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_17, corpus__0, tmp22, tmp24, tmp26, tmp28, tmp29, tmp32, tmp34, tmp35, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000506__16 any; var root_4278 any = /*line :644:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4280 lang.IFn; if

























	linked_4279 == nil { ifn_4280 = lang.IFn_Cast(root_4278) } else { ifn_4280 = nil }; var arg_4281 any; var root_4282 any = A_arbace_go_check_A_const_387.GetRawRoot__O(); var linked_4283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4282, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4284 lang.IFn; if linked_4283 == nil { ifn_4284 = lang.IFn_Cast(root_4282) } else { ifn_4284 = nil }; var arg_4285 any = A_arbace_go_check_A_const_388; var arg_4286 any; var root_4287 any = A_arbace_go_check_A_const_379.GetRawRoot__O(); var linked_4288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4287, A_arbace_go_check_report_errors_A_fn_class); var ifn_4289 lang.IFn; if linked_4288 == nil { ifn_4289 = lang.IFn_Cast(root_4287) } else { ifn_4289 = nil }; var arg_4290 any = rs__9; if linked_4288 == nil { arg_4286 = ifn_4289.Invoke_O__O(arg_4290) } else { arg_4286 = linked_4288.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4287, arg_4290) }; if linked_4283 == nil { arg_4281 = ifn_4284.Invoke_O_O__O(arg_4285, arg_4286) } else { arg_4281 = linked_4283.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4282, arg_4285, arg_4286) }; if linked_4279 == nil { seq_1685000506__16 = ifn_4280.Invoke_O__O(arg_4281) } else { seq_1685000506__16 = linked_4279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4278, arg_4281) }; var chunk_1685000507__17 any; var count_1685000508__18 int64 = 0; var i_1685000509__19 int64 = 0; L1:
//line :644:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000509__19, count_1685000508__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000507__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000509__19)); lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__20); seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000509__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_4291 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4291, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4293 lang.IFn; if linked_4292 == nil { ifn_4293 = lang.IFn_Cast(root_4291) } else { ifn_4293 = nil }; var arg_4294 any = seq_1685000506__16; if linked_4292 == nil { temp__1927000414__auto____20 = ifn_4293.Invoke_O__O(arg_4294) } else { temp__1927000414__auto____20 = linked_4292.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4291, arg_4294) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000506__21 any = temp__1927000414__auto____20; var tmp36 any; var root_4295 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4295, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4297 lang.IFn; if linked_4296 == nil { ifn_4297 = lang.IFn_Cast(root_4295) } else { ifn_4297 = nil }; var arg_4298 any = seq_1685000506__21; if linked_4296 == nil { tmp36 = ifn_4297.Invoke_O__O(arg_4298) } else { tmp36 = linked_4296.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4295, arg_4298) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____22 any; var root_4299 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4299, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4301 lang.IFn; if linked_4300 == nil { ifn_4301 = lang.IFn_Cast(root_4299) } else { ifn_4301 = nil }; var arg_4302 any = seq_1685000506__21; if linked_4300 == nil { c__1927000678__auto____22 = ifn_4301.Invoke_O__O(arg_4302) } else { c__1927000678__auto____22 = linked_4300.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4299, arg_4302) }; var tmp37 any; var root_4348 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4348, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4350 lang.IFn; if linked_4349 == nil { ifn_4350 = lang.IFn_Cast(root_4348) } else { ifn_4350 = nil }; var arg_4351 any = seq_1685000506__21; if linked_4349 == nil { tmp37 = ifn_4350.Invoke_O__O(arg_4351) } else { tmp37 = linked_4349.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4348, arg_4351) }; seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = tmp37, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_4303 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4303, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4305 lang.IFn; if linked_4304 == nil { ifn_4305 = lang.IFn_Cast(root_4303) } else { ifn_4305 = nil }; var arg_4306 any = seq_1685000506__21; if linked_4304 == nil { l__22 = ifn_4305.Invoke_O__O(arg_4306) } else { l__22 = linked_4304.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4303, arg_4306) }; lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__22); var tmp38 any; var root_4357 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4357, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4359 lang.IFn; if linked_4358 == nil { ifn_4359 = lang.IFn_Cast(root_4357) } else { ifn_4359 = nil }; var arg_4360 any = seq_1685000506__21; if linked_4358 == nil { tmp38 = ifn_4359.Invoke_O__O(arg_4360) } else { tmp38 = linked_4358.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4357, arg_4360) }; seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = tmp38, nil, 0, 0; continue L1 } } }
//line :644:1
		break L1 }; var tmp39 any; var root_4307 any =


























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4307, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4309 lang.IFn; if linked_4308 == nil { ifn_4309 = lang.IFn_Cast(root_4307) } else { ifn_4309 = nil }; var arg_4310 any; var root_4311 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4311, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4313 lang.IFn; if linked_4312 == nil { ifn_4313 = lang.IFn_Cast(root_4311) } else { ifn_4313 = nil }; var arg_4314 any = sm__10; var arg_4315 any = A_arbace_go_check_A_const_389; if linked_4312 == nil { arg_4310 = ifn_4313.Invoke_O_O__O(arg_4314, arg_4315) } else { arg_4310 = linked_4312.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4311, arg_4314, arg_4315) }; if linked_4308 == nil { tmp39 = ifn_4309.Invoke_O__O(arg_4310) } else { tmp39 = linked_4308.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4307, arg_4310) }; if jrt.J2g_Truth(tmp39) {
		var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()); var tmp42 any; var root_4325 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4325, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4327 lang.IFn; if linked_4326 == nil { ifn_4327 = lang.IFn_Cast(root_4325) } else { ifn_4327 = nil }; var arg_4328 any = sm__10; var arg_4329 any = A_arbace_go_check_A_const_390; if linked_4326 == nil { tmp42 = ifn_4327.Invoke_O_O__O(arg_4328, arg_4329) } else { tmp42 = linked_4326.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4325, arg_4328, arg_4329) }; tmp40.Invoke_O_O__O(Lit_19, tmp41.Invoke_O__O(tmp42)) }; var tmp43 any; var root_4330 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4332 lang.IFn; if linked_4331 == nil { ifn_4332 = lang.IFn_Cast(root_4330) } else { ifn_4332 = nil }; var arg_4333 any = A_arbace_go_check_A_const_144.Invoke_O__O(sm__10); if linked_4331 == nil { tmp43 = ifn_4332.Invoke_O__O(arg_4333) } else { tmp43 = linked_4331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4330, arg_4333) }; if jrt.J2g_Truth(tmp43) {
		lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()).Invoke_O_O__O(Lit_20, lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_144.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_4361 any = A_arbace_go_check_A_const_377.GetRawRoot__O(); var linked_4362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4361, A_arbace_go_check_write_edn_A_fn_class); var ifn_4363 lang.IFn; if linked_4362 == nil { ifn_4363 = lang.IFn_Cast(root_4361) } else { ifn_4363 = nil }; var arg_4364 any; var root_4366 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4366, A_arbace_go_check_reference_path_A_fn_class); var ifn_4368 lang.IFn; if linked_4367 == nil { ifn_4368 = lang.IFn_Cast(root_4366) } else { ifn_4368 = nil }; var arg_4369 any = corpus__0; if linked_4367 == nil { arg_4364 = ifn_4368.Invoke_O__O(arg_4369) } else { arg_4364 = linked_4367.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4366, arg_4369) }; var arg_4365 any; var root_4370 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4370, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4372 lang.IFn; if linked_4371 == nil { ifn_4372 = lang.IFn_Cast(root_4370) } else { ifn_4372 = nil }; var arg_4373 any; var root_4376 any = A_arbace_go_check_A_const_256.GetRawRoot__O(); var linked_4377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4376, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4378 lang.IFn; if linked_4377 == nil { ifn_4378 = lang.IFn_Cast(root_4376) } else { ifn_4378 = nil }; var arg_4379 any = sm__10; var arg_4380 any = A_arbace_go_check_A_const_336; if linked_4377 == nil { arg_4373 = ifn_4378.Invoke_O_O__O(arg_4379, arg_4380) } else { arg_4373 = linked_4377.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4376, arg_4379, arg_4380) }; var arg_4374 any = A_arbace_go_check_A_const_376; var arg_4375 any = Lit_21; if linked_4371 == nil { arg_4365 = ifn_4372.Invoke_O_O_O__O(arg_4373, arg_4374, arg_4375) } else { arg_4365 = linked_4371.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4370, arg_4373, arg_4374, arg_4375) }; if linked_4362 == nil { ifn_4363.Invoke_O_O__O(arg_4364, arg_4365) } else { linked_4362.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4361, arg_4364, arg_4365) }
		var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp45 any; var root_4386 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4386, A_arbace_go_check_reference_path_A_fn_class); var ifn_4388 lang.IFn; if linked_4387 == nil { ifn_4388 = lang.IFn_Cast(root_4386) } else { ifn_4388 = nil }; var arg_4389 any = corpus__0; if linked_4387 == nil { tmp45 = ifn_4388.Invoke_O__O(arg_4389) } else { tmp45 = linked_4387.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4386, arg_4389) }; tmp44.Invoke_O_O__O(Lit_22, tmp45)
//line :675:1
		return clean__14 } else { var tmp46 any; var root_4115 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4115, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4117 lang.IFn



			if linked_4116 == nil { ifn_4117 = lang.IFn_Cast(root_4115) } else { ifn_4117 = nil }; var arg_4118 any = clean__14; if linked_4116 == nil { tmp46 = ifn_4117.Invoke_O__O(arg_4118) } else { tmp46 = linked_4116.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4115, arg_4118) }
//line :675:1
			if jrt.J2g_Truth(tmp46) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp48 any; var root_4396 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4396, A_arbace_go_check_reference_path_A_fn_class); var ifn_4398 lang.IFn; if linked_4397 == nil { ifn_4398 = lang.IFn_Cast(root_4396) } else { ifn_4398 = nil }; var arg_4399 any = corpus__0; if linked_4397 == nil { tmp48 = ifn_4398.Invoke_O__O(arg_4399) } else { tmp48 = linked_4397.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4396, arg_4399) }; tmp47.Invoke_O_O_O__O(Lit_23, tmp48, Lit_24)
//line :675:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp49 any; var root_4119 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4119, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4121 lang.IFn





					if linked_4120 == nil { ifn_4121 = lang.IFn_Cast(root_4119) } else { ifn_4121 = nil }; var arg_4122 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_4120 == nil { tmp49 = ifn_4121.Invoke_O__O(arg_4122) } else { tmp49 = linked_4120.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4119, arg_4122) }
//line :675:1
					if jrt.J2g_Truth(tmp49) {





						var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp51 any; var root_4406 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4406, A_arbace_go_check_reference_path_A_fn_class); var ifn_4408 lang.IFn; if linked_4407 == nil { ifn_4408 = lang.IFn_Cast(root_4406) } else { ifn_4408 = nil }; var arg_4409 any = corpus__0; if linked_4407 == nil { tmp51 = ifn_4408.Invoke_O__O(arg_4409) } else { tmp51 = linked_4407.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4406, arg_4409) }; tmp50.Invoke_O_O_O__O(Lit_25, tmp51, Lit_26)
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()); var tmp54 any; var root_4419 any = A_arbace_go_check_A_const_256.GetRawRoot__O(); var linked_4420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4419, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4421 lang.IFn; if linked_4420 == nil { ifn_4421 = lang.IFn_Cast(root_4419) } else { ifn_4421 = nil }; var arg_4422 any = ref__13; var arg_4423 any = A_arbace_go_check_A_const_376; if linked_4420 == nil { tmp54 = ifn_4421.Invoke_O_O__O(arg_4422, arg_4423) } else { tmp54 = linked_4420.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4419, arg_4422, arg_4423) }; tmp52.Invoke_O_O__O(Lit_27, tmp53.Invoke_O__O(tmp54))
						var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()); var tmp57 any; var root_4433 any = A_arbace_go_check_A_const_256.GetRawRoot__O(); var linked_4434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4433, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4435 lang.IFn; if linked_4434 == nil { ifn_4435 = lang.IFn_Cast(root_4433) } else { ifn_4435 = nil }; var arg_4436 any = sm__10; var arg_4437 any = A_arbace_go_check_A_const_336; if linked_4434 == nil { tmp57 = ifn_4435.Invoke_O_O__O(arg_4436, arg_4437) } else { tmp57 = linked_4434.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4433, arg_4436, arg_4437) }; tmp55.Invoke_O_O__O(Lit_28, tmp56.Invoke_O__O(tmp57))
//line :675:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_A_New() *A_arbace_go_check_annotations_iter__1685000490__1685000496_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_A) Ctor() {}
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_A) Invoke_O_O__O(self, s__1685000491__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_New_O_O(s__1685000491__1, self); var tmp2 *jrt.Class; var fncls__4224 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class; if fncls__4224 == nil { var fncls__4224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class = fncls__4224d; tmp2 = fncls__4224d } else { tmp2 = fncls__4224 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A{}; t.Ctor_O_O(p0, p1); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A) Ctor_O_O(c__s__1685000491, c__iter__1685000490 any) { t.F_s__1685000491 = c__s__1685000491; t.F_iter__1685000490 = c__iter__1685000490 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A) Invoke_O__O(self any) any { { var s__1685000491__1 any; var t_ any = t.F_s__1685000491; t.F_s__1685000491 = nil; s__1685000491__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4140 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4140, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4142 lang.IFn; if linked_4141 == nil { ifn_4142 = lang.IFn_Cast(root_4140) } else { ifn_4142 = nil }; var arg_4143 any = s__1685000491__1; if linked_4141 == nil { temp__1927000414__auto____2 = ifn_4142.Invoke_O__O(arg_4143) } else { temp__1927000414__auto____2 = linked_4141.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4140, arg_4143) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_4144 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4144, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4146 lang.IFn; if linked_4145 == nil { ifn_4146 = lang.IFn_Cast(root_4144) } else { ifn_4146 = nil }; var arg_4147 any = xs__1927001018__auto____3; if linked_4145 == nil { r__4 = ifn_4146.Invoke_O__O(arg_4147) } else { r__4 = linked_4145.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4144, arg_4147) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__4206 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class; if fncls__4206 == nil { var fncls__4206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class = fncls__4206d; tmp2 = fncls__4206d } else { tmp2 = fncls__4206 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_4207 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4207, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4209 lang.IFn; if linked_4208 == nil { ifn_4209 = lang.IFn_Cast(root_4207) } else { ifn_4209 = nil }; var arg_4210 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_166.Invoke_O__O(r__4)); if linked_4208 == nil { fs__1927001036__auto____6 = ifn_4209.Invoke_O__O(arg_4210) } else { fs__1927001036__auto____6 = linked_4208.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4207, arg_4210) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_4211 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var linked_4212 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4211, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4213 lang.IFn; if linked_4212 == nil { ifn_4213 = lang.IFn_Cast(root_4211) } else { ifn_4213 = nil }; var arg_4214 any = fs__1927001036__auto____6; var arg_4215 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000490); var tmp4 any; var root_4216 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4216, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4218 lang.IFn; if linked_4217 == nil { ifn_4218 = lang.IFn_Cast(root_4216) } else { ifn_4218 = nil }; var arg_4219 any = s__1685000491__1; if linked_4217 == nil { tmp4 = ifn_4218.Invoke_O__O(arg_4219) } else { tmp4 = linked_4217.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4216, arg_4219) }; arg_4215 = tmp3.Invoke_O__O(tmp4); if linked_4212 == nil { return ifn_4213.Invoke_O_O__O(arg_4214, arg_4215) } else { return linked_4212.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4211, arg_4214, arg_4215) } } else { var tmp5 any; var root_4220 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4220, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4222 lang.IFn; if linked_4221 == nil { ifn_4222 = lang.IFn_Cast(root_4220) } else { ifn_4222 = nil }; var arg_4223 any = s__1685000491__1; if linked_4221 == nil { tmp5 = ifn_4222.Invoke_O__O(arg_4223) } else { tmp5 = linked_4221.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4220, arg_4223) }; s__1685000491__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A{}; t.Ctor_O(p0); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A) Invoke_O_O__O(self, s__1685000493__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_New_O_O_O(t.F_r, s__1685000493__1, self); var tmp2 *jrt.Class; var fncls__4205 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class; if fncls__4205 == nil { var fncls__4205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class = fncls__4205d; tmp2 = fncls__4205d } else { tmp2 = fncls__4205 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A) Ctor_O_O_O(c__r, c__s__1685000493, c__iter__1685000492 any) { t.F_r = c__r; t.F_s__1685000493 = c__s__1685000493; t.F_iter__1685000492 = c__iter__1685000492 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A) Invoke_O__O(self any) any { { var s__1685000493__1 any; var t_ any = t.F_s__1685000493; t.F_s__1685000493 = nil; s__1685000493__1 = t_; for { var temp__1927000414__auto____2 any; var root_4148 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4148, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4150 lang.IFn; if linked_4149 == nil { ifn_4150 = lang.IFn_Cast(root_4148) } else { ifn_4150 = nil }; var arg_4151 any = s__1685000493__1; if linked_4149 == nil { temp__1927000414__auto____2 = ifn_4150.Invoke_O__O(arg_4151) } else { temp__1927000414__auto____2 = linked_4149.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4148, arg_4151) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000493__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4152 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4152, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4154 lang.IFn; if linked_4153 == nil { ifn_4154 = lang.IFn_Cast(root_4152) } else { ifn_4154 = nil }; var arg_4155 any = s__1685000493__3; if linked_4153 == nil { tmp1 = ifn_4154.Invoke_O__O(arg_4155) } else { tmp1 = linked_4153.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4152, arg_4155) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4156 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4156, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4158 lang.IFn; if linked_4157 == nil { ifn_4158 = lang.IFn_Cast(root_4156) } else { ifn_4158 = nil }; var arg_4159 any = s__1685000493__3; if linked_4157 == nil { c__1927001037__auto____4 = ifn_4158.Invoke_O__O(arg_4159) } else { c__1927001037__auto____4 = linked_4157.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4156, arg_4159) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000495__6 any; var root_4160 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_4161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4160, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4162 lang.IFn; if linked_4161 == nil { ifn_4162 = lang.IFn_Cast(root_4160) } else { ifn_4162 = nil }; var arg_4163 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4161 == nil { b__1685000495__6 = ifn_4162.Invoke_O__O(arg_4163) } else { b__1685000495__6 = linked_4161.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4160, arg_4163) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000495__6); var tmp3 *jrt.Class; var fncls__4169 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class; if fncls__4169 == nil { var fncls__4169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class = fncls__4169d; tmp3 = fncls__4169d } else { tmp3 = fncls__4169 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4170 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4170, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4172 lang.IFn; if linked_4171 == nil { ifn_4172 = lang.IFn_Cast(root_4170) } else { ifn_4172 = nil }; var arg_4173 any; var root_4175 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4175, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4177 lang.IFn; if linked_4176 == nil { ifn_4177 = lang.IFn_Cast(root_4175) } else { ifn_4177 = nil }; var arg_4178 any = b__1685000495__6; if linked_4176 == nil { arg_4173 = ifn_4177.Invoke_O__O(arg_4178) } else { arg_4173 = linked_4176.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4175, arg_4178) }; var arg_4174 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000492); var tmp5 any; var root_4179 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4179, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4181 lang.IFn; if linked_4180 == nil { ifn_4181 = lang.IFn_Cast(root_4179) } else { ifn_4181 = nil }; var arg_4182 any = s__1685000493__3; if linked_4180 == nil { tmp5 = ifn_4181.Invoke_O__O(arg_4182) } else { tmp5 = linked_4180.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4179, arg_4182) }; arg_4174 = tmp4.Invoke_O__O(tmp5); if linked_4171 == nil { return ifn_4172.Invoke_O_O__O(arg_4173, arg_4174) } else { return linked_4171.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4170, arg_4173, arg_4174) } } else { var root_4183 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4183, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4185 lang.IFn; if linked_4184 == nil { ifn_4185 = lang.IFn_Cast(root_4183) } else { ifn_4185 = nil }; var arg_4186 any; var root_4188 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4188, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4190 lang.IFn; if linked_4189 == nil { ifn_4190 = lang.IFn_Cast(root_4188) } else { ifn_4190 = nil }; var arg_4191 any = b__1685000495__6; if linked_4189 == nil { arg_4186 = ifn_4190.Invoke_O__O(arg_4191) } else { arg_4186 = linked_4189.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4188, arg_4191) }; var arg_4187 any; if linked_4184 == nil { return ifn_4185.Invoke_O_O__O(arg_4186, arg_4187) } else { return linked_4184.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4183, arg_4186, arg_4187) } } } else { var u__4 any; var root_4192 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4192, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4194 lang.IFn; if linked_4193 == nil { ifn_4194 = lang.IFn_Cast(root_4192) } else { ifn_4194 = nil }; var arg_4195 any = s__1685000493__3; if linked_4193 == nil { u__4 = ifn_4194.Invoke_O__O(arg_4195) } else { u__4 = linked_4193.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4192, arg_4195) }; var root_4196 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4196, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4198 lang.IFn; if linked_4197 == nil { ifn_4198 = lang.IFn_Cast(root_4196) } else { ifn_4198 = nil }; var arg_4199 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), u__4); var arg_4200 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000492); var tmp7 any; var root_4201 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4201, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4203 lang.IFn; if linked_4202 == nil { ifn_4203 = lang.IFn_Cast(root_4201) } else { ifn_4203 = nil }; var arg_4204 any = s__1685000493__3; if linked_4202 == nil { tmp7 = ifn_4203.Invoke_O__O(arg_4204) } else { tmp7 = linked_4202.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4201, arg_4204) }; arg_4200 = tmp6.Invoke_O__O(tmp7); if linked_4197 == nil { return ifn_4198.Invoke_O_O__O(arg_4199, arg_4200) } else { return linked_4197.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4196, arg_4199, arg_4200) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000495 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000495 = c__b__1685000495 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A) Invoke_O__O(self any) any { { var i__1685000494__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000494__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000494__1)); var root_4164 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4164, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4166 lang.IFn; if linked_4165 == nil { ifn_4166 = lang.IFn_Cast(root_4164) } else { ifn_4166 = nil }; var arg_4167 any = t.F_b__1685000495; var arg_4168 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), u__2); if linked_4165 == nil { ifn_4166.Invoke_O_O__O(arg_4167, arg_4168) } else { linked_4165.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4164, arg_4167, arg_4168) }; i__1685000494__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000494__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :687:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :687:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000511__2 any = args__0; var seq__1685000512__3 any; var root_4438 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4438, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4440 lang.IFn; if


	linked_4439 == nil { ifn_4440 = lang.IFn_Cast(root_4438) } else { ifn_4440 = nil }; var arg_4441 any = vec__1685000511__2; if linked_4439 == nil { seq__1685000512__3 = ifn_4440.Invoke_O__O(arg_4441) } else { seq__1685000512__3 = linked_4439.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4438, arg_4441) }; var first__1685000513__4 any; var root_4442 any = /*line :687:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4444 lang.IFn; if


	linked_4443 == nil { ifn_4444 = lang.IFn_Cast(root_4442) } else { ifn_4444 = nil }; var arg_4445 any = seq__1685000512__3; if linked_4443 == nil { first__1685000513__4 = ifn_4444.Invoke_O__O(arg_4445) } else { first__1685000513__4 = linked_4443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4442, arg_4445) }; var seq__1685000512__5 any; var root_4446 any = /*line :687:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4446, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4448 lang.IFn; if


	linked_4447 == nil { ifn_4448 = lang.IFn_Cast(root_4446) } else { ifn_4448 = nil }; var arg_4449 any = seq__1685000512__3; if linked_4447 == nil { seq__1685000512__5 = ifn_4448.Invoke_O__O(arg_4449) } else { seq__1685000512__5 = linked_4447.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4446, arg_4449) }; var cmd__6 any = first__1685000513__4; var args__7 any = seq__1685000512__5; var G__1685000514__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000514__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000514__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000515_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4541 /*line :691:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000515_A_fn_class

		if fncls__4541 == nil { var fncls__4541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000515_A_fn_class = fncls__4541d; tmp2 = fncls__4541d } else { tmp2 = fncls__4541 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :691:1
		var cs__10 any; var tmp3 any; var root_4542 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4544 lang.IFn











		if linked_4543 == nil { ifn_4544 = lang.IFn_Cast(root_4542) } else { ifn_4544 = nil }; var arg_4545 any = A_arbace_go_check_A_const_392.Invoke_O__O(opts__9); if linked_4543 == nil { tmp3 = ifn_4544.Invoke_O__O(arg_4545) } else { tmp3 = linked_4543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4542, arg_4545) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_392.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_395.GetRawRoot__O() }
//line :691:1
		var ok__11 any; var root_4628 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4628, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4630 lang.IFn












		if linked_4629 == nil { ifn_4630 = lang.IFn_Cast(root_4628) } else { ifn_4630 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_284; var tmp6 any = A_arbace_go_check_A_const_163.Invoke_O__O(opts__9); var tmp7 any = A_arbace_go_check_A_const_362; var arg_4631 any = tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, A_arbace_go_check_A_const_394.Invoke_O__O(opts__9)); if linked_4629 == nil { ifn_4630.Invoke_O__O(arg_4631) } else { linked_4629.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4628, arg_4631) }; var tmp8 any = A_arbace_go_check__main_fn__1685000518_A_New_O_O(cs__10, opts__9); var tmp9 *jrt.Class; var fncls__4622 *jrt.Class = A_arbace_go_check__main_fn__1685000518_A_fn_class; if fncls__4622 == nil { var fncls__4622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_fn__1685000518_A_fn_class = fncls__4622d; tmp9 = fncls__4622d } else { tmp9 = fncls__4622 }; ok__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()


		var root_4639 any = A_arbace_go_check_A_const_399.GetRawRoot__O(); var linked_4640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4639, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4641 lang.IFn; if linked_4640 == nil { ifn_4641 = lang.IFn_Cast(root_4639) } else { ifn_4641 = nil }; if linked_4640 == nil { ifn_4641.Invoke__O() } else { linked_4640.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4639) }
		var tmp10 int64; var tmp11 any; var root_4623 any = A_arbace_go_check_A_const_397.GetRawRoot__O(); var linked_4624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4623, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4625 lang.IFn; if linked_4624 == nil { ifn_4625 = lang.IFn_Cast(root_4623) } else { ifn_4625 = nil }; var arg_4626 any = A_arbace_go_check_A_const_398.GetRawRoot__O(); var arg_4627 any = ok__11; if linked_4624 == nil { tmp11 = ifn_4625.Invoke_O_O__O(arg_4626, arg_4627) } else { tmp11 = linked_4624.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4623, arg_4626, arg_4627) }; if jrt.J2g_Truth(tmp11) { tmp10 = 0 } else { tmp10 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp10)); return nil }
//line :691:1
	default:};

















	lang.IFn_Cast(A_arbace_go_check_A_const_380.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :693:1
func A_arbace_go_check__main_fn__1685000515_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000515_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000515_A{}; t.Ctor_O(p0); return t }
//line :693:1
func (t *A_arbace_go_check__main_fn__1685000515_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :693:1
func (t *A_arbace_go_check__main_fn__1685000515_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_363; var tmp2 any = A_arbace_go_check_A_const_391; var tmp3 any = A_arbace_go_check_A_const_365; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_392, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_4451 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_4452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4451, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4453 lang.IFn; if linked_4452 == nil { ifn_4453 = lang.IFn_Cast(root_4451) } else { ifn_4453 = nil }; var arg_4454 any = as__1; if linked_4452 == nil { tmp4 = ifn_4453.Invoke_O__O(arg_4454) } else { tmp4 = linked_4452.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4451, arg_4454) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000516__3_ any; var root_4455 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4457 lang.IFn

		if linked_4456 == nil { ifn_4457 = lang.IFn_Cast(root_4455) } else { ifn_4457 = nil }; var arg_4458 any = as__1; if linked_4456 == nil { G__1685000516__3_ = ifn_4457.Invoke_O__O(arg_4458) } else { G__1685000516__3_ = linked_4456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4455, arg_4458) }; switch lang.Util_Hash_O__I_NoInit(G__1685000516__3_) >> 10 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_6) {



			var tmp5 any; var root_4460 any = A_arbace_go_check_A_const_393.GetRawRoot__O(); var linked_4461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4460, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4462 lang.IFn; if linked_4461 == nil { ifn_4462 = lang.IFn_Cast(root_4460) } else { ifn_4462 = nil }; var arg_4463 any = as__1; if linked_4461 == nil { tmp5 = ifn_4462.Invoke_O__O(arg_4463) } else { tmp5 = linked_4461.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4460, arg_4463) }; var tmp6 any = tmp5; var tmp7 any; var root_4464 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4464, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4466 lang.IFn; if linked_4465 == nil { ifn_4466 = lang.IFn_Cast(root_4464) } else { ifn_4466 = nil }; var arg_4467 any = o__2; var arg_4468 any = A_arbace_go_check_A_const_163; var arg_4469 any; var root_4470 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_4471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4470, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4472 lang.IFn; if linked_4471 == nil { ifn_4472 = lang.IFn_Cast(root_4470) } else { ifn_4472 = nil }; var arg_4473 any = as__1; if linked_4471 == nil { arg_4469 = ifn_4472.Invoke_O__O(arg_4473) } else { arg_4469 = linked_4471.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4470, arg_4473) }; if linked_4465 == nil { tmp7 = ifn_4466.Invoke_O_O_O__O(arg_4467, arg_4468, arg_4469) } else { tmp7 = linked_4465.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4464, arg_4467, arg_4468, arg_4469) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :696:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_7) {




			var tmp8 any; var root_4474 any = A_arbace_go_check_A_const_393.GetRawRoot__O(); var linked_4475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4474, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4476 lang.IFn; if linked_4475 == nil { ifn_4476 = lang.IFn_Cast(root_4474) } else { ifn_4476 = nil }; var arg_4477 any = as__1; if linked_4475 == nil { tmp8 = ifn_4476.Invoke_O__O(arg_4477) } else { tmp8 = linked_4475.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4474, arg_4477) }; var tmp9 any = tmp8; var tmp10 any; var root_4478 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4479 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4478, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4480 lang.IFn; if linked_4479 == nil { ifn_4480 = lang.IFn_Cast(root_4478) } else { ifn_4480 = nil }; var arg_4481 any = o__2; var arg_4482 any = A_arbace_go_check_A_const_394; var arg_4483 any; var root_4484 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_4485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4484, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4486 lang.IFn; if linked_4485 == nil { ifn_4486 = lang.IFn_Cast(root_4484) } else { ifn_4486 = nil }; var arg_4487 any = as__1; if linked_4485 == nil { arg_4483 = ifn_4486.Invoke_O__O(arg_4487) } else { arg_4483 = linked_4485.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4484, arg_4487) }; if linked_4479 == nil { tmp10 = ifn_4480.Invoke_O_O_O__O(arg_4481, arg_4482, arg_4483) } else { tmp10 = linked_4479.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4478, arg_4481, arg_4482, arg_4483) }; as__1, o__2 = tmp9, tmp10; continue L1 }
//line :696:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_8) {

			var tmp11 any; var root_4488 any = A_arbace_go_check_A_const_393.GetRawRoot__O(); var linked_4489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4488, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4490 lang.IFn; if linked_4489 == nil { ifn_4490 = lang.IFn_Cast(root_4488) } else { ifn_4490 = nil }; var arg_4491 any = as__1; if linked_4489 == nil { tmp11 = ifn_4490.Invoke_O__O(arg_4491) } else { tmp11 = linked_4489.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4488, arg_4491) }; var tmp12 any = tmp11; var tmp13 any; var root_4492 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4492, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4494 lang.IFn; if linked_4493 == nil { ifn_4494 = lang.IFn_Cast(root_4492) } else { ifn_4494 = nil }; var arg_4495 any = o__2; var arg_4496 any = A_arbace_go_check_A_const_363; var arg_4497 any; var tmp14 any; var root_4498 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_4499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4498, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4500 lang.IFn; if linked_4499 == nil { ifn_4500 = lang.IFn_Cast(root_4498) } else { ifn_4500 = nil }; var arg_4501 any = as__1; if linked_4499 == nil { tmp14 = ifn_4500.Invoke_O__O(arg_4501) } else { tmp14 = linked_4499.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4498, arg_4501) }; arg_4497 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp14))).Ref(); if linked_4493 == nil { tmp13 = ifn_4494.Invoke_O_O_O__O(arg_4495, arg_4496, arg_4497) } else { tmp13 = linked_4493.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4492, arg_4495, arg_4496, arg_4497) }; as__1, o__2 = tmp12, tmp13; continue L1 }
//line :696:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_9) {
			var tmp15 any; var root_4502 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4502, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4504 lang.IFn; if linked_4503 == nil { ifn_4504 = lang.IFn_Cast(root_4502) } else { ifn_4504 = nil }; var arg_4505 any = as__1; if linked_4503 == nil { tmp15 = ifn_4504.Invoke_O__O(arg_4505) } else { tmp15 = linked_4503.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4502, arg_4505) }; var tmp16 any = tmp15; var tmp17 any; var root_4506 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4507 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4506, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4508 lang.IFn; if linked_4507 == nil { ifn_4508 = lang.IFn_Cast(root_4506) } else { ifn_4508 = nil }; var arg_4509 any = o__2; var arg_4510 any = A_arbace_go_check_A_const_364; var arg_4511 any = jrt.Boolean_TRUE.Ref(); if linked_4507 == nil { tmp17 = ifn_4508.Invoke_O_O_O__O(arg_4509, arg_4510, arg_4511) } else { tmp17 = linked_4507.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4506, arg_4509, arg_4510, arg_4511) }; as__1, o__2 = tmp16, tmp17; continue L1 }
//line :696:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_10) {


			var tmp18 any; var root_4512 any = A_arbace_go_check_A_const_393.GetRawRoot__O(); var linked_4513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4512, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4514 lang.IFn; if linked_4513 == nil { ifn_4514 = lang.IFn_Cast(root_4512) } else { ifn_4514 = nil }; var arg_4515 any = as__1; if linked_4513 == nil { tmp18 = ifn_4514.Invoke_O__O(arg_4515) } else { tmp18 = linked_4513.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4512, arg_4515) }; var tmp19 any = tmp18; var tmp20 any; var root_4516 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4516, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4518 lang.IFn; if linked_4517 == nil { ifn_4518 = lang.IFn_Cast(root_4516) } else { ifn_4518 = nil }; var arg_4519 any = o__2; var arg_4520 any = A_arbace_go_check_A_const_365; var arg_4521 any; var root_4522 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_4523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4522, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4524 lang.IFn; if linked_4523 == nil { ifn_4524 = lang.IFn_Cast(root_4522) } else { ifn_4524 = nil }; var arg_4525 any = as__1; if linked_4523 == nil { arg_4521 = ifn_4524.Invoke_O__O(arg_4525) } else { arg_4521 = linked_4523.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4522, arg_4525) }; if linked_4517 == nil { tmp20 = ifn_4518.Invoke_O_O_O__O(arg_4519, arg_4520, arg_4521) } else { tmp20 = linked_4517.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4516, arg_4519, arg_4520, arg_4521) }; as__1, o__2 = tmp19, tmp20; continue L1 }
//line :696:1
		default:
		}




		var tmp21 any; var root_4526 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4526, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4528 lang.IFn; if linked_4527 == nil { ifn_4528 = lang.IFn_Cast(root_4526) } else { ifn_4528 = nil }; var arg_4529 any = as__1; if linked_4527 == nil { tmp21 = ifn_4528.Invoke_O__O(arg_4529) } else { tmp21 = linked_4527.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4526, arg_4529) }; var tmp22 any = tmp21; var tmp23 any; var root_4530 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4530, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4532 lang.IFn; if linked_4531 == nil { ifn_4532 = lang.IFn_Cast(root_4530) } else { ifn_4532 = nil }; var arg_4533 any = o__2; var arg_4534 any = A_arbace_go_check_A_const_392; var arg_4535 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4536 any; var root_4537 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4537, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4539 lang.IFn; if linked_4538 == nil { ifn_4539 = lang.IFn_Cast(root_4537) } else { ifn_4539 = nil }; var arg_4540 any = as__1; if linked_4538 == nil { arg_4536 = ifn_4539.Invoke_O__O(arg_4540) } else { arg_4536 = linked_4538.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4537, arg_4540) }; if linked_4531 == nil { tmp23 = ifn_4532.Invoke_O_O_O_O__O(arg_4533, arg_4534, arg_4535, arg_4536) } else { tmp23 = linked_4531.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4530, arg_4533, arg_4534, arg_4535, arg_4536) }; as__1, o__2 = tmp22, tmp23; continue L1 } } }; /*line :693:1*/panic("j2g: unreachable") }










func A_arbace_go_check__main_fn__1685000518_A_New_O_O(p0, p1 any) *A_arbace_go_check__main_fn__1685000518_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_A{}; t.Ctor_O_O(p0, p1); return t }
//line :704:1
func (t *A_arbace_go_check__main_fn__1685000518_A) Ctor_O_O(c__cs, c__opts any) { t.F_cs = c__cs; t.F_opts = c__opts }
//line :704:1
func (t *A_arbace_go_check__main_fn__1685000518_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_4546 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_4547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4546, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4548 lang.IFn; if linked_4547 == nil { ifn_4548 = lang.IFn_Cast(root_4546) } else { ifn_4548 = nil }; var arg_4549 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_New_O(t.F_opts); var tmp3 *jrt.Class; var fncls__4618 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class; if fncls__4618 == nil { var fncls__4618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class = fncls__4618d; tmp3 = fncls__4618d } else { tmp3 = fncls__4618 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var t_ any = t.F_cs; t.F_cs = nil; tmp5 = t_; arg_4549 = tmp4.Invoke_O__O(tmp5); if linked_4547 == nil { tmp1 = ifn_4548.Invoke_O__O(arg_4549) } else { tmp1 = linked_4547.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4546, arg_4549) } }
//line :704:1
	return nil }(); var root_4619 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_4620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4619, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4621 lang.IFn; if linked_4620 == nil { ifn_4621 = lang.IFn_Cast(root_4619) } else { ifn_4621 = nil }; if linked_4620 == nil { ifn_4621.Invoke__O() } else { linked_4620.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4619) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }

func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A{}; t.Ctor_O(p0); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A) Invoke_O_O__O(self, s__1685000520__1 any) any { var tmp1 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_New_O_O_O(self, t.F_opts, s__1685000520__1); var tmp2 *jrt.Class; var fncls__4617 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class; if fncls__4617 == nil { var fncls__4617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class = fncls__4617d; tmp2 = fncls__4617d } else { tmp2 = fncls__4617 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :706:1
func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A) Ctor_O_O_O(c__iter__1685000519, c__opts, c__s__1685000520 any) { t.F_iter__1685000519 = c__iter__1685000519; t.F_opts = c__opts; t.F_s__1685000520 = c__s__1685000520 }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A) Invoke_O__O(self any) any { { var s__1685000520__1 any; var t_ any = t.F_s__1685000520; t.F_s__1685000520 = nil; s__1685000520__1 = t_; for { var temp__1927000414__auto____2 any; var root_4550 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4550, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4552 lang.IFn; if linked_4551 == nil { ifn_4552 = lang.IFn_Cast(root_4550) } else { ifn_4552 = nil }; var arg_4553 any = s__1685000520__1; if linked_4551 == nil { temp__1927000414__auto____2 = ifn_4552.Invoke_O__O(arg_4553) } else { temp__1927000414__auto____2 = linked_4551.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4550, arg_4553) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000520__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4554 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4554, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4556 lang.IFn; if linked_4555 == nil { ifn_4556 = lang.IFn_Cast(root_4554) } else { ifn_4556 = nil }; var arg_4557 any = s__1685000520__3; if linked_4555 == nil { tmp1 = ifn_4556.Invoke_O__O(arg_4557) } else { tmp1 = linked_4555.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4554, arg_4557) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4558 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4558, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4560 lang.IFn; if linked_4559 == nil { ifn_4560 = lang.IFn_Cast(root_4558) } else { ifn_4560 = nil }; var arg_4561 any = s__1685000520__3; if linked_4559 == nil { c__1927001037__auto____4 = ifn_4560.Invoke_O__O(arg_4561) } else { c__1927001037__auto____4 = linked_4559.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4558, arg_4561) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000522__6 any; var root_4562 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_4563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4562, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4564 lang.IFn; if linked_4563 == nil { ifn_4564 = lang.IFn_Cast(root_4562) } else { ifn_4564 = nil }; var arg_4565 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4563 == nil { b__1685000522__6 = ifn_4564.Invoke_O__O(arg_4565) } else { b__1685000522__6 = linked_4563.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4562, arg_4565) }; var tmp2 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_New_O_O_I_O(b__1685000522__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4576 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class; if fncls__4576 == nil { var fncls__4576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class = fncls__4576d; tmp3 = fncls__4576d } else { tmp3 = fncls__4576 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4577 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4577, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4579 lang.IFn; if linked_4578 == nil { ifn_4579 = lang.IFn_Cast(root_4577) } else { ifn_4579 = nil }; var arg_4580 any; var root_4582 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4582, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4584 lang.IFn; if linked_4583 == nil { ifn_4584 = lang.IFn_Cast(root_4582) } else { ifn_4584 = nil }; var arg_4585 any = b__1685000522__6; if linked_4583 == nil { arg_4580 = ifn_4584.Invoke_O__O(arg_4585) } else { arg_4580 = linked_4583.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4582, arg_4585) }; var arg_4581 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000519); var tmp5 any; var root_4586 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4586, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4588 lang.IFn; if linked_4587 == nil { ifn_4588 = lang.IFn_Cast(root_4586) } else { ifn_4588 = nil }; var arg_4589 any = s__1685000520__3; if linked_4587 == nil { tmp5 = ifn_4588.Invoke_O__O(arg_4589) } else { tmp5 = linked_4587.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4586, arg_4589) }; arg_4581 = tmp4.Invoke_O__O(tmp5); if linked_4578 == nil { return ifn_4579.Invoke_O_O__O(arg_4580, arg_4581) } else { return linked_4578.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4577, arg_4580, arg_4581) } } else { var root_4590 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4592 lang.IFn; if linked_4591 == nil { ifn_4592 = lang.IFn_Cast(root_4590) } else { ifn_4592 = nil }; var arg_4593 any; var root_4595 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4597 lang.IFn; if linked_4596 == nil { ifn_4597 = lang.IFn_Cast(root_4595) } else { ifn_4597 = nil }; var arg_4598 any = b__1685000522__6; if linked_4596 == nil { arg_4593 = ifn_4597.Invoke_O__O(arg_4598) } else { arg_4593 = linked_4596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4595, arg_4598) }; var arg_4594 any; if linked_4591 == nil { return ifn_4592.Invoke_O_O__O(arg_4593, arg_4594) } else { return linked_4591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4590, arg_4593, arg_4594) } } } else { var c__4 any; var root_4599 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4599, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4601 lang.IFn; if linked_4600 == nil { ifn_4601 = lang.IFn_Cast(root_4599) } else { ifn_4601 = nil }; var arg_4602 any = s__1685000520__3; if linked_4600 == nil { c__4 = ifn_4601.Invoke_O__O(arg_4602) } else { c__4 = linked_4600.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4599, arg_4602) }; var root_4603 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4603, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4605 lang.IFn; if linked_4604 == nil { ifn_4605 = lang.IFn_Cast(root_4603) } else { ifn_4605 = nil }; var arg_4606 any; var root_4608 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4608, A_arbace_go_check_annotations_A_fn_class); var ifn_4610 lang.IFn; if linked_4609 == nil { ifn_4610 = lang.IFn_Cast(root_4608) } else { ifn_4610 = nil }; var arg_4611 any = c__4; var arg_4612 any = t.F_opts; if linked_4609 == nil { arg_4606 = ifn_4610.Invoke_O_O__O(arg_4611, arg_4612) } else { arg_4606 = linked_4609.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4608, arg_4611, arg_4612) }; var arg_4607 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000519); var tmp7 any; var root_4613 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4613, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4615 lang.IFn; if linked_4614 == nil { ifn_4615 = lang.IFn_Cast(root_4613) } else { ifn_4615 = nil }; var arg_4616 any = s__1685000520__3; if linked_4614 == nil { tmp7 = ifn_4615.Invoke_O__O(arg_4616) } else { tmp7 = linked_4614.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4613, arg_4616) }; arg_4607 = tmp6.Invoke_O__O(tmp7); if linked_4604 == nil { return ifn_4605.Invoke_O_O__O(arg_4606, arg_4607) } else { return linked_4604.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4603, arg_4606, arg_4607) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :706:1
func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A) Ctor_O_O_I_O(c__b__1685000522, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000522 = c__b__1685000522; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A) Invoke_O__O(self any) any { { var i__1685000521__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000521__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000521__1)); var root_4566 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4566, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4568 lang.IFn; if linked_4567 == nil { ifn_4568 = lang.IFn_Cast(root_4566) } else { ifn_4568 = nil }; var arg_4569 any = t.F_b__1685000522; var arg_4570 any; var root_4571 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4571, A_arbace_go_check_annotations_A_fn_class); var ifn_4573 lang.IFn; if linked_4572 == nil { ifn_4573 = lang.IFn_Cast(root_4571) } else { ifn_4573 = nil }; var arg_4574 any = c__2; var arg_4575 any = t.F_opts; if linked_4572 == nil { arg_4570 = ifn_4573.Invoke_O_O__O(arg_4574, arg_4575) } else { arg_4570 = linked_4572.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4571, arg_4574, arg_4575) }; if linked_4567 == nil { ifn_4568.Invoke_O_O__O(arg_4569, arg_4570) } else { linked_4567.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4566, arg_4569, arg_4570) }; i__1685000521__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000521__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Keyword

var A_arbace_go_check_A_const_55 *lang.Var

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Keyword

var A_arbace_go_check_A_const_61 *lang.Var

var A_arbace_go_check_A_const_62 *lang.Keyword

var A_arbace_go_check_A_const_63 *lang.Var

var A_arbace_go_check_A_const_64 *lang.Keyword

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Var

var A_arbace_go_check_A_const_67 *lang.Keyword

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Var

var A_arbace_go_check_A_const_73 *lang.Keyword

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Var

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 any

var A_arbace_go_check_A_const_78 *lang.Keyword

var A_arbace_go_check_A_const_79 *lang.Var

var A_arbace_go_check_A_const_80 *lang.Keyword

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Var

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Keyword

var A_arbace_go_check_A_const_90 *lang.Var

var A_arbace_go_check_A_const_91 *lang.Keyword

var A_arbace_go_check_A_const_92 *lang.Var

var A_arbace_go_check_A_const_93 *lang.Keyword

var A_arbace_go_check_A_const_94 any

var A_arbace_go_check_A_const_95 *lang.Keyword

var A_arbace_go_check_A_const_96 *lang.Var

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 any

var A_arbace_go_check_A_const_99 *lang.Keyword

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Var

var A_arbace_go_check_A_const_102 *lang.Var

var A_arbace_go_check_A_const_103 *lang.Var

var A_arbace_go_check_A_const_104 *lang.Var

var A_arbace_go_check_A_const_105 *lang.Var

var A_arbace_go_check_A_const_106 *lang.Keyword

var A_arbace_go_check_A_const_107 *lang.Var

var A_arbace_go_check_A_const_108 *lang.Keyword

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Keyword

var A_arbace_go_check_A_const_113 *lang.Var

var A_arbace_go_check_A_const_114 *lang.Keyword

var A_arbace_go_check_A_const_115 *lang.Keyword

var A_arbace_go_check_A_const_116 *lang.Keyword

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Keyword

var A_arbace_go_check_A_const_119 *lang.Keyword

var A_arbace_go_check_A_const_120 *lang.Keyword

var A_arbace_go_check_A_const_121 *lang.Keyword

var A_arbace_go_check_A_const_122 *lang.Var

var A_arbace_go_check_A_const_123 *lang.Var

var A_arbace_go_check_A_const_124 *lang.Keyword

var A_arbace_go_check_A_const_125 *lang.Var

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Keyword

var A_arbace_go_check_A_const_128 *lang.Var

var A_arbace_go_check_A_const_129 *lang.Var

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 any

var A_arbace_go_check_A_const_133 *lang.Var

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 any

var A_arbace_go_check_A_const_137 any

var A_arbace_go_check_A_const_138 *lang.Var

var A_arbace_go_check_A_const_139 *lang.Keyword

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 any

var A_arbace_go_check_A_const_142 *lang.Var

var A_arbace_go_check_A_const_143 *lang.Var

var A_arbace_go_check_A_const_144 *lang.Keyword

var A_arbace_go_check_A_const_145 *lang.Keyword

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Keyword

var A_arbace_go_check_A_const_150 *lang.Var

var A_arbace_go_check_A_const_151 *lang.Var

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Var

var A_arbace_go_check_A_const_154 *lang.Keyword

var A_arbace_go_check_A_const_155 *lang.Keyword

var A_arbace_go_check_A_const_156 *lang.Keyword

var A_arbace_go_check_A_const_157 *lang.Var

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Keyword

var A_arbace_go_check_A_const_164 *lang.Keyword

var A_arbace_go_check_A_const_165 *lang.Keyword

var A_arbace_go_check_A_const_166 *lang.Keyword

var A_arbace_go_check_A_const_167 *lang.Var

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Var

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Var

var A_arbace_go_check_A_const_197 *lang.Keyword

var A_arbace_go_check_A_const_198 *lang.Keyword

var A_arbace_go_check_A_const_199 *lang.Keyword

var A_arbace_go_check_A_const_200 *lang.Keyword

var A_arbace_go_check_A_const_201 *lang.Var

var A_arbace_go_check_A_const_202 *lang.Var

var A_arbace_go_check_A_const_203 *lang.Var

var A_arbace_go_check_A_const_204 *lang.Keyword

var A_arbace_go_check_A_const_205 *lang.Var

var A_arbace_go_check_A_const_206 *lang.Var

var A_arbace_go_check_A_const_207 *lang.Var

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Keyword

var A_arbace_go_check_A_const_210 *lang.Var

var A_arbace_go_check_A_const_211 *lang.Keyword

var A_arbace_go_check_A_const_212 *lang.Var

var A_arbace_go_check_A_const_213 *lang.Var

var A_arbace_go_check_A_const_214 *lang.Keyword

var A_arbace_go_check_A_const_215 *lang.Keyword

var A_arbace_go_check_A_const_216 *lang.Var

var A_arbace_go_check_A_const_217 *lang.Keyword

var A_arbace_go_check_A_const_218 *lang.Var

var A_arbace_go_check_A_const_219 *lang.Var

var A_arbace_go_check_A_const_220 *lang.Var

var A_arbace_go_check_A_const_221 *lang.Var

var A_arbace_go_check_A_const_222 *lang.Keyword

var A_arbace_go_check_A_const_223 *lang.Var

var A_arbace_go_check_A_const_224 *lang.Var

var A_arbace_go_check_A_const_225 *lang.Keyword

var A_arbace_go_check_A_const_226 *lang.Keyword

var A_arbace_go_check_A_const_227 *lang.Keyword

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Var

var A_arbace_go_check_A_const_230 *lang.Var

var A_arbace_go_check_A_const_231 *lang.Keyword

var A_arbace_go_check_A_const_232 *lang.Keyword

var A_arbace_go_check_A_const_233 *lang.Keyword

var A_arbace_go_check_A_const_234 *lang.Var

var A_arbace_go_check_A_const_235 *lang.Var

var A_arbace_go_check_A_const_236 *lang.Keyword

var A_arbace_go_check_A_const_237 *lang.Keyword

var A_arbace_go_check_A_const_238 *lang.Var

var A_arbace_go_check_A_const_239 *lang.Var

var A_arbace_go_check_A_const_240 *lang.Keyword

var A_arbace_go_check_A_const_241 *lang.Keyword

var A_arbace_go_check_A_const_242 *lang.Keyword

var A_arbace_go_check_A_const_243 *lang.Keyword

var A_arbace_go_check_A_const_244 *lang.Var

var A_arbace_go_check_A_const_245 any

var A_arbace_go_check_A_const_246 any

var A_arbace_go_check_A_const_247 *lang.Keyword

var A_arbace_go_check_A_const_248 *lang.Keyword

var A_arbace_go_check_A_const_249 *lang.Var

var A_arbace_go_check_A_const_250 *lang.Keyword

var A_arbace_go_check_A_const_251 any

var A_arbace_go_check_A_const_252 any

var A_arbace_go_check_A_const_253 *lang.Keyword

var A_arbace_go_check_A_const_254 *lang.Keyword

var A_arbace_go_check_A_const_255 *lang.Keyword

var A_arbace_go_check_A_const_256 *lang.Var

var A_arbace_go_check_A_const_257 *lang.Keyword

var A_arbace_go_check_A_const_258 *lang.Keyword

var A_arbace_go_check_A_const_259 *lang.Keyword

var A_arbace_go_check_A_const_260 *lang.Keyword

var A_arbace_go_check_A_const_261 *lang.Keyword

var A_arbace_go_check_A_const_262 *lang.Keyword

var A_arbace_go_check_A_const_263 *lang.Var

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Keyword

var A_arbace_go_check_A_const_266 *lang.Var

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 *lang.Keyword

var A_arbace_go_check_A_const_269 *lang.Keyword

var A_arbace_go_check_A_const_270 *lang.Var

var A_arbace_go_check_A_const_271 *lang.Var

var A_arbace_go_check_A_const_272 *lang.Var

var A_arbace_go_check_A_const_273 any

var A_arbace_go_check_A_const_274 *lang.Keyword

var A_arbace_go_check_A_const_275 *lang.Var

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Var

var A_arbace_go_check_A_const_278 *lang.Var

var A_arbace_go_check_A_const_279 *lang.Var

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Keyword

var A_arbace_go_check_A_const_282 *lang.Keyword

var A_arbace_go_check_A_const_283 *lang.Var

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 *lang.Keyword

var A_arbace_go_check_A_const_286 *lang.Keyword

var A_arbace_go_check_A_const_287 *lang.Keyword

var A_arbace_go_check_A_const_288 *lang.Keyword

var A_arbace_go_check_A_const_289 any

var A_arbace_go_check_A_const_290 *lang.Keyword

var A_arbace_go_check_A_const_291 any

var A_arbace_go_check_A_const_292 any

var A_arbace_go_check_A_const_293 any

var A_arbace_go_check_A_const_294 *lang.Keyword

var A_arbace_go_check_A_const_295 *lang.Var

var A_arbace_go_check_A_const_296 any

var A_arbace_go_check_A_const_297 any

var A_arbace_go_check_A_const_298 any

var A_arbace_go_check_A_const_299 any

var A_arbace_go_check_A_const_300 any

var A_arbace_go_check_A_const_301 *lang.Keyword

var A_arbace_go_check_A_const_302 any

var A_arbace_go_check_A_const_303 *lang.Var

var A_arbace_go_check_A_const_304 *lang.Var

var A_arbace_go_check_A_const_305 *lang.Var

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 any

var A_arbace_go_check_A_const_309 *lang.Var

var A_arbace_go_check_A_const_310 *lang.Keyword

var A_arbace_go_check_A_const_311 *lang.Keyword

var A_arbace_go_check_A_const_312 *lang.Keyword

var A_arbace_go_check_A_const_313 *lang.Keyword

var A_arbace_go_check_A_const_314 *lang.Var

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Keyword

var A_arbace_go_check_A_const_321 *lang.Var

var A_arbace_go_check_A_const_322 *lang.Var

var A_arbace_go_check_A_const_323 *lang.Var

var A_arbace_go_check_A_const_324 *lang.Var

var A_arbace_go_check_A_const_325 any

var A_arbace_go_check_A_const_326 *lang.Var

var A_arbace_go_check_A_const_327 any

var A_arbace_go_check_A_const_328 any

var A_arbace_go_check_A_const_329 *lang.Var

var A_arbace_go_check_A_const_330 *lang.Keyword

var A_arbace_go_check_A_const_331 *lang.Keyword

var A_arbace_go_check_A_const_332 *lang.Keyword

var A_arbace_go_check_A_const_333 *lang.Keyword

var A_arbace_go_check_A_const_334 *lang.Keyword

var A_arbace_go_check_A_const_335 *lang.Var

var A_arbace_go_check_A_const_336 *lang.Keyword

var A_arbace_go_check_A_const_337 *lang.Keyword

var A_arbace_go_check_A_const_338 *lang.Var

var A_arbace_go_check_A_const_339 *lang.Keyword

var A_arbace_go_check_A_const_340 any

var A_arbace_go_check_A_const_341 *lang.Keyword

var A_arbace_go_check_A_const_342 *lang.Keyword

var A_arbace_go_check_A_const_343 *lang.Var

var A_arbace_go_check_A_const_344 any

var A_arbace_go_check_A_const_345 any

var A_arbace_go_check_A_const_346 *lang.Var

var A_arbace_go_check_A_const_347 *lang.Var

var A_arbace_go_check_A_const_348 any

var A_arbace_go_check_A_const_349 *lang.Var

var A_arbace_go_check_A_const_350 any

var A_arbace_go_check_A_const_351 *lang.Var

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 *lang.Var

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_const_359 *lang.Var

var A_arbace_go_check_A_const_360 *lang.Var

var A_arbace_go_check_A_const_361 *lang.Var

var A_arbace_go_check_A_const_362 *lang.Var

var A_arbace_go_check_A_const_363 *lang.Keyword

var A_arbace_go_check_A_const_364 *lang.Keyword

var A_arbace_go_check_A_const_365 *lang.Keyword

var A_arbace_go_check_A_const_366 *lang.Var

var A_arbace_go_check_A_const_367 *lang.Var

var A_arbace_go_check_A_const_368 *jrt.Class

var A_arbace_go_check_A_const_369 *lang.Var

var A_arbace_go_check_A_const_370 *lang.Var

var A_arbace_go_check_A_const_371 *lang.Var

var A_arbace_go_check_A_const_372 *lang.Keyword

var A_arbace_go_check_A_const_373 any

var A_arbace_go_check_A_const_374 any

var A_arbace_go_check_A_const_375 any

var A_arbace_go_check_A_const_376 *lang.Keyword

var A_arbace_go_check_A_const_377 *lang.Var

var A_arbace_go_check_A_const_378 *lang.Keyword

var A_arbace_go_check_A_const_379 *lang.Var

var A_arbace_go_check_A_const_380 *lang.Var

var A_arbace_go_check_A_const_381 any

var A_arbace_go_check_A_const_382 any

var A_arbace_go_check_A_const_383 any

var A_arbace_go_check_A_const_384 any

var A_arbace_go_check_A_const_385 any

var A_arbace_go_check_A_const_386 any

var A_arbace_go_check_A_const_387 *lang.Var

var A_arbace_go_check_A_const_388 any

var A_arbace_go_check_A_const_389 any

var A_arbace_go_check_A_const_390 any

var A_arbace_go_check_A_const_391 any

var A_arbace_go_check_A_const_392 *lang.Keyword

var A_arbace_go_check_A_const_393 *lang.Var

var A_arbace_go_check_A_const_394 *lang.Keyword

var A_arbace_go_check_A_const_395 *lang.Var

var A_arbace_go_check_A_const_396 *lang.Var

var A_arbace_go_check_A_const_397 *lang.Var

var A_arbace_go_check_A_const_398 *lang.Var

var A_arbace_go_check_A_const_399 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29(); A_arbace_go_check_A_clinit_p30(); A_arbace_go_check_A_clinit_p31(); A_arbace_go_check_A_clinit_p32() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 583); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[183]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[184]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[185]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[186]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[187]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[189]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[190]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[191]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[192]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[193]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[194]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[195]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[196]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[200]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[203]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[204]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[205]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[207]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[208]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[209]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[213]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[214]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[216]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[220] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[221]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[223]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[224]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[226]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[231]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[232]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[233]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_55 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_61 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[245]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_66 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_72 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[257]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[259]); A_arbace_go_check_A_const_77 = A_arbace_go_check_A_const_pool.A[260]; A_arbace_go_check_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_79 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_86 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[269]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_90 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_92 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[276]); A_arbace_go_check_A_const_94 = A_arbace_go_check_A_const_pool.A[277]; A_arbace_go_check_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_96 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_98 = A_arbace_go_check_A_const_pool.A[281] }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[282]); A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[283]); A_arbace_go_check_A_const_101 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_102 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[285]); A_arbace_go_check_A_const_103 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_104 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_105 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_107 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[290]); A_arbace_go_check_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[295]); A_arbace_go_check_A_const_113 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_119 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_122 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[305]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_124 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_125 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_128 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_129 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[312]); A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_132 = A_arbace_go_check_A_const_pool.A[315]; A_arbace_go_check_A_const_133 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[316]); A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[317]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_136 = A_arbace_go_check_A_const_pool.A[319]; A_arbace_go_check_A_const_137 = A_arbace_go_check_A_const_pool.A[320]; A_arbace_go_check_A_const_138 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[321]); A_arbace_go_check_A_const_139 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_141 = A_arbace_go_check_A_const_pool.A[324]; A_arbace_go_check_A_const_142 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_143 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_144 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_145 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[329]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_149 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_150 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_151 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_153 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_154 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_155 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_156 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_157 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_163 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_164 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_165 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_166 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_167 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_191 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[377]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_196 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_197 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_198 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_199 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_200 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_201 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_202 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_203 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_204 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_205 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_206 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_209 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_210 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_211 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_212 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_213 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_215 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_216 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_217 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_218 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[401]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_220 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_221 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_222 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_223 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_224 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_229 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_230 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[413]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_233 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_234 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_235 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_238 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_239 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_241 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[424]); A_arbace_go_check_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[425]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_244 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_245 = A_arbace_go_check_A_const_pool.A[428]; A_arbace_go_check_A_const_246 = A_arbace_go_check_A_const_pool.A[429]; A_arbace_go_check_A_const_247 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[430]); A_arbace_go_check_A_const_248 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_249 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[433]); A_arbace_go_check_A_const_251 = A_arbace_go_check_A_const_pool.A[434]; A_arbace_go_check_A_const_252 = A_arbace_go_check_A_const_pool.A[435]; A_arbace_go_check_A_const_253 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[436]); A_arbace_go_check_A_const_254 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_255 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_256 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_258 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_260 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_261 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_262 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[445]); A_arbace_go_check_A_const_263 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_265 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_266 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[451]); A_arbace_go_check_A_const_269 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[452]); A_arbace_go_check_A_const_270 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_271 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_272 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_273 = A_arbace_go_check_A_const_pool.A[456]; A_arbace_go_check_A_const_274 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[457]); A_arbace_go_check_A_const_275 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_277 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_278 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_279 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_281 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_282 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_283 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_285 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_286 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_287 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_288 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[471]); A_arbace_go_check_A_const_289 = A_arbace_go_check_A_const_pool.A[472]; A_arbace_go_check_A_const_290 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[473]); A_arbace_go_check_A_const_291 = A_arbace_go_check_A_const_pool.A[474] }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = A_arbace_go_check_A_const_pool.A[475]; A_arbace_go_check_A_const_293 = A_arbace_go_check_A_const_pool.A[476]; A_arbace_go_check_A_const_294 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[477]); A_arbace_go_check_A_const_295 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[478]); A_arbace_go_check_A_const_296 = A_arbace_go_check_A_const_pool.A[479]; A_arbace_go_check_A_const_297 = A_arbace_go_check_A_const_pool.A[480]; A_arbace_go_check_A_const_298 = A_arbace_go_check_A_const_pool.A[481]; A_arbace_go_check_A_const_299 = A_arbace_go_check_A_const_pool.A[482]; A_arbace_go_check_A_const_300 = A_arbace_go_check_A_const_pool.A[483]; A_arbace_go_check_A_const_301 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[484]); A_arbace_go_check_A_const_302 = A_arbace_go_check_A_const_pool.A[485]; A_arbace_go_check_A_const_303 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[486]); A_arbace_go_check_A_const_304 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[487]); A_arbace_go_check_A_const_305 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[488]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_308 = A_arbace_go_check_A_const_pool.A[491]; A_arbace_go_check_A_const_309 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_310 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_311 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[494]); A_arbace_go_check_A_const_312 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[495]); A_arbace_go_check_A_const_313 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_314 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[498]); A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[500]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_320 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_321 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_322 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_323 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[506]); A_arbace_go_check_A_const_324 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[507]); A_arbace_go_check_A_const_325 = A_arbace_go_check_A_const_pool.A[508]; A_arbace_go_check_A_const_326 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[509]); A_arbace_go_check_A_const_327 = A_arbace_go_check_A_const_pool.A[510]; A_arbace_go_check_A_const_328 = A_arbace_go_check_A_const_pool.A[511]; A_arbace_go_check_A_const_329 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[512]) }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_330 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[513]); A_arbace_go_check_A_const_331 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[514]); A_arbace_go_check_A_const_332 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[515]); A_arbace_go_check_A_const_333 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[516]); A_arbace_go_check_A_const_334 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_335 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_336 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_337 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_338 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[521]); A_arbace_go_check_A_const_339 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[522]); A_arbace_go_check_A_const_340 = A_arbace_go_check_A_const_pool.A[523]; A_arbace_go_check_A_const_341 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[524]) }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[525]); A_arbace_go_check_A_const_343 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[526]); A_arbace_go_check_A_const_344 = A_arbace_go_check_A_const_pool.A[527]; A_arbace_go_check_A_const_345 = A_arbace_go_check_A_const_pool.A[528]; A_arbace_go_check_A_const_346 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[529]); A_arbace_go_check_A_const_347 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[530]); A_arbace_go_check_A_const_348 = A_arbace_go_check_A_const_pool.A[531]; A_arbace_go_check_A_const_349 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[532]); A_arbace_go_check_A_const_350 = A_arbace_go_check_A_const_pool.A[533]; A_arbace_go_check_A_const_351 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[534]); A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[535]); A_arbace_go_check_A_const_353 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[536]); A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[537]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[538]); A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[539]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[540]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[541]); A_arbace_go_check_A_const_359 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[542]); A_arbace_go_check_A_const_360 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[543]); A_arbace_go_check_A_const_361 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[544]); A_arbace_go_check_A_const_362 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[545]); A_arbace_go_check_A_const_363 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[546]); A_arbace_go_check_A_const_364 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[547]); A_arbace_go_check_A_const_365 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[548]); A_arbace_go_check_A_const_366 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[549]) }

func A_arbace_go_check_A_clinit_p30() { A_arbace_go_check_A_const_367 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[550]); A_arbace_go_check_A_const_368 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[551]); A_arbace_go_check_A_const_369 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[552]); A_arbace_go_check_A_const_370 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[553]); A_arbace_go_check_A_const_371 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[554]); A_arbace_go_check_A_const_372 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[555]); A_arbace_go_check_A_const_373 = A_arbace_go_check_A_const_pool.A[556]; A_arbace_go_check_A_const_374 = A_arbace_go_check_A_const_pool.A[557]; A_arbace_go_check_A_const_375 = A_arbace_go_check_A_const_pool.A[558]; A_arbace_go_check_A_const_376 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[559]); A_arbace_go_check_A_const_377 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[560]); A_arbace_go_check_A_const_378 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[561]) }

func A_arbace_go_check_A_clinit_p31() { A_arbace_go_check_A_const_379 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[562]); A_arbace_go_check_A_const_380 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[563]); A_arbace_go_check_A_const_381 = A_arbace_go_check_A_const_pool.A[564]; A_arbace_go_check_A_const_382 = A_arbace_go_check_A_const_pool.A[565]; A_arbace_go_check_A_const_383 = A_arbace_go_check_A_const_pool.A[566]; A_arbace_go_check_A_const_384 = A_arbace_go_check_A_const_pool.A[567]; A_arbace_go_check_A_const_385 = A_arbace_go_check_A_const_pool.A[568]; A_arbace_go_check_A_const_386 = A_arbace_go_check_A_const_pool.A[569]; A_arbace_go_check_A_const_387 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[570]); A_arbace_go_check_A_const_388 = A_arbace_go_check_A_const_pool.A[571]; A_arbace_go_check_A_const_389 = A_arbace_go_check_A_const_pool.A[572]; A_arbace_go_check_A_const_390 = A_arbace_go_check_A_const_pool.A[573]; A_arbace_go_check_A_const_391 = A_arbace_go_check_A_const_pool.A[574]; A_arbace_go_check_A_const_392 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[575]) }

func A_arbace_go_check_A_clinit_p32() { A_arbace_go_check_A_const_393 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[576]); A_arbace_go_check_A_const_394 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[577]); A_arbace_go_check_A_const_395 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[578]); A_arbace_go_check_A_const_396 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[579]); A_arbace_go_check_A_const_397 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[580]); A_arbace_go_check_A_const_398 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[581]); A_arbace_go_check_A_const_399 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[582]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000515_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000515_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_A struct{ j2g_header uint64; F_cs, F_opts any }

var A_arbace_go_check__main_fn__1685000518_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A struct{ j2g_header uint64; F_iter__1685000519, F_opts, F_s__1685000520 any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A struct{ j2g_header uint64; F_b__1685000522, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A struct{ j2g_header uint64; F_s__1685000491, F_iter__1685000490 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A struct{ j2g_header uint64; F_r, F_s__1685000493, F_iter__1685000492 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000495 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000370_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000374_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000378_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A struct{ j2g_header uint64; F_s__1685000389, F_iter__1685000388 any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A struct{ j2g_header uint64; F_b__1685000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A struct{ j2g_header uint64; F_iter__1685000402, F_dir, F_tdir, F_ts, F_s__1685000403 any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A struct{ j2g_header uint64; F_dir, F_b__1685000405, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A struct{ j2g_header uint64; F_s__1685000361, F_iter__1685000360 any }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000363 any }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000129_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000129_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000131_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000131_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000179_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000186_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000186_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000193_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000203_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000203_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000205_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000205_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000239_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000239_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000241_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000241_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000247_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000247_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_A struct{ j2g_header uint64; F_resolving any }

var A_arbace_go_check_check_package_fn__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A struct{ j2g_header uint64; F_s__1685000267, F_iter__1685000266, F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A struct{ j2g_header uint64; F_b__1685000269 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000299_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000299_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000311_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000311_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000231_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A struct{ j2g_header uint64; F_s__1685000302, F_iter__1685000301 any }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A struct{ j2g_header uint64; F_b__1685000304 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000235_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000235_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class *jrt.Class



type A_arbace_go_check_check_src_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_src_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000321_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000467_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000467_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A struct{ j2g_header uint64; F_iter__1685000469, F_s__1685000470 any }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1685000472, F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A struct{ j2g_header uint64; F_iter__1685000447, F_s__1685000448 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A struct{ j2g_header uint64; F_iter__1685000449, F_r, F_s__1685000450 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000452 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000318_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000318_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A struct{ j2g_header uint64; F_iter__1685000338, F_f, F_out, F_q, F_xs, F_s__1685000339 any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_b__1685000341, F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000333_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000333_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000434_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000434_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000436_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000436_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000438_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000438_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000440_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000440_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000442_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000442_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000444_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000444_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000432_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000432_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000430_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000430_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000483_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000483_A_fn_class *jrt.Class
