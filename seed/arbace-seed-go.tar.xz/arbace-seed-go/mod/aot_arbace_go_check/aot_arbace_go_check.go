//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_116)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__7, A_arbace_go_check_A_const_54.Invoke_O__O(n__6))).Ref() } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_262 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_go_check_A_const_24; var arg_266 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_268 == nil { tmp2 = ifn_269.Invoke_O__O(arg_270) } else { tmp2 = linked_268.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_267, arg_270) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_271 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_275 any = Lit_155; var arg_276 any; var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_280 == nil { arg_276 = ifn_281.Invoke_O__O(arg_282) } else { arg_276 = linked_280.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_279, arg_282) }; var arg_277 any; var root_283 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_285 lang.IFn
							if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = want__7; if linked_284 == nil { arg_277 = ifn_285.Invoke_O__O(arg_286) } else { arg_277 = linked_284.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_283, arg_286) }
//line :93:1
							var arg_278 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_289 lang.IFn
							if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_288 == nil { arg_278 = ifn_289.Invoke_O__O(arg_290) } else { arg_278 = linked_288.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_287, arg_290) }
//line :93:1
							if linked_272 == nil { ifn_273.Invoke_O_O_O_O_O__O(arg_274, arg_275, arg_276, arg_277, arg_278) } else { linked_272.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_271, arg_274, arg_275, arg_276, arg_277, arg_278) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_291 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_293 lang.IFn
									if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_292 == nil { and__1927000168__auto____11 = ifn_293.Invoke_O__O(arg_294) } else { and__1927000168__auto____11 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_295 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_67; var arg_299 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_300 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); var arg_304 any = Lit_155; var arg_305 any; var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); if linked_309 == nil { arg_305 = ifn_310.Invoke_O__O(arg_311) } else { arg_305 = linked_309.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_308, arg_311) }; var arg_306 any = Lit_156; var arg_307 any; var root_312 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_313 == nil { arg_307 = ifn_314.Invoke_O__O(arg_315) } else { arg_307 = linked_313.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_312, arg_315) }; if linked_301 == nil { ifn_302.Invoke_O_O_O_O_O__O(arg_303, arg_304, arg_305, arg_306, arg_307) } else { linked_301.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_300, arg_303, arg_304, arg_305, arg_306, arg_307) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1685000042__7; if linked_317 == nil { tmp8 = ifn_318.Invoke_O__O(arg_319) } else { tmp8 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_316, arg_319) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__9, A_arbace_go_check_A_const_54.Invoke_O__O(n__8))).Ref() } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_320 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_24; var arg_324 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_321 == nil { ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { linked_321.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_325 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_326 == nil { tmp10 = ifn_327.Invoke_O__O(arg_328) } else { tmp10 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_325, arg_328) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_329 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_333 any = Lit_155; var arg_334 any; var root_337 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_338 == nil { arg_334 = ifn_339.Invoke_O__O(arg_340) } else { arg_334 = linked_338.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_337, arg_340) }; var arg_335 any; var root_341 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_343 lang.IFn
								if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = want__9; if linked_342 == nil { arg_335 = ifn_343.Invoke_O__O(arg_344) } else { arg_335 = linked_342.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_341, arg_344) }
//line :93:1
								var arg_336 any; var root_345 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_347 lang.IFn
								if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_346 == nil { arg_336 = ifn_347.Invoke_O__O(arg_348) } else { arg_336 = linked_346.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_345, arg_348) }
//line :93:1
								if linked_330 == nil { ifn_331.Invoke_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336) } else { linked_330.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_349 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_351 lang.IFn
										if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_350 == nil { and__1927000168__auto____13 = ifn_351.Invoke_O__O(arg_352) } else { and__1927000168__auto____13 = linked_350.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_353 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_go_check_A_const_67; var arg_357 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_354 == nil { tmp11 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp11 = linked_354.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_358 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); var arg_362 any = Lit_155; var arg_363 any; var root_366 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); if linked_367 == nil { arg_363 = ifn_368.Invoke_O__O(arg_369) } else { arg_363 = linked_367.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_366, arg_369) }; var arg_364 any = Lit_156; var arg_365 any; var root_370 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_371 == nil { arg_365 = ifn_372.Invoke_O__O(arg_373) } else { arg_365 = linked_371.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_370, arg_373) }; if linked_359 == nil { ifn_360.Invoke_O_O_O_O_O__O(arg_361, arg_362, arg_363, arg_364, arg_365) } else { linked_359.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_358, arg_361, arg_362, arg_363, arg_364, arg_365) } } }
//line :86:1
				var tmp15 any; var root_374 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1685000042__7; if linked_375 == nil { tmp15 = ifn_376.Invoke_O__O(arg_377) } else { tmp15 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_70; var tmp2 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_71; var tmp4 any; var root_378 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_380 lang.IFn; if
													linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = pkg_scope__0; var arg_382 any = A_arbace_go_check_A_const_73; if linked_379 == nil { tmp4 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp4 = linked_379.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_74; var tmp7 any; var root_383 any = /*line :101:1*/A_arbace_go_check_A_const_75.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_385 lang.IFn; if


	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var or__1927000174__auto____4 any; var root_387 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = fi__1; var arg_391 any = A_arbace_go_check_A_const_77; if linked_388 == nil { or__1927000174__auto____4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { or__1927000174__auto____4 = linked_388.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_386 = or__1927000174__auto____4 } else { arg_386 = A_arbace_go_check_A_const_74.Invoke_O__O(config__2) }; if linked_384 == nil { tmp7 = ifn_385.Invoke_O__O(arg_386) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_384.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_383, arg_386)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_78; var tmp10 any; var root_392 any = /*line :101:1*/A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_394 lang.IFn; if



	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_go_check_A_const_73.Invoke_O__O(fi__1); if linked_393 == nil { tmp10 = ifn_394.Invoke_O__O(arg_395) } else { tmp10 = linked_393.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_392, arg_395) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_80; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_80; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_81.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_82; var tmp16 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_83; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_84; var tmp20 any; var root_396 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_398 lang.IFn; if





	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.PersistentVector_EMPTY.Ref(); if linked_397 == nil { tmp20 = ifn_398.Invoke_O__O(arg_399) } else { tmp20 = linked_397.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_396, arg_399) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_85; var tmp23 any; var root_400 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_402 lang.IFn; if





	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.PersistentVector_EMPTY.Ref(); if linked_401 == nil { tmp23 = ifn_402.Invoke_O__O(arg_403) } else { tmp23 = linked_401.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_400, arg_403) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__502d; tmp1 = fncls__502d } else { tmp1 = fncls__502 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_503 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_A_const_84.Invoke_O__O(fi__0); if linked_508 == nil { arg_506 = ifn_509.Invoke_O__O(arg_510) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_507, arg_510) }; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__561d; tmp3 = fncls__561d } else { tmp3 = fncls__561 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_404 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_406 lang.IFn
	if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = f__1; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_404, arg_407) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_408 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = f__1; if linked_409 == nil { temp__1927000414__auto____2 = ifn_410.Invoke_O__O(arg_411) } else { temp__1927000414__auto____2 = linked_409.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_470 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_472 lang.IFn
			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_go_check_A_const_71.Invoke_O__O(t.F_fi); var arg_474 any = q__3; if linked_471 == nil { temp__1927000414__auto____4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { temp__1927000414__auto____4 = linked_471.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_91; var tmp3 any; var root_475 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_477 lang.IFn
				if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__5; var arg_479 any = A_arbace_go_check_A_const_93; if linked_476 == nil { tmp3 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp3 = linked_476.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_480 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = x__5; var arg_484 any = A_arbace_go_check_A_const_89; var arg_485 any = jrt.Boolean_TRUE.Ref(); if linked_481 == nil { ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp5 any; var root_412 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_414 lang.IFn


			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; if linked_413 == nil { tmp5 = ifn_414.Invoke_O__O(arg_415) } else { tmp5 = linked_413.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_412, arg_415) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_416 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_418 lang.IFn; _ = ___6; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = imp__7; var arg_420 any = A_arbace_go_check_A_const_89; var arg_421 any = jrt.Boolean_TRUE.Ref(); if linked_417 == nil { ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { linked_417.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } } } else {
//line :113:1
				var tmp6 any; var root_422 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_424 lang.IFn




				if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp6 = ifn_424.Invoke_O__O(arg_425) } else { tmp6 = linked_423.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_422, arg_425) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_426 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn




					if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = f__1; if linked_427 == nil { seq_1685000052__2 = ifn_428.Invoke_O__O(arg_429) } else { seq_1685000052__2 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1685000052__2; if linked_431 == nil { temp__1927000414__auto____6 = ifn_432.Invoke_O__O(arg_433) } else { temp__1927000414__auto____6 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1685000052__7; if linked_435 == nil { tmp7 = ifn_436.Invoke_O__O(arg_437) } else { tmp7 = linked_435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_1685000052__7; if linked_439 == nil { c__1927000678__auto____8 = ifn_440.Invoke_O__O(arg_441) } else { c__1927000678__auto____8 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_438, arg_441) }; var tmp8 any; var root_486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1685000052__7; if linked_487 == nil { tmp8 = ifn_488.Invoke_O__O(arg_489) } else { tmp8 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1685000052__7; if linked_443 == nil { x__8 = ifn_444.Invoke_O__O(arg_445) } else { x__8 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_1685000052__7; if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_490, arg_493) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_446 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_448 lang.IFn





							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; if linked_447 == nil { tmp10 = ifn_448.Invoke_O__O(arg_449) } else { tmp10 = linked_447.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_446, arg_449) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_450 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn





								if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = f__1; if linked_451 == nil { seq_1685000056__2 = ifn_452.Invoke_O__O(arg_453) } else { seq_1685000056__2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1685000056__2; if linked_455 == nil { temp__1927000414__auto____6_2 = ifn_456.Invoke_O__O(arg_457) } else { temp__1927000414__auto____6_2 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_458 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1685000056__7; if linked_459 == nil { tmp11 = ifn_460.Invoke_O__O(arg_461) } else { tmp11 = linked_459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_462 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1685000056__7; if linked_463 == nil { c__1927000678__auto____8_2 = ifn_464.Invoke_O__O(arg_465) } else { c__1927000678__auto____8_2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_462, arg_465) }; var tmp12 any; var root_494 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1685000056__7; if linked_495 == nil { tmp12 = ifn_496.Invoke_O__O(arg_497) } else { tmp12 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_466 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1685000056__7; if linked_467 == nil { x__8_2 = ifn_468.Invoke_O__O(arg_469) } else { x__8_2 = linked_467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_466, arg_469) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1685000056__7; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_511 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_513 lang.IFn
		if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = f__1; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp3 any; var root_515 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn
			if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__1; if linked_516 == nil { tmp3 = ifn_517.Invoke_O__O(arg_518) } else { tmp3 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_521 lang.IFn; _ = ___4; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = imp__5; var arg_523 any = A_arbace_go_check_A_const_89; var arg_524 any = jrt.Boolean_TRUE.Ref(); if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_525 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_527 lang.IFn

				if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { or__1927000174__auto____2 = ifn_527.Invoke_O__O(arg_528) } else { or__1927000174__auto____2 = linked_526.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_529 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_529, arg_532) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__1; if linked_534 == nil { seq_1685000065__2 = ifn_535.Invoke_O__O(arg_536) } else { seq_1685000065__2 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1685000065__2; if linked_538 == nil { temp__1927000414__auto____6 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000414__auto____6 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1685000065__7; if linked_542 == nil { tmp5 = ifn_543.Invoke_O__O(arg_544) } else { tmp5 = linked_542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_541, arg_544) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = seq_1685000065__7; if linked_546 == nil { c__1927000678__auto____8 = ifn_547.Invoke_O__O(arg_548) } else { c__1927000678__auto____8 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_545, arg_548) }; var tmp6 any; var root_553 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = seq_1685000065__7; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1685000065__7; if linked_550 == nil { x__8 = ifn_551.Invoke_O__O(arg_552) } else { x__8 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_557 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1685000065__7; if linked_558 == nil { tmp7 = ifn_559.Invoke_O__O(arg_560) } else { tmp7 = linked_558.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_557, arg_560) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_98); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp6 any; var root_682 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = d__0; if linked_683 == nil { tmp6 = ifn_684.Invoke_O__O(arg_685) } else { tmp6 = linked_683.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_99; var tmp8 any; var root_674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { tmp8 = ifn_676.Invoke_O__O(arg_677) } else { tmp8 = linked_675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_674, arg_677) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp10 any; var root_678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = d__0; if linked_679 == nil { tmp10 = ifn_680.Invoke_O__O(arg_681) } else { tmp10 = linked_679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_678, arg_681) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_564 lang.IFn
		if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = f__1; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_566 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = f__1; if linked_567 == nil { tmp2 = ifn_568.Invoke_O__O(arg_569) } else { tmp2 = linked_567.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_566, arg_569) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_572 lang.IFn

			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = t.F_pkg_scope; var arg_574 any; var root_575 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = f__1; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_575, arg_578) }; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_94); var tmp4 any; var root_634 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_636 lang.IFn
				if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__3; var arg_638 any = A_arbace_go_check_A_const_93; if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp4 = linked_635.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_579 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_583 any = A_arbace_go_check_A_const_95; var arg_584 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_585 any = x__3; if linked_580 == nil { tmp6 = ifn_581.Invoke_O_O_O_O__O(arg_582, arg_583, arg_584, arg_585) } else { tmp6 = linked_580.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_579, arg_582, arg_583, arg_584, arg_585) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_586 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_588 lang.IFn




								if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = f__1; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_586, arg_589) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_639 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_641 lang.IFn




									if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = f__1; if linked_640 == nil { temp__1927000414__auto____2_2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2_2 = linked_640.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_643 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_645 lang.IFn
										if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = h__3; var arg_647 any = Lit_136; if linked_644 == nil { and__1927000168__auto____4 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { and__1927000168__auto____4 = linked_644.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_648 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = h__3; var arg_656 any = Lit_154; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { and__1927000168__auto____5 = ifn_650.Invoke_O__O(arg_651) } else { and__1927000168__auto____5 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn








									if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { seq_1685000072__2 = ifn_592.Invoke_O__O(arg_593) } else { seq_1685000072__2 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_1685000072__2; if linked_595 == nil { temp__1927000414__auto____6 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____6 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_1685000072__7; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_1685000072__7; if linked_603 == nil { c__1927000678__auto____8 = ifn_604.Invoke_O__O(arg_605) } else { c__1927000678__auto____8 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_602, arg_605) }; var tmp10 any; var root_657 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1685000072__7; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_657, arg_660) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1685000072__7; if linked_607 == nil { x__8 = ifn_608.Invoke_O__O(arg_609) } else { x__8 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_661 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1685000072__7; if linked_662 == nil { tmp11 = ifn_663.Invoke_O__O(arg_664) } else { tmp11 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_610 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_612 lang.IFn









											if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = f__1; if linked_611 == nil { tmp12 = ifn_612.Invoke_O__O(arg_613) } else { tmp12 = linked_611.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_610, arg_613) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_614 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn









												if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = f__1; if linked_615 == nil { seq_1685000076__2 = ifn_616.Invoke_O__O(arg_617) } else { seq_1685000076__2 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_1685000076__2; if linked_619 == nil { temp__1927000414__auto____6_2 = ifn_620.Invoke_O__O(arg_621) } else { temp__1927000414__auto____6_2 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_622 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_1685000076__7; if linked_623 == nil { tmp13 = ifn_624.Invoke_O__O(arg_625) } else { tmp13 = linked_623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_626 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = seq_1685000076__7; if linked_627 == nil { c__1927000678__auto____8_2 = ifn_628.Invoke_O__O(arg_629) } else { c__1927000678__auto____8_2 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any; var root_665 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1685000076__7; if linked_666 == nil { tmp14 = ifn_667.Invoke_O__O(arg_668) } else { tmp14 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_630 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1685000076__7; if linked_631 == nil { x__8_2 = ifn_632.Invoke_O__O(arg_633) } else { x__8_2 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_669 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = seq_1685000076__7; if linked_670 == nil { tmp15 = ifn_671.Invoke_O__O(arg_672) } else { tmp15 = linked_670.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_669, arg_672) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_number_local_types_BANG__A_New() *A_arbace_go_check_number_local_types_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Invoke_O_O__O(self, lts__0 any) any { { var sorted__2 any; var root_686 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_688 lang.IFn





	if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any; var tmp1 any = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New(); var tmp2 *jrt.Class; var fncls__691 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class; if fncls__691 == nil { var fncls__691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class = fncls__691d; tmp2 = fncls__691d } else { tmp2 = fncls__691 }; arg_689 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_690 any; var root_692 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any; var tmp3 any = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New(); var tmp4 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class = fncls__697d; tmp4 = fncls__697d } else { tmp4 = fncls__697 }; arg_695 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_696 any = lts__0; if linked_693 == nil { arg_690 = ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { arg_690 = linked_693.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }; if linked_687 == nil { sorted__2 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { sorted__2 = linked_687.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }
//line :151:1
	var seq_1685000094__3 any; var root_698 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_700 lang.IFn






	if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any; var root_702 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var arg_706 any = sorted__2; if linked_703 == nil { arg_701 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_699 == nil { seq_1685000094__3 = ifn_700.Invoke_O__O(arg_701) } else { seq_1685000094__3 = linked_699.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_698, arg_701) }
//line :151:1
	var chunk_1685000095__4 any; var count_1685000096__5 int64 = 0; var i_1685000097__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000097__6, count_1685000096__5) { var vec__1685000098__7 any = lang.Indexed_Cast(chunk_1685000095__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000097__6)); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000101__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_104.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var tmp7 any = A_arbace_go_check_A_const_106; var tmp8 jrt.Number_I; var na_730 any = n__8; _ = ___10
			if jrt.Long_InstanceOf(na_730) { var n0_731 int64 = jrt.NN(jrt.Long_Cast(na_730)).LongValue__J(); if n0_731 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_730) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_731 + 1)) } } else { if jrt.Double_InstanceOf(na_730) { var n0_731_2 float64 = jrt.NN(jrt.Double_Cast(na_730)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_731_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_730) } }; tmp5.Invoke_O_O_O_O__O(nt__11, tmp6, tmp7, tmp8)
//line :158:1
			seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000097__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_707 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = seq_1685000094__3; if linked_708 == nil { temp__1927000414__auto____7 = ifn_709.Invoke_O__O(arg_710) } else { temp__1927000414__auto____7 = linked_708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_707, arg_710) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000094__8 any = temp__1927000414__auto____7; var tmp9 any; var root_711 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = seq_1685000094__8; if linked_712 == nil { tmp9 = ifn_713.Invoke_O__O(arg_714) } else { tmp9 = linked_712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____9 any; var root_715 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = seq_1685000094__8; if linked_716 == nil { c__1927000678__auto____9 = ifn_717.Invoke_O__O(arg_718) } else { c__1927000678__auto____9 = linked_716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_715, arg_718) }; var tmp10 any; var root_732 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = seq_1685000094__8; if linked_733 == nil { tmp10 = ifn_734.Invoke_O__O(arg_735) } else { tmp10 = linked_733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_732, arg_735) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp10, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000104__9 any; var root_719 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = seq_1685000094__8; if linked_720 == nil { vec__1685000104__9 = ifn_721.Invoke_O__O(arg_722) } else { vec__1685000104__9 = linked_720.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_719, arg_722) }; var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000107__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(1), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_104.GetRawRoot__O()); var tmp12 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var tmp13 any = A_arbace_go_check_A_const_106; var tmp14 jrt.Number_I; var na_743 any = n__10; _ = ___12
				if jrt.Long_InstanceOf(na_743) { var n0_744 int64 = jrt.NN(jrt.Long_Cast(na_743)).LongValue__J(); if n0_744 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_743) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_744 + 1)) } } else { if jrt.Double_InstanceOf(na_743) { var n0_744_2 float64 = jrt.NN(jrt.Double_Cast(na_743)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_744_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_743) } }; tmp11.Invoke_O_O_O_O__O(nt__13, tmp12, tmp13, tmp14)
//line :158:1
				var tmp15 any; var root_745 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = seq_1685000094__8; if linked_746 == nil { tmp15 = ifn_747.Invoke_O__O(arg_748) } else { tmp15 = linked_746.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_745, arg_748) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :151:1*/panic("j2g: unreachable") }





func A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000083_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Invoke_O_O__O(self, p__1685000082__1 any) any { var vec__1685000084__2 any = p__1685000082__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(id__3, k__5) }
//line :157:1
func A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000089_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Invoke_O_O_O__O(self, k__1, p__1685000088__2 any) any { var vec__1685000090__3 any = p__1685000088__2; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(id__4, nt__5, k__1) }



func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000126__2 any) any { var map__1685000127__4 any = p__1685000126__2; var map__1685000127__5 any; if lang.ISeq_InstanceOf(map__1685000127__4) { var tmp1 any; var root_749 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = map__1685000127__4; if linked_750 == nil { tmp1 = ifn_751.Invoke_O__O(arg_752) } else { tmp1 = linked_750.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_753 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = map__1685000127__4; if linked_754 == nil { tmp2 = ifn_755.Invoke_O__O(arg_756) } else { tmp2 = linked_754.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_753, arg_756) }; map__1685000127__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_757 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = map__1685000127__4; if linked_758 == nil { tmp3 = ifn_759.Invoke_O__O(arg_760) } else { tmp3 = linked_758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_757, arg_760) }; if jrt.J2g_Truth(tmp3) { var root_761 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = map__1685000127__4; if linked_762 == nil { map__1685000127__5 = ifn_763.Invoke_O__O(arg_764) } else { map__1685000127__5 = linked_762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_761, arg_764) } } else { map__1685000127__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000127__5 = map__1685000127__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000127__5, A_arbace_go_check_A_const_108); var pkg_scope__7 any; var root_765 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_767 lang.IFn; if




	linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var arg_769 any = A_arbace_go_check_A_const_109; if linked_766 == nil { pkg_scope__7 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { pkg_scope__7 = linked_766.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; var pkg__8 any; var root_770 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_772 lang.IFn; if





	linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var tmp4 any = A_arbace_go_check_A_const_110; var tmp5 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_70; var tmp7 any = A_arbace_go_check_A_const_70.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_71; var tmp9 any = A_arbace_go_check_A_const_111; var tmp10 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp11 any = A_arbace_go_check_A_const_112; var tmp12 any; var root_774 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_776 lang.IFn; if
	linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = lang.PersistentVector_EMPTY.Ref(); if linked_775 == nil { tmp12 = ifn_776.Invoke_O__O(arg_777) } else { tmp12 = linked_775.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_774, arg_777) }; arg_773 = /*line :167:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, tmp10, tmp11, tmp12)); if linked_771 == nil { pkg__8 = ifn_772.Invoke_O__O(arg_773) } else { pkg__8 = linked_771.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_770, arg_773) }; var errors__9 any; var root_778 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_780 lang.IFn; if







	linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = lang.PersistentVector_EMPTY.Ref(); if linked_779 == nil { errors__9 = ifn_780.Invoke_O__O(arg_781) } else { errors__9 = linked_779.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_778, arg_781) }; var resolving__10 any; var root_782 any = /*line :161:1*/A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_784 lang.IFn; if










	linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_783 == nil { resolving__10 = ifn_784.Invoke_O__O(arg_785) } else { resolving__10 = linked_783.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_782, arg_785) }; var annotated__11 any; var and__1927000168__auto____11 any; var root_786 any = /*line :161:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_788 lang.IFn; if











	linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = A_arbace_go_check_A_const_81.Invoke_O__O(src__0); var arg_790 any = A_arbace_go_check_A_const_115; if linked_787 == nil { and__1927000168__auto____11 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { and__1927000168__auto____11 = linked_787.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_791 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = resolving__10; if linked_792 == nil { annotated__11 = ifn_793.Invoke_O__O(arg_794) } else { annotated__11 = linked_792.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_791, arg_794) } } else { annotated__11 = and__1927000168__auto____11 }; var ctx__12 any; var tmp13 any = A_arbace_go_check_A_const_116; var tmp14 any; var root_795 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_797 lang.IFn; if












	linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = lang.PersistentVector_EMPTY.Ref(); if linked_796 == nil { tmp14 = ifn_797.Invoke_O__O(arg_798) } else { tmp14 = linked_796.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_795, arg_798) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_117; var tmp17 any; var root_799 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_801 lang.IFn; if












	linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_800 == nil { tmp17 = ifn_801.Invoke_O__O(arg_802) } else { tmp17 = linked_800.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_799, arg_802) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_118; var tmp20 any; var root_803 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_805 lang.IFn; if












	linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = lang.PersistentVector_EMPTY.Ref(); if linked_804 == nil { tmp20 = ifn_805.Invoke_O__O(arg_806) } else { tmp20 = linked_804.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_803, arg_806) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_119; var tmp23 any; var root_807 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_809 lang.IFn; if












	linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = lang.PersistentVector_EMPTY.Ref(); if linked_808 == nil { tmp23 = ifn_809.Invoke_O__O(arg_810) } else { tmp23 = linked_808.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_807, arg_810) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_go_check_A_const_120; ctx__12 = /*line :161:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__11, A_arbace_go_check_A_const_121, resolving__10)))); var fis__13 any; var root_811 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_813 lang.IFn; if














	linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any; var tmp26 any = A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(src__0, pkg_scope__7); var tmp27 *jrt.Class; var fncls__822 *jrt.Class = A_arbace_go_check_check_package_fn__1685000129_A_fn_class; if fncls__822 == nil { var fncls__822d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000129_A_fn_class = fncls__822d; tmp27 = fncls__822d } else { tmp27 = fncls__822 }; arg_814 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_815 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__0); if linked_812 == nil { fis__13 = ifn_813.Invoke_O_O__O(arg_814, arg_815) } else { fis__13 = linked_812.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_811, arg_814, arg_815) }; var root_1280 any =
	A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp29 any = A_arbace_go_check_A_const_170; var tmp30 any = A_arbace_go_check_A_const_171; var tmp31 any = A_arbace_go_check_A_const_172; var tmp32 any = jrt.IdentityHashMap_New(); var tmp33 any = A_arbace_go_check_A_const_173; var tmp34 any = A_arbace_go_check_A_const_174; var tmp35 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); var tmp36 any = A_arbace_go_check_A_const_175; var tmp37 any = A_arbace_go_check_A_const_61; var tmp38 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__11, A_arbace_go_check_A_const_121, resolving__10)); var tmp39 any = A_arbace_go_check_A_const_176; var tmp40 any = A_arbace_go_check_A_const_177.GetRawRoot__O(); var tmp41 any = A_arbace_go_check_A_const_178; var tmp42 any = A_arbace_go_check_A_const_179.GetRawRoot__O(); var tmp43 any = A_arbace_go_check_A_const_180; var tmp44 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp45 any = A_arbace_go_check_A_const_181; var tmp46 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var tmp47 any = A_arbace_go_check_A_const_183; var tmp48 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var tmp49 any = A_arbace_go_check_A_const_185; var tmp50 any = A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp51 *jrt.Class; var fncls__1288 *jrt.Class = A_arbace_go_check_check_package_fn__1685000131_A_fn_class; if











	fncls__1288 == nil { var fncls__1288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000131_A_fn_class = fncls__1288d; tmp51 = fncls__1288d } else { tmp51 = fncls__1288 }; var tmp52 any = /*line :177:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil); var tmp53 any = A_arbace_go_check_A_const_187; var tmp54 any = A_arbace_go_check_A_const_188.GetRawRoot__O(); var tmp55 any = A_arbace_go_check_A_const_189; var tmp56 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var tmp57 any = A_arbace_go_check_A_const_191; var tmp58 any = A_arbace_go_check_A_const_192.GetRawRoot__O(); var tmp59 any = A_arbace_go_check_A_const_193; var tmp60 any; var root_1289 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1291 lang.IFn; if
















	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.PersistentVector_EMPTY.Ref(); if linked_1290 == nil { tmp60 = ifn_1291.Invoke_O__O(arg_1292) } else { tmp60 = linked_1290.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1289, arg_1292) }; var tmp61 any = tmp60; var tmp62 any = A_arbace_go_check_A_const_194; var tmp63 any; var root_1293 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1295 lang.IFn; if

















	linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_195, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_196, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_197, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_198, lang.PersistentArrayMap_EMPTY.Ref())); if linked_1294 == nil { tmp63 = ifn_1295.Invoke_O__O(arg_1296) } else { tmp63 = linked_1294.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1293, arg_1296) }; var tmp64 any = tmp63; var tmp65 any = A_arbace_go_check_A_const_199; var tmp66 any; var root_1297 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1299 lang.IFn; if


















	linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = lang.PersistentVector_EMPTY.Ref(); if linked_1298 == nil { tmp66 = ifn_1299.Invoke_O__O(arg_1300) } else { tmp66 = linked_1298.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1297, arg_1300) }; arg_1283 = /*line :177:1*/tmp28.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp29, pkg__8, tmp30, errors__9, tmp31, tmp32, tmp33, ctx__12, tmp34, tmp35, tmp36, resolving__10, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp52, tmp53, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp61, tmp62, tmp64, tmp65, tmp66)))); if linked_1281 == nil { ifn_1282.Invoke_O__O(arg_1283) } else { linked_1281.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1280, arg_1283) }; var tmp67 any; tmp327 := /*line :161:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000133__16 any; var root_1301 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1303 lang.IFn



































		if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = fis__13; if linked_1302 == nil { seq_1685000133__16 = ifn_1303.Invoke_O__O(arg_1304) } else { seq_1685000133__16 = linked_1302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1301, arg_1304) }
//line :161:1
		var chunk_1685000134__17 any; var count_1685000135__18 int64 = 0; var i_1685000136__19 int64 = 0; L1: for {



































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000136__19, count_1685000135__18) { var fi__20 any = lang.Indexed_Cast(chunk_1685000134__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000136__19)); var root_1364 any = A_arbace_go_check_A_const_201.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = fi__20; var arg_1368 any = resolve__1; if linked_1365 == nil { ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { linked_1365.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000136__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_1305 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = seq_1685000133__16; if linked_1306 == nil { temp__1927000414__auto____20 = ifn_1307.Invoke_O__O(arg_1308) } else { temp__1927000414__auto____20 = linked_1306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1305, arg_1308) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000133__21 any = temp__1927000414__auto____20; var tmp68 any; var root_1309 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = seq_1685000133__21; if linked_1310 == nil { tmp68 = ifn_1311.Invoke_O__O(arg_1312) } else { tmp68 = linked_1310.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1309, arg_1312) }; if jrt.J2g_Truth(tmp68) { var c__1927000678__auto____22 any; var root_1313 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = seq_1685000133__21; if linked_1314 == nil { c__1927000678__auto____22 = ifn_1315.Invoke_O__O(arg_1316) } else { c__1927000678__auto____22 = linked_1314.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1313, arg_1316) }; var tmp69 any; var root_1369 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = seq_1685000133__21; if linked_1370 == nil { tmp69 = ifn_1371.Invoke_O__O(arg_1372) } else { tmp69 = linked_1370.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1369, arg_1372) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp69, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__22 any; var root_1317 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = seq_1685000133__21; if linked_1318 == nil { fi__22 = ifn_1319.Invoke_O__O(arg_1320) } else { fi__22 = linked_1318.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1317, arg_1320) }; var root_1373 any = A_arbace_go_check_A_const_201.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = fi__22; var arg_1377 any = resolve__1; if linked_1374 == nil { ifn_1375.Invoke_O_O__O(arg_1376, arg_1377) } else { linked_1374.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1373, arg_1376, arg_1377) }; var tmp70 any; var root_1378 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = seq_1685000133__21; if linked_1379 == nil { tmp70 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp70 = linked_1379.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1378, arg_1381) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp70, nil, 0, 0; continue L1 } } }
//line :161:1
			break L1 }; var seq_1685000137__16 any; var root_1321 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1323 lang.IFn




































		if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = fis__13; if linked_1322 == nil { seq_1685000137__16 = ifn_1323.Invoke_O__O(arg_1324) } else { seq_1685000137__16 = linked_1322.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1321, arg_1324) }
//line :161:1
		var chunk_1685000138__17 any; var count_1685000139__18 int64 = 0; var i_1685000140__19 int64 = 0; L2: for {




































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000140__19, count_1685000139__18) { var fi__20_2 any = lang.Indexed_Cast(chunk_1685000138__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000140__19)); var root_1382 any = A_arbace_go_check_A_const_202.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = fi__20_2; if linked_1383 == nil { ifn_1384.Invoke_O__O(arg_1385) } else { linked_1383.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1382, arg_1385) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000140__19); continue L2 } else { var temp__1927000414__auto____20_2 any; var root_1325 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = seq_1685000137__16; if linked_1326 == nil { temp__1927000414__auto____20_2 = ifn_1327.Invoke_O__O(arg_1328) } else { temp__1927000414__auto____20_2 = linked_1326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1325, arg_1328) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000137__21 any = temp__1927000414__auto____20_2; var tmp71 any; var root_1329 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = seq_1685000137__21; if linked_1330 == nil { tmp71 = ifn_1331.Invoke_O__O(arg_1332) } else { tmp71 = linked_1330.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1329, arg_1332) }; if jrt.J2g_Truth(tmp71) { var c__1927000678__auto____22_2 any; var root_1333 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = seq_1685000137__21; if linked_1334 == nil { c__1927000678__auto____22_2 = ifn_1335.Invoke_O__O(arg_1336) } else { c__1927000678__auto____22_2 = linked_1334.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1333, arg_1336) }; var tmp72 any; var root_1386 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = seq_1685000137__21; if linked_1387 == nil { tmp72 = ifn_1388.Invoke_O__O(arg_1389) } else { tmp72 = linked_1387.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1386, arg_1389) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp72, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__22_2 any; var root_1337 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = seq_1685000137__21; if linked_1338 == nil { fi__22_2 = ifn_1339.Invoke_O__O(arg_1340) } else { fi__22_2 = linked_1338.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1337, arg_1340) }; var root_1390 any = A_arbace_go_check_A_const_202.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = fi__22_2; if linked_1391 == nil { ifn_1392.Invoke_O__O(arg_1393) } else { linked_1391.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1390, arg_1393) }; var tmp73 any; var root_1394 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = seq_1685000137__21; if linked_1395 == nil { tmp73 = ifn_1396.Invoke_O__O(arg_1397) } else { tmp73 = linked_1395.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1394, arg_1397) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp73, nil, 0, 0; continue L2 } } }
//line :161:1
			break L2 }; var seq_1685000141__16 any; var root_1341 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1343 lang.IFn





































		if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = fis__13; if linked_1342 == nil { seq_1685000141__16 = ifn_1343.Invoke_O__O(arg_1344) } else { seq_1685000141__16 = linked_1342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1341, arg_1344) }
//line :161:1
		var chunk_1685000142__17 any; var count_1685000143__18 int64 = 0; var i_1685000144__19 int64 = 0; L3: for {





































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000144__19, count_1685000143__18) { var fi__20_3 any = lang.Indexed_Cast(chunk_1685000142__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000144__19)); var root_1398 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = fi__20_3; if linked_1399 == nil { ifn_1400.Invoke_O__O(arg_1401) } else { linked_1399.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1398, arg_1401) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000144__19); continue L3 } else { var temp__1927000414__auto____20_3 any; var root_1345 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = seq_1685000141__16; if linked_1346 == nil { temp__1927000414__auto____20_3 = ifn_1347.Invoke_O__O(arg_1348) } else { temp__1927000414__auto____20_3 = linked_1346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1345, arg_1348) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000141__21 any = temp__1927000414__auto____20_3; var tmp74 any; var root_1349 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = seq_1685000141__21; if linked_1350 == nil { tmp74 = ifn_1351.Invoke_O__O(arg_1352) } else { tmp74 = linked_1350.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1349, arg_1352) }; if jrt.J2g_Truth(tmp74) { var c__1927000678__auto____22_3 any; var root_1353 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = seq_1685000141__21; if linked_1354 == nil { c__1927000678__auto____22_3 = ifn_1355.Invoke_O__O(arg_1356) } else { c__1927000678__auto____22_3 = linked_1354.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1353, arg_1356) }; var tmp75 any; var root_1402 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = seq_1685000141__21; if linked_1403 == nil { tmp75 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp75 = linked_1403.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1402, arg_1405) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp75, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__22_3 any; var root_1357 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = seq_1685000141__21; if linked_1358 == nil { fi__22_3 = ifn_1359.Invoke_O__O(arg_1360) } else { fi__22_3 = linked_1358.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1357, arg_1360) }; var root_1406 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = fi__22_3; if linked_1407 == nil { ifn_1408.Invoke_O__O(arg_1409) } else { linked_1407.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1406, arg_1409) }; var tmp76 any; var root_1410 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = seq_1685000141__21; if linked_1411 == nil { tmp76 = ifn_1412.Invoke_O__O(arg_1413) } else { tmp76 = linked_1411.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1410, arg_1413) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp76, nil, 0, 0; continue L3 } } }
//line :161:1
			break L3
		}





































		var root_1361 any = A_arbace_go_check_A_const_200.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; if linked_1362 == nil { ifn_1363.Invoke__O() } else { linked_1362.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1361) }
//line :161:1
		var objs__16 any; var root_823 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_825 lang.IFn







































		if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = A_arbace_go_check_A_const_116.Invoke_O__O(ctx__12); if linked_824 == nil { objs__16 = ifn_825.Invoke_O__O(arg_826) } else { objs__16 = linked_824.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_823, arg_826) }
//line :161:1
		var seq_1685000145__17 any; var root_1414 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1416 lang.IFn








































		if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any; var root_1418 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var arg_1422 any = objs__16; if linked_1419 == nil { arg_1417 = ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { arg_1417 = linked_1419.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) }; if linked_1415 == nil { seq_1685000145__17 = ifn_1416.Invoke_O__O(arg_1417) } else { seq_1685000145__17 = linked_1415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1414, arg_1417) }
//line :161:1
		var chunk_1685000146__18 any; var count_1685000147__19 int64 = 0; var i_1685000148__20 int64 = 0; L4: for {








































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000148__20, count_1685000147__19) { var vec__1685000149__21 any = lang.Indexed_Cast(chunk_1685000146__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000148__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000149__21, lang.RT_IntCast_J__I_NoInit(0), nil); var x__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000149__21, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1616 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = x__23; var arg_1620 any = A_arbace_go_check_A_const_207; var arg_1621 any = i__22; if linked_1617 == nil { ifn_1618.Invoke_O_O_O__O(arg_1619, arg_1620, arg_1621) } else { linked_1617.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1616, arg_1619, arg_1620, arg_1621) }; seq_1685000145__17, chunk_1685000146__18, count_1685000147__19, i_1685000148__20 = seq_1685000145__17, chunk_1685000146__18, count_1685000147__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000148__20); continue L4 } else { var temp__1927000414__auto____21 any; var root_1423 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = seq_1685000145__17; if linked_1424 == nil { temp__1927000414__auto____21 = ifn_1425.Invoke_O__O(arg_1426) } else { temp__1927000414__auto____21 = linked_1424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1423, arg_1426) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000145__22 any = temp__1927000414__auto____21; var tmp77 any; var root_1427 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = seq_1685000145__22; if linked_1428 == nil { tmp77 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp77 = linked_1428.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1427, arg_1430) }; if jrt.J2g_Truth(tmp77) { var c__1927000678__auto____23 any; var root_1431 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = seq_1685000145__22; if linked_1432 == nil { c__1927000678__auto____23 = ifn_1433.Invoke_O__O(arg_1434) } else { c__1927000678__auto____23 = linked_1432.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1431, arg_1434) }; var tmp78 any; var root_1622 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = seq_1685000145__22; if linked_1623 == nil { tmp78 = ifn_1624.Invoke_O__O(arg_1625) } else { tmp78 = linked_1623.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1622, arg_1625) }; seq_1685000145__17, chunk_1685000146__18, count_1685000147__19, i_1685000148__20 = tmp78, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1685000152__23 any; var root_1435 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = seq_1685000145__22; if linked_1436 == nil { vec__1685000152__23 = ifn_1437.Invoke_O__O(arg_1438) } else { vec__1685000152__23 = linked_1436.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1435, arg_1438) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000152__23, lang.RT_IntCast_J__I_NoInit(0), nil); var x__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000152__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1626 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = x__25; var arg_1630 any = A_arbace_go_check_A_const_207; var arg_1631 any = i__24; if linked_1627 == nil { ifn_1628.Invoke_O_O_O__O(arg_1629, arg_1630, arg_1631) } else { linked_1627.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1626, arg_1629, arg_1630, arg_1631) }; var tmp79 any; var root_1632 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = seq_1685000145__22; if linked_1633 == nil { tmp79 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp79 = linked_1633.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1632, arg_1635) }; seq_1685000145__17, chunk_1685000146__18, count_1685000147__19, i_1685000148__20 = tmp79, nil, 0, 0; continue L4 } } }
//line :161:1
			break L4
		}









































		var root_1439 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = objs__16; if linked_1440 == nil { ifn_1441.Invoke_O__O(arg_1442) } else { linked_1440.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A).Invoke_O_O__O(root_1439, arg_1442) }
//line :161:1
		var seq_1685000155__17 any; var root_1443 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1445 lang.IFn












































		if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = objs__16; if linked_1444 == nil { seq_1685000155__17 = ifn_1445.Invoke_O__O(arg_1446) } else { seq_1685000155__17 = linked_1444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1443, arg_1446) }
//line :161:1
		var chunk_1685000156__18 any; var count_1685000157__19 int64 = 0; var i_1685000158__20 int64 = 0; L5: for {












































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000158__20, count_1685000157__19) { var x__21 any = lang.Indexed_Cast(chunk_1685000156__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000158__20)); var tmp80 any; var and__1927000168__auto____22 bool; var tmp81 any = A_arbace_go_check_A_const_54; var tmp82 any; var root_1447 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = x__21; var arg_1451 any = A_arbace_go_check_A_const_93; if linked_1448 == nil { tmp82 = ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { tmp82 = linked_1448.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) }; and__1927000168__auto____22 = lang.Util_Equiv_O_O__Z_NoInit(tmp81, tmp82); if and__1927000168__auto____22 { var root_1452 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any; var root_1456 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = x__21; var arg_1460 any = A_arbace_go_check_A_const_205; if linked_1457 == nil { arg_1455 = ifn_1458.Invoke_O_O__O(arg_1459, arg_1460) } else { arg_1455 = linked_1457.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1456, arg_1459, arg_1460) }; if linked_1453 == nil { tmp80 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp80 = linked_1453.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1452, arg_1455) } } else { tmp80 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22).Ref() }; if jrt.J2g_Truth(tmp80) { var root_1636 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = x__21; if linked_1637 == nil { ifn_1638.Invoke_O__O(arg_1639) } else { linked_1637.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1636, arg_1639) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000158__20); continue L5 } else { seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000158__20); continue L5 } } else { var temp__1927000414__auto____21_2 any; var root_1461 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = seq_1685000155__17; if linked_1462 == nil { temp__1927000414__auto____21_2 = ifn_1463.Invoke_O__O(arg_1464) } else { temp__1927000414__auto____21_2 = linked_1462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1461, arg_1464) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000155__22 any = temp__1927000414__auto____21_2; var tmp83 any; var root_1465 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = seq_1685000155__22; if linked_1466 == nil { tmp83 = ifn_1467.Invoke_O__O(arg_1468) } else { tmp83 = linked_1466.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1465, arg_1468) }; if jrt.J2g_Truth(tmp83) { var c__1927000678__auto____23_2 any; var root_1469 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = seq_1685000155__22; if linked_1470 == nil { c__1927000678__auto____23_2 = ifn_1471.Invoke_O__O(arg_1472) } else { c__1927000678__auto____23_2 = linked_1470.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1469, arg_1472) }; var tmp84 any; var root_1640 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = seq_1685000155__22; if linked_1641 == nil { tmp84 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp84 = linked_1641.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1640, arg_1643) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = tmp84, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var x__23_2 any; var root_1473 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = seq_1685000155__22; if linked_1474 == nil { x__23_2 = ifn_1475.Invoke_O__O(arg_1476) } else { x__23_2 = linked_1474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1473, arg_1476) }; var tmp85 any; var and__1927000168__auto____24 bool; var tmp86 any = A_arbace_go_check_A_const_54; var tmp87 any; var root_1477 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = x__23_2; var arg_1481 any = A_arbace_go_check_A_const_93; if linked_1478 == nil { tmp87 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { tmp87 = linked_1478.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) }; and__1927000168__auto____24 = lang.Util_Equiv_O_O__Z_NoInit(tmp86, tmp87); if and__1927000168__auto____24 { var root_1482 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any; var root_1486 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = x__23_2; var arg_1490 any = A_arbace_go_check_A_const_205; if linked_1487 == nil { arg_1485 = ifn_1488.Invoke_O_O__O(arg_1489, arg_1490) } else { arg_1485 = linked_1487.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1486, arg_1489, arg_1490) }; if linked_1483 == nil { tmp85 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp85 = linked_1483.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1482, arg_1485) } } else { tmp85 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24).Ref() }; if jrt.J2g_Truth(tmp85) { var root_1644 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = x__23_2; if linked_1645 == nil { ifn_1646.Invoke_O__O(arg_1647) } else { linked_1645.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1644, arg_1647) }; var tmp88 any; var root_1648 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = seq_1685000155__22; if linked_1649 == nil { tmp88 = ifn_1650.Invoke_O__O(arg_1651) } else { tmp88 = linked_1649.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1648, arg_1651) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = tmp88, nil, 0, 0; continue L5 } else { var tmp89 any; var root_1652 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = seq_1685000155__22; if linked_1653 == nil { tmp89 = ifn_1654.Invoke_O__O(arg_1655) } else { tmp89 = linked_1653.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1652, arg_1655) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = tmp89, nil, 0, 0; continue L5 } } } }
//line :161:1
			break L5 }; var seq_1685000159__17 any; var root_1491 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1493 lang.IFn













































		if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = objs__16; if linked_1492 == nil { seq_1685000159__17 = ifn_1493.Invoke_O__O(arg_1494) } else { seq_1685000159__17 = linked_1492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1491, arg_1494) }
//line :161:1
		var chunk_1685000160__18 any; var count_1685000161__19 int64 = 0; var i_1685000162__20 int64 = 0; L6: for {













































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000162__20, count_1685000161__19) { var x__21_2 any = lang.Indexed_Cast(chunk_1685000160__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000162__20)); var tmp90 any; var and__1927000168__auto____22_2 bool; var tmp91 any = A_arbace_go_check_A_const_54; var tmp92 any; var root_1495 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = x__21_2; var arg_1499 any = A_arbace_go_check_A_const_93; if linked_1496 == nil { tmp92 = ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { tmp92 = linked_1496.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) }; and__1927000168__auto____22_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp91, tmp92); if and__1927000168__auto____22_2 { var root_1500 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = x__21_2; var arg_1504 any = A_arbace_go_check_A_const_205; if linked_1501 == nil { tmp90 = ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { tmp90 = linked_1501.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) } } else { tmp90 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22_2).Ref() }; if jrt.J2g_Truth(tmp90) { var root_1656 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = x__21_2; if linked_1657 == nil { ifn_1658.Invoke_O__O(arg_1659) } else { linked_1657.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1656, arg_1659) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } else { seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } } else { var temp__1927000414__auto____21_3 any; var root_1505 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = seq_1685000159__17; if linked_1506 == nil { temp__1927000414__auto____21_3 = ifn_1507.Invoke_O__O(arg_1508) } else { temp__1927000414__auto____21_3 = linked_1506.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1505, arg_1508) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000159__22 any = temp__1927000414__auto____21_3; var tmp93 any; var root_1509 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = seq_1685000159__22; if linked_1510 == nil { tmp93 = ifn_1511.Invoke_O__O(arg_1512) } else { tmp93 = linked_1510.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1509, arg_1512) }; if jrt.J2g_Truth(tmp93) { var c__1927000678__auto____23_3 any; var root_1513 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = seq_1685000159__22; if linked_1514 == nil { c__1927000678__auto____23_3 = ifn_1515.Invoke_O__O(arg_1516) } else { c__1927000678__auto____23_3 = linked_1514.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1513, arg_1516) }; var tmp94 any; var root_1660 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = seq_1685000159__22; if linked_1661 == nil { tmp94 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp94 = linked_1661.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1660, arg_1663) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp94, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__23_3 any; var root_1517 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = seq_1685000159__22; if linked_1518 == nil { x__23_3 = ifn_1519.Invoke_O__O(arg_1520) } else { x__23_3 = linked_1518.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1517, arg_1520) }; var tmp95 any; var and__1927000168__auto____24_2 bool; var tmp96 any = A_arbace_go_check_A_const_54; var tmp97 any; var root_1521 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = x__23_3; var arg_1525 any = A_arbace_go_check_A_const_93; if linked_1522 == nil { tmp97 = ifn_1523.Invoke_O_O__O(arg_1524, arg_1525) } else { tmp97 = linked_1522.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1521, arg_1524, arg_1525) }; and__1927000168__auto____24_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp96, tmp97); if and__1927000168__auto____24_2 { var root_1526 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = x__23_3; var arg_1530 any = A_arbace_go_check_A_const_205; if linked_1527 == nil { tmp95 = ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { tmp95 = linked_1527.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) } } else { tmp95 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24_2).Ref() }; if jrt.J2g_Truth(tmp95) { var root_1664 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = x__23_3; if linked_1665 == nil { ifn_1666.Invoke_O__O(arg_1667) } else { linked_1665.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1664, arg_1667) }; var tmp98 any; var root_1668 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = seq_1685000159__22; if linked_1669 == nil { tmp98 = ifn_1670.Invoke_O__O(arg_1671) } else { tmp98 = linked_1669.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1668, arg_1671) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp98, nil, 0, 0; continue L6 } else { var tmp99 any; var root_1672 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = seq_1685000159__22; if linked_1673 == nil { tmp99 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp99 = linked_1673.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1672, arg_1675) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp99, nil, 0, 0; continue L6 } } } }
//line :161:1
			break L6 }; var seq_1685000163__17 any; var root_1531 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1533 lang.IFn














































		if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = objs__16; if linked_1532 == nil { seq_1685000163__17 = ifn_1533.Invoke_O__O(arg_1534) } else { seq_1685000163__17 = linked_1532.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1531, arg_1534) }
//line :161:1
		var chunk_1685000164__18 any; var count_1685000165__19 int64 = 0; var i_1685000166__20 int64 = 0; L7: for {














































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000166__20, count_1685000165__19) { var x__21_3 any = lang.Indexed_Cast(chunk_1685000164__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000166__20)); var tmp100 any; var root_1535 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = A_arbace_go_check_A_const_54; var arg_1539 any; var root_1540 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = x__21_3; var arg_1544 any = A_arbace_go_check_A_const_93; if linked_1541 == nil { arg_1539 = ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { arg_1539 = linked_1541.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }; if linked_1536 == nil { tmp100 = ifn_1537.Invoke_O_O__O(arg_1538, arg_1539) } else { tmp100 = linked_1536.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1535, arg_1538, arg_1539) }; if jrt.J2g_Truth(tmp100) { var root_1676 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = x__21_3; if linked_1677 == nil { ifn_1678.Invoke_O__O(arg_1679) } else { linked_1677.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1676, arg_1679) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } else { seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } } else { var temp__1927000414__auto____21_4 any; var root_1545 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = seq_1685000163__17; if linked_1546 == nil { temp__1927000414__auto____21_4 = ifn_1547.Invoke_O__O(arg_1548) } else { temp__1927000414__auto____21_4 = linked_1546.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1545, arg_1548) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000163__22 any = temp__1927000414__auto____21_4; var tmp101 any; var root_1549 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = seq_1685000163__22; if linked_1550 == nil { tmp101 = ifn_1551.Invoke_O__O(arg_1552) } else { tmp101 = linked_1550.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1549, arg_1552) }; if jrt.J2g_Truth(tmp101) { var c__1927000678__auto____23_4 any; var root_1553 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = seq_1685000163__22; if linked_1554 == nil { c__1927000678__auto____23_4 = ifn_1555.Invoke_O__O(arg_1556) } else { c__1927000678__auto____23_4 = linked_1554.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1553, arg_1556) }; var tmp102 any; var root_1680 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = seq_1685000163__22; if linked_1681 == nil { tmp102 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp102 = linked_1681.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1680, arg_1683) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp102, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__23_4 any; var root_1557 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = seq_1685000163__22; if linked_1558 == nil { x__23_4 = ifn_1559.Invoke_O__O(arg_1560) } else { x__23_4 = linked_1558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1557, arg_1560) }; var tmp103 any; var root_1561 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = A_arbace_go_check_A_const_54; var arg_1565 any; var root_1566 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = x__23_4; var arg_1570 any = A_arbace_go_check_A_const_93; if linked_1567 == nil { arg_1565 = ifn_1568.Invoke_O_O__O(arg_1569, arg_1570) } else { arg_1565 = linked_1567.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1566, arg_1569, arg_1570) }; if linked_1562 == nil { tmp103 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { tmp103 = linked_1562.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; if jrt.J2g_Truth(tmp103) { var root_1684 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = x__23_4; if linked_1685 == nil { ifn_1686.Invoke_O__O(arg_1687) } else { linked_1685.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1684, arg_1687) }; var tmp104 any; var root_1688 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = seq_1685000163__22; if linked_1689 == nil { tmp104 = ifn_1690.Invoke_O__O(arg_1691) } else { tmp104 = linked_1689.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1688, arg_1691) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp104, nil, 0, 0; continue L7 } else { var tmp105 any; var root_1692 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = seq_1685000163__22; if linked_1693 == nil { tmp105 = ifn_1694.Invoke_O__O(arg_1695) } else { tmp105 = linked_1693.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1692, arg_1695) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp105, nil, 0, 0; continue L7 } } } }
//line :161:1
			break L7 }; var seq_1685000167__17 any; var root_1571 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1573 lang.IFn
















































		if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any; var root_1575 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = A_arbace_go_check_A_const_118.Invoke_O__O(ctx__12); if linked_1576 == nil { arg_1574 = ifn_1577.Invoke_O__O(arg_1578) } else { arg_1574 = linked_1576.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1575, arg_1578) }; if linked_1572 == nil { seq_1685000167__17 = ifn_1573.Invoke_O__O(arg_1574) } else { seq_1685000167__17 = linked_1572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1571, arg_1574) }
//line :161:1
		var chunk_1685000168__18 any; var count_1685000169__19 int64 = 0; var i_1685000170__20 int64 = 0; L8: for {
















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000170__20, count_1685000169__19) { var x__21_4 any = lang.Indexed_Cast(chunk_1685000168__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000170__20)); var root_1696 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = x__21_4; if linked_1697 == nil { ifn_1698.Invoke_O__O(arg_1699) } else { linked_1697.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1696, arg_1699) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } else { var temp__1927000414__auto____21_5 any; var root_1579 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = seq_1685000167__17; if linked_1580 == nil { temp__1927000414__auto____21_5 = ifn_1581.Invoke_O__O(arg_1582) } else { temp__1927000414__auto____21_5 = linked_1580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1579, arg_1582) }; if jrt.J2g_Truth(temp__1927000414__auto____21_5) { var seq_1685000167__22 any = temp__1927000414__auto____21_5; var tmp106 any; var root_1583 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = seq_1685000167__22; if linked_1584 == nil { tmp106 = ifn_1585.Invoke_O__O(arg_1586) } else { tmp106 = linked_1584.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1583, arg_1586) }; if jrt.J2g_Truth(tmp106) { var c__1927000678__auto____23_5 any; var root_1587 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = seq_1685000167__22; if linked_1588 == nil { c__1927000678__auto____23_5 = ifn_1589.Invoke_O__O(arg_1590) } else { c__1927000678__auto____23_5 = linked_1588.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1587, arg_1590) }; var tmp107 any; var root_1700 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = seq_1685000167__22; if linked_1701 == nil { tmp107 = ifn_1702.Invoke_O__O(arg_1703) } else { tmp107 = linked_1701.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1700, arg_1703) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp107, c__1927000678__auto____23_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__23_5 any; var root_1591 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = seq_1685000167__22; if linked_1592 == nil { x__23_5 = ifn_1593.Invoke_O__O(arg_1594) } else { x__23_5 = linked_1592.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1591, arg_1594) }; var root_1704 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = x__23_5; if linked_1705 == nil { ifn_1706.Invoke_O__O(arg_1707) } else { linked_1705.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1704, arg_1707) }; var tmp108 any; var root_1708 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = seq_1685000167__22; if linked_1709 == nil { tmp108 = ifn_1710.Invoke_O__O(arg_1711) } else { tmp108 = linked_1709.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1708, arg_1711) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp108, nil, 0, 0; continue L8 } } }
//line :161:1
			break L8 }; L9: for { var vs__17 any; var root_1595 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1597 lang.IFn



















































				if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = A_arbace_go_check_A_const_193.Get__O(); if linked_1596 == nil { vs__17 = ifn_1597.Invoke_O__O(arg_1598) } else { vs__17 = linked_1596.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1595, arg_1598) }
				var tmp109 any; var root_1599 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = vs__17; if linked_1600 == nil { tmp109 = ifn_1601.Invoke_O__O(arg_1602) } else { tmp109 = linked_1600.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1599, arg_1602) }; if jrt.J2g_Truth(tmp109) {
					var root_1712 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = A_arbace_go_check_A_const_193.Get__O(); var arg_1716 any = lang.PersistentVector_EMPTY.Ref(); if linked_1713 == nil { ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { linked_1713.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) }
//line :214:1
					var seq_1685000171__18 any; var root_1717 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1719 lang.IFn

					if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = vs__17; if linked_1718 == nil { seq_1685000171__18 = ifn_1719.Invoke_O__O(arg_1720) } else { seq_1685000171__18 = linked_1718.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1717, arg_1720) }
//line :214:1
					var chunk_1685000172__19 any; var count_1685000173__20 int64 = 0; var i_1685000174__21 int64 = 0; L10: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000174__21, count_1685000173__20) { var v__22 any = lang.Indexed_Cast(chunk_1685000172__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000174__21)); lang.IFn_Cast(v__22).Invoke__O(); seq_1685000171__18, chunk_1685000172__19, count_1685000173__20, i_1685000174__21 = seq_1685000171__18, chunk_1685000172__19, count_1685000173__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000174__21); continue L10 } else { var temp__1927000414__auto____22 any; var root_1721 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = seq_1685000171__18; if linked_1722 == nil { temp__1927000414__auto____22 = ifn_1723.Invoke_O__O(arg_1724) } else { temp__1927000414__auto____22 = linked_1722.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1721, arg_1724) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1685000171__23 any = temp__1927000414__auto____22; var tmp110 any; var root_1725 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = seq_1685000171__23; if linked_1726 == nil { tmp110 = ifn_1727.Invoke_O__O(arg_1728) } else { tmp110 = linked_1726.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1725, arg_1728) }; if jrt.J2g_Truth(tmp110) { var c__1927000678__auto____24 any; var root_1729 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = seq_1685000171__23; if linked_1730 == nil { c__1927000678__auto____24 = ifn_1731.Invoke_O__O(arg_1732) } else { c__1927000678__auto____24 = linked_1730.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1729, arg_1732) }; var tmp111 any; var root_1737 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = seq_1685000171__23; if linked_1738 == nil { tmp111 = ifn_1739.Invoke_O__O(arg_1740) } else { tmp111 = linked_1738.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1737, arg_1740) }; seq_1685000171__18, chunk_1685000172__19, count_1685000173__20, i_1685000174__21 = tmp111, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L10 } else { var v__24 any; var root_1733 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = seq_1685000171__23; if linked_1734 == nil { v__24 = ifn_1735.Invoke_O__O(arg_1736) } else { v__24 = linked_1734.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1733, arg_1736) }; lang.IFn_Cast(v__24).Invoke__O(); var tmp112 any; var root_1741 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = seq_1685000171__23; if linked_1742 == nil { tmp112 = ifn_1743.Invoke_O__O(arg_1744) } else { tmp112 = linked_1742.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1741, arg_1744) }; seq_1685000171__18, chunk_1685000172__19, count_1685000173__20, i_1685000174__21 = tmp112, nil, 0, 0; continue L10 } } }
//line :214:1
						break L10
					}

					continue L9 }
//line :161:1
				break L9
			}























































		var root_1603 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, A_arbace_go_check_number_local_types_BANG__A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any; var root_1607 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any; var root_1611 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = pkg__8; var arg_1615 any = A_arbace_go_check_A_const_112; if linked_1612 == nil { arg_1610 = ifn_1613.Invoke_O_O__O(arg_1614, arg_1615) } else { arg_1610 = linked_1612.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1611, arg_1614, arg_1615) }; if linked_1608 == nil { arg_1606 = ifn_1609.Invoke_O__O(arg_1610) } else { arg_1606 = linked_1608.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1607, arg_1610) }; if linked_1604 == nil { ifn_1605.Invoke_O__O(arg_1606) } else { linked_1604.(*A_arbace_go_check_number_local_types_BANG__A).Invoke_O_O__O(root_1603, arg_1606) }
//line :161:1
		var decls__17 any; var root_827 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_829 lang.IFn

























































		if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any; var root_831 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var tmp113 any = A_arbace_go_check_check_package_fn__1685000175_A_New(); var tmp114 *jrt.Class; var fncls__841 *jrt.Class = A_arbace_go_check_check_package_fn__1685000175_A_fn_class; if fncls__841 == nil { var fncls__841d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_check_check_package_fn__1685000175_A_fn_class = fncls__841d; tmp114 = fncls__841d } else { tmp114 = fncls__841 }; arg_834 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp113, tmp114, nil); var arg_835 any = objs__16; if linked_832 == nil { arg_830 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { arg_830 = linked_832.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) }; if linked_828 == nil { decls__17 = ifn_829.Invoke_O__O(arg_830) } else { decls__17 = linked_828.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_827, arg_830) }
//line :161:1
		var seq_1685000177__18 any; var root_1745 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1747 lang.IFn


























































		if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any = decls__17; if linked_1746 == nil { seq_1685000177__18 = ifn_1747.Invoke_O__O(arg_1748) } else { seq_1685000177__18 = linked_1746.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1745, arg_1748) }
//line :161:1
		var chunk_1685000178__19 any; var count_1685000179__20 int64 = 0; var i_1685000180__21 int64 = 0; L11: for {


























































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000180__21, count_1685000179__20) { var d__22 any = lang.Indexed_Cast(chunk_1685000178__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000180__21)); L12: for { var ls__23 any; var tmp115 *lang.Keyword = A_arbace_go_check_A_const_211; var tmp116 any; var root_1869 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1871 lang.IFn

				if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = d__22; if linked_1870 == nil { tmp116 = ifn_1871.Invoke_O__O(arg_1872) } else { tmp116 = linked_1870.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1869, arg_1872) }; ls__23 = tmp115.Invoke_O__O(tmp116)
				var tmp117 any; var root_1873 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = ls__23; if linked_1874 == nil { tmp117 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp117 = linked_1874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1873, arg_1876) }; if jrt.J2g_Truth(tmp117) {
					var tmp118 *lang.Volatile = lang.Volatile_Cast(d__22); var tmp119 any; var root_1877 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = jrt.NN(lang.Volatile_Cast(d__22)).Deref__O(); var arg_1881 any = A_arbace_go_check_A_const_211; var arg_1882 any = lang.PersistentVector_EMPTY.Ref(); if linked_1878 == nil { tmp119 = ifn_1879.Invoke_O_O_O__O(arg_1880, arg_1881, arg_1882) } else { tmp119 = linked_1878.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1877, arg_1880, arg_1881, arg_1882) }; jrt.NN(tmp118).Reset_O__O(tmp119)
					var root_1929 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any; var tmp120 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp121 any = A_arbace_go_check_A_const_215; var tmp122 any = A_arbace_go_check_A_const_216; var tmp123 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp124 any; var root_1942 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = d__22; if linked_1943 == nil { tmp124 = ifn_1944.Invoke_O__O(arg_1945) } else { tmp124 = linked_1943.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1942, arg_1945) }; var tmp125 any = tmp123.Invoke_O__O(tmp124); var tmp126 any = A_arbace_go_check_A_const_217; var tmp127 any; var G__1685000181__24_ any; var tmp128 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp129 any; var root_1946 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = d__22; if linked_1947 == nil { tmp129 = ifn_1948.Invoke_O__O(arg_1949) } else { tmp129 = linked_1947.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1946, arg_1949) }; G__1685000181__24_ = tmp128.Invoke_O__O(tmp129); if lang.Util_Identical_O_O__Z_NoInit(G__1685000181__24_, nil) { tmp127 = nil } else { var root_1950 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = G__1685000181__24_; var arg_1954 any = A_arbace_go_check_A_const_78; if linked_1951 == nil { tmp127 = ifn_1952.Invoke_O_O__O(arg_1953, arg_1954) } else { tmp127 = linked_1951.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1950, arg_1953, arg_1954) } }; arg_1932 = tmp120.Invoke_O_O_O_O_O_O__O(tmp121, d__22, tmp122, tmp125, tmp126, tmp127); if linked_1930 == nil { ifn_1931.Invoke_O__O(arg_1932) } else { linked_1930.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1929, arg_1932) }; var tmp130 any = A_arbace_go_check_check_package_fn__1685000182_A_New_O_O(d__22, ls__23); var tmp131 *jrt.Class; var fncls__1928 *jrt.Class = A_arbace_go_check_check_package_fn__1685000182_A_fn_class; if fncls__1928 == nil { var fncls__1928d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_check_check_package_fn__1685000182_A_fn_class = fncls__1928d; tmp131 = fncls__1928d } else { tmp131 = fncls__1928 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp130, tmp131, nil).Invoke__O()


					continue L12 }
//line :220:1
				break L12 }; seq_1685000177__18, chunk_1685000178__19, count_1685000179__20, i_1685000180__21 = seq_1685000177__18, chunk_1685000178__19, count_1685000179__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000180__21); continue L11 } else { var temp__1927000414__auto____22_2 any; var root_1749 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = seq_1685000177__18; if linked_1750 == nil { temp__1927000414__auto____22_2 = ifn_1751.Invoke_O__O(arg_1752) } else { temp__1927000414__auto____22_2 = linked_1750.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1749, arg_1752) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1685000177__23 any = temp__1927000414__auto____22_2; var tmp132 any; var root_1753 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = seq_1685000177__23; if linked_1754 == nil { tmp132 = ifn_1755.Invoke_O__O(arg_1756) } else { tmp132 = linked_1754.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1753, arg_1756) }; if jrt.J2g_Truth(tmp132) { var c__1927000678__auto____24_2 any; var root_1757 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = seq_1685000177__23; if linked_1758 == nil { c__1927000678__auto____24_2 = ifn_1759.Invoke_O__O(arg_1760) } else { c__1927000678__auto____24_2 = linked_1758.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1757, arg_1760) }; var tmp133 any; var root_1955 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = seq_1685000177__23; if linked_1956 == nil { tmp133 = ifn_1957.Invoke_O__O(arg_1958) } else { tmp133 = linked_1956.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1955, arg_1958) }; seq_1685000177__18, chunk_1685000178__19, count_1685000179__20, i_1685000180__21 = tmp133, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var d__24 any; var root_1761 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = seq_1685000177__23; if linked_1762 == nil { d__24 = ifn_1763.Invoke_O__O(arg_1764) } else { d__24 = linked_1762.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1761, arg_1764) }; L13: for { var ls__25 any; var tmp134 *lang.Keyword = A_arbace_go_check_A_const_211; var tmp135 any; var root_1959 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1961 lang.IFn

					if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = d__24; if linked_1960 == nil { tmp135 = ifn_1961.Invoke_O__O(arg_1962) } else { tmp135 = linked_1960.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1959, arg_1962) }; ls__25 = tmp134.Invoke_O__O(tmp135)
					var tmp136 any; var root_1963 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = ls__25; if linked_1964 == nil { tmp136 = ifn_1965.Invoke_O__O(arg_1966) } else { tmp136 = linked_1964.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1963, arg_1966) }; if jrt.J2g_Truth(tmp136) {
						var tmp137 *lang.Volatile = lang.Volatile_Cast(d__24); var tmp138 any; var root_1967 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1967, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any = jrt.NN(lang.Volatile_Cast(d__24)).Deref__O(); var arg_1971 any = A_arbace_go_check_A_const_211; var arg_1972 any = lang.PersistentVector_EMPTY.Ref(); if linked_1968 == nil { tmp138 = ifn_1969.Invoke_O_O_O__O(arg_1970, arg_1971, arg_1972) } else { tmp138 = linked_1968.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1967, arg_1970, arg_1971, arg_1972) }; jrt.NN(tmp137).Reset_O__O(tmp138)
						var root_2019 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any; var tmp139 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp140 any = A_arbace_go_check_A_const_215; var tmp141 any = A_arbace_go_check_A_const_216; var tmp142 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp143 any; var root_2032 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = d__24; if linked_2033 == nil { tmp143 = ifn_2034.Invoke_O__O(arg_2035) } else { tmp143 = linked_2033.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2032, arg_2035) }; var tmp144 any = tmp142.Invoke_O__O(tmp143); var tmp145 any = A_arbace_go_check_A_const_217; var tmp146 any; var G__1685000188__26_ any; var tmp147 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp148 any; var root_2036 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = d__24; if linked_2037 == nil { tmp148 = ifn_2038.Invoke_O__O(arg_2039) } else { tmp148 = linked_2037.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2036, arg_2039) }; G__1685000188__26_ = tmp147.Invoke_O__O(tmp148); if lang.Util_Identical_O_O__Z_NoInit(G__1685000188__26_, nil) { tmp146 = nil } else { var root_2040 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = G__1685000188__26_; var arg_2044 any = A_arbace_go_check_A_const_78; if linked_2041 == nil { tmp146 = ifn_2042.Invoke_O_O__O(arg_2043, arg_2044) } else { tmp146 = linked_2041.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2040, arg_2043, arg_2044) } }; arg_2022 = tmp139.Invoke_O_O_O_O_O_O__O(tmp140, d__24, tmp141, tmp144, tmp145, tmp146); if linked_2020 == nil { ifn_2021.Invoke_O__O(arg_2022) } else { linked_2020.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2019, arg_2022) }; var tmp149 any = A_arbace_go_check_check_package_fn__1685000189_A_New_O_O(d__24, ls__25); var tmp150 *jrt.Class; var fncls__2018 *jrt.Class = A_arbace_go_check_check_package_fn__1685000189_A_fn_class; if fncls__2018 == nil { var fncls__2018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_check_package_fn__1685000189_A_fn_class = fncls__2018d; tmp150 = fncls__2018d } else { tmp150 = fncls__2018 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp149, tmp150, nil).Invoke__O()


						continue L13 }
//line :220:1
					break L13 }; var tmp151 any; var root_2045 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2047 lang.IFn; if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = seq_1685000177__23; if linked_2046 == nil { tmp151 = ifn_2047.Invoke_O__O(arg_2048) } else { tmp151 = linked_2046.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2045, arg_2048) }; seq_1685000177__18, chunk_1685000178__19, count_1685000179__20, i_1685000180__21 = tmp151, nil, 0, 0; continue L11 } } }
//line :161:1
			break L11 }; var seq_1685000195__18 any; var root_1765 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1767 lang.IFn




































































		if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = decls__17; if linked_1766 == nil { seq_1685000195__18 = ifn_1767.Invoke_O__O(arg_1768) } else { seq_1685000195__18 = linked_1766.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1765, arg_1768) }
//line :161:1
		var chunk_1685000196__19 any; var count_1685000197__20 int64 = 0; var i_1685000198__21 int64 = 0; L14: for {




































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000198__21, count_1685000197__20) { var d__22_2 any = lang.Indexed_Cast(chunk_1685000196__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000198__21)); var tmp152 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp153 any; var root_1769 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = d__22_2; if linked_1770 == nil { tmp153 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp153 = linked_1770.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1769, arg_1772) }; if jrt.J2g_Truth(tmp152.Invoke_O__O(tmp153)) {
				var root_2061 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any; var tmp154 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp155 any = A_arbace_go_check_A_const_215; var tmp156 any = A_arbace_go_check_A_const_216; var tmp157 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp158 any; var root_2072 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = d__22_2; if linked_2073 == nil { tmp158 = ifn_2074.Invoke_O__O(arg_2075) } else { tmp158 = linked_2073.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2072, arg_2075) }; arg_2064 = tmp154.Invoke_O_O_O_O__O(tmp155, d__22_2, tmp156, tmp157.Invoke_O__O(tmp158)); if linked_2062 == nil { ifn_2063.Invoke_O__O(arg_2064) } else { linked_2062.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2061, arg_2064) }; var tmp159 any = A_arbace_go_check_check_package_fn__1685000199_A_New_O(d__22_2); var tmp160 *jrt.Class; var fncls__2060 *jrt.Class = A_arbace_go_check_check_package_fn__1685000199_A_fn_class; if fncls__2060 == nil { var fncls__2060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_fn__1685000199_A_fn_class = fncls__2060d; tmp160 = fncls__2060d } else { tmp160 = fncls__2060 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp159, tmp160, nil).Invoke__O()
//line :230:1
				seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, i_1685000198__21 = seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000198__21); continue L14 } else { seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, i_1685000198__21 = seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000198__21); continue L14 } } else { var temp__1927000414__auto____22_3 any; var root_1773 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = seq_1685000195__18; if linked_1774 == nil { temp__1927000414__auto____22_3 = ifn_1775.Invoke_O__O(arg_1776) } else { temp__1927000414__auto____22_3 = linked_1774.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1773, arg_1776) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1685000195__23 any = temp__1927000414__auto____22_3; var tmp161 any; var root_1777 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = seq_1685000195__23; if linked_1778 == nil { tmp161 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp161 = linked_1778.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1777, arg_1780) }; if jrt.J2g_Truth(tmp161) { var c__1927000678__auto____24_3 any; var root_1781 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = seq_1685000195__23; if linked_1782 == nil { c__1927000678__auto____24_3 = ifn_1783.Invoke_O__O(arg_1784) } else { c__1927000678__auto____24_3 = linked_1782.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1781, arg_1784) }; var tmp162 any; var root_2076 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = seq_1685000195__23; if linked_2077 == nil { tmp162 = ifn_2078.Invoke_O__O(arg_2079) } else { tmp162 = linked_2077.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2076, arg_2079) }; seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, i_1685000198__21 = tmp162, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var d__24_2 any; var root_1785 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = seq_1685000195__23; if linked_1786 == nil { d__24_2 = ifn_1787.Invoke_O__O(arg_1788) } else { d__24_2 = linked_1786.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1785, arg_1788) }; var tmp163 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp164 any; var root_1789 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = d__24_2; if linked_1790 == nil { tmp164 = ifn_1791.Invoke_O__O(arg_1792) } else { tmp164 = linked_1790.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1789, arg_1792) }; if jrt.J2g_Truth(tmp163.Invoke_O__O(tmp164)) {
					var root_2092 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any; var tmp165 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp166 any = A_arbace_go_check_A_const_215; var tmp167 any = A_arbace_go_check_A_const_216; var tmp168 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp169 any; var root_2103 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = d__24_2; if linked_2104 == nil { tmp169 = ifn_2105.Invoke_O__O(arg_2106) } else { tmp169 = linked_2104.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2103, arg_2106) }; arg_2095 = tmp165.Invoke_O_O_O_O__O(tmp166, d__24_2, tmp167, tmp168.Invoke_O__O(tmp169)); if linked_2093 == nil { ifn_2094.Invoke_O__O(arg_2095) } else { linked_2093.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2092, arg_2095) }; var tmp170 any = A_arbace_go_check_check_package_fn__1685000201_A_New_O(d__24_2); var tmp171 *jrt.Class; var fncls__2091 *jrt.Class = A_arbace_go_check_check_package_fn__1685000201_A_fn_class; if fncls__2091 == nil { var fncls__2091d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_check_check_package_fn__1685000201_A_fn_class = fncls__2091d; tmp171 = fncls__2091d } else { tmp171 = fncls__2091 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp170, tmp171, nil).Invoke__O()
//line :230:1
					var tmp172 any; var root_2107 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2109 lang.IFn; if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = seq_1685000195__23; if linked_2108 == nil { tmp172 = ifn_2109.Invoke_O__O(arg_2110) } else { tmp172 = linked_2108.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2107, arg_2110) }; seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, i_1685000198__21 = tmp172, nil, 0, 0; continue L14 } else { var tmp173 any; var root_2111 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = seq_1685000195__23; if linked_2112 == nil { tmp173 = ifn_2113.Invoke_O__O(arg_2114) } else { tmp173 = linked_2112.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2111, arg_2114) }; seq_1685000195__18, chunk_1685000196__19, count_1685000197__20, i_1685000198__21 = tmp173, nil, 0, 0; continue L14 } } } }
//line :161:1
			break L14
		}








































































		if jrt.J2g_Truth(resolving__10) { var seq_1685000203__18 any; var root_1793 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1795 lang.IFn
			if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = decls__17; if linked_1794 == nil { seq_1685000203__18 = ifn_1795.Invoke_O__O(arg_1796) } else { seq_1685000203__18 = linked_1794.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1793, arg_1796) }
//line :235:1
			var chunk_1685000204__19 any; var count_1685000205__20 int64 = 0; var i_1685000206__21 int64 = 0; L15: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000206__21, count_1685000205__20) { var d__22_3 any = lang.Indexed_Cast(chunk_1685000204__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000206__21)); var tmp174 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp175 any; var root_1797 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = d__22_3; if linked_1798 == nil { tmp175 = ifn_1799.Invoke_O__O(arg_1800) } else { tmp175 = linked_1798.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1797, arg_1800) }; if jrt.J2g_Truth(tmp174.Invoke_O__O(tmp175)) { var seq_1685000211__23 any; var root_2115 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any; var root_2119 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2121 lang.IFn
					if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any; var tmp176 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp177 any; var root_2123 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = d__22_3; if linked_2124 == nil { tmp177 = ifn_2125.Invoke_O__O(arg_2126) } else { tmp177 = linked_2124.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2123, arg_2126) }; arg_2122 = tmp176.Invoke_O__O(tmp177); if linked_2120 == nil { arg_2118 = ifn_2121.Invoke_O__O(arg_2122) } else { arg_2118 = linked_2120.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2119, arg_2122) }
//line :236:1
					if linked_2116 == nil { seq_1685000211__23 = ifn_2117.Invoke_O__O(arg_2118) } else { seq_1685000211__23 = linked_2116.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2115, arg_2118) }; var chunk_1685000212__24 any; var count_1685000213__25 int64 = 0; var i_1685000214__26 int64 = 0; L16: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000214__26, count_1685000213__25) { var n__27 any = lang.Indexed_Cast(chunk_1685000212__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000214__26)); var tmp178 any; var tmp179 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____28 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp179, A_arbace_go_check_A_const_50.Invoke_O__O(n__27))

						if and__1927000168__auto____28 { tmp178 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__27)) } else { tmp178 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____28).Ref() }
//line :236:1
						if jrt.J2g_Truth(tmp178) {


							var root_2143 any = A_arbace_go_check_A_const_220.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__27); var arg_2147 any; var tmp180 any = A_arbace_go_check_A_const_221; var tmp181 any = A_arbace_go_check_A_const_221.Invoke_O__O(n__27); var tmp182 any = A_arbace_go_check_A_const_54; var G__1685000215__28_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp180, tmp181, tmp182, A_arbace_go_check_A_const_54.Invoke_O__O(n__27), A_arbace_go_check_A_const_222, jrt.Boolean_TRUE.Ref())); var tmp183 *lang.Keyword = A_arbace_go_check_A_const_223; if jrt.J2g_Truth(tmp183.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__27))) {

								var root_2148 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = G__1685000215__28_; var arg_2152 any = A_arbace_go_check_A_const_224; var arg_2153 any = jrt.Boolean_TRUE.Ref(); if linked_2149 == nil { arg_2147 = ifn_2150.Invoke_O_O_O__O(arg_2151, arg_2152, arg_2153) } else { arg_2147 = linked_2149.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2148, arg_2151, arg_2152, arg_2153) } } else {
//line :239:1
									arg_2147 = G__1685000215__28_ }; if linked_2144 == nil { ifn_2145.Invoke_O_O__O(arg_2146, arg_2147) } else { linked_2144.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2143, arg_2146, arg_2147) }
//line :236:1
							seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, i_1685000214__26 = seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__26); continue L16 } else { seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, i_1685000214__26 = seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__26); continue L16 } } else { var temp__1927000414__auto____27 any; var root_2127 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = seq_1685000211__23; if linked_2128 == nil { temp__1927000414__auto____27 = ifn_2129.Invoke_O__O(arg_2130) } else { temp__1927000414__auto____27 = linked_2128.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2127, arg_2130) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var seq_1685000211__28 any = temp__1927000414__auto____27; var tmp184 any; var root_2131 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any = seq_1685000211__28; if linked_2132 == nil { tmp184 = ifn_2133.Invoke_O__O(arg_2134) } else { tmp184 = linked_2132.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2131, arg_2134) }; if jrt.J2g_Truth(tmp184) { var c__1927000678__auto____29 any; var root_2135 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = seq_1685000211__28; if linked_2136 == nil { c__1927000678__auto____29 = ifn_2137.Invoke_O__O(arg_2138) } else { c__1927000678__auto____29 = linked_2136.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2135, arg_2138) }; var tmp185 any; var root_2154 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = seq_1685000211__28; if linked_2155 == nil { tmp185 = ifn_2156.Invoke_O__O(arg_2157) } else { tmp185 = linked_2155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2154, arg_2157) }; seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, i_1685000214__26 = tmp185, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var n__29 any; var root_2139 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = seq_1685000211__28; if linked_2140 == nil { n__29 = ifn_2141.Invoke_O__O(arg_2142) } else { n__29 = linked_2140.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2139, arg_2142) }; var tmp186 any; var tmp187 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____30 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp187, A_arbace_go_check_A_const_50.Invoke_O__O(n__29))

								if and__1927000168__auto____30 { tmp186 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__29)) } else { tmp186 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30).Ref() }
//line :236:1
								if jrt.J2g_Truth(tmp186) {


									var root_2158 any = A_arbace_go_check_A_const_220.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__29); var arg_2162 any; var tmp188 any = A_arbace_go_check_A_const_221; var tmp189 any = A_arbace_go_check_A_const_221.Invoke_O__O(n__29); var tmp190 any = A_arbace_go_check_A_const_54; var G__1685000216__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp188, tmp189, tmp190, A_arbace_go_check_A_const_54.Invoke_O__O(n__29), A_arbace_go_check_A_const_222, jrt.Boolean_TRUE.Ref())); var tmp191 *lang.Keyword = A_arbace_go_check_A_const_223; if jrt.J2g_Truth(tmp191.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__29))) {

										var root_2163 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = G__1685000216__30_; var arg_2167 any = A_arbace_go_check_A_const_224; var arg_2168 any = jrt.Boolean_TRUE.Ref(); if linked_2164 == nil { arg_2162 = ifn_2165.Invoke_O_O_O__O(arg_2166, arg_2167, arg_2168) } else { arg_2162 = linked_2164.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2163, arg_2166, arg_2167, arg_2168) } } else {
//line :239:1
											arg_2162 = G__1685000216__30_ }; if linked_2159 == nil { ifn_2160.Invoke_O_O__O(arg_2161, arg_2162) } else { linked_2159.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2158, arg_2161, arg_2162) }
//line :236:1
									var tmp192 any; var root_2169 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2171 lang.IFn; if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any = seq_1685000211__28; if linked_2170 == nil { tmp192 = ifn_2171.Invoke_O__O(arg_2172) } else { tmp192 = linked_2170.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2169, arg_2172) }; seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, i_1685000214__26 = tmp192, nil, 0, 0; continue L16 } else { var tmp193 any; var root_2173 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = seq_1685000211__28; if linked_2174 == nil { tmp193 = ifn_2175.Invoke_O__O(arg_2176) } else { tmp193 = linked_2174.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2173, arg_2176) }; seq_1685000211__23, chunk_1685000212__24, count_1685000213__25, i_1685000214__26 = tmp193, nil, 0, 0; continue L16 } } } }; break L16 }; seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, i_1685000206__21 = seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000206__21); continue L15 } else { seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, i_1685000206__21 = seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000206__21); continue L15 } } else { var temp__1927000414__auto____22_4 any; var root_1801 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = seq_1685000203__18; if linked_1802 == nil { temp__1927000414__auto____22_4 = ifn_1803.Invoke_O__O(arg_1804) } else { temp__1927000414__auto____22_4 = linked_1802.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1801, arg_1804) }; if jrt.J2g_Truth(temp__1927000414__auto____22_4) { var seq_1685000203__23 any = temp__1927000414__auto____22_4; var tmp194 any; var root_1805 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = seq_1685000203__23; if linked_1806 == nil { tmp194 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp194 = linked_1806.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1805, arg_1808) }; if jrt.J2g_Truth(tmp194) { var c__1927000678__auto____24_4 any; var root_1809 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = seq_1685000203__23; if linked_1810 == nil { c__1927000678__auto____24_4 = ifn_1811.Invoke_O__O(arg_1812) } else { c__1927000678__auto____24_4 = linked_1810.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1809, arg_1812) }; var tmp195 any; var root_2177 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = seq_1685000203__23; if linked_2178 == nil { tmp195 = ifn_2179.Invoke_O__O(arg_2180) } else { tmp195 = linked_2178.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2177, arg_2180) }; seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, i_1685000206__21 = tmp195, c__1927000678__auto____24_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__24_3 any; var root_1813 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = seq_1685000203__23; if linked_1814 == nil { d__24_3 = ifn_1815.Invoke_O__O(arg_1816) } else { d__24_3 = linked_1814.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1813, arg_1816) }; var tmp196 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp197 any; var root_1817 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = d__24_3; if linked_1818 == nil { tmp197 = ifn_1819.Invoke_O__O(arg_1820) } else { tmp197 = linked_1818.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1817, arg_1820) }; if jrt.J2g_Truth(tmp196.Invoke_O__O(tmp197)) { var seq_1685000207__25 any; var root_2181 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any; var root_2185 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2187 lang.IFn
										if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any; var tmp198 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp199 any; var root_2189 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = d__24_3; if linked_2190 == nil { tmp199 = ifn_2191.Invoke_O__O(arg_2192) } else { tmp199 = linked_2190.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2189, arg_2192) }; arg_2188 = tmp198.Invoke_O__O(tmp199); if linked_2186 == nil { arg_2184 = ifn_2187.Invoke_O__O(arg_2188) } else { arg_2184 = linked_2186.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2185, arg_2188) }
//line :236:1
										if linked_2182 == nil { seq_1685000207__25 = ifn_2183.Invoke_O__O(arg_2184) } else { seq_1685000207__25 = linked_2182.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2181, arg_2184) }; var chunk_1685000208__26 any; var count_1685000209__27 int64 = 0; var i_1685000210__28 int64 = 0; L17: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000210__28, count_1685000209__27) { var n__29_2 any = lang.Indexed_Cast(chunk_1685000208__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000210__28)); var tmp200 any; var tmp201 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____30_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp201, A_arbace_go_check_A_const_50.Invoke_O__O(n__29_2))

											if and__1927000168__auto____30_2 { tmp200 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__29_2)) } else { tmp200 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30_2).Ref() }
//line :236:1
											if jrt.J2g_Truth(tmp200) {


												var root_2209 any = A_arbace_go_check_A_const_220.GetRawRoot__O(); var linked_2210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2209, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2211 lang.IFn; if linked_2210 == nil { ifn_2211 = lang.IFn_Cast(root_2209) } else { ifn_2211 = nil }; var arg_2212 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__29_2); var arg_2213 any; var tmp202 any = A_arbace_go_check_A_const_221; var tmp203 any = A_arbace_go_check_A_const_221.Invoke_O__O(n__29_2); var tmp204 any = A_arbace_go_check_A_const_54; var G__1685000217__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp202, tmp203, tmp204, A_arbace_go_check_A_const_54.Invoke_O__O(n__29_2), A_arbace_go_check_A_const_222, jrt.Boolean_TRUE.Ref())); var tmp205 *lang.Keyword = A_arbace_go_check_A_const_223; if jrt.J2g_Truth(tmp205.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__29_2))) {

													var root_2214 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = G__1685000217__30_; var arg_2218 any = A_arbace_go_check_A_const_224; var arg_2219 any = jrt.Boolean_TRUE.Ref(); if linked_2215 == nil { arg_2213 = ifn_2216.Invoke_O_O_O__O(arg_2217, arg_2218, arg_2219) } else { arg_2213 = linked_2215.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2214, arg_2217, arg_2218, arg_2219) } } else {
//line :239:1
														arg_2213 = G__1685000217__30_ }; if linked_2210 == nil { ifn_2211.Invoke_O_O__O(arg_2212, arg_2213) } else { linked_2210.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2209, arg_2212, arg_2213) }
//line :236:1
												seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, i_1685000210__28 = seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__28); continue L17 } else { seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, i_1685000210__28 = seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__28); continue L17 } } else { var temp__1927000414__auto____29 any; var root_2193 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = seq_1685000207__25; if linked_2194 == nil { temp__1927000414__auto____29 = ifn_2195.Invoke_O__O(arg_2196) } else { temp__1927000414__auto____29 = linked_2194.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2193, arg_2196) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1685000207__30 any = temp__1927000414__auto____29; var tmp206 any; var root_2197 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = seq_1685000207__30; if linked_2198 == nil { tmp206 = ifn_2199.Invoke_O__O(arg_2200) } else { tmp206 = linked_2198.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2197, arg_2200) }; if jrt.J2g_Truth(tmp206) { var c__1927000678__auto____31 any; var root_2201 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2203 lang.IFn; if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = seq_1685000207__30; if linked_2202 == nil { c__1927000678__auto____31 = ifn_2203.Invoke_O__O(arg_2204) } else { c__1927000678__auto____31 = linked_2202.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2201, arg_2204) }; var tmp207 any; var root_2220 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = seq_1685000207__30; if linked_2221 == nil { tmp207 = ifn_2222.Invoke_O__O(arg_2223) } else { tmp207 = linked_2221.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2220, arg_2223) }; seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, i_1685000210__28 = tmp207, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L17 } else { var n__31 any; var root_2205 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2207 lang.IFn; if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any = seq_1685000207__30; if linked_2206 == nil { n__31 = ifn_2207.Invoke_O__O(arg_2208) } else { n__31 = linked_2206.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2205, arg_2208) }; var tmp208 any; var tmp209 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____32 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp209, A_arbace_go_check_A_const_50.Invoke_O__O(n__31))

													if and__1927000168__auto____32 { tmp208 = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__31)) } else { tmp208 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____32).Ref() }
//line :236:1
													if jrt.J2g_Truth(tmp208) {


														var root_2224 any = A_arbace_go_check_A_const_220.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__31); var arg_2228 any; var tmp210 any = A_arbace_go_check_A_const_221; var tmp211 any = A_arbace_go_check_A_const_221.Invoke_O__O(n__31); var tmp212 any = A_arbace_go_check_A_const_54; var G__1685000218__32_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp210, tmp211, tmp212, A_arbace_go_check_A_const_54.Invoke_O__O(n__31), A_arbace_go_check_A_const_222, jrt.Boolean_TRUE.Ref())); var tmp213 *lang.Keyword = A_arbace_go_check_A_const_223; if jrt.J2g_Truth(tmp213.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__31))) {

															var root_2229 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = G__1685000218__32_; var arg_2233 any = A_arbace_go_check_A_const_224; var arg_2234 any = jrt.Boolean_TRUE.Ref(); if linked_2230 == nil { arg_2228 = ifn_2231.Invoke_O_O_O__O(arg_2232, arg_2233, arg_2234) } else { arg_2228 = linked_2230.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2229, arg_2232, arg_2233, arg_2234) } } else {
//line :239:1
																arg_2228 = G__1685000218__32_ }; if linked_2225 == nil { ifn_2226.Invoke_O_O__O(arg_2227, arg_2228) } else { linked_2225.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2224, arg_2227, arg_2228) }
//line :236:1
														var tmp214 any; var root_2235 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2237 lang.IFn; if linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = seq_1685000207__30; if linked_2236 == nil { tmp214 = ifn_2237.Invoke_O__O(arg_2238) } else { tmp214 = linked_2236.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2235, arg_2238) }; seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, i_1685000210__28 = tmp214, nil, 0, 0; continue L17 } else { var tmp215 any; var root_2239 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = seq_1685000207__30; if linked_2240 == nil { tmp215 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp215 = linked_2240.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2239, arg_2242) }; seq_1685000207__25, chunk_1685000208__26, count_1685000209__27, i_1685000210__28 = tmp215, nil, 0, 0; continue L17 } } } }; break L17 }; var tmp216 any; var root_2243 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = seq_1685000203__23; if linked_2244 == nil { tmp216 = ifn_2245.Invoke_O__O(arg_2246) } else { tmp216 = linked_2244.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2243, arg_2246) }; seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, i_1685000206__21 = tmp216, nil, 0, 0; continue L15 } else { var tmp217 any; var root_2247 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = seq_1685000203__23; if linked_2248 == nil { tmp217 = ifn_2249.Invoke_O__O(arg_2250) } else { tmp217 = linked_2248.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2247, arg_2250) }; seq_1685000203__18, chunk_1685000204__19, count_1685000205__20, i_1685000206__21 = tmp217, nil, 0, 0; continue L15 } } } }
//line :235:1
				break L15 } }
//line :161:1
		var seq_1685000219__18 any; var root_1821 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1823 lang.IFn

















































































		if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = decls__17; if linked_1822 == nil { seq_1685000219__18 = ifn_1823.Invoke_O__O(arg_1824) } else { seq_1685000219__18 = linked_1822.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1821, arg_1824) }
//line :161:1
		var chunk_1685000220__19 any; var count_1685000221__20 int64 = 0; var i_1685000222__21 int64 = 0; L18: for {

















































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000222__21, count_1685000221__20) { var d__22_4 any = lang.Indexed_Cast(chunk_1685000220__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000222__21)); var tmp218 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp219 any; var root_1825 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = d__22_4; if linked_1826 == nil { tmp219 = ifn_1827.Invoke_O__O(arg_1828) } else { tmp219 = linked_1826.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1825, arg_1828) }; if jrt.J2g_Truth(tmp218.Invoke_O__O(tmp219)) {
				var root_2251 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2251, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any; var tmp220 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp221 any; var root_2256 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = d__22_4; if linked_2257 == nil { tmp221 = ifn_2258.Invoke_O__O(arg_2259) } else { tmp221 = linked_2257.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2256, arg_2259) }; arg_2254 = tmp220.Invoke_O__O(tmp221); var arg_2255 any; var tmp222 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp223 any; var root_2260 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any = d__22_4; if linked_2261 == nil { tmp223 = ifn_2262.Invoke_O__O(arg_2263) } else { tmp223 = linked_2261.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2260, arg_2263) }; arg_2255 = tmp222.Invoke_O__O(tmp223); if linked_2252 == nil { ifn_2253.Invoke_O_O__O(arg_2254, arg_2255) } else { linked_2252.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2251, arg_2254, arg_2255) }
//line :243:1
				seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, i_1685000222__21 = seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000222__21); continue L18 } else { seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, i_1685000222__21 = seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000222__21); continue L18 } } else { var temp__1927000414__auto____22_5 any; var root_1829 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = seq_1685000219__18; if linked_1830 == nil { temp__1927000414__auto____22_5 = ifn_1831.Invoke_O__O(arg_1832) } else { temp__1927000414__auto____22_5 = linked_1830.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1829, arg_1832) }; if jrt.J2g_Truth(temp__1927000414__auto____22_5) { var seq_1685000219__23 any = temp__1927000414__auto____22_5; var tmp224 any; var root_1833 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = seq_1685000219__23; if linked_1834 == nil { tmp224 = ifn_1835.Invoke_O__O(arg_1836) } else { tmp224 = linked_1834.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1833, arg_1836) }; if jrt.J2g_Truth(tmp224) { var c__1927000678__auto____24_5 any; var root_1837 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = seq_1685000219__23; if linked_1838 == nil { c__1927000678__auto____24_5 = ifn_1839.Invoke_O__O(arg_1840) } else { c__1927000678__auto____24_5 = linked_1838.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1837, arg_1840) }; var tmp225 any; var root_2264 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any = seq_1685000219__23; if linked_2265 == nil { tmp225 = ifn_2266.Invoke_O__O(arg_2267) } else { tmp225 = linked_2265.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2264, arg_2267) }; seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, i_1685000222__21 = tmp225, c__1927000678__auto____24_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L18 } else { var d__24_4 any; var root_1841 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = seq_1685000219__23; if linked_1842 == nil { d__24_4 = ifn_1843.Invoke_O__O(arg_1844) } else { d__24_4 = linked_1842.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1841, arg_1844) }; var tmp226 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp227 any; var root_1845 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = d__24_4; if linked_1846 == nil { tmp227 = ifn_1847.Invoke_O__O(arg_1848) } else { tmp227 = linked_1846.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1845, arg_1848) }; if jrt.J2g_Truth(tmp226.Invoke_O__O(tmp227)) {
					var root_2268 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any; var tmp228 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp229 any; var root_2273 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = d__24_4; if linked_2274 == nil { tmp229 = ifn_2275.Invoke_O__O(arg_2276) } else { tmp229 = linked_2274.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2273, arg_2276) }; arg_2271 = tmp228.Invoke_O__O(tmp229); var arg_2272 any; var tmp230 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp231 any; var root_2277 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = d__24_4; if linked_2278 == nil { tmp231 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp231 = linked_2278.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2277, arg_2280) }; arg_2272 = tmp230.Invoke_O__O(tmp231); if linked_2269 == nil { ifn_2270.Invoke_O_O__O(arg_2271, arg_2272) } else { linked_2269.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2268, arg_2271, arg_2272) }
//line :243:1
					var tmp232 any; var root_2281 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = seq_1685000219__23; if linked_2282 == nil { tmp232 = ifn_2283.Invoke_O__O(arg_2284) } else { tmp232 = linked_2282.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2281, arg_2284) }; seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, i_1685000222__21 = tmp232, nil, 0, 0; continue L18 } else { var tmp233 any; var root_2285 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = seq_1685000219__23; if linked_2286 == nil { tmp233 = ifn_2287.Invoke_O__O(arg_2288) } else { tmp233 = linked_2286.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2285, arg_2288) }; seq_1685000219__18, chunk_1685000220__19, count_1685000221__20, i_1685000222__21 = tmp233, nil, 0, 0; continue L18 } } } }
//line :161:1
			break L18 }; var seq_1685000223__18 any; var root_1849 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1851 lang.IFn



















































































		if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = fis__13; if linked_1850 == nil { seq_1685000223__18 = ifn_1851.Invoke_O__O(arg_1852) } else { seq_1685000223__18 = linked_1850.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1849, arg_1852) }
//line :161:1
		var chunk_1685000224__19 any; var count_1685000225__20 int64 = 0; var i_1685000226__21 int64 = 0; L19: for {



















































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000226__21, count_1685000225__20) { var fi__22_4 any = lang.Indexed_Cast(chunk_1685000224__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000226__21)); var root_2289 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = fi__22_4; if linked_2290 == nil { ifn_2291.Invoke_O__O(arg_2292) } else { linked_2290.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2289, arg_2292) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } else { var temp__1927000414__auto____22_6 any; var root_1853 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = seq_1685000223__18; if linked_1854 == nil { temp__1927000414__auto____22_6 = ifn_1855.Invoke_O__O(arg_1856) } else { temp__1927000414__auto____22_6 = linked_1854.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(temp__1927000414__auto____22_6) { var seq_1685000223__23 any = temp__1927000414__auto____22_6; var tmp234 any; var root_1857 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = seq_1685000223__23; if linked_1858 == nil { tmp234 = ifn_1859.Invoke_O__O(arg_1860) } else { tmp234 = linked_1858.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1857, arg_1860) }; if jrt.J2g_Truth(tmp234) { var c__1927000678__auto____24_6 any; var root_1861 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = seq_1685000223__23; if linked_1862 == nil { c__1927000678__auto____24_6 = ifn_1863.Invoke_O__O(arg_1864) } else { c__1927000678__auto____24_6 = linked_1862.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1861, arg_1864) }; var tmp235 any; var root_2293 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = seq_1685000223__23; if linked_2294 == nil { tmp235 = ifn_2295.Invoke_O__O(arg_2296) } else { tmp235 = linked_2294.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2293, arg_2296) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp235, c__1927000678__auto____24_6, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_6))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L19 } else { var fi__24 any; var root_1865 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = seq_1685000223__23; if linked_1866 == nil { fi__24 = ifn_1867.Invoke_O__O(arg_1868) } else { fi__24 = linked_1866.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1865, arg_1868) }; var root_2297 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = fi__24; if linked_2298 == nil { ifn_2299.Invoke_O__O(arg_2300) } else { linked_2298.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2297, arg_2300) }; var tmp236 any; var root_2301 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = seq_1685000223__23; if linked_2302 == nil { tmp236 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp236 = linked_2302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2301, arg_2304) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp236, nil, 0, 0; continue L19 } } }
//line :161:1
			break L19 }; var order__18 any; var root_842 any = A_arbace_go_check_A_const_128.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_844 lang.IFn





















































































		if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = objs__16; if linked_843 == nil { order__18 = ifn_844.Invoke_O__O(arg_845) } else { order__18 = linked_843.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_842, arg_845) }
//line :161:1
		var ___19 any; var tmp237 any; var root_846 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_848 lang.IFn; _ = ___19























































































		if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = errors__9; if linked_851 == nil { arg_849 = ifn_852.Invoke_O__O(arg_853) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_850, arg_853) }; if linked_847 == nil { tmp237 = ifn_848.Invoke_O__O(arg_849) } else { tmp237 = linked_847.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_846, arg_849) }; if jrt.J2g_Truth(tmp237) { var root_854 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; if linked_855 == nil { ___19 = ifn_856.Invoke__O() } else { ___19 = linked_855.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A).Invoke_O__O(root_854) } } else { ___19 = nil }
//line :161:1
		var ___20 any; var tmp238 any; var root_857 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_859 lang.IFn; _ = ___20

























































































		if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = errors__9; if linked_862 == nil { arg_860 = ifn_863.Invoke_O__O(arg_864) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_861, arg_864) }; if linked_858 == nil { tmp238 = ifn_859.Invoke_O__O(arg_860) } else { tmp238 = linked_858.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(tmp238) { var root_865 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; if linked_866 == nil { ___20 = ifn_867.Invoke__O() } else { ___20 = linked_866.(*aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A).Invoke_O__O(root_865) } } else { ___20 = nil }
//line :161:1
		var say__21 any; var root_868 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_870 lang.IFn


























































































		if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = src__0; var arg_872 any = A_arbace_go_check_A_const_132; if linked_869 == nil { say__21 = ifn_870.Invoke_O_O__O(arg_871, arg_872) } else { say__21 = linked_869.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_868, arg_871, arg_872) }
//line :161:1
		var init_entry__22 any; var tmp239 any = A_arbace_go_check_check_package_init_entry__1685000227_A_New(); var tmp240 *jrt.Class
		var fncls__913 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000227_A_fn_class



























































































		if fncls__913 == nil { var fncls__913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_init_entry__1685000227_A_fn_class = fncls__913d; tmp240 = fncls__913d } else { tmp240 = fncls__913 }; init_entry__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp239, tmp240, nil)
//line :161:1
		var have__23 any; var root_914 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_916 lang.IFn






























































































		if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = init_entry__22; var arg_918 any = order__18; if linked_915 == nil { have__23 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { have__23 = linked_915.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }
//line :161:1
		var norm__24 any; var tmp241 any = A_arbace_go_check_check_package_norm__1685000231_A_New(); var tmp242 *jrt.Class
		var fncls__947 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000231_A_fn_class
































































































		if fncls__947 == nil { var fncls__947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_norm__1685000231_A_fn_class = fncls__947d; tmp242 = fncls__947d } else { tmp242 = fncls__947 }; norm__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp241, tmp242, nil)
//line :161:1
		var init_result__25 any; var tmp243 any; var root_948 any = A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_950 lang.IFn





































































































		if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = say__21; if linked_949 == nil { tmp243 = ifn_950.Invoke_O__O(arg_951) } else { tmp243 = linked_949.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_948, arg_951) }; if jrt.J2g_Truth(tmp243) {
			var tmp244 any; var root_952 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = norm__24; var arg_956 any = say__21; if linked_953 == nil { tmp244 = ifn_954.Invoke_O_O__O(arg_955, arg_956) } else { tmp244 = linked_953.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_952, arg_955, arg_956) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp244, have__23) { var tmp245 any = A_arbace_go_check_A_const_139; var tmp246 any = jrt.Boolean_TRUE.Ref(); var tmp247 any = A_arbace_go_check_A_const_140; init_result__25 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp245, tmp246, tmp247, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__21)).Ref())) } else {

				var root_2305 any = A_arbace_go_check_A_const_227.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_228.Invoke_O__O(src__0)) { arg_2308 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_228.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp248 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp249 any; var root_2312 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__0); if linked_2313 == nil { tmp249 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp249 = linked_2313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2312, arg_2315) }; arg_2308 = tmp248.Invoke_O__O(tmp249) }; var arg_2309 any; var or__1927000174__auto____25 any = A_arbace_go_check_A_const_229.Invoke_O__O(src__0)
				if jrt.J2g_Truth(or__1927000174__auto____25) { arg_2309 = or__1927000174__auto____25 } else { arg_2309 = A_arbace_go_check_A_const_22 }
//line :266:1
				var arg_2310 any = A_arbace_go_check_A_const_230; var arg_2311 any = lang.IFn_Cast(A_arbace_go_check_A_const_231.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_64, A_arbace_go_check_A_const_110.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()).Invoke_O__O(say__21), lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()).Invoke_O__O(have__23)); if linked_2306 == nil { ifn_2307.Invoke_O_O_O_O__O(arg_2308, arg_2309, arg_2310, arg_2311) } else { linked_2306.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_2305, arg_2308, arg_2309, arg_2310, arg_2311) }
//line :264:1
				init_result__25 = A_arbace_go_check_A_const_141 } } else {
//line :263:1
					init_result__25 = nil }
//line :161:1
		var generic_ids__26 any; var root_957 any = A_arbace_go_check_A_const_142.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_959 lang.IFn














































































































		if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any; var root_961 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any; var tmp250 any = A_arbace_go_check_check_package_fn__1685000235_A_New(); var tmp251 *jrt.Class; var fncls__974 *jrt.Class = A_arbace_go_check_check_package_fn__1685000235_A_fn_class; if fncls__974 == nil { var fncls__974d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_fn__1685000235_A_fn_class = fncls__974d; tmp251 = fncls__974d } else { tmp251 = fncls__974 }; arg_964 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp250, tmp251, nil); var arg_965 any = decls__17; if linked_962 == nil { arg_960 = ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { arg_960 = linked_962.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_961, arg_964, arg_965) }; if linked_958 == nil { generic_ids__26 = ifn_959.Invoke_O__O(arg_960) } else { generic_ids__26 = linked_958.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_957, arg_960) }
//line :161:1
		var errs__27 any; var root_975 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_977 lang.IFn





















































































		if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = errors__9; if linked_976 == nil { errs__27 = ifn_977.Invoke_O__O(arg_978) } else { errs__27 = linked_976.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_975, arg_978) }
//line :161:1
		var counted__28 any; var root_979 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_981 lang.IFn
















































































































		if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var tmp252 any = A_arbace_go_check_check_package_fn__1685000237_A_New_O(generic_ids__26); var tmp253 *jrt.Class; var fncls__989 *jrt.Class = A_arbace_go_check_check_package_fn__1685000237_A_fn_class; if fncls__989 == nil { var fncls__989d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_check_package_fn__1685000237_A_fn_class = fncls__989d; tmp253 = fncls__989d } else { tmp253 = fncls__989 }; arg_982 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp252, tmp253, nil); var arg_983 any = errs__27; if linked_980 == nil { counted__28 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { counted__28 = linked_980.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }
//line :161:1
		var forms__29 any; var m__29 any = jrt.IdentityHashMap_New(); var order__30 any = jrt.ArrayList_New(); var seq_1685000239__31 any; var root_2331 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2333 lang.IFn




















































































































		if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = decls__17; if linked_2332 == nil { seq_1685000239__31 = ifn_2333.Invoke_O__O(arg_2334) } else { seq_1685000239__31 = linked_2332.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2331, arg_2334) }
//line :161:1
		var chunk_1685000240__32 any; var count_1685000241__33 int64 = 0; var i_1685000242__34 int64 = 0; L20: for {




















































































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000242__34, count_1685000241__33) { var d__35 any = lang.Indexed_Cast(chunk_1685000240__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000242__34)); var f__36 any; var tmp254 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp255 any; var root_2351 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2351, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2353 lang.IFn
				if linked_2352 == nil { ifn_2353 = lang.IFn_Cast(root_2351) } else { ifn_2353 = nil }; var arg_2354 any = d__35; if linked_2352 == nil { tmp255 = ifn_2353.Invoke_O__O(arg_2354) } else { tmp255 = linked_2352.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2351, arg_2354) }; f__36 = tmp254.Invoke_O__O(tmp255)
				if jrt.NN(jrt.IdentityHashMap_Cast(m__29)).ContainsKey_O__Z(f__36) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__30)).Add_O__Z(f__36)); jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Put_O_O__O(f__36, lang.PersistentVector_EMPTY.Ref()) }
				var tmp256 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__29); var tmp257 any; var root_2355 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Get_O__O(f__36); var arg_2359 any = d__35; if linked_2356 == nil { tmp257 = ifn_2357.Invoke_O_O__O(arg_2358, arg_2359) } else { tmp257 = linked_2356.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2355, arg_2358, arg_2359) }; jrt.NN(tmp256).Put_O_O__O(f__36, tmp257)
//line :278:1
				seq_1685000239__31, chunk_1685000240__32, count_1685000241__33, i_1685000242__34 = seq_1685000239__31, chunk_1685000240__32, count_1685000241__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000242__34); continue L20 } else { var temp__1927000414__auto____35 any; var root_2335 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = seq_1685000239__31; if linked_2336 == nil { temp__1927000414__auto____35 = ifn_2337.Invoke_O__O(arg_2338) } else { temp__1927000414__auto____35 = linked_2336.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2335, arg_2338) }; if jrt.J2g_Truth(temp__1927000414__auto____35) { var seq_1685000239__36 any = temp__1927000414__auto____35; var tmp258 any; var root_2339 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = seq_1685000239__36; if linked_2340 == nil { tmp258 = ifn_2341.Invoke_O__O(arg_2342) } else { tmp258 = linked_2340.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2339, arg_2342) }; if jrt.J2g_Truth(tmp258) { var c__1927000678__auto____37 any; var root_2343 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = seq_1685000239__36; if linked_2344 == nil { c__1927000678__auto____37 = ifn_2345.Invoke_O__O(arg_2346) } else { c__1927000678__auto____37 = linked_2344.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2343, arg_2346) }; var tmp259 any; var root_2360 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2362 lang.IFn; if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any = seq_1685000239__36; if linked_2361 == nil { tmp259 = ifn_2362.Invoke_O__O(arg_2363) } else { tmp259 = linked_2361.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2360, arg_2363) }; seq_1685000239__31, chunk_1685000240__32, count_1685000241__33, i_1685000242__34 = tmp259, c__1927000678__auto____37, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L20 } else { var d__37 any; var root_2347 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = seq_1685000239__36; if linked_2348 == nil { d__37 = ifn_2349.Invoke_O__O(arg_2350) } else { d__37 = linked_2348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2347, arg_2350) }; var f__38 any; var tmp260 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp261 any; var root_2364 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2366 lang.IFn
					if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = d__37; if linked_2365 == nil { tmp261 = ifn_2366.Invoke_O__O(arg_2367) } else { tmp261 = linked_2365.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2364, arg_2367) }; f__38 = tmp260.Invoke_O__O(tmp261)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__29)).ContainsKey_O__Z(f__38) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__30)).Add_O__Z(f__38)); jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Put_O_O__O(f__38, lang.PersistentVector_EMPTY.Ref()) }
					var tmp262 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__29); var tmp263 any; var root_2368 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Get_O__O(f__38); var arg_2372 any = d__37; if linked_2369 == nil { tmp263 = ifn_2370.Invoke_O_O__O(arg_2371, arg_2372) } else { tmp263 = linked_2369.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2368, arg_2371, arg_2372) }; jrt.NN(tmp262).Put_O_O__O(f__38, tmp263)
//line :278:1
					var tmp264 any; var root_2373 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = seq_1685000239__36; if linked_2374 == nil { tmp264 = ifn_2375.Invoke_O__O(arg_2376) } else { tmp264 = linked_2374.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2373, arg_2376) }; seq_1685000239__31, chunk_1685000240__32, count_1685000241__33, i_1685000242__34 = tmp264, nil, 0, 0; continue L20 } } }
//line :161:1
			break L20
		}























































































































		var root_990 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any; var tmp265 any = A_arbace_go_check_check_package_fn__1685000243_A_New_O(m__29); var tmp266 *jrt.Class; var fncls__995 *jrt.Class = A_arbace_go_check_check_package_fn__1685000243_A_fn_class; if fncls__995 == nil { var fncls__995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_fn__1685000243_A_fn_class = fncls__995d; tmp266 = fncls__995d } else { tmp266 = fncls__995 }; arg_993 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp265, tmp266, nil); var arg_994 any = order__30; if linked_991 == nil { forms__29 = ifn_992.Invoke_O_O__O(arg_993, arg_994) } else { forms__29 = linked_991.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_990, arg_993, arg_994) }
//line :161:1
		var stats__30 any; var root_996 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_998 lang.IFn

























































































































		if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var tmp267 any = A_arbace_go_check_check_package_fn__1685000246_A_New_O(resolving__10); var tmp268 *jrt.Class; var fncls__1276 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_A_fn_class
		if fncls__1276 == nil { var fncls__1276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000246_A_fn_class = fncls__1276d; tmp268 = fncls__1276d } else { tmp268 = fncls__1276 }; arg_999 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp267, tmp268, nil)
//line :283:1
		var arg_1000 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_163, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_154, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_164, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_139, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_156, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_166, lang.PersistentVector_EMPTY.Ref())); var arg_1001 any = forms__29; if linked_997 == nil { stats__30 = ifn_998.Invoke_O_O_O__O(arg_999, arg_1000, arg_1001) } else { stats__30 = linked_997.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_996, arg_999, arg_1000, arg_1001)
		}




























		var tmp269 any
		var and__1927000168__auto____31 any = resolving__10

		if jrt.J2g_Truth(and__1927000168__auto____31) { var root_2377 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2377, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2379 lang.IFn; if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any = keep_trees__6; if linked_2378 == nil { tmp269 = ifn_2379.Invoke_O__O(arg_2380) } else { tmp269 = linked_2378.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2377, arg_2380) } } else { tmp269 = and__1927000168__auto____31 }
//line :313:1
		if jrt.J2g_Truth(tmp269) { var seq_1685000287__31 any; var root_2381 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2383 lang.IFn



			if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = decls__17; if linked_2382 == nil { seq_1685000287__31 = ifn_2383.Invoke_O__O(arg_2384) } else { seq_1685000287__31 = linked_2382.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2381, arg_2384) }
//line :313:1
			var chunk_1685000288__32 any; var count_1685000289__33 int64 = 0; var i_1685000290__34 int64 = 0; L21: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000290__34, count_1685000289__33) { var d__35_2 any = lang.Indexed_Cast(chunk_1685000288__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000290__34)); var root_2580 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = d__35_2; var arg_2584 any; var root_2585 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2585, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2587 lang.IFn; if linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any; var root_2590 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = d__35_2; if linked_2591 == nil { arg_2588 = ifn_2592.Invoke_O__O(arg_2593) } else { arg_2588 = linked_2591.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2590, arg_2593) }; var arg_2589 any = A_arbace_go_check_A_const_248; if linked_2586 == nil { arg_2584 = ifn_2587.Invoke_O_O__O(arg_2588, arg_2589) } else { arg_2584 = linked_2586.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2585, arg_2588, arg_2589) }; if linked_2581 == nil { ifn_2582.Invoke_O_O__O(arg_2583, arg_2584) } else { linked_2581.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2580, arg_2583, arg_2584) }; seq_1685000287__31, chunk_1685000288__32, count_1685000289__33, i_1685000290__34 = seq_1685000287__31, chunk_1685000288__32, count_1685000289__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000290__34); continue L21 } else { var temp__1927000414__auto____35_2 any; var root_2385 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any = seq_1685000287__31; if linked_2386 == nil { temp__1927000414__auto____35_2 = ifn_2387.Invoke_O__O(arg_2388) } else { temp__1927000414__auto____35_2 = linked_2386.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2385, arg_2388) }; if jrt.J2g_Truth(temp__1927000414__auto____35_2) { var seq_1685000287__36 any = temp__1927000414__auto____35_2; var tmp270 any; var root_2389 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = seq_1685000287__36; if linked_2390 == nil { tmp270 = ifn_2391.Invoke_O__O(arg_2392) } else { tmp270 = linked_2390.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2389, arg_2392) }; if jrt.J2g_Truth(tmp270) { var c__1927000678__auto____37_2 any; var root_2393 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = seq_1685000287__36; if linked_2394 == nil { c__1927000678__auto____37_2 = ifn_2395.Invoke_O__O(arg_2396) } else { c__1927000678__auto____37_2 = linked_2394.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2393, arg_2396) }; var tmp271 any; var root_2594 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2596 lang.IFn; if linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any = seq_1685000287__36; if linked_2595 == nil { tmp271 = ifn_2596.Invoke_O__O(arg_2597) } else { tmp271 = linked_2595.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2594, arg_2597) }; seq_1685000287__31, chunk_1685000288__32, count_1685000289__33, i_1685000290__34 = tmp271, c__1927000678__auto____37_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L21 } else { var d__37_2 any; var root_2397 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = seq_1685000287__36; if linked_2398 == nil { d__37_2 = ifn_2399.Invoke_O__O(arg_2400) } else { d__37_2 = linked_2398.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2397, arg_2400) }; var root_2598 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any = d__37_2; var arg_2602 any; var root_2603 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2605 lang.IFn; if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any; var root_2608 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = d__37_2; if linked_2609 == nil { arg_2606 = ifn_2610.Invoke_O__O(arg_2611) } else { arg_2606 = linked_2609.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2608, arg_2611) }; var arg_2607 any = A_arbace_go_check_A_const_249; if linked_2604 == nil { arg_2602 = ifn_2605.Invoke_O_O__O(arg_2606, arg_2607) } else { arg_2602 = linked_2604.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2603, arg_2606, arg_2607) }; if linked_2599 == nil { ifn_2600.Invoke_O_O__O(arg_2601, arg_2602) } else { linked_2599.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2598, arg_2601, arg_2602) }; var tmp272 any; var root_2612 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = seq_1685000287__36; if linked_2613 == nil { tmp272 = ifn_2614.Invoke_O__O(arg_2615) } else { tmp272 = linked_2613.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2612, arg_2615) }; seq_1685000287__31, chunk_1685000288__32, count_1685000289__33, i_1685000290__34 = tmp272, nil, 0, 0; continue L21 } } }
//line :313:1
				break L21 } } else { var tmp273 any; var root_2401 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2403 lang.IFn




					if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = keep_trees__6; if linked_2402 == nil { tmp273 = ifn_2403.Invoke_O__O(arg_2404) } else { tmp273 = linked_2402.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2401, arg_2404) }
//line :313:1
					if jrt.J2g_Truth(tmp273) { var seq_1685000291__31 any; var root_2405 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2407 lang.IFn





						if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any = decls__17; if linked_2406 == nil { seq_1685000291__31 = ifn_2407.Invoke_O__O(arg_2408) } else { seq_1685000291__31 = linked_2406.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2405, arg_2408) }
//line :313:1
						var chunk_1685000292__32 any; var count_1685000293__33 int64 = 0; var i_1685000294__34 int64 = 0; L22: for {





							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000294__34, count_1685000293__33) { var d__35_3 any = lang.Indexed_Cast(chunk_1685000292__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000294__34)); var tmp274 any; var and__1927000168__auto____36 bool; var tmp275 any = A_arbace_go_check_A_const_250; var tmp276 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp277 any; var root_2616 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2618 lang.IFn
								if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = d__35_3; if linked_2617 == nil { tmp277 = ifn_2618.Invoke_O__O(arg_2619) } else { tmp277 = linked_2617.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2616, arg_2619) }; and__1927000168__auto____36 = lang.Util_Equiv_O_O__Z_NoInit(tmp275, tmp276.Invoke_O__O(tmp277)); if and__1927000168__auto____36 { var or__1927000174__auto____37 any; var root_2620 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any; var root_2624 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any; var tmp278 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp279 any; var root_2629 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = d__35_3; if linked_2630 == nil { tmp279 = ifn_2631.Invoke_O__O(arg_2632) } else { tmp279 = linked_2630.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2629, arg_2632) }; arg_2627 = tmp278.Invoke_O__O(tmp279); var arg_2628 any = A_arbace_go_check_A_const_251; if linked_2625 == nil { arg_2623 = ifn_2626.Invoke_O_O__O(arg_2627, arg_2628) } else { arg_2623 = linked_2625.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2624, arg_2627, arg_2628) }; if linked_2621 == nil { or__1927000174__auto____37 = ifn_2622.Invoke_O__O(arg_2623) } else { or__1927000174__auto____37 = linked_2621.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2620, arg_2623) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp274 = or__1927000174__auto____37 } else { var root_2633 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any; var root_2637 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any; var tmp280 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp281 any; var root_2642 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = d__35_3; if linked_2643 == nil { tmp281 = ifn_2644.Invoke_O__O(arg_2645) } else { tmp281 = linked_2643.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2642, arg_2645) }; arg_2640 = tmp280.Invoke_O__O(tmp281); var arg_2641 any = A_arbace_go_check_A_const_252; if linked_2638 == nil { arg_2636 = ifn_2639.Invoke_O_O__O(arg_2640, arg_2641) } else { arg_2636 = linked_2638.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2637, arg_2640, arg_2641) }; if linked_2634 == nil { tmp274 = ifn_2635.Invoke_O__O(arg_2636) } else { tmp274 = linked_2634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2633, arg_2636) } } } else { tmp274 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____36).Ref() }; if jrt.J2g_Truth(tmp274) {
									jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_253.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_254, A_arbace_go_check_A_const_255, A_arbace_go_check_A_const_256)) } else {
										jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_253.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_210, A_arbace_go_check_A_const_254, A_arbace_go_check_A_const_255, A_arbace_go_check_A_const_256)) }
//line :319:1
								seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000294__34); continue L22 } else { var temp__1927000414__auto____35_3 any; var root_2409 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2411 lang.IFn; if linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = seq_1685000291__31; if linked_2410 == nil { temp__1927000414__auto____35_3 = ifn_2411.Invoke_O__O(arg_2412) } else { temp__1927000414__auto____35_3 = linked_2410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2409, arg_2412) }; if jrt.J2g_Truth(temp__1927000414__auto____35_3) { var seq_1685000291__36 any = temp__1927000414__auto____35_3; var tmp282 any; var root_2413 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2413, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2415 lang.IFn; if linked_2414 == nil { ifn_2415 = lang.IFn_Cast(root_2413) } else { ifn_2415 = nil }; var arg_2416 any = seq_1685000291__36; if linked_2414 == nil { tmp282 = ifn_2415.Invoke_O__O(arg_2416) } else { tmp282 = linked_2414.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2413, arg_2416) }; if jrt.J2g_Truth(tmp282) { var c__1927000678__auto____37_3 any; var root_2417 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2417, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2419 lang.IFn; if linked_2418 == nil { ifn_2419 = lang.IFn_Cast(root_2417) } else { ifn_2419 = nil }; var arg_2420 any = seq_1685000291__36; if linked_2418 == nil { c__1927000678__auto____37_3 = ifn_2419.Invoke_O__O(arg_2420) } else { c__1927000678__auto____37_3 = linked_2418.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2417, arg_2420) }; var tmp283 any; var root_2661 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any = seq_1685000291__36; if linked_2662 == nil { tmp283 = ifn_2663.Invoke_O__O(arg_2664) } else { tmp283 = linked_2662.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2661, arg_2664) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp283, c__1927000678__auto____37_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L22 } else { var d__37_3 any; var root_2421 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = seq_1685000291__36; if linked_2422 == nil { d__37_3 = ifn_2423.Invoke_O__O(arg_2424) } else { d__37_3 = linked_2422.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2421, arg_2424) }
									var tmp284 any; var and__1927000168__auto____38 bool; var tmp285 any = A_arbace_go_check_A_const_250; var tmp286 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp287 any; var root_2665 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = d__37_3; if linked_2666 == nil { tmp287 = ifn_2667.Invoke_O__O(arg_2668) } else { tmp287 = linked_2666.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2665, arg_2668) }; and__1927000168__auto____38 = lang.Util_Equiv_O_O__Z_NoInit(tmp285, tmp286.Invoke_O__O(tmp287)); if and__1927000168__auto____38 { var or__1927000174__auto____39 any; var root_2669 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2671 lang.IFn; if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any; var root_2673 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2675 lang.IFn; if linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any; var tmp288 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp289 any; var root_2678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = d__37_3; if linked_2679 == nil { tmp289 = ifn_2680.Invoke_O__O(arg_2681) } else { tmp289 = linked_2679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2678, arg_2681) }; arg_2676 = tmp288.Invoke_O__O(tmp289); var arg_2677 any = A_arbace_go_check_A_const_251; if linked_2674 == nil { arg_2672 = ifn_2675.Invoke_O_O__O(arg_2676, arg_2677) } else { arg_2672 = linked_2674.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2673, arg_2676, arg_2677) }; if linked_2670 == nil { or__1927000174__auto____39 = ifn_2671.Invoke_O__O(arg_2672) } else { or__1927000174__auto____39 = linked_2670.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2669, arg_2672) }; if jrt.J2g_Truth(or__1927000174__auto____39) { tmp284 = or__1927000174__auto____39 } else { var root_2682 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any; var root_2686 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2686, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2688 lang.IFn; if linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any; var tmp290 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp291 any; var root_2691 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = d__37_3; if linked_2692 == nil { tmp291 = ifn_2693.Invoke_O__O(arg_2694) } else { tmp291 = linked_2692.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2691, arg_2694) }; arg_2689 = tmp290.Invoke_O__O(tmp291); var arg_2690 any = A_arbace_go_check_A_const_252; if linked_2687 == nil { arg_2685 = ifn_2688.Invoke_O_O__O(arg_2689, arg_2690) } else { arg_2685 = linked_2687.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2686, arg_2689, arg_2690) }; if linked_2683 == nil { tmp284 = ifn_2684.Invoke_O__O(arg_2685) } else { tmp284 = linked_2683.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2682, arg_2685) } } } else { tmp284 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____38).Ref() }; if jrt.J2g_Truth(tmp284) {
										jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_253.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_254, A_arbace_go_check_A_const_255, A_arbace_go_check_A_const_256)) } else {
											jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_253.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_210, A_arbace_go_check_A_const_254, A_arbace_go_check_A_const_255, A_arbace_go_check_A_const_256)) }
//line :319:1
									var tmp292 any; var root_2710 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2710, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2712 lang.IFn; if linked_2711 == nil { ifn_2712 = lang.IFn_Cast(root_2710) } else { ifn_2712 = nil }; var arg_2713 any = seq_1685000291__36; if linked_2711 == nil { tmp292 = ifn_2712.Invoke_O__O(arg_2713) } else { tmp292 = linked_2711.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2710, arg_2713) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp292, nil, 0, 0; continue L22 } } }
//line :313:1
							break L22
						}
					}
				}






		var tmp293 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp294 any; var root_2425 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2429 any = A_arbace_go_check_A_const_233; var arg_2430 any; var tmp295 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp296 any = A_arbace_go_check_A_const_110; var tmp297 any = A_arbace_go_check_A_const_110.Invoke_O__O(src__0); var tmp298 any = A_arbace_go_check_A_const_234; var tmp299 any; var root_2431 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2433 lang.IFn


		if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any; var root_2435 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any; var root_2440 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = A_arbace_go_check_A_const_73; var arg_2444 any = A_arbace_go_check_A_const_78; if linked_2441 == nil { arg_2438 = ifn_2442.Invoke_O_O__O(arg_2443, arg_2444) } else { arg_2438 = linked_2441.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2440, arg_2443, arg_2444) }; var arg_2439 any = counted__28; if linked_2436 == nil { arg_2434 = ifn_2437.Invoke_O_O__O(arg_2438, arg_2439) } else { arg_2434 = linked_2436.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2435, arg_2438, arg_2439) }; if linked_2432 == nil { tmp299 = ifn_2433.Invoke_O__O(arg_2434) } else { tmp299 = linked_2432.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2431, arg_2434) }
//line :324:1
		var tmp300 any = tmp299; var tmp301 any = A_arbace_go_check_A_const_237; var tmp302 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__27)), int64(lang.RT_Count_O__I_NoInit(counted__28)))).Ref(); var tmp303 any = A_arbace_go_check_A_const_238; var tmp304 any = A_arbace_go_check_A_const_239; var tmp305 any




		if jrt.J2g_Truth(keep_trees__6) { var root_2445 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any; var root_2449 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2451 lang.IFn; if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any; var tmp306 any = A_arbace_go_check_check_package_fn__1685000295_A_New(); var tmp307 *jrt.Class; var fncls__2458 *jrt.Class = A_arbace_go_check_check_package_fn__1685000295_A_fn_class; if fncls__2458 == nil { var fncls__2458d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000295_A_fn_class = fncls__2458d; tmp307 = fncls__2458d } else { tmp307 = fncls__2458 }; arg_2452 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp306, tmp307, nil); var arg_2453 any = decls__17; if linked_2450 == nil { arg_2448 = ifn_2451.Invoke_O_O__O(arg_2452, arg_2453) } else { arg_2448 = linked_2450.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2449, arg_2452, arg_2453) }; if linked_2446 == nil { tmp305 = ifn_2447.Invoke_O__O(arg_2448) } else { tmp305 = linked_2446.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2445, arg_2448) } } else { tmp305 = nil }
//line :324:1
		var tmp308 any = tmp305; var tmp309 any = A_arbace_go_check_A_const_240; var tmp310 any







		if jrt.J2g_Truth(keep_trees__6) {
			var root_2459 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any; var iter__1927001039__auto____31 any; var tmp311 any = A_arbace_go_check_check_package_iter__1685000297__1685000301_A_New(); var tmp312 *jrt.Class; var fncls__2539 *jrt.Class = A_arbace_go_check_check_package_iter__1685000297__1685000301_A_fn_class; if fncls__2539 == nil { var fncls__2539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_iter__1685000297__1685000301_A_fn_class = fncls__2539d; tmp312 = fncls__2539d } else { tmp312 = fncls__2539 }; iter__1927001039__auto____31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp311, tmp312, nil); arg_2462 = lang.IFn_Cast(iter__1927001039__auto____31).Invoke_O__O(decls__17); if linked_2460 == nil { tmp310 = ifn_2461.Invoke_O__O(arg_2462) } else { tmp310 = linked_2460.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2459, arg_2462) } } else {
//line :332:1
				tmp310 = nil }
//line :324:1
		var tmp313 any = tmp310; var tmp314 any = A_arbace_go_check_A_const_244; var tmp315 any











		if jrt.J2g_Truth(keep_trees__6) { tmp315 = order__18 } else { tmp315 = nil }
//line :324:1
		var tmp316 any = tmp315; var tmp317 any = A_arbace_go_check_A_const_245; var tmp318 any













		if jrt.J2g_Truth(resolving__10) {
			var root_2540 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any; var tmp319 any = A_arbace_go_check_check_package_fn__1685000307_A_New(); var tmp320 *jrt.Class; var fncls__2575 *jrt.Class = A_arbace_go_check_check_package_fn__1685000307_A_fn_class; if fncls__2575 == nil { var fncls__2575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000307_A_fn_class = fncls__2575d; tmp320 = fncls__2575d } else { tmp320 = fncls__2575 }; arg_2543 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp319, tmp320, nil); var arg_2544 any = order__18; if linked_2541 == nil { tmp318 = ifn_2542.Invoke_O_O__O(arg_2543, arg_2544) } else { tmp318 = linked_2541.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2540, arg_2543, arg_2544) } } else {
//line :338:1
				tmp318 = nil }
//line :324:1
		var tmp321 any = tmp318; var tmp322 any = A_arbace_go_check_A_const_71; var tmp323 any
















		if jrt.J2g_Truth(keep_trees__6) { tmp323 = pkg_scope__7 } else { tmp323 = nil }
//line :324:1
		var tmp324 any = tmp323; var tmp325 any = A_arbace_go_check_A_const_119; var tmp326 any

















		if jrt.J2g_Truth(keep_trees__6) { var root_2576 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = A_arbace_go_check_A_const_119.Invoke_O__O(ctx__12); if linked_2577 == nil { tmp326 = ifn_2578.Invoke_O__O(arg_2579) } else { tmp326 = linked_2577.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2576, arg_2579) } } else { tmp326 = nil }
//line :324:1
		arg_2430 = tmp295.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, stats__30, tmp296, tmp297, tmp298, tmp300, tmp301, tmp302, tmp303, init_result__25, tmp304, tmp308, tmp309, tmp313, tmp314, tmp316, tmp317, tmp321, tmp322, tmp324, tmp325, tmp326))))
//line :323:1
		if linked_2426 == nil { tmp294 = ifn_2427.Invoke_O_O_O__O(arg_2428, arg_2429, arg_2430) } else { tmp294 = linked_2426.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2425, arg_2428, arg_2429, arg_2430) }; jrt.NN(tmp293).Reset_O__O(tmp294)
//line :161:1
		tmp67 = pkg__8 }; return nil }(); var root_1277 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1279 lang.IFn; if















	linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; if linked_1278 == nil { ifn_1279.Invoke__O() } else { linked_1278.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1277) }; if /*line :161:1*/ tmp327 != nil { panic(tmp327) }; return tmp67 }














func A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000129_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Invoke_O_O__O(self, p1__1685000111_SHARP___1 any) any { var root_816 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_go_check_file_info_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = t.F_pkg_scope; var arg_820 any = p1__1685000111_SHARP___1; var arg_821 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src); if linked_817 == nil { return ifn_818.Invoke_O_O_O__O(arg_819, arg_820, arg_821) } else { return linked_817.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_816, arg_819, arg_820, arg_821) } }












func A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000131_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :189:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :189:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1284 any = A_arbace_go_check_A_const_186.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = A_arbace_go_check_A_const_110.Invoke_O__O(t.F_src); if linked_1285 == nil { tmp1 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp1 = linked_1285.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1284, arg_1287) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :189:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }





























func A_arbace_go_check_check_package_fn__1685000175_A_New() *A_arbace_go_check_check_package_fn__1685000175_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000175_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_go_check_check_package_fn__1685000175_A) Ctor() {}
//line :219:1
func (t *A_arbace_go_check_check_package_fn__1685000175_A) Invoke_O_O__O(self, p1__1685000112_SHARP___1 any) any { var root_836 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = p1__1685000112_SHARP___1; var arg_840 any = A_arbace_go_check_A_const_127; if linked_837 == nil { return ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { return linked_837.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) } }





func A_arbace_go_check_check_package_fn__1685000182_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000182_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000182_A{}; t.Ctor_O_O(p0, p1); return t }
//line :225:1
func (t *A_arbace_go_check_check_package_fn__1685000182_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :225:1
func (t *A_arbace_go_check_check_package_fn__1685000182_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000183__5 any; var root_1883 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1885 lang.IFn
											if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1886 = t_; if linked_1884 == nil { seq_1685000183__5 = ifn_1885.Invoke_O__O(arg_1886) } else { seq_1685000183__5 = linked_1884.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1883, arg_1886) }
//line :225:1
	var chunk_1685000184__6 any; var count_1685000185__7 int64 = 0; var i_1685000186__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000186__8, count_1685000185__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000184__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000186__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, i_1685000186__8 = seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000186__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1887 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = seq_1685000183__5; if linked_1888 == nil { temp__1927000414__auto____9 = ifn_1889.Invoke_O__O(arg_1890) } else { temp__1927000414__auto____9 = linked_1888.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1887, arg_1890) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000183__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1891 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = seq_1685000183__10; if linked_1892 == nil { tmp2 = ifn_1893.Invoke_O__O(arg_1894) } else { tmp2 = linked_1892.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1891, arg_1894) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1895 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = seq_1685000183__10; if linked_1896 == nil { c__1927000678__auto____11 = ifn_1897.Invoke_O__O(arg_1898) } else { c__1927000678__auto____11 = linked_1896.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1895, arg_1898) }; var tmp3 any; var root_1906 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = seq_1685000183__10; if linked_1907 == nil { tmp3 = ifn_1908.Invoke_O__O(arg_1909) } else { tmp3 = linked_1907.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1906, arg_1909) }; seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, i_1685000186__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1899 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = seq_1685000183__10; if linked_1900 == nil { l__11 = ifn_1901.Invoke_O__O(arg_1902) } else { l__11 = linked_1900.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1899, arg_1902) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1910 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = seq_1685000183__10; if linked_1911 == nil { tmp4 = ifn_1912.Invoke_O__O(arg_1913) } else { tmp4 = linked_1911.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1910, arg_1913) }; seq_1685000183__5, chunk_1685000184__6, count_1685000185__7, i_1685000186__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :225:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1914 any = A_arbace_go_check_A_const_212.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1916 lang.IFn

			if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = ex__5; if linked_1915 == nil { tmp6 = ifn_1916.Invoke_O__O(arg_1917) } else { tmp6 = linked_1915.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1914, arg_1917) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1918 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1918, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1921 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1922 any = A_arbace_go_check_A_const_144; var arg_1923 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_213; var tmp11 any; var root_1924 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = ex__5; if linked_1925 == nil { tmp11 = ifn_1926.Invoke_O__O(arg_1927) } else { tmp11 = linked_1925.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1924, arg_1927) }; arg_1923 = tmp10.Invoke_O__O(tmp11); if linked_1919 == nil { tmp8 = ifn_1920.Invoke_O_O_O__O(arg_1921, arg_1922, arg_1923) } else { tmp8 = linked_1919.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1918, arg_1921, arg_1922, arg_1923) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :225:1
				panic(tmp5) } } }; return nil }(); var root_1903 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; if linked_1904 == nil { ifn_1905.Invoke__O() } else { linked_1904.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1903) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :225:1
func A_arbace_go_check_check_package_fn__1685000189_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000189_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000189_A{}; t.Ctor_O_O(p0, p1); return t }
//line :225:1
func (t *A_arbace_go_check_check_package_fn__1685000189_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :225:1
func (t *A_arbace_go_check_check_package_fn__1685000189_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000190__5 any; var root_1973 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1973, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1975 lang.IFn
											if linked_1974 == nil { ifn_1975 = lang.IFn_Cast(root_1973) } else { ifn_1975 = nil }; var arg_1976 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1976 = t_; if linked_1974 == nil { seq_1685000190__5 = ifn_1975.Invoke_O__O(arg_1976) } else { seq_1685000190__5 = linked_1974.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1973, arg_1976) }
//line :225:1
	var chunk_1685000191__6 any; var count_1685000192__7 int64 = 0; var i_1685000193__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000193__8, count_1685000192__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000191__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000193__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, i_1685000193__8 = seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000193__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1977 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1979 lang.IFn; if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any = seq_1685000190__5; if linked_1978 == nil { temp__1927000414__auto____9 = ifn_1979.Invoke_O__O(arg_1980) } else { temp__1927000414__auto____9 = linked_1978.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1977, arg_1980) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000190__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1981 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = seq_1685000190__10; if linked_1982 == nil { tmp2 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp2 = linked_1982.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1981, arg_1984) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1985 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = seq_1685000190__10; if linked_1986 == nil { c__1927000678__auto____11 = ifn_1987.Invoke_O__O(arg_1988) } else { c__1927000678__auto____11 = linked_1986.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1985, arg_1988) }; var tmp3 any; var root_1996 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = seq_1685000190__10; if linked_1997 == nil { tmp3 = ifn_1998.Invoke_O__O(arg_1999) } else { tmp3 = linked_1997.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1996, arg_1999) }; seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, i_1685000193__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1989 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = seq_1685000190__10; if linked_1990 == nil { l__11 = ifn_1991.Invoke_O__O(arg_1992) } else { l__11 = linked_1990.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1989, arg_1992) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_2000 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = seq_1685000190__10; if linked_2001 == nil { tmp4 = ifn_2002.Invoke_O__O(arg_2003) } else { tmp4 = linked_2001.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2000, arg_2003) }; seq_1685000190__5, chunk_1685000191__6, count_1685000192__7, i_1685000193__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :225:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_2004 any = A_arbace_go_check_A_const_212.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2006 lang.IFn

			if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = ex__5; if linked_2005 == nil { tmp6 = ifn_2006.Invoke_O__O(arg_2007) } else { tmp6 = linked_2005.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_2004, arg_2007) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2008 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2011 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2012 any = A_arbace_go_check_A_const_144; var arg_2013 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_213; var tmp11 any; var root_2014 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = ex__5; if linked_2015 == nil { tmp11 = ifn_2016.Invoke_O__O(arg_2017) } else { tmp11 = linked_2015.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2014, arg_2017) }; arg_2013 = tmp10.Invoke_O__O(tmp11); if linked_2009 == nil { tmp8 = ifn_2010.Invoke_O_O_O__O(arg_2011, arg_2012, arg_2013) } else { tmp8 = linked_2009.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2008, arg_2011, arg_2012, arg_2013) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :225:1
				panic(tmp5) } } }; return nil }(); var root_1993 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; if linked_1994 == nil { ifn_1995.Invoke__O() } else { linked_1994.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1993) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000199_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000199_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000199_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_go_check_check_package_fn__1685000199_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :231:1
func (t *A_arbace_go_check_check_package_fn__1685000199_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2049 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp3 any; var root_2053 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any; var t_ any = t.F_d; t.F_d = nil; arg_2056 = t_; if linked_2054 == nil { tmp3 = ifn_2055.Invoke_O__O(arg_2056) } else { tmp3 = linked_2054.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2053, arg_2056) }; arg_2052 = tmp2.Invoke_O__O(tmp3); if linked_2050 == nil { tmp1 = ifn_2051.Invoke_O__O(arg_2052) } else { tmp1 = linked_2050.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2049, arg_2052) } }
//line :231:1
	return nil }(); var root_2057 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2059 lang.IFn; if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; if linked_2058 == nil { ifn_2059.Invoke__O() } else { linked_2058.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2057) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :231:1
func A_arbace_go_check_check_package_fn__1685000201_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000201_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000201_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_go_check_check_package_fn__1685000201_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :231:1
func (t *A_arbace_go_check_check_package_fn__1685000201_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2080 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp3 any; var root_2084 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any; var t_ any = t.F_d; t.F_d = nil; arg_2087 = t_; if linked_2085 == nil { tmp3 = ifn_2086.Invoke_O__O(arg_2087) } else { tmp3 = linked_2085.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2084, arg_2087) }; arg_2083 = tmp2.Invoke_O__O(tmp3); if linked_2081 == nil { tmp1 = ifn_2082.Invoke_O__O(arg_2083) } else { tmp1 = linked_2081.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2080, arg_2083) } }
//line :231:1
	return nil }(); var root_2088 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; if linked_2089 == nil { ifn_2090.Invoke__O() } else { linked_2089.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2088) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_go_check_check_package_init_entry__1685000227_A_New() *A_arbace_go_check_check_package_init_entry__1685000227_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000227_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_go_check_check_package_init_entry__1685000227_A) Ctor() {}
//line :253:1
func (t *A_arbace_go_check_check_package_init_entry__1685000227_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A_New(); var tmp2 *jrt.Class; var fncls__897 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A_fn_class; if
													fncls__897 == nil { var fncls__897d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A_fn_class = fncls__897d; tmp2 = fncls__897d } else { tmp2 = fncls__897 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_909 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = lhs__1; if linked_910 == nil { tmp4 = ifn_911.Invoke_O__O(arg_912) } else { tmp4 = linked_910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_909, arg_912) }; return tmp3.Invoke_O__O(tmp4) } else { var root_898 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var arg_902 any = A_arbace_go_check_A_const_136; var arg_903 any; var root_904 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = one__2; var arg_908 any = lhs__1; if linked_905 == nil { arg_903 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { arg_903 = linked_905.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; if linked_899 == nil { return ifn_900.Invoke_O_O_O__O(arg_901, arg_902, arg_903) } else { return linked_899.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_898, arg_901, arg_902, arg_903) } } }
//line :254:1
func A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A_New() *A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A) Ctor() {}
//line :254:1
func (t *A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_873 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = v__1; var arg_877 any = A_arbace_go_check_A_const_70; if linked_874 == nil { tmp1 = ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { tmp1 = linked_874.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_87, tmp1) { var tmp2 any; var root_887 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = v__1; var arg_891 any = A_arbace_go_check_A_const_73; if linked_888 == nil { tmp2 = ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { tmp2 = linked_888.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_887, arg_890, arg_891) }; var tmp3 any = tmp2; var tmp4 any; var root_892 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = v__1; var arg_896 any = A_arbace_go_check_A_const_78; if linked_893 == nil { tmp4 = ifn_894.Invoke_O_O__O(arg_895, arg_896) } else { tmp4 = linked_893.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_892, arg_895, arg_896) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_878 any = A_arbace_go_check_A_const_133.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any; var root_882 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = v__1; var arg_886 any = A_arbace_go_check_A_const_70; if linked_883 == nil { arg_881 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { arg_881 = linked_883.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }; if linked_879 == nil { return ifn_880.Invoke_O__O(arg_881) } else { return linked_879.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_878, arg_881) } } }



func A_arbace_go_check_check_package_norm__1685000231_A_New() *A_arbace_go_check_check_package_norm__1685000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000231_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_norm__1685000231_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_check_package_norm__1685000231_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_919 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_921 lang.IFn; if
												linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = x__1; if linked_920 == nil { tmp1 = ifn_921.Invoke_O__O(arg_922) } else { tmp1 = linked_920.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_919, arg_922) }; if /*line :258:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_923 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_925 lang.IFn

		if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = x__1; if linked_924 == nil { tmp2 = ifn_925.Invoke_O__O(arg_926) } else { tmp2 = linked_924.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_923, arg_926) }
//line :258:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_90, tmp2) {


			var root_927 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var arg_931 any = A_arbace_go_check_A_const_137; var arg_932 any; var root_933 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A_New(); var tmp4 *jrt.Class; var fncls__942 *jrt.Class = A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A_fn_class; if fncls__942 == nil { var fncls__942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A_fn_class = fncls__942d; tmp4 = fncls__942d } else { tmp4 = fncls__942 }; arg_936 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_937 any; var root_943 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = x__1; if linked_944 == nil { arg_937 = ifn_945.Invoke_O__O(arg_946) } else { arg_937 = linked_944.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_943, arg_946) }; if linked_934 == nil { arg_932 = ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { arg_932 = linked_934.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) }; if linked_928 == nil { return ifn_929.Invoke_O_O_O__O(arg_930, arg_931, arg_932) } else { return linked_928.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_927, arg_930, arg_931, arg_932) } } else {
//line :258:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A_New() *A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A) Ctor() {}
//line :261:1
func (t *A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A) Invoke_O_O__O(self, p1__1685000113_SHARP___1 any) any { var tmp1 any; var root_938 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = p1__1685000113_SHARP___1; if linked_939 == nil { tmp1 = ifn_940.Invoke_O__O(arg_941) } else { tmp1 = linked_939.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_938, arg_941) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000113_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000235_A_New() *A_arbace_go_check_check_package_fn__1685000235_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000235_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_go_check_check_package_fn__1685000235_A) Ctor() {}
//line :272:1
func (t *A_arbace_go_check_check_package_fn__1685000235_A) Invoke_O_O__O(self, p1__1685000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp2 any; var root_966 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = p1__1685000114_SHARP___1; if linked_967 == nil { tmp2 = ifn_968.Invoke_O__O(arg_969) } else { tmp2 = linked_967.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_966, arg_969) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp4 any; var root_970 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = p1__1685000114_SHARP___1; if linked_971 == nil { tmp4 = ifn_972.Invoke_O__O(arg_973) } else { tmp4 = linked_971.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_970, arg_973) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000237_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000237_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000237_A{}; t.Ctor_O(p0); return t }
//line :274:1
func (t *A_arbace_go_check_check_package_fn__1685000237_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :274:1
func (t *A_arbace_go_check_check_package_fn__1685000237_A) Invoke_O_O__O(self, p1__1685000115_SHARP___1 any) any { var root_984 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = t.F_generic_ids; var arg_988 any = A_arbace_go_check_A_const_127.Invoke_O__O(p1__1685000115_SHARP___1); if linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } }







func A_arbace_go_check_check_package_fn__1685000243_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000243_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000243_A{}; t.Ctor_O(p0); return t }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000243_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000243_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000246_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_A{}; t.Ctor_O(p0); return t }
//line :284:1
func (t *A_arbace_go_check_check_package_fn__1685000246_A) Ctor_O(c__resolving any) { t.F_resolving = c__resolving }
//line :284:1
func (t *A_arbace_go_check_check_package_fn__1685000246_A) Invoke_O_O_O__O(self, acc__1, p__1685000245__2 any) any { var vec__1685000247__3 any = p__1685000245__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000247__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000247__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_1002 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1004 lang.IFn; if
															linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A_New(); var tmp2 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A_fn_class = fncls__1011d; tmp2 = fncls__1011d } else { tmp2 = fncls__1011 }; arg_1005 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1006 any = ds__5; if linked_1003 == nil { gen__6 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { gen__6 = linked_1003.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }; var uses_generics__7 any; var root_1012 any = /*line :284:1*/A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1014 lang.IFn; if

	linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A_New(); var tmp4 *jrt.Class; var fncls__1021 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A_fn_class; if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A_fn_class = fncls__1021d; tmp4 = fncls__1021d } else { tmp4 = fncls__1021 }; arg_1015 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1016 any = ds__5; if linked_1013 == nil { uses_generics__7 = ifn_1014.Invoke_O_O__O(arg_1015, arg_1016) } else { uses_generics__7 = linked_1013.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1012, arg_1015, arg_1016) }; var present__8 any; if
	jrt.J2g_Truth(t.F_resolving) { present__8 = lang.PersistentArrayMap_EMPTY.Ref() } else { var root_1022 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_check_annotations_present_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = form__4; if linked_1023 == nil { present__8 = ifn_1024.Invoke_O__O(arg_1025) } else { present__8 = linked_1023.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_1022, arg_1025) } }; var verified__9 any; var root_1026 any = /*line :284:1*/A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1028 lang.IFn; if



	linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var arg_1030 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1031 any; var root_1032 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A_New(); var tmp6 *jrt.Class; var fncls__1041 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A_fn_class; if fncls__1041 == nil { var fncls__1041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A_fn_class = fncls__1041d; tmp6 = fncls__1041d } else { tmp6 = fncls__1041 }; arg_1035 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1036 any = ds__5; if linked_1033 == nil { arg_1031 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { arg_1031 = linked_1033.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }; if linked_1027 == nil { verified__9 = ifn_1028.Invoke_O_O_O__O(arg_1029, arg_1030, arg_1031) } else { verified__9 = linked_1027.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1026, arg_1029, arg_1030, arg_1031) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_1042 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var root_1049 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = acc__1; var arg_1053 any = A_arbace_go_check_A_const_152; var arg_1054 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); if linked_1050 == nil { arg_1045 = ifn_1051.Invoke_O_O_O__O(arg_1052, arg_1053, arg_1054) } else { arg_1045 = linked_1050.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1049, arg_1052, arg_1053, arg_1054) }; var arg_1046 any = A_arbace_go_check_A_const_154; var arg_1047 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1048 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1043 == nil { acc__10 = ifn_1044.Invoke_O_O_O_O__O(arg_1045, arg_1046, arg_1047, arg_1048) } else { acc__10 = linked_1043.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1042, arg_1045, arg_1046, arg_1047, arg_1048) } } else {
//line :289:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_1055 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any; var root_1061 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1063 lang.IFn
//line :295:1
		if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1067 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1069 lang.IFn
//line :294:1
		if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = acc__10; var arg_1071 any = A_arbace_go_check_A_const_155; var arg_1072 any; var root_1073 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); var arg_1077 any = A_arbace_go_check_A_const_22; if linked_1074 == nil { arg_1072 = ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { arg_1072 = linked_1074.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) }; if linked_1068 == nil { arg_1064 = ifn_1069.Invoke_O_O_O__O(arg_1070, arg_1071, arg_1072) } else { arg_1064 = linked_1068.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1067, arg_1070, arg_1071, arg_1072) }
		var arg_1065 any = A_arbace_go_check_A_const_156; var arg_1066 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A_New_O(present__8); var tmp8 *jrt.Class; var fncls__1084 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A_fn_class; if fncls__1084 == nil { var fncls__1084d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A_fn_class = fncls__1084d; tmp8 = fncls__1084d } else { tmp8 = fncls__1084 }; arg_1066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_1062 == nil { arg_1058 = ifn_1063.Invoke_O_O_O__O(arg_1064, arg_1065, arg_1066) } else { arg_1058 = linked_1062.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1061, arg_1064, arg_1065, arg_1066) }
		var arg_1059 any = A_arbace_go_check_A_const_144; var arg_1060 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A_New_O(ds__5); var tmp10 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A_fn_class = fncls__1107d; tmp10 = fncls__1107d } else { tmp10 = fncls__1107 }; arg_1060 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1056 == nil { return ifn_1057.Invoke_O_O_O__O(arg_1058, arg_1059, arg_1060) } else { return linked_1056.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1055, arg_1058, arg_1059, arg_1060) } } else {
//line :292:1
			var unver__11 any; var root_1108 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1110 lang.IFn




			if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1112 any; var iter__1927001039__auto____11 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A_New_O(verified__9); var tmp12 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A_fn_class = fncls__1195d; tmp12 = fncls__1195d } else { tmp12 = fncls__1195 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1112 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1109 == nil { unver__11 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { unver__11 = linked_1109.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112)
			}








			var root_1196 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any; var root_1202 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1204 lang.IFn
//line :306:1
			if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any; var root_1208 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1210 lang.IFn
//line :305:1
			if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1214 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1216 lang.IFn
//line :304:1
			if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any; var root_1220 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1222 lang.IFn
//line :303:1
			if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var root_1227 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1229 lang.IFn
//line :302:1
			if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = acc__10; var arg_1231 any = A_arbace_go_check_A_const_163; var arg_1232 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); if linked_1228 == nil { arg_1223 = ifn_1229.Invoke_O_O_O__O(arg_1230, arg_1231, arg_1232) } else { arg_1223 = linked_1228.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1227, arg_1230, arg_1231, arg_1232) }
			var arg_1224 any = A_arbace_go_check_A_const_82; var arg_1225 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1226 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1221 == nil { arg_1217 = ifn_1222.Invoke_O_O_O_O__O(arg_1223, arg_1224, arg_1225, arg_1226) } else { arg_1217 = linked_1221.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1220, arg_1223, arg_1224, arg_1225, arg_1226) }
			var arg_1218 any = A_arbace_go_check_A_const_164; var arg_1219 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A_New_O(present__8); var tmp14 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A_fn_class; if fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A_fn_class = fncls__1239d; tmp14 = fncls__1239d } else { tmp14 = fncls__1239 }; arg_1219 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1215 == nil { arg_1211 = ifn_1216.Invoke_O_O_O__O(arg_1217, arg_1218, arg_1219) } else { arg_1211 = linked_1215.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1214, arg_1217, arg_1218, arg_1219) }
			var arg_1212 any = A_arbace_go_check_A_const_139; var arg_1213 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A_New_O(verified__9); var tmp16 *jrt.Class; var fncls__1246 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A_fn_class; if fncls__1246 == nil { var fncls__1246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A_fn_class = fncls__1246d; tmp16 = fncls__1246d } else { tmp16 = fncls__1246 }; arg_1213 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1209 == nil { arg_1205 = ifn_1210.Invoke_O_O_O__O(arg_1211, arg_1212, arg_1213) } else { arg_1205 = linked_1209.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1208, arg_1211, arg_1212, arg_1213) }
			var arg_1206 any = A_arbace_go_check_A_const_165; var arg_1207 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A_New_O(unver__11); var tmp18 *jrt.Class; var fncls__1253 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A_fn_class; if fncls__1253 == nil { var fncls__1253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A_fn_class = fncls__1253d; tmp18 = fncls__1253d } else { tmp18 = fncls__1253 }; arg_1207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1203 == nil { arg_1199 = ifn_1204.Invoke_O_O_O__O(arg_1205, arg_1206, arg_1207) } else { arg_1199 = linked_1203.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1202, arg_1205, arg_1206, arg_1207) }
			var arg_1200 any = A_arbace_go_check_A_const_166; var arg_1201 any; var tmp19 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A_New_O_O_O(form__4, ds__5, unver__11); var tmp20 *jrt.Class; var fncls__1275 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A_fn_class; if fncls__1275 == nil { var fncls__1275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A_fn_class = fncls__1275d; tmp20 = fncls__1275d } else { tmp20 = fncls__1275 }; arg_1201 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); if linked_1197 == nil { return ifn_1198.Invoke_O_O_O__O(arg_1199, arg_1200, arg_1201) } else { return linked_1197.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1196, arg_1199, arg_1200, arg_1201) } } }
//line :285:1
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A_New() *A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A{}; t.Ctor(); return t }
//line :285:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A) Ctor() {}
//line :285:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A) Invoke_O_O__O(self, p1__1685000116_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp2 any; var root_1007 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = p1__1685000116_SHARP___1; if linked_1008 == nil { tmp2 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp2 = linked_1008.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1007, arg_1010) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A_New() *A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A) Invoke_O_O__O(self, p1__1685000117_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_149; var tmp2 any; var root_1017 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = p1__1685000117_SHARP___1; if linked_1018 == nil { tmp2 = ifn_1019.Invoke_O__O(arg_1020) } else { tmp2 = linked_1018.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1017, arg_1020) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A_New() *A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A) Ctor() {}
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A) Invoke_O_O__O(self, p1__1685000118_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_139; var tmp2 any; var root_1037 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = p1__1685000118_SHARP___1; if linked_1038 == nil { tmp2 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp2 = linked_1038.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1037, arg_1040) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A{}; t.Ctor_O(p0); return t }
//line :295:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :295:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A) Invoke_O_O__O(self, p1__1685000119_SHARP___1 any) any { var root_1078 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1082 any = p1__1685000119_SHARP___1; var arg_1083 any = t.F_present; if linked_1079 == nil { return ifn_1080.Invoke_O_O_O__O(arg_1081, arg_1082, arg_1083) } else { return linked_1079.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1078, arg_1081, arg_1082, arg_1083) } }
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A{}; t.Ctor_O(p0); return t }
//line :296:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :296:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A) Invoke_O_O__O(self, p1__1685000120_SHARP___1 any) any { var root_1085 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A_New(); var tmp2 *jrt.Class; var fncls__1106 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A_fn_class; if fncls__1106 == nil { var fncls__1106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A_fn_class = fncls__1106d; tmp2 = fncls__1106d } else { tmp2 = fncls__1106 }; arg_1088 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1089 any = p1__1685000120_SHARP___1; var arg_1090 any = t.F_ds; if linked_1086 == nil { return ifn_1087.Invoke_O_O_O__O(arg_1088, arg_1089, arg_1090) } else { return linked_1086.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1085, arg_1088, arg_1089, arg_1090) } }
//line :296:1
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A_New() *A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_144; var tmp2 any; var root_1091 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = d__2; if linked_1092 == nil { tmp2 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp2 = linked_1092.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1091, arg_1094) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_1095 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = m__1; var arg_1099 any = u__4; var arg_1100 any; var root_1101 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); var arg_1105 any = A_arbace_go_check_A_const_22; if linked_1102 == nil { arg_1100 = ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { arg_1100 = linked_1102.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }; if linked_1096 == nil { return ifn_1097.Invoke_O_O_O__O(arg_1098, arg_1099, arg_1100) } else { return linked_1096.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1095, arg_1098, arg_1099, arg_1100) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A{}; t.Ctor_O(p0); return t }
//line :297:1
func (t *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :297:1
func (t *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A) Invoke_O_O__O(self, s__1685000263__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A_New_O_O_O(s__1685000263__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1194 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A_fn_class; if fncls__1194 == nil { var fncls__1194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A_fn_class = fncls__1194d; tmp2 = fncls__1194d } else { tmp2 = fncls__1194 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :297:1
func A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :297:1
func (t *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A) Ctor_O_O_O(c__s__1685000263, c__iter__1685000262, c__verified any) { t.F_s__1685000263 = c__s__1685000263; t.F_iter__1685000262 = c__iter__1685000262; t.F_verified = c__verified }
//line :297:1
func (t *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A) Invoke_O__O(self any) any { { var s__1685000263__1 any; var t_ any = t.F_s__1685000263; t.F_s__1685000263 = nil; s__1685000263__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1113 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = s__1685000263__1; if linked_1114 == nil { temp__1927000414__auto____2 = ifn_1115.Invoke_O__O(arg_1116) } else { temp__1927000414__auto____2 = linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000263__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1117 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = s__1685000263__3; if linked_1118 == nil { tmp1 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp1 = linked_1118.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1117, arg_1120) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1121 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__1685000263__3; if linked_1122 == nil { c__1927001037__auto____4 = ifn_1123.Invoke_O__O(arg_1124) } else { c__1927001037__auto____4 = linked_1122.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1121, arg_1124) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000265__6 any; var root_1125 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1126 == nil { b__1685000265__6 = ifn_1127.Invoke_O__O(arg_1128) } else { b__1685000265__6 = linked_1126.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A_New_I_O_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1685000265__6, t.F_verified); var tmp3 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A_fn_class; if fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A_fn_class = fncls__1144d; tmp3 = fncls__1144d } else { tmp3 = fncls__1144 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1145 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any; var root_1150 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = b__1685000265__6; if linked_1151 == nil { arg_1148 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1148 = linked_1151.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1150, arg_1153) }; var arg_1149 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000262); var tmp5 any; var root_1154 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = s__1685000263__3; if linked_1155 == nil { tmp5 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp5 = linked_1155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1154, arg_1157) }; arg_1149 = tmp4.Invoke_O__O(tmp5); if linked_1146 == nil { return ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { return linked_1146.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) } } else { var root_1158 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var root_1163 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = b__1685000265__6; if linked_1164 == nil { arg_1161 = ifn_1165.Invoke_O__O(arg_1166) } else { arg_1161 = linked_1164.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1163, arg_1166) }; var arg_1162 any; if linked_1159 == nil { return ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { return linked_1159.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } } } else { var vec__1685000273__4 any; var root_1167 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = s__1685000263__3; if linked_1168 == nil { vec__1685000273__4 = ifn_1169.Invoke_O__O(arg_1170) } else { vec__1685000273__4 = linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1171 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1173 lang.IFn

	if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = n__6; var arg_1175 any = v__7; if linked_1172 == nil { tmp6 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { tmp6 = linked_1172.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }
//line :297:1
	if jrt.J2g_Truth(tmp6) { var root_1176 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var tmp7 jrt.Number_I; var na_1181 any = n__6; var na_1182 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1181); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1182) }; tmp8 = tmp9; if tmp8 { var n0_1183 int64 = jrt.NN(jrt.Long_Cast(na_1181)).LongValue__J(); var n1_1184 int64 = jrt.NN(jrt.Long_Cast(na_1182)).LongValue__J(); var nr_1185 int64 = n0_1183 - n1_1184; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1184 == -9223372036854775808); if tmp11 { tmp11 = (n0_1183^n1_1184)&(n0_1183^nr_1185) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1185)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1181, na_1182) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1181); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1182) }; tmp12 = tmp13; if tmp12 { var n0_1183_2 float64 = jrt.NN(jrt.Double_Cast(na_1181)).DoubleValue__D(); var n1_1184_2 float64 = jrt.NN(jrt.Double_Cast(na_1182)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1183_2 + -n1_1184_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1181, na_1182) } }
//line :297:1
		arg_1179 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1180 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000262); var tmp15 any; var root_1186 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = s__1685000263__3; if linked_1187 == nil { tmp15 = ifn_1188.Invoke_O__O(arg_1189) } else { tmp15 = linked_1187.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1186, arg_1189) }; arg_1180 = tmp14.Invoke_O__O(tmp15); if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } } else { var tmp16 any; var root_1190 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = s__1685000263__3; if linked_1191 == nil { tmp16 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp16 = linked_1191.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1190, arg_1193) }; s__1685000263__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :297:1
func A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :297:1
func (t *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A) Ctor_I_O_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000265, c__verified any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000265 = c__b__1685000265; t.F_verified = c__verified }
//line :297:1
func (t *A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A) Invoke_O__O(self any) any { { var i__1685000264__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000264__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000269__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000264__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000269__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000269__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1129 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1131 lang.IFn

	if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = n__4; var arg_1133 any = v__5; if linked_1130 == nil { tmp2 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp2 = linked_1130.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }
//line :297:1
	if jrt.J2g_Truth(tmp2) { var root_1134 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = t.F_b__1685000265; var arg_1138 any; var tmp3 jrt.Number_I; var na_1139 any = n__4; var na_1140 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1139); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1140) }; tmp4 = tmp5; if tmp4 { var n0_1141 int64 = jrt.NN(jrt.Long_Cast(na_1139)).LongValue__J(); var n1_1142 int64 = jrt.NN(jrt.Long_Cast(na_1140)).LongValue__J(); var nr_1143 int64 = n0_1141 - n1_1142; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1142 == -9223372036854775808); if tmp7 { tmp7 = (n0_1141^n1_1142)&(n0_1141^nr_1143) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1143)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1139, na_1140) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1139); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1140) }; tmp8 = tmp9; if tmp8 { var n0_1141_2 float64 = jrt.NN(jrt.Double_Cast(na_1139)).DoubleValue__D(); var n1_1142_2 float64 = jrt.NN(jrt.Double_Cast(na_1140)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1141_2 + -n1_1142_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1139, na_1140) } }
//line :297:1
		arg_1138 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1135 == nil { ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { linked_1135.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; i__1685000264__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000264__1); continue L1 } else { i__1685000264__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000264__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :304:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A) Invoke_O_O__O(self, p1__1685000121_SHARP___1 any) any { var root_1233 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1237 any = p1__1685000121_SHARP___1; var arg_1238 any = t.F_present; if linked_1234 == nil { return ifn_1235.Invoke_O_O_O__O(arg_1236, arg_1237, arg_1238) } else { return linked_1234.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1233, arg_1236, arg_1237, arg_1238) } }
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A) Invoke_O_O__O(self, p1__1685000122_SHARP___1 any) any { var root_1240 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1244 any = p1__1685000122_SHARP___1; var arg_1245 any = t.F_verified; if linked_1241 == nil { return ifn_1242.Invoke_O_O_O__O(arg_1243, arg_1244, arg_1245) } else { return linked_1241.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1240, arg_1243, arg_1244, arg_1245) } }
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :306:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A) Invoke_O_O__O(self, p1__1685000123_SHARP___1 any) any { var root_1247 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1251 any = p1__1685000123_SHARP___1; var arg_1252 any = t.F_unver; if linked_1248 == nil { return ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { return linked_1248.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) } }
func A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :307:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :307:1
func (t *A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A) Invoke_O_O__O(self, p1__1685000124_SHARP___1 any) any { var tmp1 any; var root_1254 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = t.F_unver; if linked_1255 == nil { tmp1 = ifn_1256.Invoke_O__O(arg_1257) } else { tmp1 = linked_1255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1254, arg_1257) }; if jrt.J2g_Truth(tmp1) { var root_1258 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = p1__1685000124_SHARP___1; var arg_1262 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp4 any; var root_1263 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any; var root_1267 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = t.F_ds; if linked_1268 == nil { arg_1266 = ifn_1269.Invoke_O__O(arg_1270) } else { arg_1266 = linked_1268.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1267, arg_1270) }; if linked_1264 == nil { tmp4 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp4 = linked_1264.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1263, arg_1266) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1271 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = t.F_form; if linked_1272 == nil { tmp6 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp6 = linked_1272.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1271, arg_1274) }; arg_1262 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1259 == nil { return ifn_1260.Invoke_O_O__O(arg_1261, arg_1262) } else { return linked_1259.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1258, arg_1261, arg_1262) } } else { return p1__1685000124_SHARP___1 } }





















func A_arbace_go_check_check_package_fn__1685000295_A_New() *A_arbace_go_check_check_package_fn__1685000295_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000295_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_go_check_check_package_fn__1685000295_A) Ctor() {}
//line :329:1
func (t *A_arbace_go_check_check_package_fn__1685000295_A) Invoke_O_O__O(self, p1__1685000125_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_210; var tmp2 any; var root_2454 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = p1__1685000125_SHARP___1; if linked_2455 == nil { tmp2 = ifn_2456.Invoke_O__O(arg_2457) } else { tmp2 = linked_2455.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2454, arg_2457) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000297__1685000301_A_New() *A_arbace_go_check_check_package_iter__1685000297__1685000301_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000297__1685000301_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_go_check_check_package_iter__1685000297__1685000301_A) Ctor() {}
//line :333:1
func (t *A_arbace_go_check_check_package_iter__1685000297__1685000301_A) Invoke_O_O__O(self, s__1685000298__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A_New_O_O(s__1685000298__1, self); var tmp2 *jrt.Class; var fncls__2538 *jrt.Class = A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A_fn_class; if fncls__2538 == nil { var fncls__2538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A_fn_class = fncls__2538d; tmp2 = fncls__2538d } else { tmp2 = fncls__2538 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :333:1
func A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A{}; t.Ctor_O_O(p0, p1); return t }
//line :333:1
func (t *A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A) Ctor_O_O(c__s__1685000298, c__iter__1685000297 any) { t.F_s__1685000298 = c__s__1685000298; t.F_iter__1685000297 = c__iter__1685000297 }
//line :333:1
func (t *A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A) Invoke_O__O(self any) any { { var s__1685000298__1 any; var t_ any = t.F_s__1685000298; t.F_s__1685000298 = nil; s__1685000298__1 = t_; for { var temp__1927000414__auto____2 any; var root_2463 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = s__1685000298__1; if linked_2464 == nil { temp__1927000414__auto____2 = ifn_2465.Invoke_O__O(arg_2466) } else { temp__1927000414__auto____2 = linked_2464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2463, arg_2466) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000298__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2467 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = s__1685000298__3; if linked_2468 == nil { tmp1 = ifn_2469.Invoke_O__O(arg_2470) } else { tmp1 = linked_2468.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2467, arg_2470) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2471 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = s__1685000298__3; if linked_2472 == nil { c__1927001037__auto____4 = ifn_2473.Invoke_O__O(arg_2474) } else { c__1927001037__auto____4 = linked_2472.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2471, arg_2474) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000300__6 any; var root_2475 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2477 lang.IFn; if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; var arg_2478 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2476 == nil { b__1685000300__6 = ifn_2477.Invoke_O__O(arg_2478) } else { b__1685000300__6 = linked_2476.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2475, arg_2478) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A_New_O_I_O(b__1685000300__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2493 *jrt.Class = A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A_fn_class; if fncls__2493 == nil { var fncls__2493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A_fn_class = fncls__2493d; tmp3 = fncls__2493d } else { tmp3 = fncls__2493 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2494 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any; var root_2499 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = b__1685000300__6; if linked_2500 == nil { arg_2497 = ifn_2501.Invoke_O__O(arg_2502) } else { arg_2497 = linked_2500.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2499, arg_2502) }; var arg_2498 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000297); var tmp5 any; var root_2503 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = s__1685000298__3; if linked_2504 == nil { tmp5 = ifn_2505.Invoke_O__O(arg_2506) } else { tmp5 = linked_2504.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2503, arg_2506) }; arg_2498 = tmp4.Invoke_O__O(tmp5); if linked_2495 == nil { return ifn_2496.Invoke_O_O__O(arg_2497, arg_2498) } else { return linked_2495.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2494, arg_2497, arg_2498) } } else { var root_2507 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any; var root_2512 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any = b__1685000300__6; if linked_2513 == nil { arg_2510 = ifn_2514.Invoke_O__O(arg_2515) } else { arg_2510 = linked_2513.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2512, arg_2515) }; var arg_2511 any; if linked_2508 == nil { return ifn_2509.Invoke_O_O__O(arg_2510, arg_2511) } else { return linked_2508.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2507, arg_2510, arg_2511) } } } else { var d__4 any; var root_2516 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = s__1685000298__3; if linked_2517 == nil { d__4 = ifn_2518.Invoke_O__O(arg_2519) } else { d__4 = linked_2517.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2516, arg_2519) }; var root_2520 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2520, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2522 lang.IFn; if linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 any; var root_2525 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2527 lang.IFn
															if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any; var root_2530 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = d__4; if linked_2531 == nil { arg_2528 = ifn_2532.Invoke_O__O(arg_2533) } else { arg_2528 = linked_2531.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2530, arg_2533) }; var arg_2529 any = A_arbace_go_check_A_const_243; if linked_2526 == nil { arg_2523 = ifn_2527.Invoke_O_O__O(arg_2528, arg_2529) } else { arg_2523 = linked_2526.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2525, arg_2528, arg_2529) }
//line :333:1
	var arg_2524 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000297); var tmp7 any; var root_2534 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = s__1685000298__3; if linked_2535 == nil { tmp7 = ifn_2536.Invoke_O__O(arg_2537) } else { tmp7 = linked_2535.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2534, arg_2537) }; arg_2524 = tmp6.Invoke_O__O(tmp7); if linked_2521 == nil { return ifn_2522.Invoke_O_O__O(arg_2523, arg_2524) } else { return linked_2521.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2520, arg_2523, arg_2524) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :333:1
func A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :333:1
func (t *A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A) Ctor_O_I_O(c__b__1685000300 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000300 = c__b__1685000300; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :333:1
func (t *A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A) Invoke_O__O(self any) any { { var i__1685000299__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000299__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000299__1)); var root_2479 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2481 lang.IFn; if linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any = t.F_b__1685000300; var arg_2483 any; var root_2484 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2486 lang.IFn
																	if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any; var root_2489 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2491 lang.IFn; if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = d__2; if linked_2490 == nil { arg_2487 = ifn_2491.Invoke_O__O(arg_2492) } else { arg_2487 = linked_2490.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2489, arg_2492) }; var arg_2488 any = A_arbace_go_check_A_const_242; if linked_2485 == nil { arg_2483 = ifn_2486.Invoke_O_O__O(arg_2487, arg_2488) } else { arg_2483 = linked_2485.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2484, arg_2487, arg_2488) }
//line :333:1
	if linked_2480 == nil { ifn_2481.Invoke_O_O__O(arg_2482, arg_2483) } else { linked_2480.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2479, arg_2482, arg_2483) }; i__1685000299__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000299__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_check_package_fn__1685000307_A_New() *A_arbace_go_check_check_package_fn__1685000307_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000307_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_go_check_check_package_fn__1685000307_A) Ctor() {}
//line :339:1
func (t *A_arbace_go_check_check_package_fn__1685000307_A) Invoke_O_O__O(self, lhs__1 any) any { var root_2545 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A_New(); var tmp2 *jrt.Class; var fncls__2574 *jrt.Class = A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A_fn_class; if fncls__2574 == nil { var fncls__2574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A_fn_class = fncls__2574d; tmp2 = fncls__2574d } else { tmp2 = fncls__2574 }; arg_2548 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2549 any = lhs__1; if linked_2546 == nil { return ifn_2547.Invoke_O_O__O(arg_2548, arg_2549) } else { return linked_2546.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2545, arg_2548, arg_2549) } }
//line :339:1
func A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A_New() *A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A) Ctor() {}
//line :339:1
func (t *A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_2550 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any = v__1; var arg_2554 any = A_arbace_go_check_A_const_70; if linked_2551 == nil { tmp1 = ifn_2552.Invoke_O_O__O(arg_2553, arg_2554) } else { tmp1 = linked_2551.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2550, arg_2553, arg_2554) }; var tmp2 any = tmp1; var tmp3 any; var root_2555 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = v__1; var arg_2559 any = A_arbace_go_check_A_const_73; if linked_2556 == nil { tmp3 = ifn_2557.Invoke_O_O__O(arg_2558, arg_2559) } else { tmp3 = linked_2556.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2555, arg_2558, arg_2559) }; var tmp4 any = tmp3; var tmp5 any; var root_2560 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = v__1; var arg_2564 any = A_arbace_go_check_A_const_78; if linked_2561 == nil { tmp5 = ifn_2562.Invoke_O_O__O(arg_2563, arg_2564) } else { tmp5 = linked_2561.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2560, arg_2563, arg_2564) }; var tmp6 any = tmp5; var tmp7 any; var root_2565 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2567 lang.IFn; if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any; var root_2569 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2569, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = v__1; var arg_2573 any = A_arbace_go_check_A_const_247; if linked_2570 == nil { arg_2568 = ifn_2571.Invoke_O_O__O(arg_2572, arg_2573) } else { arg_2568 = linked_2570.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2569, arg_2572, arg_2573) }; if linked_2566 == nil { tmp7 = ifn_2567.Invoke_O__O(arg_2568) } else { tmp7 = linked_2566.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2565, arg_2568) }; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :347:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_257; var tmp2 any = A_arbace_go_check_A_const_258; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_259; var tmp5 any; var root_2714 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_2715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2714, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2716 lang.IFn; if



	linked_2715 == nil { ifn_2716 = lang.IFn_Cast(root_2714) } else { ifn_2716 = nil }; var arg_2717 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2715 == nil { tmp5 = ifn_2716.Invoke_O__O(arg_2717) } else { tmp5 = linked_2715.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2714, arg_2717) }; return /*line :347:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :355:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2718 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2718, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2720 lang.IFn; if



	linked_2719 == nil { ifn_2720 = lang.IFn_Cast(root_2718) } else { ifn_2720 = nil }; var arg_2721 any = A_arbace_go_check_A_const_259.Invoke_O__O(s__0); if linked_2719 == nil { tmp1 = ifn_2720.Invoke_O__O(arg_2721) } else { tmp1 = linked_2719.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2718, arg_2721) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_258.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2722 any = A_arbace_go_check_A_const_261.GetRawRoot__O(); var linked_2723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2722, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2724 lang.IFn; if linked_2723 == nil { ifn_2724 = lang.IFn_Cast(root_2722) } else { ifn_2724 = nil }; var arg_2725 any = p__5; if linked_2723 == nil { tmp2 = ifn_2724.Invoke_O__O(arg_2725) } else { tmp2 = linked_2723.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2722, arg_2725) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2726 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any = p__5; if linked_2727 == nil { or__1927000174__auto____3 = ifn_2728.Invoke_O__O(arg_2729) } else { or__1927000174__auto____3 = linked_2727.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2726, arg_2729) } } else { or__1927000174__auto____3 = nil } } else {
//line :359:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_262.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2730 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, A_arbace_go_check_ns_package_A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = d__5; var arg_2734 any = ns_name__1; if linked_2731 == nil { return ifn_2732.Invoke_O_O__O(arg_2733, arg_2734) } else { return linked_2731.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2730, arg_2733, arg_2734) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :364:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000314_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2778 *jrt.Class = A_arbace_go_check_resolver_fn__1685000314_A_fn_class; _ = deps__4; if




	fncls__2778 == nil { var fncls__2778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_resolver_fn__1685000314_A_fn_class = fncls__2778d; tmp2 = fncls__2778d } else { tmp2 = fncls__2778 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :369:1
func A_arbace_go_check_resolver_fn__1685000314_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000314_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000314_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :369:1
func (t *A_arbace_go_check_resolver_fn__1685000314_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :369:1
func (t *A_arbace_go_check_resolver_fn__1685000314_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_135, path__1) { return A_arbace_go_check_A_const_264.GetRawRoot__O() } else { var lp__3 any; var root_2735 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2735, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2737 lang.IFn

		if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any = t.F_src; var arg_2739 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_81, A_arbace_go_check_A_const_265, path__1); var arg_2740 any = path__1; if linked_2736 == nil { lp__3 = ifn_2737.Invoke_O_O_O__O(arg_2738, arg_2739, arg_2740) } else { lp__3 = linked_2736.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2735, arg_2738, arg_2739, arg_2740) }
//line :372:1
		var why__4 any; var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_266.Invoke_O__O(t.F_s)



		if jrt.J2g_Truth(temp__1927000414__auto____4) { var rf__5 any = temp__1927000414__auto____4; why__4 = lang.IFn_Cast(rf__5).Invoke_O_O__O(lp__3, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_src)) } else { why__4 = nil }
//line :372:1
		var p__5 any
		var or__1927000174__auto____5 any = why__4




		if jrt.J2g_Truth(or__1927000174__auto____5) { p__5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_2741 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2741, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2743 lang.IFn
			if linked_2742 == nil { ifn_2743 = lang.IFn_Cast(root_2741) } else { ifn_2743 = nil }; var arg_2744 any = t.F_s; var arg_2745 any = lp__3; var arg_2746 any = t.F_src; var arg_2747 any = t.F_chain; if linked_2742 == nil { or__1927000174__auto____6 = ifn_2743.Invoke_O_O_O_O__O(arg_2744, arg_2745, arg_2746, arg_2747) } else { or__1927000174__auto____6 = linked_2742.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2741, arg_2744, arg_2745, arg_2746, arg_2747) }
//line :378:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { p__5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 any; var and__1927000168__auto____7 any; var root_2748 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2750 lang.IFn

				if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any; var root_2752 any = A_arbace_go_check_A_const_268.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any; var root_2757 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2757, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2759 lang.IFn; if linked_2758 == nil { ifn_2759 = lang.IFn_Cast(root_2757) } else { ifn_2759 = nil }; var arg_2760 any; var root_2761 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2761, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2763 lang.IFn; if linked_2762 == nil { ifn_2763 = lang.IFn_Cast(root_2761) } else { ifn_2763 = nil }; var arg_2764 any = lp__3; var arg_2765 any = A_arbace_go_check_A_const_270; if linked_2762 == nil { arg_2760 = ifn_2763.Invoke_O_O__O(arg_2764, arg_2765) } else { arg_2760 = linked_2762.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2761, arg_2764, arg_2765) }; if linked_2758 == nil { arg_2755 = ifn_2759.Invoke_O__O(arg_2760) } else { arg_2755 = linked_2758.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2757, arg_2760) }; var arg_2756 any = Lit_136; if linked_2753 == nil { arg_2751 = ifn_2754.Invoke_O_O__O(arg_2755, arg_2756) } else { arg_2751 = linked_2753.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2752, arg_2755, arg_2756) }; if linked_2749 == nil { and__1927000168__auto____7 = ifn_2750.Invoke_O__O(arg_2751) } else { and__1927000168__auto____7 = linked_2749.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2748, arg_2751) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____7 = nil } else { or__1927000174__auto____7 = nil }
//line :378:1
				if jrt.J2g_Truth(or__1927000174__auto____7) { p__5 = or__1927000174__auto____7 } else {


					var root_2766 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = t.F_s; var arg_2770 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2771 any = t.F_src; var arg_2772 any = t.F_chain; if linked_2767 == nil { p__5 = ifn_2768.Invoke_O_O_O_O__O(arg_2769, arg_2770, arg_2771, arg_2772) } else { p__5 = linked_2767.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2766, arg_2769, arg_2770, arg_2771, arg_2772) } } } }
//line :372:1
		return p__5 } }
//line :369:1
func (t *A_arbace_go_check_resolver_fn__1685000314_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2773 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2773, A_arbace_go_check_ns_package_A_fn_class); var ifn_2775 lang.IFn; if linked_2774 == nil { ifn_2775 = lang.IFn_Cast(root_2773) } else { ifn_2775 = nil }; var arg_2776 any = t.F_s; var arg_2777 any = ns_name__1; if linked_2774 == nil { return ifn_2775.Invoke_O_O__O(arg_2776, arg_2777) } else { return linked_2774.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2773, arg_2776, arg_2777)
	}
}











func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :384:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2860 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2860, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2862 lang.IFn; if linked_2861 == nil { ifn_2862 = lang.IFn_Cast(root_2860) } else { ifn_2862 = nil }; var arg_2863 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2864 any = chain__3; if linked_2861 == nil { tmp1 = ifn_2862.Invoke_O_O__O(arg_2863, arg_2864) } else { tmp1 = linked_2861.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2860, arg_2863, arg_2864) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2865 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2865, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2867 lang.IFn
		if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_109, nil); var tmp4 any; var root_2870 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2872 lang.IFn; if linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any = Lit_110; var arg_2874 any; var root_2875 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2875, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2877 lang.IFn; if linked_2876 == nil { ifn_2877 = lang.IFn_Cast(root_2875) } else { ifn_2877 = nil }; var arg_2878 any = chain__3; var arg_2879 any = path__1; if linked_2876 == nil { arg_2874 = ifn_2877.Invoke_O_O__O(arg_2878, arg_2879) } else { arg_2874 = linked_2876.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2875, arg_2878, arg_2879) }; if linked_2871 == nil { tmp4 = ifn_2872.Invoke_O_O__O(arg_2873, arg_2874) } else { tmp4 = linked_2871.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2870, arg_2873, arg_2874) }; arg_2868 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2869 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110, path__1)); if linked_2866 == nil { tmp2 = ifn_2867.Invoke_O_O__O(arg_2868, arg_2869) } else { tmp2 = linked_2866.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2865, arg_2868, arg_2869) }
//line :387:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :384:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_262.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2779 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2779, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2781 lang.IFn; if linked_2780 == nil { ifn_2781 = lang.IFn_Cast(root_2779) } else { ifn_2781 = nil }; var arg_2782 any = lang.IFn_Cast(A_arbace_go_check_A_const_271.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2780 == nil { and__1927000168__auto____6 = ifn_2781.Invoke_O__O(arg_2782) } else { and__1927000168__auto____6 = linked_2780.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2779, arg_2782) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_262.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2783 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2785 lang.IFn

		if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any = d__6; var arg_2787 any = path__1; var arg_2788 any = importer__2; var arg_2789 any = chain__3; if linked_2784 == nil { return ifn_2785.Invoke_O_O_O_O__O(arg_2786, arg_2787, arg_2788, arg_2789) } else { return linked_2784.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2783, arg_2786, arg_2787, arg_2788, arg_2789) } } else {
//line :389:1
			var cache__6 any = A_arbace_go_check_A_const_258.Invoke_O__O(s__0); var p__7 any; var root_2790 any = A_arbace_go_check_A_const_272.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2792 lang.IFn



			if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; if linked_2791 == nil { p__7 = ifn_2792.Invoke__O() } else { p__7 = linked_2791.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2790) }
//line :389:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2793 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2793, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2795 lang.IFn; if linked_2794 == nil { ifn_2795 = lang.IFn_Cast(root_2793) } else { ifn_2795 = nil }; var arg_2796 any = prev__8; if linked_2794 == nil { return ifn_2795.Invoke_O__O(arg_2796) } else { return linked_2794.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2793, arg_2796) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_257.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2797 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2797, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2799 lang.IFn; if linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__9); if linked_2798 == nil { tmp5 = ifn_2799.Invoke_O__O(arg_2800) } else { tmp5 = linked_2798.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2797, arg_2800) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000317_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2859 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000317_A_fn_class; if fncls__2859 == nil { var fncls__2859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_check_ensure_package_fn__1685000317_A_fn_class = fncls__2859d; tmp7 = fncls__2859d } else { tmp7 = fncls__2859 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :398:1
						pkg__10 = nil
					}






				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2880 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2880, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2884 any = A_arbace_go_check_A_const_278; var arg_2885 any; var root_2886 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2890 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_279; var tmp11 any; var root_2891 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = pkg__10; var arg_2895 any = A_arbace_go_check_A_const_71; if linked_2892 == nil { tmp11 = ifn_2893.Invoke_O_O__O(arg_2894, arg_2895) } else { tmp11 = linked_2892.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2891, arg_2894, arg_2895) }; arg_2890 = tmp10.Invoke_O__O(tmp11); if linked_2887 == nil { arg_2885 = ifn_2888.Invoke_O_O__O(arg_2889, arg_2890) } else { arg_2885 = linked_2887.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2886, arg_2889, arg_2890) }; if linked_2881 == nil { tmp9 = ifn_2882.Invoke_O_O_O__O(arg_2883, arg_2884, arg_2885) } else { tmp9 = linked_2881.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2880, arg_2883, arg_2884, arg_2885) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2896 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any = A_arbace_go_check_A_const_259.Invoke_O__O(s__0); var arg_2900 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var arg_2901 any; var root_2903 any = A_arbace_go_check_A_const_186.GetRawRoot__O(); var linked_2904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2903, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_2905 lang.IFn; if linked_2904 == nil { ifn_2905 = lang.IFn_Cast(root_2903) } else { ifn_2905 = nil }; var arg_2906 any = path__1; if linked_2904 == nil { arg_2901 = ifn_2905.Invoke_O__O(arg_2906) } else { arg_2901 = linked_2904.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2903, arg_2906) }; var arg_2902 any = path__1; if linked_2897 == nil { ifn_2898.Invoke_O_O_O_O__O(arg_2899, arg_2900, arg_2901, arg_2902) } else { linked_2897.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2896, arg_2899, arg_2900, arg_2901, arg_2902) }
				var root_2907 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2907, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2909 lang.IFn; if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any = p__7; var arg_2911 any = pkg__10; if linked_2908 == nil { ifn_2909.Invoke_O_O__O(arg_2910, arg_2911) } else { linked_2908.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2907, arg_2910, arg_2911) }
//line :395:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000317_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000317_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000317_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :399:1
func (t *A_arbace_go_check_ensure_package_fn__1685000317_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :399:1
func (t *A_arbace_go_check_ensure_package_fn__1685000317_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var G__1685000318__3_ any = A_arbace_go_check_A_const_108.Invoke_O__O(t.F_s); if lang.Util_Identical_O_O__Z_NoInit(G__1685000318__3_, nil) { tmp2 = nil } else { var root_2801 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = G__1685000318__3_; var arg_2805 any = lang.Tuple_Create_O__IPersistentVector(t.F_path); if linked_2802 == nil { tmp2 = ifn_2803.Invoke_O_O__O(arg_2804, arg_2805) } else { tmp2 = linked_2802.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2801, arg_2804, arg_2805) } }; if jrt.J2g_Truth(tmp2) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_273.GetRawRoot__O()); var tmp4 any = t.F_src; var tmp5 any; var root_2813 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2813, A_arbace_go_check_resolver_A_fn_class); var ifn_2815 lang.IFn; if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any; var t_ any = t.F_s; t.F_s = nil; arg_2816 = t_; var arg_2817 any; var t__2 any = t.F_src; t.F_src = nil; arg_2817 = t__2; var arg_2818 any; var root_2819 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2821 lang.IFn; if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any; var root_2824 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2827 = t__3; if linked_2825 == nil { arg_2822 = ifn_2826.Invoke_O__O(arg_2827) } else { arg_2822 = linked_2825.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2824, arg_2827) }; var arg_2823 any = t.F_path; if linked_2820 == nil { arg_2818 = ifn_2821.Invoke_O_O__O(arg_2822, arg_2823) } else { arg_2818 = linked_2820.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2819, arg_2822, arg_2823) }; if linked_2814 == nil { tmp5 = ifn_2815.Invoke_O_O_O__O(arg_2816, arg_2817, arg_2818) } else { tmp5 = linked_2814.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2813, arg_2816, arg_2817, arg_2818) }; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, A_arbace_go_check_A_const_108, jrt.Boolean_TRUE.Ref()) } else {
													var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_273.GetRawRoot__O()); var tmp7 any = t.F_src; var tmp8 any; var root_2833 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, A_arbace_go_check_resolver_A_fn_class); var ifn_2835 lang.IFn; if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var arg_2836 any; var t__4 any = t.F_s; t.F_s = nil; arg_2836 = t__4; var arg_2837 any; var t__5 any = t.F_src; t.F_src = nil; arg_2837 = t__5; var arg_2838 any; var root_2839 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2839, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any; var root_2844 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2844, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2846 lang.IFn; if linked_2845 == nil { ifn_2846 = lang.IFn_Cast(root_2844) } else { ifn_2846 = nil }; var arg_2847 any; var t__6 any = t.F_chain; t.F_chain = nil; arg_2847 = t__6; if linked_2845 == nil { arg_2842 = ifn_2846.Invoke_O__O(arg_2847) } else { arg_2842 = linked_2845.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2844, arg_2847) }; var arg_2843 any = t.F_path; if linked_2840 == nil { arg_2838 = ifn_2841.Invoke_O_O__O(arg_2842, arg_2843) } else { arg_2838 = linked_2840.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2839, arg_2842, arg_2843) }; if linked_2834 == nil { tmp8 = ifn_2835.Invoke_O_O_O__O(arg_2836, arg_2837, arg_2838) } else { tmp8 = linked_2834.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2833, arg_2836, arg_2837, arg_2838) }; tmp1 = tmp6.Invoke_O_O__O(tmp7, tmp8) } }
//line :399:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_2854 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2856 lang.IFn




		if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any; var t__7 any = t.F_p; t.F_p = nil; arg_2857 = t__7; var arg_2858 any; if linked_2855 == nil { ifn_2856.Invoke_O_O__O(arg_2857, arg_2858) } else { linked_2855.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2854, arg_2857, arg_2858) }
//line :399:1
		var tmp10 any; var root_2848 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2850 lang.IFn





		if linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var tmp11 any = t.F_path; var arg_2851 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_112, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2852 any; var tmp12 any = A_arbace_go_check_A_const_110; var tmp13 any; var t__8 any = t.F_path; t.F_path = nil; tmp13 = t__8; arg_2852 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); var arg_2853 any = ex__3; if linked_2849 == nil { tmp10 = ifn_2850.Invoke_O_O_O__O(arg_2851, arg_2852, arg_2853) } else { tmp10 = linked_2849.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2848, arg_2851, arg_2852, arg_2853) }
//line :399:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) } }; return tmp1 }











func A_arbace_go_check_check_src_A_New() *A_arbace_go_check_check_src_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_src_A{}; t.Ctor(); return t }
//line :411:1
func (t *A_arbace_go_check_check_src_A) Ctor() {}
//line :411:1
func (t *A_arbace_go_check_check_src_A) Invoke_O_O_O__O(self, s__0, src__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_273.GetRawRoot__O()); var tmp2 any; var root_2917 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2917, A_arbace_go_check_resolver_A_fn_class); var ifn_2919 lang.IFn; if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any = s__0; var arg_2921 any = src__1; var arg_2922 any = lang.PersistentVector_EMPTY.Ref(); if linked_2918 == nil { tmp2 = ifn_2919.Invoke_O_O_O__O(arg_2920, arg_2921, arg_2922) } else { tmp2 = linked_2918.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2917, arg_2920, arg_2921, arg_2922) }; return tmp1.Invoke_O_O__O(src__1, tmp2)
}










func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :426:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :426:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var temp__1927000408__auto____2 any = A_arbace_go_check_A_const_281.Get__O(); if
											jrt.J2g_Truth(temp__1927000408__auto____2) { var f__3 any = temp__1927000408__auto____2; var G__1685000322__4_ any = corpus__0
												switch lang.Util_Hash_O__I_NoInit(G__1685000322__4_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000322__4_, Lit_92) { var tmp1 any = A_arbace_go_check_A_const_282; var tmp2 any = A_arbace_go_check_A_const_284; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_283; var tmp5 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_285, Lit_95)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_286)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000322__4_, Lit_96) { var tmp6 any = A_arbace_go_check_A_const_282; var tmp7 any = A_arbace_go_check_A_const_284; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_287; var tmp10 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_97), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_285, Lit_95)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_288)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000322__4_, Lit_54) { var tmp11 any = A_arbace_go_check_A_const_282; var tmp12 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_289)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000322__4_, Lit_99) { var tmp13 any = A_arbace_go_check_A_const_282; var tmp14 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_290)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000322__4_, Lit_101) { var tmp15 any = A_arbace_go_check_A_const_282; var tmp16 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_297)) }; default:}; var tmp17 any; var root_2924 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2924, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2926 lang.IFn







		if linked_2925 == nil { ifn_2926 = lang.IFn_Cast(root_2924) } else { ifn_2926 = nil }; var arg_2927 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2928 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_291, corpus__0)); if linked_2925 == nil { tmp17 = ifn_2926.Invoke_O_O__O(arg_2927, arg_2928) } else { tmp17 = linked_2925.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2924, arg_2927, arg_2928) }
//line :428:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) } else {
//line :427:1
			var G__1685000323__3_ any = corpus__0









			switch lang.Util_Hash_O__I_NoInit(G__1685000323__3_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000323__3_, Lit_92) { var tmp18 any = A_arbace_go_check_A_const_282; var tmp19 any = A_arbace_go_check_A_const_284; var tmp20 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref()))); var tmp21 any = A_arbace_go_check_A_const_283; var tmp22 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp20, tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_285, Lit_95)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_293)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000323__3_, Lit_96) { var tmp23 any = A_arbace_go_check_A_const_282; var tmp24 any = A_arbace_go_check_A_const_284; var tmp25 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref()))); var tmp26 any = A_arbace_go_check_A_const_287; var tmp27 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp25, tmp26, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_285, Lit_95)), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_294)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000323__3_, Lit_54) { var tmp28 any = A_arbace_go_check_A_const_282; var tmp29 any = A_arbace_go_check_A_const_284; var tmp30 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_106), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref(); var tmp31 any = A_arbace_go_check_A_const_298; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_295)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000323__3_, Lit_99) { var tmp32 any = A_arbace_go_check_A_const_282; var tmp33 any = A_arbace_go_check_A_const_284; var tmp34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_106), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref(); var tmp35 any = A_arbace_go_check_A_const_298; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_296)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000323__3_, Lit_101) { var tmp36 any = A_arbace_go_check_A_const_282; var tmp37 any = A_arbace_go_check_A_const_284; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp36, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_111, A_arbace_go_check_A_const_299)) }; default:}; var tmp38 any; var root_2930 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2930, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2932 lang.IFn












			if linked_2931 == nil { ifn_2932 = lang.IFn_Cast(root_2930) } else { ifn_2932 = nil }; var arg_2933 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2934 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_291, corpus__0)); if linked_2931 == nil { tmp38 = ifn_2932.Invoke_O_O__O(arg_2933, arg_2934) } else { tmp38 = linked_2931.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2930, arg_2933, arg_2934) }
//line :437:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp38))) } }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :452:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :452:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000326__0 any) any { var map__1685000327__2 any = p__1685000326__0; var map__1685000327__3 any; if lang.ISeq_InstanceOf(map__1685000327__2) { var tmp1 any; var root_2935 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2935, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2937 lang.IFn; if linked_2936 == nil { ifn_2937 = lang.IFn_Cast(root_2935) } else { ifn_2937 = nil }; var arg_2938 any = map__1685000327__2; if linked_2936 == nil { tmp1 = ifn_2937.Invoke_O__O(arg_2938) } else { tmp1 = linked_2936.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2935, arg_2938) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2939 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = map__1685000327__2; if linked_2940 == nil { tmp2 = ifn_2941.Invoke_O__O(arg_2942) } else { tmp2 = linked_2940.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2939, arg_2942) }; map__1685000327__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2943 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = map__1685000327__2; if linked_2944 == nil { tmp3 = ifn_2945.Invoke_O__O(arg_2946) } else { tmp3 = linked_2944.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2943, arg_2946) }; if jrt.J2g_Truth(tmp3) { var root_2947 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = map__1685000327__2; if linked_2948 == nil { map__1685000327__3 = ifn_2949.Invoke_O__O(arg_2950) } else { map__1685000327__3 = linked_2948.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2947, arg_2950) } } else { map__1685000327__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000327__3 = map__1685000327__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000327__3, A_arbace_go_check_A_const_282); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000327__3, A_arbace_go_check_A_const_111); var root_2951 any = A_arbace_go_check_A_const_300.GetRawRoot__O(); var linked_2952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2951, A_arbace_go_check_session_A_fn_class); var ifn_2953 lang.IFn; if
											linked_2952 == nil { ifn_2953 = lang.IFn_Cast(root_2951) } else { ifn_2953 = nil }; var arg_2954 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000329_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__2967 *jrt.Class = A_arbace_go_check_std_session_fn__1685000329_A_fn_class; if fncls__2967 == nil { var fncls__2967d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_check_std_session_fn__1685000329_A_fn_class = fncls__2967d; tmp5 = fncls__2967d } else { tmp5 = fncls__2967 }; arg_2954 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_2952 == nil { return ifn_2953.Invoke_O__O(arg_2954) } else { return linked_2952.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2951, arg_2954) } }
//line :453:1
func A_arbace_go_check_std_session_fn__1685000329_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000329_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :453:1
func (t *A_arbace_go_check_std_session_fn__1685000329_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :453:1
func (t *A_arbace_go_check_std_session_fn__1685000329_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_2955 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2955, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2957 lang.IFn; if linked_2956 == nil { ifn_2957 = lang.IFn_Cast(root_2955) } else { ifn_2957 = nil }; var arg_2958 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__2966 *jrt.Class = A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A_fn_class; if fncls__2966 == nil { var fncls__2966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A_fn_class = fncls__2966d; tmp2 = fncls__2966d } else { tmp2 = fncls__2966 }; arg_2958 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2959 any = t.F_roots; if linked_2956 == nil { return ifn_2957.Invoke_O_O__O(arg_2958, arg_2959) } else { return linked_2956.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2955, arg_2958, arg_2959) } }
//line :454:1
func A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A{}; t.Ctor_O_O(p0, p1); return t }
//line :454:1
func (t *A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :454:1
func (t *A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A) Invoke_O_O__O(self, p1__1685000325_SHARP___1 any) any { var root_2960 any = A_arbace_go_check_A_const_301.GetRawRoot__O(); var linked_2961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2960, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2962 lang.IFn; if linked_2961 == nil { ifn_2962 = lang.IFn_Cast(root_2960) } else { ifn_2962 = nil }; var arg_2963 any = p1__1685000325_SHARP___1; var arg_2964 any = t.F_path; var arg_2965 any = t.F_config; if linked_2961 == nil { return ifn_2962.Invoke_O_O_O__O(arg_2963, arg_2964, arg_2965) } else { return linked_2961.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_2960, arg_2963, arg_2964, arg_2965) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :460:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :460:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_2968 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2968, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2970 lang.IFn; if


	linked_2969 == nil { ifn_2970 = lang.IFn_Cast(root_2968) } else { ifn_2970 = nil }; var arg_2971 any = xs__2; if linked_2969 == nil { xs__4 = ifn_2970.Invoke_O__O(arg_2971) } else { xs__4 = linked_2969.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2968, arg_2971) }; var q__5 any = /*line :460:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_2972 any = A_arbace_go_check_A_const_302.GetRawRoot__O(); var linked_2973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2972, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2974 lang.IFn; if





	linked_2973 == nil { ifn_2974 = lang.IFn_Cast(root_2972) } else { ifn_2974 = nil }; var arg_2975 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__3044 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A_fn_class; if fncls__3044 == nil { var fncls__3044d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A_fn_class = fncls__3044d; tmp2 = fncls__3044d } else { tmp2 = fncls__3044 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_3045 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3047 lang.IFn; if linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any = n__0; if linked_3046 == nil { tmp4 = ifn_3047.Invoke_O__O(arg_3048) } else { tmp4 = linked_3046.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3045, arg_3048) }; arg_2975 = tmp3.Invoke_O__O(tmp4); if linked_2973 == nil { workers__7 = ifn_2974.Invoke_O__O(arg_2975) } else { workers__7 = linked_2973.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2972, arg_2975) }; var seq_1685000348__8 any; var root_3053 any = /*line :460:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3053, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3055 lang.IFn; if















	linked_3054 == nil { ifn_3055 = lang.IFn_Cast(root_3053) } else { ifn_3055 = nil }; var arg_3056 any = workers__7; if linked_3054 == nil { seq_1685000348__8 = ifn_3055.Invoke_O__O(arg_3056) } else { seq_1685000348__8 = linked_3054.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3053, arg_3056) }; var chunk_1685000349__9 any; var count_1685000350__10 int64 = 0; var i_1685000351__11 int64 = 0; L1:
//line :460:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000351__11, count_1685000350__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000349__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000351__11)); var root_3073 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3073, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3075 lang.IFn; if linked_3074 == nil { ifn_3075 = lang.IFn_Cast(root_3073) } else { ifn_3075 = nil }; var arg_3076 any = w__12; if linked_3074 == nil { ifn_3075.Invoke_O__O(arg_3076) } else { linked_3074.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3073, arg_3076) }; seq_1685000348__8, chunk_1685000349__9, count_1685000350__10, i_1685000351__11 = seq_1685000348__8, chunk_1685000349__9, count_1685000350__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000351__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_3057 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3057, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3059 lang.IFn; if linked_3058 == nil { ifn_3059 = lang.IFn_Cast(root_3057) } else { ifn_3059 = nil }; var arg_3060 any = seq_1685000348__8; if linked_3058 == nil { temp__1927000414__auto____12 = ifn_3059.Invoke_O__O(arg_3060) } else { temp__1927000414__auto____12 = linked_3058.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3057, arg_3060) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000348__13 any = temp__1927000414__auto____12; var tmp5 any; var root_3061 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3061, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3063 lang.IFn; if linked_3062 == nil { ifn_3063 = lang.IFn_Cast(root_3061) } else { ifn_3063 = nil }; var arg_3064 any = seq_1685000348__13; if linked_3062 == nil { tmp5 = ifn_3063.Invoke_O__O(arg_3064) } else { tmp5 = linked_3062.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3061, arg_3064) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_3065 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3065, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3067 lang.IFn; if linked_3066 == nil { ifn_3067 = lang.IFn_Cast(root_3065) } else { ifn_3067 = nil }; var arg_3068 any = seq_1685000348__13; if linked_3066 == nil { c__1927000678__auto____14 = ifn_3067.Invoke_O__O(arg_3068) } else { c__1927000678__auto____14 = linked_3066.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3065, arg_3068) }; var tmp6 any; var root_3077 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3079 lang.IFn; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = seq_1685000348__13; if linked_3078 == nil { tmp6 = ifn_3079.Invoke_O__O(arg_3080) } else { tmp6 = linked_3078.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3077, arg_3080) }; seq_1685000348__8, chunk_1685000349__9, count_1685000350__10, i_1685000351__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_3069 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3069, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3071 lang.IFn; if linked_3070 == nil { ifn_3071 = lang.IFn_Cast(root_3069) } else { ifn_3071 = nil }; var arg_3072 any = seq_1685000348__13; if linked_3070 == nil { w__14 = ifn_3071.Invoke_O__O(arg_3072) } else { w__14 = linked_3070.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3069, arg_3072) }; var root_3081 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = w__14; if linked_3082 == nil { ifn_3083.Invoke_O__O(arg_3084) } else { linked_3082.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3081, arg_3084) }; var tmp7 any; var root_3085 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3085, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3087 lang.IFn; if linked_3086 == nil { ifn_3087 = lang.IFn_Cast(root_3085) } else { ifn_3087 = nil }; var arg_3088 any = seq_1685000348__13; if linked_3086 == nil { tmp7 = ifn_3087.Invoke_O__O(arg_3088) } else { tmp7 = linked_3086.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3085, arg_3088) }; seq_1685000348__8, chunk_1685000349__9, count_1685000350__10, i_1685000351__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :460:1
		break L1 }; var root_3049 any =
















	A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3051 lang.IFn; if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any = out__6; if linked_3050 == nil { return ifn_3051.Invoke_O__O(arg_3052) } else { return linked_3050.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3049, arg_3052) } }
//line :466:1
func A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :466:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :466:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A) Invoke_O_O__O(self, s__1685000335__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A_New_O_O_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs, s__1685000335__1, self); var tmp2 *jrt.Class; var fncls__3043 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A_fn_class; if fncls__3043 == nil { var fncls__3043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A_fn_class = fncls__3043d; tmp2 = fncls__3043d } else { tmp2 = fncls__3043 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :466:1
func A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :466:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A) Ctor_O_O_O_O_O_O(c__f, c__out, c__q, c__xs, c__s__1685000335, c__iter__1685000334 any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_s__1685000335 = c__s__1685000335; t.F_iter__1685000334 = c__iter__1685000334 }
//line :466:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A) Invoke_O__O(self any) any { { var s__1685000335__1 any; var t_ any = t.F_s__1685000335; t.F_s__1685000335 = nil; s__1685000335__1 = t_; for { var temp__1927000414__auto____2 any; var root_2976 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2976, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2978 lang.IFn; if linked_2977 == nil { ifn_2978 = lang.IFn_Cast(root_2976) } else { ifn_2978 = nil }; var arg_2979 any = s__1685000335__1; if linked_2977 == nil { temp__1927000414__auto____2 = ifn_2978.Invoke_O__O(arg_2979) } else { temp__1927000414__auto____2 = linked_2977.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2976, arg_2979) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000335__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2980 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2980, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2982 lang.IFn; if linked_2981 == nil { ifn_2982 = lang.IFn_Cast(root_2980) } else { ifn_2982 = nil }; var arg_2983 any = s__1685000335__3; if linked_2981 == nil { tmp1 = ifn_2982.Invoke_O__O(arg_2983) } else { tmp1 = linked_2981.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2980, arg_2983) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2984 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2984, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2986 lang.IFn; if linked_2985 == nil { ifn_2986 = lang.IFn_Cast(root_2984) } else { ifn_2986 = nil }; var arg_2987 any = s__1685000335__3; if linked_2985 == nil { c__1927001037__auto____4 = ifn_2986.Invoke_O__O(arg_2987) } else { c__1927001037__auto____4 = linked_2985.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2984, arg_2987) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000337__6 any; var root_2988 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2988, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2990 lang.IFn; if linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; var arg_2991 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2989 == nil { b__1685000337__6 = ifn_2990.Invoke_O__O(arg_2991) } else { b__1685000337__6 = linked_2989.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2988, arg_2991) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_New_O_O_O_O_O_I_O(t.F_f, b__1685000337__6, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3002 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_fn_class; if fncls__3002 == nil { var fncls__3002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_fn_class = fncls__3002d; tmp3 = fncls__3002d } else { tmp3 = fncls__3002 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3003 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any; var root_3008 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3010 lang.IFn; if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = b__1685000337__6; if linked_3009 == nil { arg_3006 = ifn_3010.Invoke_O__O(arg_3011) } else { arg_3006 = linked_3009.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3008, arg_3011) }; var arg_3007 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000334); var tmp5 any; var root_3012 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = s__1685000335__3; if linked_3013 == nil { tmp5 = ifn_3014.Invoke_O__O(arg_3015) } else { tmp5 = linked_3013.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3012, arg_3015) }; arg_3007 = tmp4.Invoke_O__O(tmp5); if linked_3004 == nil { return ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { return linked_3004.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) } } else { var root_3016 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any; var root_3021 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3023 lang.IFn; if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any = b__1685000337__6; if linked_3022 == nil { arg_3019 = ifn_3023.Invoke_O__O(arg_3024) } else { arg_3019 = linked_3022.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3021, arg_3024) }; var arg_3020 any; if linked_3017 == nil { return ifn_3018.Invoke_O_O__O(arg_3019, arg_3020) } else { return linked_3017.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3016, arg_3019, arg_3020) } } } else { var ___4 any; var root_3025 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3025, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3027 lang.IFn; _ = ___4; if linked_3026 == nil { ifn_3027 = lang.IFn_Cast(root_3025) } else { ifn_3027 = nil }; var arg_3028 any = s__1685000335__3; if linked_3026 == nil { ___4 = ifn_3027.Invoke_O__O(arg_3028) } else { ___4 = linked_3026.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3025, arg_3028) }; var root_3029 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3029, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3031 lang.IFn; if linked_3030 == nil { ifn_3031 = lang.IFn_Cast(root_3029) } else { ifn_3031 = nil }; var arg_3032 any; var root_3034 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3036 lang.IFn
															if linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__3038 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A_fn_class; if fncls__3038 == nil { var fncls__3038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A_fn_class = fncls__3038d; tmp7 = fncls__3038d } else { tmp7 = fncls__3038 }; arg_3037 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3035 == nil { arg_3032 = ifn_3036.Invoke_O__O(arg_3037) } else { arg_3032 = linked_3035.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3034, arg_3037) }
//line :466:1
	var arg_3033 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000334); var tmp9 any; var root_3039 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3041 lang.IFn; if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any = s__1685000335__3; if linked_3040 == nil { tmp9 = ifn_3041.Invoke_O__O(arg_3042) } else { tmp9 = linked_3040.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3039, arg_3042) }; arg_3033 = tmp8.Invoke_O__O(tmp9); if linked_3030 == nil { return ifn_3031.Invoke_O_O__O(arg_3032, arg_3033) } else { return linked_3030.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3029, arg_3032, arg_3033) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :466:1
func A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :466:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A) Ctor_O_O_O_O_O_I_O(c__f, c__b__1685000337, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_b__1685000337 = c__b__1685000337; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :466:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A) Invoke_O__O(self any) any { { var i__1685000336__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000336__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000336__1)); var root_2992 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2994 lang.IFn; _ = ___2; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any = t.F_b__1685000337; var arg_2996 any; var root_2997 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2999 lang.IFn
																if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__3001 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A_fn_class; if fncls__3001 == nil { var fncls__3001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A_fn_class = fncls__3001d; tmp3 = fncls__3001d } else { tmp3 = fncls__3001 }; arg_3000 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2998 == nil { arg_2996 = ifn_2999.Invoke_O__O(arg_3000) } else { arg_2996 = linked_2998.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2997, arg_3000) }
//line :466:1
	if linked_2993 == nil { ifn_2994.Invoke_O_O__O(arg_2995, arg_2996) } else { linked_2993.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2992, arg_2995, arg_2996) }; i__1685000336__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000336__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :467:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :467:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_304.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_304.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_305) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_304.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_304.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :470:1
			return nil } } }; /*line :467:1*/panic("j2g: unreachable") }
//line :467:1
func A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :467:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :467:1
func (t *A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_304.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_304.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_305) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_304.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_304.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :470:1
			return nil } } }; /*line :467:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :479:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :479:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_3089 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3089, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3091 lang.IFn; if linked_3090 == nil { ifn_3091 = lang.IFn_Cast(root_3089) } else { ifn_3091 = nil }; var arg_3092 any = pkg__0; var arg_3093 any = A_arbace_go_check_A_const_233; if linked_3090 == nil { return ifn_3091.Invoke_O_O__O(arg_3092, arg_3093) } else { return linked_3090.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3089, arg_3092, arg_3093) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :481:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :481:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_110; var tmp2 any = A_arbace_go_check_A_const_234; var tmp3 any = A_arbace_go_check_A_const_73; var tmp4 any = A_arbace_go_check_A_const_78; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_308; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_114, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_115, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :481:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_309, A_arbace_go_check_A_const_310))), A_arbace_go_check_A_const_163, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_154, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_164, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_139, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_156, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_307, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :488:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_3094 any = A_arbace_go_check_A_const_311.GetRawRoot__O(); var linked_3095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3094, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3096 lang.IFn; if


	linked_3095 == nil { ifn_3096 = lang.IFn_Cast(root_3094) } else { ifn_3096 = nil }; var arg_3097 any = corpus__0; if linked_3095 == nil { cc__3 = ifn_3096.Invoke_O__O(arg_3097) } else { cc__3 = linked_3095.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3094, arg_3097) }; var s__4 any; var root_3098 any = /*line :488:1*/A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3098, A_arbace_go_check_std_session_A_fn_class); var ifn_3100 lang.IFn; if



	linked_3099 == nil { ifn_3100 = lang.IFn_Cast(root_3098) } else { ifn_3100 = nil }; var arg_3101 any = cc__3; if linked_3099 == nil { s__4 = ifn_3100.Invoke_O__O(arg_3101) } else { s__4 = linked_3099.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3098, arg_3101) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :488:1*/A_arbace_go_check_A_const_287.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_283.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_3102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3104 lang.IFn
		if linked_3103 == nil { ifn_3104 = lang.IFn_Cast(root_3102) } else { ifn_3104 = nil }; var arg_3105 any = A_arbace_go_check_A_const_282.Invoke_O__O(cc__3); if linked_3103 == nil { root__5 = ifn_3104.Invoke_O__O(arg_3105) } else { root__5 = linked_3103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3102, arg_3105) }
		var root_3106 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A_New(); var tmp3 *jrt.Class; var fncls__3176 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A_fn_class; if fncls__3176 == nil { var fncls__3176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A_fn_class = fncls__3176d; tmp3 = fncls__3176d } else { tmp3 = fncls__3176 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_3177 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3177, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3179 lang.IFn; if linked_3178 == nil { ifn_3179 = lang.IFn_Cast(root_3177) } else { ifn_3179 = nil }; var arg_3180 any = root__5; var arg_3181 any = Lit_36; if linked_3178 == nil { tmp5 = ifn_3179.Invoke_O_O__O(arg_3180, arg_3181) } else { tmp5 = linked_3178.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3177, arg_3180, arg_3181) }; arg_3109 = tmp4.Invoke_O__O(tmp5); if linked_3107 == nil { std_pkgs__5 = ifn_3108.Invoke_O__O(arg_3109) } else { std_pkgs__5 = linked_3107.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3106, arg_3109) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_3182 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3182, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3184 lang.IFn; if linked_3183 == nil { ifn_3184 = lang.IFn_Cast(root_3182) } else { ifn_3184 = nil }; var arg_3185 any = jobs__1; var arg_3186 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000366_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__3204 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000366_A_fn_class
		if fncls__3204 == nil { var fncls__3204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000366_A_fn_class = fncls__3204d; tmp7 = fncls__3204d } else { tmp7 = fncls__3204 }; arg_3186 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :500:1
		var arg_3187 any = std_pkgs__5; if linked_3183 == nil { return ifn_3184.Invoke_O_O_O__O(arg_3185, arg_3186, arg_3187) } else { return linked_3183.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3182, arg_3185, arg_3186, arg_3187) } } else {
//line :498:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_287.Invoke_O__O(cc__3)) { var map__1685000368__6 any = A_arbace_go_check_A_const_287.Invoke_O__O(cc__3); var map__1685000368__7 any








				if lang.ISeq_InstanceOf(map__1685000368__6) { var tmp8 any; var root_3205 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3205, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3207 lang.IFn; if linked_3206 == nil { ifn_3207 = lang.IFn_Cast(root_3205) } else { ifn_3207 = nil }; var arg_3208 any = map__1685000368__6; if linked_3206 == nil { tmp8 = ifn_3207.Invoke_O__O(arg_3208) } else { tmp8 = linked_3206.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3205, arg_3208) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_3209 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3211 lang.IFn; if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any = map__1685000368__6; if linked_3210 == nil { tmp9 = ifn_3211.Invoke_O__O(arg_3212) } else { tmp9 = linked_3210.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3209, arg_3212) }; map__1685000368__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_3213 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = map__1685000368__6; if linked_3214 == nil { tmp10 = ifn_3215.Invoke_O__O(arg_3216) } else { tmp10 = linked_3214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3213, arg_3216) }; if jrt.J2g_Truth(tmp10) { var root_3217 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3219 lang.IFn; if linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any = map__1685000368__6; if linked_3218 == nil { map__1685000368__7 = ifn_3219.Invoke_O__O(arg_3220) } else { map__1685000368__7 = linked_3218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3217, arg_3220) } } else { map__1685000368__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000368__7 = map__1685000368__6 }
//line :498:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000368__7, A_arbace_go_check_A_const_284); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000368__7, A_arbace_go_check_A_const_285); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_284, dir__8)); var root_3221 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3223 lang.IFn










				if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = jobs__1; var arg_3225 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000370_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__3269 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class
				if fncls__3269 == nil { var fncls__3269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class = fncls__3269d; tmp12 = fncls__3269d } else { tmp12 = fncls__3269 }; arg_3225 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :509:1
				var arg_3226 any; var root_3270 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3270, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3272 lang.IFn








				if linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any = root__10; var arg_3274 any = sub__9; if linked_3271 == nil { arg_3226 = ifn_3272.Invoke_O_O__O(arg_3273, arg_3274) } else { arg_3226 = linked_3271.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3270, arg_3273, arg_3274) }
//line :509:1
				if linked_3222 == nil { return ifn_3223.Invoke_O_O_O__O(arg_3224, arg_3225, arg_3226) } else { return linked_3222.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3221, arg_3224, arg_3225, arg_3226) } } else {
//line :498:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_283.Invoke_O__O(cc__3)) { var map__1685000372__6 any = A_arbace_go_check_A_const_283.Invoke_O__O(cc__3); var map__1685000372__7 any





















						if lang.ISeq_InstanceOf(map__1685000372__6) { var tmp13 any; var root_3275 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3275, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3277 lang.IFn; if linked_3276 == nil { ifn_3277 = lang.IFn_Cast(root_3275) } else { ifn_3277 = nil }; var arg_3278 any = map__1685000372__6; if linked_3276 == nil { tmp13 = ifn_3277.Invoke_O__O(arg_3278) } else { tmp13 = linked_3276.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3275, arg_3278) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_3279 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3279, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3281 lang.IFn; if linked_3280 == nil { ifn_3281 = lang.IFn_Cast(root_3279) } else { ifn_3281 = nil }; var arg_3282 any = map__1685000372__6; if linked_3280 == nil { tmp14 = ifn_3281.Invoke_O__O(arg_3282) } else { tmp14 = linked_3280.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3279, arg_3282) }; map__1685000372__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp14, jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 any; var root_3283 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3285 lang.IFn; if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any = map__1685000372__6; if linked_3284 == nil { tmp15 = ifn_3285.Invoke_O__O(arg_3286) } else { tmp15 = linked_3284.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3283, arg_3286) }; if jrt.J2g_Truth(tmp15) { var root_3287 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3289 lang.IFn; if linked_3288 == nil { ifn_3289 = lang.IFn_Cast(root_3287) } else { ifn_3289 = nil }; var arg_3290 any = map__1685000372__6; if linked_3288 == nil { map__1685000372__7 = ifn_3289.Invoke_O__O(arg_3290) } else { map__1685000372__7 = linked_3288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3287, arg_3290) } } else { map__1685000372__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000372__7 = map__1685000372__6 }
//line :498:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_284); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_285); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_284, dir__8_2)); var pfs__11 any; var root_3291 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3291, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3293 lang.IFn























						if linked_3292 == nil { ifn_3293 = lang.IFn_Cast(root_3291) } else { ifn_3293 = nil }; var arg_3294 any = root__10_2; var arg_3295 any = sub__9_2; if linked_3292 == nil { pfs__11 = ifn_3293.Invoke_O_O__O(arg_3294, arg_3295) } else { pfs__11 = linked_3292.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3291, arg_3294, arg_3295) }
//line :498:1
						var tests__12 any; var root_3296 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3296, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3298 lang.IFn

























						if linked_3297 == nil { ifn_3298 = lang.IFn_Cast(root_3296) } else { ifn_3298 = nil }; var arg_3299 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000374_A_New(); var tmp17 *jrt.Class; var fncls__3306 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class; if fncls__3306 == nil { var fncls__3306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class = fncls__3306d; tmp17 = fncls__3306d } else { tmp17 = fncls__3306 }; arg_3299 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3300 any = pfs__11; if linked_3297 == nil { tests__12 = ifn_3298.Invoke_O_O__O(arg_3299, arg_3300) } else { tests__12 = linked_3297.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3296, arg_3299, arg_3300)
						}


						var root_3307 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3307, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3309 lang.IFn; if linked_3308 == nil { ifn_3309 = lang.IFn_Cast(root_3307) } else { ifn_3309 = nil }; var arg_3310 any; var root_3311 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3311, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3313 lang.IFn; if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var arg_3315 any; var root_3316 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3318 lang.IFn
						if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any = jobs__1; var arg_3320 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000380_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__3549 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_A_fn_class
						if fncls__3549 == nil { var fncls__3549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000380_A_fn_class = fncls__3549d; tmp19 = fncls__3549d } else { tmp19 = fncls__3549 }; arg_3320 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :529:1
						var arg_3321 any; var root_3550 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3552 lang.IFn














						if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var arg_3554 any = tests__12; if linked_3551 == nil { arg_3321 = ifn_3552.Invoke_O_O__O(arg_3553, arg_3554) } else { arg_3321 = linked_3551.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3550, arg_3553, arg_3554) }
//line :529:1
						if linked_3317 == nil { arg_3315 = ifn_3318.Invoke_O_O_O__O(arg_3319, arg_3320, arg_3321) } else { arg_3315 = linked_3317.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3316, arg_3319, arg_3320, arg_3321) }
//line :528:1
						if linked_3312 == nil { arg_3310 = ifn_3313.Invoke_O_O__O(arg_3314, arg_3315) } else { arg_3310 = linked_3312.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3311, arg_3314, arg_3315) }; if linked_3308 == nil { return ifn_3309.Invoke_O__O(arg_3310) } else { return linked_3308.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3307, arg_3310) } } else {
//line :498:1
							return nil } } } }
//line :496:1
func A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A_New() *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A) Ctor() {}
//line :496:1
func (t *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A) Invoke_O_O__O(self, s__1685000357__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A_New_O_O(s__1685000357__1, self); var tmp2 *jrt.Class; var fncls__3175 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A_fn_class; if fncls__3175 == nil { var fncls__3175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A_fn_class = fncls__3175d; tmp2 = fncls__3175d } else { tmp2 = fncls__3175 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :496:1
func A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A{}; t.Ctor_O_O(p0, p1); return t }
//line :496:1
func (t *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A) Ctor_O_O(c__s__1685000357, c__iter__1685000356 any) { t.F_s__1685000357 = c__s__1685000357; t.F_iter__1685000356 = c__iter__1685000356 }
//line :496:1
func (t *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A) Invoke_O__O(self any) any { { var s__1685000357__1 any; var t_ any = t.F_s__1685000357; t.F_s__1685000357 = nil; s__1685000357__1 = t_; for { var temp__1927000414__auto____2 any; var root_3110 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3112 lang.IFn; if linked_3111 == nil { ifn_3112 = lang.IFn_Cast(root_3110) } else { ifn_3112 = nil }; var arg_3113 any = s__1685000357__1; if linked_3111 == nil { temp__1927000414__auto____2 = ifn_3112.Invoke_O__O(arg_3113) } else { temp__1927000414__auto____2 = linked_3111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3110, arg_3113) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000357__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3114 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3116 lang.IFn; if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any = s__1685000357__3; if linked_3115 == nil { tmp1 = ifn_3116.Invoke_O__O(arg_3117) } else { tmp1 = linked_3115.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3114, arg_3117) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3118 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3118, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3120 lang.IFn; if linked_3119 == nil { ifn_3120 = lang.IFn_Cast(root_3118) } else { ifn_3120 = nil }; var arg_3121 any = s__1685000357__3; if linked_3119 == nil { c__1927001037__auto____4 = ifn_3120.Invoke_O__O(arg_3121) } else { c__1927001037__auto____4 = linked_3119.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3118, arg_3121) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000359__6 any; var root_3122 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3122, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3124 lang.IFn; if linked_3123 == nil { ifn_3124 = lang.IFn_Cast(root_3122) } else { ifn_3124 = nil }; var arg_3125 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3123 == nil { b__1685000359__6 = ifn_3124.Invoke_O__O(arg_3125) } else { b__1685000359__6 = linked_3123.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3122, arg_3125) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A_New_O_I_O(b__1685000359__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3135 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A_fn_class; if fncls__3135 == nil { var fncls__3135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A_fn_class = fncls__3135d; tmp3 = fncls__3135d } else { tmp3 = fncls__3135 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3136 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3138 lang.IFn; if linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any; var root_3141 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3141, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3143 lang.IFn; if linked_3142 == nil { ifn_3143 = lang.IFn_Cast(root_3141) } else { ifn_3143 = nil }; var arg_3144 any = b__1685000359__6; if linked_3142 == nil { arg_3139 = ifn_3143.Invoke_O__O(arg_3144) } else { arg_3139 = linked_3142.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3141, arg_3144) }; var arg_3140 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000356); var tmp5 any; var root_3145 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3145, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3147 lang.IFn; if linked_3146 == nil { ifn_3147 = lang.IFn_Cast(root_3145) } else { ifn_3147 = nil }; var arg_3148 any = s__1685000357__3; if linked_3146 == nil { tmp5 = ifn_3147.Invoke_O__O(arg_3148) } else { tmp5 = linked_3146.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3145, arg_3148) }; arg_3140 = tmp4.Invoke_O__O(tmp5); if linked_3137 == nil { return ifn_3138.Invoke_O_O__O(arg_3139, arg_3140) } else { return linked_3137.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3136, arg_3139, arg_3140) } } else { var root_3149 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3149, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3151 lang.IFn; if linked_3150 == nil { ifn_3151 = lang.IFn_Cast(root_3149) } else { ifn_3151 = nil }; var arg_3152 any; var root_3154 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3154, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3156 lang.IFn; if linked_3155 == nil { ifn_3156 = lang.IFn_Cast(root_3154) } else { ifn_3156 = nil }; var arg_3157 any = b__1685000359__6; if linked_3155 == nil { arg_3152 = ifn_3156.Invoke_O__O(arg_3157) } else { arg_3152 = linked_3155.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3154, arg_3157) }; var arg_3153 any; if linked_3150 == nil { return ifn_3151.Invoke_O_O__O(arg_3152, arg_3153) } else { return linked_3150.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3149, arg_3152, arg_3153) } } } else { var pf__4 any; var root_3158 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3158, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3160 lang.IFn; if linked_3159 == nil { ifn_3160 = lang.IFn_Cast(root_3158) } else { ifn_3160 = nil }; var arg_3161 any = s__1685000357__3; if linked_3159 == nil { pf__4 = ifn_3160.Invoke_O__O(arg_3161) } else { pf__4 = linked_3159.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3158, arg_3161) }; var root_3162 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3162, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3164 lang.IFn; if linked_3163 == nil { ifn_3164 = lang.IFn_Cast(root_3162) } else { ifn_3164 = nil }; var arg_3165 any; var root_3167 any = A_arbace_go_check_A_const_313.GetRawRoot__O(); var linked_3168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3167, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3169 lang.IFn
															if linked_3168 == nil { ifn_3169 = lang.IFn_Cast(root_3167) } else { ifn_3169 = nil }; var arg_3170 any = pf__4; if linked_3168 == nil { arg_3165 = ifn_3169.Invoke_O__O(arg_3170) } else { arg_3165 = linked_3168.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3167, arg_3170) }
//line :496:1
	var arg_3166 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000356); var tmp7 any; var root_3171 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3171, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3173 lang.IFn; if linked_3172 == nil { ifn_3173 = lang.IFn_Cast(root_3171) } else { ifn_3173 = nil }; var arg_3174 any = s__1685000357__3; if linked_3172 == nil { tmp7 = ifn_3173.Invoke_O__O(arg_3174) } else { tmp7 = linked_3172.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3171, arg_3174) }; arg_3166 = tmp6.Invoke_O__O(tmp7); if linked_3163 == nil { return ifn_3164.Invoke_O_O__O(arg_3165, arg_3166) } else { return linked_3163.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3162, arg_3165, arg_3166) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :496:1
func A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :496:1
func (t *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A) Ctor_O_I_O(c__b__1685000359 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000359 = c__b__1685000359; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :496:1
func (t *A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A) Invoke_O__O(self any) any { { var i__1685000358__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000358__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000358__1)); var root_3126 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3126, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3128 lang.IFn; if linked_3127 == nil { ifn_3128 = lang.IFn_Cast(root_3126) } else { ifn_3128 = nil }; var arg_3129 any = t.F_b__1685000359; var arg_3130 any; var root_3131 any = A_arbace_go_check_A_const_313.GetRawRoot__O(); var linked_3132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3131, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3133 lang.IFn
																if linked_3132 == nil { ifn_3133 = lang.IFn_Cast(root_3131) } else { ifn_3133 = nil }; var arg_3134 any = pf__2; if linked_3132 == nil { arg_3130 = ifn_3133.Invoke_O__O(arg_3134) } else { arg_3130 = linked_3132.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3131, arg_3134) }
//line :496:1
	if linked_3127 == nil { ifn_3128.Invoke_O_O__O(arg_3129, arg_3130) } else { linked_3127.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3126, arg_3129, arg_3130) }; i__1685000358__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000358__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000366_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000366_A{}; t.Ctor_O(p0); return t }
//line :501:1
func (t *A_arbace_go_check_check_corpus_fn__1685000366_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :501:1
func (t *A_arbace_go_check_check_corpus_fn__1685000366_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_3188 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3188, A_arbace_go_check_result_of_A_fn_class); var ifn_3190 lang.IFn
												if linked_3189 == nil { ifn_3190 = lang.IFn_Cast(root_3188) } else { ifn_3190 = nil }; var arg_3191 any; var root_3192 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_3193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3192, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3194 lang.IFn; if linked_3193 == nil { ifn_3194 = lang.IFn_Cast(root_3192) } else { ifn_3194 = nil }; var arg_3195 any = t.F_s; var arg_3196 any = path__1; var arg_3197 any; var arg_3198 any = lang.PersistentVector_EMPTY.Ref(); if linked_3193 == nil { arg_3191 = ifn_3194.Invoke_O_O_O_O__O(arg_3195, arg_3196, arg_3197, arg_3198) } else { arg_3191 = linked_3193.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3192, arg_3195, arg_3196, arg_3197, arg_3198) }; if linked_3189 == nil { or__1927000174__auto____4 = ifn_3190.Invoke_O__O(arg_3191) } else { or__1927000174__auto____4 = linked_3189.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3188, arg_3191) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110, path__1, A_arbace_go_check_A_const_317, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :501:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_3199 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3199, A_arbace_go_check_error_result_A_fn_class); var ifn_3201 lang.IFn


		if linked_3200 == nil { ifn_3201 = lang.IFn_Cast(root_3199) } else { ifn_3201 = nil }; var arg_3202 any = path__1; var arg_3203 any = ex__4; if linked_3200 == nil { tmp1 = ifn_3201.Invoke_O_O__O(arg_3202, arg_3203) } else { tmp1 = linked_3200.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3199, arg_3202, arg_3203) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000370_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000370_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :510:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :510:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_3227 any = A_arbace_go_check_A_const_301.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3227, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3229 lang.IFn

	if linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any = t.F_root; var arg_3231 any; var arg_3232 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_cc); var arg_3233 any = pf__1; if linked_3228 == nil { src__4 = ifn_3229.Invoke_O_O_O_O__O(arg_3230, arg_3231, arg_3232, arg_3233) } else { src__4 = linked_3228.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3227, arg_3230, arg_3231, arg_3232, arg_3233) }
	var tmp2 any; var root_3234 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3236 lang.IFn; if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = A_arbace_go_check_A_const_124.Invoke_O__O(src__4); if linked_3235 == nil { tmp2 = ifn_3236.Invoke_O__O(arg_3237) } else { tmp2 = linked_3235.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3234, arg_3237) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_110; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_317, jrt.Boolean_TRUE.Ref())) } else {

		var root_3238 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3238, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3240 lang.IFn; if linked_3239 == nil { ifn_3240 = lang.IFn_Cast(root_3238) } else { ifn_3240 = nil }; var arg_3241 any; var root_3244 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3244, A_arbace_go_check_result_of_A_fn_class); var ifn_3246 lang.IFn; if linked_3245 == nil { ifn_3246 = lang.IFn_Cast(root_3244) } else { ifn_3246 = nil }; var arg_3247 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_273.GetRawRoot__O()); var tmp5 any; var root_3253 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_3254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3253, A_arbace_go_check_resolver_A_fn_class); var ifn_3255 lang.IFn; if linked_3254 == nil { ifn_3255 = lang.IFn_Cast(root_3253) } else { ifn_3255 = nil }; var arg_3256 any = t.F_s; var arg_3257 any = src__4; var arg_3258 any = lang.PersistentVector_EMPTY.Ref(); if linked_3254 == nil { tmp5 = ifn_3255.Invoke_O_O_O__O(arg_3256, arg_3257, arg_3258) } else { tmp5 = linked_3254.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3253, arg_3256, arg_3257, arg_3258) }; arg_3247 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_3245 == nil { arg_3241 = ifn_3246.Invoke_O__O(arg_3247) } else { arg_3241 = linked_3245.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3244, arg_3247) }; var arg_3242 any = A_arbace_go_check_A_const_110; var arg_3243 any; var root_3259 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3261 lang.IFn
		if linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; var arg_3262 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3263 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_3260 == nil { arg_3243 = ifn_3261.Invoke_O_O__O(arg_3262, arg_3263) } else { arg_3243 = linked_3260.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3259, arg_3262, arg_3263) }
//line :515:1
		if linked_3239 == nil { tmp1 = ifn_3240.Invoke_O_O_O__O(arg_3241, arg_3242, arg_3243) } else { tmp1 = linked_3239.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3238, arg_3241, arg_3242, arg_3243) } } }; return nil }(); if /*line :510:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_3264 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3264, A_arbace_go_check_error_result_A_fn_class); var ifn_3266 lang.IFn






			if linked_3265 == nil { ifn_3266 = lang.IFn_Cast(root_3264) } else { ifn_3266 = nil }; var arg_3267 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3268 any = ex__4; if linked_3265 == nil { tmp1 = ifn_3266.Invoke_O_O__O(arg_3267, arg_3268) } else { tmp1 = linked_3265.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3264, arg_3267, arg_3268) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000374_A_New() *A_arbace_go_check_check_corpus_fn__1685000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000374_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Ctor() {}
//line :524:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_3301 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3301, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3303 lang.IFn; if

	linked_3302 == nil { ifn_3303 = lang.IFn_Cast(root_3301) } else { ifn_3303 = nil }; var arg_3304 any = A_arbace_go_check_A_const_322; var arg_3305 any = p__2; if linked_3302 == nil { temp__1927000408__auto____3 = ifn_3303.Invoke_O_O__O(arg_3304, arg_3305) } else { temp__1927000408__auto____3 = linked_3302.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3301, arg_3304, arg_3305) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000375__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000375__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000375__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000380_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000380_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :530:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :530:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_A) Invoke_O_O__O(self, p__1685000379__1 any) any { var vec__1685000381__2 any = p__1685000379__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000381__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000381__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_3322 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3322, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3324 lang.IFn

	if linked_3323 == nil { ifn_3324 = lang.IFn_Cast(root_3322) } else { ifn_3324 = nil }; var arg_3325 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3326 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A_New(); var tmp3 *jrt.Class; var fncls__3393 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A_fn_class; if fncls__3393 == nil { var fncls__3393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A_fn_class = fncls__3393d; tmp3 = fncls__3393d } else { tmp3 = fncls__3393 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_3326 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_3323 == nil { by_path__7 = ifn_3324.Invoke_O_O__O(arg_3325, arg_3326) } else { by_path__7 = linked_3323.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3322, arg_3325, arg_3326) }
//line :530:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp5 any; var root_3402 any = A_arbace_go_check_A_const_300.GetRawRoot__O(); var linked_3403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3402, A_arbace_go_check_session_A_fn_class); var ifn_3404 lang.IFn



	if linked_3403 == nil { ifn_3404 = lang.IFn_Cast(root_3402) } else { ifn_3404 = nil }; var arg_3405 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__3413 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A_fn_class; if fncls__3413 == nil { var fncls__3413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A_fn_class = fncls__3413d; tmp7 = fncls__3413d } else { tmp7 = fncls__3413 }; arg_3405 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3403 == nil { tmp5 = ifn_3404.Invoke_O__O(arg_3405) } else { tmp5 = linked_3403.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3402, arg_3405) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_262; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_271; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__3419 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A_fn_class; if fncls__3419 == nil { var fncls__3419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A_fn_class = fncls__3419d; tmp13 = fncls__3419d } else { tmp13 = fncls__3419 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_3420 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3420, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3422 lang.IFn; if linked_3421 == nil { ifn_3422 = lang.IFn_Cast(root_3420) } else { ifn_3422 = nil }; var arg_3423 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__3538 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A_fn_class; if fncls__3538 == nil { var fncls__3538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A_fn_class = fncls__3538d; tmp15 = fncls__3538d } else { tmp15 = fncls__3538 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_3539 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3539, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3541 lang.IFn; if linked_3540 == nil { ifn_3541 = lang.IFn_Cast(root_3539) } else { ifn_3541 = nil }; var arg_3542 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var arg_3543 any = by_path__7; if linked_3540 == nil { tmp17 = ifn_3541.Invoke_O_O__O(arg_3542, arg_3543) } else { tmp17 = linked_3540.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3539, arg_3542, arg_3543) }; arg_3423 = tmp16.Invoke_O__O(tmp17); if linked_3421 == nil { tmp1 = ifn_3422.Invoke_O__O(arg_3423) } else { tmp1 = linked_3421.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3420, arg_3423) } }; return nil }(); if /*line :530:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_3544 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3544, A_arbace_go_check_error_result_A_fn_class); var ifn_3546 lang.IFn












		if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = tdir__3; var arg_3548 any = ex__7; if linked_3545 == nil { tmp19 = ifn_3546.Invoke_O_O__O(arg_3547, arg_3548) } else { tmp19 = linked_3545.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3544, arg_3547, arg_3548) }
//line :530:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A_New() *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A) Ctor() {}
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A) Invoke_O_O__O(self, s__1685000385__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A_New_O_O(s__1685000385__1, self); var tmp2 *jrt.Class; var fncls__3392 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A_fn_class; if fncls__3392 == nil { var fncls__3392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A_fn_class = fncls__3392d; tmp2 = fncls__3392d } else { tmp2 = fncls__3392 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :532:1
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A{}; t.Ctor_O_O(p0, p1); return t }
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A) Ctor_O_O(c__s__1685000385, c__iter__1685000384 any) { t.F_s__1685000385 = c__s__1685000385; t.F_iter__1685000384 = c__iter__1685000384 }
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A) Invoke_O__O(self any) any { { var s__1685000385__1 any; var t_ any = t.F_s__1685000385; t.F_s__1685000385 = nil; s__1685000385__1 = t_; for { var temp__1927000414__auto____2 any; var root_3327 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3327, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3329 lang.IFn; if linked_3328 == nil { ifn_3329 = lang.IFn_Cast(root_3327) } else { ifn_3329 = nil }; var arg_3330 any = s__1685000385__1; if linked_3328 == nil { temp__1927000414__auto____2 = ifn_3329.Invoke_O__O(arg_3330) } else { temp__1927000414__auto____2 = linked_3328.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3327, arg_3330) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000385__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3331 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3331, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3333 lang.IFn; if linked_3332 == nil { ifn_3333 = lang.IFn_Cast(root_3331) } else { ifn_3333 = nil }; var arg_3334 any = s__1685000385__3; if linked_3332 == nil { tmp1 = ifn_3333.Invoke_O__O(arg_3334) } else { tmp1 = linked_3332.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3331, arg_3334) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3335 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3335, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3337 lang.IFn; if linked_3336 == nil { ifn_3337 = lang.IFn_Cast(root_3335) } else { ifn_3337 = nil }; var arg_3338 any = s__1685000385__3; if linked_3336 == nil { c__1927001037__auto____4 = ifn_3337.Invoke_O__O(arg_3338) } else { c__1927001037__auto____4 = linked_3336.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3335, arg_3338) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000387__6 any; var root_3339 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3339, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3341 lang.IFn; if linked_3340 == nil { ifn_3341 = lang.IFn_Cast(root_3339) } else { ifn_3341 = nil }; var arg_3342 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3340 == nil { b__1685000387__6 = ifn_3341.Invoke_O__O(arg_3342) } else { b__1685000387__6 = linked_3340.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3339, arg_3342) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A_New_O_I_O(b__1685000387__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3352 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A_fn_class; if fncls__3352 == nil { var fncls__3352d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A_fn_class = fncls__3352d; tmp3 = fncls__3352d } else { tmp3 = fncls__3352 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3353 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any; var root_3358 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3360 lang.IFn; if linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = b__1685000387__6; if linked_3359 == nil { arg_3356 = ifn_3360.Invoke_O__O(arg_3361) } else { arg_3356 = linked_3359.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3358, arg_3361) }; var arg_3357 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000384); var tmp5 any; var root_3362 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3362, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3364 lang.IFn; if linked_3363 == nil { ifn_3364 = lang.IFn_Cast(root_3362) } else { ifn_3364 = nil }; var arg_3365 any = s__1685000385__3; if linked_3363 == nil { tmp5 = ifn_3364.Invoke_O__O(arg_3365) } else { tmp5 = linked_3363.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3362, arg_3365) }; arg_3357 = tmp4.Invoke_O__O(tmp5); if linked_3354 == nil { return ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { return linked_3354.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) } } else { var root_3366 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3366, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3368 lang.IFn; if linked_3367 == nil { ifn_3368 = lang.IFn_Cast(root_3366) } else { ifn_3368 = nil }; var arg_3369 any; var root_3371 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3373 lang.IFn; if linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = b__1685000387__6; if linked_3372 == nil { arg_3369 = ifn_3373.Invoke_O__O(arg_3374) } else { arg_3369 = linked_3372.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3371, arg_3374) }; var arg_3370 any; if linked_3367 == nil { return ifn_3368.Invoke_O_O__O(arg_3369, arg_3370) } else { return linked_3367.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3366, arg_3369, arg_3370) } } } else { var pf__4 any; var root_3375 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3375, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3377 lang.IFn; if linked_3376 == nil { ifn_3377 = lang.IFn_Cast(root_3375) } else { ifn_3377 = nil }; var arg_3378 any = s__1685000385__3; if linked_3376 == nil { pf__4 = ifn_3377.Invoke_O__O(arg_3378) } else { pf__4 = linked_3376.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3375, arg_3378) }; var root_3379 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3379, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3381 lang.IFn; if linked_3380 == nil { ifn_3381 = lang.IFn_Cast(root_3379) } else { ifn_3381 = nil }; var arg_3382 any; var tmp6 any; var root_3384 any = A_arbace_go_check_A_const_313.GetRawRoot__O(); var linked_3385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3384, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3386 lang.IFn; if linked_3385 == nil { ifn_3386 = lang.IFn_Cast(root_3384) } else { ifn_3386 = nil }; var arg_3387 any = pf__4; if linked_3385 == nil { tmp6 = ifn_3386.Invoke_O__O(arg_3387) } else { tmp6 = linked_3385.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3384, arg_3387) }; arg_3382 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_3383 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000384); var tmp8 any; var root_3388 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3388, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3390 lang.IFn; if linked_3389 == nil { ifn_3390 = lang.IFn_Cast(root_3388) } else { ifn_3390 = nil }; var arg_3391 any = s__1685000385__3; if linked_3389 == nil { tmp8 = ifn_3390.Invoke_O__O(arg_3391) } else { tmp8 = linked_3389.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3388, arg_3391) }; arg_3383 = tmp7.Invoke_O__O(tmp8); if linked_3380 == nil { return ifn_3381.Invoke_O_O__O(arg_3382, arg_3383) } else { return linked_3380.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3379, arg_3382, arg_3383) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :532:1
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A) Ctor_O_I_O(c__b__1685000387 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000387 = c__b__1685000387; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A) Invoke_O__O(self any) any { { var i__1685000386__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000386__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000386__1)); var root_3343 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3345 lang.IFn; if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = t.F_b__1685000387; var arg_3347 any; var tmp2 any; var root_3348 any = A_arbace_go_check_A_const_313.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3348, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3350 lang.IFn; if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any = pf__2; if linked_3349 == nil { tmp2 = ifn_3350.Invoke_O__O(arg_3351) } else { tmp2 = linked_3349.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3348, arg_3351) }; arg_3347 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_3344 == nil { ifn_3345.Invoke_O_O__O(arg_3346, arg_3347) } else { linked_3344.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3343, arg_3346, arg_3347) }; i__1685000386__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000386__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_3406 any = A_arbace_go_check_A_const_301.GetRawRoot__O(); var linked_3407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3406, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3408 lang.IFn
																	if linked_3407 == nil { ifn_3408 = lang.IFn_Cast(root_3406) } else { ifn_3408 = nil }; var arg_3409 any = t.F_root; var arg_3410 any = path__1; var arg_3411 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_cc); var arg_3412 any = pf__4; if linked_3407 == nil { return ifn_3408.Invoke_O_O_O_O__O(arg_3409, arg_3410, arg_3411, arg_3412) } else { return linked_3407.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3406, arg_3409, arg_3410, arg_3411, arg_3412) } } else {
//line :535:1
			return nil } }
//line :534:1
func A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A{}; t.Ctor_O(p0); return t }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A) Invoke_O_O__O(self, p1__1685000355_SHARP___1 any) any {


	var root_3414 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3416 lang.IFn; if linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any = t.F_by_path; var arg_3418 any = p1__1685000355_SHARP___1; if linked_3415 == nil { return ifn_3416.Invoke_O_O__O(arg_3417, arg_3418) } else { return linked_3415.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3414, arg_3417, arg_3418) } }
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A) Invoke_O_O__O(self, s__1685000399__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A_New_O_O_O_O_O(t.F_dir, t.F_tdir, s__1685000399__1, t.F_ts, self); var tmp2 *jrt.Class; var fncls__3537 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A_fn_class; if fncls__3537 == nil { var fncls__3537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A_fn_class = fncls__3537d; tmp2 = fncls__3537d } else { tmp2 = fncls__3537 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :538:1
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A) Ctor_O_O_O_O_O(c__dir, c__tdir, c__s__1685000399, c__ts, c__iter__1685000398 any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_s__1685000399 = c__s__1685000399; t.F_ts = c__ts; t.F_iter__1685000398 = c__iter__1685000398 }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A) Invoke_O__O(self any) any { { var s__1685000399__1 any; var t_ any = t.F_s__1685000399; t.F_s__1685000399 = nil; s__1685000399__1 = t_; for { var temp__1927000414__auto____2 any; var root_3424 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3424, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3426 lang.IFn; if linked_3425 == nil { ifn_3426 = lang.IFn_Cast(root_3424) } else { ifn_3426 = nil }; var arg_3427 any = s__1685000399__1; if linked_3425 == nil { temp__1927000414__auto____2 = ifn_3426.Invoke_O__O(arg_3427) } else { temp__1927000414__auto____2 = linked_3425.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3424, arg_3427) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000399__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3428 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3428, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3430 lang.IFn; if linked_3429 == nil { ifn_3430 = lang.IFn_Cast(root_3428) } else { ifn_3430 = nil }; var arg_3431 any = s__1685000399__3; if linked_3429 == nil { tmp1 = ifn_3430.Invoke_O__O(arg_3431) } else { tmp1 = linked_3429.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3428, arg_3431) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3432 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3432, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3434 lang.IFn; if linked_3433 == nil { ifn_3434 = lang.IFn_Cast(root_3432) } else { ifn_3434 = nil }; var arg_3435 any = s__1685000399__3; if linked_3433 == nil { c__1927001037__auto____4 = ifn_3434.Invoke_O__O(arg_3435) } else { c__1927001037__auto____4 = linked_3433.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3432, arg_3435) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000401__6 any; var root_3436 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3438 lang.IFn; if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3437 == nil { b__1685000401__6 = ifn_3438.Invoke_O__O(arg_3439) } else { b__1685000401__6 = linked_3437.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3436, arg_3439) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A_New_O_O_O_O_I_O(b__1685000401__6, t.F_dir, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3473 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A_fn_class; if fncls__3473 == nil { var fncls__3473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A_fn_class = fncls__3473d; tmp3 = fncls__3473d } else { tmp3 = fncls__3473 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3474 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any; var root_3479 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3479, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3481 lang.IFn; if linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any = b__1685000401__6; if linked_3480 == nil { arg_3477 = ifn_3481.Invoke_O__O(arg_3482) } else { arg_3477 = linked_3480.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3479, arg_3482) }; var arg_3478 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000398); var tmp5 any; var root_3483 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3483, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3485 lang.IFn; if linked_3484 == nil { ifn_3485 = lang.IFn_Cast(root_3483) } else { ifn_3485 = nil }; var arg_3486 any = s__1685000399__3; if linked_3484 == nil { tmp5 = ifn_3485.Invoke_O__O(arg_3486) } else { tmp5 = linked_3484.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3483, arg_3486) }; arg_3478 = tmp4.Invoke_O__O(tmp5); if linked_3475 == nil { return ifn_3476.Invoke_O_O__O(arg_3477, arg_3478) } else { return linked_3475.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3474, arg_3477, arg_3478) } } else { var root_3487 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3487, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3489 lang.IFn; if linked_3488 == nil { ifn_3489 = lang.IFn_Cast(root_3487) } else { ifn_3489 = nil }; var arg_3490 any; var root_3492 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3492, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3494 lang.IFn; if linked_3493 == nil { ifn_3494 = lang.IFn_Cast(root_3492) } else { ifn_3494 = nil }; var arg_3495 any = b__1685000401__6; if linked_3493 == nil { arg_3490 = ifn_3494.Invoke_O__O(arg_3495) } else { arg_3490 = linked_3493.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3492, arg_3495) }; var arg_3491 any; if linked_3488 == nil { return ifn_3489.Invoke_O_O__O(arg_3490, arg_3491) } else { return linked_3488.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3487, arg_3490, arg_3491) } } } else { var vec__1685000411__4 any; var root_3496 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3498 lang.IFn; if linked_3497 == nil { ifn_3498 = lang.IFn_Cast(root_3496) } else { ifn_3498 = nil }; var arg_3499 any = s__1685000399__3; if linked_3497 == nil { vec__1685000411__4 = ifn_3498.Invoke_O__O(arg_3499) } else { vec__1685000411__4 = linked_3497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3496, arg_3499) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000411__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000411__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3500 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3500, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3502 lang.IFn; _ = pf__6; if linked_3501 == nil { ifn_3502 = lang.IFn_Cast(root_3500) } else { ifn_3502 = nil }; var arg_3503 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3532 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A_fn_class
																if fncls__3532 == nil { var fncls__3532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A_fn_class = fncls__3532d; tmp7 = fncls__3532d } else { tmp7 = fncls__3532 }; arg_3503 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :538:1
	var arg_3504 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000398); var tmp9 any; var root_3533 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3533, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3535 lang.IFn; if linked_3534 == nil { ifn_3535 = lang.IFn_Cast(root_3533) } else { ifn_3535 = nil }; var arg_3536 any = s__1685000399__3; if linked_3534 == nil { tmp9 = ifn_3535.Invoke_O__O(arg_3536) } else { tmp9 = linked_3534.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3533, arg_3536) }; arg_3504 = tmp8.Invoke_O__O(tmp9); if linked_3501 == nil { return ifn_3502.Invoke_O_O__O(arg_3503, arg_3504) } else { return linked_3501.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3500, arg_3503, arg_3504) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :538:1
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A) Ctor_O_O_O_O_I_O(c__b__1685000401, c__dir, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000401 = c__b__1685000401; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A) Invoke_O__O(self any) any { { var i__1685000400__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000400__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000405__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000400__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000405__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000405__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3440 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3442 lang.IFn; _ = pf__4; if linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any = t.F_b__1685000401; var arg_3444 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3472 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A_fn_class
																		if fncls__3472 == nil { var fncls__3472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A_fn_class = fncls__3472d; tmp3 = fncls__3472d } else { tmp3 = fncls__3472 }; arg_3444 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :538:1
	if linked_3441 == nil { ifn_3442.Invoke_O_O__O(arg_3443, arg_3444) } else { linked_3441.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3440, arg_3443, arg_3444) }; i__1685000400__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000400__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :539:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :539:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_3445 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3445, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3447 lang.IFn; if linked_3446 == nil { ifn_3447 = lang.IFn_Cast(root_3445) } else { ifn_3447 = nil }; var arg_3448 any; var or__1927000174__auto____3 any; var root_3451 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, A_arbace_go_check_result_of_A_fn_class); var ifn_3453 lang.IFn; if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any; var root_3455 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3458 = t_; var arg_3459 any = t.F_path; var arg_3460 any; var arg_3461 any = lang.PersistentVector_EMPTY.Ref(); if linked_3456 == nil { arg_3454 = ifn_3457.Invoke_O_O_O_O__O(arg_3458, arg_3459, arg_3460, arg_3461) } else { arg_3454 = linked_3456.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3455, arg_3458, arg_3459, arg_3460, arg_3461) }; if linked_3452 == nil { or__1927000174__auto____3 = ifn_3453.Invoke_O__O(arg_3454) } else { or__1927000174__auto____3 = linked_3452.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3451, arg_3454) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3448 = or__1927000174__auto____3 } else { arg_3448 = A_arbace_go_check_A_const_324 }; var arg_3449 any = A_arbace_go_check_A_const_110; var arg_3450 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3462 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3462, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3464 lang.IFn
																					if linked_3463 == nil { ifn_3464 = lang.IFn_Cast(root_3462) } else { ifn_3464 = nil }; var arg_3465 any = t.F_tdir; var arg_3466 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3466 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3463 == nil { tmp3 = ifn_3464.Invoke_O_O__O(arg_3465, arg_3466) } else { tmp3 = linked_3463.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3462, arg_3465, arg_3466) }; arg_3450 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :540:1
		if linked_3446 == nil { tmp1 = ifn_3447.Invoke_O_O_O__O(arg_3448, arg_3449, arg_3450) } else { tmp1 = linked_3446.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3445, arg_3448, arg_3449, arg_3450) } }
//line :539:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3467 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3467, A_arbace_go_check_error_result_A_fn_class); var ifn_3469 lang.IFn


		if linked_3468 == nil { ifn_3469 = lang.IFn_Cast(root_3467) } else { ifn_3469 = nil }; var arg_3470 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3470 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3471 any = ex__3; if linked_3468 == nil { tmp1 = ifn_3469.Invoke_O_O__O(arg_3470, arg_3471) } else { tmp1 = linked_3468.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3467, arg_3470, arg_3471) } } }; return tmp1 }
//line :539:1
func A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :539:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :539:1
func (t *A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3505 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3505, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any; var or__1927000174__auto____3 any; var root_3511 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3511, A_arbace_go_check_result_of_A_fn_class); var ifn_3513 lang.IFn; if linked_3512 == nil { ifn_3513 = lang.IFn_Cast(root_3511) } else { ifn_3513 = nil }; var arg_3514 any; var root_3515 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_3516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3515, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3517 lang.IFn; if linked_3516 == nil { ifn_3517 = lang.IFn_Cast(root_3515) } else { ifn_3517 = nil }; var arg_3518 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3518 = t_; var arg_3519 any = t.F_path; var arg_3520 any; var arg_3521 any = lang.PersistentVector_EMPTY.Ref(); if linked_3516 == nil { arg_3514 = ifn_3517.Invoke_O_O_O_O__O(arg_3518, arg_3519, arg_3520, arg_3521) } else { arg_3514 = linked_3516.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3515, arg_3518, arg_3519, arg_3520, arg_3521) }; if linked_3512 == nil { or__1927000174__auto____3 = ifn_3513.Invoke_O__O(arg_3514) } else { or__1927000174__auto____3 = linked_3512.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3511, arg_3514) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3508 = or__1927000174__auto____3 } else { arg_3508 = A_arbace_go_check_A_const_325 }; var arg_3509 any = A_arbace_go_check_A_const_110; var arg_3510 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3522 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3522, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3524 lang.IFn
																			if linked_3523 == nil { ifn_3524 = lang.IFn_Cast(root_3522) } else { ifn_3524 = nil }; var arg_3525 any = t.F_tdir; var arg_3526 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3526 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3523 == nil { tmp3 = ifn_3524.Invoke_O_O__O(arg_3525, arg_3526) } else { tmp3 = linked_3523.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3522, arg_3525, arg_3526) }; arg_3510 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :540:1
		if linked_3506 == nil { tmp1 = ifn_3507.Invoke_O_O_O__O(arg_3508, arg_3509, arg_3510) } else { tmp1 = linked_3506.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3505, arg_3508, arg_3509, arg_3510) } }
//line :539:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3527 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3527, A_arbace_go_check_error_result_A_fn_class); var ifn_3529 lang.IFn


		if linked_3528 == nil { ifn_3529 = lang.IFn_Cast(root_3527) } else { ifn_3529 = nil }; var arg_3530 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3530 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3531 any = ex__3; if linked_3528 == nil { tmp1 = ifn_3529.Invoke_O_O__O(arg_3530, arg_3531) } else { tmp1 = linked_3528.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3527, arg_3530, arg_3531) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :546:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3555 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3555, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3557 lang.IFn; if


	linked_3556 == nil { ifn_3557 = lang.IFn_Cast(root_3555) } else { ifn_3557 = nil }; var arg_3558 any = A_arbace_go_check_A_const_317; var arg_3559 any = results__1; if linked_3556 == nil { rs__3 = ifn_3557.Invoke_O_O__O(arg_3558, arg_3559) } else { rs__3 = linked_3556.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3555, arg_3558, arg_3559) }; var sum__4 any; var tmp1 any = /*line :546:1*/A_arbace_go_check_summarize_sum__1685000426_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3571 *jrt.Class = A_arbace_go_check_summarize_sum__1685000426_A_fn_class; if



	fncls__3571 == nil { var fncls__3571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_check_summarize_sum__1685000426_A_fn_class = fncls__3571d; tmp2 = fncls__3571d } else { tmp2 = fncls__3571 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :546:1*/A_arbace_go_check_summarize_msum__1685000428_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__3584 *jrt.Class = A_arbace_go_check_summarize_msum__1685000428_A_fn_class; if




	fncls__3584 == nil { var fncls__3584d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_go_check_summarize_msum__1685000428_A_fn_class = fncls__3584d; tmp4 = fncls__3584d } else { tmp4 = fncls__3584 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_291; var tmp6 any = A_arbace_go_check_A_const_327; var tmp7 any = /*line :546:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_328; var tmp9 any = A_arbace_go_check_A_const_329; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_82); var tmp11 any = A_arbace_go_check_A_const_163; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_163); var tmp13 any = A_arbace_go_check_A_const_149; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_154); var tmp15 any = A_arbace_go_check_A_const_152; var tmp16 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_152); var tmp17 any = A_arbace_go_check_A_const_144; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_155))); var tmp19 any = A_arbace_go_check_A_const_234; var tmp20 lang.IFn = lang.IFn_Cast(sum__4); var tmp21 any = A_arbace_go_check_summarize_fn__1685000430_A_New(); var tmp22 *jrt.Class; var fncls__3667 *jrt.Class = A_arbace_go_check_summarize_fn__1685000430_A_fn_class; if












	fncls__3667 == nil { var fncls__3667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_check_summarize_fn__1685000430_A_fn_class = fncls__3667d; tmp22 = fncls__3667d } else { tmp22 = fncls__3667 }; var tmp23 any = /*line :546:1*/tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)); var tmp24 any = A_arbace_go_check_A_const_330; var tmp25 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_237); var tmp26 any = A_arbace_go_check_A_const_331; var tmp27 any; var root_3585 any = A_arbace_go_check_A_const_332.GetRawRoot__O(); var linked_3586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3585, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3587 lang.IFn; if














	linked_3586 == nil { ifn_3587 = lang.IFn_Cast(root_3585) } else { ifn_3587 = nil }; var arg_3588 any; var tmp28 any = A_arbace_go_check_summarize_fn__1685000432_A_New(); var tmp29 *jrt.Class; var fncls__3590 *jrt.Class = A_arbace_go_check_summarize_fn__1685000432_A_fn_class; if fncls__3590 == nil { var fncls__3590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_go_check_summarize_fn__1685000432_A_fn_class = fncls__3590d; tmp29 = fncls__3590d } else { tmp29 = fncls__3590 }; arg_3588 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_3589 any = rs__3; if linked_3586 == nil { tmp27 = ifn_3587.Invoke_O_O__O(arg_3588, arg_3589) } else { tmp27 = linked_3586.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3585, arg_3588, arg_3589) }; var tmp30 any = /*line :546:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref(); var tmp31 any = A_arbace_go_check_A_const_333; var tmp32 any; var root_3591 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3591, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3593 lang.IFn; if















	linked_3592 == nil { ifn_3593 = lang.IFn_Cast(root_3591) } else { ifn_3593 = nil }; var arg_3594 any; var root_3595 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_3596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3595, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3597 lang.IFn; if linked_3596 == nil { ifn_3597 = lang.IFn_Cast(root_3595) } else { ifn_3597 = nil }; var arg_3598 any; var tmp33 any = A_arbace_go_check_summarize_fn__1685000434_A_New(); var tmp34 *jrt.Class; var fncls__3600 *jrt.Class = A_arbace_go_check_summarize_fn__1685000434_A_fn_class; if fncls__3600 == nil { var fncls__3600d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_go_check_summarize_fn__1685000434_A_fn_class = fncls__3600d; tmp34 = fncls__3600d } else { tmp34 = fncls__3600 }; arg_3598 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3599 any = rs__3; if linked_3596 == nil { arg_3594 = ifn_3597.Invoke_O_O__O(arg_3598, arg_3599) } else { arg_3594 = linked_3596.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3595, arg_3598, arg_3599) }; if linked_3592 == nil { tmp32 = ifn_3593.Invoke_O__O(arg_3594) } else { tmp32 = linked_3592.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3591, arg_3594) }; var tmp35 any = tmp32; var tmp36 any = A_arbace_go_check_A_const_334; var tmp37 any = A_arbace_go_check_A_const_139; var tmp38 any; var root_3601 any = /*line :546:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3601, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3603 lang.IFn; if
















	linked_3602 == nil { ifn_3603 = lang.IFn_Cast(root_3601) } else { ifn_3603 = nil }; var arg_3604 any = lang.IFn_Cast(A_arbace_go_check_A_const_335.GetRawRoot__O()).Invoke__O(); var arg_3605 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_139); if linked_3602 == nil { tmp38 = ifn_3603.Invoke_O_O__O(arg_3604, arg_3605) } else { tmp38 = linked_3602.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3601, arg_3604, arg_3605) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_go_check_A_const_164; var tmp41 any; var root_3609 any = /*line :546:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3609, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3611 lang.IFn; if

















	linked_3610 == nil { ifn_3611 = lang.IFn_Cast(root_3609) } else { ifn_3611 = nil }; var arg_3612 any = lang.IFn_Cast(A_arbace_go_check_A_const_335.GetRawRoot__O()).Invoke__O(); var arg_3613 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_164); if linked_3610 == nil { tmp41 = ifn_3611.Invoke_O_O__O(arg_3612, arg_3613) } else { tmp41 = linked_3610.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3609, arg_3612, arg_3613) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_go_check_A_const_165; var tmp44 any; var root_3617 any = /*line :546:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3617, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3619 lang.IFn; if


















	linked_3618 == nil { ifn_3619 = lang.IFn_Cast(root_3617) } else { ifn_3619 = nil }; var arg_3620 any = lang.IFn_Cast(A_arbace_go_check_A_const_335.GetRawRoot__O()).Invoke__O(); var arg_3621 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_165); if linked_3618 == nil { tmp44 = ifn_3619.Invoke_O_O__O(arg_3620, arg_3621) } else { tmp44 = linked_3618.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3617, arg_3620, arg_3621) }; var tmp45 any = tmp44; var tmp46 any = A_arbace_go_check_A_const_336; var tmp47 any; var root_3625 any = /*line :546:1*/A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3627 lang.IFn; if



















	linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any = lang.IFn_Cast(A_arbace_go_check_A_const_335.GetRawRoot__O()).Invoke__O(); var arg_3629 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_156); if linked_3626 == nil { tmp47 = ifn_3627.Invoke_O_O__O(arg_3628, arg_3629) } else { tmp47 = linked_3626.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3625, arg_3628, arg_3629) }; var tmp48 any = tmp47; var tmp49 any = A_arbace_go_check_A_const_238; var tmp50 any = A_arbace_go_check_A_const_327; var tmp51 any; var root_3633 any = /*line :546:1*/A_arbace_go_check_A_const_332.GetRawRoot__O(); var linked_3634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3633, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3635 lang.IFn; if




















	linked_3634 == nil { ifn_3635 = lang.IFn_Cast(root_3633) } else { ifn_3635 = nil }; var arg_3636 any; var tmp52 any = A_arbace_go_check_summarize_fn__1685000436_A_New(); var tmp53 *jrt.Class; var fncls__3643 *jrt.Class = A_arbace_go_check_summarize_fn__1685000436_A_fn_class; if fncls__3643 == nil { var fncls__3643d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_go_check_summarize_fn__1685000436_A_fn_class = fncls__3643d; tmp53 = fncls__3643d } else { tmp53 = fncls__3643 }; arg_3636 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var arg_3637 any = rs__3; if linked_3634 == nil { tmp51 = ifn_3635.Invoke_O_O__O(arg_3636, arg_3637) } else { tmp51 = linked_3634.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3633, arg_3636, arg_3637) }; var tmp54 any = /*line :546:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp51)).Ref(); var tmp55 any = A_arbace_go_check_A_const_338; var tmp56 lang.IFn = lang.IFn_Cast(sum__4); var tmp57 any = A_arbace_go_check_summarize_fn__1685000438_A_New(); var tmp58 *jrt.Class; var fncls__3674 *jrt.Class = A_arbace_go_check_summarize_fn__1685000438_A_fn_class; if





















	fncls__3674 == nil { var fncls__3674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_go_check_summarize_fn__1685000438_A_fn_class = fncls__3674d; tmp58 = fncls__3674d } else { tmp58 = fncls__3674 }; var tmp59 any = /*line :546:1*/tmp56.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil)); var tmp60 any = A_arbace_go_check_A_const_339; var tmp61 any; var root_3644 any = A_arbace_go_check_A_const_332.GetRawRoot__O(); var linked_3645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3644, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3646 lang.IFn; if






















	linked_3645 == nil { ifn_3646 = lang.IFn_Cast(root_3644) } else { ifn_3646 = nil }; var arg_3647 any; var tmp62 any = A_arbace_go_check_summarize_fn__1685000440_A_New(); var tmp63 *jrt.Class; var fncls__3658 *jrt.Class = A_arbace_go_check_summarize_fn__1685000440_A_fn_class; if fncls__3658 == nil { var fncls__3658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_go_check_summarize_fn__1685000440_A_fn_class = fncls__3658d; tmp63 = fncls__3658d } else { tmp63 = fncls__3658 }; arg_3647 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil); var arg_3648 any = rs__3; if linked_3645 == nil { tmp61 = ifn_3646.Invoke_O_O__O(arg_3647, arg_3648) } else { tmp61 = linked_3645.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3644, arg_3647, arg_3648) }; var tmp64 any = /*line :546:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, tmp40, tmp42, tmp43, tmp45, tmp46, tmp48, tmp49, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp54, tmp55, tmp59, tmp60, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp61)).Ref())))); var tmp65 any = A_arbace_go_check_A_const_144; var tmp66 any; var root_3659 any = A_arbace_go_check_A_const_157.GetRawRoot__O(); var linked_3660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3659, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3661 lang.IFn; if























	linked_3660 == nil { ifn_3661 = lang.IFn_Cast(root_3659) } else { ifn_3661 = nil }; var arg_3662 any = lang.IFn_Cast(A_arbace_go_check_A_const_335.GetRawRoot__O()).Invoke__O(); var arg_3663 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_144); if linked_3660 == nil { tmp66 = ifn_3661.Invoke_O_O__O(arg_3662, arg_3663) } else { tmp66 = linked_3660.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3659, arg_3662, arg_3663) }; return /*line :546:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp18, tmp19, tmp23, tmp24, tmp25, tmp26, tmp30, tmp31, tmp35, tmp36, tmp64, tmp65, tmp66)) }



func A_arbace_go_check_summarize_sum__1685000426_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000426_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000426_A{}; t.Ctor_O(p0); return t }
//line :550:1
func (t *A_arbace_go_check_summarize_sum__1685000426_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :550:1
func (t *A_arbace_go_check_summarize_sum__1685000426_A) Invoke_O_O__O(self, k__1 any) any { var root_3560 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3560, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3562 lang.IFn; if linked_3561 == nil { ifn_3562 = lang.IFn_Cast(root_3560) } else { ifn_3562 = nil }; var arg_3563 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3564 any = A_arbace_go_check_A_const_22; var arg_3565 any; var root_3566 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_3567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3566, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3568 lang.IFn; if linked_3567 == nil { ifn_3568 = lang.IFn_Cast(root_3566) } else { ifn_3568 = nil }; var arg_3569 any = k__1; var arg_3570 any = t.F_rs; if linked_3567 == nil { arg_3565 = ifn_3568.Invoke_O_O__O(arg_3569, arg_3570) } else { arg_3565 = linked_3567.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3566, arg_3569, arg_3570) }; if linked_3561 == nil { return ifn_3562.Invoke_O_O_O__O(arg_3563, arg_3564, arg_3565) } else { return linked_3561.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3560, arg_3563, arg_3564, arg_3565) } }
func A_arbace_go_check_summarize_msum__1685000428_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000428_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000428_A{}; t.Ctor_O(p0); return t }
//line :551:1
func (t *A_arbace_go_check_summarize_msum__1685000428_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :551:1
func (t *A_arbace_go_check_summarize_msum__1685000428_A) Invoke_O_O__O(self, k__1 any) any { var root_3572 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_3573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3572, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3574 lang.IFn; if linked_3573 == nil { ifn_3574 = lang.IFn_Cast(root_3572) } else { ifn_3574 = nil }; var arg_3575 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var arg_3576 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3577 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3578 any; var root_3579 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3579, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3581 lang.IFn; if linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any = k__1; var arg_3583 any = t.F_rs; if linked_3580 == nil { arg_3578 = ifn_3581.Invoke_O_O__O(arg_3582, arg_3583) } else { arg_3578 = linked_3580.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3579, arg_3582, arg_3583) }; if linked_3573 == nil { return ifn_3574.Invoke_O_O_O_O__O(arg_3575, arg_3576, arg_3577, arg_3578) } else { return linked_3573.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3572, arg_3575, arg_3576, arg_3577, arg_3578) } }







func A_arbace_go_check_summarize_fn__1685000430_A_New() *A_arbace_go_check_summarize_fn__1685000430_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000430_A{}; t.Ctor(); return t }
//line :559:1
func (t *A_arbace_go_check_summarize_fn__1685000430_A) Ctor() {}
//line :559:1
func (t *A_arbace_go_check_summarize_fn__1685000430_A) Invoke_O_O__O(self, p1__1685000420_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_234.Invoke_O__O(p1__1685000420_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000432_A_New() *A_arbace_go_check_summarize_fn__1685000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000432_A{}; t.Ctor(); return t }
//line :561:1
func (t *A_arbace_go_check_summarize_fn__1685000432_A) Ctor() {}
//line :561:1
func (t *A_arbace_go_check_summarize_fn__1685000432_A) Invoke_O_O__O(self, p1__1685000421_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_307.Invoke_O__O(p1__1685000421_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000421_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000434_A_New() *A_arbace_go_check_summarize_fn__1685000434_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000434_A{}; t.Ctor(); return t }
//line :562:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Ctor() {}
//line :562:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Invoke_O_O__O(self, p1__1685000422_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_307.Invoke_O__O(p1__1685000422_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000422_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_110.Invoke_O__O(p1__1685000422_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000436_A_New() *A_arbace_go_check_summarize_fn__1685000436_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000436_A{}; t.Ctor(); return t }
//line :567:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Ctor() {}
//line :567:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Invoke_O_O__O(self, p1__1685000423_SHARP___1 any) any { var root_3638 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3638, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3640 lang.IFn; if linked_3639 == nil { ifn_3640 = lang.IFn_Cast(root_3638) } else { ifn_3640 = nil }; var arg_3641 any = p1__1685000423_SHARP___1; var arg_3642 any = A_arbace_go_check_A_const_337; if linked_3639 == nil { return ifn_3640.Invoke_O_O__O(arg_3641, arg_3642) } else { return linked_3639.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3638, arg_3641, arg_3642) } }
func A_arbace_go_check_summarize_fn__1685000438_A_New() *A_arbace_go_check_summarize_fn__1685000438_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000438_A{}; t.Ctor(); return t }
//line :568:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Ctor() {}
//line :568:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Invoke_O_O__O(self, p1__1685000424_SHARP___1 any) any { var root_3668 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3668, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3670 lang.IFn; if linked_3669 == nil { ifn_3670 = lang.IFn_Cast(root_3668) } else { ifn_3670 = nil }; var arg_3671 any = p1__1685000424_SHARP___1; var arg_3672 any = A_arbace_go_check_A_const_342; var arg_3673 any = A_arbace_go_check_A_const_22; if linked_3669 == nil { return ifn_3670.Invoke_O_O_O__O(arg_3671, arg_3672, arg_3673) } else { return linked_3669.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3668, arg_3671, arg_3672, arg_3673) } }
func A_arbace_go_check_summarize_fn__1685000440_A_New() *A_arbace_go_check_summarize_fn__1685000440_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000440_A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Ctor() {}
//line :569:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Invoke_O_O__O(self, p1__1685000425_SHARP___1 any) any { var root_3649 any = A_arbace_go_check_A_const_340.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3651 lang.IFn; if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any; var root_3653 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3653, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3655 lang.IFn; if linked_3654 == nil { ifn_3655 = lang.IFn_Cast(root_3653) } else { ifn_3655 = nil }; var arg_3656 any = p1__1685000425_SHARP___1; var arg_3657 any = A_arbace_go_check_A_const_341; if linked_3654 == nil { arg_3652 = ifn_3655.Invoke_O_O__O(arg_3656, arg_3657) } else { arg_3652 = linked_3654.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3653, arg_3656, arg_3657) }; if linked_3650 == nil { return ifn_3651.Invoke_O__O(arg_3652) } else { return linked_3650.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3649, arg_3652) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :572:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000443__1685000449_A_New(); var tmp2 *jrt.Class; var fncls__3760 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000443__1685000449_A_fn_class; if


	fncls__3760 == nil { var fncls__3760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_check_report_errors_iter__1685000443__1685000449_A_fn_class = fncls__3760d; tmp2 = fncls__3760d } else { tmp2 = fncls__3760 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :575:1
func A_arbace_go_check_report_errors_iter__1685000443__1685000449_A_New() *A_arbace_go_check_report_errors_iter__1685000443__1685000449_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000443__1685000449_A{}; t.Ctor(); return t }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_A) Ctor() {}
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_A) Invoke_O_O__O(self, s__1685000444__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A_New_O_O(s__1685000444__1, self); var tmp2 *jrt.Class; var fncls__3759 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A_fn_class; if fncls__3759 == nil { var fncls__3759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A_fn_class = fncls__3759d; tmp2 = fncls__3759d } else { tmp2 = fncls__3759 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :575:1
func A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A{}; t.Ctor_O_O(p0, p1); return t }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A) Ctor_O_O(c__s__1685000444, c__iter__1685000443 any) { t.F_s__1685000444 = c__s__1685000444; t.F_iter__1685000443 = c__iter__1685000443 }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A) Invoke_O__O(self any) any { { var s__1685000444__1 any; var t_ any = t.F_s__1685000444; t.F_s__1685000444 = nil; s__1685000444__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3675 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3677 lang.IFn; if linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any = s__1685000444__1; if linked_3676 == nil { temp__1927000414__auto____2 = ifn_3677.Invoke_O__O(arg_3678) } else { temp__1927000414__auto____2 = linked_3676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3675, arg_3678) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3679 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3679, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3681 lang.IFn; if linked_3680 == nil { ifn_3681 = lang.IFn_Cast(root_3679) } else { ifn_3681 = nil }; var arg_3682 any = xs__1927001018__auto____3; if linked_3680 == nil { r__4 = ifn_3681.Invoke_O__O(arg_3682) } else { r__4 = linked_3680.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3679, arg_3682) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3741 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A_fn_class; if fncls__3741 == nil { var fncls__3741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A_fn_class = fncls__3741d; tmp2 = fncls__3741d } else { tmp2 = fncls__3741 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3742 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3744 lang.IFn; if linked_3743 == nil { ifn_3744 = lang.IFn_Cast(root_3742) } else { ifn_3744 = nil }; var arg_3745 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_234.Invoke_O__O(r__4)); if linked_3743 == nil { fs__1927001036__auto____6 = ifn_3744.Invoke_O__O(arg_3745) } else { fs__1927001036__auto____6 = linked_3743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3742, arg_3745) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3746 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3746, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3748 lang.IFn; if linked_3747 == nil { ifn_3748 = lang.IFn_Cast(root_3746) } else { ifn_3748 = nil }; var arg_3749 any = fs__1927001036__auto____6; var arg_3750 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000443); var tmp4 any; var root_3751 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3751, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3753 lang.IFn; if linked_3752 == nil { ifn_3753 = lang.IFn_Cast(root_3751) } else { ifn_3753 = nil }; var arg_3754 any = s__1685000444__1; if linked_3752 == nil { tmp4 = ifn_3753.Invoke_O__O(arg_3754) } else { tmp4 = linked_3752.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3751, arg_3754) }; arg_3750 = tmp3.Invoke_O__O(tmp4); if linked_3747 == nil { return ifn_3748.Invoke_O_O__O(arg_3749, arg_3750) } else { return linked_3747.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3746, arg_3749, arg_3750) } } else { var tmp5 any; var root_3755 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3755, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3757 lang.IFn; if linked_3756 == nil { ifn_3757 = lang.IFn_Cast(root_3755) } else { ifn_3757 = nil }; var arg_3758 any = s__1685000444__1; if linked_3756 == nil { tmp5 = ifn_3757.Invoke_O__O(arg_3758) } else { tmp5 = linked_3756.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3755, arg_3758) }; s__1685000444__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :575:1
func A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A{}; t.Ctor_O(p0); return t }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A) Invoke_O_O__O(self, s__1685000446__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A_New_O_O_O(t.F_r, s__1685000446__1, self); var tmp2 *jrt.Class; var fncls__3740 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A_fn_class; if fncls__3740 == nil { var fncls__3740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A_fn_class = fncls__3740d; tmp2 = fncls__3740d } else { tmp2 = fncls__3740 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :575:1
func A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A) Ctor_O_O_O(c__r, c__s__1685000446, c__iter__1685000445 any) { t.F_r = c__r; t.F_s__1685000446 = c__s__1685000446; t.F_iter__1685000445 = c__iter__1685000445 }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A) Invoke_O__O(self any) any { { var s__1685000446__1 any; var t_ any = t.F_s__1685000446; t.F_s__1685000446 = nil; s__1685000446__1 = t_; for { var temp__1927000414__auto____2 any; var root_3683 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3683, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3685 lang.IFn; if linked_3684 == nil { ifn_3685 = lang.IFn_Cast(root_3683) } else { ifn_3685 = nil }; var arg_3686 any = s__1685000446__1; if linked_3684 == nil { temp__1927000414__auto____2 = ifn_3685.Invoke_O__O(arg_3686) } else { temp__1927000414__auto____2 = linked_3684.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3683, arg_3686) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000446__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3687 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3687, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3689 lang.IFn; if linked_3688 == nil { ifn_3689 = lang.IFn_Cast(root_3687) } else { ifn_3689 = nil }; var arg_3690 any = s__1685000446__3; if linked_3688 == nil { tmp1 = ifn_3689.Invoke_O__O(arg_3690) } else { tmp1 = linked_3688.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3687, arg_3690) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3691 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3691, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3693 lang.IFn; if linked_3692 == nil { ifn_3693 = lang.IFn_Cast(root_3691) } else { ifn_3693 = nil }; var arg_3694 any = s__1685000446__3; if linked_3692 == nil { c__1927001037__auto____4 = ifn_3693.Invoke_O__O(arg_3694) } else { c__1927001037__auto____4 = linked_3692.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3691, arg_3694) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000448__6 any; var root_3695 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3695, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3697 lang.IFn; if linked_3696 == nil { ifn_3697 = lang.IFn_Cast(root_3695) } else { ifn_3697 = nil }; var arg_3698 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3696 == nil { b__1685000448__6 = ifn_3697.Invoke_O__O(arg_3698) } else { b__1685000448__6 = linked_3696.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3695, arg_3698) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A_New_O_O_I_O(b__1685000448__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3704 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A_fn_class; if fncls__3704 == nil { var fncls__3704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A_fn_class = fncls__3704d; tmp3 = fncls__3704d } else { tmp3 = fncls__3704 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3705 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3705, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3707 lang.IFn; if linked_3706 == nil { ifn_3707 = lang.IFn_Cast(root_3705) } else { ifn_3707 = nil }; var arg_3708 any; var root_3710 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3710, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3712 lang.IFn; if linked_3711 == nil { ifn_3712 = lang.IFn_Cast(root_3710) } else { ifn_3712 = nil }; var arg_3713 any = b__1685000448__6; if linked_3711 == nil { arg_3708 = ifn_3712.Invoke_O__O(arg_3713) } else { arg_3708 = linked_3711.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3710, arg_3713) }; var arg_3709 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000445); var tmp5 any; var root_3714 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3714, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3716 lang.IFn; if linked_3715 == nil { ifn_3716 = lang.IFn_Cast(root_3714) } else { ifn_3716 = nil }; var arg_3717 any = s__1685000446__3; if linked_3715 == nil { tmp5 = ifn_3716.Invoke_O__O(arg_3717) } else { tmp5 = linked_3715.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3714, arg_3717) }; arg_3709 = tmp4.Invoke_O__O(tmp5); if linked_3706 == nil { return ifn_3707.Invoke_O_O__O(arg_3708, arg_3709) } else { return linked_3706.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3705, arg_3708, arg_3709) } } else { var root_3718 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3718, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3720 lang.IFn; if linked_3719 == nil { ifn_3720 = lang.IFn_Cast(root_3718) } else { ifn_3720 = nil }; var arg_3721 any; var root_3723 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3723, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3725 lang.IFn; if linked_3724 == nil { ifn_3725 = lang.IFn_Cast(root_3723) } else { ifn_3725 = nil }; var arg_3726 any = b__1685000448__6; if linked_3724 == nil { arg_3721 = ifn_3725.Invoke_O__O(arg_3726) } else { arg_3721 = linked_3724.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3723, arg_3726) }; var arg_3722 any; if linked_3719 == nil { return ifn_3720.Invoke_O_O__O(arg_3721, arg_3722) } else { return linked_3719.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3718, arg_3721, arg_3722) } } } else { var e__4 any; var root_3727 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3727, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3729 lang.IFn; if linked_3728 == nil { ifn_3729 = lang.IFn_Cast(root_3727) } else { ifn_3729 = nil }; var arg_3730 any = s__1685000446__3; if linked_3728 == nil { e__4 = ifn_3729.Invoke_O__O(arg_3730) } else { e__4 = linked_3728.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3727, arg_3730) }; var root_3731 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3731, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3733 lang.IFn; if linked_3732 == nil { ifn_3733 = lang.IFn_Cast(root_3731) } else { ifn_3733 = nil }; var arg_3734 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, Lit_26, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_308.Invoke_O__O(e__4))).Ref(); var arg_3735 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000445); var tmp7 any; var root_3736 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3736, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3738 lang.IFn; if linked_3737 == nil { ifn_3738 = lang.IFn_Cast(root_3736) } else { ifn_3738 = nil }; var arg_3739 any = s__1685000446__3; if linked_3737 == nil { tmp7 = ifn_3738.Invoke_O__O(arg_3739) } else { tmp7 = linked_3737.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3736, arg_3739) }; arg_3735 = tmp6.Invoke_O__O(tmp7); if linked_3732 == nil { return ifn_3733.Invoke_O_O__O(arg_3734, arg_3735) } else { return linked_3732.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3731, arg_3734, arg_3735) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :575:1
func A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A) Ctor_O_O_I_O(c__b__1685000448, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000448 = c__b__1685000448; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :575:1
func (t *A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A) Invoke_O__O(self any) any { { var i__1685000447__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000447__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000447__1)); var root_3699 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3699, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3701 lang.IFn; if linked_3700 == nil { ifn_3701 = lang.IFn_Cast(root_3699) } else { ifn_3701 = nil }; var arg_3702 any = t.F_b__1685000448; var arg_3703 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, Lit_26, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_308.Invoke_O__O(e__2))).Ref(); if linked_3700 == nil { ifn_3701.Invoke_O_O__O(arg_3702, arg_3703) } else { linked_3700.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3699, arg_3702, arg_3703) }; i__1685000447__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000447__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :580:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :580:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000461__3 any; var root_3761 any = A_arbace_go_check_A_const_343.GetRawRoot__O(); var linked_3762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3761, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3763 lang.IFn; if



	linked_3762 == nil { ifn_3763 = lang.IFn_Cast(root_3761) } else { ifn_3763 = nil }; var arg_3764 any = forms__0; if linked_3762 == nil { map__1685000461__3 = ifn_3763.Invoke_O__O(arg_3764) } else { map__1685000461__3 = linked_3762.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3761, arg_3764) }; var map__1685000461__4 any; if lang.ISeq_InstanceOf(map__1685000461__3) { var tmp1 any; var root_3765 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3765, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3767 lang.IFn; if linked_3766 == nil { ifn_3767 = lang.IFn_Cast(root_3765) } else { ifn_3767 = nil }; var arg_3768 any = map__1685000461__3; if linked_3766 == nil { tmp1 = ifn_3767.Invoke_O__O(arg_3768) } else { tmp1 = linked_3766.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3765, arg_3768) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3769 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3771 lang.IFn; if linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any = map__1685000461__3; if linked_3770 == nil { tmp2 = ifn_3771.Invoke_O__O(arg_3772) } else { tmp2 = linked_3770.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3769, arg_3772) }; map__1685000461__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3773 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3775 lang.IFn; if linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = map__1685000461__3; if linked_3774 == nil { tmp3 = ifn_3775.Invoke_O__O(arg_3776) } else { tmp3 = linked_3774.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3773, arg_3776) }; if jrt.J2g_Truth(tmp3) { var root_3777 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3779 lang.IFn; if linked_3778 == nil { ifn_3779 = lang.IFn_Cast(root_3777) } else { ifn_3779 = nil }; var arg_3780 any = map__1685000461__3; if linked_3778 == nil { map__1685000461__4 = ifn_3779.Invoke_O__O(arg_3780) } else { map__1685000461__4 = linked_3778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3777, arg_3780) } } else { map__1685000461__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000461__4 = map__1685000461__3 }; var package__5 any = /*line :580:1*/lang.RT_Get_O_O__O_NoInit(map__1685000461__4, A_arbace_go_check_A_const_109); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000461__4, A_arbace_go_check_A_const_70); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000461__4, A_arbace_go_check_A_const_124); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_344.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_345; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_111.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_110; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_110.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_117 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_70; var tmp10 any; var root_3787 any = /*line :580:1*/A_arbace_go_check_A_const_346.GetRawRoot__O(); var linked_3788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3787, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3789 lang.IFn; if





	linked_3788 == nil { ifn_3789 = lang.IFn_Cast(root_3787) } else { ifn_3789 = nil }; var arg_3790 any = name__6; if linked_3788 == nil { tmp10 = ifn_3789.Invoke_O__O(arg_3790) } else { tmp10 = linked_3788.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3787, arg_3790) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_111; var tmp13 any = A_arbace_go_check_A_const_81; var tmp14 any = A_arbace_go_check_A_const_229; var tmp15 any; var root_3791 any = /*line :580:1*/A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3793 lang.IFn; if






	linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; var arg_3794 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000463_A_New(); var tmp17 *jrt.Class; var fncls__3808 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000463_A_fn_class; if fncls__3808 == nil { var fncls__3808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_go_check_forms_source_fn__1685000463_A_fn_class = fncls__3808d; tmp17 = fncls__3808d } else { tmp17 = fncls__3808 }; arg_3794 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3795 any = forms__0; if linked_3792 == nil { tmp15 = ifn_3793.Invoke_O_O__O(arg_3794, arg_3795) } else { tmp15 = linked_3792.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3791, arg_3794, arg_3795) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_124; var tmp20 any; var root_3809 any = /*line :580:1*/A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3809, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3811 lang.IFn; if







	linked_3810 == nil { ifn_3811 = lang.IFn_Cast(root_3809) } else { ifn_3811 = nil }; var arg_3812 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000465__1685000469_A_New(); var tmp22 *jrt.Class; var fncls__3883 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000465__1685000469_A_fn_class; if fncls__3883 == nil { var fncls__3883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_forms_source_iter__1685000465__1685000469_A_fn_class = fncls__3883d; tmp22 = fncls__3883d } else { tmp22 = fncls__3883 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3812 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3810 == nil { tmp20 = ifn_3811.Invoke_O__O(arg_3812) } else { tmp20 = linked_3810.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3809, arg_3812) }; return /*line :580:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000463_A_New() *A_arbace_go_check_forms_source_fn__1685000463_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000463_A{}; t.Ctor(); return t }
//line :587:1
func (t *A_arbace_go_check_forms_source_fn__1685000463_A) Ctor() {}
//line :587:1
func (t *A_arbace_go_check_forms_source_fn__1685000463_A) Invoke_O_O__O(self, p1__1685000460_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3796 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3796, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3798 lang.IFn; if linked_3797 == nil { ifn_3798 = lang.IFn_Cast(root_3796) } else { ifn_3798 = nil }; var arg_3799 any = p1__1685000460_SHARP___1; if linked_3797 == nil { and__1927000168__auto____2 = ifn_3798.Invoke_O__O(arg_3799) } else { and__1927000168__auto____2 = linked_3797.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3796, arg_3799) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_347; var tmp3 any; var root_3800 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3800, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3802 lang.IFn; if linked_3801 == nil { ifn_3802 = lang.IFn_Cast(root_3800) } else { ifn_3802 = nil }; var arg_3803 any = p1__1685000460_SHARP___1; if linked_3801 == nil { tmp3 = ifn_3802.Invoke_O__O(arg_3803) } else { tmp3 = linked_3801.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3800, arg_3803) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3804 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_3805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3804, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3806 lang.IFn; if linked_3805 == nil { ifn_3806 = lang.IFn_Cast(root_3804) } else { ifn_3806 = nil }; var arg_3807 any = p1__1685000460_SHARP___1; if linked_3805 == nil { return ifn_3806.Invoke_O__O(arg_3807) } else { return linked_3805.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3804, arg_3807) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000465__1685000469_A_New() *A_arbace_go_check_forms_source_iter__1685000465__1685000469_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000465__1685000469_A{}; t.Ctor(); return t }
//line :588:1
func (t *A_arbace_go_check_forms_source_iter__1685000465__1685000469_A) Ctor() {}
//line :588:1
func (t *A_arbace_go_check_forms_source_iter__1685000465__1685000469_A) Invoke_O_O__O(self, s__1685000466__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A_New_O_O(s__1685000466__1, self); var tmp2 *jrt.Class; var fncls__3882 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A_fn_class; if fncls__3882 == nil { var fncls__3882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A_fn_class = fncls__3882d; tmp2 = fncls__3882d } else { tmp2 = fncls__3882 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :588:1
func A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A{}; t.Ctor_O_O(p0, p1); return t }
//line :588:1
func (t *A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A) Ctor_O_O(c__s__1685000466, c__iter__1685000465 any) { t.F_s__1685000466 = c__s__1685000466; t.F_iter__1685000465 = c__iter__1685000465 }
//line :588:1
func (t *A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A) Invoke_O__O(self any) any { { var s__1685000466__1 any; var t_ any = t.F_s__1685000466; t.F_s__1685000466 = nil; s__1685000466__1 = t_; for { var temp__1927000414__auto____2 any; var root_3813 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3813, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3815 lang.IFn; if linked_3814 == nil { ifn_3815 = lang.IFn_Cast(root_3813) } else { ifn_3815 = nil }; var arg_3816 any = s__1685000466__1; if linked_3814 == nil { temp__1927000414__auto____2 = ifn_3815.Invoke_O__O(arg_3816) } else { temp__1927000414__auto____2 = linked_3814.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3813, arg_3816) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000466__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3817 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3817, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3819 lang.IFn; if linked_3818 == nil { ifn_3819 = lang.IFn_Cast(root_3817) } else { ifn_3819 = nil }; var arg_3820 any = s__1685000466__3; if linked_3818 == nil { tmp1 = ifn_3819.Invoke_O__O(arg_3820) } else { tmp1 = linked_3818.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3817, arg_3820) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3821 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3823 lang.IFn; if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any = s__1685000466__3; if linked_3822 == nil { c__1927001037__auto____4 = ifn_3823.Invoke_O__O(arg_3824) } else { c__1927001037__auto____4 = linked_3822.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3821, arg_3824) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000468__6 any; var root_3825 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3826 == nil { b__1685000468__6 = ifn_3827.Invoke_O__O(arg_3828) } else { b__1685000468__6 = linked_3826.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3825, arg_3828) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A_New_O_I_O(b__1685000468__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3840 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A_fn_class; if fncls__3840 == nil { var fncls__3840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A_fn_class = fncls__3840d; tmp3 = fncls__3840d } else { tmp3 = fncls__3840 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3841 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3841, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3843 lang.IFn; if linked_3842 == nil { ifn_3843 = lang.IFn_Cast(root_3841) } else { ifn_3843 = nil }; var arg_3844 any; var root_3846 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3846, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3848 lang.IFn; if linked_3847 == nil { ifn_3848 = lang.IFn_Cast(root_3846) } else { ifn_3848 = nil }; var arg_3849 any = b__1685000468__6; if linked_3847 == nil { arg_3844 = ifn_3848.Invoke_O__O(arg_3849) } else { arg_3844 = linked_3847.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3846, arg_3849) }; var arg_3845 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000465); var tmp5 any; var root_3850 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3850, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3852 lang.IFn; if linked_3851 == nil { ifn_3852 = lang.IFn_Cast(root_3850) } else { ifn_3852 = nil }; var arg_3853 any = s__1685000466__3; if linked_3851 == nil { tmp5 = ifn_3852.Invoke_O__O(arg_3853) } else { tmp5 = linked_3851.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3850, arg_3853) }; arg_3845 = tmp4.Invoke_O__O(tmp5); if linked_3842 == nil { return ifn_3843.Invoke_O_O__O(arg_3844, arg_3845) } else { return linked_3842.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3841, arg_3844, arg_3845) } } else { var root_3854 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3854, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3856 lang.IFn; if linked_3855 == nil { ifn_3856 = lang.IFn_Cast(root_3854) } else { ifn_3856 = nil }; var arg_3857 any; var root_3859 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3859, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3861 lang.IFn; if linked_3860 == nil { ifn_3861 = lang.IFn_Cast(root_3859) } else { ifn_3861 = nil }; var arg_3862 any = b__1685000468__6; if linked_3860 == nil { arg_3857 = ifn_3861.Invoke_O__O(arg_3862) } else { arg_3857 = linked_3860.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3859, arg_3862) }; var arg_3858 any; if linked_3855 == nil { return ifn_3856.Invoke_O_O__O(arg_3857, arg_3858) } else { return linked_3855.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3854, arg_3857, arg_3858) } } } else { var fi__4 any; var root_3863 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3863, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3865 lang.IFn; if linked_3864 == nil { ifn_3865 = lang.IFn_Cast(root_3863) } else { ifn_3865 = nil }; var arg_3866 any = s__1685000466__3; if linked_3864 == nil { fi__4 = ifn_3865.Invoke_O__O(arg_3866) } else { fi__4 = linked_3864.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3863, arg_3866) }; var root_3867 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3867, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3869 lang.IFn; if linked_3868 == nil { ifn_3869 = lang.IFn_Cast(root_3867) } else { ifn_3869 = nil }; var arg_3870 any; var root_3872 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3873 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3872, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3874 lang.IFn; if linked_3873 == nil { ifn_3874 = lang.IFn_Cast(root_3872) } else { ifn_3874 = nil }; var arg_3875 any = fi__4; var arg_3876 any = A_arbace_go_check_A_const_81; var arg_3877 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__4); if linked_3873 == nil { arg_3870 = ifn_3874.Invoke_O_O_O__O(arg_3875, arg_3876, arg_3877) } else { arg_3870 = linked_3873.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3872, arg_3875, arg_3876, arg_3877) }; var arg_3871 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000465); var tmp7 any; var root_3878 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_3879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3878, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3880 lang.IFn; if linked_3879 == nil { ifn_3880 = lang.IFn_Cast(root_3878) } else { ifn_3880 = nil }; var arg_3881 any = s__1685000466__3; if linked_3879 == nil { tmp7 = ifn_3880.Invoke_O__O(arg_3881) } else { tmp7 = linked_3879.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3878, arg_3881) }; arg_3871 = tmp6.Invoke_O__O(tmp7); if linked_3868 == nil { return ifn_3869.Invoke_O_O__O(arg_3870, arg_3871) } else { return linked_3868.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3867, arg_3870, arg_3871) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :588:1
func A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :588:1
func (t *A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A) Ctor_O_I_O(c__b__1685000468 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000468 = c__b__1685000468; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :588:1
func (t *A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A) Invoke_O__O(self any) any { { var i__1685000467__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000467__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000467__1)); var root_3829 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3829, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3831 lang.IFn; if linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any = t.F_b__1685000468; var arg_3833 any; var root_3834 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_3835 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3834, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3836 lang.IFn; if linked_3835 == nil { ifn_3836 = lang.IFn_Cast(root_3834) } else { ifn_3836 = nil }; var arg_3837 any = fi__2; var arg_3838 any = A_arbace_go_check_A_const_81; var arg_3839 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__2); if linked_3835 == nil { arg_3833 = ifn_3836.Invoke_O_O_O__O(arg_3837, arg_3838, arg_3839) } else { arg_3833 = linked_3835.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3834, arg_3837, arg_3838, arg_3839) }; if linked_3830 == nil { ifn_3831.Invoke_O_O__O(arg_3832, arg_3833) } else { linked_3830.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3829, arg_3832, arg_3833) }; i__1685000467__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000467__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :590:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :590:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3893 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_3894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3893, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3895 lang.IFn; if




	linked_3894 == nil { ifn_3895 = lang.IFn_Cast(root_3893) } else { ifn_3895 = nil }; var arg_3896 any = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_349, jrt.Boolean_FALSE.Ref()); if linked_3894 == nil { ifn_3895.Invoke_O__O(arg_3896) } else { linked_3894.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3893, arg_3896) }; var tmp1 any; tmp3 := /*line :590:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3884 any = A_arbace_go_check_A_const_348.GetRawRoot__O(); var linked_3885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3884, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3886 lang.IFn






		if linked_3885 == nil { ifn_3886 = lang.IFn_Cast(root_3884) } else { ifn_3886 = nil }; var arg_3887 any = r__2; var arg_3888 any = jrt.Boolean_FALSE.Ref(); var arg_3889 any = eof__3; if linked_3885 == nil { f__7 = ifn_3886.Invoke_O_O_O__O(arg_3887, arg_3888, arg_3889) } else { f__7 = linked_3885.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3884, arg_3887, arg_3888, arg_3889) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3902 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = acc__6; var arg_3906 any = f__7; if linked_3903 == nil { tmp2 = ifn_3904.Invoke_O_O__O(arg_3905, arg_3906) } else { tmp2 = linked_3903.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3902, arg_3905, arg_3906) }; acc__6 = tmp2; continue L1 }
//line :590:1
		break L1 } }; return nil }(); var root_3890 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_3891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3890, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3892 lang.IFn; if




	linked_3891 == nil { ifn_3892 = lang.IFn_Cast(root_3890) } else { ifn_3892 = nil }; if linked_3891 == nil { ifn_3892.Invoke__O() } else { linked_3891.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3890) }; if /*line :590:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :602:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :602:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3907 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3907, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3909 lang.IFn; if


	linked_3908 == nil { ifn_3909 = lang.IFn_Cast(root_3907) } else { ifn_3909 = nil }; var arg_3910 any = A_arbace_go_check_A_const_350.GetRawRoot__O(); if linked_3908 == nil { tmp1 = ifn_3909.Invoke_O__O(arg_3910) } else { tmp1 = linked_3908.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3907, arg_3910) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3911 any = A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3911, A_arbace_go_check_std_session_A_fn_class); var ifn_3913 lang.IFn
		if linked_3912 == nil { ifn_3913 = lang.IFn_Cast(root_3911) } else { ifn_3913 = nil }; var arg_3914 any; var root_3915 any = A_arbace_go_check_A_const_311.GetRawRoot__O(); var linked_3916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3915, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3917 lang.IFn; if linked_3916 == nil { ifn_3917 = lang.IFn_Cast(root_3915) } else { ifn_3917 = nil }; var arg_3918 any = corpus__0; if linked_3916 == nil { arg_3914 = ifn_3917.Invoke_O__O(arg_3918) } else { arg_3914 = linked_3916.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3915, arg_3918) }; if linked_3912 == nil { s__3 = ifn_3913.Invoke_O__O(arg_3914) } else { s__3 = linked_3912.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3911, arg_3914) }
		var root_3919 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3919, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3921 lang.IFn; if linked_3920 == nil { ifn_3921 = lang.IFn_Cast(root_3919) } else { ifn_3921 = nil }; var arg_3922 any = A_arbace_go_check_A_const_350.GetRawRoot__O(); var arg_3923 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var arg_3924 any = corpus__0; var arg_3925 any = s__3; if linked_3920 == nil { ifn_3921.Invoke_O_O_O_O__O(arg_3922, arg_3923, arg_3924, arg_3925) } else { linked_3920.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3919, arg_3922, arg_3923, arg_3924, arg_3925) }
//line :605:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :610:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :610:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3926 any = A_arbace_go_check_A_const_351.GetRawRoot__O(); var linked_3927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3926, A_arbace_go_check_std_A_fn_class); var ifn_3928 lang.IFn; if




	linked_3927 == nil { ifn_3928 = lang.IFn_Cast(root_3926) } else { ifn_3928 = nil }; var arg_3929 any = corpus__1; if linked_3927 == nil { s__4 = ifn_3928.Invoke_O__O(arg_3929) } else { s__4 = linked_3927.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3926, arg_3929) }; var src__5 any; var root_3930 any = /*line :610:1*/A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_3931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3930, A_arbace_go_check_forms_source_A_fn_class); var ifn_3932 lang.IFn; if





	linked_3931 == nil { ifn_3932 = lang.IFn_Cast(root_3930) } else { ifn_3932 = nil }; var arg_3933 any = forms__0; var arg_3934 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_111; var tmp2 any; var root_3935 any = A_arbace_go_check_A_const_311.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3935, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3937 lang.IFn; if linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; var arg_3938 any = corpus__1; if linked_3936 == nil { tmp2 = ifn_3937.Invoke_O__O(arg_3938) } else { tmp2 = linked_3936.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3935, arg_3938) }; arg_3934 = tmp1.Invoke_O__O(tmp2); if linked_3931 == nil { src__5 = ifn_3932.Invoke_O_O__O(arg_3933, arg_3934) } else { src__5 = linked_3931.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3930, arg_3933, arg_3934) }; var pkg__6 any; var tmp3 lang.IFn = /*line :610:1*/lang.IFn_Cast(A_arbace_go_check_A_const_273.GetRawRoot__O()); var tmp4 any; var root_3946 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_3947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3946, A_arbace_go_check_resolver_A_fn_class); var ifn_3948 lang.IFn; if






	linked_3947 == nil { ifn_3948 = lang.IFn_Cast(root_3946) } else { ifn_3948 = nil }; var arg_3949 any = s__4; var arg_3950 any = src__5; var arg_3951 any = lang.PersistentVector_EMPTY.Ref(); if linked_3947 == nil { tmp4 = ifn_3948.Invoke_O_O_O__O(arg_3949, arg_3950, arg_3951) } else { tmp4 = linked_3947.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3946, arg_3949, arg_3950, arg_3951) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_108; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_108.Invoke_O__O(opts__2)); var root_3952 any =
	A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3952, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3954 lang.IFn; if linked_3953 == nil { ifn_3954 = lang.IFn_Cast(root_3952) } else { ifn_3954 = nil }; var arg_3955 any = pkg__6; var arg_3956 any = A_arbace_go_check_A_const_233; if linked_3953 == nil { return ifn_3954.Invoke_O_O__O(arg_3955, arg_3956) } else { return linked_3953.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3952, arg_3955, arg_3956) } }
//line :610:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_3957 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); var linked_3958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3957, A_arbace_go_check_check_forms_A_fn_class); var ifn_3959 lang.IFn; if linked_3958 == nil { ifn_3959 = lang.IFn_Cast(root_3957) } else { ifn_3959 = nil }; var arg_3960 any = forms__0; var arg_3961 any = Lit_54; var arg_3962 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3958 == nil { return ifn_3959.Invoke_O_O_O__O(arg_3960, arg_3961, arg_3962) } else { return linked_3958.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_3957, arg_3960, arg_3961, arg_3962)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :626:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :626:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_358.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_354.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_3980 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_3981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3980, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3982 lang.IFn; if linked_3981 == nil { ifn_3982 = lang.IFn_Cast(root_3980) } else { ifn_3982 = nil }; var arg_3983 any = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_357, s__1927001093__auto____3); if linked_3981 == nil { ifn_3982.Invoke_O__O(arg_3983) } else { linked_3981.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3980, arg_3983) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000479_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__3979 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000479_A_fn_class; if fncls__3979 == nil { var fncls__3979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_go_check_write_edn_fn__1685000479_A_fn_class = fncls__3979d; tmp4 = fncls__3979d } else { tmp4 = fncls__3979 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :628:1
func A_arbace_go_check_write_edn_fn__1685000479_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000479_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000479_A{}; t.Ctor_O_O(p0, p1); return t }
//line :628:1
func (t *A_arbace_go_check_write_edn_fn__1685000479_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :628:1
func (t *A_arbace_go_check_write_edn_fn__1685000479_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3975 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_3976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3975, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_3977 lang.IFn; if linked_3976 == nil { ifn_3977 = lang.IFn_Cast(root_3975) } else { ifn_3977 = nil }; var arg_3978 any; var t_ any = t.F_x; t.F_x = nil; arg_3978 = t_; if linked_3976 == nil { ifn_3977.Invoke_O__O(arg_3978) } else { linked_3976.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_3975, arg_3978) }; var root_3968 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_3969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3968, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3970 lang.IFn; if linked_3969 == nil { ifn_3970 = lang.IFn_Cast(root_3968) } else { ifn_3970 = nil }; var arg_3971 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_3971 = t__2; if linked_3969 == nil { tmp1 = ifn_3970.Invoke_O__O(arg_3971) } else { tmp1 = linked_3969.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3968, arg_3971) } }; return nil }(); var root_3972 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_3973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3972, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3974 lang.IFn; if linked_3973 == nil { ifn_3974 = lang.IFn_Cast(root_3972) } else { ifn_3974 = nil }; if linked_3973 == nil { ifn_3974.Invoke__O() } else { linked_3973.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3972) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }






func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :635:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :635:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any {
	if jrt.J2g_Truth(A_arbace_go_check_A_const_359.Get__O()) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_359.Get__O(), nil, corpus__0, nil)).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_127, nil, Lit_128), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil, corpus__0, nil)).Ref()
		} }
func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :640:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :640:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000483__1 any) any { var map__1685000484__3 any = p__1685000483__1; var map__1685000484__4 any; if lang.ISeq_InstanceOf(map__1685000484__3) { var tmp1 any; var root_3993 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3993, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3995 lang.IFn; if linked_3994 == nil { ifn_3995 = lang.IFn_Cast(root_3993) } else { ifn_3995 = nil }; var arg_3996 any = map__1685000484__3; if linked_3994 == nil { tmp1 = ifn_3995.Invoke_O__O(arg_3996) } else { tmp1 = linked_3994.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3993, arg_3996) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3997 any = A_arbace_go_check_A_const_107.GetRawRoot__O(); var linked_3998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3997, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3999 lang.IFn; if linked_3998 == nil { ifn_3999 = lang.IFn_Cast(root_3997) } else { ifn_3999 = nil }; var arg_4000 any = map__1685000484__3; if linked_3998 == nil { tmp2 = ifn_3999.Invoke_O__O(arg_4000) } else { tmp2 = linked_3998.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3997, arg_4000) }; map__1685000484__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_4001 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4001, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4003 lang.IFn; if linked_4002 == nil { ifn_4003 = lang.IFn_Cast(root_4001) } else { ifn_4003 = nil }; var arg_4004 any = map__1685000484__3; if linked_4002 == nil { tmp3 = ifn_4003.Invoke_O__O(arg_4004) } else { tmp3 = linked_4002.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4001, arg_4004) }; if jrt.J2g_Truth(tmp3) { var root_4005 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4005, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4007 lang.IFn; if linked_4006 == nil { ifn_4007 = lang.IFn_Cast(root_4005) } else { ifn_4007 = nil }; var arg_4008 any = map__1685000484__3; if linked_4006 == nil { map__1685000484__4 = ifn_4007.Invoke_O__O(arg_4008) } else { map__1685000484__4 = linked_4006.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4005, arg_4008) } } else { map__1685000484__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000484__4 = map__1685000484__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000484__4, A_arbace_go_check_A_const_360); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000484__4, A_arbace_go_check_A_const_361); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000484__4, A_arbace_go_check_A_const_362); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_4009 any = A_arbace_go_check_A_const_363.GetRawRoot__O(); var linked_4010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4009, A_arbace_go_check_check_corpus_A_fn_class); var ifn_4011 lang.IFn; if






	linked_4010 == nil { ifn_4011 = lang.IFn_Cast(root_4009) } else { ifn_4011 = nil }; var arg_4012 any = corpus__0; var arg_4013 any = jobs__5; if linked_4010 == nil { rs__9 = ifn_4011.Invoke_O_O__O(arg_4012, arg_4013) } else { rs__9 = linked_4010.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_4009, arg_4012, arg_4013) }; var sm__10 any; var root_4014 any = /*line :640:1*/A_arbace_go_check_A_const_364.GetRawRoot__O(); var linked_4015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4014, A_arbace_go_check_summarize_A_fn_class); var ifn_4016 lang.IFn; if







	linked_4015 == nil { ifn_4016 = lang.IFn_Cast(root_4014) } else { ifn_4016 = nil }; var arg_4017 any = corpus__0; var arg_4018 any = rs__9; if linked_4015 == nil { sm__10 = ifn_4016.Invoke_O_O__O(arg_4017, arg_4018) } else { sm__10 = linked_4015.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_4014, arg_4017, arg_4018) }; var secs__11 float64 = /*line :640:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_365; var tmp5 any; var root_4019 any = A_arbace_go_check_A_const_366.GetRawRoot__O(); var linked_4020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4019, A_arbace_go_check_reference_path_A_fn_class); var ifn_4021 lang.IFn; if









	linked_4020 == nil { ifn_4021 = lang.IFn_Cast(root_4019) } else { ifn_4021 = nil }; var arg_4022 any = corpus__0; if linked_4020 == nil { tmp5 = ifn_4021.Invoke_O__O(arg_4022) } else { tmp5 = linked_4020.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4019, arg_4022) }; ref_file__12 = /*line :640:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var r__13 any; var root_4023 any = A_arbace_go_check_A_const_367.GetRawRoot__O(); var linked_4024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4023, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_4025 lang.IFn
		if linked_4024 == nil { ifn_4025 = lang.IFn_Cast(root_4023) } else { ifn_4025 = nil }; var arg_4026 any = lang.IFn_Cast(A_arbace_go_check_A_const_368.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_4024 == nil { r__13 = ifn_4025.Invoke_O__O(arg_4026) } else { r__13 = linked_4024.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_4023, arg_4026) }; if jrt.J2g_Truth(A_arbace_go_check_A_const_359.Get__O()) { var root_4031 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_4032 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4031, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4033 lang.IFn; if linked_4032 == nil { ifn_4033 = lang.IFn_Cast(root_4031) } else { ifn_4033 = nil }; var arg_4034 any = A_arbace_go_check_A_const_369.Invoke_O__O(r__13); var arg_4035 any = A_arbace_go_check_A_const_333; if linked_4032 == nil { ref__13 = ifn_4033.Invoke_O_O__O(arg_4034, arg_4035) } else { ref__13 = linked_4032.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4031, arg_4034, arg_4035) } } else { ref__13 = r__13 } } else {
//line :651:1
			ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_4036 any = /*line :640:1*/A_arbace_go_check_A_const_234.Invoke_O__O(sm__10); if












	jrt.Long_InstanceOf(na_4036) { var n0_4037 int64 = jrt.NN(jrt.Long_Cast(na_4036)).LongValue__J(); and__1927000168__auto____14 = n0_4037 == 0 } else { if jrt.Double_InstanceOf(na_4036) { var n0_4037_2 float64 = jrt.NN(jrt.Double_Cast(na_4036)).DoubleValue__D(); and__1927000168__auto____14 = n0_4037_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_4036) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_4038 any = A_arbace_go_check_A_const_331.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_4038) { var n0_4039 int64 = jrt.NN(jrt.Long_Cast(na_4038)).LongValue__J(); and__1927000168__auto____15 = n0_4039 == 0 } else { if jrt.Double_InstanceOf(na_4038) { var n0_4039_2 float64 = jrt.NN(jrt.Double_Cast(na_4038)).DoubleValue__D(); and__1927000168__auto____15 = n0_4039_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_4038) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_4040 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_4041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4040, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4042 lang.IFn; if linked_4041 == nil { ifn_4042 = lang.IFn_Cast(root_4040) } else { ifn_4042 = nil }; var arg_4043 any; var root_4044 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4044, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4046 lang.IFn; if linked_4045 == nil { ifn_4046 = lang.IFn_Cast(root_4044) } else { ifn_4046 = nil }; var arg_4047 any = sm__10; var arg_4048 any = A_arbace_go_check_A_const_370; if linked_4045 == nil { arg_4043 = ifn_4046.Invoke_O_O__O(arg_4047, arg_4048) } else { arg_4043 = linked_4045.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4044, arg_4047, arg_4048) }; if linked_4041 == nil { and__1927000168__auto____16 = ifn_4042.Invoke_O__O(arg_4043) } else { and__1927000168__auto____16 = linked_4041.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4040, arg_4043) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_4049 any; var root_4050 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4050, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4052 lang.IFn
		if linked_4051 == nil { ifn_4052 = lang.IFn_Cast(root_4050) } else { ifn_4052 = nil }; var arg_4053 any = sm__10; var arg_4054 any = A_arbace_go_check_A_const_371; if linked_4051 == nil { na_4049 = ifn_4052.Invoke_O_O__O(arg_4053, arg_4054) } else { na_4049 = linked_4051.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4050, arg_4053, arg_4054) }; if jrt.Long_InstanceOf(na_4049) { var n0_4055 int64 = jrt.NN(jrt.Long_Cast(na_4049)).LongValue__J(); and__1927000168__auto____17 = n0_4055 == 0 } else { if jrt.Double_InstanceOf(na_4049) { var n0_4055_2 float64 = jrt.NN(jrt.Double_Cast(na_4049)).DoubleValue__D(); and__1927000168__auto____17 = n0_4055_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_4049) } }
//line :653:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_4056 any; var root_4057 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4057, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4059 lang.IFn; if linked_4058 == nil { ifn_4059 = lang.IFn_Cast(root_4057) } else { ifn_4059 = nil }; var arg_4060 any = sm__10; var arg_4061 any = A_arbace_go_check_A_const_372; if linked_4058 == nil { na_4056 = ifn_4059.Invoke_O_O__O(arg_4060, arg_4061) } else { na_4056 = linked_4058.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4057, arg_4060, arg_4061) }; if jrt.Long_InstanceOf(na_4056) { var n0_4062 int64 = jrt.NN(jrt.Long_Cast(na_4056)).LongValue__J(); tmp6 = n0_4062 == 0 } else { if jrt.Double_InstanceOf(na_4056) { var n0_4062_2 float64 = jrt.NN(jrt.Double_Cast(na_4056)).DoubleValue__D(); tmp6 = n0_4062_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_4056) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :653:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_4063 any = /*line :640:1*/A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_4064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4063, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4065 lang.IFn; if















	linked_4064 == nil { ifn_4065 = lang.IFn_Cast(root_4063) } else { ifn_4065 = nil }; var arg_4066 any = ref__13; var arg_4067 any = A_arbace_go_check_A_const_373; if linked_4064 == nil { tmp7 = ifn_4065.Invoke_O_O__O(arg_4066, arg_4067) } else { tmp7 = linked_4064.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4063, arg_4066, arg_4067) }; var tmp8 any = tmp7; var tmp9 any; var root_4068 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_4069 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4068, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4070 lang.IFn; if linked_4069 == nil { ifn_4070 = lang.IFn_Cast(root_4068) } else { ifn_4070 = nil }; var arg_4071 any = sm__10; var arg_4072 any = A_arbace_go_check_A_const_333; if linked_4069 == nil { tmp9 = ifn_4070.Invoke_O_O__O(arg_4071, arg_4072) } else { tmp9 = linked_4069.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4068, arg_4071, arg_4072) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_4081 any =
	A_arbace_go_check_A_const_374.GetRawRoot__O(); var linked_4082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4081, A_arbace_go_check_write_edn_A_fn_class); var ifn_4083 lang.IFn; if linked_4082 == nil { ifn_4083 = lang.IFn_Cast(root_4081) } else { ifn_4083 = nil }; var arg_4084 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_4085 any; var tmp10 any = A_arbace_go_check_A_const_369; var tmp11 any = A_arbace_go_check_A_const_375; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_234; var tmp14 any; var root_4086 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_4087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4086, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4088 lang.IFn; if

	linked_4087 == nil { ifn_4088 = lang.IFn_Cast(root_4086) } else { ifn_4088 = nil }; var arg_4089 any; var root_4090 any = A_arbace_go_check_A_const_376.GetRawRoot__O(); var linked_4091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4090, A_arbace_go_check_report_errors_A_fn_class); var ifn_4092 lang.IFn; if linked_4091 == nil { ifn_4092 = lang.IFn_Cast(root_4090) } else { ifn_4092 = nil }; var arg_4093 any = rs__9; if linked_4091 == nil { arg_4089 = ifn_4092.Invoke_O__O(arg_4093) } else { arg_4089 = linked_4091.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4090, arg_4093) }; if linked_4087 == nil { tmp14 = ifn_4088.Invoke_O__O(arg_4089) } else { tmp14 = linked_4087.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4086, arg_4089) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_165; var tmp17 any; var root_4094 any = /*line :657:1*/A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_4095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4094, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4096 lang.IFn; if


	linked_4095 == nil { ifn_4096 = lang.IFn_Cast(root_4094) } else { ifn_4096 = nil }; var arg_4097 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000486__1685000492_A_New(); var tmp19 *jrt.Class; var fncls__4183 *jrt.Class = A_arbace_go_check_annotations_iter__1685000486__1685000492_A_fn_class; if fncls__4183 == nil { var fncls__4183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_annotations_iter__1685000486__1685000492_A_fn_class = fncls__4183d; tmp19 = fncls__4183d } else { tmp19 = fncls__4183 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_4097 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_4095 == nil { tmp17 = ifn_4096.Invoke_O__O(arg_4097) } else { tmp17 = linked_4095.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4094, arg_4097) }; arg_4085 = /*line :657:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_4082 == nil { ifn_4083.Invoke_O_O__O(arg_4084, arg_4085) } else { linked_4082.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4081, arg_4084, arg_4085) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_231.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_327.Invoke_O__O(sm__10); var tmp23 any; var root_4202 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4202, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4204 lang.IFn; if
	linked_4203 == nil { ifn_4204 = lang.IFn_Cast(root_4202) } else { ifn_4204 = nil }; var arg_4205 any = sm__10; var arg_4206 any = A_arbace_go_check_A_const_378; if linked_4203 == nil { tmp23 = ifn_4204.Invoke_O_O__O(arg_4205, arg_4206) } else { tmp23 = linked_4203.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4202, arg_4205, arg_4206) }; var tmp24 any = tmp23; var tmp25 any; var root_4207 any = /*line :661:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4207, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4209 lang.IFn; if
	linked_4208 == nil { ifn_4209 = lang.IFn_Cast(root_4207) } else { ifn_4209 = nil }; var arg_4210 any = sm__10; var arg_4211 any = A_arbace_go_check_A_const_379; if linked_4208 == nil { tmp25 = ifn_4209.Invoke_O_O__O(arg_4210, arg_4211) } else { tmp25 = linked_4208.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4207, arg_4210, arg_4211) }; var tmp26 any = tmp25; var tmp27 any; var root_4212 any = /*line :661:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4212, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4214 lang.IFn; if

	linked_4213 == nil { ifn_4214 = lang.IFn_Cast(root_4212) } else { ifn_4214 = nil }; var arg_4215 any = sm__10; var arg_4216 any = A_arbace_go_check_A_const_380; if linked_4213 == nil { tmp27 = ifn_4214.Invoke_O_O__O(arg_4215, arg_4216) } else { tmp27 = linked_4213.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4212, arg_4215, arg_4216) }; var tmp28 any = tmp27; var tmp29 any = /*line :661:1*/A_arbace_go_check_A_const_234.Invoke_O__O(sm__10); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()); var tmp31 any; var root_4221 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4221, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4223 lang.IFn; if


	linked_4222 == nil { ifn_4223 = lang.IFn_Cast(root_4221) } else { ifn_4223 = nil }; var arg_4224 any = sm__10; var arg_4225 any = A_arbace_go_check_A_const_381; if linked_4222 == nil { tmp31 = ifn_4223.Invoke_O_O__O(arg_4224, arg_4225) } else { tmp31 = linked_4222.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4221, arg_4224, arg_4225) }; var tmp32 any = /*line :661:1*/tmp30.Invoke_O__O(tmp31); var tmp33 any; var root_4226 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4226, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4228 lang.IFn; if



	linked_4227 == nil { ifn_4228 = lang.IFn_Cast(root_4226) } else { ifn_4228 = nil }; var arg_4229 any = sm__10; var arg_4230 any = A_arbace_go_check_A_const_382; if linked_4227 == nil { tmp33 = ifn_4228.Invoke_O_O__O(arg_4229, arg_4230) } else { tmp33 = linked_4227.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4226, arg_4229, arg_4230) }; var tmp34 any = tmp33; var tmp35 any; var root_4231 any = /*line :661:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4231, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4233 lang.IFn; if



	linked_4232 == nil { ifn_4233 = lang.IFn_Cast(root_4231) } else { ifn_4233 = nil }; var arg_4234 any = sm__10; var arg_4235 any = A_arbace_go_check_A_const_383; if linked_4232 == nil { tmp35 = ifn_4233.Invoke_O_O__O(arg_4234, arg_4235) } else { tmp35 = linked_4232.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4231, arg_4234, arg_4235) }; /*line :661:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_17, corpus__0, tmp22, tmp24, tmp26, tmp28, tmp29, tmp32, tmp34, tmp35, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000502__16 any; var root_4236 any = /*line :640:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4238 lang.IFn; if

























	linked_4237 == nil { ifn_4238 = lang.IFn_Cast(root_4236) } else { ifn_4238 = nil }; var arg_4239 any; var root_4240 any = A_arbace_go_check_A_const_384.GetRawRoot__O(); var linked_4241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4240, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4242 lang.IFn; if linked_4241 == nil { ifn_4242 = lang.IFn_Cast(root_4240) } else { ifn_4242 = nil }; var arg_4243 any = A_arbace_go_check_A_const_385; var arg_4244 any; var root_4245 any = A_arbace_go_check_A_const_376.GetRawRoot__O(); var linked_4246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4245, A_arbace_go_check_report_errors_A_fn_class); var ifn_4247 lang.IFn; if linked_4246 == nil { ifn_4247 = lang.IFn_Cast(root_4245) } else { ifn_4247 = nil }; var arg_4248 any = rs__9; if linked_4246 == nil { arg_4244 = ifn_4247.Invoke_O__O(arg_4248) } else { arg_4244 = linked_4246.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4245, arg_4248) }; if linked_4241 == nil { arg_4239 = ifn_4242.Invoke_O_O__O(arg_4243, arg_4244) } else { arg_4239 = linked_4241.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4240, arg_4243, arg_4244) }; if linked_4237 == nil { seq_1685000502__16 = ifn_4238.Invoke_O__O(arg_4239) } else { seq_1685000502__16 = linked_4237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4236, arg_4239) }; var chunk_1685000503__17 any; var count_1685000504__18 int64 = 0; var i_1685000505__19 int64 = 0; L1:
//line :640:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000505__19, count_1685000504__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000503__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000505__19)); lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__20); seq_1685000502__16, chunk_1685000503__17, count_1685000504__18, i_1685000505__19 = seq_1685000502__16, chunk_1685000503__17, count_1685000504__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000505__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_4249 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4251 lang.IFn; if linked_4250 == nil { ifn_4251 = lang.IFn_Cast(root_4249) } else { ifn_4251 = nil }; var arg_4252 any = seq_1685000502__16; if linked_4250 == nil { temp__1927000414__auto____20 = ifn_4251.Invoke_O__O(arg_4252) } else { temp__1927000414__auto____20 = linked_4250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4249, arg_4252) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000502__21 any = temp__1927000414__auto____20; var tmp36 any; var root_4253 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4253, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4255 lang.IFn; if linked_4254 == nil { ifn_4255 = lang.IFn_Cast(root_4253) } else { ifn_4255 = nil }; var arg_4256 any = seq_1685000502__21; if linked_4254 == nil { tmp36 = ifn_4255.Invoke_O__O(arg_4256) } else { tmp36 = linked_4254.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4253, arg_4256) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____22 any; var root_4257 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4257, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4259 lang.IFn; if linked_4258 == nil { ifn_4259 = lang.IFn_Cast(root_4257) } else { ifn_4259 = nil }; var arg_4260 any = seq_1685000502__21; if linked_4258 == nil { c__1927000678__auto____22 = ifn_4259.Invoke_O__O(arg_4260) } else { c__1927000678__auto____22 = linked_4258.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4257, arg_4260) }; var tmp37 any; var root_4306 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4306, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4308 lang.IFn; if linked_4307 == nil { ifn_4308 = lang.IFn_Cast(root_4306) } else { ifn_4308 = nil }; var arg_4309 any = seq_1685000502__21; if linked_4307 == nil { tmp37 = ifn_4308.Invoke_O__O(arg_4309) } else { tmp37 = linked_4307.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4306, arg_4309) }; seq_1685000502__16, chunk_1685000503__17, count_1685000504__18, i_1685000505__19 = tmp37, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_4261 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4261, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4263 lang.IFn; if linked_4262 == nil { ifn_4263 = lang.IFn_Cast(root_4261) } else { ifn_4263 = nil }; var arg_4264 any = seq_1685000502__21; if linked_4262 == nil { l__22 = ifn_4263.Invoke_O__O(arg_4264) } else { l__22 = linked_4262.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4261, arg_4264) }; lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__22); var tmp38 any; var root_4315 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4315, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4317 lang.IFn; if linked_4316 == nil { ifn_4317 = lang.IFn_Cast(root_4315) } else { ifn_4317 = nil }; var arg_4318 any = seq_1685000502__21; if linked_4316 == nil { tmp38 = ifn_4317.Invoke_O__O(arg_4318) } else { tmp38 = linked_4316.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4315, arg_4318) }; seq_1685000502__16, chunk_1685000503__17, count_1685000504__18, i_1685000505__19 = tmp38, nil, 0, 0; continue L1 } } }
//line :640:1
		break L1 }; var tmp39 any; var root_4265 any =


























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4267 lang.IFn; if linked_4266 == nil { ifn_4267 = lang.IFn_Cast(root_4265) } else { ifn_4267 = nil }; var arg_4268 any; var root_4269 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4269, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4271 lang.IFn; if linked_4270 == nil { ifn_4271 = lang.IFn_Cast(root_4269) } else { ifn_4271 = nil }; var arg_4272 any = sm__10; var arg_4273 any = A_arbace_go_check_A_const_386; if linked_4270 == nil { arg_4268 = ifn_4271.Invoke_O_O__O(arg_4272, arg_4273) } else { arg_4268 = linked_4270.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4269, arg_4272, arg_4273) }; if linked_4266 == nil { tmp39 = ifn_4267.Invoke_O__O(arg_4268) } else { tmp39 = linked_4266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4265, arg_4268) }; if jrt.J2g_Truth(tmp39) {
		var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()); var tmp42 any; var root_4283 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_4284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4283, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4285 lang.IFn; if linked_4284 == nil { ifn_4285 = lang.IFn_Cast(root_4283) } else { ifn_4285 = nil }; var arg_4286 any = sm__10; var arg_4287 any = A_arbace_go_check_A_const_387; if linked_4284 == nil { tmp42 = ifn_4285.Invoke_O_O__O(arg_4286, arg_4287) } else { tmp42 = linked_4284.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4283, arg_4286, arg_4287) }; tmp40.Invoke_O_O__O(Lit_19, tmp41.Invoke_O__O(tmp42)) }; var tmp43 any; var root_4288 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4288, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4290 lang.IFn; if linked_4289 == nil { ifn_4290 = lang.IFn_Cast(root_4288) } else { ifn_4290 = nil }; var arg_4291 any = A_arbace_go_check_A_const_144.Invoke_O__O(sm__10); if linked_4289 == nil { tmp43 = ifn_4290.Invoke_O__O(arg_4291) } else { tmp43 = linked_4289.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4288, arg_4291) }; if jrt.J2g_Truth(tmp43) {
		lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()).Invoke_O_O__O(Lit_20, lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_144.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_4319 any = A_arbace_go_check_A_const_374.GetRawRoot__O(); var linked_4320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4319, A_arbace_go_check_write_edn_A_fn_class); var ifn_4321 lang.IFn; if linked_4320 == nil { ifn_4321 = lang.IFn_Cast(root_4319) } else { ifn_4321 = nil }; var arg_4322 any; var root_4324 any = A_arbace_go_check_A_const_366.GetRawRoot__O(); var linked_4325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4324, A_arbace_go_check_reference_path_A_fn_class); var ifn_4326 lang.IFn; if linked_4325 == nil { ifn_4326 = lang.IFn_Cast(root_4324) } else { ifn_4326 = nil }; var arg_4327 any = corpus__0; if linked_4325 == nil { arg_4322 = ifn_4326.Invoke_O__O(arg_4327) } else { arg_4322 = linked_4325.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4324, arg_4327) }; var arg_4323 any; var root_4328 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4328, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4330 lang.IFn; if linked_4329 == nil { ifn_4330 = lang.IFn_Cast(root_4328) } else { ifn_4330 = nil }; var arg_4331 any; var root_4334 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_4335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4334, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4336 lang.IFn; if linked_4335 == nil { ifn_4336 = lang.IFn_Cast(root_4334) } else { ifn_4336 = nil }; var arg_4337 any = sm__10; var arg_4338 any = A_arbace_go_check_A_const_333; if linked_4335 == nil { arg_4331 = ifn_4336.Invoke_O_O__O(arg_4337, arg_4338) } else { arg_4331 = linked_4335.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4334, arg_4337, arg_4338) }; var arg_4332 any = A_arbace_go_check_A_const_373; var arg_4333 any = Lit_21; if linked_4329 == nil { arg_4323 = ifn_4330.Invoke_O_O_O__O(arg_4331, arg_4332, arg_4333) } else { arg_4323 = linked_4329.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4328, arg_4331, arg_4332, arg_4333) }; if linked_4320 == nil { ifn_4321.Invoke_O_O__O(arg_4322, arg_4323) } else { linked_4320.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4319, arg_4322, arg_4323) }
		var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp45 any; var root_4344 any = A_arbace_go_check_A_const_366.GetRawRoot__O(); var linked_4345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4344, A_arbace_go_check_reference_path_A_fn_class); var ifn_4346 lang.IFn; if linked_4345 == nil { ifn_4346 = lang.IFn_Cast(root_4344) } else { ifn_4346 = nil }; var arg_4347 any = corpus__0; if linked_4345 == nil { tmp45 = ifn_4346.Invoke_O__O(arg_4347) } else { tmp45 = linked_4345.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4344, arg_4347) }; tmp44.Invoke_O_O__O(Lit_22, tmp45)
//line :671:1
		return clean__14 } else { var tmp46 any; var root_4073 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4073, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4075 lang.IFn



			if linked_4074 == nil { ifn_4075 = lang.IFn_Cast(root_4073) } else { ifn_4075 = nil }; var arg_4076 any = clean__14; if linked_4074 == nil { tmp46 = ifn_4075.Invoke_O__O(arg_4076) } else { tmp46 = linked_4074.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4073, arg_4076) }
//line :671:1
			if jrt.J2g_Truth(tmp46) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp48 any; var root_4354 any = A_arbace_go_check_A_const_366.GetRawRoot__O(); var linked_4355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4354, A_arbace_go_check_reference_path_A_fn_class); var ifn_4356 lang.IFn; if linked_4355 == nil { ifn_4356 = lang.IFn_Cast(root_4354) } else { ifn_4356 = nil }; var arg_4357 any = corpus__0; if linked_4355 == nil { tmp48 = ifn_4356.Invoke_O__O(arg_4357) } else { tmp48 = linked_4355.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4354, arg_4357) }; tmp47.Invoke_O_O_O__O(Lit_23, tmp48, Lit_24)
//line :671:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp49 any; var root_4077 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4077, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4079 lang.IFn





					if linked_4078 == nil { ifn_4079 = lang.IFn_Cast(root_4077) } else { ifn_4079 = nil }; var arg_4080 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_4078 == nil { tmp49 = ifn_4079.Invoke_O__O(arg_4080) } else { tmp49 = linked_4078.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4077, arg_4080) }
//line :671:1
					if jrt.J2g_Truth(tmp49) {





						var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp51 any; var root_4364 any = A_arbace_go_check_A_const_366.GetRawRoot__O(); var linked_4365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4364, A_arbace_go_check_reference_path_A_fn_class); var ifn_4366 lang.IFn; if linked_4365 == nil { ifn_4366 = lang.IFn_Cast(root_4364) } else { ifn_4366 = nil }; var arg_4367 any = corpus__0; if linked_4365 == nil { tmp51 = ifn_4366.Invoke_O__O(arg_4367) } else { tmp51 = linked_4365.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4364, arg_4367) }; tmp50.Invoke_O_O_O__O(Lit_25, tmp51, Lit_26)
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()); var tmp54 any; var root_4377 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_4378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4377, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4379 lang.IFn; if linked_4378 == nil { ifn_4379 = lang.IFn_Cast(root_4377) } else { ifn_4379 = nil }; var arg_4380 any = ref__13; var arg_4381 any = A_arbace_go_check_A_const_373; if linked_4378 == nil { tmp54 = ifn_4379.Invoke_O_O__O(arg_4380, arg_4381) } else { tmp54 = linked_4378.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4377, arg_4380, arg_4381) }; tmp52.Invoke_O_O__O(Lit_27, tmp53.Invoke_O__O(tmp54))
						var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_232.GetRawRoot__O()); var tmp57 any; var root_4391 any = A_arbace_go_check_A_const_253.GetRawRoot__O(); var linked_4392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4391, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4393 lang.IFn; if linked_4392 == nil { ifn_4393 = lang.IFn_Cast(root_4391) } else { ifn_4393 = nil }; var arg_4394 any = sm__10; var arg_4395 any = A_arbace_go_check_A_const_333; if linked_4392 == nil { tmp57 = ifn_4393.Invoke_O_O__O(arg_4394, arg_4395) } else { tmp57 = linked_4392.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4391, arg_4394, arg_4395) }; tmp55.Invoke_O_O__O(Lit_28, tmp56.Invoke_O__O(tmp57))
//line :671:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :660:1
func A_arbace_go_check_annotations_iter__1685000486__1685000492_A_New() *A_arbace_go_check_annotations_iter__1685000486__1685000492_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000486__1685000492_A{}; t.Ctor(); return t }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_A) Ctor() {}
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_A) Invoke_O_O__O(self, s__1685000487__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A_New_O_O(s__1685000487__1, self); var tmp2 *jrt.Class; var fncls__4182 *jrt.Class = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A_fn_class; if fncls__4182 == nil { var fncls__4182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A_fn_class = fncls__4182d; tmp2 = fncls__4182d } else { tmp2 = fncls__4182 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :660:1
func A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A{}; t.Ctor_O_O(p0, p1); return t }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A) Ctor_O_O(c__s__1685000487, c__iter__1685000486 any) { t.F_s__1685000487 = c__s__1685000487; t.F_iter__1685000486 = c__iter__1685000486 }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A) Invoke_O__O(self any) any { { var s__1685000487__1 any; var t_ any = t.F_s__1685000487; t.F_s__1685000487 = nil; s__1685000487__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4098 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4098, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4100 lang.IFn; if linked_4099 == nil { ifn_4100 = lang.IFn_Cast(root_4098) } else { ifn_4100 = nil }; var arg_4101 any = s__1685000487__1; if linked_4099 == nil { temp__1927000414__auto____2 = ifn_4100.Invoke_O__O(arg_4101) } else { temp__1927000414__auto____2 = linked_4099.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4098, arg_4101) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_4102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4104 lang.IFn; if linked_4103 == nil { ifn_4104 = lang.IFn_Cast(root_4102) } else { ifn_4104 = nil }; var arg_4105 any = xs__1927001018__auto____3; if linked_4103 == nil { r__4 = ifn_4104.Invoke_O__O(arg_4105) } else { r__4 = linked_4103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4102, arg_4105) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__4164 *jrt.Class = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A_fn_class; if fncls__4164 == nil { var fncls__4164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A_fn_class = fncls__4164d; tmp2 = fncls__4164d } else { tmp2 = fncls__4164 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_4165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4167 lang.IFn; if linked_4166 == nil { ifn_4167 = lang.IFn_Cast(root_4165) } else { ifn_4167 = nil }; var arg_4168 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_166.Invoke_O__O(r__4)); if linked_4166 == nil { fs__1927001036__auto____6 = ifn_4167.Invoke_O__O(arg_4168) } else { fs__1927001036__auto____6 = linked_4166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4165, arg_4168) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_4169 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_4170 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4169, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4171 lang.IFn; if linked_4170 == nil { ifn_4171 = lang.IFn_Cast(root_4169) } else { ifn_4171 = nil }; var arg_4172 any = fs__1927001036__auto____6; var arg_4173 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000486); var tmp4 any; var root_4174 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4174, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4176 lang.IFn; if linked_4175 == nil { ifn_4176 = lang.IFn_Cast(root_4174) } else { ifn_4176 = nil }; var arg_4177 any = s__1685000487__1; if linked_4175 == nil { tmp4 = ifn_4176.Invoke_O__O(arg_4177) } else { tmp4 = linked_4175.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4174, arg_4177) }; arg_4173 = tmp3.Invoke_O__O(tmp4); if linked_4170 == nil { return ifn_4171.Invoke_O_O__O(arg_4172, arg_4173) } else { return linked_4170.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4169, arg_4172, arg_4173) } } else { var tmp5 any; var root_4178 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4178, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4180 lang.IFn; if linked_4179 == nil { ifn_4180 = lang.IFn_Cast(root_4178) } else { ifn_4180 = nil }; var arg_4181 any = s__1685000487__1; if linked_4179 == nil { tmp5 = ifn_4180.Invoke_O__O(arg_4181) } else { tmp5 = linked_4179.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4178, arg_4181) }; s__1685000487__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :660:1
func A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A{}; t.Ctor_O(p0); return t }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A) Invoke_O_O__O(self, s__1685000489__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A_New_O_O_O(t.F_r, s__1685000489__1, self); var tmp2 *jrt.Class; var fncls__4163 *jrt.Class = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A_fn_class; if fncls__4163 == nil { var fncls__4163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A_fn_class = fncls__4163d; tmp2 = fncls__4163d } else { tmp2 = fncls__4163 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :660:1
func A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A) Ctor_O_O_O(c__r, c__s__1685000489, c__iter__1685000488 any) { t.F_r = c__r; t.F_s__1685000489 = c__s__1685000489; t.F_iter__1685000488 = c__iter__1685000488 }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A) Invoke_O__O(self any) any { { var s__1685000489__1 any; var t_ any = t.F_s__1685000489; t.F_s__1685000489 = nil; s__1685000489__1 = t_; for { var temp__1927000414__auto____2 any; var root_4106 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4106, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4108 lang.IFn; if linked_4107 == nil { ifn_4108 = lang.IFn_Cast(root_4106) } else { ifn_4108 = nil }; var arg_4109 any = s__1685000489__1; if linked_4107 == nil { temp__1927000414__auto____2 = ifn_4108.Invoke_O__O(arg_4109) } else { temp__1927000414__auto____2 = linked_4107.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4106, arg_4109) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000489__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4110 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4110, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4112 lang.IFn; if linked_4111 == nil { ifn_4112 = lang.IFn_Cast(root_4110) } else { ifn_4112 = nil }; var arg_4113 any = s__1685000489__3; if linked_4111 == nil { tmp1 = ifn_4112.Invoke_O__O(arg_4113) } else { tmp1 = linked_4111.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4110, arg_4113) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4114 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4114, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4116 lang.IFn; if linked_4115 == nil { ifn_4116 = lang.IFn_Cast(root_4114) } else { ifn_4116 = nil }; var arg_4117 any = s__1685000489__3; if linked_4115 == nil { c__1927001037__auto____4 = ifn_4116.Invoke_O__O(arg_4117) } else { c__1927001037__auto____4 = linked_4115.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4114, arg_4117) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000491__6 any; var root_4118 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_4119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4118, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4120 lang.IFn; if linked_4119 == nil { ifn_4120 = lang.IFn_Cast(root_4118) } else { ifn_4120 = nil }; var arg_4121 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4119 == nil { b__1685000491__6 = ifn_4120.Invoke_O__O(arg_4121) } else { b__1685000491__6 = linked_4119.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4118, arg_4121) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A_New_O_O_I_O(t.F_r, b__1685000491__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4127 *jrt.Class = A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A_fn_class; if fncls__4127 == nil { var fncls__4127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A_fn_class = fncls__4127d; tmp3 = fncls__4127d } else { tmp3 = fncls__4127 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4128 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4128, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4130 lang.IFn; if linked_4129 == nil { ifn_4130 = lang.IFn_Cast(root_4128) } else { ifn_4130 = nil }; var arg_4131 any; var root_4133 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4133, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4135 lang.IFn; if linked_4134 == nil { ifn_4135 = lang.IFn_Cast(root_4133) } else { ifn_4135 = nil }; var arg_4136 any = b__1685000491__6; if linked_4134 == nil { arg_4131 = ifn_4135.Invoke_O__O(arg_4136) } else { arg_4131 = linked_4134.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4133, arg_4136) }; var arg_4132 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000488); var tmp5 any; var root_4137 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4137, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4139 lang.IFn; if linked_4138 == nil { ifn_4139 = lang.IFn_Cast(root_4137) } else { ifn_4139 = nil }; var arg_4140 any = s__1685000489__3; if linked_4138 == nil { tmp5 = ifn_4139.Invoke_O__O(arg_4140) } else { tmp5 = linked_4138.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4137, arg_4140) }; arg_4132 = tmp4.Invoke_O__O(tmp5); if linked_4129 == nil { return ifn_4130.Invoke_O_O__O(arg_4131, arg_4132) } else { return linked_4129.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4128, arg_4131, arg_4132) } } else { var root_4141 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4141, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4143 lang.IFn; if linked_4142 == nil { ifn_4143 = lang.IFn_Cast(root_4141) } else { ifn_4143 = nil }; var arg_4144 any; var root_4146 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4146, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4148 lang.IFn; if linked_4147 == nil { ifn_4148 = lang.IFn_Cast(root_4146) } else { ifn_4148 = nil }; var arg_4149 any = b__1685000491__6; if linked_4147 == nil { arg_4144 = ifn_4148.Invoke_O__O(arg_4149) } else { arg_4144 = linked_4147.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4146, arg_4149) }; var arg_4145 any; if linked_4142 == nil { return ifn_4143.Invoke_O_O__O(arg_4144, arg_4145) } else { return linked_4142.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4141, arg_4144, arg_4145) } } } else { var u__4 any; var root_4150 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4150, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4152 lang.IFn; if linked_4151 == nil { ifn_4152 = lang.IFn_Cast(root_4150) } else { ifn_4152 = nil }; var arg_4153 any = s__1685000489__3; if linked_4151 == nil { u__4 = ifn_4152.Invoke_O__O(arg_4153) } else { u__4 = linked_4151.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4150, arg_4153) }; var root_4154 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4154, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4156 lang.IFn; if linked_4155 == nil { ifn_4156 = lang.IFn_Cast(root_4154) } else { ifn_4156 = nil }; var arg_4157 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), u__4); var arg_4158 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000488); var tmp7 any; var root_4159 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4159, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4161 lang.IFn; if linked_4160 == nil { ifn_4161 = lang.IFn_Cast(root_4159) } else { ifn_4161 = nil }; var arg_4162 any = s__1685000489__3; if linked_4160 == nil { tmp7 = ifn_4161.Invoke_O__O(arg_4162) } else { tmp7 = linked_4160.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4159, arg_4162) }; arg_4158 = tmp6.Invoke_O__O(tmp7); if linked_4155 == nil { return ifn_4156.Invoke_O_O__O(arg_4157, arg_4158) } else { return linked_4155.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4154, arg_4157, arg_4158) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :660:1
func A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A) Ctor_O_O_I_O(c__r, c__b__1685000491 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_r = c__r; t.F_b__1685000491 = c__b__1685000491; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :660:1
func (t *A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A) Invoke_O__O(self any) any { { var i__1685000490__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000490__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000490__1)); var root_4122 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4122, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4124 lang.IFn; if linked_4123 == nil { ifn_4124 = lang.IFn_Cast(root_4122) } else { ifn_4124 = nil }; var arg_4125 any = t.F_b__1685000491; var arg_4126 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_110.Invoke_O__O(t.F_r), u__2); if linked_4123 == nil { ifn_4124.Invoke_O_O__O(arg_4125, arg_4126) } else { linked_4123.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4122, arg_4125, arg_4126) }; i__1685000490__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000490__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :683:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :683:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000507__2 any = args__0; var seq__1685000508__3 any; var root_4396 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4396, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4398 lang.IFn; if


	linked_4397 == nil { ifn_4398 = lang.IFn_Cast(root_4396) } else { ifn_4398 = nil }; var arg_4399 any = vec__1685000507__2; if linked_4397 == nil { seq__1685000508__3 = ifn_4398.Invoke_O__O(arg_4399) } else { seq__1685000508__3 = linked_4397.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4396, arg_4399) }; var first__1685000509__4 any; var root_4400 any = /*line :683:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4400, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4402 lang.IFn; if


	linked_4401 == nil { ifn_4402 = lang.IFn_Cast(root_4400) } else { ifn_4402 = nil }; var arg_4403 any = seq__1685000508__3; if linked_4401 == nil { first__1685000509__4 = ifn_4402.Invoke_O__O(arg_4403) } else { first__1685000509__4 = linked_4401.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4400, arg_4403) }; var seq__1685000508__5 any; var root_4404 any = /*line :683:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4404, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4406 lang.IFn; if


	linked_4405 == nil { ifn_4406 = lang.IFn_Cast(root_4404) } else { ifn_4406 = nil }; var arg_4407 any = seq__1685000508__3; if linked_4405 == nil { seq__1685000508__5 = ifn_4406.Invoke_O__O(arg_4407) } else { seq__1685000508__5 = linked_4405.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4404, arg_4407) }; var cmd__6 any = first__1685000509__4; var args__7 any = seq__1685000508__5; var G__1685000510__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000510__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000510__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000511_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4499 /*line :687:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000511_A_fn_class

		if fncls__4499 == nil { var fncls__4499d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000511_A_fn_class = fncls__4499d; tmp2 = fncls__4499d } else { tmp2 = fncls__4499 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :687:1
		var cs__10 any; var tmp3 any; var root_4500 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4500, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4502 lang.IFn











		if linked_4501 == nil { ifn_4502 = lang.IFn_Cast(root_4500) } else { ifn_4502 = nil }; var arg_4503 any = A_arbace_go_check_A_const_389.Invoke_O__O(opts__9); if linked_4501 == nil { tmp3 = ifn_4502.Invoke_O__O(arg_4503) } else { tmp3 = linked_4501.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4500, arg_4503) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_389.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_392.GetRawRoot__O() }
//line :687:1
		var ok__11 any; var root_4586 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4586, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4588 lang.IFn












		if linked_4587 == nil { ifn_4588 = lang.IFn_Cast(root_4586) } else { ifn_4588 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_169.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_281; var tmp6 any = A_arbace_go_check_A_const_163.Invoke_O__O(opts__9); var tmp7 any = A_arbace_go_check_A_const_359; var arg_4589 any = tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, A_arbace_go_check_A_const_391.Invoke_O__O(opts__9)); if linked_4587 == nil { ifn_4588.Invoke_O__O(arg_4589) } else { linked_4587.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4586, arg_4589) }; var tmp8 any = A_arbace_go_check__main_fn__1685000514_A_New_O_O(cs__10, opts__9); var tmp9 *jrt.Class; var fncls__4580 *jrt.Class = A_arbace_go_check__main_fn__1685000514_A_fn_class; if fncls__4580 == nil { var fncls__4580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_fn__1685000514_A_fn_class = fncls__4580d; tmp9 = fncls__4580d } else { tmp9 = fncls__4580 }; ok__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()


		var root_4597 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4597, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4599 lang.IFn; if linked_4598 == nil { ifn_4599 = lang.IFn_Cast(root_4597) } else { ifn_4599 = nil }; if linked_4598 == nil { ifn_4599.Invoke__O() } else { linked_4598.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4597) }
		var tmp10 int64; var tmp11 any; var root_4581 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4581, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4583 lang.IFn; if linked_4582 == nil { ifn_4583 = lang.IFn_Cast(root_4581) } else { ifn_4583 = nil }; var arg_4584 any = A_arbace_go_check_A_const_395.GetRawRoot__O(); var arg_4585 any = ok__11; if linked_4582 == nil { tmp11 = ifn_4583.Invoke_O_O__O(arg_4584, arg_4585) } else { tmp11 = linked_4582.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4581, arg_4584, arg_4585) }; if jrt.J2g_Truth(tmp11) { tmp10 = 0 } else { tmp10 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp10)); return nil }
//line :687:1
	default:};

















	lang.IFn_Cast(A_arbace_go_check_A_const_377.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :689:1
func A_arbace_go_check__main_fn__1685000511_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000511_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000511_A{}; t.Ctor_O(p0); return t }
//line :689:1
func (t *A_arbace_go_check__main_fn__1685000511_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :689:1
func (t *A_arbace_go_check__main_fn__1685000511_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_360; var tmp2 any = A_arbace_go_check_A_const_388; var tmp3 any = A_arbace_go_check_A_const_362; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_292.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_389, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_4409 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_4410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4409, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4411 lang.IFn; if linked_4410 == nil { ifn_4411 = lang.IFn_Cast(root_4409) } else { ifn_4411 = nil }; var arg_4412 any = as__1; if linked_4410 == nil { tmp4 = ifn_4411.Invoke_O__O(arg_4412) } else { tmp4 = linked_4410.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4409, arg_4412) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000512__3_ any; var root_4413 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4413, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4415 lang.IFn

		if linked_4414 == nil { ifn_4415 = lang.IFn_Cast(root_4413) } else { ifn_4415 = nil }; var arg_4416 any = as__1; if linked_4414 == nil { G__1685000512__3_ = ifn_4415.Invoke_O__O(arg_4416) } else { G__1685000512__3_ = linked_4414.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4413, arg_4416) }; switch lang.Util_Hash_O__I_NoInit(G__1685000512__3_) >> 10 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000512__3_, Lit_6) {



			var tmp5 any; var root_4418 any = A_arbace_go_check_A_const_390.GetRawRoot__O(); var linked_4419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4418, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4420 lang.IFn; if linked_4419 == nil { ifn_4420 = lang.IFn_Cast(root_4418) } else { ifn_4420 = nil }; var arg_4421 any = as__1; if linked_4419 == nil { tmp5 = ifn_4420.Invoke_O__O(arg_4421) } else { tmp5 = linked_4419.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4418, arg_4421) }; var tmp6 any = tmp5; var tmp7 any; var root_4422 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4422, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4424 lang.IFn; if linked_4423 == nil { ifn_4424 = lang.IFn_Cast(root_4422) } else { ifn_4424 = nil }; var arg_4425 any = o__2; var arg_4426 any = A_arbace_go_check_A_const_163; var arg_4427 any; var root_4428 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_4429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4428, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4430 lang.IFn; if linked_4429 == nil { ifn_4430 = lang.IFn_Cast(root_4428) } else { ifn_4430 = nil }; var arg_4431 any = as__1; if linked_4429 == nil { arg_4427 = ifn_4430.Invoke_O__O(arg_4431) } else { arg_4427 = linked_4429.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4428, arg_4431) }; if linked_4423 == nil { tmp7 = ifn_4424.Invoke_O_O_O__O(arg_4425, arg_4426, arg_4427) } else { tmp7 = linked_4423.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4422, arg_4425, arg_4426, arg_4427) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :692:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000512__3_, Lit_7) {




			var tmp8 any; var root_4432 any = A_arbace_go_check_A_const_390.GetRawRoot__O(); var linked_4433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4432, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4434 lang.IFn; if linked_4433 == nil { ifn_4434 = lang.IFn_Cast(root_4432) } else { ifn_4434 = nil }; var arg_4435 any = as__1; if linked_4433 == nil { tmp8 = ifn_4434.Invoke_O__O(arg_4435) } else { tmp8 = linked_4433.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4432, arg_4435) }; var tmp9 any = tmp8; var tmp10 any; var root_4436 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4436, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4438 lang.IFn; if linked_4437 == nil { ifn_4438 = lang.IFn_Cast(root_4436) } else { ifn_4438 = nil }; var arg_4439 any = o__2; var arg_4440 any = A_arbace_go_check_A_const_391; var arg_4441 any; var root_4442 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_4443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4442, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4444 lang.IFn; if linked_4443 == nil { ifn_4444 = lang.IFn_Cast(root_4442) } else { ifn_4444 = nil }; var arg_4445 any = as__1; if linked_4443 == nil { arg_4441 = ifn_4444.Invoke_O__O(arg_4445) } else { arg_4441 = linked_4443.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4442, arg_4445) }; if linked_4437 == nil { tmp10 = ifn_4438.Invoke_O_O_O__O(arg_4439, arg_4440, arg_4441) } else { tmp10 = linked_4437.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4436, arg_4439, arg_4440, arg_4441) }; as__1, o__2 = tmp9, tmp10; continue L1 }
//line :692:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000512__3_, Lit_8) {

			var tmp11 any; var root_4446 any = A_arbace_go_check_A_const_390.GetRawRoot__O(); var linked_4447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4446, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4448 lang.IFn; if linked_4447 == nil { ifn_4448 = lang.IFn_Cast(root_4446) } else { ifn_4448 = nil }; var arg_4449 any = as__1; if linked_4447 == nil { tmp11 = ifn_4448.Invoke_O__O(arg_4449) } else { tmp11 = linked_4447.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4446, arg_4449) }; var tmp12 any = tmp11; var tmp13 any; var root_4450 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4450, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4452 lang.IFn; if linked_4451 == nil { ifn_4452 = lang.IFn_Cast(root_4450) } else { ifn_4452 = nil }; var arg_4453 any = o__2; var arg_4454 any = A_arbace_go_check_A_const_360; var arg_4455 any; var tmp14 any; var root_4456 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_4457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4456, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4458 lang.IFn; if linked_4457 == nil { ifn_4458 = lang.IFn_Cast(root_4456) } else { ifn_4458 = nil }; var arg_4459 any = as__1; if linked_4457 == nil { tmp14 = ifn_4458.Invoke_O__O(arg_4459) } else { tmp14 = linked_4457.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4456, arg_4459) }; arg_4455 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp14))).Ref(); if linked_4451 == nil { tmp13 = ifn_4452.Invoke_O_O_O__O(arg_4453, arg_4454, arg_4455) } else { tmp13 = linked_4451.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4450, arg_4453, arg_4454, arg_4455) }; as__1, o__2 = tmp12, tmp13; continue L1 }
//line :692:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000512__3_, Lit_9) {
			var tmp15 any; var root_4460 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4460, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4462 lang.IFn; if linked_4461 == nil { ifn_4462 = lang.IFn_Cast(root_4460) } else { ifn_4462 = nil }; var arg_4463 any = as__1; if linked_4461 == nil { tmp15 = ifn_4462.Invoke_O__O(arg_4463) } else { tmp15 = linked_4461.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4460, arg_4463) }; var tmp16 any = tmp15; var tmp17 any; var root_4464 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4464, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4466 lang.IFn; if linked_4465 == nil { ifn_4466 = lang.IFn_Cast(root_4464) } else { ifn_4466 = nil }; var arg_4467 any = o__2; var arg_4468 any = A_arbace_go_check_A_const_361; var arg_4469 any = jrt.Boolean_TRUE.Ref(); if linked_4465 == nil { tmp17 = ifn_4466.Invoke_O_O_O__O(arg_4467, arg_4468, arg_4469) } else { tmp17 = linked_4465.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4464, arg_4467, arg_4468, arg_4469) }; as__1, o__2 = tmp16, tmp17; continue L1 }
//line :692:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000512__3_, Lit_10) {


			var tmp18 any; var root_4470 any = A_arbace_go_check_A_const_390.GetRawRoot__O(); var linked_4471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4470, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4472 lang.IFn; if linked_4471 == nil { ifn_4472 = lang.IFn_Cast(root_4470) } else { ifn_4472 = nil }; var arg_4473 any = as__1; if linked_4471 == nil { tmp18 = ifn_4472.Invoke_O__O(arg_4473) } else { tmp18 = linked_4471.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4470, arg_4473) }; var tmp19 any = tmp18; var tmp20 any; var root_4474 any = A_arbace_go_check_A_const_105.GetRawRoot__O(); var linked_4475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4474, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4476 lang.IFn; if linked_4475 == nil { ifn_4476 = lang.IFn_Cast(root_4474) } else { ifn_4476 = nil }; var arg_4477 any = o__2; var arg_4478 any = A_arbace_go_check_A_const_362; var arg_4479 any; var root_4480 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_4481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4480, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4482 lang.IFn; if linked_4481 == nil { ifn_4482 = lang.IFn_Cast(root_4480) } else { ifn_4482 = nil }; var arg_4483 any = as__1; if linked_4481 == nil { arg_4479 = ifn_4482.Invoke_O__O(arg_4483) } else { arg_4479 = linked_4481.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4480, arg_4483) }; if linked_4475 == nil { tmp20 = ifn_4476.Invoke_O_O_O__O(arg_4477, arg_4478, arg_4479) } else { tmp20 = linked_4475.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4474, arg_4477, arg_4478, arg_4479) }; as__1, o__2 = tmp19, tmp20; continue L1 }
//line :692:1
		default:
		}




		var tmp21 any; var root_4484 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4484, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4486 lang.IFn; if linked_4485 == nil { ifn_4486 = lang.IFn_Cast(root_4484) } else { ifn_4486 = nil }; var arg_4487 any = as__1; if linked_4485 == nil { tmp21 = ifn_4486.Invoke_O__O(arg_4487) } else { tmp21 = linked_4485.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4484, arg_4487) }; var tmp22 any = tmp21; var tmp23 any; var root_4488 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4488, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4490 lang.IFn; if linked_4489 == nil { ifn_4490 = lang.IFn_Cast(root_4488) } else { ifn_4490 = nil }; var arg_4491 any = o__2; var arg_4492 any = A_arbace_go_check_A_const_389; var arg_4493 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4494 any; var root_4495 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4495, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4497 lang.IFn; if linked_4496 == nil { ifn_4497 = lang.IFn_Cast(root_4495) } else { ifn_4497 = nil }; var arg_4498 any = as__1; if linked_4496 == nil { arg_4494 = ifn_4497.Invoke_O__O(arg_4498) } else { arg_4494 = linked_4496.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4495, arg_4498) }; if linked_4489 == nil { tmp23 = ifn_4490.Invoke_O_O_O_O__O(arg_4491, arg_4492, arg_4493, arg_4494) } else { tmp23 = linked_4489.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4488, arg_4491, arg_4492, arg_4493, arg_4494) }; as__1, o__2 = tmp22, tmp23; continue L1 } } }; /*line :689:1*/panic("j2g: unreachable") }










func A_arbace_go_check__main_fn__1685000514_A_New_O_O(p0, p1 any) *A_arbace_go_check__main_fn__1685000514_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000514_A{}; t.Ctor_O_O(p0, p1); return t }
//line :700:1
func (t *A_arbace_go_check__main_fn__1685000514_A) Ctor_O_O(c__cs, c__opts any) { t.F_cs = c__cs; t.F_opts = c__opts }
//line :700:1
func (t *A_arbace_go_check__main_fn__1685000514_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_4504 any = A_arbace_go_check_A_const_302.GetRawRoot__O(); var linked_4505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4504, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4506 lang.IFn; if linked_4505 == nil { ifn_4506 = lang.IFn_Cast(root_4504) } else { ifn_4506 = nil }; var arg_4507 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A_New_O(t.F_opts); var tmp3 *jrt.Class; var fncls__4576 *jrt.Class = A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A_fn_class; if fncls__4576 == nil { var fncls__4576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A_fn_class = fncls__4576d; tmp3 = fncls__4576d } else { tmp3 = fncls__4576 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var t_ any = t.F_cs; t.F_cs = nil; tmp5 = t_; arg_4507 = tmp4.Invoke_O__O(tmp5); if linked_4505 == nil { tmp1 = ifn_4506.Invoke_O__O(arg_4507) } else { tmp1 = linked_4505.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4504, arg_4507) } }
//line :700:1
	return nil }(); var root_4577 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var linked_4578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4577, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4579 lang.IFn; if linked_4578 == nil { ifn_4579 = lang.IFn_Cast(root_4577) } else { ifn_4579 = nil }; if linked_4578 == nil { ifn_4579.Invoke__O() } else { linked_4578.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4577) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }

func A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A{}; t.Ctor_O(p0); return t }
//line :702:1
func (t *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :702:1
func (t *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A) Invoke_O_O__O(self, s__1685000516__1 any) any { var tmp1 any = A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A_New_O_O_O(self, t.F_opts, s__1685000516__1); var tmp2 *jrt.Class; var fncls__4575 *jrt.Class = A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A_fn_class; if fncls__4575 == nil { var fncls__4575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A_fn_class = fncls__4575d; tmp2 = fncls__4575d } else { tmp2 = fncls__4575 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :702:1
func A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :702:1
func (t *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A) Ctor_O_O_O(c__iter__1685000515, c__opts, c__s__1685000516 any) { t.F_iter__1685000515 = c__iter__1685000515; t.F_opts = c__opts; t.F_s__1685000516 = c__s__1685000516 }
//line :702:1
func (t *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A) Invoke_O__O(self any) any { { var s__1685000516__1 any; var t_ any = t.F_s__1685000516; t.F_s__1685000516 = nil; s__1685000516__1 = t_; for { var temp__1927000414__auto____2 any; var root_4508 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4508, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4510 lang.IFn; if linked_4509 == nil { ifn_4510 = lang.IFn_Cast(root_4508) } else { ifn_4510 = nil }; var arg_4511 any = s__1685000516__1; if linked_4509 == nil { temp__1927000414__auto____2 = ifn_4510.Invoke_O__O(arg_4511) } else { temp__1927000414__auto____2 = linked_4509.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4508, arg_4511) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000516__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4512 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4512, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4514 lang.IFn; if linked_4513 == nil { ifn_4514 = lang.IFn_Cast(root_4512) } else { ifn_4514 = nil }; var arg_4515 any = s__1685000516__3; if linked_4513 == nil { tmp1 = ifn_4514.Invoke_O__O(arg_4515) } else { tmp1 = linked_4513.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4512, arg_4515) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4516 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4516, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4518 lang.IFn; if linked_4517 == nil { ifn_4518 = lang.IFn_Cast(root_4516) } else { ifn_4518 = nil }; var arg_4519 any = s__1685000516__3; if linked_4517 == nil { c__1927001037__auto____4 = ifn_4518.Invoke_O__O(arg_4519) } else { c__1927001037__auto____4 = linked_4517.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4516, arg_4519) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000518__6 any; var root_4520 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_4521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4520, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4522 lang.IFn; if linked_4521 == nil { ifn_4522 = lang.IFn_Cast(root_4520) } else { ifn_4522 = nil }; var arg_4523 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4521 == nil { b__1685000518__6 = ifn_4522.Invoke_O__O(arg_4523) } else { b__1685000518__6 = linked_4521.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4520, arg_4523) }; var tmp2 any = A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A_New_O_O_I_O(b__1685000518__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4534 *jrt.Class = A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A_fn_class; if fncls__4534 == nil { var fncls__4534d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A_fn_class = fncls__4534d; tmp3 = fncls__4534d } else { tmp3 = fncls__4534 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4535 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4535, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4537 lang.IFn; if linked_4536 == nil { ifn_4537 = lang.IFn_Cast(root_4535) } else { ifn_4537 = nil }; var arg_4538 any; var root_4540 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4540, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4542 lang.IFn; if linked_4541 == nil { ifn_4542 = lang.IFn_Cast(root_4540) } else { ifn_4542 = nil }; var arg_4543 any = b__1685000518__6; if linked_4541 == nil { arg_4538 = ifn_4542.Invoke_O__O(arg_4543) } else { arg_4538 = linked_4541.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4540, arg_4543) }; var arg_4539 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000515); var tmp5 any; var root_4544 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4544, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4546 lang.IFn; if linked_4545 == nil { ifn_4546 = lang.IFn_Cast(root_4544) } else { ifn_4546 = nil }; var arg_4547 any = s__1685000516__3; if linked_4545 == nil { tmp5 = ifn_4546.Invoke_O__O(arg_4547) } else { tmp5 = linked_4545.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4544, arg_4547) }; arg_4539 = tmp4.Invoke_O__O(tmp5); if linked_4536 == nil { return ifn_4537.Invoke_O_O__O(arg_4538, arg_4539) } else { return linked_4536.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4535, arg_4538, arg_4539) } } else { var root_4548 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4548, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4550 lang.IFn; if linked_4549 == nil { ifn_4550 = lang.IFn_Cast(root_4548) } else { ifn_4550 = nil }; var arg_4551 any; var root_4553 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4553, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4555 lang.IFn; if linked_4554 == nil { ifn_4555 = lang.IFn_Cast(root_4553) } else { ifn_4555 = nil }; var arg_4556 any = b__1685000518__6; if linked_4554 == nil { arg_4551 = ifn_4555.Invoke_O__O(arg_4556) } else { arg_4551 = linked_4554.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4553, arg_4556) }; var arg_4552 any; if linked_4549 == nil { return ifn_4550.Invoke_O_O__O(arg_4551, arg_4552) } else { return linked_4549.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4548, arg_4551, arg_4552) } } } else { var c__4 any; var root_4557 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4559 lang.IFn; if linked_4558 == nil { ifn_4559 = lang.IFn_Cast(root_4557) } else { ifn_4559 = nil }; var arg_4560 any = s__1685000516__3; if linked_4558 == nil { c__4 = ifn_4559.Invoke_O__O(arg_4560) } else { c__4 = linked_4558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4557, arg_4560) }; var root_4561 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4561, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4563 lang.IFn; if linked_4562 == nil { ifn_4563 = lang.IFn_Cast(root_4561) } else { ifn_4563 = nil }; var arg_4564 any; var root_4566 any = A_arbace_go_check_A_const_393.GetRawRoot__O(); var linked_4567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4566, A_arbace_go_check_annotations_A_fn_class); var ifn_4568 lang.IFn; if linked_4567 == nil { ifn_4568 = lang.IFn_Cast(root_4566) } else { ifn_4568 = nil }; var arg_4569 any = c__4; var arg_4570 any = t.F_opts; if linked_4567 == nil { arg_4564 = ifn_4568.Invoke_O_O__O(arg_4569, arg_4570) } else { arg_4564 = linked_4567.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4566, arg_4569, arg_4570) }; var arg_4565 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000515); var tmp7 any; var root_4571 any = A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_4572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4571, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4573 lang.IFn; if linked_4572 == nil { ifn_4573 = lang.IFn_Cast(root_4571) } else { ifn_4573 = nil }; var arg_4574 any = s__1685000516__3; if linked_4572 == nil { tmp7 = ifn_4573.Invoke_O__O(arg_4574) } else { tmp7 = linked_4572.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4571, arg_4574) }; arg_4565 = tmp6.Invoke_O__O(tmp7); if linked_4562 == nil { return ifn_4563.Invoke_O_O__O(arg_4564, arg_4565) } else { return linked_4562.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4561, arg_4564, arg_4565) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :702:1
func A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :702:1
func (t *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A) Ctor_O_O_I_O(c__b__1685000518, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000518 = c__b__1685000518; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :702:1
func (t *A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A) Invoke_O__O(self any) any { { var i__1685000517__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000517__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000517__1)); var root_4524 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4524, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4526 lang.IFn; if linked_4525 == nil { ifn_4526 = lang.IFn_Cast(root_4524) } else { ifn_4526 = nil }; var arg_4527 any = t.F_b__1685000518; var arg_4528 any; var root_4529 any = A_arbace_go_check_A_const_393.GetRawRoot__O(); var linked_4530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4529, A_arbace_go_check_annotations_A_fn_class); var ifn_4531 lang.IFn; if linked_4530 == nil { ifn_4531 = lang.IFn_Cast(root_4529) } else { ifn_4531 = nil }; var arg_4532 any = c__2; var arg_4533 any = t.F_opts; if linked_4530 == nil { arg_4528 = ifn_4531.Invoke_O_O__O(arg_4532, arg_4533) } else { arg_4528 = linked_4530.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4529, arg_4532, arg_4533) }; if linked_4525 == nil { ifn_4526.Invoke_O_O__O(arg_4527, arg_4528) } else { linked_4525.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4524, arg_4527, arg_4528) }; i__1685000517__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000517__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Keyword

var A_arbace_go_check_A_const_55 *lang.Var

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Keyword

var A_arbace_go_check_A_const_61 *lang.Var

var A_arbace_go_check_A_const_62 *lang.Keyword

var A_arbace_go_check_A_const_63 *lang.Var

var A_arbace_go_check_A_const_64 *lang.Keyword

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Var

var A_arbace_go_check_A_const_67 *lang.Keyword

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Var

var A_arbace_go_check_A_const_73 *lang.Keyword

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Var

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 any

var A_arbace_go_check_A_const_78 *lang.Keyword

var A_arbace_go_check_A_const_79 *lang.Var

var A_arbace_go_check_A_const_80 *lang.Keyword

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Var

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Keyword

var A_arbace_go_check_A_const_90 *lang.Var

var A_arbace_go_check_A_const_91 *lang.Keyword

var A_arbace_go_check_A_const_92 *lang.Var

var A_arbace_go_check_A_const_93 *lang.Keyword

var A_arbace_go_check_A_const_94 any

var A_arbace_go_check_A_const_95 *lang.Keyword

var A_arbace_go_check_A_const_96 *lang.Var

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 any

var A_arbace_go_check_A_const_99 *lang.Keyword

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Var

var A_arbace_go_check_A_const_102 *lang.Var

var A_arbace_go_check_A_const_103 *lang.Var

var A_arbace_go_check_A_const_104 *lang.Var

var A_arbace_go_check_A_const_105 *lang.Var

var A_arbace_go_check_A_const_106 *lang.Keyword

var A_arbace_go_check_A_const_107 *lang.Var

var A_arbace_go_check_A_const_108 *lang.Keyword

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Keyword

var A_arbace_go_check_A_const_113 *lang.Var

var A_arbace_go_check_A_const_114 *lang.Keyword

var A_arbace_go_check_A_const_115 *lang.Keyword

var A_arbace_go_check_A_const_116 *lang.Keyword

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Keyword

var A_arbace_go_check_A_const_119 *lang.Keyword

var A_arbace_go_check_A_const_120 *lang.Keyword

var A_arbace_go_check_A_const_121 *lang.Keyword

var A_arbace_go_check_A_const_122 *lang.Var

var A_arbace_go_check_A_const_123 *lang.Var

var A_arbace_go_check_A_const_124 *lang.Keyword

var A_arbace_go_check_A_const_125 *lang.Var

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Keyword

var A_arbace_go_check_A_const_128 *lang.Var

var A_arbace_go_check_A_const_129 *lang.Var

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 any

var A_arbace_go_check_A_const_133 *lang.Var

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 any

var A_arbace_go_check_A_const_137 any

var A_arbace_go_check_A_const_138 *lang.Var

var A_arbace_go_check_A_const_139 *lang.Keyword

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 any

var A_arbace_go_check_A_const_142 *lang.Var

var A_arbace_go_check_A_const_143 *lang.Var

var A_arbace_go_check_A_const_144 *lang.Keyword

var A_arbace_go_check_A_const_145 *lang.Keyword

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Keyword

var A_arbace_go_check_A_const_150 *lang.Var

var A_arbace_go_check_A_const_151 *lang.Var

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Var

var A_arbace_go_check_A_const_154 *lang.Keyword

var A_arbace_go_check_A_const_155 *lang.Keyword

var A_arbace_go_check_A_const_156 *lang.Keyword

var A_arbace_go_check_A_const_157 *lang.Var

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Keyword

var A_arbace_go_check_A_const_164 *lang.Keyword

var A_arbace_go_check_A_const_165 *lang.Keyword

var A_arbace_go_check_A_const_166 *lang.Keyword

var A_arbace_go_check_A_const_167 *lang.Var

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Var

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Keyword

var A_arbace_go_check_A_const_196 *lang.Keyword

var A_arbace_go_check_A_const_197 *lang.Keyword

var A_arbace_go_check_A_const_198 *lang.Keyword

var A_arbace_go_check_A_const_199 *lang.Var

var A_arbace_go_check_A_const_200 *lang.Var

var A_arbace_go_check_A_const_201 *lang.Var

var A_arbace_go_check_A_const_202 *lang.Var

var A_arbace_go_check_A_const_203 *lang.Var

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Keyword

var A_arbace_go_check_A_const_206 *lang.Var

var A_arbace_go_check_A_const_207 *lang.Keyword

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Var

var A_arbace_go_check_A_const_210 *lang.Keyword

var A_arbace_go_check_A_const_211 *lang.Keyword

var A_arbace_go_check_A_const_212 *lang.Var

var A_arbace_go_check_A_const_213 *lang.Keyword

var A_arbace_go_check_A_const_214 *lang.Var

var A_arbace_go_check_A_const_215 *lang.Var

var A_arbace_go_check_A_const_216 *lang.Var

var A_arbace_go_check_A_const_217 *lang.Var

var A_arbace_go_check_A_const_218 *lang.Keyword

var A_arbace_go_check_A_const_219 *lang.Var

var A_arbace_go_check_A_const_220 *lang.Var

var A_arbace_go_check_A_const_221 *lang.Keyword

var A_arbace_go_check_A_const_222 *lang.Keyword

var A_arbace_go_check_A_const_223 *lang.Keyword

var A_arbace_go_check_A_const_224 *lang.Keyword

var A_arbace_go_check_A_const_225 *lang.Var

var A_arbace_go_check_A_const_226 *lang.Var

var A_arbace_go_check_A_const_227 *lang.Var

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Keyword

var A_arbace_go_check_A_const_230 *lang.Keyword

var A_arbace_go_check_A_const_231 *lang.Var

var A_arbace_go_check_A_const_232 *lang.Var

var A_arbace_go_check_A_const_233 *lang.Keyword

var A_arbace_go_check_A_const_234 *lang.Keyword

var A_arbace_go_check_A_const_235 *lang.Var

var A_arbace_go_check_A_const_236 *lang.Var

var A_arbace_go_check_A_const_237 *lang.Keyword

var A_arbace_go_check_A_const_238 *lang.Keyword

var A_arbace_go_check_A_const_239 *lang.Keyword

var A_arbace_go_check_A_const_240 *lang.Keyword

var A_arbace_go_check_A_const_241 *lang.Var

var A_arbace_go_check_A_const_242 any

var A_arbace_go_check_A_const_243 any

var A_arbace_go_check_A_const_244 *lang.Keyword

var A_arbace_go_check_A_const_245 *lang.Keyword

var A_arbace_go_check_A_const_246 *lang.Var

var A_arbace_go_check_A_const_247 *lang.Keyword

var A_arbace_go_check_A_const_248 any

var A_arbace_go_check_A_const_249 any

var A_arbace_go_check_A_const_250 *lang.Keyword

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 *lang.Keyword

var A_arbace_go_check_A_const_253 *lang.Var

var A_arbace_go_check_A_const_254 *lang.Keyword

var A_arbace_go_check_A_const_255 *lang.Keyword

var A_arbace_go_check_A_const_256 *lang.Keyword

var A_arbace_go_check_A_const_257 *lang.Keyword

var A_arbace_go_check_A_const_258 *lang.Keyword

var A_arbace_go_check_A_const_259 *lang.Keyword

var A_arbace_go_check_A_const_260 *lang.Var

var A_arbace_go_check_A_const_261 *lang.Var

var A_arbace_go_check_A_const_262 *lang.Keyword

var A_arbace_go_check_A_const_263 *lang.Var

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Keyword

var A_arbace_go_check_A_const_266 *lang.Keyword

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 *lang.Var

var A_arbace_go_check_A_const_269 *lang.Var

var A_arbace_go_check_A_const_270 any

var A_arbace_go_check_A_const_271 *lang.Keyword

var A_arbace_go_check_A_const_272 *lang.Var

var A_arbace_go_check_A_const_273 *lang.Var

var A_arbace_go_check_A_const_274 *lang.Var

var A_arbace_go_check_A_const_275 *lang.Var

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Var

var A_arbace_go_check_A_const_278 *lang.Keyword

var A_arbace_go_check_A_const_279 *lang.Keyword

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Keyword

var A_arbace_go_check_A_const_283 *lang.Keyword

var A_arbace_go_check_A_const_284 *lang.Keyword

var A_arbace_go_check_A_const_285 *lang.Keyword

var A_arbace_go_check_A_const_286 any

var A_arbace_go_check_A_const_287 *lang.Keyword

var A_arbace_go_check_A_const_288 any

var A_arbace_go_check_A_const_289 any

var A_arbace_go_check_A_const_290 any

var A_arbace_go_check_A_const_291 *lang.Keyword

var A_arbace_go_check_A_const_292 *lang.Var

var A_arbace_go_check_A_const_293 any

var A_arbace_go_check_A_const_294 any

var A_arbace_go_check_A_const_295 any

var A_arbace_go_check_A_const_296 any

var A_arbace_go_check_A_const_297 any

var A_arbace_go_check_A_const_298 *lang.Keyword

var A_arbace_go_check_A_const_299 any

var A_arbace_go_check_A_const_300 *lang.Var

var A_arbace_go_check_A_const_301 *lang.Var

var A_arbace_go_check_A_const_302 *lang.Var

var A_arbace_go_check_A_const_303 *lang.Var

var A_arbace_go_check_A_const_304 *lang.Var

var A_arbace_go_check_A_const_305 any

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Keyword

var A_arbace_go_check_A_const_308 *lang.Keyword

var A_arbace_go_check_A_const_309 *lang.Keyword

var A_arbace_go_check_A_const_310 *lang.Keyword

var A_arbace_go_check_A_const_311 *lang.Var

var A_arbace_go_check_A_const_312 *lang.Var

var A_arbace_go_check_A_const_313 *lang.Var

var A_arbace_go_check_A_const_314 *lang.Var

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Keyword

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 *lang.Var

var A_arbace_go_check_A_const_322 any

var A_arbace_go_check_A_const_323 *lang.Var

var A_arbace_go_check_A_const_324 any

var A_arbace_go_check_A_const_325 any

var A_arbace_go_check_A_const_326 *lang.Var

var A_arbace_go_check_A_const_327 *lang.Keyword

var A_arbace_go_check_A_const_328 *lang.Keyword

var A_arbace_go_check_A_const_329 *lang.Keyword

var A_arbace_go_check_A_const_330 *lang.Keyword

var A_arbace_go_check_A_const_331 *lang.Keyword

var A_arbace_go_check_A_const_332 *lang.Var

var A_arbace_go_check_A_const_333 *lang.Keyword

var A_arbace_go_check_A_const_334 *lang.Keyword

var A_arbace_go_check_A_const_335 *lang.Var

var A_arbace_go_check_A_const_336 *lang.Keyword

var A_arbace_go_check_A_const_337 any

var A_arbace_go_check_A_const_338 *lang.Keyword

var A_arbace_go_check_A_const_339 *lang.Keyword

var A_arbace_go_check_A_const_340 *lang.Var

var A_arbace_go_check_A_const_341 any

var A_arbace_go_check_A_const_342 any

var A_arbace_go_check_A_const_343 *lang.Var

var A_arbace_go_check_A_const_344 *lang.Var

var A_arbace_go_check_A_const_345 any

var A_arbace_go_check_A_const_346 *lang.Var

var A_arbace_go_check_A_const_347 any

var A_arbace_go_check_A_const_348 *lang.Var

var A_arbace_go_check_A_const_349 *lang.Var

var A_arbace_go_check_A_const_350 *lang.Var

var A_arbace_go_check_A_const_351 *lang.Var

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 *lang.Var

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_const_359 *lang.Var

var A_arbace_go_check_A_const_360 *lang.Keyword

var A_arbace_go_check_A_const_361 *lang.Keyword

var A_arbace_go_check_A_const_362 *lang.Keyword

var A_arbace_go_check_A_const_363 *lang.Var

var A_arbace_go_check_A_const_364 *lang.Var

var A_arbace_go_check_A_const_365 *jrt.Class

var A_arbace_go_check_A_const_366 *lang.Var

var A_arbace_go_check_A_const_367 *lang.Var

var A_arbace_go_check_A_const_368 *lang.Var

var A_arbace_go_check_A_const_369 *lang.Keyword

var A_arbace_go_check_A_const_370 any

var A_arbace_go_check_A_const_371 any

var A_arbace_go_check_A_const_372 any

var A_arbace_go_check_A_const_373 *lang.Keyword

var A_arbace_go_check_A_const_374 *lang.Var

var A_arbace_go_check_A_const_375 *lang.Keyword

var A_arbace_go_check_A_const_376 *lang.Var

var A_arbace_go_check_A_const_377 *lang.Var

var A_arbace_go_check_A_const_378 any

var A_arbace_go_check_A_const_379 any

var A_arbace_go_check_A_const_380 any

var A_arbace_go_check_A_const_381 any

var A_arbace_go_check_A_const_382 any

var A_arbace_go_check_A_const_383 any

var A_arbace_go_check_A_const_384 *lang.Var

var A_arbace_go_check_A_const_385 any

var A_arbace_go_check_A_const_386 any

var A_arbace_go_check_A_const_387 any

var A_arbace_go_check_A_const_388 any

var A_arbace_go_check_A_const_389 *lang.Keyword

var A_arbace_go_check_A_const_390 *lang.Var

var A_arbace_go_check_A_const_391 *lang.Keyword

var A_arbace_go_check_A_const_392 *lang.Var

var A_arbace_go_check_A_const_393 *lang.Var

var A_arbace_go_check_A_const_394 *lang.Var

var A_arbace_go_check_A_const_395 *lang.Var

var A_arbace_go_check_A_const_396 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29(); A_arbace_go_check_A_clinit_p30(); A_arbace_go_check_A_clinit_p31(); A_arbace_go_check_A_clinit_p32() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 579); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[182]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[183]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[184]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[185]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[186]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[187]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[189]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[190]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[191]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[192]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[193]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[194]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[195]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[196]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[199]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[200]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[203]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[204]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[205]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[207]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[208]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[209]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[212]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[213]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[214]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[216]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[219] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[220]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[221]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[223]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[224]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[225]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[226]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[230]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[231]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[232]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[233]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_55 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_61 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[245]); A_arbace_go_check_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_66 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_72 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[256]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[257]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_77 = A_arbace_go_check_A_const_pool.A[259]; A_arbace_go_check_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[260]); A_arbace_go_check_A_const_79 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_86 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[268]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[269]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_90 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_92 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_94 = A_arbace_go_check_A_const_pool.A[276]; A_arbace_go_check_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_96 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_98 = A_arbace_go_check_A_const_pool.A[280] }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[281]); A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[282]); A_arbace_go_check_A_const_101 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[283]); A_arbace_go_check_A_const_102 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_103 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[285]); A_arbace_go_check_A_const_104 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_105 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_107 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[290]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[292]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]); A_arbace_go_check_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_113 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[295]); A_arbace_go_check_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_119 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_122 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[304]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[305]); A_arbace_go_check_A_const_124 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_125 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_128 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_129 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[312]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_132 = A_arbace_go_check_A_const_pool.A[314]; A_arbace_go_check_A_const_133 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[316]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[317]); A_arbace_go_check_A_const_136 = A_arbace_go_check_A_const_pool.A[318]; A_arbace_go_check_A_const_137 = A_arbace_go_check_A_const_pool.A[319]; A_arbace_go_check_A_const_138 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[320]); A_arbace_go_check_A_const_139 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[321]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_141 = A_arbace_go_check_A_const_pool.A[323]; A_arbace_go_check_A_const_142 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[324]); A_arbace_go_check_A_const_143 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_144 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_145 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[328]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[329]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_149 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_150 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_151 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_153 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_154 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_155 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_156 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_157 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[340]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_163 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_164 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_165 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_166 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_167 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[352]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]); A_arbace_go_check_A_const_191 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[377]); A_arbace_go_check_A_const_196 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_197 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_198 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_199 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_200 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_201 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_202 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_203 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_205 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_206 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[388]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[389]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_209 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_210 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_211 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_212 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_214 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_215 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_216 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_217 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[400]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[401]); A_arbace_go_check_A_const_220 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_221 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_222 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_223 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_224 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_225 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_226 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_227 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_230 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[412]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[413]); A_arbace_go_check_A_const_232 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_233 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_235 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_236 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_239 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_241 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_242 = A_arbace_go_check_A_const_pool.A[424] }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = A_arbace_go_check_A_const_pool.A[425]; A_arbace_go_check_A_const_244 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_245 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_246 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[428]); A_arbace_go_check_A_const_247 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[429]); A_arbace_go_check_A_const_248 = A_arbace_go_check_A_const_pool.A[430]; A_arbace_go_check_A_const_249 = A_arbace_go_check_A_const_pool.A[431]; A_arbace_go_check_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[433]); A_arbace_go_check_A_const_252 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_253 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[435]); A_arbace_go_check_A_const_254 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[436]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_255 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]); A_arbace_go_check_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_258 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_260 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_261 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_262 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_263 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[445]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_265 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_266 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[448]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_268 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]); A_arbace_go_check_A_const_269 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[451]); A_arbace_go_check_A_const_270 = A_arbace_go_check_A_const_pool.A[452]; A_arbace_go_check_A_const_271 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_272 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_273 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_274 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_275 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[457]); A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_277 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_278 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[460]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_279 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_282 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_283 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_284 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_285 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_286 = A_arbace_go_check_A_const_pool.A[468]; A_arbace_go_check_A_const_287 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_288 = A_arbace_go_check_A_const_pool.A[470]; A_arbace_go_check_A_const_289 = A_arbace_go_check_A_const_pool.A[471]; A_arbace_go_check_A_const_290 = A_arbace_go_check_A_const_pool.A[472]; A_arbace_go_check_A_const_291 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[473]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[474]); A_arbace_go_check_A_const_293 = A_arbace_go_check_A_const_pool.A[475]; A_arbace_go_check_A_const_294 = A_arbace_go_check_A_const_pool.A[476]; A_arbace_go_check_A_const_295 = A_arbace_go_check_A_const_pool.A[477]; A_arbace_go_check_A_const_296 = A_arbace_go_check_A_const_pool.A[478]; A_arbace_go_check_A_const_297 = A_arbace_go_check_A_const_pool.A[479]; A_arbace_go_check_A_const_298 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[480]); A_arbace_go_check_A_const_299 = A_arbace_go_check_A_const_pool.A[481]; A_arbace_go_check_A_const_300 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[482]); A_arbace_go_check_A_const_301 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[483]); A_arbace_go_check_A_const_302 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[484]); A_arbace_go_check_A_const_303 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_304 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[486]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_305 = A_arbace_go_check_A_const_pool.A[487]; A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[488]); A_arbace_go_check_A_const_307 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_308 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_309 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_310 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_311 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_312 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[494]); A_arbace_go_check_A_const_313 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[495]); A_arbace_go_check_A_const_314 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[498]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_317 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[500]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_321 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_322 = A_arbace_go_check_A_const_pool.A[504]; A_arbace_go_check_A_const_323 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_324 = A_arbace_go_check_A_const_pool.A[506]; A_arbace_go_check_A_const_325 = A_arbace_go_check_A_const_pool.A[507]; A_arbace_go_check_A_const_326 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[508]); A_arbace_go_check_A_const_327 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[509]); A_arbace_go_check_A_const_328 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[510]) }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_329 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[511]); A_arbace_go_check_A_const_330 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[512]); A_arbace_go_check_A_const_331 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[513]); A_arbace_go_check_A_const_332 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[514]); A_arbace_go_check_A_const_333 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[515]); A_arbace_go_check_A_const_334 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[516]); A_arbace_go_check_A_const_335 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_336 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_337 = A_arbace_go_check_A_const_pool.A[519]; A_arbace_go_check_A_const_338 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_339 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[521]); A_arbace_go_check_A_const_340 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[522]) }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_341 = A_arbace_go_check_A_const_pool.A[523]; A_arbace_go_check_A_const_342 = A_arbace_go_check_A_const_pool.A[524]; A_arbace_go_check_A_const_343 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[525]); A_arbace_go_check_A_const_344 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[526]); A_arbace_go_check_A_const_345 = A_arbace_go_check_A_const_pool.A[527]; A_arbace_go_check_A_const_346 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[528]); A_arbace_go_check_A_const_347 = A_arbace_go_check_A_const_pool.A[529]; A_arbace_go_check_A_const_348 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[530]); A_arbace_go_check_A_const_349 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[531]); A_arbace_go_check_A_const_350 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[532]); A_arbace_go_check_A_const_351 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[533]); A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[534]); A_arbace_go_check_A_const_353 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[535]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[536]); A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[537]); A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[538]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[539]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[540]); A_arbace_go_check_A_const_359 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[541]); A_arbace_go_check_A_const_360 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[542]); A_arbace_go_check_A_const_361 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[543]); A_arbace_go_check_A_const_362 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[544]); A_arbace_go_check_A_const_363 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[545]); A_arbace_go_check_A_const_364 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[546]); A_arbace_go_check_A_const_365 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[547]) }

func A_arbace_go_check_A_clinit_p30() { A_arbace_go_check_A_const_366 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[548]); A_arbace_go_check_A_const_367 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[549]); A_arbace_go_check_A_const_368 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[550]); A_arbace_go_check_A_const_369 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[551]); A_arbace_go_check_A_const_370 = A_arbace_go_check_A_const_pool.A[552]; A_arbace_go_check_A_const_371 = A_arbace_go_check_A_const_pool.A[553]; A_arbace_go_check_A_const_372 = A_arbace_go_check_A_const_pool.A[554]; A_arbace_go_check_A_const_373 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[555]); A_arbace_go_check_A_const_374 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[556]); A_arbace_go_check_A_const_375 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[557]); A_arbace_go_check_A_const_376 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[558]); A_arbace_go_check_A_const_377 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[559]); A_arbace_go_check_A_const_378 = A_arbace_go_check_A_const_pool.A[560] }

func A_arbace_go_check_A_clinit_p31() { A_arbace_go_check_A_const_379 = A_arbace_go_check_A_const_pool.A[561]; A_arbace_go_check_A_const_380 = A_arbace_go_check_A_const_pool.A[562]; A_arbace_go_check_A_const_381 = A_arbace_go_check_A_const_pool.A[563]; A_arbace_go_check_A_const_382 = A_arbace_go_check_A_const_pool.A[564]; A_arbace_go_check_A_const_383 = A_arbace_go_check_A_const_pool.A[565]; A_arbace_go_check_A_const_384 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[566]); A_arbace_go_check_A_const_385 = A_arbace_go_check_A_const_pool.A[567]; A_arbace_go_check_A_const_386 = A_arbace_go_check_A_const_pool.A[568]; A_arbace_go_check_A_const_387 = A_arbace_go_check_A_const_pool.A[569]; A_arbace_go_check_A_const_388 = A_arbace_go_check_A_const_pool.A[570]; A_arbace_go_check_A_const_389 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[571]); A_arbace_go_check_A_const_390 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[572]); A_arbace_go_check_A_const_391 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[573]); A_arbace_go_check_A_const_392 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[574]) }

func A_arbace_go_check_A_clinit_p32() { A_arbace_go_check_A_const_393 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[575]); A_arbace_go_check_A_const_394 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[576]); A_arbace_go_check_A_const_395 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[577]); A_arbace_go_check_A_const_396 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[578]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000511_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000511_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000514_A struct{ j2g_header uint64; F_cs, F_opts any }

var A_arbace_go_check__main_fn__1685000514_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A struct{ j2g_header uint64; F_iter__1685000515, F_opts, F_s__1685000516 any }

var A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A struct{ j2g_header uint64; F_b__1685000518, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_fn__1685000514_iter__1685000515__1685000519_fn__1685000520_fn__1685000521_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000486__1685000492_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000486__1685000492_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A struct{ j2g_header uint64; F_s__1685000487, F_iter__1685000486 any }

var A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A struct{ j2g_header uint64; F_r, F_s__1685000489, F_iter__1685000488 any }

var A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A struct{ j2g_header uint64; F_r, F_b__1685000491 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_annotations_iter__1685000486__1685000492_fn__1685000493_iter__1685000488__1685000494_fn__1685000495_fn__1685000496_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000366_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000370_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000374_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000380_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000394_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000380_fn__1685000396_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A struct{ j2g_header uint64; F_s__1685000385, F_iter__1685000384 any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A struct{ j2g_header uint64; F_b__1685000387 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000384__1685000388_fn__1685000389_fn__1685000390_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A struct{ j2g_header uint64; F_dir, F_tdir, F_s__1685000399, F_ts, F_iter__1685000398 any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A struct{ j2g_header uint64; F_b__1685000401, F_dir, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000404_fn__1685000408_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000380_iter__1685000398__1685000402_fn__1685000403_fn__1685000414_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000356__1685000360_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A struct{ j2g_header uint64; F_s__1685000357, F_iter__1685000356 any }

var A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A struct{ j2g_header uint64; F_b__1685000359 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_iter__1685000356__1685000360_fn__1685000361_fn__1685000362_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000129_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000129_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000131_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000131_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000175_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000175_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000182_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000182_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000189_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000189_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000199_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000199_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000201_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000201_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000235_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000235_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000237_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000237_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000243_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000243_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_A struct{ j2g_header uint64; F_resolving any }

var A_arbace_go_check_check_package_fn__1685000246_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000252_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000254_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000256_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000258_fn__1685000259_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000278_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000280_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000282_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000246_fn__1685000284_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A struct{ j2g_header uint64; F_s__1685000263, F_iter__1685000262, F_verified any }

var A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000265, F_verified any }

var A_arbace_go_check_check_package_fn__1685000246_iter__1685000262__1685000266_fn__1685000267_fn__1685000268_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000295_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000295_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000307_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000307_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000307_fn__1685000308_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000227_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000227_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000227_one__1685000228_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000297__1685000301_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000297__1685000301_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A struct{ j2g_header uint64; F_s__1685000298, F_iter__1685000297 any }

var A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A struct{ j2g_header uint64; F_b__1685000300 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000297__1685000301_fn__1685000302_fn__1685000303_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000231_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000231_fn__1685000232_A_fn_class *jrt.Class



type A_arbace_go_check_check_src_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_src_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000317_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000317_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000463_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000463_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000465__1685000469_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000465__1685000469_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A struct{ j2g_header uint64; F_s__1685000466, F_iter__1685000465 any }

var A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A struct{ j2g_header uint64; F_b__1685000468 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000465__1685000469_fn__1685000470_fn__1685000471_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000443__1685000449_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000443__1685000449_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A struct{ j2g_header uint64; F_s__1685000444, F_iter__1685000443 any }

var A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A struct{ j2g_header uint64; F_r, F_s__1685000446, F_iter__1685000445 any }

var A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A struct{ j2g_header uint64; F_b__1685000448, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_report_errors_iter__1685000443__1685000449_fn__1685000450_iter__1685000445__1685000451_fn__1685000452_fn__1685000453_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000314_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000314_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000334__1685000338_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs, F_s__1685000335, F_iter__1685000334 any }

var A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A struct{ j2g_header uint64; F_f, F_b__1685000337, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000341_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000334__1685000338_fn__1685000339_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000329_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000329_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000329_fn__1685000330_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000430_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000430_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000432_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000432_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000434_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000434_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000436_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000436_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000438_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000438_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000440_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000440_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000428_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000428_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000426_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000426_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000479_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000479_A_fn_class *jrt.Class
