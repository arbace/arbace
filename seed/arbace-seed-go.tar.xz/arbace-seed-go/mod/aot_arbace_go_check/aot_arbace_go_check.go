//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_117)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { var root_262 any = A_arbace_go_check_A_const_54.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = want__7; var arg_266 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_263 == nil { tmp1 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { tmp1 = linked_263.(*aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_24; var arg_271 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_268 == nil { ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { linked_268.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_267, arg_270, arg_271) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_272 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_273 == nil { tmp2 = ifn_274.Invoke_O__O(arg_275) } else { tmp2 = linked_273.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_272, arg_275) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_276 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_280 any = Lit_156; var arg_281 any; var root_284 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_285 == nil { arg_281 = ifn_286.Invoke_O__O(arg_287) } else { arg_281 = linked_285.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_284, arg_287) }; var arg_282 any; var root_288 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_290 lang.IFn
							if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = want__7; if linked_289 == nil { arg_282 = ifn_290.Invoke_O__O(arg_291) } else { arg_282 = linked_289.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_288, arg_291) }
//line :93:1
							var arg_283 any; var root_292 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_294 lang.IFn
							if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_293 == nil { arg_283 = ifn_294.Invoke_O__O(arg_295) } else { arg_283 = linked_293.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_292, arg_295) }
//line :93:1
							if linked_277 == nil { ifn_278.Invoke_O_O_O_O_O__O(arg_279, arg_280, arg_281, arg_282, arg_283) } else { linked_277.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_276, arg_279, arg_280, arg_281, arg_282, arg_283) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_61; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_62.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_65; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_296 any = A_arbace_go_check_A_const_67.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_298 lang.IFn
									if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_297 == nil { and__1927000168__auto____11 = ifn_298.Invoke_O__O(arg_299) } else { and__1927000168__auto____11 = linked_297.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_296, arg_299) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_300 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68; var arg_304 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_301 == nil { tmp3 = ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { tmp3 = linked_301.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_305 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__6); var arg_309 any = Lit_156; var arg_310 any; var root_313 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__6); if linked_314 == nil { arg_310 = ifn_315.Invoke_O__O(arg_316) } else { arg_310 = linked_314.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_313, arg_316) }; var arg_311 any = Lit_157; var arg_312 any; var root_317 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_318 == nil { arg_312 = ifn_319.Invoke_O__O(arg_320) } else { arg_312 = linked_318.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_317, arg_320) }; if linked_306 == nil { ifn_307.Invoke_O_O_O_O_O__O(arg_308, arg_309, arg_310, arg_311, arg_312) } else { linked_306.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_305, arg_308, arg_309, arg_310, arg_311, arg_312) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_321 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = seq_1685000042__7; if linked_322 == nil { tmp8 = ifn_323.Invoke_O__O(arg_324) } else { tmp8 = linked_322.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_321, arg_324) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { var root_325 any = A_arbace_go_check_A_const_54.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = want__9; var arg_329 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_326 == nil { tmp9 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { tmp9 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_325, arg_328, arg_329) } } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_330 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = A_arbace_go_check_A_const_24; var arg_334 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_331 == nil { ifn_332.Invoke_O_O__O(arg_333, arg_334) } else { linked_331.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_330, arg_333, arg_334) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_335 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_336 == nil { tmp10 = ifn_337.Invoke_O__O(arg_338) } else { tmp10 = linked_336.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_335, arg_338) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_339 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_343 any = Lit_156; var arg_344 any; var root_347 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_348 == nil { arg_344 = ifn_349.Invoke_O__O(arg_350) } else { arg_344 = linked_348.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_347, arg_350) }; var arg_345 any; var root_351 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_353 lang.IFn
								if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = want__9; if linked_352 == nil { arg_345 = ifn_353.Invoke_O__O(arg_354) } else { arg_345 = linked_352.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_351, arg_354) }
//line :93:1
								var arg_346 any; var root_355 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_357 lang.IFn
								if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_356 == nil { arg_346 = ifn_357.Invoke_O__O(arg_358) } else { arg_346 = linked_356.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_355, arg_358) }
//line :93:1
								if linked_340 == nil { ifn_341.Invoke_O_O_O_O_O__O(arg_342, arg_343, arg_344, arg_345, arg_346) } else { linked_340.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_339, arg_342, arg_343, arg_344, arg_345, arg_346) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_61; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_62.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_65; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_359 any = A_arbace_go_check_A_const_67.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_361 lang.IFn
										if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_360 == nil { and__1927000168__auto____13 = ifn_361.Invoke_O__O(arg_362) } else { and__1927000168__auto____13 = linked_360.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_359, arg_362) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_363 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = A_arbace_go_check_A_const_68; var arg_367 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_364 == nil { tmp11 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { tmp11 = linked_364.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_363, arg_366, arg_367) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_368 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__8); var arg_372 any = Lit_156; var arg_373 any; var root_376 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__8); if linked_377 == nil { arg_373 = ifn_378.Invoke_O__O(arg_379) } else { arg_373 = linked_377.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_376, arg_379) }; var arg_374 any = Lit_157; var arg_375 any; var root_380 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_381 == nil { arg_375 = ifn_382.Invoke_O__O(arg_383) } else { arg_375 = linked_381.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_380, arg_383) }; if linked_369 == nil { ifn_370.Invoke_O_O_O_O_O__O(arg_371, arg_372, arg_373, arg_374, arg_375) } else { linked_369.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_368, arg_371, arg_372, arg_373, arg_374, arg_375) } } }
//line :86:1
				var tmp15 any; var root_384 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = seq_1685000042__7; if linked_385 == nil { tmp15 = ifn_386.Invoke_O__O(arg_387) } else { tmp15 = linked_385.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_384, arg_387) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_71; var tmp2 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_72; var tmp4 any; var root_388 any = A_arbace_go_check_A_const_73.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_390 lang.IFn; if
													linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = pkg_scope__0; var arg_392 any = A_arbace_go_check_A_const_74; if linked_389 == nil { tmp4 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { tmp4 = linked_389.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_75; var tmp7 any; var root_393 any = /*line :101:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_393, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_395 lang.IFn; if


	linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var or__1927000174__auto____4 any; var root_397 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = fi__1; var arg_401 any = A_arbace_go_check_A_const_78; if linked_398 == nil { or__1927000174__auto____4 = ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { or__1927000174__auto____4 = linked_398.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_396 = or__1927000174__auto____4 } else { arg_396 = A_arbace_go_check_A_const_75.Invoke_O__O(config__2) }; if linked_394 == nil { tmp7 = ifn_395.Invoke_O__O(arg_396) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_394.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_393, arg_396)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_79; var tmp10 any; var root_402 any = /*line :101:1*/A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_404 lang.IFn; if



	linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_go_check_A_const_74.Invoke_O__O(fi__1); if linked_403 == nil { tmp10 = ifn_404.Invoke_O__O(arg_405) } else { tmp10 = linked_403.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_402, arg_405) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_81; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_81; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_82.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_83; var tmp16 any = A_arbace_go_check_A_const_83.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_84; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_85; var tmp20 any; var root_406 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_408 lang.IFn; if





	linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = lang.PersistentVector_EMPTY.Ref(); if linked_407 == nil { tmp20 = ifn_408.Invoke_O__O(arg_409) } else { tmp20 = linked_407.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_406, arg_409) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_86; var tmp23 any; var root_410 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_412 lang.IFn; if





	linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = lang.PersistentVector_EMPTY.Ref(); if linked_411 == nil { tmp23 = ifn_412.Invoke_O__O(arg_413) } else { tmp23 = linked_411.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_410, arg_413) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__512d; tmp1 = fncls__512d } else { tmp1 = fncls__512 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_513 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any; var root_517 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = A_arbace_go_check_A_const_85.Invoke_O__O(fi__0); if linked_518 == nil { arg_516 = ifn_519.Invoke_O__O(arg_520) } else { arg_516 = linked_518.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_517, arg_520) }; if linked_514 == nil { tmp2 = ifn_515.Invoke_O__O(arg_516) } else { tmp2 = linked_514.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_513, arg_516) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__571 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__571 == nil { var fncls__571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__571d; tmp3 = fncls__571d } else { tmp3 = fncls__571 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_414 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_416 lang.IFn
	if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = f__1; if linked_415 == nil { tmp1 = ifn_416.Invoke_O__O(arg_417) } else { tmp1 = linked_415.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_414, arg_417) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_418 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_420 lang.IFn
		if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = f__1; if linked_419 == nil { temp__1927000414__auto____2 = ifn_420.Invoke_O__O(arg_421) } else { temp__1927000414__auto____2 = linked_419.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_480 any = A_arbace_go_check_A_const_91.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_482 lang.IFn
			if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = A_arbace_go_check_A_const_72.Invoke_O__O(t.F_fi); var arg_484 any = q__3; if linked_481 == nil { temp__1927000414__auto____4 = ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { temp__1927000414__auto____4 = linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_92; var tmp3 any; var root_485 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_487 lang.IFn
				if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = x__5; var arg_489 any = A_arbace_go_check_A_const_94; if linked_486 == nil { tmp3 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { tmp3 = linked_486.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_490 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = x__5; var arg_494 any = A_arbace_go_check_A_const_90; var arg_495 any = jrt.Boolean_TRUE.Ref(); if linked_491 == nil { ifn_492.Invoke_O_O_O__O(arg_493, arg_494, arg_495) } else { linked_491.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_490, arg_493, arg_494, arg_495) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_84.Invoke_O__O(t.F_fi)); var tmp5 any; var root_422 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_424 lang.IFn


			if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp5 = ifn_424.Invoke_O__O(arg_425) } else { tmp5 = linked_423.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_422, arg_425) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_426 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_428 lang.IFn; _ = ___6; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = imp__7; var arg_430 any = A_arbace_go_check_A_const_90; var arg_431 any = jrt.Boolean_TRUE.Ref(); if linked_427 == nil { ifn_428.Invoke_O_O_O__O(arg_429, arg_430, arg_431) } else { linked_427.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_426, arg_429, arg_430, arg_431) } } } } else {
//line :113:1
				var tmp6 any; var root_432 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_434 lang.IFn




				if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = f__1; if linked_433 == nil { tmp6 = ifn_434.Invoke_O__O(arg_435) } else { tmp6 = linked_433.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_432, arg_435) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_436 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_438 lang.IFn




					if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = f__1; if linked_437 == nil { seq_1685000052__2 = ifn_438.Invoke_O__O(arg_439) } else { seq_1685000052__2 = linked_437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_436, arg_439) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_440 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = seq_1685000052__2; if linked_441 == nil { temp__1927000414__auto____6 = ifn_442.Invoke_O__O(arg_443) } else { temp__1927000414__auto____6 = linked_441.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_440, arg_443) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_444 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = seq_1685000052__7; if linked_445 == nil { tmp7 = ifn_446.Invoke_O__O(arg_447) } else { tmp7 = linked_445.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_444, arg_447) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_448 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_1685000052__7; if linked_449 == nil { c__1927000678__auto____8 = ifn_450.Invoke_O__O(arg_451) } else { c__1927000678__auto____8 = linked_449.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_448, arg_451) }; var tmp8 any; var root_496 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = seq_1685000052__7; if linked_497 == nil { tmp8 = ifn_498.Invoke_O__O(arg_499) } else { tmp8 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_496, arg_499) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_452 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1685000052__7; if linked_453 == nil { x__8 = ifn_454.Invoke_O__O(arg_455) } else { x__8 = linked_453.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_452, arg_455) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_500 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = seq_1685000052__7; if linked_501 == nil { tmp9 = ifn_502.Invoke_O__O(arg_503) } else { tmp9 = linked_501.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_500, arg_503) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_456 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_458 lang.IFn





							if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = f__1; if linked_457 == nil { tmp10 = ifn_458.Invoke_O__O(arg_459) } else { tmp10 = linked_457.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_456, arg_459) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_460 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_462 lang.IFn





								if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = f__1; if linked_461 == nil { seq_1685000056__2 = ifn_462.Invoke_O__O(arg_463) } else { seq_1685000056__2 = linked_461.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_460, arg_463) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_464 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = seq_1685000056__2; if linked_465 == nil { temp__1927000414__auto____6_2 = ifn_466.Invoke_O__O(arg_467) } else { temp__1927000414__auto____6_2 = linked_465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_464, arg_467) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_468 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = seq_1685000056__7; if linked_469 == nil { tmp11 = ifn_470.Invoke_O__O(arg_471) } else { tmp11 = linked_469.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_468, arg_471) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_472 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = seq_1685000056__7; if linked_473 == nil { c__1927000678__auto____8_2 = ifn_474.Invoke_O__O(arg_475) } else { c__1927000678__auto____8_2 = linked_473.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_472, arg_475) }; var tmp12 any; var root_504 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = seq_1685000056__7; if linked_505 == nil { tmp12 = ifn_506.Invoke_O__O(arg_507) } else { tmp12 = linked_505.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_504, arg_507) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_476 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = seq_1685000056__7; if linked_477 == nil { x__8_2 = ifn_478.Invoke_O__O(arg_479) } else { x__8_2 = linked_477.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_476, arg_479) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_508 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seq_1685000056__7; if linked_509 == nil { tmp13 = ifn_510.Invoke_O__O(arg_511) } else { tmp13 = linked_509.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_508, arg_511) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_521 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_523 lang.IFn
		if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = f__1; if linked_522 == nil { tmp1 = ifn_523.Invoke_O__O(arg_524) } else { tmp1 = linked_522.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_521, arg_524) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_84.Invoke_O__O(t.F_fi)); var tmp3 any; var root_525 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_527 lang.IFn
			if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { tmp3 = ifn_527.Invoke_O__O(arg_528) } else { tmp3 = linked_526.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_525, arg_528) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_529 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_531 lang.IFn; _ = ___4; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = imp__5; var arg_533 any = A_arbace_go_check_A_const_90; var arg_534 any = jrt.Boolean_TRUE.Ref(); if linked_530 == nil { return ifn_531.Invoke_O_O_O__O(arg_532, arg_533, arg_534) } else { return linked_530.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_529, arg_532, arg_533, arg_534) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_535 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_537 lang.IFn

				if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = f__1; if linked_536 == nil { or__1927000174__auto____2 = ifn_537.Invoke_O__O(arg_538) } else { or__1927000174__auto____2 = linked_536.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_535, arg_538) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_539 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = f__1; if linked_540 == nil { tmp4 = ifn_541.Invoke_O__O(arg_542) } else { tmp4 = linked_540.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_539, arg_542) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_543 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_545 lang.IFn

					if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = f__1; if linked_544 == nil { seq_1685000065__2 = ifn_545.Invoke_O__O(arg_546) } else { seq_1685000065__2 = linked_544.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_543, arg_546) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_547 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = seq_1685000065__2; if linked_548 == nil { temp__1927000414__auto____6 = ifn_549.Invoke_O__O(arg_550) } else { temp__1927000414__auto____6 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_551 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = seq_1685000065__7; if linked_552 == nil { tmp5 = ifn_553.Invoke_O__O(arg_554) } else { tmp5 = linked_552.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_551, arg_554) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_555 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = seq_1685000065__7; if linked_556 == nil { c__1927000678__auto____8 = ifn_557.Invoke_O__O(arg_558) } else { c__1927000678__auto____8 = linked_556.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_555, arg_558) }; var tmp6 any; var root_563 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = seq_1685000065__7; if linked_564 == nil { tmp6 = ifn_565.Invoke_O__O(arg_566) } else { tmp6 = linked_564.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_563, arg_566) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_559 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = seq_1685000065__7; if linked_560 == nil { x__8 = ifn_561.Invoke_O__O(arg_562) } else { x__8 = linked_560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_559, arg_562) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_567 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = seq_1685000065__7; if linked_568 == nil { tmp7 = ifn_569.Invoke_O__O(arg_570) } else { tmp7 = linked_568.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_567, arg_570) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__683 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__683 == nil { var fncls__683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__683d; tmp1 = fncls__683d } else { tmp1 = fncls__683 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_99); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp6 any; var root_692 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = d__0; if linked_693 == nil { tmp6 = ifn_694.Invoke_O__O(arg_695) } else { tmp6 = linked_693.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_692, arg_695) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp8 any; var root_684 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = d__0; if linked_685 == nil { tmp8 = ifn_686.Invoke_O__O(arg_687) } else { tmp8 = linked_685.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_684, arg_687) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp10 any; var root_688 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = d__0; if linked_689 == nil { tmp10 = ifn_690.Invoke_O__O(arg_691) } else { tmp10 = linked_689.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_688, arg_691) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_572 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_574 lang.IFn
		if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = f__1; if linked_573 == nil { and__1927000168__auto____2 = ifn_574.Invoke_O__O(arg_575) } else { and__1927000168__auto____2 = linked_573.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_572, arg_575) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_576 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = f__1; if linked_577 == nil { tmp2 = ifn_578.Invoke_O__O(arg_579) } else { tmp2 = linked_577.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_576, arg_579) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_580 any = A_arbace_go_check_A_const_91.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_582 lang.IFn

			if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = t.F_pkg_scope; var arg_584 any; var root_585 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = f__1; if linked_586 == nil { arg_584 = ifn_587.Invoke_O__O(arg_588) } else { arg_584 = linked_586.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_585, arg_588) }; if linked_581 == nil { temp__1927000414__auto____2 = ifn_582.Invoke_O_O__O(arg_583, arg_584) } else { temp__1927000414__auto____2 = linked_581.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_580, arg_583, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_95); var tmp4 any; var root_644 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_646 lang.IFn
				if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = x__3; var arg_648 any = A_arbace_go_check_A_const_94; if linked_645 == nil { tmp4 = ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { tmp4 = linked_645.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_589 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_593 any = A_arbace_go_check_A_const_96; var arg_594 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_595 any = x__3; if linked_590 == nil { tmp6 = ifn_591.Invoke_O_O_O_O__O(arg_592, arg_593, arg_594, arg_595) } else { tmp6 = linked_590.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_589, arg_592, arg_593, arg_594, arg_595) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_596 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_598 lang.IFn




								if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = f__1; if linked_597 == nil { tmp7 = ifn_598.Invoke_O__O(arg_599) } else { tmp7 = linked_597.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_596, arg_599) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_649 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_651 lang.IFn




									if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = f__1; if linked_650 == nil { temp__1927000414__auto____2_2 = ifn_651.Invoke_O__O(arg_652) } else { temp__1927000414__auto____2_2 = linked_650.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_649, arg_652) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_653 any = A_arbace_go_check_A_const_98.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_655 lang.IFn
										if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = h__3; var arg_657 any = Lit_137; if linked_654 == nil { and__1927000168__auto____4 = ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { and__1927000168__auto____4 = linked_654.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_653, arg_656, arg_657) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_658 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any; var root_662 any = A_arbace_go_check_A_const_98.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = h__3; var arg_666 any = Lit_155; if linked_663 == nil { arg_661 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { arg_661 = linked_663.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }; if linked_659 == nil { and__1927000168__auto____5 = ifn_660.Invoke_O__O(arg_661) } else { and__1927000168__auto____5 = linked_659.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_658, arg_661) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_600 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_602 lang.IFn








									if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = f__1; if linked_601 == nil { seq_1685000072__2 = ifn_602.Invoke_O__O(arg_603) } else { seq_1685000072__2 = linked_601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_600, arg_603) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_604 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = seq_1685000072__2; if linked_605 == nil { temp__1927000414__auto____6 = ifn_606.Invoke_O__O(arg_607) } else { temp__1927000414__auto____6 = linked_605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_604, arg_607) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_608 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = seq_1685000072__7; if linked_609 == nil { tmp9 = ifn_610.Invoke_O__O(arg_611) } else { tmp9 = linked_609.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_608, arg_611) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_612 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = seq_1685000072__7; if linked_613 == nil { c__1927000678__auto____8 = ifn_614.Invoke_O__O(arg_615) } else { c__1927000678__auto____8 = linked_613.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_612, arg_615) }; var tmp10 any; var root_667 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1685000072__7; if linked_668 == nil { tmp10 = ifn_669.Invoke_O__O(arg_670) } else { tmp10 = linked_668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_667, arg_670) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_616 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = seq_1685000072__7; if linked_617 == nil { x__8 = ifn_618.Invoke_O__O(arg_619) } else { x__8 = linked_617.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_616, arg_619) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_671 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = seq_1685000072__7; if linked_672 == nil { tmp11 = ifn_673.Invoke_O__O(arg_674) } else { tmp11 = linked_672.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_671, arg_674) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_620 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_622 lang.IFn









											if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = f__1; if linked_621 == nil { tmp12 = ifn_622.Invoke_O__O(arg_623) } else { tmp12 = linked_621.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_620, arg_623) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_624 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_626 lang.IFn









												if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = f__1; if linked_625 == nil { seq_1685000076__2 = ifn_626.Invoke_O__O(arg_627) } else { seq_1685000076__2 = linked_625.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_624, arg_627) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_628 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = seq_1685000076__2; if linked_629 == nil { temp__1927000414__auto____6_2 = ifn_630.Invoke_O__O(arg_631) } else { temp__1927000414__auto____6_2 = linked_629.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_628, arg_631) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_632 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = seq_1685000076__7; if linked_633 == nil { tmp13 = ifn_634.Invoke_O__O(arg_635) } else { tmp13 = linked_633.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_632, arg_635) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_636 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = seq_1685000076__7; if linked_637 == nil { c__1927000678__auto____8_2 = ifn_638.Invoke_O__O(arg_639) } else { c__1927000678__auto____8_2 = linked_637.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_636, arg_639) }; var tmp14 any; var root_675 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = seq_1685000076__7; if linked_676 == nil { tmp14 = ifn_677.Invoke_O__O(arg_678) } else { tmp14 = linked_676.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_675, arg_678) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_640 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = seq_1685000076__7; if linked_641 == nil { x__8_2 = ifn_642.Invoke_O__O(arg_643) } else { x__8_2 = linked_641.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_640, arg_643) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_679 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = seq_1685000076__7; if linked_680 == nil { tmp15 = ifn_681.Invoke_O__O(arg_682) } else { tmp15 = linked_680.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_679, arg_682) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_number_local_types_BANG__A_New() *A_arbace_go_check_number_local_types_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Invoke_O_O__O(self, lts__0 any) any { { var sorted__2 any; var root_696 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_698 lang.IFn





	if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var tmp1 any = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New(); var tmp2 *jrt.Class; var fncls__701 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class; if fncls__701 == nil { var fncls__701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class = fncls__701d; tmp2 = fncls__701d } else { tmp2 = fncls__701 }; arg_699 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_700 any; var root_702 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var tmp3 any = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New(); var tmp4 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class = fncls__707d; tmp4 = fncls__707d } else { tmp4 = fncls__707 }; arg_705 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_706 any = lts__0; if linked_703 == nil { arg_700 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_700 = linked_703.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_697 == nil { sorted__2 = ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { sorted__2 = linked_697.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) }
//line :151:1
	var seq_1685000094__3 any; var root_708 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_710 lang.IFn






	if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any; var root_712 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = A_arbace_go_check_A_const_104.GetRawRoot__O(); var arg_716 any = sorted__2; if linked_713 == nil { arg_711 = ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { arg_711 = linked_713.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_712, arg_715, arg_716) }; if linked_709 == nil { seq_1685000094__3 = ifn_710.Invoke_O__O(arg_711) } else { seq_1685000094__3 = linked_709.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_708, arg_711) }
//line :151:1
	var chunk_1685000095__4 any; var count_1685000096__5 int64 = 0; var i_1685000097__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000097__6, count_1685000096__5) { var vec__1685000098__7 any = lang.Indexed_Cast(chunk_1685000095__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000097__6)); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000101__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var tmp7 any = A_arbace_go_check_A_const_107; var tmp8 jrt.Number_I; var na_740 any = n__8; _ = ___10
			if jrt.Long_InstanceOf(na_740) { var n0_741 int64 = jrt.NN(jrt.Long_Cast(na_740)).LongValue__J(); if n0_741 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_740) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_741 + 1)) } } else { if jrt.Double_InstanceOf(na_740) { var n0_741_2 float64 = jrt.NN(jrt.Double_Cast(na_740)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_741_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_740) } }; tmp5.Invoke_O_O_O_O__O(nt__11, tmp6, tmp7, tmp8)
//line :158:1
			seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000097__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_717 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1685000094__3; if linked_718 == nil { temp__1927000414__auto____7 = ifn_719.Invoke_O__O(arg_720) } else { temp__1927000414__auto____7 = linked_718.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_717, arg_720) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000094__8 any = temp__1927000414__auto____7; var tmp9 any; var root_721 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = seq_1685000094__8; if linked_722 == nil { tmp9 = ifn_723.Invoke_O__O(arg_724) } else { tmp9 = linked_722.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_721, arg_724) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____9 any; var root_725 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1685000094__8; if linked_726 == nil { c__1927000678__auto____9 = ifn_727.Invoke_O__O(arg_728) } else { c__1927000678__auto____9 = linked_726.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_725, arg_728) }; var tmp10 any; var root_742 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = seq_1685000094__8; if linked_743 == nil { tmp10 = ifn_744.Invoke_O__O(arg_745) } else { tmp10 = linked_743.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_742, arg_745) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp10, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000104__9 any; var root_729 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_1685000094__8; if linked_730 == nil { vec__1685000104__9 = ifn_731.Invoke_O__O(arg_732) } else { vec__1685000104__9 = linked_730.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_729, arg_732) }; var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000107__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(1), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp12 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var tmp13 any = A_arbace_go_check_A_const_107; var tmp14 jrt.Number_I; var na_753 any = n__10; _ = ___12
				if jrt.Long_InstanceOf(na_753) { var n0_754 int64 = jrt.NN(jrt.Long_Cast(na_753)).LongValue__J(); if n0_754 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_753) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_754 + 1)) } } else { if jrt.Double_InstanceOf(na_753) { var n0_754_2 float64 = jrt.NN(jrt.Double_Cast(na_753)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_754_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_753) } }; tmp11.Invoke_O_O_O_O__O(nt__13, tmp12, tmp13, tmp14)
//line :158:1
				var tmp15 any; var root_755 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = seq_1685000094__8; if linked_756 == nil { tmp15 = ifn_757.Invoke_O__O(arg_758) } else { tmp15 = linked_756.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_755, arg_758) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :151:1*/panic("j2g: unreachable") }





func A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000083_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Invoke_O_O__O(self, p__1685000082__1 any) any { var vec__1685000084__2 any = p__1685000082__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(id__3, k__5) }
//line :157:1
func A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000089_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Invoke_O_O_O__O(self, k__1, p__1685000088__2 any) any { var vec__1685000090__3 any = p__1685000088__2; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(id__4, nt__5, k__1) }



func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000126__2 any) any { var map__1685000127__4 any = p__1685000126__2; var map__1685000127__5 any; if lang.ISeq_InstanceOf(map__1685000127__4) { var tmp1 any; var root_759 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = map__1685000127__4; if linked_760 == nil { tmp1 = ifn_761.Invoke_O__O(arg_762) } else { tmp1 = linked_760.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_759, arg_762) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_763 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = map__1685000127__4; if linked_764 == nil { tmp2 = ifn_765.Invoke_O__O(arg_766) } else { tmp2 = linked_764.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_763, arg_766) }; map__1685000127__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_767 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = map__1685000127__4; if linked_768 == nil { tmp3 = ifn_769.Invoke_O__O(arg_770) } else { tmp3 = linked_768.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_767, arg_770) }; if jrt.J2g_Truth(tmp3) { var root_771 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = map__1685000127__4; if linked_772 == nil { map__1685000127__5 = ifn_773.Invoke_O__O(arg_774) } else { map__1685000127__5 = linked_772.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_771, arg_774) } } else { map__1685000127__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000127__5 = map__1685000127__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000127__5, A_arbace_go_check_A_const_109); var pkg_scope__7 any; var root_775 any = A_arbace_go_check_A_const_73.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_777 lang.IFn; if




	linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var arg_779 any = A_arbace_go_check_A_const_110; if linked_776 == nil { pkg_scope__7 = ifn_777.Invoke_O_O__O(arg_778, arg_779) } else { pkg_scope__7 = linked_776.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_775, arg_778, arg_779) }; var pkg__8 any; var root_780 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_782 lang.IFn; if





	linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; var tmp4 any = A_arbace_go_check_A_const_111; var tmp5 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_71; var tmp7 any = A_arbace_go_check_A_const_71.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_72; var tmp9 any = A_arbace_go_check_A_const_112; var tmp10 any = A_arbace_go_check_A_const_112.Invoke_O__O(src__0); var tmp11 any = A_arbace_go_check_A_const_113; var tmp12 any; var root_784 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_786 lang.IFn; if
	linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = lang.PersistentVector_EMPTY.Ref(); if linked_785 == nil { tmp12 = ifn_786.Invoke_O__O(arg_787) } else { tmp12 = linked_785.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_784, arg_787) }; arg_783 = /*line :167:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, tmp10, tmp11, tmp12)); if linked_781 == nil { pkg__8 = ifn_782.Invoke_O__O(arg_783) } else { pkg__8 = linked_781.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_780, arg_783) }; var errors__9 any; var root_788 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_790 lang.IFn; if







	linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = lang.PersistentVector_EMPTY.Ref(); if linked_789 == nil { errors__9 = ifn_790.Invoke_O__O(arg_791) } else { errors__9 = linked_789.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_788, arg_791) }; var resolving__10 any; var root_792 any = /*line :161:1*/A_arbace_go_check_A_const_114.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_794 lang.IFn; if










	linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = A_arbace_go_check_A_const_115.Invoke_O__O(src__0); if linked_793 == nil { resolving__10 = ifn_794.Invoke_O__O(arg_795) } else { resolving__10 = linked_793.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_792, arg_795) }; var annotated__11 any; var and__1927000168__auto____11 any; var root_796 any = /*line :161:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_798 lang.IFn; if











	linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = A_arbace_go_check_A_const_82.Invoke_O__O(src__0); var arg_800 any = A_arbace_go_check_A_const_116; if linked_797 == nil { and__1927000168__auto____11 = ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { and__1927000168__auto____11 = linked_797.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_796, arg_799, arg_800) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_801 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = resolving__10; if linked_802 == nil { annotated__11 = ifn_803.Invoke_O__O(arg_804) } else { annotated__11 = linked_802.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_801, arg_804) } } else { annotated__11 = and__1927000168__auto____11 }; var ctx__12 any; var tmp13 any = A_arbace_go_check_A_const_117; var tmp14 any; var root_805 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_807 lang.IFn; if












	linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = lang.PersistentVector_EMPTY.Ref(); if linked_806 == nil { tmp14 = ifn_807.Invoke_O__O(arg_808) } else { tmp14 = linked_806.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_805, arg_808) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_118; var tmp17 any; var root_809 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_811 lang.IFn; if












	linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_810 == nil { tmp17 = ifn_811.Invoke_O__O(arg_812) } else { tmp17 = linked_810.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_809, arg_812) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_119; var tmp20 any; var root_813 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_815 lang.IFn; if












	linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = lang.PersistentVector_EMPTY.Ref(); if linked_814 == nil { tmp20 = ifn_815.Invoke_O__O(arg_816) } else { tmp20 = linked_814.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_813, arg_816) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_120; var tmp23 any; var root_817 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_819 lang.IFn; if












	linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = lang.PersistentVector_EMPTY.Ref(); if linked_818 == nil { tmp23 = ifn_819.Invoke_O__O(arg_820) } else { tmp23 = linked_818.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_817, arg_820) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_go_check_A_const_121; ctx__12 = /*line :161:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_61, annotated__11, A_arbace_go_check_A_const_122, resolving__10)))); var fis__13 any; var root_821 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_823 lang.IFn; if














	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any; var tmp26 any = A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(src__0, pkg_scope__7); var tmp27 *jrt.Class; var fncls__832 *jrt.Class = A_arbace_go_check_check_package_fn__1685000129_A_fn_class; if fncls__832 == nil { var fncls__832d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000129_A_fn_class = fncls__832d; tmp27 = fncls__832d } else { tmp27 = fncls__832 }; arg_824 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_825 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__0); if linked_822 == nil { fis__13 = ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { fis__13 = linked_822.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_821, arg_824, arg_825) }; var root_1290 any =
	A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp29 any = A_arbace_go_check_A_const_171; var tmp30 any = A_arbace_go_check_A_const_172; var tmp31 any = A_arbace_go_check_A_const_173; var tmp32 any = jrt.IdentityHashMap_New(); var tmp33 any = A_arbace_go_check_A_const_174; var tmp34 any = A_arbace_go_check_A_const_175; var tmp35 any = A_arbace_go_check_A_const_115.Invoke_O__O(src__0); var tmp36 any = A_arbace_go_check_A_const_176; var tmp37 any = jrt.Boolean_TRUE.Ref(); var tmp38 any = A_arbace_go_check_A_const_62; var tmp39 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_61, annotated__11, A_arbace_go_check_A_const_122, resolving__10)); var tmp40 any = A_arbace_go_check_A_const_177; var tmp41 any = A_arbace_go_check_A_const_178.GetRawRoot__O(); var tmp42 any = A_arbace_go_check_A_const_179; var tmp43 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var tmp44 any = A_arbace_go_check_A_const_181; var tmp45 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp46 any = A_arbace_go_check_A_const_182; var tmp47 any = A_arbace_go_check_A_const_183.GetRawRoot__O(); var tmp48 any = A_arbace_go_check_A_const_184; var tmp49 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var tmp50 any = A_arbace_go_check_A_const_186; var tmp51 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var tmp52 any = A_arbace_go_check_A_const_188; var tmp53 any = A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp54 *jrt.Class; var fncls__1298 *jrt.Class = A_arbace_go_check_check_package_fn__1685000131_A_fn_class; if












	fncls__1298 == nil { var fncls__1298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000131_A_fn_class = fncls__1298d; tmp54 = fncls__1298d } else { tmp54 = fncls__1298 }; var tmp55 any = /*line :177:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil); var tmp56 any = A_arbace_go_check_A_const_190; var tmp57 any = A_arbace_go_check_A_const_191.GetRawRoot__O(); var tmp58 any = A_arbace_go_check_A_const_192; var tmp59 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var tmp60 any = A_arbace_go_check_A_const_194; var tmp61 any = A_arbace_go_check_A_const_195.GetRawRoot__O(); var tmp62 any = A_arbace_go_check_A_const_196; var tmp63 any; var root_1299 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1301 lang.IFn; if

















	linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = lang.PersistentVector_EMPTY.Ref(); if linked_1300 == nil { tmp63 = ifn_1301.Invoke_O__O(arg_1302) } else { tmp63 = linked_1300.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1299, arg_1302) }; var tmp64 any = tmp63; var tmp65 any = A_arbace_go_check_A_const_197; var tmp66 any; var root_1303 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1305 lang.IFn; if


















	linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_198, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_199, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_200, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_201, lang.PersistentArrayMap_EMPTY.Ref())); if linked_1304 == nil { tmp66 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp66 = linked_1304.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1303, arg_1306) }; var tmp67 any = tmp66; var tmp68 any = A_arbace_go_check_A_const_202; var tmp69 any; var root_1307 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1309 lang.IFn; if



















	linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = lang.PersistentVector_EMPTY.Ref(); if linked_1308 == nil { tmp69 = ifn_1309.Invoke_O__O(arg_1310) } else { tmp69 = linked_1308.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1307, arg_1310) }; arg_1293 = /*line :177:1*/tmp28.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp29, pkg__8, tmp30, errors__9, tmp31, tmp32, tmp33, ctx__12, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp62, tmp64, tmp65, tmp67, tmp68, tmp69)))); if linked_1291 == nil { ifn_1292.Invoke_O__O(arg_1293) } else { linked_1291.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1290, arg_1293) }; var tmp70 any; tmp333 := /*line :161:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





































		if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, A_arbace_go_check_A_const_71.Invoke_O__O(src__0)) { var seq_1685000133__16 any; var root_1311 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1313 lang.IFn
			if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = fis__13; if linked_1312 == nil { seq_1685000133__16 = ifn_1313.Invoke_O__O(arg_1314) } else { seq_1685000133__16 = linked_1312.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1311, arg_1314) }
//line :199:1
			var chunk_1685000134__17 any; var count_1685000135__18 int64 = 0; var i_1685000136__19 int64 = 0; L1: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000136__19, count_1685000135__18) { var fi__20 any = lang.Indexed_Cast(chunk_1685000134__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000136__19)); var root_1394 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__20); var arg_1398 any; var or__1927000174__auto____21 any = A_arbace_go_check_A_const_79.Invoke_O__O(fi__20); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_1398 = or__1927000174__auto____21 } else { arg_1398 = A_arbace_go_check_A_const_43 }; var arg_1399 any = A_arbace_go_check_A_const_205; var arg_1400 any = Lit_58; if linked_1395 == nil { ifn_1396.Invoke_O_O_O_O__O(arg_1397, arg_1398, arg_1399, arg_1400) } else { linked_1395.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1394, arg_1397, arg_1398, arg_1399, arg_1400) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000136__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_1315 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = seq_1685000133__16; if linked_1316 == nil { temp__1927000414__auto____20 = ifn_1317.Invoke_O__O(arg_1318) } else { temp__1927000414__auto____20 = linked_1316.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1315, arg_1318) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000133__21 any = temp__1927000414__auto____20; var tmp71 any; var root_1319 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = seq_1685000133__21; if linked_1320 == nil { tmp71 = ifn_1321.Invoke_O__O(arg_1322) } else { tmp71 = linked_1320.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1319, arg_1322) }; if jrt.J2g_Truth(tmp71) { var c__1927000678__auto____22 any; var root_1323 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = seq_1685000133__21; if linked_1324 == nil { c__1927000678__auto____22 = ifn_1325.Invoke_O__O(arg_1326) } else { c__1927000678__auto____22 = linked_1324.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1323, arg_1326) }; var tmp72 any; var root_1401 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = seq_1685000133__21; if linked_1402 == nil { tmp72 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp72 = linked_1402.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1401, arg_1404) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp72, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__22 any; var root_1327 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = seq_1685000133__21; if linked_1328 == nil { fi__22 = ifn_1329.Invoke_O__O(arg_1330) } else { fi__22 = linked_1328.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1327, arg_1330) }; var root_1405 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__22); var arg_1409 any; var or__1927000174__auto____23 any = A_arbace_go_check_A_const_79.Invoke_O__O(fi__22); if jrt.J2g_Truth(or__1927000174__auto____23) { arg_1409 = or__1927000174__auto____23 } else { arg_1409 = A_arbace_go_check_A_const_43 }; var arg_1410 any = A_arbace_go_check_A_const_205; var arg_1411 any = Lit_58; if linked_1406 == nil { ifn_1407.Invoke_O_O_O_O__O(arg_1408, arg_1409, arg_1410, arg_1411) } else { linked_1406.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1405, arg_1408, arg_1409, arg_1410, arg_1411) }; var tmp73 any; var root_1412 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = seq_1685000133__21; if linked_1413 == nil { tmp73 = ifn_1414.Invoke_O__O(arg_1415) } else { tmp73 = linked_1413.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1412, arg_1415) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp73, nil, 0, 0; continue L1 } } }
//line :199:1
				break L1 } }
//line :161:1
		{ var seq_1685000137__16 any; var root_1331 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1333 lang.IFn







































			if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = fis__13; if linked_1332 == nil { seq_1685000137__16 = ifn_1333.Invoke_O__O(arg_1334) } else { seq_1685000137__16 = linked_1332.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1331, arg_1334) }
//line :161:1
			var chunk_1685000138__17 any; var count_1685000139__18 int64 = 0; var i_1685000140__19 int64 = 0; L2: for {







































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000140__19, count_1685000139__18) { var fi__20_2 any = lang.Indexed_Cast(chunk_1685000138__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000140__19)); var root_1416 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = fi__20_2; var arg_1420 any = resolve__1; if linked_1417 == nil { ifn_1418.Invoke_O_O__O(arg_1419, arg_1420) } else { linked_1417.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1416, arg_1419, arg_1420) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000140__19); continue L2 } else { var temp__1927000414__auto____20_2 any; var root_1335 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = seq_1685000137__16; if linked_1336 == nil { temp__1927000414__auto____20_2 = ifn_1337.Invoke_O__O(arg_1338) } else { temp__1927000414__auto____20_2 = linked_1336.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1335, arg_1338) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000137__21 any = temp__1927000414__auto____20_2; var tmp74 any; var root_1339 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = seq_1685000137__21; if linked_1340 == nil { tmp74 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp74 = linked_1340.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1339, arg_1342) }; if jrt.J2g_Truth(tmp74) { var c__1927000678__auto____22_2 any; var root_1343 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = seq_1685000137__21; if linked_1344 == nil { c__1927000678__auto____22_2 = ifn_1345.Invoke_O__O(arg_1346) } else { c__1927000678__auto____22_2 = linked_1344.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1343, arg_1346) }; var tmp75 any; var root_1421 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = seq_1685000137__21; if linked_1422 == nil { tmp75 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp75 = linked_1422.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1421, arg_1424) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp75, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__22_2 any; var root_1347 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = seq_1685000137__21; if linked_1348 == nil { fi__22_2 = ifn_1349.Invoke_O__O(arg_1350) } else { fi__22_2 = linked_1348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1347, arg_1350) }; var root_1425 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = fi__22_2; var arg_1429 any = resolve__1; if linked_1426 == nil { ifn_1427.Invoke_O_O__O(arg_1428, arg_1429) } else { linked_1426.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1425, arg_1428, arg_1429) }; var tmp76 any; var root_1430 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = seq_1685000137__21; if linked_1431 == nil { tmp76 = ifn_1432.Invoke_O__O(arg_1433) } else { tmp76 = linked_1431.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1430, arg_1433) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp76, nil, 0, 0; continue L2 } } }
//line :161:1
				break L2 }; var seq_1685000141__16 any; var root_1351 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1353 lang.IFn








































			if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = fis__13; if linked_1352 == nil { seq_1685000141__16 = ifn_1353.Invoke_O__O(arg_1354) } else { seq_1685000141__16 = linked_1352.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1351, arg_1354) }
//line :161:1
			var chunk_1685000142__17 any; var count_1685000143__18 int64 = 0; var i_1685000144__19 int64 = 0; L3: for {








































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000144__19, count_1685000143__18) { var fi__20_3 any = lang.Indexed_Cast(chunk_1685000142__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000144__19)); var root_1434 any = A_arbace_go_check_A_const_207.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = fi__20_3; if linked_1435 == nil { ifn_1436.Invoke_O__O(arg_1437) } else { linked_1435.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1434, arg_1437) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000144__19); continue L3 } else { var temp__1927000414__auto____20_3 any; var root_1355 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = seq_1685000141__16; if linked_1356 == nil { temp__1927000414__auto____20_3 = ifn_1357.Invoke_O__O(arg_1358) } else { temp__1927000414__auto____20_3 = linked_1356.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1355, arg_1358) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000141__21 any = temp__1927000414__auto____20_3; var tmp77 any; var root_1359 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = seq_1685000141__21; if linked_1360 == nil { tmp77 = ifn_1361.Invoke_O__O(arg_1362) } else { tmp77 = linked_1360.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1359, arg_1362) }; if jrt.J2g_Truth(tmp77) { var c__1927000678__auto____22_3 any; var root_1363 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = seq_1685000141__21; if linked_1364 == nil { c__1927000678__auto____22_3 = ifn_1365.Invoke_O__O(arg_1366) } else { c__1927000678__auto____22_3 = linked_1364.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1363, arg_1366) }; var tmp78 any; var root_1438 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = seq_1685000141__21; if linked_1439 == nil { tmp78 = ifn_1440.Invoke_O__O(arg_1441) } else { tmp78 = linked_1439.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1438, arg_1441) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp78, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__22_3 any; var root_1367 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = seq_1685000141__21; if linked_1368 == nil { fi__22_3 = ifn_1369.Invoke_O__O(arg_1370) } else { fi__22_3 = linked_1368.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1367, arg_1370) }; var root_1442 any = A_arbace_go_check_A_const_207.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = fi__22_3; if linked_1443 == nil { ifn_1444.Invoke_O__O(arg_1445) } else { linked_1443.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1442, arg_1445) }; var tmp79 any; var root_1446 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = seq_1685000141__21; if linked_1447 == nil { tmp79 = ifn_1448.Invoke_O__O(arg_1449) } else { tmp79 = linked_1447.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1446, arg_1449) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp79, nil, 0, 0; continue L3 } } }
//line :161:1
				break L3 }; var seq_1685000145__16 any; var root_1371 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1373 lang.IFn









































			if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = fis__13; if linked_1372 == nil { seq_1685000145__16 = ifn_1373.Invoke_O__O(arg_1374) } else { seq_1685000145__16 = linked_1372.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1371, arg_1374) }
//line :161:1
			var chunk_1685000146__17 any; var count_1685000147__18 int64 = 0; var i_1685000148__19 int64 = 0; L4: for {









































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000148__19, count_1685000147__18) { var fi__20_4 any = lang.Indexed_Cast(chunk_1685000146__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000148__19)); var root_1450 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = fi__20_4; if linked_1451 == nil { ifn_1452.Invoke_O__O(arg_1453) } else { linked_1451.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1450, arg_1453) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000148__19); continue L4 } else { var temp__1927000414__auto____20_4 any; var root_1375 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = seq_1685000145__16; if linked_1376 == nil { temp__1927000414__auto____20_4 = ifn_1377.Invoke_O__O(arg_1378) } else { temp__1927000414__auto____20_4 = linked_1376.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1375, arg_1378) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000145__21 any = temp__1927000414__auto____20_4; var tmp80 any; var root_1379 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = seq_1685000145__21; if linked_1380 == nil { tmp80 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp80 = linked_1380.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1379, arg_1382) }; if jrt.J2g_Truth(tmp80) { var c__1927000678__auto____22_4 any; var root_1383 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = seq_1685000145__21; if linked_1384 == nil { c__1927000678__auto____22_4 = ifn_1385.Invoke_O__O(arg_1386) } else { c__1927000678__auto____22_4 = linked_1384.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1383, arg_1386) }; var tmp81 any; var root_1454 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = seq_1685000145__21; if linked_1455 == nil { tmp81 = ifn_1456.Invoke_O__O(arg_1457) } else { tmp81 = linked_1455.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1454, arg_1457) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp81, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var fi__22_4 any; var root_1387 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = seq_1685000145__21; if linked_1388 == nil { fi__22_4 = ifn_1389.Invoke_O__O(arg_1390) } else { fi__22_4 = linked_1388.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1387, arg_1390) }; var root_1458 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = fi__22_4; if linked_1459 == nil { ifn_1460.Invoke_O__O(arg_1461) } else { linked_1459.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1458, arg_1461) }; var tmp82 any; var root_1462 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = seq_1685000145__21; if linked_1463 == nil { tmp82 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp82 = linked_1463.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1462, arg_1465) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp82, nil, 0, 0; continue L4 } } }
//line :161:1
				break L4
			}









































			var root_1391 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; if linked_1392 == nil { ifn_1393.Invoke__O() } else { linked_1392.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1391) }
//line :161:1
			var objs__16 any; var root_833 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_835 lang.IFn











































			if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = A_arbace_go_check_A_const_117.Invoke_O__O(ctx__12); if linked_834 == nil { objs__16 = ifn_835.Invoke_O__O(arg_836) } else { objs__16 = linked_834.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_833, arg_836) }
//line :161:1
			var seq_1685000149__17 any; var root_1466 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1468 lang.IFn












































			if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any; var root_1470 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = A_arbace_go_check_A_const_104.GetRawRoot__O(); var arg_1474 any = objs__16; if linked_1471 == nil { arg_1469 = ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { arg_1469 = linked_1471.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) }; if linked_1467 == nil { seq_1685000149__17 = ifn_1468.Invoke_O__O(arg_1469) } else { seq_1685000149__17 = linked_1467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1466, arg_1469) }
//line :161:1
			var chunk_1685000150__18 any; var count_1685000151__19 int64 = 0; var i_1685000152__20 int64 = 0; L5: for {












































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000152__20, count_1685000151__19) { var vec__1685000153__21 any = lang.Indexed_Cast(chunk_1685000150__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000152__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000153__21, lang.RT_IntCast_J__I_NoInit(0), nil); var x__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000153__21, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1668 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = x__23; var arg_1672 any = A_arbace_go_check_A_const_212; var arg_1673 any = i__22; if linked_1669 == nil { ifn_1670.Invoke_O_O_O__O(arg_1671, arg_1672, arg_1673) } else { linked_1669.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1668, arg_1671, arg_1672, arg_1673) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000152__20); continue L5 } else { var temp__1927000414__auto____21 any; var root_1475 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = seq_1685000149__17; if linked_1476 == nil { temp__1927000414__auto____21 = ifn_1477.Invoke_O__O(arg_1478) } else { temp__1927000414__auto____21 = linked_1476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1475, arg_1478) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000149__22 any = temp__1927000414__auto____21; var tmp83 any; var root_1479 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = seq_1685000149__22; if linked_1480 == nil { tmp83 = ifn_1481.Invoke_O__O(arg_1482) } else { tmp83 = linked_1480.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1479, arg_1482) }; if jrt.J2g_Truth(tmp83) { var c__1927000678__auto____23 any; var root_1483 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = seq_1685000149__22; if linked_1484 == nil { c__1927000678__auto____23 = ifn_1485.Invoke_O__O(arg_1486) } else { c__1927000678__auto____23 = linked_1484.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1483, arg_1486) }; var tmp84 any; var root_1674 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = seq_1685000149__22; if linked_1675 == nil { tmp84 = ifn_1676.Invoke_O__O(arg_1677) } else { tmp84 = linked_1675.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1674, arg_1677) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = tmp84, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1685000156__23 any; var root_1487 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = seq_1685000149__22; if linked_1488 == nil { vec__1685000156__23 = ifn_1489.Invoke_O__O(arg_1490) } else { vec__1685000156__23 = linked_1488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1487, arg_1490) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000156__23, lang.RT_IntCast_J__I_NoInit(0), nil); var x__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000156__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1678 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = x__25; var arg_1682 any = A_arbace_go_check_A_const_212; var arg_1683 any = i__24; if linked_1679 == nil { ifn_1680.Invoke_O_O_O__O(arg_1681, arg_1682, arg_1683) } else { linked_1679.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1678, arg_1681, arg_1682, arg_1683) }; var tmp85 any; var root_1684 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = seq_1685000149__22; if linked_1685 == nil { tmp85 = ifn_1686.Invoke_O__O(arg_1687) } else { tmp85 = linked_1685.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1684, arg_1687) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = tmp85, nil, 0, 0; continue L5 } } }
//line :161:1
				break L5
			}













































			var root_1491 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = objs__16; if linked_1492 == nil { ifn_1493.Invoke_O__O(arg_1494) } else { linked_1492.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A).Invoke_O_O__O(root_1491, arg_1494) }
//line :161:1
			var seq_1685000159__17 any; var root_1495 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1497 lang.IFn
















































			if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = objs__16; if linked_1496 == nil { seq_1685000159__17 = ifn_1497.Invoke_O__O(arg_1498) } else { seq_1685000159__17 = linked_1496.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1495, arg_1498) }
//line :161:1
			var chunk_1685000160__18 any; var count_1685000161__19 int64 = 0; var i_1685000162__20 int64 = 0; L6: for {
















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000162__20, count_1685000161__19) { var x__21 any = lang.Indexed_Cast(chunk_1685000160__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000162__20)); var tmp86 any; var and__1927000168__auto____22 bool; var tmp87 any = A_arbace_go_check_A_const_55; var tmp88 any; var root_1499 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = x__21; var arg_1503 any = A_arbace_go_check_A_const_94; if linked_1500 == nil { tmp88 = ifn_1501.Invoke_O_O__O(arg_1502, arg_1503) } else { tmp88 = linked_1500.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1499, arg_1502, arg_1503) }; and__1927000168__auto____22 = lang.Util_Equiv_O_O__Z_NoInit(tmp87, tmp88); if and__1927000168__auto____22 { var root_1504 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any; var root_1508 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = x__21; var arg_1512 any = A_arbace_go_check_A_const_210; if linked_1509 == nil { arg_1507 = ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { arg_1507 = linked_1509.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) }; if linked_1505 == nil { tmp86 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp86 = linked_1505.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1504, arg_1507) } } else { tmp86 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22).Ref() }; if jrt.J2g_Truth(tmp86) { var root_1688 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = x__21; if linked_1689 == nil { ifn_1690.Invoke_O__O(arg_1691) } else { linked_1689.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1688, arg_1691) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } else { seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } } else { var temp__1927000414__auto____21_2 any; var root_1513 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = seq_1685000159__17; if linked_1514 == nil { temp__1927000414__auto____21_2 = ifn_1515.Invoke_O__O(arg_1516) } else { temp__1927000414__auto____21_2 = linked_1514.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1513, arg_1516) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000159__22 any = temp__1927000414__auto____21_2; var tmp89 any; var root_1517 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = seq_1685000159__22; if linked_1518 == nil { tmp89 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp89 = linked_1518.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1517, arg_1520) }; if jrt.J2g_Truth(tmp89) { var c__1927000678__auto____23_2 any; var root_1521 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = seq_1685000159__22; if linked_1522 == nil { c__1927000678__auto____23_2 = ifn_1523.Invoke_O__O(arg_1524) } else { c__1927000678__auto____23_2 = linked_1522.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1521, arg_1524) }; var tmp90 any; var root_1692 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = seq_1685000159__22; if linked_1693 == nil { tmp90 = ifn_1694.Invoke_O__O(arg_1695) } else { tmp90 = linked_1693.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1692, arg_1695) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp90, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__23_2 any; var root_1525 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = seq_1685000159__22; if linked_1526 == nil { x__23_2 = ifn_1527.Invoke_O__O(arg_1528) } else { x__23_2 = linked_1526.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1525, arg_1528) }; var tmp91 any; var and__1927000168__auto____24 bool; var tmp92 any = A_arbace_go_check_A_const_55; var tmp93 any; var root_1529 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = x__23_2; var arg_1533 any = A_arbace_go_check_A_const_94; if linked_1530 == nil { tmp93 = ifn_1531.Invoke_O_O__O(arg_1532, arg_1533) } else { tmp93 = linked_1530.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1529, arg_1532, arg_1533) }; and__1927000168__auto____24 = lang.Util_Equiv_O_O__Z_NoInit(tmp92, tmp93); if and__1927000168__auto____24 { var root_1534 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any; var root_1538 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = x__23_2; var arg_1542 any = A_arbace_go_check_A_const_210; if linked_1539 == nil { arg_1537 = ifn_1540.Invoke_O_O__O(arg_1541, arg_1542) } else { arg_1537 = linked_1539.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1538, arg_1541, arg_1542) }; if linked_1535 == nil { tmp91 = ifn_1536.Invoke_O__O(arg_1537) } else { tmp91 = linked_1535.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1534, arg_1537) } } else { tmp91 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24).Ref() }; if jrt.J2g_Truth(tmp91) { var root_1696 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = x__23_2; if linked_1697 == nil { ifn_1698.Invoke_O__O(arg_1699) } else { linked_1697.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1696, arg_1699) }; var tmp94 any; var root_1700 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = seq_1685000159__22; if linked_1701 == nil { tmp94 = ifn_1702.Invoke_O__O(arg_1703) } else { tmp94 = linked_1701.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1700, arg_1703) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp94, nil, 0, 0; continue L6 } else { var tmp95 any; var root_1704 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = seq_1685000159__22; if linked_1705 == nil { tmp95 = ifn_1706.Invoke_O__O(arg_1707) } else { tmp95 = linked_1705.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1704, arg_1707) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp95, nil, 0, 0; continue L6 } } } }
//line :161:1
				break L6 }; var seq_1685000163__17 any; var root_1543 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1545 lang.IFn

















































			if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = objs__16; if linked_1544 == nil { seq_1685000163__17 = ifn_1545.Invoke_O__O(arg_1546) } else { seq_1685000163__17 = linked_1544.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1543, arg_1546) }
//line :161:1
			var chunk_1685000164__18 any; var count_1685000165__19 int64 = 0; var i_1685000166__20 int64 = 0; L7: for {

















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000166__20, count_1685000165__19) { var x__21_2 any = lang.Indexed_Cast(chunk_1685000164__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000166__20)); var tmp96 any; var and__1927000168__auto____22_2 bool; var tmp97 any = A_arbace_go_check_A_const_55; var tmp98 any; var root_1547 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = x__21_2; var arg_1551 any = A_arbace_go_check_A_const_94; if linked_1548 == nil { tmp98 = ifn_1549.Invoke_O_O__O(arg_1550, arg_1551) } else { tmp98 = linked_1548.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1547, arg_1550, arg_1551) }; and__1927000168__auto____22_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp97, tmp98); if and__1927000168__auto____22_2 { var root_1552 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = x__21_2; var arg_1556 any = A_arbace_go_check_A_const_210; if linked_1553 == nil { tmp96 = ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { tmp96 = linked_1553.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) } } else { tmp96 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22_2).Ref() }; if jrt.J2g_Truth(tmp96) { var root_1708 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = x__21_2; if linked_1709 == nil { ifn_1710.Invoke_O__O(arg_1711) } else { linked_1709.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1708, arg_1711) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } else { seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } } else { var temp__1927000414__auto____21_3 any; var root_1557 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = seq_1685000163__17; if linked_1558 == nil { temp__1927000414__auto____21_3 = ifn_1559.Invoke_O__O(arg_1560) } else { temp__1927000414__auto____21_3 = linked_1558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1557, arg_1560) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000163__22 any = temp__1927000414__auto____21_3; var tmp99 any; var root_1561 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = seq_1685000163__22; if linked_1562 == nil { tmp99 = ifn_1563.Invoke_O__O(arg_1564) } else { tmp99 = linked_1562.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1561, arg_1564) }; if jrt.J2g_Truth(tmp99) { var c__1927000678__auto____23_3 any; var root_1565 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = seq_1685000163__22; if linked_1566 == nil { c__1927000678__auto____23_3 = ifn_1567.Invoke_O__O(arg_1568) } else { c__1927000678__auto____23_3 = linked_1566.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1565, arg_1568) }; var tmp100 any; var root_1712 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = seq_1685000163__22; if linked_1713 == nil { tmp100 = ifn_1714.Invoke_O__O(arg_1715) } else { tmp100 = linked_1713.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1712, arg_1715) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp100, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__23_3 any; var root_1569 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = seq_1685000163__22; if linked_1570 == nil { x__23_3 = ifn_1571.Invoke_O__O(arg_1572) } else { x__23_3 = linked_1570.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1569, arg_1572) }; var tmp101 any; var and__1927000168__auto____24_2 bool; var tmp102 any = A_arbace_go_check_A_const_55; var tmp103 any; var root_1573 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = x__23_3; var arg_1577 any = A_arbace_go_check_A_const_94; if linked_1574 == nil { tmp103 = ifn_1575.Invoke_O_O__O(arg_1576, arg_1577) } else { tmp103 = linked_1574.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1573, arg_1576, arg_1577) }; and__1927000168__auto____24_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp102, tmp103); if and__1927000168__auto____24_2 { var root_1578 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = x__23_3; var arg_1582 any = A_arbace_go_check_A_const_210; if linked_1579 == nil { tmp101 = ifn_1580.Invoke_O_O__O(arg_1581, arg_1582) } else { tmp101 = linked_1579.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1578, arg_1581, arg_1582) } } else { tmp101 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24_2).Ref() }; if jrt.J2g_Truth(tmp101) { var root_1716 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = x__23_3; if linked_1717 == nil { ifn_1718.Invoke_O__O(arg_1719) } else { linked_1717.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1716, arg_1719) }; var tmp104 any; var root_1720 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = seq_1685000163__22; if linked_1721 == nil { tmp104 = ifn_1722.Invoke_O__O(arg_1723) } else { tmp104 = linked_1721.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1720, arg_1723) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp104, nil, 0, 0; continue L7 } else { var tmp105 any; var root_1724 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = seq_1685000163__22; if linked_1725 == nil { tmp105 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp105 = linked_1725.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1724, arg_1727) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp105, nil, 0, 0; continue L7 } } } }
//line :161:1
				break L7 }; var seq_1685000167__17 any; var root_1583 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1585 lang.IFn


















































			if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = objs__16; if linked_1584 == nil { seq_1685000167__17 = ifn_1585.Invoke_O__O(arg_1586) } else { seq_1685000167__17 = linked_1584.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1583, arg_1586) }
//line :161:1
			var chunk_1685000168__18 any; var count_1685000169__19 int64 = 0; var i_1685000170__20 int64 = 0; L8: for {


















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000170__20, count_1685000169__19) { var x__21_3 any = lang.Indexed_Cast(chunk_1685000168__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000170__20)); var tmp106 any; var root_1587 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = A_arbace_go_check_A_const_55; var arg_1591 any; var root_1592 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = x__21_3; var arg_1596 any = A_arbace_go_check_A_const_94; if linked_1593 == nil { arg_1591 = ifn_1594.Invoke_O_O__O(arg_1595, arg_1596) } else { arg_1591 = linked_1593.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1592, arg_1595, arg_1596) }; if linked_1588 == nil { tmp106 = ifn_1589.Invoke_O_O__O(arg_1590, arg_1591) } else { tmp106 = linked_1588.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1587, arg_1590, arg_1591) }; if jrt.J2g_Truth(tmp106) { var root_1728 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = x__21_3; if linked_1729 == nil { ifn_1730.Invoke_O__O(arg_1731) } else { linked_1729.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1728, arg_1731) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } else { seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } } else { var temp__1927000414__auto____21_4 any; var root_1597 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = seq_1685000167__17; if linked_1598 == nil { temp__1927000414__auto____21_4 = ifn_1599.Invoke_O__O(arg_1600) } else { temp__1927000414__auto____21_4 = linked_1598.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1597, arg_1600) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000167__22 any = temp__1927000414__auto____21_4; var tmp107 any; var root_1601 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = seq_1685000167__22; if linked_1602 == nil { tmp107 = ifn_1603.Invoke_O__O(arg_1604) } else { tmp107 = linked_1602.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1601, arg_1604) }; if jrt.J2g_Truth(tmp107) { var c__1927000678__auto____23_4 any; var root_1605 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = seq_1685000167__22; if linked_1606 == nil { c__1927000678__auto____23_4 = ifn_1607.Invoke_O__O(arg_1608) } else { c__1927000678__auto____23_4 = linked_1606.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1605, arg_1608) }; var tmp108 any; var root_1732 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = seq_1685000167__22; if linked_1733 == nil { tmp108 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp108 = linked_1733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1732, arg_1735) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp108, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__23_4 any; var root_1609 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = seq_1685000167__22; if linked_1610 == nil { x__23_4 = ifn_1611.Invoke_O__O(arg_1612) } else { x__23_4 = linked_1610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1609, arg_1612) }; var tmp109 any; var root_1613 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = A_arbace_go_check_A_const_55; var arg_1617 any; var root_1618 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = x__23_4; var arg_1622 any = A_arbace_go_check_A_const_94; if linked_1619 == nil { arg_1617 = ifn_1620.Invoke_O_O__O(arg_1621, arg_1622) } else { arg_1617 = linked_1619.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1618, arg_1621, arg_1622) }; if linked_1614 == nil { tmp109 = ifn_1615.Invoke_O_O__O(arg_1616, arg_1617) } else { tmp109 = linked_1614.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1613, arg_1616, arg_1617) }; if jrt.J2g_Truth(tmp109) { var root_1736 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = x__23_4; if linked_1737 == nil { ifn_1738.Invoke_O__O(arg_1739) } else { linked_1737.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1736, arg_1739) }; var tmp110 any; var root_1740 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = seq_1685000167__22; if linked_1741 == nil { tmp110 = ifn_1742.Invoke_O__O(arg_1743) } else { tmp110 = linked_1741.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1740, arg_1743) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp110, nil, 0, 0; continue L8 } else { var tmp111 any; var root_1744 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = seq_1685000167__22; if linked_1745 == nil { tmp111 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp111 = linked_1745.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1744, arg_1747) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp111, nil, 0, 0; continue L8 } } } }
//line :161:1
				break L8 }; var seq_1685000171__17 any; var root_1623 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1625 lang.IFn




















































			if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any; var root_1627 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = A_arbace_go_check_A_const_119.Invoke_O__O(ctx__12); if linked_1628 == nil { arg_1626 = ifn_1629.Invoke_O__O(arg_1630) } else { arg_1626 = linked_1628.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1627, arg_1630) }; if linked_1624 == nil { seq_1685000171__17 = ifn_1625.Invoke_O__O(arg_1626) } else { seq_1685000171__17 = linked_1624.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1623, arg_1626) }
//line :161:1
			var chunk_1685000172__18 any; var count_1685000173__19 int64 = 0; var i_1685000174__20 int64 = 0; L9: for {




















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000174__20, count_1685000173__19) { var x__21_4 any = lang.Indexed_Cast(chunk_1685000172__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000174__20)); var root_1748 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = x__21_4; if linked_1749 == nil { ifn_1750.Invoke_O__O(arg_1751) } else { linked_1749.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1748, arg_1751) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000174__20); continue L9 } else { var temp__1927000414__auto____21_5 any; var root_1631 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = seq_1685000171__17; if linked_1632 == nil { temp__1927000414__auto____21_5 = ifn_1633.Invoke_O__O(arg_1634) } else { temp__1927000414__auto____21_5 = linked_1632.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1631, arg_1634) }; if jrt.J2g_Truth(temp__1927000414__auto____21_5) { var seq_1685000171__22 any = temp__1927000414__auto____21_5; var tmp112 any; var root_1635 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = seq_1685000171__22; if linked_1636 == nil { tmp112 = ifn_1637.Invoke_O__O(arg_1638) } else { tmp112 = linked_1636.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1635, arg_1638) }; if jrt.J2g_Truth(tmp112) { var c__1927000678__auto____23_5 any; var root_1639 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = seq_1685000171__22; if linked_1640 == nil { c__1927000678__auto____23_5 = ifn_1641.Invoke_O__O(arg_1642) } else { c__1927000678__auto____23_5 = linked_1640.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1639, arg_1642) }; var tmp113 any; var root_1752 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = seq_1685000171__22; if linked_1753 == nil { tmp113 = ifn_1754.Invoke_O__O(arg_1755) } else { tmp113 = linked_1753.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1752, arg_1755) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp113, c__1927000678__auto____23_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L9 } else { var x__23_5 any; var root_1643 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = seq_1685000171__22; if linked_1644 == nil { x__23_5 = ifn_1645.Invoke_O__O(arg_1646) } else { x__23_5 = linked_1644.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1643, arg_1646) }; var root_1756 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any = x__23_5; if linked_1757 == nil { ifn_1758.Invoke_O__O(arg_1759) } else { linked_1757.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1756, arg_1759) }; var tmp114 any; var root_1760 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = seq_1685000171__22; if linked_1761 == nil { tmp114 = ifn_1762.Invoke_O__O(arg_1763) } else { tmp114 = linked_1761.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1760, arg_1763) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp114, nil, 0, 0; continue L9 } } }
//line :161:1
				break L9 }; L10: for { var vs__17 any; var root_1647 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1649 lang.IFn























































					if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = A_arbace_go_check_A_const_196.Get__O(); if linked_1648 == nil { vs__17 = ifn_1649.Invoke_O__O(arg_1650) } else { vs__17 = linked_1648.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1647, arg_1650) }
					var tmp115 any; var root_1651 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = vs__17; if linked_1652 == nil { tmp115 = ifn_1653.Invoke_O__O(arg_1654) } else { tmp115 = linked_1652.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1651, arg_1654) }; if jrt.J2g_Truth(tmp115) {
						var root_1764 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = A_arbace_go_check_A_const_196.Get__O(); var arg_1768 any = lang.PersistentVector_EMPTY.Ref(); if linked_1765 == nil { ifn_1766.Invoke_O_O__O(arg_1767, arg_1768) } else { linked_1765.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1764, arg_1767, arg_1768) }
//line :218:1
						var seq_1685000175__18 any; var root_1769 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1771 lang.IFn

						if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = vs__17; if linked_1770 == nil { seq_1685000175__18 = ifn_1771.Invoke_O__O(arg_1772) } else { seq_1685000175__18 = linked_1770.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1769, arg_1772) }
//line :218:1
						var chunk_1685000176__19 any; var count_1685000177__20 int64 = 0; var i_1685000178__21 int64 = 0; L11: for {

							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000178__21, count_1685000177__20) { var v__22 any = lang.Indexed_Cast(chunk_1685000176__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000178__21)); lang.IFn_Cast(v__22).Invoke__O(); seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000178__21); continue L11 } else { var temp__1927000414__auto____22 any; var root_1773 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = seq_1685000175__18; if linked_1774 == nil { temp__1927000414__auto____22 = ifn_1775.Invoke_O__O(arg_1776) } else { temp__1927000414__auto____22 = linked_1774.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1773, arg_1776) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1685000175__23 any = temp__1927000414__auto____22; var tmp116 any; var root_1777 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = seq_1685000175__23; if linked_1778 == nil { tmp116 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp116 = linked_1778.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1777, arg_1780) }; if jrt.J2g_Truth(tmp116) { var c__1927000678__auto____24 any; var root_1781 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = seq_1685000175__23; if linked_1782 == nil { c__1927000678__auto____24 = ifn_1783.Invoke_O__O(arg_1784) } else { c__1927000678__auto____24 = linked_1782.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1781, arg_1784) }; var tmp117 any; var root_1789 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = seq_1685000175__23; if linked_1790 == nil { tmp117 = ifn_1791.Invoke_O__O(arg_1792) } else { tmp117 = linked_1790.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1789, arg_1792) }; seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = tmp117, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var v__24 any; var root_1785 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = seq_1685000175__23; if linked_1786 == nil { v__24 = ifn_1787.Invoke_O__O(arg_1788) } else { v__24 = linked_1786.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1785, arg_1788) }; lang.IFn_Cast(v__24).Invoke__O(); var tmp118 any; var root_1793 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = seq_1685000175__23; if linked_1794 == nil { tmp118 = ifn_1795.Invoke_O__O(arg_1796) } else { tmp118 = linked_1794.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1793, arg_1796) }; seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = tmp118, nil, 0, 0; continue L11 } } }
//line :218:1
							break L11
						}

						continue L10 }
//line :161:1
					break L10
				}



























































			var root_1655 any = A_arbace_go_check_A_const_211.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, A_arbace_go_check_number_local_types_BANG__A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any; var root_1659 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1659, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1661 lang.IFn; if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any; var root_1663 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = pkg__8; var arg_1667 any = A_arbace_go_check_A_const_113; if linked_1664 == nil { arg_1662 = ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { arg_1662 = linked_1664.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) }; if linked_1660 == nil { arg_1658 = ifn_1661.Invoke_O__O(arg_1662) } else { arg_1658 = linked_1660.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1659, arg_1662) }; if linked_1656 == nil { ifn_1657.Invoke_O__O(arg_1658) } else { linked_1656.(*A_arbace_go_check_number_local_types_BANG__A).Invoke_O_O__O(root_1655, arg_1658) }
//line :161:1
			var decls__17 any; var root_837 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_839 lang.IFn





























































			if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var root_841 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var tmp119 any = A_arbace_go_check_check_package_fn__1685000179_A_New(); var tmp120 *jrt.Class; var fncls__851 *jrt.Class = A_arbace_go_check_check_package_fn__1685000179_A_fn_class; if fncls__851 == nil { var fncls__851d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_check_package_fn__1685000179_A_fn_class = fncls__851d; tmp120 = fncls__851d } else { tmp120 = fncls__851 }; arg_844 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp119, tmp120, nil); var arg_845 any = objs__16; if linked_842 == nil { arg_840 = ifn_843.Invoke_O_O__O(arg_844, arg_845) } else { arg_840 = linked_842.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_841, arg_844, arg_845) }; if linked_838 == nil { decls__17 = ifn_839.Invoke_O__O(arg_840) } else { decls__17 = linked_838.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_837, arg_840) }
//line :161:1
			var seq_1685000181__18 any; var root_1797 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1799 lang.IFn






























































			if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = decls__17; if linked_1798 == nil { seq_1685000181__18 = ifn_1799.Invoke_O__O(arg_1800) } else { seq_1685000181__18 = linked_1798.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1797, arg_1800) }
//line :161:1
			var chunk_1685000182__19 any; var count_1685000183__20 int64 = 0; var i_1685000184__21 int64 = 0; L12: for {






























































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000184__21, count_1685000183__20) { var d__22 any = lang.Indexed_Cast(chunk_1685000182__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000184__21)); L13: for { var ls__23 any; var tmp121 *lang.Keyword = A_arbace_go_check_A_const_216; var tmp122 any; var root_1921 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1923 lang.IFn

					if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = d__22; if linked_1922 == nil { tmp122 = ifn_1923.Invoke_O__O(arg_1924) } else { tmp122 = linked_1922.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1921, arg_1924) }; ls__23 = tmp121.Invoke_O__O(tmp122)
					var tmp123 any; var root_1925 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = ls__23; if linked_1926 == nil { tmp123 = ifn_1927.Invoke_O__O(arg_1928) } else { tmp123 = linked_1926.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1925, arg_1928) }; if jrt.J2g_Truth(tmp123) {
						var tmp124 *lang.Volatile = lang.Volatile_Cast(d__22); var tmp125 any; var root_1929 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = jrt.NN(lang.Volatile_Cast(d__22)).Deref__O(); var arg_1933 any = A_arbace_go_check_A_const_216; var arg_1934 any = lang.PersistentVector_EMPTY.Ref(); if linked_1930 == nil { tmp125 = ifn_1931.Invoke_O_O_O__O(arg_1932, arg_1933, arg_1934) } else { tmp125 = linked_1930.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1929, arg_1932, arg_1933, arg_1934) }; jrt.NN(tmp124).Reset_O__O(tmp125)
						var root_1981 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any; var tmp126 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp127 any = A_arbace_go_check_A_const_220; var tmp128 any = A_arbace_go_check_A_const_221; var tmp129 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp130 any; var root_1994 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = d__22; if linked_1995 == nil { tmp130 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp130 = linked_1995.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1994, arg_1997) }; var tmp131 any = tmp129.Invoke_O__O(tmp130); var tmp132 any = A_arbace_go_check_A_const_222; var tmp133 any; var G__1685000185__24_ any; var tmp134 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp135 any; var root_1998 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = d__22; if linked_1999 == nil { tmp135 = ifn_2000.Invoke_O__O(arg_2001) } else { tmp135 = linked_1999.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1998, arg_2001) }; G__1685000185__24_ = tmp134.Invoke_O__O(tmp135); if lang.Util_Identical_O_O__Z_NoInit(G__1685000185__24_, nil) { tmp133 = nil } else { var root_2002 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = G__1685000185__24_; var arg_2006 any = A_arbace_go_check_A_const_79; if linked_2003 == nil { tmp133 = ifn_2004.Invoke_O_O__O(arg_2005, arg_2006) } else { tmp133 = linked_2003.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2002, arg_2005, arg_2006) } }; arg_1984 = tmp126.Invoke_O_O_O_O_O_O__O(tmp127, d__22, tmp128, tmp131, tmp132, tmp133); if linked_1982 == nil { ifn_1983.Invoke_O__O(arg_1984) } else { linked_1982.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1981, arg_1984) }; var tmp136 any = A_arbace_go_check_check_package_fn__1685000186_A_New_O_O(d__22, ls__23); var tmp137 *jrt.Class; var fncls__1980 *jrt.Class = A_arbace_go_check_check_package_fn__1685000186_A_fn_class; if fncls__1980 == nil { var fncls__1980d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_fn__1685000186_A_fn_class = fncls__1980d; tmp137 = fncls__1980d } else { tmp137 = fncls__1980 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp136, tmp137, nil).Invoke__O()


						continue L13 }
//line :224:1
					break L13 }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000184__21); continue L12 } else { var temp__1927000414__auto____22_2 any; var root_1801 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = seq_1685000181__18; if linked_1802 == nil { temp__1927000414__auto____22_2 = ifn_1803.Invoke_O__O(arg_1804) } else { temp__1927000414__auto____22_2 = linked_1802.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1801, arg_1804) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1685000181__23 any = temp__1927000414__auto____22_2; var tmp138 any; var root_1805 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = seq_1685000181__23; if linked_1806 == nil { tmp138 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp138 = linked_1806.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1805, arg_1808) }; if jrt.J2g_Truth(tmp138) { var c__1927000678__auto____24_2 any; var root_1809 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = seq_1685000181__23; if linked_1810 == nil { c__1927000678__auto____24_2 = ifn_1811.Invoke_O__O(arg_1812) } else { c__1927000678__auto____24_2 = linked_1810.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1809, arg_1812) }; var tmp139 any; var root_2007 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = seq_1685000181__23; if linked_2008 == nil { tmp139 = ifn_2009.Invoke_O__O(arg_2010) } else { tmp139 = linked_2008.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2007, arg_2010) }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = tmp139, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__24 any; var root_1813 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = seq_1685000181__23; if linked_1814 == nil { d__24 = ifn_1815.Invoke_O__O(arg_1816) } else { d__24 = linked_1814.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1813, arg_1816) }; L14: for { var ls__25 any; var tmp140 *lang.Keyword = A_arbace_go_check_A_const_216; var tmp141 any; var root_2011 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2013 lang.IFn

						if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = d__24; if linked_2012 == nil { tmp141 = ifn_2013.Invoke_O__O(arg_2014) } else { tmp141 = linked_2012.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2011, arg_2014) }; ls__25 = tmp140.Invoke_O__O(tmp141)
						var tmp142 any; var root_2015 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = ls__25; if linked_2016 == nil { tmp142 = ifn_2017.Invoke_O__O(arg_2018) } else { tmp142 = linked_2016.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2015, arg_2018) }; if jrt.J2g_Truth(tmp142) {
							var tmp143 *lang.Volatile = lang.Volatile_Cast(d__24); var tmp144 any; var root_2019 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = jrt.NN(lang.Volatile_Cast(d__24)).Deref__O(); var arg_2023 any = A_arbace_go_check_A_const_216; var arg_2024 any = lang.PersistentVector_EMPTY.Ref(); if linked_2020 == nil { tmp144 = ifn_2021.Invoke_O_O_O__O(arg_2022, arg_2023, arg_2024) } else { tmp144 = linked_2020.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2019, arg_2022, arg_2023, arg_2024) }; jrt.NN(tmp143).Reset_O__O(tmp144)
							var root_2071 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any; var tmp145 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp146 any = A_arbace_go_check_A_const_220; var tmp147 any = A_arbace_go_check_A_const_221; var tmp148 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp149 any; var root_2084 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = d__24; if linked_2085 == nil { tmp149 = ifn_2086.Invoke_O__O(arg_2087) } else { tmp149 = linked_2085.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2084, arg_2087) }; var tmp150 any = tmp148.Invoke_O__O(tmp149); var tmp151 any = A_arbace_go_check_A_const_222; var tmp152 any; var G__1685000192__26_ any; var tmp153 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp154 any; var root_2088 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = d__24; if linked_2089 == nil { tmp154 = ifn_2090.Invoke_O__O(arg_2091) } else { tmp154 = linked_2089.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2088, arg_2091) }; G__1685000192__26_ = tmp153.Invoke_O__O(tmp154); if lang.Util_Identical_O_O__Z_NoInit(G__1685000192__26_, nil) { tmp152 = nil } else { var root_2092 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = G__1685000192__26_; var arg_2096 any = A_arbace_go_check_A_const_79; if linked_2093 == nil { tmp152 = ifn_2094.Invoke_O_O__O(arg_2095, arg_2096) } else { tmp152 = linked_2093.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2092, arg_2095, arg_2096) } }; arg_2074 = tmp145.Invoke_O_O_O_O_O_O__O(tmp146, d__24, tmp147, tmp150, tmp151, tmp152); if linked_2072 == nil { ifn_2073.Invoke_O__O(arg_2074) } else { linked_2072.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2071, arg_2074) }; var tmp155 any = A_arbace_go_check_check_package_fn__1685000193_A_New_O_O(d__24, ls__25); var tmp156 *jrt.Class; var fncls__2070 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_A_fn_class; if fncls__2070 == nil { var fncls__2070d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_check_check_package_fn__1685000193_A_fn_class = fncls__2070d; tmp156 = fncls__2070d } else { tmp156 = fncls__2070 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp155, tmp156, nil).Invoke__O()


							continue L14 }
//line :224:1
						break L14 }; var tmp157 any; var root_2097 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = seq_1685000181__23; if linked_2098 == nil { tmp157 = ifn_2099.Invoke_O__O(arg_2100) } else { tmp157 = linked_2098.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2097, arg_2100) }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = tmp157, nil, 0, 0; continue L12 } } }
//line :161:1
				break L12 }; var seq_1685000199__18 any; var root_1817 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1819 lang.IFn








































































			if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = decls__17; if linked_1818 == nil { seq_1685000199__18 = ifn_1819.Invoke_O__O(arg_1820) } else { seq_1685000199__18 = linked_1818.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1817, arg_1820) }
//line :161:1
			var chunk_1685000200__19 any; var count_1685000201__20 int64 = 0; var i_1685000202__21 int64 = 0; L15: for {








































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000202__21, count_1685000201__20) { var d__22_2 any = lang.Indexed_Cast(chunk_1685000200__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000202__21)); var tmp158 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp159 any; var root_1821 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = d__22_2; if linked_1822 == nil { tmp159 = ifn_1823.Invoke_O__O(arg_1824) } else { tmp159 = linked_1822.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1821, arg_1824) }; if jrt.J2g_Truth(tmp158.Invoke_O__O(tmp159)) {
					var root_2113 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any; var tmp160 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp161 any = A_arbace_go_check_A_const_220; var tmp162 any = A_arbace_go_check_A_const_221; var tmp163 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp164 any; var root_2124 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = d__22_2; if linked_2125 == nil { tmp164 = ifn_2126.Invoke_O__O(arg_2127) } else { tmp164 = linked_2125.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2124, arg_2127) }; arg_2116 = tmp160.Invoke_O_O_O_O__O(tmp161, d__22_2, tmp162, tmp163.Invoke_O__O(tmp164)); if linked_2114 == nil { ifn_2115.Invoke_O__O(arg_2116) } else { linked_2114.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2113, arg_2116) }; var tmp165 any = A_arbace_go_check_check_package_fn__1685000203_A_New_O(d__22_2); var tmp166 *jrt.Class; var fncls__2112 *jrt.Class = A_arbace_go_check_check_package_fn__1685000203_A_fn_class; if fncls__2112 == nil { var fncls__2112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_fn__1685000203_A_fn_class = fncls__2112d; tmp166 = fncls__2112d } else { tmp166 = fncls__2112 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp165, tmp166, nil).Invoke__O()
//line :234:1
					seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000202__21); continue L15 } else { seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000202__21); continue L15 } } else { var temp__1927000414__auto____22_3 any; var root_1825 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = seq_1685000199__18; if linked_1826 == nil { temp__1927000414__auto____22_3 = ifn_1827.Invoke_O__O(arg_1828) } else { temp__1927000414__auto____22_3 = linked_1826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1825, arg_1828) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1685000199__23 any = temp__1927000414__auto____22_3; var tmp167 any; var root_1829 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = seq_1685000199__23; if linked_1830 == nil { tmp167 = ifn_1831.Invoke_O__O(arg_1832) } else { tmp167 = linked_1830.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1829, arg_1832) }; if jrt.J2g_Truth(tmp167) { var c__1927000678__auto____24_3 any; var root_1833 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = seq_1685000199__23; if linked_1834 == nil { c__1927000678__auto____24_3 = ifn_1835.Invoke_O__O(arg_1836) } else { c__1927000678__auto____24_3 = linked_1834.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1833, arg_1836) }; var tmp168 any; var root_2128 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = seq_1685000199__23; if linked_2129 == nil { tmp168 = ifn_2130.Invoke_O__O(arg_2131) } else { tmp168 = linked_2129.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2128, arg_2131) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp168, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__24_2 any; var root_1837 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = seq_1685000199__23; if linked_1838 == nil { d__24_2 = ifn_1839.Invoke_O__O(arg_1840) } else { d__24_2 = linked_1838.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1837, arg_1840) }; var tmp169 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp170 any; var root_1841 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = d__24_2; if linked_1842 == nil { tmp170 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp170 = linked_1842.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1841, arg_1844) }; if jrt.J2g_Truth(tmp169.Invoke_O__O(tmp170)) {
						var root_2144 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any; var tmp171 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp172 any = A_arbace_go_check_A_const_220; var tmp173 any = A_arbace_go_check_A_const_221; var tmp174 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp175 any; var root_2155 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = d__24_2; if linked_2156 == nil { tmp175 = ifn_2157.Invoke_O__O(arg_2158) } else { tmp175 = linked_2156.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2155, arg_2158) }; arg_2147 = tmp171.Invoke_O_O_O_O__O(tmp172, d__24_2, tmp173, tmp174.Invoke_O__O(tmp175)); if linked_2145 == nil { ifn_2146.Invoke_O__O(arg_2147) } else { linked_2145.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2144, arg_2147) }; var tmp176 any = A_arbace_go_check_check_package_fn__1685000205_A_New_O(d__24_2); var tmp177 *jrt.Class; var fncls__2143 *jrt.Class = A_arbace_go_check_check_package_fn__1685000205_A_fn_class; if fncls__2143 == nil { var fncls__2143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_fn__1685000205_A_fn_class = fncls__2143d; tmp177 = fncls__2143d } else { tmp177 = fncls__2143 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp176, tmp177, nil).Invoke__O()
//line :234:1
						var tmp178 any; var root_2159 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = seq_1685000199__23; if linked_2160 == nil { tmp178 = ifn_2161.Invoke_O__O(arg_2162) } else { tmp178 = linked_2160.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2159, arg_2162) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp178, nil, 0, 0; continue L15 } else { var tmp179 any; var root_2163 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = seq_1685000199__23; if linked_2164 == nil { tmp179 = ifn_2165.Invoke_O__O(arg_2166) } else { tmp179 = linked_2164.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2163, arg_2166) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp179, nil, 0, 0; continue L15 } } } }
//line :161:1
				break L15
			}












































































			if jrt.J2g_Truth(resolving__10) { var seq_1685000207__18 any; var root_1845 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1847 lang.IFn
				if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = decls__17; if linked_1846 == nil { seq_1685000207__18 = ifn_1847.Invoke_O__O(arg_1848) } else { seq_1685000207__18 = linked_1846.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1845, arg_1848) }
//line :239:1
				var chunk_1685000208__19 any; var count_1685000209__20 int64 = 0; var i_1685000210__21 int64 = 0; L16: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000210__21, count_1685000209__20) { var d__22_3 any = lang.Indexed_Cast(chunk_1685000208__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000210__21)); var tmp180 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp181 any; var root_1849 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = d__22_3; if linked_1850 == nil { tmp181 = ifn_1851.Invoke_O__O(arg_1852) } else { tmp181 = linked_1850.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1849, arg_1852) }; if jrt.J2g_Truth(tmp180.Invoke_O__O(tmp181)) { var seq_1685000215__23 any; var root_2167 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any; var root_2171 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2173 lang.IFn
						if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var tmp182 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp183 any; var root_2175 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = d__22_3; if linked_2176 == nil { tmp183 = ifn_2177.Invoke_O__O(arg_2178) } else { tmp183 = linked_2176.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2175, arg_2178) }; arg_2174 = tmp182.Invoke_O__O(tmp183); if linked_2172 == nil { arg_2170 = ifn_2173.Invoke_O__O(arg_2174) } else { arg_2170 = linked_2172.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2171, arg_2174) }
//line :240:1
						if linked_2168 == nil { seq_1685000215__23 = ifn_2169.Invoke_O__O(arg_2170) } else { seq_1685000215__23 = linked_2168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2167, arg_2170) }; var chunk_1685000216__24 any; var count_1685000217__25 int64 = 0; var i_1685000218__26 int64 = 0; L17: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000218__26, count_1685000217__25) { var n__27 any = lang.Indexed_Cast(chunk_1685000216__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000218__26)); var tmp184 any; var tmp185 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____28 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp185, A_arbace_go_check_A_const_50.Invoke_O__O(n__27))

							if and__1927000168__auto____28 { tmp184 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__27)) } else { tmp184 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____28).Ref() }
//line :240:1
							if jrt.J2g_Truth(tmp184) {


								var root_2195 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__27); var arg_2199 any; var tmp186 any = A_arbace_go_check_A_const_226; var tmp187 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__27); var tmp188 any = A_arbace_go_check_A_const_55; var G__1685000219__28_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp186, tmp187, tmp188, A_arbace_go_check_A_const_55.Invoke_O__O(n__27), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp189 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp189.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__27))) {

									var root_2200 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = G__1685000219__28_; var arg_2204 any = A_arbace_go_check_A_const_229; var arg_2205 any = jrt.Boolean_TRUE.Ref(); if linked_2201 == nil { arg_2199 = ifn_2202.Invoke_O_O_O__O(arg_2203, arg_2204, arg_2205) } else { arg_2199 = linked_2201.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2200, arg_2203, arg_2204, arg_2205) } } else {
//line :243:1
										arg_2199 = G__1685000219__28_ }; if linked_2196 == nil { ifn_2197.Invoke_O_O__O(arg_2198, arg_2199) } else { linked_2196.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2195, arg_2198, arg_2199) }
//line :240:1
								seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000218__26); continue L17 } else { seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000218__26); continue L17 } } else { var temp__1927000414__auto____27 any; var root_2179 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = seq_1685000215__23; if linked_2180 == nil { temp__1927000414__auto____27 = ifn_2181.Invoke_O__O(arg_2182) } else { temp__1927000414__auto____27 = linked_2180.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2179, arg_2182) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var seq_1685000215__28 any = temp__1927000414__auto____27; var tmp190 any; var root_2183 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = seq_1685000215__28; if linked_2184 == nil { tmp190 = ifn_2185.Invoke_O__O(arg_2186) } else { tmp190 = linked_2184.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2183, arg_2186) }; if jrt.J2g_Truth(tmp190) { var c__1927000678__auto____29 any; var root_2187 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any = seq_1685000215__28; if linked_2188 == nil { c__1927000678__auto____29 = ifn_2189.Invoke_O__O(arg_2190) } else { c__1927000678__auto____29 = linked_2188.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2187, arg_2190) }; var tmp191 any; var root_2206 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2208 lang.IFn; if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = seq_1685000215__28; if linked_2207 == nil { tmp191 = ifn_2208.Invoke_O__O(arg_2209) } else { tmp191 = linked_2207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2206, arg_2209) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp191, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L17 } else { var n__29 any; var root_2191 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = seq_1685000215__28; if linked_2192 == nil { n__29 = ifn_2193.Invoke_O__O(arg_2194) } else { n__29 = linked_2192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2191, arg_2194) }; var tmp192 any; var tmp193 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____30 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp193, A_arbace_go_check_A_const_50.Invoke_O__O(n__29))

									if and__1927000168__auto____30 { tmp192 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__29)) } else { tmp192 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30).Ref() }
//line :240:1
									if jrt.J2g_Truth(tmp192) {


										var root_2210 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__29); var arg_2214 any; var tmp194 any = A_arbace_go_check_A_const_226; var tmp195 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__29); var tmp196 any = A_arbace_go_check_A_const_55; var G__1685000220__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp194, tmp195, tmp196, A_arbace_go_check_A_const_55.Invoke_O__O(n__29), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp197 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp197.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__29))) {

											var root_2215 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = G__1685000220__30_; var arg_2219 any = A_arbace_go_check_A_const_229; var arg_2220 any = jrt.Boolean_TRUE.Ref(); if linked_2216 == nil { arg_2214 = ifn_2217.Invoke_O_O_O__O(arg_2218, arg_2219, arg_2220) } else { arg_2214 = linked_2216.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2215, arg_2218, arg_2219, arg_2220) } } else {
//line :243:1
												arg_2214 = G__1685000220__30_ }; if linked_2211 == nil { ifn_2212.Invoke_O_O__O(arg_2213, arg_2214) } else { linked_2211.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2210, arg_2213, arg_2214) }
//line :240:1
										var tmp198 any; var root_2221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = seq_1685000215__28; if linked_2222 == nil { tmp198 = ifn_2223.Invoke_O__O(arg_2224) } else { tmp198 = linked_2222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2221, arg_2224) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp198, nil, 0, 0; continue L17 } else { var tmp199 any; var root_2225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = seq_1685000215__28; if linked_2226 == nil { tmp199 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp199 = linked_2226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2225, arg_2228) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp199, nil, 0, 0; continue L17 } } } }; break L17 }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__21); continue L16 } else { seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__21); continue L16 } } else { var temp__1927000414__auto____22_4 any; var root_1853 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = seq_1685000207__18; if linked_1854 == nil { temp__1927000414__auto____22_4 = ifn_1855.Invoke_O__O(arg_1856) } else { temp__1927000414__auto____22_4 = linked_1854.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(temp__1927000414__auto____22_4) { var seq_1685000207__23 any = temp__1927000414__auto____22_4; var tmp200 any; var root_1857 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = seq_1685000207__23; if linked_1858 == nil { tmp200 = ifn_1859.Invoke_O__O(arg_1860) } else { tmp200 = linked_1858.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1857, arg_1860) }; if jrt.J2g_Truth(tmp200) { var c__1927000678__auto____24_4 any; var root_1861 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = seq_1685000207__23; if linked_1862 == nil { c__1927000678__auto____24_4 = ifn_1863.Invoke_O__O(arg_1864) } else { c__1927000678__auto____24_4 = linked_1862.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1861, arg_1864) }; var tmp201 any; var root_2229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = seq_1685000207__23; if linked_2230 == nil { tmp201 = ifn_2231.Invoke_O__O(arg_2232) } else { tmp201 = linked_2230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2229, arg_2232) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp201, c__1927000678__auto____24_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var d__24_3 any; var root_1865 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = seq_1685000207__23; if linked_1866 == nil { d__24_3 = ifn_1867.Invoke_O__O(arg_1868) } else { d__24_3 = linked_1866.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1865, arg_1868) }; var tmp202 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp203 any; var root_1869 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = d__24_3; if linked_1870 == nil { tmp203 = ifn_1871.Invoke_O__O(arg_1872) } else { tmp203 = linked_1870.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1869, arg_1872) }; if jrt.J2g_Truth(tmp202.Invoke_O__O(tmp203)) { var seq_1685000211__25 any; var root_2233 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any; var root_2237 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2239 lang.IFn
											if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any; var tmp204 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp205 any; var root_2241 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = d__24_3; if linked_2242 == nil { tmp205 = ifn_2243.Invoke_O__O(arg_2244) } else { tmp205 = linked_2242.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2241, arg_2244) }; arg_2240 = tmp204.Invoke_O__O(tmp205); if linked_2238 == nil { arg_2236 = ifn_2239.Invoke_O__O(arg_2240) } else { arg_2236 = linked_2238.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2237, arg_2240) }
//line :240:1
											if linked_2234 == nil { seq_1685000211__25 = ifn_2235.Invoke_O__O(arg_2236) } else { seq_1685000211__25 = linked_2234.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2233, arg_2236) }; var chunk_1685000212__26 any; var count_1685000213__27 int64 = 0; var i_1685000214__28 int64 = 0; L18: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000214__28, count_1685000213__27) { var n__29_2 any = lang.Indexed_Cast(chunk_1685000212__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000214__28)); var tmp206 any; var tmp207 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____30_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp207, A_arbace_go_check_A_const_50.Invoke_O__O(n__29_2))

												if and__1927000168__auto____30_2 { tmp206 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__29_2)) } else { tmp206 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30_2).Ref() }
//line :240:1
												if jrt.J2g_Truth(tmp206) {


													var root_2261 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__29_2); var arg_2265 any; var tmp208 any = A_arbace_go_check_A_const_226; var tmp209 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__29_2); var tmp210 any = A_arbace_go_check_A_const_55; var G__1685000221__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp208, tmp209, tmp210, A_arbace_go_check_A_const_55.Invoke_O__O(n__29_2), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp211 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp211.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__29_2))) {

														var root_2266 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = G__1685000221__30_; var arg_2270 any = A_arbace_go_check_A_const_229; var arg_2271 any = jrt.Boolean_TRUE.Ref(); if linked_2267 == nil { arg_2265 = ifn_2268.Invoke_O_O_O__O(arg_2269, arg_2270, arg_2271) } else { arg_2265 = linked_2267.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2266, arg_2269, arg_2270, arg_2271) } } else {
//line :243:1
															arg_2265 = G__1685000221__30_ }; if linked_2262 == nil { ifn_2263.Invoke_O_O__O(arg_2264, arg_2265) } else { linked_2262.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2261, arg_2264, arg_2265) }
//line :240:1
													seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__28); continue L18 } else { seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__28); continue L18 } } else { var temp__1927000414__auto____29 any; var root_2245 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = seq_1685000211__25; if linked_2246 == nil { temp__1927000414__auto____29 = ifn_2247.Invoke_O__O(arg_2248) } else { temp__1927000414__auto____29 = linked_2246.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2245, arg_2248) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1685000211__30 any = temp__1927000414__auto____29; var tmp212 any; var root_2249 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = seq_1685000211__30; if linked_2250 == nil { tmp212 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp212 = linked_2250.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2249, arg_2252) }; if jrt.J2g_Truth(tmp212) { var c__1927000678__auto____31 any; var root_2253 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = seq_1685000211__30; if linked_2254 == nil { c__1927000678__auto____31 = ifn_2255.Invoke_O__O(arg_2256) } else { c__1927000678__auto____31 = linked_2254.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2253, arg_2256) }; var tmp213 any; var root_2272 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = seq_1685000211__30; if linked_2273 == nil { tmp213 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp213 = linked_2273.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2272, arg_2275) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp213, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L18 } else { var n__31 any; var root_2257 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = seq_1685000211__30; if linked_2258 == nil { n__31 = ifn_2259.Invoke_O__O(arg_2260) } else { n__31 = linked_2258.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2257, arg_2260) }; var tmp214 any; var tmp215 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____32 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp215, A_arbace_go_check_A_const_50.Invoke_O__O(n__31))

														if and__1927000168__auto____32 { tmp214 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__31)) } else { tmp214 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____32).Ref() }
//line :240:1
														if jrt.J2g_Truth(tmp214) {


															var root_2276 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__31); var arg_2280 any; var tmp216 any = A_arbace_go_check_A_const_226; var tmp217 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__31); var tmp218 any = A_arbace_go_check_A_const_55; var G__1685000222__32_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp216, tmp217, tmp218, A_arbace_go_check_A_const_55.Invoke_O__O(n__31), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp219 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp219.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__31))) {

																var root_2281 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = G__1685000222__32_; var arg_2285 any = A_arbace_go_check_A_const_229; var arg_2286 any = jrt.Boolean_TRUE.Ref(); if linked_2282 == nil { arg_2280 = ifn_2283.Invoke_O_O_O__O(arg_2284, arg_2285, arg_2286) } else { arg_2280 = linked_2282.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2281, arg_2284, arg_2285, arg_2286) } } else {
//line :243:1
																	arg_2280 = G__1685000222__32_ }; if linked_2277 == nil { ifn_2278.Invoke_O_O__O(arg_2279, arg_2280) } else { linked_2277.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2276, arg_2279, arg_2280) }
//line :240:1
															var tmp220 any; var root_2287 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2287, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2289 lang.IFn; if linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any = seq_1685000211__30; if linked_2288 == nil { tmp220 = ifn_2289.Invoke_O__O(arg_2290) } else { tmp220 = linked_2288.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2287, arg_2290) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp220, nil, 0, 0; continue L18 } else { var tmp221 any; var root_2291 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = seq_1685000211__30; if linked_2292 == nil { tmp221 = ifn_2293.Invoke_O__O(arg_2294) } else { tmp221 = linked_2292.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2291, arg_2294) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp221, nil, 0, 0; continue L18 } } } }; break L18 }; var tmp222 any; var root_2295 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = seq_1685000207__23; if linked_2296 == nil { tmp222 = ifn_2297.Invoke_O__O(arg_2298) } else { tmp222 = linked_2296.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2295, arg_2298) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp222, nil, 0, 0; continue L16 } else { var tmp223 any; var root_2299 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = seq_1685000207__23; if linked_2300 == nil { tmp223 = ifn_2301.Invoke_O__O(arg_2302) } else { tmp223 = linked_2300.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2299, arg_2302) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp223, nil, 0, 0; continue L16 } } } }
//line :239:1
					break L16 } }
//line :161:1
			var seq_1685000223__18 any; var root_1873 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1875 lang.IFn





















































































			if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = decls__17; if linked_1874 == nil { seq_1685000223__18 = ifn_1875.Invoke_O__O(arg_1876) } else { seq_1685000223__18 = linked_1874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1873, arg_1876) }
//line :161:1
			var chunk_1685000224__19 any; var count_1685000225__20 int64 = 0; var i_1685000226__21 int64 = 0; L19: for {





















































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000226__21, count_1685000225__20) { var d__22_4 any = lang.Indexed_Cast(chunk_1685000224__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000226__21)); var tmp224 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp225 any; var root_1877 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = d__22_4; if linked_1878 == nil { tmp225 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp225 = linked_1878.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1877, arg_1880) }; if jrt.J2g_Truth(tmp224.Invoke_O__O(tmp225)) {
					var root_2303 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any; var tmp226 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp227 any; var root_2308 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = d__22_4; if linked_2309 == nil { tmp227 = ifn_2310.Invoke_O__O(arg_2311) } else { tmp227 = linked_2309.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2308, arg_2311) }; arg_2306 = tmp226.Invoke_O__O(tmp227); var arg_2307 any; var tmp228 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp229 any; var root_2312 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = d__22_4; if linked_2313 == nil { tmp229 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp229 = linked_2313.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2312, arg_2315) }; arg_2307 = tmp228.Invoke_O__O(tmp229); if linked_2304 == nil { ifn_2305.Invoke_O_O__O(arg_2306, arg_2307) } else { linked_2304.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2303, arg_2306, arg_2307) }
//line :247:1
					seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } else { seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } } else { var temp__1927000414__auto____22_5 any; var root_1881 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = seq_1685000223__18; if linked_1882 == nil { temp__1927000414__auto____22_5 = ifn_1883.Invoke_O__O(arg_1884) } else { temp__1927000414__auto____22_5 = linked_1882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1881, arg_1884) }; if jrt.J2g_Truth(temp__1927000414__auto____22_5) { var seq_1685000223__23 any = temp__1927000414__auto____22_5; var tmp230 any; var root_1885 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = seq_1685000223__23; if linked_1886 == nil { tmp230 = ifn_1887.Invoke_O__O(arg_1888) } else { tmp230 = linked_1886.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1885, arg_1888) }; if jrt.J2g_Truth(tmp230) { var c__1927000678__auto____24_5 any; var root_1889 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = seq_1685000223__23; if linked_1890 == nil { c__1927000678__auto____24_5 = ifn_1891.Invoke_O__O(arg_1892) } else { c__1927000678__auto____24_5 = linked_1890.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1889, arg_1892) }; var tmp231 any; var root_2316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = seq_1685000223__23; if linked_2317 == nil { tmp231 = ifn_2318.Invoke_O__O(arg_2319) } else { tmp231 = linked_2317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2316, arg_2319) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp231, c__1927000678__auto____24_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L19 } else { var d__24_4 any; var root_1893 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = seq_1685000223__23; if linked_1894 == nil { d__24_4 = ifn_1895.Invoke_O__O(arg_1896) } else { d__24_4 = linked_1894.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1893, arg_1896) }; var tmp232 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp233 any; var root_1897 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = d__24_4; if linked_1898 == nil { tmp233 = ifn_1899.Invoke_O__O(arg_1900) } else { tmp233 = linked_1898.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1897, arg_1900) }; if jrt.J2g_Truth(tmp232.Invoke_O__O(tmp233)) {
						var root_2320 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any; var tmp234 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp235 any; var root_2325 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = d__24_4; if linked_2326 == nil { tmp235 = ifn_2327.Invoke_O__O(arg_2328) } else { tmp235 = linked_2326.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2325, arg_2328) }; arg_2323 = tmp234.Invoke_O__O(tmp235); var arg_2324 any; var tmp236 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp237 any; var root_2329 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = d__24_4; if linked_2330 == nil { tmp237 = ifn_2331.Invoke_O__O(arg_2332) } else { tmp237 = linked_2330.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2329, arg_2332) }; arg_2324 = tmp236.Invoke_O__O(tmp237); if linked_2321 == nil { ifn_2322.Invoke_O_O__O(arg_2323, arg_2324) } else { linked_2321.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2320, arg_2323, arg_2324) }
//line :247:1
						var tmp238 any; var root_2333 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2335 lang.IFn; if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = seq_1685000223__23; if linked_2334 == nil { tmp238 = ifn_2335.Invoke_O__O(arg_2336) } else { tmp238 = linked_2334.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2333, arg_2336) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp238, nil, 0, 0; continue L19 } else { var tmp239 any; var root_2337 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2339 lang.IFn; if linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = seq_1685000223__23; if linked_2338 == nil { tmp239 = ifn_2339.Invoke_O__O(arg_2340) } else { tmp239 = linked_2338.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2337, arg_2340) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp239, nil, 0, 0; continue L19 } } } }
//line :161:1
				break L19 }; var seq_1685000227__18 any; var root_1901 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1903 lang.IFn























































































			if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = fis__13; if linked_1902 == nil { seq_1685000227__18 = ifn_1903.Invoke_O__O(arg_1904) } else { seq_1685000227__18 = linked_1902.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1901, arg_1904) }
//line :161:1
			var chunk_1685000228__19 any; var count_1685000229__20 int64 = 0; var i_1685000230__21 int64 = 0; L20: for {























































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000230__21, count_1685000229__20) { var fi__22_5 any = lang.Indexed_Cast(chunk_1685000228__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000230__21)); var root_2341 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2343 lang.IFn; if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = fi__22_5; if linked_2342 == nil { ifn_2343.Invoke_O__O(arg_2344) } else { linked_2342.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2341, arg_2344) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000230__21); continue L20 } else { var temp__1927000414__auto____22_6 any; var root_1905 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = seq_1685000227__18; if linked_1906 == nil { temp__1927000414__auto____22_6 = ifn_1907.Invoke_O__O(arg_1908) } else { temp__1927000414__auto____22_6 = linked_1906.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1905, arg_1908) }; if jrt.J2g_Truth(temp__1927000414__auto____22_6) { var seq_1685000227__23 any = temp__1927000414__auto____22_6; var tmp240 any; var root_1909 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = seq_1685000227__23; if linked_1910 == nil { tmp240 = ifn_1911.Invoke_O__O(arg_1912) } else { tmp240 = linked_1910.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1909, arg_1912) }; if jrt.J2g_Truth(tmp240) { var c__1927000678__auto____24_6 any; var root_1913 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = seq_1685000227__23; if linked_1914 == nil { c__1927000678__auto____24_6 = ifn_1915.Invoke_O__O(arg_1916) } else { c__1927000678__auto____24_6 = linked_1914.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1913, arg_1916) }; var tmp241 any; var root_2345 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2347 lang.IFn; if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; var arg_2348 any = seq_1685000227__23; if linked_2346 == nil { tmp241 = ifn_2347.Invoke_O__O(arg_2348) } else { tmp241 = linked_2346.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2345, arg_2348) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = tmp241, c__1927000678__auto____24_6, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_6))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L20 } else { var fi__24 any; var root_1917 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = seq_1685000227__23; if linked_1918 == nil { fi__24 = ifn_1919.Invoke_O__O(arg_1920) } else { fi__24 = linked_1918.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1917, arg_1920) }; var root_2349 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2349, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2351 lang.IFn; if linked_2350 == nil { ifn_2351 = lang.IFn_Cast(root_2349) } else { ifn_2351 = nil }; var arg_2352 any = fi__24; if linked_2350 == nil { ifn_2351.Invoke_O__O(arg_2352) } else { linked_2350.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2349, arg_2352) }; var tmp242 any; var root_2353 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = seq_1685000227__23; if linked_2354 == nil { tmp242 = ifn_2355.Invoke_O__O(arg_2356) } else { tmp242 = linked_2354.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2353, arg_2356) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = tmp242, nil, 0, 0; continue L20 } } }
//line :161:1
				break L20 }; var order__18 any; var root_852 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_854 lang.IFn

























































































			if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = objs__16; if linked_853 == nil { order__18 = ifn_854.Invoke_O__O(arg_855) } else { order__18 = linked_853.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_852, arg_855) }
//line :161:1
			var ___19 any; var tmp243 any; var root_856 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_858 lang.IFn; _ = ___19



























































































			if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any; var root_860 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = errors__9; if linked_861 == nil { arg_859 = ifn_862.Invoke_O__O(arg_863) } else { arg_859 = linked_861.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_860, arg_863) }; if linked_857 == nil { tmp243 = ifn_858.Invoke_O__O(arg_859) } else { tmp243 = linked_857.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_856, arg_859) }; if jrt.J2g_Truth(tmp243) { var root_864 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; if linked_865 == nil { ___19 = ifn_866.Invoke__O() } else { ___19 = linked_865.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A).Invoke_O__O(root_864) } } else { ___19 = nil }
//line :161:1
			var ___20 any; var tmp244 any; var root_867 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_869 lang.IFn; _ = ___20





























































































			if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any; var root_871 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = errors__9; if linked_872 == nil { arg_870 = ifn_873.Invoke_O__O(arg_874) } else { arg_870 = linked_872.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_871, arg_874) }; if linked_868 == nil { tmp244 = ifn_869.Invoke_O__O(arg_870) } else { tmp244 = linked_868.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_867, arg_870) }; if jrt.J2g_Truth(tmp244) { var root_875 any = A_arbace_go_check_A_const_132.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; if linked_876 == nil { ___20 = ifn_877.Invoke__O() } else { ___20 = linked_876.(*aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A).Invoke_O__O(root_875) } } else { ___20 = nil }
//line :161:1
			var say__21 any; var root_878 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_880 lang.IFn






























































































			if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = src__0; var arg_882 any = A_arbace_go_check_A_const_133; if linked_879 == nil { say__21 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { say__21 = linked_879.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_878, arg_881, arg_882) }
//line :161:1
			var init_entry__22 any; var tmp245 any = A_arbace_go_check_check_package_init_entry__1685000231_A_New(); var tmp246 *jrt.Class
			var fncls__923 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class































































































			if fncls__923 == nil { var fncls__923d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class = fncls__923d; tmp246 = fncls__923d } else { tmp246 = fncls__923 }; init_entry__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp245, tmp246, nil)
//line :161:1
			var have__23 any; var root_924 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_926 lang.IFn


































































































			if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = init_entry__22; var arg_928 any = order__18; if linked_925 == nil { have__23 = ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { have__23 = linked_925.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }
//line :161:1
			var norm__24 any; var tmp247 any = A_arbace_go_check_check_package_norm__1685000235_A_New(); var tmp248 *jrt.Class
			var fncls__957 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000235_A_fn_class




































































































			if fncls__957 == nil { var fncls__957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_norm__1685000235_A_fn_class = fncls__957d; tmp248 = fncls__957d } else { tmp248 = fncls__957 }; norm__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp247, tmp248, nil)
//line :161:1
			var init_result__25 any; var tmp249 any; var root_958 any = A_arbace_go_check_A_const_114.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_960 lang.IFn









































































































			if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = say__21; if linked_959 == nil { tmp249 = ifn_960.Invoke_O__O(arg_961) } else { tmp249 = linked_959.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_958, arg_961) }; if jrt.J2g_Truth(tmp249) {
				var tmp250 any; var root_962 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = norm__24; var arg_966 any = say__21; if linked_963 == nil { tmp250 = ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { tmp250 = linked_963.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_962, arg_965, arg_966) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp250, have__23) { var tmp251 any = A_arbace_go_check_A_const_140; var tmp252 any = jrt.Boolean_TRUE.Ref(); var tmp253 any = A_arbace_go_check_A_const_141; init_result__25 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp251, tmp252, tmp253, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__21)).Ref())) } else {

					var root_2357 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_232.Invoke_O__O(src__0)) { arg_2360 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_232.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp254 *lang.Keyword = A_arbace_go_check_A_const_71; var tmp255 any; var root_2364 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2366 lang.IFn; if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__0); if linked_2365 == nil { tmp255 = ifn_2366.Invoke_O__O(arg_2367) } else { tmp255 = linked_2365.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2364, arg_2367) }; arg_2360 = tmp254.Invoke_O__O(tmp255) }; var arg_2361 any; var or__1927000174__auto____25 any = A_arbace_go_check_A_const_233.Invoke_O__O(src__0)
					if jrt.J2g_Truth(or__1927000174__auto____25) { arg_2361 = or__1927000174__auto____25 } else { arg_2361 = A_arbace_go_check_A_const_22 }
//line :270:1
					var arg_2362 any = A_arbace_go_check_A_const_234; var arg_2363 any = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_66, A_arbace_go_check_A_const_111.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()).Invoke_O__O(say__21), lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()).Invoke_O__O(have__23)); if linked_2358 == nil { ifn_2359.Invoke_O_O_O_O__O(arg_2360, arg_2361, arg_2362, arg_2363) } else { linked_2358.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_2357, arg_2360, arg_2361, arg_2362, arg_2363) }
//line :268:1
					init_result__25 = A_arbace_go_check_A_const_142 } } else {
//line :267:1
						init_result__25 = nil }
//line :161:1
			var generic_ids__26 any; var root_967 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_969 lang.IFn


















































































































			if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any; var root_971 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var tmp256 any = A_arbace_go_check_check_package_fn__1685000239_A_New(); var tmp257 *jrt.Class; var fncls__984 *jrt.Class = A_arbace_go_check_check_package_fn__1685000239_A_fn_class; if fncls__984 == nil { var fncls__984d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_fn__1685000239_A_fn_class = fncls__984d; tmp257 = fncls__984d } else { tmp257 = fncls__984 }; arg_974 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp256, tmp257, nil); var arg_975 any = decls__17; if linked_972 == nil { arg_970 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { arg_970 = linked_972.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }; if linked_968 == nil { generic_ids__26 = ifn_969.Invoke_O__O(arg_970) } else { generic_ids__26 = linked_968.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_967, arg_970) }
//line :161:1
			var errs__27 any; var root_985 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_987 lang.IFn

























































































			if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = errors__9; if linked_986 == nil { errs__27 = ifn_987.Invoke_O__O(arg_988) } else { errs__27 = linked_986.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_985, arg_988) }
//line :161:1
			var counted__28 any; var root_989 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_991 lang.IFn




















































































































			if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any; var tmp258 any = A_arbace_go_check_check_package_fn__1685000241_A_New_O(generic_ids__26); var tmp259 *jrt.Class; var fncls__999 *jrt.Class = A_arbace_go_check_check_package_fn__1685000241_A_fn_class; if fncls__999 == nil { var fncls__999d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000241_A_fn_class = fncls__999d; tmp259 = fncls__999d } else { tmp259 = fncls__999 }; arg_992 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp258, tmp259, nil); var arg_993 any = errs__27; if linked_990 == nil { counted__28 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { counted__28 = linked_990.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }
//line :161:1
			var forms__29 any; var m__29 any = jrt.IdentityHashMap_New(); var order__30 any = jrt.ArrayList_New(); var seq_1685000243__31 any; var root_2383 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2385 lang.IFn
























































































































			if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = decls__17; if linked_2384 == nil { seq_1685000243__31 = ifn_2385.Invoke_O__O(arg_2386) } else { seq_1685000243__31 = linked_2384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2383, arg_2386) }
//line :161:1
			var chunk_1685000244__32 any; var count_1685000245__33 int64 = 0; var i_1685000246__34 int64 = 0; L21: for {
























































































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000246__34, count_1685000245__33) { var d__35 any = lang.Indexed_Cast(chunk_1685000244__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000246__34)); var f__36 any; var tmp260 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp261 any; var root_2403 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2405 lang.IFn
					if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = d__35; if linked_2404 == nil { tmp261 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp261 = linked_2404.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2403, arg_2406) }; f__36 = tmp260.Invoke_O__O(tmp261)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__29)).ContainsKey_O__Z(f__36) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__30)).Add_O__Z(f__36)); jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Put_O_O__O(f__36, lang.PersistentVector_EMPTY.Ref()) }
					var tmp262 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__29); var tmp263 any; var root_2407 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Get_O__O(f__36); var arg_2411 any = d__35; if linked_2408 == nil { tmp263 = ifn_2409.Invoke_O_O__O(arg_2410, arg_2411) } else { tmp263 = linked_2408.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2407, arg_2410, arg_2411) }; jrt.NN(tmp262).Put_O_O__O(f__36, tmp263)
//line :282:1
					seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000246__34); continue L21 } else { var temp__1927000414__auto____35 any; var root_2387 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = seq_1685000243__31; if linked_2388 == nil { temp__1927000414__auto____35 = ifn_2389.Invoke_O__O(arg_2390) } else { temp__1927000414__auto____35 = linked_2388.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2387, arg_2390) }; if jrt.J2g_Truth(temp__1927000414__auto____35) { var seq_1685000243__36 any = temp__1927000414__auto____35; var tmp264 any; var root_2391 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = seq_1685000243__36; if linked_2392 == nil { tmp264 = ifn_2393.Invoke_O__O(arg_2394) } else { tmp264 = linked_2392.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2391, arg_2394) }; if jrt.J2g_Truth(tmp264) { var c__1927000678__auto____37 any; var root_2395 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2397 lang.IFn; if linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = seq_1685000243__36; if linked_2396 == nil { c__1927000678__auto____37 = ifn_2397.Invoke_O__O(arg_2398) } else { c__1927000678__auto____37 = linked_2396.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2395, arg_2398) }; var tmp265 any; var root_2412 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = seq_1685000243__36; if linked_2413 == nil { tmp265 = ifn_2414.Invoke_O__O(arg_2415) } else { tmp265 = linked_2413.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2412, arg_2415) }; seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = tmp265, c__1927000678__auto____37, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L21 } else { var d__37 any; var root_2399 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = seq_1685000243__36; if linked_2400 == nil { d__37 = ifn_2401.Invoke_O__O(arg_2402) } else { d__37 = linked_2400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2399, arg_2402) }; var f__38 any; var tmp266 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp267 any; var root_2416 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2418 lang.IFn
						if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = d__37; if linked_2417 == nil { tmp267 = ifn_2418.Invoke_O__O(arg_2419) } else { tmp267 = linked_2417.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2416, arg_2419) }; f__38 = tmp266.Invoke_O__O(tmp267)
						if jrt.NN(jrt.IdentityHashMap_Cast(m__29)).ContainsKey_O__Z(f__38) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__30)).Add_O__Z(f__38)); jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Put_O_O__O(f__38, lang.PersistentVector_EMPTY.Ref()) }
						var tmp268 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__29); var tmp269 any; var root_2420 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any = jrt.NN(jrt.IdentityHashMap_Cast(m__29)).Get_O__O(f__38); var arg_2424 any = d__37; if linked_2421 == nil { tmp269 = ifn_2422.Invoke_O_O__O(arg_2423, arg_2424) } else { tmp269 = linked_2421.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2420, arg_2423, arg_2424) }; jrt.NN(tmp268).Put_O_O__O(f__38, tmp269)
//line :282:1
						var tmp270 any; var root_2425 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = seq_1685000243__36; if linked_2426 == nil { tmp270 = ifn_2427.Invoke_O__O(arg_2428) } else { tmp270 = linked_2426.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2425, arg_2428) }; seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = tmp270, nil, 0, 0; continue L21 } } }
//line :161:1
				break L21
			}



























































































































			var root_1000 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any; var tmp271 any = A_arbace_go_check_check_package_fn__1685000247_A_New_O(m__29); var tmp272 *jrt.Class; var fncls__1005 *jrt.Class = A_arbace_go_check_check_package_fn__1685000247_A_fn_class; if fncls__1005 == nil { var fncls__1005d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000247_A_fn_class = fncls__1005d; tmp272 = fncls__1005d } else { tmp272 = fncls__1005 }; arg_1003 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp271, tmp272, nil); var arg_1004 any = order__30; if linked_1001 == nil { forms__29 = ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { forms__29 = linked_1001.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) }
//line :161:1
			var stats__30 any; var root_1006 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1008 lang.IFn





























































































































			if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any; var tmp273 any = A_arbace_go_check_check_package_fn__1685000250_A_New_O(resolving__10); var tmp274 *jrt.Class; var fncls__1286 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_A_fn_class
			if fncls__1286 == nil { var fncls__1286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_fn__1685000250_A_fn_class = fncls__1286d; tmp274 = fncls__1286d } else { tmp274 = fncls__1286 }; arg_1009 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp273, tmp274, nil)
//line :287:1
			var arg_1010 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_164, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_83, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_153, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_155, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_140, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_166, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_157, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_145, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_167, lang.PersistentVector_EMPTY.Ref())); var arg_1011 any = forms__29; if linked_1007 == nil { stats__30 = ifn_1008.Invoke_O_O_O__O(arg_1009, arg_1010, arg_1011) } else { stats__30 = linked_1007.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1006, arg_1009, arg_1010, arg_1011)
			}




























			var tmp275 any
			var and__1927000168__auto____31 any = resolving__10

			if jrt.J2g_Truth(and__1927000168__auto____31) { var root_2429 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any = keep_trees__6; if linked_2430 == nil { tmp275 = ifn_2431.Invoke_O__O(arg_2432) } else { tmp275 = linked_2430.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2429, arg_2432) } } else { tmp275 = and__1927000168__auto____31 }
//line :317:1
			if jrt.J2g_Truth(tmp275) { var seq_1685000291__31 any; var root_2433 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2435 lang.IFn



				if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = decls__17; if linked_2434 == nil { seq_1685000291__31 = ifn_2435.Invoke_O__O(arg_2436) } else { seq_1685000291__31 = linked_2434.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2433, arg_2436) }
//line :317:1
				var chunk_1685000292__32 any; var count_1685000293__33 int64 = 0; var i_1685000294__34 int64 = 0; L22: for {



					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000294__34, count_1685000293__33) { var d__35_2 any = lang.Indexed_Cast(chunk_1685000292__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000294__34)); var root_2632 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = d__35_2; var arg_2636 any; var root_2637 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any; var root_2642 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = d__35_2; if linked_2643 == nil { arg_2640 = ifn_2644.Invoke_O__O(arg_2645) } else { arg_2640 = linked_2643.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2642, arg_2645) }; var arg_2641 any = A_arbace_go_check_A_const_252; if linked_2638 == nil { arg_2636 = ifn_2639.Invoke_O_O__O(arg_2640, arg_2641) } else { arg_2636 = linked_2638.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2637, arg_2640, arg_2641) }; if linked_2633 == nil { ifn_2634.Invoke_O_O__O(arg_2635, arg_2636) } else { linked_2633.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2632, arg_2635, arg_2636) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000294__34); continue L22 } else { var temp__1927000414__auto____35_2 any; var root_2437 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2437, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2439 lang.IFn; if linked_2438 == nil { ifn_2439 = lang.IFn_Cast(root_2437) } else { ifn_2439 = nil }; var arg_2440 any = seq_1685000291__31; if linked_2438 == nil { temp__1927000414__auto____35_2 = ifn_2439.Invoke_O__O(arg_2440) } else { temp__1927000414__auto____35_2 = linked_2438.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2437, arg_2440) }; if jrt.J2g_Truth(temp__1927000414__auto____35_2) { var seq_1685000291__36 any = temp__1927000414__auto____35_2; var tmp276 any; var root_2441 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = seq_1685000291__36; if linked_2442 == nil { tmp276 = ifn_2443.Invoke_O__O(arg_2444) } else { tmp276 = linked_2442.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2441, arg_2444) }; if jrt.J2g_Truth(tmp276) { var c__1927000678__auto____37_2 any; var root_2445 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = seq_1685000291__36; if linked_2446 == nil { c__1927000678__auto____37_2 = ifn_2447.Invoke_O__O(arg_2448) } else { c__1927000678__auto____37_2 = linked_2446.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2445, arg_2448) }; var tmp277 any; var root_2646 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = seq_1685000291__36; if linked_2647 == nil { tmp277 = ifn_2648.Invoke_O__O(arg_2649) } else { tmp277 = linked_2647.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2646, arg_2649) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp277, c__1927000678__auto____37_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L22 } else { var d__37_2 any; var root_2449 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2451 lang.IFn; if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = seq_1685000291__36; if linked_2450 == nil { d__37_2 = ifn_2451.Invoke_O__O(arg_2452) } else { d__37_2 = linked_2450.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2449, arg_2452) }; var root_2650 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_2651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2650, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2652 lang.IFn; if linked_2651 == nil { ifn_2652 = lang.IFn_Cast(root_2650) } else { ifn_2652 = nil }; var arg_2653 any = d__37_2; var arg_2654 any; var root_2655 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2655, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2657 lang.IFn; if linked_2656 == nil { ifn_2657 = lang.IFn_Cast(root_2655) } else { ifn_2657 = nil }; var arg_2658 any; var root_2660 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any = d__37_2; if linked_2661 == nil { arg_2658 = ifn_2662.Invoke_O__O(arg_2663) } else { arg_2658 = linked_2661.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2660, arg_2663) }; var arg_2659 any = A_arbace_go_check_A_const_253; if linked_2656 == nil { arg_2654 = ifn_2657.Invoke_O_O__O(arg_2658, arg_2659) } else { arg_2654 = linked_2656.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2655, arg_2658, arg_2659) }; if linked_2651 == nil { ifn_2652.Invoke_O_O__O(arg_2653, arg_2654) } else { linked_2651.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2650, arg_2653, arg_2654) }; var tmp278 any; var root_2664 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2664, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2666 lang.IFn; if linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = seq_1685000291__36; if linked_2665 == nil { tmp278 = ifn_2666.Invoke_O__O(arg_2667) } else { tmp278 = linked_2665.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2664, arg_2667) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp278, nil, 0, 0; continue L22 } } }
//line :317:1
					break L22 } } else { var tmp279 any; var root_2453 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2455 lang.IFn




						if linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = keep_trees__6; if linked_2454 == nil { tmp279 = ifn_2455.Invoke_O__O(arg_2456) } else { tmp279 = linked_2454.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2453, arg_2456) }
//line :317:1
						if jrt.J2g_Truth(tmp279) { var seq_1685000295__31 any; var root_2457 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2459 lang.IFn





							if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = decls__17; if linked_2458 == nil { seq_1685000295__31 = ifn_2459.Invoke_O__O(arg_2460) } else { seq_1685000295__31 = linked_2458.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2457, arg_2460) }
//line :317:1
							var chunk_1685000296__32 any; var count_1685000297__33 int64 = 0; var i_1685000298__34 int64 = 0; L23: for {





								if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000298__34, count_1685000297__33) { var d__35_3 any = lang.Indexed_Cast(chunk_1685000296__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000298__34)); var tmp280 any; var and__1927000168__auto____36 bool; var tmp281 any = A_arbace_go_check_A_const_254; var tmp282 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp283 any; var root_2668 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2670 lang.IFn
									if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = d__35_3; if linked_2669 == nil { tmp283 = ifn_2670.Invoke_O__O(arg_2671) } else { tmp283 = linked_2669.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2668, arg_2671) }; and__1927000168__auto____36 = lang.Util_Equiv_O_O__Z_NoInit(tmp281, tmp282.Invoke_O__O(tmp283)); if and__1927000168__auto____36 { var or__1927000174__auto____37 any; var root_2672 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any; var root_2676 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2676, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2678 lang.IFn; if linked_2677 == nil { ifn_2678 = lang.IFn_Cast(root_2676) } else { ifn_2678 = nil }; var arg_2679 any; var tmp284 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp285 any; var root_2681 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2683 lang.IFn; if linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; var arg_2684 any = d__35_3; if linked_2682 == nil { tmp285 = ifn_2683.Invoke_O__O(arg_2684) } else { tmp285 = linked_2682.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2681, arg_2684) }; arg_2679 = tmp284.Invoke_O__O(tmp285); var arg_2680 any = A_arbace_go_check_A_const_255; if linked_2677 == nil { arg_2675 = ifn_2678.Invoke_O_O__O(arg_2679, arg_2680) } else { arg_2675 = linked_2677.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2676, arg_2679, arg_2680) }; if linked_2673 == nil { or__1927000174__auto____37 = ifn_2674.Invoke_O__O(arg_2675) } else { or__1927000174__auto____37 = linked_2673.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2672, arg_2675) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp280 = or__1927000174__auto____37 } else { var root_2685 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2687 lang.IFn; if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any; var root_2689 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2691 lang.IFn; if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any; var tmp286 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp287 any; var root_2694 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = d__35_3; if linked_2695 == nil { tmp287 = ifn_2696.Invoke_O__O(arg_2697) } else { tmp287 = linked_2695.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2694, arg_2697) }; arg_2692 = tmp286.Invoke_O__O(tmp287); var arg_2693 any = A_arbace_go_check_A_const_256; if linked_2690 == nil { arg_2688 = ifn_2691.Invoke_O_O__O(arg_2692, arg_2693) } else { arg_2688 = linked_2690.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2689, arg_2692, arg_2693) }; if linked_2686 == nil { tmp280 = ifn_2687.Invoke_O__O(arg_2688) } else { tmp280 = linked_2686.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2685, arg_2688) } } } else { tmp280 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____36).Ref() }; if jrt.J2g_Truth(tmp280) {
										jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) } else {
											jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_215, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) }
//line :323:1
									seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000298__34); continue L23 } else { var temp__1927000414__auto____35_3 any; var root_2461 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = seq_1685000295__31; if linked_2462 == nil { temp__1927000414__auto____35_3 = ifn_2463.Invoke_O__O(arg_2464) } else { temp__1927000414__auto____35_3 = linked_2462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2461, arg_2464) }; if jrt.J2g_Truth(temp__1927000414__auto____35_3) { var seq_1685000295__36 any = temp__1927000414__auto____35_3; var tmp288 any; var root_2465 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2465, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2467 lang.IFn; if linked_2466 == nil { ifn_2467 = lang.IFn_Cast(root_2465) } else { ifn_2467 = nil }; var arg_2468 any = seq_1685000295__36; if linked_2466 == nil { tmp288 = ifn_2467.Invoke_O__O(arg_2468) } else { tmp288 = linked_2466.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2465, arg_2468) }; if jrt.J2g_Truth(tmp288) { var c__1927000678__auto____37_3 any; var root_2469 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2471 lang.IFn; if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = seq_1685000295__36; if linked_2470 == nil { c__1927000678__auto____37_3 = ifn_2471.Invoke_O__O(arg_2472) } else { c__1927000678__auto____37_3 = linked_2470.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2469, arg_2472) }; var tmp289 any; var root_2713 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = seq_1685000295__36; if linked_2714 == nil { tmp289 = ifn_2715.Invoke_O__O(arg_2716) } else { tmp289 = linked_2714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2713, arg_2716) }; seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = tmp289, c__1927000678__auto____37_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L23 } else { var d__37_3 any; var root_2473 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2475 lang.IFn; if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = seq_1685000295__36; if linked_2474 == nil { d__37_3 = ifn_2475.Invoke_O__O(arg_2476) } else { d__37_3 = linked_2474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2473, arg_2476) }
										var tmp290 any; var and__1927000168__auto____38 bool; var tmp291 any = A_arbace_go_check_A_const_254; var tmp292 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp293 any; var root_2717 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = d__37_3; if linked_2718 == nil { tmp293 = ifn_2719.Invoke_O__O(arg_2720) } else { tmp293 = linked_2718.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2717, arg_2720) }; and__1927000168__auto____38 = lang.Util_Equiv_O_O__Z_NoInit(tmp291, tmp292.Invoke_O__O(tmp293)); if and__1927000168__auto____38 { var or__1927000174__auto____39 any; var root_2721 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any; var root_2725 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2727 lang.IFn; if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any; var tmp294 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp295 any; var root_2730 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = d__37_3; if linked_2731 == nil { tmp295 = ifn_2732.Invoke_O__O(arg_2733) } else { tmp295 = linked_2731.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2730, arg_2733) }; arg_2728 = tmp294.Invoke_O__O(tmp295); var arg_2729 any = A_arbace_go_check_A_const_255; if linked_2726 == nil { arg_2724 = ifn_2727.Invoke_O_O__O(arg_2728, arg_2729) } else { arg_2724 = linked_2726.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2725, arg_2728, arg_2729) }; if linked_2722 == nil { or__1927000174__auto____39 = ifn_2723.Invoke_O__O(arg_2724) } else { or__1927000174__auto____39 = linked_2722.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2721, arg_2724) }; if jrt.J2g_Truth(or__1927000174__auto____39) { tmp290 = or__1927000174__auto____39 } else { var root_2734 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any; var root_2738 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any; var tmp296 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp297 any; var root_2743 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2745 lang.IFn; if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; var arg_2746 any = d__37_3; if linked_2744 == nil { tmp297 = ifn_2745.Invoke_O__O(arg_2746) } else { tmp297 = linked_2744.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2743, arg_2746) }; arg_2741 = tmp296.Invoke_O__O(tmp297); var arg_2742 any = A_arbace_go_check_A_const_256; if linked_2739 == nil { arg_2737 = ifn_2740.Invoke_O_O__O(arg_2741, arg_2742) } else { arg_2737 = linked_2739.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2738, arg_2741, arg_2742) }; if linked_2735 == nil { tmp290 = ifn_2736.Invoke_O__O(arg_2737) } else { tmp290 = linked_2735.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2734, arg_2737) } } } else { tmp290 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____38).Ref() }; if jrt.J2g_Truth(tmp290) {
											jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) } else {
												jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_215, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) }
//line :323:1
										var tmp298 any; var root_2762 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = seq_1685000295__36; if linked_2763 == nil { tmp298 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp298 = linked_2763.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2762, arg_2765) }; seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = tmp298, nil, 0, 0; continue L23 } } }
//line :317:1
								break L23
							}
						}
					}






			var tmp299 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp300 any; var root_2477 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2481 any = A_arbace_go_check_A_const_237; var arg_2482 any; var tmp301 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_106.GetRawRoot__O()); var tmp302 any = A_arbace_go_check_A_const_111; var tmp303 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp304 any = A_arbace_go_check_A_const_238; var tmp305 any; var root_2483 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2483, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2485 lang.IFn


			if linked_2484 == nil { ifn_2485 = lang.IFn_Cast(root_2483) } else { ifn_2485 = nil }; var arg_2486 any; var root_2487 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_2488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2487, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2489 lang.IFn; if linked_2488 == nil { ifn_2489 = lang.IFn_Cast(root_2487) } else { ifn_2489 = nil }; var arg_2490 any; var root_2492 any = A_arbace_go_check_A_const_240.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = A_arbace_go_check_A_const_74; var arg_2496 any = A_arbace_go_check_A_const_79; if linked_2493 == nil { arg_2490 = ifn_2494.Invoke_O_O__O(arg_2495, arg_2496) } else { arg_2490 = linked_2493.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2492, arg_2495, arg_2496) }; var arg_2491 any = counted__28; if linked_2488 == nil { arg_2486 = ifn_2489.Invoke_O_O__O(arg_2490, arg_2491) } else { arg_2486 = linked_2488.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2487, arg_2490, arg_2491) }; if linked_2484 == nil { tmp305 = ifn_2485.Invoke_O__O(arg_2486) } else { tmp305 = linked_2484.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2483, arg_2486) }
//line :328:1
			var tmp306 any = tmp305; var tmp307 any = A_arbace_go_check_A_const_241; var tmp308 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__27)), int64(lang.RT_Count_O__I_NoInit(counted__28)))).Ref(); var tmp309 any = A_arbace_go_check_A_const_242; var tmp310 any = A_arbace_go_check_A_const_243; var tmp311 any




			if jrt.J2g_Truth(keep_trees__6) { var root_2497 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2499 lang.IFn; if linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any; var root_2501 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2503 lang.IFn; if linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any; var tmp312 any = A_arbace_go_check_check_package_fn__1685000299_A_New(); var tmp313 *jrt.Class; var fncls__2510 *jrt.Class = A_arbace_go_check_check_package_fn__1685000299_A_fn_class; if fncls__2510 == nil { var fncls__2510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000299_A_fn_class = fncls__2510d; tmp313 = fncls__2510d } else { tmp313 = fncls__2510 }; arg_2504 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp312, tmp313, nil); var arg_2505 any = decls__17; if linked_2502 == nil { arg_2500 = ifn_2503.Invoke_O_O__O(arg_2504, arg_2505) } else { arg_2500 = linked_2502.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2501, arg_2504, arg_2505) }; if linked_2498 == nil { tmp311 = ifn_2499.Invoke_O__O(arg_2500) } else { tmp311 = linked_2498.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2497, arg_2500) } } else { tmp311 = nil }
//line :328:1
			var tmp314 any = tmp311; var tmp315 any = A_arbace_go_check_A_const_244; var tmp316 any







			if jrt.J2g_Truth(keep_trees__6) {
				var root_2511 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2511, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2513 lang.IFn; if linked_2512 == nil { ifn_2513 = lang.IFn_Cast(root_2511) } else { ifn_2513 = nil }; var arg_2514 any; var iter__1927001039__auto____31 any; var tmp317 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_A_New(); var tmp318 *jrt.Class; var fncls__2591 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class; if fncls__2591 == nil { var fncls__2591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class = fncls__2591d; tmp318 = fncls__2591d } else { tmp318 = fncls__2591 }; iter__1927001039__auto____31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp317, tmp318, nil); arg_2514 = lang.IFn_Cast(iter__1927001039__auto____31).Invoke_O__O(decls__17); if linked_2512 == nil { tmp316 = ifn_2513.Invoke_O__O(arg_2514) } else { tmp316 = linked_2512.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2511, arg_2514) } } else {
//line :336:1
					tmp316 = nil }
//line :328:1
			var tmp319 any = tmp316; var tmp320 any = A_arbace_go_check_A_const_248; var tmp321 any











			if jrt.J2g_Truth(keep_trees__6) { tmp321 = order__18 } else { tmp321 = nil }
//line :328:1
			var tmp322 any = tmp321; var tmp323 any = A_arbace_go_check_A_const_249; var tmp324 any













			if jrt.J2g_Truth(resolving__10) {
				var root_2592 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any; var tmp325 any = A_arbace_go_check_check_package_fn__1685000311_A_New(); var tmp326 *jrt.Class; var fncls__2627 *jrt.Class = A_arbace_go_check_check_package_fn__1685000311_A_fn_class; if fncls__2627 == nil { var fncls__2627d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000311_A_fn_class = fncls__2627d; tmp326 = fncls__2627d } else { tmp326 = fncls__2627 }; arg_2595 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp325, tmp326, nil); var arg_2596 any = order__18; if linked_2593 == nil { tmp324 = ifn_2594.Invoke_O_O__O(arg_2595, arg_2596) } else { tmp324 = linked_2593.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2592, arg_2595, arg_2596) } } else {
//line :342:1
					tmp324 = nil }
//line :328:1
			var tmp327 any = tmp324; var tmp328 any = A_arbace_go_check_A_const_72; var tmp329 any
















			if jrt.J2g_Truth(keep_trees__6) { tmp329 = pkg_scope__7 } else { tmp329 = nil }
//line :328:1
			var tmp330 any = tmp329; var tmp331 any = A_arbace_go_check_A_const_120; var tmp332 any

















			if jrt.J2g_Truth(keep_trees__6) { var root_2628 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = A_arbace_go_check_A_const_120.Invoke_O__O(ctx__12); if linked_2629 == nil { tmp332 = ifn_2630.Invoke_O__O(arg_2631) } else { tmp332 = linked_2629.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2628, arg_2631) } } else { tmp332 = nil }
//line :328:1
			arg_2482 = tmp301.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, stats__30, tmp302, tmp303, tmp304, tmp306, tmp307, tmp308, tmp309, init_result__25, tmp310, tmp314, tmp315, tmp319, tmp320, tmp322, tmp323, tmp327, tmp328, tmp330, tmp331, tmp332))))
//line :327:1
			if linked_2478 == nil { tmp300 = ifn_2479.Invoke_O_O_O__O(arg_2480, arg_2481, arg_2482) } else { tmp300 = linked_2478.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2477, arg_2480, arg_2481, arg_2482) }; jrt.NN(tmp299).Reset_O__O(tmp300)
//line :161:1
			tmp70 = pkg__8 }; return nil }(); var root_1287 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1289 lang.IFn; if















	linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; if linked_1288 == nil { ifn_1289.Invoke__O() } else { linked_1288.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1287) }; if /*line :161:1*/ tmp333 != nil { panic(tmp333) }; return tmp70 }














func A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000129_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Invoke_O_O__O(self, p1__1685000111_SHARP___1 any) any { var root_826 any = A_arbace_go_check_A_const_124.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_go_check_file_info_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = t.F_pkg_scope; var arg_830 any = p1__1685000111_SHARP___1; var arg_831 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_src); if linked_827 == nil { return ifn_828.Invoke_O_O_O__O(arg_829, arg_830, arg_831) } else { return linked_827.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_826, arg_829, arg_830, arg_831) } }













func A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000131_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1294 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src); if linked_1295 == nil { tmp1 = ifn_1296.Invoke_O__O(arg_1297) } else { tmp1 = linked_1295.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1294, arg_1297) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :190:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }
































func A_arbace_go_check_check_package_fn__1685000179_A_New() *A_arbace_go_check_check_package_fn__1685000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000179_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Invoke_O_O__O(self, p1__1685000112_SHARP___1 any) any { var root_846 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = p1__1685000112_SHARP___1; var arg_850 any = A_arbace_go_check_A_const_128; if linked_847 == nil { return ifn_848.Invoke_O_O__O(arg_849, arg_850) } else { return linked_847.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_846, arg_849, arg_850) } }





func A_arbace_go_check_check_package_fn__1685000186_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000186_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000187__5 any; var root_1935 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1937 lang.IFn
											if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1938 = t_; if linked_1936 == nil { seq_1685000187__5 = ifn_1937.Invoke_O__O(arg_1938) } else { seq_1685000187__5 = linked_1936.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1935, arg_1938) }
//line :229:1
	var chunk_1685000188__6 any; var count_1685000189__7 int64 = 0; var i_1685000190__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000190__8, count_1685000189__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000188__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000190__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000190__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1939 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = seq_1685000187__5; if linked_1940 == nil { temp__1927000414__auto____9 = ifn_1941.Invoke_O__O(arg_1942) } else { temp__1927000414__auto____9 = linked_1940.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1939, arg_1942) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000187__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1943 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = seq_1685000187__10; if linked_1944 == nil { tmp2 = ifn_1945.Invoke_O__O(arg_1946) } else { tmp2 = linked_1944.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1943, arg_1946) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1947 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = seq_1685000187__10; if linked_1948 == nil { c__1927000678__auto____11 = ifn_1949.Invoke_O__O(arg_1950) } else { c__1927000678__auto____11 = linked_1948.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1947, arg_1950) }; var tmp3 any; var root_1958 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = seq_1685000187__10; if linked_1959 == nil { tmp3 = ifn_1960.Invoke_O__O(arg_1961) } else { tmp3 = linked_1959.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1958, arg_1961) }; seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1951 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = seq_1685000187__10; if linked_1952 == nil { l__11 = ifn_1953.Invoke_O__O(arg_1954) } else { l__11 = linked_1952.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1951, arg_1954) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1962 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = seq_1685000187__10; if linked_1963 == nil { tmp4 = ifn_1964.Invoke_O__O(arg_1965) } else { tmp4 = linked_1963.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1962, arg_1965) }; seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1966 any = A_arbace_go_check_A_const_217.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1968 lang.IFn

			if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = ex__5; if linked_1967 == nil { tmp6 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp6 = linked_1967.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1966, arg_1969) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1970 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1973 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1974 any = A_arbace_go_check_A_const_145; var arg_1975 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp11 any; var root_1976 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = ex__5; if linked_1977 == nil { tmp11 = ifn_1978.Invoke_O__O(arg_1979) } else { tmp11 = linked_1977.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1976, arg_1979) }; arg_1975 = tmp10.Invoke_O__O(tmp11); if linked_1971 == nil { tmp8 = ifn_1972.Invoke_O_O_O__O(arg_1973, arg_1974, arg_1975) } else { tmp8 = linked_1971.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1970, arg_1973, arg_1974, arg_1975) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_1955 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; if linked_1956 == nil { ifn_1957.Invoke__O() } else { linked_1956.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1955) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :229:1
func A_arbace_go_check_check_package_fn__1685000193_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000193_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000194__5 any; var root_2025 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2027 lang.IFn
											if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any; var t_ any = t.F_ls; t.F_ls = nil; arg_2028 = t_; if linked_2026 == nil { seq_1685000194__5 = ifn_2027.Invoke_O__O(arg_2028) } else { seq_1685000194__5 = linked_2026.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2025, arg_2028) }
//line :229:1
	var chunk_1685000195__6 any; var count_1685000196__7 int64 = 0; var i_1685000197__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000197__8, count_1685000196__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000195__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000197__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000197__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_2029 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = seq_1685000194__5; if linked_2030 == nil { temp__1927000414__auto____9 = ifn_2031.Invoke_O__O(arg_2032) } else { temp__1927000414__auto____9 = linked_2030.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2029, arg_2032) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000194__10 any = temp__1927000414__auto____9; var tmp2 any; var root_2033 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = seq_1685000194__10; if linked_2034 == nil { tmp2 = ifn_2035.Invoke_O__O(arg_2036) } else { tmp2 = linked_2034.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2033, arg_2036) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_2037 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = seq_1685000194__10; if linked_2038 == nil { c__1927000678__auto____11 = ifn_2039.Invoke_O__O(arg_2040) } else { c__1927000678__auto____11 = linked_2038.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2037, arg_2040) }; var tmp3 any; var root_2048 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = seq_1685000194__10; if linked_2049 == nil { tmp3 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp3 = linked_2049.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2048, arg_2051) }; seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_2041 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = seq_1685000194__10; if linked_2042 == nil { l__11 = ifn_2043.Invoke_O__O(arg_2044) } else { l__11 = linked_2042.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2041, arg_2044) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_2052 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = seq_1685000194__10; if linked_2053 == nil { tmp4 = ifn_2054.Invoke_O__O(arg_2055) } else { tmp4 = linked_2053.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2052, arg_2055) }; seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_2056 any = A_arbace_go_check_A_const_217.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2058 lang.IFn

			if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = ex__5; if linked_2057 == nil { tmp6 = ifn_2058.Invoke_O__O(arg_2059) } else { tmp6 = linked_2057.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_2056, arg_2059) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2060 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2063 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2064 any = A_arbace_go_check_A_const_145; var arg_2065 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp11 any; var root_2066 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = ex__5; if linked_2067 == nil { tmp11 = ifn_2068.Invoke_O__O(arg_2069) } else { tmp11 = linked_2067.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2066, arg_2069) }; arg_2065 = tmp10.Invoke_O__O(tmp11); if linked_2061 == nil { tmp8 = ifn_2062.Invoke_O_O_O__O(arg_2063, arg_2064, arg_2065) } else { tmp8 = linked_2061.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2060, arg_2063, arg_2064, arg_2065) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_2045 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2047 lang.IFn; if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; if linked_2046 == nil { ifn_2047.Invoke__O() } else { linked_2046.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2045) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000203_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000203_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000203_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000203_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000203_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2101 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp3 any; var root_2105 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any; var t_ any = t.F_d; t.F_d = nil; arg_2108 = t_; if linked_2106 == nil { tmp3 = ifn_2107.Invoke_O__O(arg_2108) } else { tmp3 = linked_2106.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2105, arg_2108) }; arg_2104 = tmp2.Invoke_O__O(tmp3); if linked_2102 == nil { tmp1 = ifn_2103.Invoke_O__O(arg_2104) } else { tmp1 = linked_2102.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2101, arg_2104) } }
//line :235:1
	return nil }(); var root_2109 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; if linked_2110 == nil { ifn_2111.Invoke__O() } else { linked_2110.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2109) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :235:1
func A_arbace_go_check_check_package_fn__1685000205_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000205_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000205_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000205_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000205_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2132 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp3 any; var root_2136 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any; var t_ any = t.F_d; t.F_d = nil; arg_2139 = t_; if linked_2137 == nil { tmp3 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp3 = linked_2137.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2136, arg_2139) }; arg_2135 = tmp2.Invoke_O__O(tmp3); if linked_2133 == nil { tmp1 = ifn_2134.Invoke_O__O(arg_2135) } else { tmp1 = linked_2133.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2132, arg_2135) } }
//line :235:1
	return nil }(); var root_2140 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; if linked_2141 == nil { ifn_2142.Invoke__O() } else { linked_2141.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2140) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_go_check_check_package_init_entry__1685000231_A_New() *A_arbace_go_check_check_package_init_entry__1685000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000231_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_New(); var tmp2 *jrt.Class; var fncls__907 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class; if
													fncls__907 == nil { var fncls__907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class = fncls__907d; tmp2 = fncls__907d } else { tmp2 = fncls__907 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_919 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = lhs__1; if linked_920 == nil { tmp4 = ifn_921.Invoke_O__O(arg_922) } else { tmp4 = linked_920.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_919, arg_922) }; return tmp3.Invoke_O__O(tmp4) } else { var root_908 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var arg_912 any = A_arbace_go_check_A_const_137; var arg_913 any; var root_914 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = one__2; var arg_918 any = lhs__1; if linked_915 == nil { arg_913 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { arg_913 = linked_915.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }; if linked_909 == nil { return ifn_910.Invoke_O_O_O__O(arg_911, arg_912, arg_913) } else { return linked_909.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_908, arg_911, arg_912, arg_913) } } }
//line :258:1
func A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_New() *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_883 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = v__1; var arg_887 any = A_arbace_go_check_A_const_71; if linked_884 == nil { tmp1 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { tmp1 = linked_884.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, tmp1) { var tmp2 any; var root_897 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = v__1; var arg_901 any = A_arbace_go_check_A_const_74; if linked_898 == nil { tmp2 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { tmp2 = linked_898.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_897, arg_900, arg_901) }; var tmp3 any = tmp2; var tmp4 any; var root_902 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = v__1; var arg_906 any = A_arbace_go_check_A_const_79; if linked_903 == nil { tmp4 = ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { tmp4 = linked_903.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_888 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var root_892 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = v__1; var arg_896 any = A_arbace_go_check_A_const_71; if linked_893 == nil { arg_891 = ifn_894.Invoke_O_O__O(arg_895, arg_896) } else { arg_891 = linked_893.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_892, arg_895, arg_896) }; if linked_889 == nil { return ifn_890.Invoke_O__O(arg_891) } else { return linked_889.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_888, arg_891) } } }



func A_arbace_go_check_check_package_norm__1685000235_A_New() *A_arbace_go_check_check_package_norm__1685000235_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000235_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1685000235_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1685000235_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_929 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_931 lang.IFn; if
												linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = x__1; if linked_930 == nil { tmp1 = ifn_931.Invoke_O__O(arg_932) } else { tmp1 = linked_930.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_929, arg_932) }; if /*line :262:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_933 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_935 lang.IFn

		if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = x__1; if linked_934 == nil { tmp2 = ifn_935.Invoke_O__O(arg_936) } else { tmp2 = linked_934.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_933, arg_936) }
//line :262:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_91, tmp2) {


			var root_937 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var arg_941 any = A_arbace_go_check_A_const_138; var arg_942 any; var root_943 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_New(); var tmp4 *jrt.Class; var fncls__952 *jrt.Class = A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class; if fncls__952 == nil { var fncls__952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class = fncls__952d; tmp4 = fncls__952d } else { tmp4 = fncls__952 }; arg_946 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_947 any; var root_953 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = x__1; if linked_954 == nil { arg_947 = ifn_955.Invoke_O__O(arg_956) } else { arg_947 = linked_954.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_953, arg_956) }; if linked_944 == nil { arg_942 = ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { arg_942 = linked_944.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) }; if linked_938 == nil { return ifn_939.Invoke_O_O_O__O(arg_940, arg_941, arg_942) } else { return linked_938.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_937, arg_940, arg_941, arg_942) } } else {
//line :262:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_New() *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A) Ctor() {}
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A) Invoke_O_O__O(self, p1__1685000113_SHARP___1 any) any { var tmp1 any; var root_948 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = p1__1685000113_SHARP___1; if linked_949 == nil { tmp1 = ifn_950.Invoke_O__O(arg_951) } else { tmp1 = linked_949.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_948, arg_951) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000113_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000239_A_New() *A_arbace_go_check_check_package_fn__1685000239_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000239_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_go_check_check_package_fn__1685000239_A) Ctor() {}
//line :276:1
func (t *A_arbace_go_check_check_package_fn__1685000239_A) Invoke_O_O__O(self, p1__1685000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp2 any; var root_976 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = p1__1685000114_SHARP___1; if linked_977 == nil { tmp2 = ifn_978.Invoke_O__O(arg_979) } else { tmp2 = linked_977.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_976, arg_979) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_146; var tmp4 any; var root_980 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = p1__1685000114_SHARP___1; if linked_981 == nil { tmp4 = ifn_982.Invoke_O__O(arg_983) } else { tmp4 = linked_981.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_980, arg_983) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000241_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000241_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000241_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_go_check_check_package_fn__1685000241_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :278:1
func (t *A_arbace_go_check_check_package_fn__1685000241_A) Invoke_O_O__O(self, p1__1685000115_SHARP___1 any) any { var root_994 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = t.F_generic_ids; var arg_998 any = A_arbace_go_check_A_const_128.Invoke_O__O(p1__1685000115_SHARP___1); if linked_995 == nil { return ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { return linked_995.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_994, arg_997, arg_998) } }







func A_arbace_go_check_check_package_fn__1685000247_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000247_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000247_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000247_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000247_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000250_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000250_A) Ctor_O(c__resolving any) { t.F_resolving = c__resolving }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000250_A) Invoke_O_O_O__O(self, acc__1, p__1685000249__2 any) any { var vec__1685000251__3 any = p__1685000249__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000251__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000251__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_1012 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1014 lang.IFn; if
															linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_New(); var tmp2 *jrt.Class; var fncls__1021 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class; if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class = fncls__1021d; tmp2 = fncls__1021d } else { tmp2 = fncls__1021 }; arg_1015 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1016 any = ds__5; if linked_1013 == nil { gen__6 = ifn_1014.Invoke_O_O__O(arg_1015, arg_1016) } else { gen__6 = linked_1013.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1012, arg_1015, arg_1016) }; var uses_generics__7 any; var root_1022 any = /*line :288:1*/A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1024 lang.IFn; if

	linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_New(); var tmp4 *jrt.Class; var fncls__1031 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class; if fncls__1031 == nil { var fncls__1031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class = fncls__1031d; tmp4 = fncls__1031d } else { tmp4 = fncls__1031 }; arg_1025 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1026 any = ds__5; if linked_1023 == nil { uses_generics__7 = ifn_1024.Invoke_O_O__O(arg_1025, arg_1026) } else { uses_generics__7 = linked_1023.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1022, arg_1025, arg_1026) }; var present__8 any; if
	jrt.J2g_Truth(t.F_resolving) { present__8 = lang.PersistentArrayMap_EMPTY.Ref() } else { var root_1032 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, A_arbace_go_check_annotations_present_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = form__4; if linked_1033 == nil { present__8 = ifn_1034.Invoke_O__O(arg_1035) } else { present__8 = linked_1033.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_1032, arg_1035) } }; var verified__9 any; var root_1036 any = /*line :288:1*/A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1038 lang.IFn; if



	linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var arg_1040 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1041 any; var root_1042 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_New(); var tmp6 *jrt.Class; var fncls__1051 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class; if fncls__1051 == nil { var fncls__1051d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class = fncls__1051d; tmp6 = fncls__1051d } else { tmp6 = fncls__1051 }; arg_1045 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1046 any = ds__5; if linked_1043 == nil { arg_1041 = ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { arg_1041 = linked_1043.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) }; if linked_1037 == nil { verified__9 = ifn_1038.Invoke_O_O_O__O(arg_1039, arg_1040, arg_1041) } else { verified__9 = linked_1037.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1036, arg_1039, arg_1040, arg_1041) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_1052 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any; var root_1059 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = acc__1; var arg_1063 any = A_arbace_go_check_A_const_153; var arg_1064 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); if linked_1060 == nil { arg_1055 = ifn_1061.Invoke_O_O_O__O(arg_1062, arg_1063, arg_1064) } else { arg_1055 = linked_1060.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1059, arg_1062, arg_1063, arg_1064) }; var arg_1056 any = A_arbace_go_check_A_const_155; var arg_1057 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1058 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1053 == nil { acc__10 = ifn_1054.Invoke_O_O_O_O__O(arg_1055, arg_1056, arg_1057, arg_1058) } else { acc__10 = linked_1053.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1052, arg_1055, arg_1056, arg_1057, arg_1058) } } else {
//line :293:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_1065 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any; var root_1071 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1073 lang.IFn
//line :299:1
		if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any; var root_1077 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1079 lang.IFn
//line :298:1
		if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = acc__10; var arg_1081 any = A_arbace_go_check_A_const_156; var arg_1082 any; var root_1083 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var arg_1087 any = A_arbace_go_check_A_const_22; if linked_1084 == nil { arg_1082 = ifn_1085.Invoke_O_O__O(arg_1086, arg_1087) } else { arg_1082 = linked_1084.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1083, arg_1086, arg_1087) }; if linked_1078 == nil { arg_1074 = ifn_1079.Invoke_O_O_O__O(arg_1080, arg_1081, arg_1082) } else { arg_1074 = linked_1078.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1077, arg_1080, arg_1081, arg_1082) }
		var arg_1075 any = A_arbace_go_check_A_const_157; var arg_1076 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_New_O(present__8); var tmp8 *jrt.Class; var fncls__1094 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class; if fncls__1094 == nil { var fncls__1094d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class = fncls__1094d; tmp8 = fncls__1094d } else { tmp8 = fncls__1094 }; arg_1076 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_1072 == nil { arg_1068 = ifn_1073.Invoke_O_O_O__O(arg_1074, arg_1075, arg_1076) } else { arg_1068 = linked_1072.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1071, arg_1074, arg_1075, arg_1076) }
		var arg_1069 any = A_arbace_go_check_A_const_145; var arg_1070 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_New_O(ds__5); var tmp10 *jrt.Class; var fncls__1117 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class; if fncls__1117 == nil { var fncls__1117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class = fncls__1117d; tmp10 = fncls__1117d } else { tmp10 = fncls__1117 }; arg_1070 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1066 == nil { return ifn_1067.Invoke_O_O_O__O(arg_1068, arg_1069, arg_1070) } else { return linked_1066.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1065, arg_1068, arg_1069, arg_1070) } } else {
//line :296:1
			var unver__11 any; var root_1118 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1120 lang.IFn




			if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1122 any; var iter__1927001039__auto____11 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_New_O(verified__9); var tmp12 *jrt.Class; var fncls__1205 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class; if fncls__1205 == nil { var fncls__1205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class = fncls__1205d; tmp12 = fncls__1205d } else { tmp12 = fncls__1205 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1122 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1119 == nil { unver__11 = ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { unver__11 = linked_1119.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122)
			}








			var root_1206 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any; var root_1212 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1214 lang.IFn
//line :310:1
			if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any; var root_1218 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1220 lang.IFn
//line :309:1
			if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any; var root_1224 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1226 lang.IFn
//line :308:1
			if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any; var root_1230 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1232 lang.IFn
//line :307:1
			if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any; var root_1237 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1239 lang.IFn
//line :306:1
			if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = acc__10; var arg_1241 any = A_arbace_go_check_A_const_164; var arg_1242 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); if linked_1238 == nil { arg_1233 = ifn_1239.Invoke_O_O_O__O(arg_1240, arg_1241, arg_1242) } else { arg_1233 = linked_1238.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1237, arg_1240, arg_1241, arg_1242) }
			var arg_1234 any = A_arbace_go_check_A_const_83; var arg_1235 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1236 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1231 == nil { arg_1227 = ifn_1232.Invoke_O_O_O_O__O(arg_1233, arg_1234, arg_1235, arg_1236) } else { arg_1227 = linked_1231.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1230, arg_1233, arg_1234, arg_1235, arg_1236) }
			var arg_1228 any = A_arbace_go_check_A_const_165; var arg_1229 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_New_O(present__8); var tmp14 *jrt.Class; var fncls__1249 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class; if fncls__1249 == nil { var fncls__1249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class = fncls__1249d; tmp14 = fncls__1249d } else { tmp14 = fncls__1249 }; arg_1229 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1225 == nil { arg_1221 = ifn_1226.Invoke_O_O_O__O(arg_1227, arg_1228, arg_1229) } else { arg_1221 = linked_1225.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1224, arg_1227, arg_1228, arg_1229) }
			var arg_1222 any = A_arbace_go_check_A_const_140; var arg_1223 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_New_O(verified__9); var tmp16 *jrt.Class; var fncls__1256 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class; if fncls__1256 == nil { var fncls__1256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class = fncls__1256d; tmp16 = fncls__1256d } else { tmp16 = fncls__1256 }; arg_1223 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1219 == nil { arg_1215 = ifn_1220.Invoke_O_O_O__O(arg_1221, arg_1222, arg_1223) } else { arg_1215 = linked_1219.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1218, arg_1221, arg_1222, arg_1223) }
			var arg_1216 any = A_arbace_go_check_A_const_166; var arg_1217 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_New_O(unver__11); var tmp18 *jrt.Class; var fncls__1263 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class; if fncls__1263 == nil { var fncls__1263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class = fncls__1263d; tmp18 = fncls__1263d } else { tmp18 = fncls__1263 }; arg_1217 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1213 == nil { arg_1209 = ifn_1214.Invoke_O_O_O__O(arg_1215, arg_1216, arg_1217) } else { arg_1209 = linked_1213.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1212, arg_1215, arg_1216, arg_1217) }
			var arg_1210 any = A_arbace_go_check_A_const_167; var arg_1211 any; var tmp19 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_New_O_O_O(form__4, ds__5, unver__11); var tmp20 *jrt.Class; var fncls__1285 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class; if fncls__1285 == nil { var fncls__1285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class = fncls__1285d; tmp20 = fncls__1285d } else { tmp20 = fncls__1285 }; arg_1211 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); if linked_1207 == nil { return ifn_1208.Invoke_O_O_O__O(arg_1209, arg_1210, arg_1211) } else { return linked_1207.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1206, arg_1209, arg_1210, arg_1211) } } }
//line :289:1
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A) Ctor() {}
//line :289:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A) Invoke_O_O__O(self, p1__1685000116_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp2 any; var root_1017 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = p1__1685000116_SHARP___1; if linked_1018 == nil { tmp2 = ifn_1019.Invoke_O__O(arg_1020) } else { tmp2 = linked_1018.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1017, arg_1020) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A) Ctor() {}
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A) Invoke_O_O__O(self, p1__1685000117_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_150; var tmp2 any; var root_1027 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = p1__1685000117_SHARP___1; if linked_1028 == nil { tmp2 = ifn_1029.Invoke_O__O(arg_1030) } else { tmp2 = linked_1028.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1027, arg_1030) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A) Ctor() {}
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A) Invoke_O_O__O(self, p1__1685000118_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_140; var tmp2 any; var root_1047 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = p1__1685000118_SHARP___1; if linked_1048 == nil { tmp2 = ifn_1049.Invoke_O__O(arg_1050) } else { tmp2 = linked_1048.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1047, arg_1050) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :299:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A) Invoke_O_O__O(self, p1__1685000119_SHARP___1 any) any { var root_1088 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1092 any = p1__1685000119_SHARP___1; var arg_1093 any = t.F_present; if linked_1089 == nil { return ifn_1090.Invoke_O_O_O__O(arg_1091, arg_1092, arg_1093) } else { return linked_1089.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1088, arg_1091, arg_1092, arg_1093) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A) Invoke_O_O__O(self, p1__1685000120_SHARP___1 any) any { var root_1095 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_New(); var tmp2 *jrt.Class; var fncls__1116 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class; if fncls__1116 == nil { var fncls__1116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class = fncls__1116d; tmp2 = fncls__1116d } else { tmp2 = fncls__1116 }; arg_1098 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1099 any = p1__1685000120_SHARP___1; var arg_1100 any = t.F_ds; if linked_1096 == nil { return ifn_1097.Invoke_O_O_O__O(arg_1098, arg_1099, arg_1100) } else { return linked_1096.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1095, arg_1098, arg_1099, arg_1100) } }
//line :300:1
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp2 any; var root_1101 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = d__2; if linked_1102 == nil { tmp2 = ifn_1103.Invoke_O__O(arg_1104) } else { tmp2 = linked_1102.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1101, arg_1104) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_1105 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = m__1; var arg_1109 any = u__4; var arg_1110 any; var root_1111 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var arg_1115 any = A_arbace_go_check_A_const_22; if linked_1112 == nil { arg_1110 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { arg_1110 = linked_1112.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }; if linked_1106 == nil { return ifn_1107.Invoke_O_O_O__O(arg_1108, arg_1109, arg_1110) } else { return linked_1106.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1105, arg_1108, arg_1109, arg_1110) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A) Invoke_O_O__O(self, s__1685000267__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_New_O_O_O(s__1685000267__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1204 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class; if fncls__1204 == nil { var fncls__1204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class = fncls__1204d; tmp2 = fncls__1204d } else { tmp2 = fncls__1204 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :301:1
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A) Ctor_O_O_O(c__s__1685000267, c__iter__1685000266, c__verified any) { t.F_s__1685000267 = c__s__1685000267; t.F_iter__1685000266 = c__iter__1685000266; t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A) Invoke_O__O(self any) any { { var s__1685000267__1 any; var t_ any = t.F_s__1685000267; t.F_s__1685000267 = nil; s__1685000267__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1123 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = s__1685000267__1; if linked_1124 == nil { temp__1927000414__auto____2 = ifn_1125.Invoke_O__O(arg_1126) } else { temp__1927000414__auto____2 = linked_1124.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1123, arg_1126) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000267__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1127 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = s__1685000267__3; if linked_1128 == nil { tmp1 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp1 = linked_1128.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1127, arg_1130) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1131 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = s__1685000267__3; if linked_1132 == nil { c__1927001037__auto____4 = ifn_1133.Invoke_O__O(arg_1134) } else { c__1927001037__auto____4 = linked_1132.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1131, arg_1134) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000269__6 any; var root_1135 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1136 == nil { b__1685000269__6 = ifn_1137.Invoke_O__O(arg_1138) } else { b__1685000269__6 = linked_1136.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1135, arg_1138) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_New_O_I_O_O(b__1685000269__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1154 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class; if fncls__1154 == nil { var fncls__1154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class = fncls__1154d; tmp3 = fncls__1154d } else { tmp3 = fncls__1154 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1155 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any; var root_1160 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1162 lang.IFn; if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = b__1685000269__6; if linked_1161 == nil { arg_1158 = ifn_1162.Invoke_O__O(arg_1163) } else { arg_1158 = linked_1161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1160, arg_1163) }; var arg_1159 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000266); var tmp5 any; var root_1164 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = s__1685000267__3; if linked_1165 == nil { tmp5 = ifn_1166.Invoke_O__O(arg_1167) } else { tmp5 = linked_1165.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1164, arg_1167) }; arg_1159 = tmp4.Invoke_O__O(tmp5); if linked_1156 == nil { return ifn_1157.Invoke_O_O__O(arg_1158, arg_1159) } else { return linked_1156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1155, arg_1158, arg_1159) } } else { var root_1168 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any; var root_1173 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = b__1685000269__6; if linked_1174 == nil { arg_1171 = ifn_1175.Invoke_O__O(arg_1176) } else { arg_1171 = linked_1174.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1173, arg_1176) }; var arg_1172 any; if linked_1169 == nil { return ifn_1170.Invoke_O_O__O(arg_1171, arg_1172) } else { return linked_1169.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1168, arg_1171, arg_1172) } } } else { var vec__1685000277__4 any; var root_1177 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = s__1685000267__3; if linked_1178 == nil { vec__1685000277__4 = ifn_1179.Invoke_O__O(arg_1180) } else { vec__1685000277__4 = linked_1178.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1177, arg_1180) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000277__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000277__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1181 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1183 lang.IFn

	if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = n__6; var arg_1185 any = v__7; if linked_1182 == nil { tmp6 = ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { tmp6 = linked_1182.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) }
//line :301:1
	if jrt.J2g_Truth(tmp6) { var root_1186 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var tmp7 jrt.Number_I; var na_1191 any = n__6; var na_1192 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1191); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1192) }; tmp8 = tmp9; if tmp8 { var n0_1193 int64 = jrt.NN(jrt.Long_Cast(na_1191)).LongValue__J(); var n1_1194 int64 = jrt.NN(jrt.Long_Cast(na_1192)).LongValue__J(); var nr_1195 int64 = n0_1193 - n1_1194; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1194 == -9223372036854775808); if tmp11 { tmp11 = (n0_1193^n1_1194)&(n0_1193^nr_1195) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1195)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1191, na_1192) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1191); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1192) }; tmp12 = tmp13; if tmp12 { var n0_1193_2 float64 = jrt.NN(jrt.Double_Cast(na_1191)).DoubleValue__D(); var n1_1194_2 float64 = jrt.NN(jrt.Double_Cast(na_1192)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1193_2 + -n1_1194_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1191, na_1192) } }
//line :301:1
		arg_1189 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1190 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000266); var tmp15 any; var root_1196 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = s__1685000267__3; if linked_1197 == nil { tmp15 = ifn_1198.Invoke_O__O(arg_1199) } else { tmp15 = linked_1197.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1196, arg_1199) }; arg_1190 = tmp14.Invoke_O__O(tmp15); if linked_1187 == nil { return ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { return linked_1187.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) } } else { var tmp16 any; var root_1200 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = s__1685000267__3; if linked_1201 == nil { tmp16 = ifn_1202.Invoke_O__O(arg_1203) } else { tmp16 = linked_1201.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1200, arg_1203) }; s__1685000267__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :301:1
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A) Ctor_O_I_O_O(c__b__1685000269 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1685000269 = c__b__1685000269; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A) Invoke_O__O(self any) any { { var i__1685000268__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000268__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000273__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000268__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1139 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1141 lang.IFn

	if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = n__4; var arg_1143 any = v__5; if linked_1140 == nil { tmp2 = ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { tmp2 = linked_1140.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) }
//line :301:1
	if jrt.J2g_Truth(tmp2) { var root_1144 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = t.F_b__1685000269; var arg_1148 any; var tmp3 jrt.Number_I; var na_1149 any = n__4; var na_1150 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1149); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1150) }; tmp4 = tmp5; if tmp4 { var n0_1151 int64 = jrt.NN(jrt.Long_Cast(na_1149)).LongValue__J(); var n1_1152 int64 = jrt.NN(jrt.Long_Cast(na_1150)).LongValue__J(); var nr_1153 int64 = n0_1151 - n1_1152; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1152 == -9223372036854775808); if tmp7 { tmp7 = (n0_1151^n1_1152)&(n0_1151^nr_1153) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1153)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1149, na_1150) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1149); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1150) }; tmp8 = tmp9; if tmp8 { var n0_1151_2 float64 = jrt.NN(jrt.Double_Cast(na_1149)).DoubleValue__D(); var n1_1152_2 float64 = jrt.NN(jrt.Double_Cast(na_1150)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1151_2 + -n1_1152_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1149, na_1150) } }
//line :301:1
		arg_1148 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1145 == nil { ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { linked_1145.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) }; i__1685000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000268__1); continue L1 } else { i__1685000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000268__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :308:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A) Invoke_O_O__O(self, p1__1685000121_SHARP___1 any) any { var root_1243 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1247 any = p1__1685000121_SHARP___1; var arg_1248 any = t.F_present; if linked_1244 == nil { return ifn_1245.Invoke_O_O_O__O(arg_1246, arg_1247, arg_1248) } else { return linked_1244.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1243, arg_1246, arg_1247, arg_1248) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :309:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A) Invoke_O_O__O(self, p1__1685000122_SHARP___1 any) any { var root_1250 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1254 any = p1__1685000122_SHARP___1; var arg_1255 any = t.F_verified; if linked_1251 == nil { return ifn_1252.Invoke_O_O_O__O(arg_1253, arg_1254, arg_1255) } else { return linked_1251.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1250, arg_1253, arg_1254, arg_1255) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A) Invoke_O_O__O(self, p1__1685000123_SHARP___1 any) any { var root_1257 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1261 any = p1__1685000123_SHARP___1; var arg_1262 any = t.F_unver; if linked_1258 == nil { return ifn_1259.Invoke_O_O_O__O(arg_1260, arg_1261, arg_1262) } else { return linked_1258.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1257, arg_1260, arg_1261, arg_1262) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :311:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :311:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A) Invoke_O_O__O(self, p1__1685000124_SHARP___1 any) any { var tmp1 any; var root_1264 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = t.F_unver; if linked_1265 == nil { tmp1 = ifn_1266.Invoke_O__O(arg_1267) } else { tmp1 = linked_1265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1264, arg_1267) }; if jrt.J2g_Truth(tmp1) { var root_1268 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = p1__1685000124_SHARP___1; var arg_1272 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_71; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp4 any; var root_1273 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any; var root_1277 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = t.F_ds; if linked_1278 == nil { arg_1276 = ifn_1279.Invoke_O__O(arg_1280) } else { arg_1276 = linked_1278.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1277, arg_1280) }; if linked_1274 == nil { tmp4 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp4 = linked_1274.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1273, arg_1276) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1281 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = t.F_form; if linked_1282 == nil { tmp6 = ifn_1283.Invoke_O__O(arg_1284) } else { tmp6 = linked_1282.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1281, arg_1284) }; arg_1272 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1269 == nil { return ifn_1270.Invoke_O_O__O(arg_1271, arg_1272) } else { return linked_1269.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1268, arg_1271, arg_1272) } } else { return p1__1685000124_SHARP___1 } }





















func A_arbace_go_check_check_package_fn__1685000299_A_New() *A_arbace_go_check_check_package_fn__1685000299_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000299_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_go_check_check_package_fn__1685000299_A) Ctor() {}
//line :333:1
func (t *A_arbace_go_check_check_package_fn__1685000299_A) Invoke_O_O__O(self, p1__1685000125_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp2 any; var root_2506 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = p1__1685000125_SHARP___1; if linked_2507 == nil { tmp2 = ifn_2508.Invoke_O__O(arg_2509) } else { tmp2 = linked_2507.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2506, arg_2509) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000301__1685000305_A_New() *A_arbace_go_check_check_package_iter__1685000301__1685000305_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_A) Ctor() {}
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_A) Invoke_O_O__O(self, s__1685000302__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_New_O_O(s__1685000302__1, self); var tmp2 *jrt.Class; var fncls__2590 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class; if fncls__2590 == nil { var fncls__2590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class = fncls__2590d; tmp2 = fncls__2590d } else { tmp2 = fncls__2590 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A) Ctor_O_O(c__s__1685000302, c__iter__1685000301 any) { t.F_s__1685000302 = c__s__1685000302; t.F_iter__1685000301 = c__iter__1685000301 }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A) Invoke_O__O(self any) any { { var s__1685000302__1 any; var t_ any = t.F_s__1685000302; t.F_s__1685000302 = nil; s__1685000302__1 = t_; for { var temp__1927000414__auto____2 any; var root_2515 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2515, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2517 lang.IFn; if linked_2516 == nil { ifn_2517 = lang.IFn_Cast(root_2515) } else { ifn_2517 = nil }; var arg_2518 any = s__1685000302__1; if linked_2516 == nil { temp__1927000414__auto____2 = ifn_2517.Invoke_O__O(arg_2518) } else { temp__1927000414__auto____2 = linked_2516.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2515, arg_2518) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000302__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2519 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = s__1685000302__3; if linked_2520 == nil { tmp1 = ifn_2521.Invoke_O__O(arg_2522) } else { tmp1 = linked_2520.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2519, arg_2522) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2523 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = s__1685000302__3; if linked_2524 == nil { c__1927001037__auto____4 = ifn_2525.Invoke_O__O(arg_2526) } else { c__1927001037__auto____4 = linked_2524.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2523, arg_2526) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000304__6 any; var root_2527 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2528 == nil { b__1685000304__6 = ifn_2529.Invoke_O__O(arg_2530) } else { b__1685000304__6 = linked_2528.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2527, arg_2530) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_New_O_I_O(b__1685000304__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2545 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class; if fncls__2545 == nil { var fncls__2545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class = fncls__2545d; tmp3 = fncls__2545d } else { tmp3 = fncls__2545 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2546 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any; var root_2551 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = b__1685000304__6; if linked_2552 == nil { arg_2549 = ifn_2553.Invoke_O__O(arg_2554) } else { arg_2549 = linked_2552.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2551, arg_2554) }; var arg_2550 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000301); var tmp5 any; var root_2555 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = s__1685000302__3; if linked_2556 == nil { tmp5 = ifn_2557.Invoke_O__O(arg_2558) } else { tmp5 = linked_2556.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2555, arg_2558) }; arg_2550 = tmp4.Invoke_O__O(tmp5); if linked_2547 == nil { return ifn_2548.Invoke_O_O__O(arg_2549, arg_2550) } else { return linked_2547.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2546, arg_2549, arg_2550) } } else { var root_2559 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any; var root_2564 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2566 lang.IFn; if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = b__1685000304__6; if linked_2565 == nil { arg_2562 = ifn_2566.Invoke_O__O(arg_2567) } else { arg_2562 = linked_2565.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2564, arg_2567) }; var arg_2563 any; if linked_2560 == nil { return ifn_2561.Invoke_O_O__O(arg_2562, arg_2563) } else { return linked_2560.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2559, arg_2562, arg_2563) } } } else { var d__4 any; var root_2568 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = s__1685000302__3; if linked_2569 == nil { d__4 = ifn_2570.Invoke_O__O(arg_2571) } else { d__4 = linked_2569.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2568, arg_2571) }; var root_2572 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any; var root_2577 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2577, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2579 lang.IFn
															if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any; var root_2582 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2582, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2584 lang.IFn; if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = d__4; if linked_2583 == nil { arg_2580 = ifn_2584.Invoke_O__O(arg_2585) } else { arg_2580 = linked_2583.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2582, arg_2585) }; var arg_2581 any = A_arbace_go_check_A_const_247; if linked_2578 == nil { arg_2575 = ifn_2579.Invoke_O_O__O(arg_2580, arg_2581) } else { arg_2575 = linked_2578.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2577, arg_2580, arg_2581) }
//line :337:1
	var arg_2576 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000301); var tmp7 any; var root_2586 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = s__1685000302__3; if linked_2587 == nil { tmp7 = ifn_2588.Invoke_O__O(arg_2589) } else { tmp7 = linked_2587.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2586, arg_2589) }; arg_2576 = tmp6.Invoke_O__O(tmp7); if linked_2573 == nil { return ifn_2574.Invoke_O_O__O(arg_2575, arg_2576) } else { return linked_2573.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2572, arg_2575, arg_2576) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A) Ctor_O_I_O(c__b__1685000304 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000304 = c__b__1685000304; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A) Invoke_O__O(self any) any { { var i__1685000303__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000303__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000303__1)); var root_2531 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = t.F_b__1685000304; var arg_2535 any; var root_2536 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2538 lang.IFn
																	if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any; var root_2541 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any = d__2; if linked_2542 == nil { arg_2539 = ifn_2543.Invoke_O__O(arg_2544) } else { arg_2539 = linked_2542.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2541, arg_2544) }; var arg_2540 any = A_arbace_go_check_A_const_246; if linked_2537 == nil { arg_2535 = ifn_2538.Invoke_O_O__O(arg_2539, arg_2540) } else { arg_2535 = linked_2537.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2536, arg_2539, arg_2540) }
//line :337:1
	if linked_2532 == nil { ifn_2533.Invoke_O_O__O(arg_2534, arg_2535) } else { linked_2532.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2531, arg_2534, arg_2535) }; i__1685000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000303__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_check_package_fn__1685000311_A_New() *A_arbace_go_check_check_package_fn__1685000311_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000311_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_A) Invoke_O_O__O(self, lhs__1 any) any { var root_2597 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2597, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_New(); var tmp2 *jrt.Class; var fncls__2626 *jrt.Class = A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class; if fncls__2626 == nil { var fncls__2626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class = fncls__2626d; tmp2 = fncls__2626d } else { tmp2 = fncls__2626 }; arg_2600 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2601 any = lhs__1; if linked_2598 == nil { return ifn_2599.Invoke_O_O__O(arg_2600, arg_2601) } else { return linked_2598.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2597, arg_2600, arg_2601) } }
//line :343:1
func A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_New() *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_2602 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2602, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = v__1; var arg_2606 any = A_arbace_go_check_A_const_71; if linked_2603 == nil { tmp1 = ifn_2604.Invoke_O_O__O(arg_2605, arg_2606) } else { tmp1 = linked_2603.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2602, arg_2605, arg_2606) }; var tmp2 any = tmp1; var tmp3 any; var root_2607 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = v__1; var arg_2611 any = A_arbace_go_check_A_const_74; if linked_2608 == nil { tmp3 = ifn_2609.Invoke_O_O__O(arg_2610, arg_2611) } else { tmp3 = linked_2608.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2607, arg_2610, arg_2611) }; var tmp4 any = tmp3; var tmp5 any; var root_2612 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = v__1; var arg_2616 any = A_arbace_go_check_A_const_79; if linked_2613 == nil { tmp5 = ifn_2614.Invoke_O_O__O(arg_2615, arg_2616) } else { tmp5 = linked_2613.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2612, arg_2615, arg_2616) }; var tmp6 any = tmp5; var tmp7 any; var root_2617 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any; var root_2621 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = v__1; var arg_2625 any = A_arbace_go_check_A_const_251; if linked_2622 == nil { arg_2620 = ifn_2623.Invoke_O_O__O(arg_2624, arg_2625) } else { arg_2620 = linked_2622.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2621, arg_2624, arg_2625) }; if linked_2618 == nil { tmp7 = ifn_2619.Invoke_O__O(arg_2620) } else { tmp7 = linked_2618.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2617, arg_2620) }; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :351:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_261; var tmp2 any = A_arbace_go_check_A_const_262; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_263; var tmp5 any; var root_2766 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2768 lang.IFn; if



	linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2767 == nil { tmp5 = ifn_2768.Invoke_O__O(arg_2769) } else { tmp5 = linked_2767.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2766, arg_2769) }; return /*line :351:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2770 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2772 lang.IFn; if



	linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = A_arbace_go_check_A_const_263.Invoke_O__O(s__0); if linked_2771 == nil { tmp1 = ifn_2772.Invoke_O__O(arg_2773) } else { tmp1 = linked_2771.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2770, arg_2773) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_262.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2774 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2774, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2776 lang.IFn; if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any = p__5; if linked_2775 == nil { tmp2 = ifn_2776.Invoke_O__O(arg_2777) } else { tmp2 = linked_2775.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2774, arg_2777) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2778 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2778, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2780 lang.IFn; if linked_2779 == nil { ifn_2780 = lang.IFn_Cast(root_2778) } else { ifn_2780 = nil }; var arg_2781 any = p__5; if linked_2779 == nil { or__1927000174__auto____3 = ifn_2780.Invoke_O__O(arg_2781) } else { or__1927000174__auto____3 = linked_2779.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2778, arg_2781) } } else { or__1927000174__auto____3 = nil } } else {
//line :363:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_266.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2782 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2782, A_arbace_go_check_ns_package_A_fn_class); var ifn_2784 lang.IFn; if linked_2783 == nil { ifn_2784 = lang.IFn_Cast(root_2782) } else { ifn_2784 = nil }; var arg_2785 any = d__5; var arg_2786 any = ns_name__1; if linked_2783 == nil { return ifn_2784.Invoke_O_O__O(arg_2785, arg_2786) } else { return linked_2783.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2782, arg_2785, arg_2786) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000318_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2830 *jrt.Class = A_arbace_go_check_resolver_fn__1685000318_A_fn_class; _ = deps__4; if




	fncls__2830 == nil { var fncls__2830d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_resolver_fn__1685000318_A_fn_class = fncls__2830d; tmp2 = fncls__2830d } else { tmp2 = fncls__2830 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :373:1
func A_arbace_go_check_resolver_fn__1685000318_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000318_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000318_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_136, path__1) { return A_arbace_go_check_A_const_268.GetRawRoot__O() } else { var lp__3 any; var root_2787 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2789 lang.IFn

		if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any = t.F_src; var arg_2791 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_269, path__1); var arg_2792 any = path__1; if linked_2788 == nil { lp__3 = ifn_2789.Invoke_O_O_O__O(arg_2790, arg_2791, arg_2792) } else { lp__3 = linked_2788.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2787, arg_2790, arg_2791, arg_2792) }
//line :376:1
		var why__4 any; var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_270.Invoke_O__O(t.F_s)



		if jrt.J2g_Truth(temp__1927000414__auto____4) { var rf__5 any = temp__1927000414__auto____4; why__4 = lang.IFn_Cast(rf__5).Invoke_O_O__O(lp__3, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src)) } else { why__4 = nil }
//line :376:1
		var p__5 any
		var or__1927000174__auto____5 any = why__4




		if jrt.J2g_Truth(or__1927000174__auto____5) { p__5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_2793 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2793, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2795 lang.IFn
			if linked_2794 == nil { ifn_2795 = lang.IFn_Cast(root_2793) } else { ifn_2795 = nil }; var arg_2796 any = t.F_s; var arg_2797 any = lp__3; var arg_2798 any = t.F_src; var arg_2799 any = t.F_chain; if linked_2794 == nil { or__1927000174__auto____6 = ifn_2795.Invoke_O_O_O_O__O(arg_2796, arg_2797, arg_2798, arg_2799) } else { or__1927000174__auto____6 = linked_2794.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2793, arg_2796, arg_2797, arg_2798, arg_2799) }
//line :382:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { p__5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 any; var and__1927000168__auto____7 any; var root_2800 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2800, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2802 lang.IFn

				if linked_2801 == nil { ifn_2802 = lang.IFn_Cast(root_2800) } else { ifn_2802 = nil }; var arg_2803 any; var root_2804 any = A_arbace_go_check_A_const_272.GetRawRoot__O(); var linked_2805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2804, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2806 lang.IFn; if linked_2805 == nil { ifn_2806 = lang.IFn_Cast(root_2804) } else { ifn_2806 = nil }; var arg_2807 any; var root_2809 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any; var root_2813 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2813, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2815 lang.IFn; if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any = lp__3; var arg_2817 any = A_arbace_go_check_A_const_274; if linked_2814 == nil { arg_2812 = ifn_2815.Invoke_O_O__O(arg_2816, arg_2817) } else { arg_2812 = linked_2814.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2813, arg_2816, arg_2817) }; if linked_2810 == nil { arg_2807 = ifn_2811.Invoke_O__O(arg_2812) } else { arg_2807 = linked_2810.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2809, arg_2812) }; var arg_2808 any = Lit_137; if linked_2805 == nil { arg_2803 = ifn_2806.Invoke_O_O__O(arg_2807, arg_2808) } else { arg_2803 = linked_2805.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2804, arg_2807, arg_2808) }; if linked_2801 == nil { and__1927000168__auto____7 = ifn_2802.Invoke_O__O(arg_2803) } else { and__1927000168__auto____7 = linked_2801.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2800, arg_2803) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____7 = nil } else { or__1927000174__auto____7 = nil }
//line :382:1
				if jrt.J2g_Truth(or__1927000174__auto____7) { p__5 = or__1927000174__auto____7 } else {


					var root_2818 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2818, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2820 lang.IFn; if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any = t.F_s; var arg_2822 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2823 any = t.F_src; var arg_2824 any = t.F_chain; if linked_2819 == nil { p__5 = ifn_2820.Invoke_O_O_O_O__O(arg_2821, arg_2822, arg_2823, arg_2824) } else { p__5 = linked_2819.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2818, arg_2821, arg_2822, arg_2823, arg_2824) } } } }
//line :376:1
		return p__5 } }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2825 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, A_arbace_go_check_ns_package_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = t.F_s; var arg_2829 any = ns_name__1; if linked_2826 == nil { return ifn_2827.Invoke_O_O__O(arg_2828, arg_2829) } else { return linked_2826.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2825, arg_2828, arg_2829)
	}
}











func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :388:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2912 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2912, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2914 lang.IFn; if linked_2913 == nil { ifn_2914 = lang.IFn_Cast(root_2912) } else { ifn_2914 = nil }; var arg_2915 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2916 any = chain__3; if linked_2913 == nil { tmp1 = ifn_2914.Invoke_O_O__O(arg_2915, arg_2916) } else { tmp1 = linked_2913.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2912, arg_2915, arg_2916) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2917 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2917, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2919 lang.IFn
		if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_110, nil); var tmp4 any; var root_2922 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2922, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2924 lang.IFn; if linked_2923 == nil { ifn_2924 = lang.IFn_Cast(root_2922) } else { ifn_2924 = nil }; var arg_2925 any = Lit_111; var arg_2926 any; var root_2927 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2927, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2929 lang.IFn; if linked_2928 == nil { ifn_2929 = lang.IFn_Cast(root_2927) } else { ifn_2929 = nil }; var arg_2930 any = chain__3; var arg_2931 any = path__1; if linked_2928 == nil { arg_2926 = ifn_2929.Invoke_O_O__O(arg_2930, arg_2931) } else { arg_2926 = linked_2928.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2927, arg_2930, arg_2931) }; if linked_2923 == nil { tmp4 = ifn_2924.Invoke_O_O__O(arg_2925, arg_2926) } else { tmp4 = linked_2923.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2922, arg_2925, arg_2926) }; arg_2920 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2921 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111, path__1)); if linked_2918 == nil { tmp2 = ifn_2919.Invoke_O_O__O(arg_2920, arg_2921) } else { tmp2 = linked_2918.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2917, arg_2920, arg_2921) }
//line :391:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :388:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_266.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2831 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2831, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2833 lang.IFn; if linked_2832 == nil { ifn_2833 = lang.IFn_Cast(root_2831) } else { ifn_2833 = nil }; var arg_2834 any = lang.IFn_Cast(A_arbace_go_check_A_const_275.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2832 == nil { and__1927000168__auto____6 = ifn_2833.Invoke_O__O(arg_2834) } else { and__1927000168__auto____6 = linked_2832.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2831, arg_2834) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_266.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2835 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2837 lang.IFn

		if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = d__6; var arg_2839 any = path__1; var arg_2840 any = importer__2; var arg_2841 any = chain__3; if linked_2836 == nil { return ifn_2837.Invoke_O_O_O_O__O(arg_2838, arg_2839, arg_2840, arg_2841) } else { return linked_2836.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2835, arg_2838, arg_2839, arg_2840, arg_2841) } } else {
//line :393:1
			var cache__6 any = A_arbace_go_check_A_const_262.Invoke_O__O(s__0); var p__7 any; var root_2842 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2842, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2844 lang.IFn



			if linked_2843 == nil { ifn_2844 = lang.IFn_Cast(root_2842) } else { ifn_2844 = nil }; if linked_2843 == nil { p__7 = ifn_2844.Invoke__O() } else { p__7 = linked_2843.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2842) }
//line :393:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2845 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2847 lang.IFn; if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any = prev__8; if linked_2846 == nil { return ifn_2847.Invoke_O__O(arg_2848) } else { return linked_2846.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2845, arg_2848) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_261.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2849 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2849, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2851 lang.IFn; if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__9); if linked_2850 == nil { tmp5 = ifn_2851.Invoke_O__O(arg_2852) } else { tmp5 = linked_2850.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2849, arg_2852) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000321_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2911 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class; if fncls__2911 == nil { var fncls__2911d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class = fncls__2911d; tmp7 = fncls__2911d } else { tmp7 = fncls__2911 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :402:1
						pkg__10 = nil
					}






				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2932 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2932, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2934 lang.IFn; if linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2936 any = A_arbace_go_check_A_const_282; var arg_2937 any; var root_2938 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2938, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2940 lang.IFn; if linked_2939 == nil { ifn_2940 = lang.IFn_Cast(root_2938) } else { ifn_2940 = nil }; var arg_2941 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2942 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_283; var tmp11 any; var root_2943 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = pkg__10; var arg_2947 any = A_arbace_go_check_A_const_72; if linked_2944 == nil { tmp11 = ifn_2945.Invoke_O_O__O(arg_2946, arg_2947) } else { tmp11 = linked_2944.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2943, arg_2946, arg_2947) }; arg_2942 = tmp10.Invoke_O__O(tmp11); if linked_2939 == nil { arg_2937 = ifn_2940.Invoke_O_O__O(arg_2941, arg_2942) } else { arg_2937 = linked_2939.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2938, arg_2941, arg_2942) }; if linked_2933 == nil { tmp9 = ifn_2934.Invoke_O_O_O__O(arg_2935, arg_2936, arg_2937) } else { tmp9 = linked_2933.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2932, arg_2935, arg_2936, arg_2937) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2948 any = A_arbace_go_check_A_const_284.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2948, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = A_arbace_go_check_A_const_263.Invoke_O__O(s__0); var arg_2952 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var arg_2953 any; var root_2955 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_2956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2955, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_2957 lang.IFn; if linked_2956 == nil { ifn_2957 = lang.IFn_Cast(root_2955) } else { ifn_2957 = nil }; var arg_2958 any = path__1; if linked_2956 == nil { arg_2953 = ifn_2957.Invoke_O__O(arg_2958) } else { arg_2953 = linked_2956.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2955, arg_2958) }; var arg_2954 any = path__1; if linked_2949 == nil { ifn_2950.Invoke_O_O_O_O__O(arg_2951, arg_2952, arg_2953, arg_2954) } else { linked_2949.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2948, arg_2951, arg_2952, arg_2953, arg_2954) }
				var root_2959 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2961 lang.IFn; if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = p__7; var arg_2963 any = pkg__10; if linked_2960 == nil { ifn_2961.Invoke_O_O__O(arg_2962, arg_2963) } else { linked_2960.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2959, arg_2962, arg_2963) }
//line :399:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000321_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000321_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000321_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :403:1
func (t *A_arbace_go_check_ensure_package_fn__1685000321_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :403:1
func (t *A_arbace_go_check_ensure_package_fn__1685000321_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var G__1685000322__3_ any = A_arbace_go_check_A_const_109.Invoke_O__O(t.F_s); if lang.Util_Identical_O_O__Z_NoInit(G__1685000322__3_, nil) { tmp2 = nil } else { var root_2853 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2853, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2855 lang.IFn; if linked_2854 == nil { ifn_2855 = lang.IFn_Cast(root_2853) } else { ifn_2855 = nil }; var arg_2856 any = G__1685000322__3_; var arg_2857 any = lang.Tuple_Create_O__IPersistentVector(t.F_path); if linked_2854 == nil { tmp2 = ifn_2855.Invoke_O_O__O(arg_2856, arg_2857) } else { tmp2 = linked_2854.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2853, arg_2856, arg_2857) } }; if jrt.J2g_Truth(tmp2) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp4 any = t.F_src; var tmp5 any; var root_2865 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2865, A_arbace_go_check_resolver_A_fn_class); var ifn_2867 lang.IFn; if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any; var t_ any = t.F_s; t.F_s = nil; arg_2868 = t_; var arg_2869 any; var t__2 any = t.F_src; t.F_src = nil; arg_2869 = t__2; var arg_2870 any; var root_2871 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any; var root_2876 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2879 = t__3; if linked_2877 == nil { arg_2874 = ifn_2878.Invoke_O__O(arg_2879) } else { arg_2874 = linked_2877.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2876, arg_2879) }; var arg_2875 any = t.F_path; if linked_2872 == nil { arg_2870 = ifn_2873.Invoke_O_O__O(arg_2874, arg_2875) } else { arg_2870 = linked_2872.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2871, arg_2874, arg_2875) }; if linked_2866 == nil { tmp5 = ifn_2867.Invoke_O_O_O__O(arg_2868, arg_2869, arg_2870) } else { tmp5 = linked_2866.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2865, arg_2868, arg_2869, arg_2870) }; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, A_arbace_go_check_A_const_109, jrt.Boolean_TRUE.Ref()) } else {
													var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp7 any = t.F_src; var tmp8 any; var root_2885 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, A_arbace_go_check_resolver_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any; var t__4 any = t.F_s; t.F_s = nil; arg_2888 = t__4; var arg_2889 any; var t__5 any = t.F_src; t.F_src = nil; arg_2889 = t__5; var arg_2890 any; var root_2891 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2891, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any; var root_2896 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any; var t__6 any = t.F_chain; t.F_chain = nil; arg_2899 = t__6; if linked_2897 == nil { arg_2894 = ifn_2898.Invoke_O__O(arg_2899) } else { arg_2894 = linked_2897.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2896, arg_2899) }; var arg_2895 any = t.F_path; if linked_2892 == nil { arg_2890 = ifn_2893.Invoke_O_O__O(arg_2894, arg_2895) } else { arg_2890 = linked_2892.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2891, arg_2894, arg_2895) }; if linked_2886 == nil { tmp8 = ifn_2887.Invoke_O_O_O__O(arg_2888, arg_2889, arg_2890) } else { tmp8 = linked_2886.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2885, arg_2888, arg_2889, arg_2890) }; tmp1 = tmp6.Invoke_O_O__O(tmp7, tmp8) } }
//line :403:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_2906 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2908 lang.IFn




		if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any; var t__7 any = t.F_p; t.F_p = nil; arg_2909 = t__7; var arg_2910 any; if linked_2907 == nil { ifn_2908.Invoke_O_O__O(arg_2909, arg_2910) } else { linked_2907.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2906, arg_2909, arg_2910) }
//line :403:1
		var tmp10 any; var root_2900 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2902 lang.IFn





		if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var tmp11 any = t.F_path; var arg_2903 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2904 any; var tmp12 any = A_arbace_go_check_A_const_111; var tmp13 any; var t__8 any = t.F_path; t.F_path = nil; tmp13 = t__8; arg_2904 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); var arg_2905 any = ex__3; if linked_2901 == nil { tmp10 = ifn_2902.Invoke_O_O_O__O(arg_2903, arg_2904, arg_2905) } else { tmp10 = linked_2901.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2900, arg_2903, arg_2904, arg_2905) }
//line :403:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) } }; return tmp1 }











func A_arbace_go_check_check_src_A_New() *A_arbace_go_check_check_src_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_src_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_go_check_check_src_A) Ctor() {}
//line :415:1
func (t *A_arbace_go_check_check_src_A) Invoke_O_O_O__O(self, s__0, src__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp2 any; var root_2969 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, A_arbace_go_check_resolver_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = s__0; var arg_2973 any = src__1; var arg_2974 any = lang.PersistentVector_EMPTY.Ref(); if linked_2970 == nil { tmp2 = ifn_2971.Invoke_O_O_O__O(arg_2972, arg_2973, arg_2974) } else { tmp2 = linked_2970.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2969, arg_2972, arg_2973, arg_2974) }; return tmp1.Invoke_O_O__O(src__1, tmp2)
}










func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :430:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var temp__1927000408__auto____2 any = A_arbace_go_check_A_const_285.Get__O(); if
											jrt.J2g_Truth(temp__1927000408__auto____2) { var f__3 any = temp__1927000408__auto____2; var G__1685000326__4_ any = corpus__0
												switch lang.Util_Hash_O__I_NoInit(G__1685000326__4_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_93) { var tmp1 any = A_arbace_go_check_A_const_286; var tmp2 any = A_arbace_go_check_A_const_288; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_287; var tmp5 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_290)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_97) { var tmp6 any = A_arbace_go_check_A_const_286; var tmp7 any = A_arbace_go_check_A_const_288; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_291; var tmp10 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_292)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_54) { var tmp11 any = A_arbace_go_check_A_const_286; var tmp12 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_99), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_293)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_100) { var tmp13 any = A_arbace_go_check_A_const_286; var tmp14 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_101), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_294)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_102) { var tmp15 any = A_arbace_go_check_A_const_286; var tmp16 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_301)) }; default:}; var tmp17 any; var root_2976 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2976, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2978 lang.IFn







		if linked_2977 == nil { ifn_2978 = lang.IFn_Cast(root_2976) } else { ifn_2978 = nil }; var arg_2979 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2980 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295, corpus__0)); if linked_2977 == nil { tmp17 = ifn_2978.Invoke_O_O__O(arg_2979, arg_2980) } else { tmp17 = linked_2977.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2976, arg_2979, arg_2980) }
//line :432:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) } else {
//line :431:1
			var G__1685000327__3_ any = corpus__0









			switch lang.Util_Hash_O__I_NoInit(G__1685000327__3_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_93) { var tmp18 any = A_arbace_go_check_A_const_286; var tmp19 any = A_arbace_go_check_A_const_288; var tmp20 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))); var tmp21 any = A_arbace_go_check_A_const_287; var tmp22 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp20, tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_297)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_97) { var tmp23 any = A_arbace_go_check_A_const_286; var tmp24 any = A_arbace_go_check_A_const_288; var tmp25 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))); var tmp26 any = A_arbace_go_check_A_const_291; var tmp27 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp25, tmp26, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_106), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_298)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_54) { var tmp28 any = A_arbace_go_check_A_const_286; var tmp29 any = A_arbace_go_check_A_const_288; var tmp30 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(); var tmp31 any = A_arbace_go_check_A_const_302; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_299)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_100) { var tmp32 any = A_arbace_go_check_A_const_286; var tmp33 any = A_arbace_go_check_A_const_288; var tmp34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(); var tmp35 any = A_arbace_go_check_A_const_302; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_109), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_300)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_102) { var tmp36 any = A_arbace_go_check_A_const_286; var tmp37 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp36, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_303)) }; default:}; var tmp38 any; var root_2982 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2984 lang.IFn












			if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2986 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295, corpus__0)); if linked_2983 == nil { tmp38 = ifn_2984.Invoke_O_O__O(arg_2985, arg_2986) } else { tmp38 = linked_2983.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2982, arg_2985, arg_2986) }
//line :441:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp38))) } }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :456:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :456:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000330__0 any) any { var map__1685000331__2 any = p__1685000330__0; var map__1685000331__3 any; if lang.ISeq_InstanceOf(map__1685000331__2) { var tmp1 any; var root_2987 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2987, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2989 lang.IFn; if linked_2988 == nil { ifn_2989 = lang.IFn_Cast(root_2987) } else { ifn_2989 = nil }; var arg_2990 any = map__1685000331__2; if linked_2988 == nil { tmp1 = ifn_2989.Invoke_O__O(arg_2990) } else { tmp1 = linked_2988.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2987, arg_2990) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2991 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2993 lang.IFn; if linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any = map__1685000331__2; if linked_2992 == nil { tmp2 = ifn_2993.Invoke_O__O(arg_2994) } else { tmp2 = linked_2992.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2991, arg_2994) }; map__1685000331__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2995 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any = map__1685000331__2; if linked_2996 == nil { tmp3 = ifn_2997.Invoke_O__O(arg_2998) } else { tmp3 = linked_2996.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2995, arg_2998) }; if jrt.J2g_Truth(tmp3) { var root_2999 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2999, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3001 lang.IFn; if linked_3000 == nil { ifn_3001 = lang.IFn_Cast(root_2999) } else { ifn_3001 = nil }; var arg_3002 any = map__1685000331__2; if linked_3000 == nil { map__1685000331__3 = ifn_3001.Invoke_O__O(arg_3002) } else { map__1685000331__3 = linked_3000.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2999, arg_3002) } } else { map__1685000331__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000331__3 = map__1685000331__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000331__3, A_arbace_go_check_A_const_286); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000331__3, A_arbace_go_check_A_const_112); var root_3003 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, A_arbace_go_check_session_A_fn_class); var ifn_3005 lang.IFn; if
											linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000333_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__3019 *jrt.Class = A_arbace_go_check_std_session_fn__1685000333_A_fn_class; if fncls__3019 == nil { var fncls__3019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_go_check_std_session_fn__1685000333_A_fn_class = fncls__3019d; tmp5 = fncls__3019d } else { tmp5 = fncls__3019 }; arg_3006 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_3004 == nil { return ifn_3005.Invoke_O__O(arg_3006) } else { return linked_3004.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3003, arg_3006) } }
//line :457:1
func A_arbace_go_check_std_session_fn__1685000333_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000333_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000333_A{}; t.Ctor_O_O(p0, p1); return t }
//line :457:1
func (t *A_arbace_go_check_std_session_fn__1685000333_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :457:1
func (t *A_arbace_go_check_std_session_fn__1685000333_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_3007 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3007, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3009 lang.IFn; if linked_3008 == nil { ifn_3009 = lang.IFn_Cast(root_3007) } else { ifn_3009 = nil }; var arg_3010 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__3018 *jrt.Class = A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class; if fncls__3018 == nil { var fncls__3018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class = fncls__3018d; tmp2 = fncls__3018d } else { tmp2 = fncls__3018 }; arg_3010 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3011 any = t.F_roots; if linked_3008 == nil { return ifn_3009.Invoke_O_O__O(arg_3010, arg_3011) } else { return linked_3008.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3007, arg_3010, arg_3011) } }
//line :458:1
func A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :458:1
func (t *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :458:1
func (t *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A) Invoke_O_O__O(self, p1__1685000329_SHARP___1 any) any { var root_3012 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = p1__1685000329_SHARP___1; var arg_3016 any = t.F_path; var arg_3017 any = t.F_config; if linked_3013 == nil { return ifn_3014.Invoke_O_O_O__O(arg_3015, arg_3016, arg_3017) } else { return linked_3013.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_3012, arg_3015, arg_3016, arg_3017) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :464:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_3020 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3022 lang.IFn; if


	linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = xs__2; if linked_3021 == nil { xs__4 = ifn_3022.Invoke_O__O(arg_3023) } else { xs__4 = linked_3021.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3020, arg_3023) }; var q__5 any = /*line :464:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_3024 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3026 lang.IFn; if





	linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__3096 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class; if fncls__3096 == nil { var fncls__3096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class = fncls__3096d; tmp2 = fncls__3096d } else { tmp2 = fncls__3096 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_3097 any = A_arbace_go_check_A_const_310.GetRawRoot__O(); var linked_3098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3097, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3099 lang.IFn; if linked_3098 == nil { ifn_3099 = lang.IFn_Cast(root_3097) } else { ifn_3099 = nil }; var arg_3100 any = n__0; if linked_3098 == nil { tmp4 = ifn_3099.Invoke_O__O(arg_3100) } else { tmp4 = linked_3098.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3097, arg_3100) }; arg_3027 = tmp3.Invoke_O__O(tmp4); if linked_3025 == nil { workers__7 = ifn_3026.Invoke_O__O(arg_3027) } else { workers__7 = linked_3025.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3024, arg_3027) }; var seq_1685000352__8 any; var root_3105 any = /*line :464:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3105, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3107 lang.IFn; if















	linked_3106 == nil { ifn_3107 = lang.IFn_Cast(root_3105) } else { ifn_3107 = nil }; var arg_3108 any = workers__7; if linked_3106 == nil { seq_1685000352__8 = ifn_3107.Invoke_O__O(arg_3108) } else { seq_1685000352__8 = linked_3106.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3105, arg_3108) }; var chunk_1685000353__9 any; var count_1685000354__10 int64 = 0; var i_1685000355__11 int64 = 0; L1:
//line :464:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000355__11, count_1685000354__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000353__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000355__11)); var root_3125 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3125, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3127 lang.IFn; if linked_3126 == nil { ifn_3127 = lang.IFn_Cast(root_3125) } else { ifn_3127 = nil }; var arg_3128 any = w__12; if linked_3126 == nil { ifn_3127.Invoke_O__O(arg_3128) } else { linked_3126.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3125, arg_3128) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000355__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_3109 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3109, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3111 lang.IFn; if linked_3110 == nil { ifn_3111 = lang.IFn_Cast(root_3109) } else { ifn_3111 = nil }; var arg_3112 any = seq_1685000352__8; if linked_3110 == nil { temp__1927000414__auto____12 = ifn_3111.Invoke_O__O(arg_3112) } else { temp__1927000414__auto____12 = linked_3110.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3109, arg_3112) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000352__13 any = temp__1927000414__auto____12; var tmp5 any; var root_3113 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3113, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3115 lang.IFn; if linked_3114 == nil { ifn_3115 = lang.IFn_Cast(root_3113) } else { ifn_3115 = nil }; var arg_3116 any = seq_1685000352__13; if linked_3114 == nil { tmp5 = ifn_3115.Invoke_O__O(arg_3116) } else { tmp5 = linked_3114.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3113, arg_3116) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_3117 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3117, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3119 lang.IFn; if linked_3118 == nil { ifn_3119 = lang.IFn_Cast(root_3117) } else { ifn_3119 = nil }; var arg_3120 any = seq_1685000352__13; if linked_3118 == nil { c__1927000678__auto____14 = ifn_3119.Invoke_O__O(arg_3120) } else { c__1927000678__auto____14 = linked_3118.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3117, arg_3120) }; var tmp6 any; var root_3129 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3129, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3131 lang.IFn; if linked_3130 == nil { ifn_3131 = lang.IFn_Cast(root_3129) } else { ifn_3131 = nil }; var arg_3132 any = seq_1685000352__13; if linked_3130 == nil { tmp6 = ifn_3131.Invoke_O__O(arg_3132) } else { tmp6 = linked_3130.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3129, arg_3132) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_3121 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3121, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3123 lang.IFn; if linked_3122 == nil { ifn_3123 = lang.IFn_Cast(root_3121) } else { ifn_3123 = nil }; var arg_3124 any = seq_1685000352__13; if linked_3122 == nil { w__14 = ifn_3123.Invoke_O__O(arg_3124) } else { w__14 = linked_3122.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3121, arg_3124) }; var root_3133 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3133, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3135 lang.IFn; if linked_3134 == nil { ifn_3135 = lang.IFn_Cast(root_3133) } else { ifn_3135 = nil }; var arg_3136 any = w__14; if linked_3134 == nil { ifn_3135.Invoke_O__O(arg_3136) } else { linked_3134.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3133, arg_3136) }; var tmp7 any; var root_3137 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3137, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3139 lang.IFn; if linked_3138 == nil { ifn_3139 = lang.IFn_Cast(root_3137) } else { ifn_3139 = nil }; var arg_3140 any = seq_1685000352__13; if linked_3138 == nil { tmp7 = ifn_3139.Invoke_O__O(arg_3140) } else { tmp7 = linked_3138.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3137, arg_3140) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :464:1
		break L1 }; var root_3101 any =
















	A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3101, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3103 lang.IFn; if linked_3102 == nil { ifn_3103 = lang.IFn_Cast(root_3101) } else { ifn_3103 = nil }; var arg_3104 any = out__6; if linked_3102 == nil { return ifn_3103.Invoke_O__O(arg_3104) } else { return linked_3102.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3101, arg_3104) } }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A) Invoke_O_O__O(self, s__1685000339__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O_O(self, t.F_f, t.F_out, t.F_q, t.F_xs, s__1685000339__1); var tmp2 *jrt.Class; var fncls__3095 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class; if fncls__3095 == nil { var fncls__3095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class = fncls__3095d; tmp2 = fncls__3095d } else { tmp2 = fncls__3095 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A) Ctor_O_O_O_O_O_O(c__iter__1685000338, c__f, c__out, c__q, c__xs, c__s__1685000339 any) { t.F_iter__1685000338 = c__iter__1685000338; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_s__1685000339 = c__s__1685000339 }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A) Invoke_O__O(self any) any { { var s__1685000339__1 any; var t_ any = t.F_s__1685000339; t.F_s__1685000339 = nil; s__1685000339__1 = t_; for { var temp__1927000414__auto____2 any; var root_3028 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3028, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3030 lang.IFn; if linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any = s__1685000339__1; if linked_3029 == nil { temp__1927000414__auto____2 = ifn_3030.Invoke_O__O(arg_3031) } else { temp__1927000414__auto____2 = linked_3029.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3028, arg_3031) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000339__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3032 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3032, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3034 lang.IFn; if linked_3033 == nil { ifn_3034 = lang.IFn_Cast(root_3032) } else { ifn_3034 = nil }; var arg_3035 any = s__1685000339__3; if linked_3033 == nil { tmp1 = ifn_3034.Invoke_O__O(arg_3035) } else { tmp1 = linked_3033.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3032, arg_3035) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3036 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3036, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3038 lang.IFn; if linked_3037 == nil { ifn_3038 = lang.IFn_Cast(root_3036) } else { ifn_3038 = nil }; var arg_3039 any = s__1685000339__3; if linked_3037 == nil { c__1927001037__auto____4 = ifn_3038.Invoke_O__O(arg_3039) } else { c__1927001037__auto____4 = linked_3037.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3036, arg_3039) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000341__6 any; var root_3040 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3041 == nil { b__1685000341__6 = ifn_3042.Invoke_O__O(arg_3043) } else { b__1685000341__6 = linked_3041.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3040, arg_3043) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_O_I_O_O(t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, b__1685000341__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3054 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class; if fncls__3054 == nil { var fncls__3054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class = fncls__3054d; tmp3 = fncls__3054d } else { tmp3 = fncls__3054 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3055 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3057 lang.IFn; if linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any; var root_3060 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3062 lang.IFn; if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any = b__1685000341__6; if linked_3061 == nil { arg_3058 = ifn_3062.Invoke_O__O(arg_3063) } else { arg_3058 = linked_3061.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3060, arg_3063) }; var arg_3059 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp5 any; var root_3064 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3064, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3066 lang.IFn; if linked_3065 == nil { ifn_3066 = lang.IFn_Cast(root_3064) } else { ifn_3066 = nil }; var arg_3067 any = s__1685000339__3; if linked_3065 == nil { tmp5 = ifn_3066.Invoke_O__O(arg_3067) } else { tmp5 = linked_3065.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3064, arg_3067) }; arg_3059 = tmp4.Invoke_O__O(tmp5); if linked_3056 == nil { return ifn_3057.Invoke_O_O__O(arg_3058, arg_3059) } else { return linked_3056.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3055, arg_3058, arg_3059) } } else { var root_3068 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3068, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3070 lang.IFn; if linked_3069 == nil { ifn_3070 = lang.IFn_Cast(root_3068) } else { ifn_3070 = nil }; var arg_3071 any; var root_3073 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3073, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3075 lang.IFn; if linked_3074 == nil { ifn_3075 = lang.IFn_Cast(root_3073) } else { ifn_3075 = nil }; var arg_3076 any = b__1685000341__6; if linked_3074 == nil { arg_3071 = ifn_3075.Invoke_O__O(arg_3076) } else { arg_3071 = linked_3074.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3073, arg_3076) }; var arg_3072 any; if linked_3069 == nil { return ifn_3070.Invoke_O_O__O(arg_3071, arg_3072) } else { return linked_3069.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3068, arg_3071, arg_3072) } } } else { var ___4 any; var root_3077 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3079 lang.IFn; _ = ___4; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = s__1685000339__3; if linked_3078 == nil { ___4 = ifn_3079.Invoke_O__O(arg_3080) } else { ___4 = linked_3078.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3077, arg_3080) }; var root_3081 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any; var root_3086 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3088 lang.IFn
															if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__3090 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class; if fncls__3090 == nil { var fncls__3090d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class = fncls__3090d; tmp7 = fncls__3090d } else { tmp7 = fncls__3090 }; arg_3089 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3087 == nil { arg_3084 = ifn_3088.Invoke_O__O(arg_3089) } else { arg_3084 = linked_3087.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3086, arg_3089) }
//line :470:1
	var arg_3085 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp9 any; var root_3091 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3091, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3093 lang.IFn; if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = s__1685000339__3; if linked_3092 == nil { tmp9 = ifn_3093.Invoke_O__O(arg_3094) } else { tmp9 = linked_3092.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3091, arg_3094) }; arg_3085 = tmp8.Invoke_O__O(tmp9); if linked_3082 == nil { return ifn_3083.Invoke_O_O__O(arg_3084, arg_3085) } else { return linked_3082.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3081, arg_3084, arg_3085) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Ctor_O_O_O_O_I_O_O(c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__b__1685000341, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000341 = c__b__1685000341; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Invoke_O__O(self any) any { { var i__1685000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000340__1)); var root_3044 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3046 lang.IFn; _ = ___2; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = t.F_b__1685000341; var arg_3048 any; var root_3049 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3051 lang.IFn
																if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__3053 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class; if fncls__3053 == nil { var fncls__3053d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class = fncls__3053d; tmp3 = fncls__3053d } else { tmp3 = fncls__3053 }; arg_3052 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_3050 == nil { arg_3048 = ifn_3051.Invoke_O__O(arg_3052) } else { arg_3048 = linked_3050.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3049, arg_3052) }
//line :470:1
	if linked_3045 == nil { ifn_3046.Invoke_O_O__O(arg_3047, arg_3048) } else { linked_3045.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3044, arg_3047, arg_3048) }; i__1685000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_309) }
		var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_out); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :471:1*/panic("j2g: unreachable") }
//line :471:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_309) }
		var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_out); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :471:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :483:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_3141 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_3142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3141, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3143 lang.IFn; if linked_3142 == nil { ifn_3143 = lang.IFn_Cast(root_3141) } else { ifn_3143 = nil }; var arg_3144 any = pkg__0; var arg_3145 any = A_arbace_go_check_A_const_237; if linked_3142 == nil { return ifn_3143.Invoke_O_O__O(arg_3144, arg_3145) } else { return linked_3142.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3141, arg_3144, arg_3145) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :485:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :485:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_111; var tmp2 any = A_arbace_go_check_A_const_238; var tmp3 any = A_arbace_go_check_A_const_74; var tmp4 any = A_arbace_go_check_A_const_79; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_312; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_115, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :485:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_313, A_arbace_go_check_A_const_314))), A_arbace_go_check_A_const_164, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_83, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_153, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_155, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_140, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_166, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_157, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_145, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_311, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :492:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_3146 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3146, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3148 lang.IFn; if


	linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; var arg_3149 any = corpus__0; if linked_3147 == nil { cc__3 = ifn_3148.Invoke_O__O(arg_3149) } else { cc__3 = linked_3147.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3146, arg_3149) }; var s__4 any; var root_3150 any = /*line :492:1*/A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3150, A_arbace_go_check_std_session_A_fn_class); var ifn_3152 lang.IFn; if



	linked_3151 == nil { ifn_3152 = lang.IFn_Cast(root_3150) } else { ifn_3152 = nil }; var arg_3153 any = cc__3; if linked_3151 == nil { s__4 = ifn_3152.Invoke_O__O(arg_3153) } else { s__4 = linked_3151.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3150, arg_3153) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :492:1*/A_arbace_go_check_A_const_291.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_287.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_3154 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3154, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3156 lang.IFn
		if linked_3155 == nil { ifn_3156 = lang.IFn_Cast(root_3154) } else { ifn_3156 = nil }; var arg_3157 any = A_arbace_go_check_A_const_286.Invoke_O__O(cc__3); if linked_3155 == nil { root__5 = ifn_3156.Invoke_O__O(arg_3157) } else { root__5 = linked_3155.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3154, arg_3157) }
		var root_3158 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3158, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3160 lang.IFn; if linked_3159 == nil { ifn_3160 = lang.IFn_Cast(root_3158) } else { ifn_3160 = nil }; var arg_3161 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_New(); var tmp3 *jrt.Class; var fncls__3228 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class; if fncls__3228 == nil { var fncls__3228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class = fncls__3228d; tmp3 = fncls__3228d } else { tmp3 = fncls__3228 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_3229 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3229, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3231 lang.IFn; if linked_3230 == nil { ifn_3231 = lang.IFn_Cast(root_3229) } else { ifn_3231 = nil }; var arg_3232 any = root__5; var arg_3233 any = Lit_36; if linked_3230 == nil { tmp5 = ifn_3231.Invoke_O_O__O(arg_3232, arg_3233) } else { tmp5 = linked_3230.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3229, arg_3232, arg_3233) }; arg_3161 = tmp4.Invoke_O__O(tmp5); if linked_3159 == nil { std_pkgs__5 = ifn_3160.Invoke_O__O(arg_3161) } else { std_pkgs__5 = linked_3159.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3158, arg_3161) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_3234 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3236 lang.IFn; if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = jobs__1; var arg_3238 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000370_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__3256 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class
		if fncls__3256 == nil { var fncls__3256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class = fncls__3256d; tmp7 = fncls__3256d } else { tmp7 = fncls__3256 }; arg_3238 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :504:1
		var arg_3239 any = std_pkgs__5; if linked_3235 == nil { return ifn_3236.Invoke_O_O_O__O(arg_3237, arg_3238, arg_3239) } else { return linked_3235.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3234, arg_3237, arg_3238, arg_3239) } } else {
//line :502:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_291.Invoke_O__O(cc__3)) { var map__1685000372__6 any = A_arbace_go_check_A_const_291.Invoke_O__O(cc__3); var map__1685000372__7 any








				if lang.ISeq_InstanceOf(map__1685000372__6) { var tmp8 any; var root_3257 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3257, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3259 lang.IFn; if linked_3258 == nil { ifn_3259 = lang.IFn_Cast(root_3257) } else { ifn_3259 = nil }; var arg_3260 any = map__1685000372__6; if linked_3258 == nil { tmp8 = ifn_3259.Invoke_O__O(arg_3260) } else { tmp8 = linked_3258.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3257, arg_3260) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_3261 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3261, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3263 lang.IFn; if linked_3262 == nil { ifn_3263 = lang.IFn_Cast(root_3261) } else { ifn_3263 = nil }; var arg_3264 any = map__1685000372__6; if linked_3262 == nil { tmp9 = ifn_3263.Invoke_O__O(arg_3264) } else { tmp9 = linked_3262.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3261, arg_3264) }; map__1685000372__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp9)).Ref() } else { var tmp10 any; var root_3265 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3267 lang.IFn; if linked_3266 == nil { ifn_3267 = lang.IFn_Cast(root_3265) } else { ifn_3267 = nil }; var arg_3268 any = map__1685000372__6; if linked_3266 == nil { tmp10 = ifn_3267.Invoke_O__O(arg_3268) } else { tmp10 = linked_3266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3265, arg_3268) }; if jrt.J2g_Truth(tmp10) { var root_3269 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3269, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3271 lang.IFn; if linked_3270 == nil { ifn_3271 = lang.IFn_Cast(root_3269) } else { ifn_3271 = nil }; var arg_3272 any = map__1685000372__6; if linked_3270 == nil { map__1685000372__7 = ifn_3271.Invoke_O__O(arg_3272) } else { map__1685000372__7 = linked_3270.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3269, arg_3272) } } else { map__1685000372__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000372__7 = map__1685000372__6 }
//line :502:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_288); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_289); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_288, dir__8)); var root_3273 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3273, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3275 lang.IFn










				if linked_3274 == nil { ifn_3275 = lang.IFn_Cast(root_3273) } else { ifn_3275 = nil }; var arg_3276 any = jobs__1; var arg_3277 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000374_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__3321 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class
				if fncls__3321 == nil { var fncls__3321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class = fncls__3321d; tmp12 = fncls__3321d } else { tmp12 = fncls__3321 }; arg_3277 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :513:1
				var arg_3278 any; var root_3322 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3322, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3324 lang.IFn








				if linked_3323 == nil { ifn_3324 = lang.IFn_Cast(root_3322) } else { ifn_3324 = nil }; var arg_3325 any = root__10; var arg_3326 any = sub__9; if linked_3323 == nil { arg_3278 = ifn_3324.Invoke_O_O__O(arg_3325, arg_3326) } else { arg_3278 = linked_3323.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3322, arg_3325, arg_3326) }
//line :513:1
				if linked_3274 == nil { return ifn_3275.Invoke_O_O_O__O(arg_3276, arg_3277, arg_3278) } else { return linked_3274.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3273, arg_3276, arg_3277, arg_3278) } } else {
//line :502:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_287.Invoke_O__O(cc__3)) { var map__1685000376__6 any = A_arbace_go_check_A_const_287.Invoke_O__O(cc__3); var map__1685000376__7 any





















						if lang.ISeq_InstanceOf(map__1685000376__6) { var tmp13 any; var root_3327 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3327, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3329 lang.IFn; if linked_3328 == nil { ifn_3329 = lang.IFn_Cast(root_3327) } else { ifn_3329 = nil }; var arg_3330 any = map__1685000376__6; if linked_3328 == nil { tmp13 = ifn_3329.Invoke_O__O(arg_3330) } else { tmp13 = linked_3328.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3327, arg_3330) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_3331 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3331, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3333 lang.IFn; if linked_3332 == nil { ifn_3333 = lang.IFn_Cast(root_3331) } else { ifn_3333 = nil }; var arg_3334 any = map__1685000376__6; if linked_3332 == nil { tmp14 = ifn_3333.Invoke_O__O(arg_3334) } else { tmp14 = linked_3332.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3331, arg_3334) }; map__1685000376__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp14)).Ref() } else { var tmp15 any; var root_3335 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3335, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3337 lang.IFn; if linked_3336 == nil { ifn_3337 = lang.IFn_Cast(root_3335) } else { ifn_3337 = nil }; var arg_3338 any = map__1685000376__6; if linked_3336 == nil { tmp15 = ifn_3337.Invoke_O__O(arg_3338) } else { tmp15 = linked_3336.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3335, arg_3338) }; if jrt.J2g_Truth(tmp15) { var root_3339 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3339, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3341 lang.IFn; if linked_3340 == nil { ifn_3341 = lang.IFn_Cast(root_3339) } else { ifn_3341 = nil }; var arg_3342 any = map__1685000376__6; if linked_3340 == nil { map__1685000376__7 = ifn_3341.Invoke_O__O(arg_3342) } else { map__1685000376__7 = linked_3340.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3339, arg_3342) } } else { map__1685000376__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000376__7 = map__1685000376__6 }
//line :502:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000376__7, A_arbace_go_check_A_const_288); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000376__7, A_arbace_go_check_A_const_289); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_288, dir__8_2)); var pfs__11 any; var root_3343 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3345 lang.IFn























						if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = root__10_2; var arg_3347 any = sub__9_2; if linked_3344 == nil { pfs__11 = ifn_3345.Invoke_O_O__O(arg_3346, arg_3347) } else { pfs__11 = linked_3344.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3343, arg_3346, arg_3347) }
//line :502:1
						var tests__12 any; var root_3348 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3348, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3350 lang.IFn

























						if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000378_A_New(); var tmp17 *jrt.Class; var fncls__3358 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class; if fncls__3358 == nil { var fncls__3358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class = fncls__3358d; tmp17 = fncls__3358d } else { tmp17 = fncls__3358 }; arg_3351 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3352 any = pfs__11; if linked_3349 == nil { tests__12 = ifn_3350.Invoke_O_O__O(arg_3351, arg_3352) } else { tests__12 = linked_3349.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3348, arg_3351, arg_3352)
						}


						var root_3359 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3359, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3361 lang.IFn; if linked_3360 == nil { ifn_3361 = lang.IFn_Cast(root_3359) } else { ifn_3361 = nil }; var arg_3362 any; var root_3363 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3363, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3365 lang.IFn; if linked_3364 == nil { ifn_3365 = lang.IFn_Cast(root_3363) } else { ifn_3365 = nil }; var arg_3366 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var arg_3367 any; var root_3368 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3368, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3370 lang.IFn
						if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any = jobs__1; var arg_3372 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000384_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__3601 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class
						if fncls__3601 == nil { var fncls__3601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class = fncls__3601d; tmp19 = fncls__3601d } else { tmp19 = fncls__3601 }; arg_3372 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :533:1
						var arg_3373 any; var root_3602 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_3603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3602, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3604 lang.IFn














						if linked_3603 == nil { ifn_3604 = lang.IFn_Cast(root_3602) } else { ifn_3604 = nil }; var arg_3605 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); var arg_3606 any = tests__12; if linked_3603 == nil { arg_3373 = ifn_3604.Invoke_O_O__O(arg_3605, arg_3606) } else { arg_3373 = linked_3603.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3602, arg_3605, arg_3606) }
//line :533:1
						if linked_3369 == nil { arg_3367 = ifn_3370.Invoke_O_O_O__O(arg_3371, arg_3372, arg_3373) } else { arg_3367 = linked_3369.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3368, arg_3371, arg_3372, arg_3373) }
//line :532:1
						if linked_3364 == nil { arg_3362 = ifn_3365.Invoke_O_O__O(arg_3366, arg_3367) } else { arg_3362 = linked_3364.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3363, arg_3366, arg_3367) }; if linked_3360 == nil { return ifn_3361.Invoke_O__O(arg_3362) } else { return linked_3360.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3359, arg_3362) } } else {
//line :502:1
							return nil } } } }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_New() *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A) Ctor() {}
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A) Invoke_O_O__O(self, s__1685000361__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_New_O_O(s__1685000361__1, self); var tmp2 *jrt.Class; var fncls__3227 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class; if fncls__3227 == nil { var fncls__3227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class = fncls__3227d; tmp2 = fncls__3227d } else { tmp2 = fncls__3227 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A{}; t.Ctor_O_O(p0, p1); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A) Ctor_O_O(c__s__1685000361, c__iter__1685000360 any) { t.F_s__1685000361 = c__s__1685000361; t.F_iter__1685000360 = c__iter__1685000360 }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A) Invoke_O__O(self any) any { { var s__1685000361__1 any; var t_ any = t.F_s__1685000361; t.F_s__1685000361 = nil; s__1685000361__1 = t_; for { var temp__1927000414__auto____2 any; var root_3162 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3162, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3164 lang.IFn; if linked_3163 == nil { ifn_3164 = lang.IFn_Cast(root_3162) } else { ifn_3164 = nil }; var arg_3165 any = s__1685000361__1; if linked_3163 == nil { temp__1927000414__auto____2 = ifn_3164.Invoke_O__O(arg_3165) } else { temp__1927000414__auto____2 = linked_3163.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3162, arg_3165) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000361__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3166 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3166, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3168 lang.IFn; if linked_3167 == nil { ifn_3168 = lang.IFn_Cast(root_3166) } else { ifn_3168 = nil }; var arg_3169 any = s__1685000361__3; if linked_3167 == nil { tmp1 = ifn_3168.Invoke_O__O(arg_3169) } else { tmp1 = linked_3167.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3166, arg_3169) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3170 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3170, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3172 lang.IFn; if linked_3171 == nil { ifn_3172 = lang.IFn_Cast(root_3170) } else { ifn_3172 = nil }; var arg_3173 any = s__1685000361__3; if linked_3171 == nil { c__1927001037__auto____4 = ifn_3172.Invoke_O__O(arg_3173) } else { c__1927001037__auto____4 = linked_3171.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3170, arg_3173) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000363__6 any; var root_3174 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3174, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3176 lang.IFn; if linked_3175 == nil { ifn_3176 = lang.IFn_Cast(root_3174) } else { ifn_3176 = nil }; var arg_3177 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3175 == nil { b__1685000363__6 = ifn_3176.Invoke_O__O(arg_3177) } else { b__1685000363__6 = linked_3175.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3174, arg_3177) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1685000363__6); var tmp3 *jrt.Class; var fncls__3187 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class; if fncls__3187 == nil { var fncls__3187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class = fncls__3187d; tmp3 = fncls__3187d } else { tmp3 = fncls__3187 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3188 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3188, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3190 lang.IFn; if linked_3189 == nil { ifn_3190 = lang.IFn_Cast(root_3188) } else { ifn_3190 = nil }; var arg_3191 any; var root_3193 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3193, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3195 lang.IFn; if linked_3194 == nil { ifn_3195 = lang.IFn_Cast(root_3193) } else { ifn_3195 = nil }; var arg_3196 any = b__1685000363__6; if linked_3194 == nil { arg_3191 = ifn_3195.Invoke_O__O(arg_3196) } else { arg_3191 = linked_3194.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3193, arg_3196) }; var arg_3192 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000360); var tmp5 any; var root_3197 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3197, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3199 lang.IFn; if linked_3198 == nil { ifn_3199 = lang.IFn_Cast(root_3197) } else { ifn_3199 = nil }; var arg_3200 any = s__1685000361__3; if linked_3198 == nil { tmp5 = ifn_3199.Invoke_O__O(arg_3200) } else { tmp5 = linked_3198.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3197, arg_3200) }; arg_3192 = tmp4.Invoke_O__O(tmp5); if linked_3189 == nil { return ifn_3190.Invoke_O_O__O(arg_3191, arg_3192) } else { return linked_3189.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3188, arg_3191, arg_3192) } } else { var root_3201 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3201, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3203 lang.IFn; if linked_3202 == nil { ifn_3203 = lang.IFn_Cast(root_3201) } else { ifn_3203 = nil }; var arg_3204 any; var root_3206 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3206, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3208 lang.IFn; if linked_3207 == nil { ifn_3208 = lang.IFn_Cast(root_3206) } else { ifn_3208 = nil }; var arg_3209 any = b__1685000363__6; if linked_3207 == nil { arg_3204 = ifn_3208.Invoke_O__O(arg_3209) } else { arg_3204 = linked_3207.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3206, arg_3209) }; var arg_3205 any; if linked_3202 == nil { return ifn_3203.Invoke_O_O__O(arg_3204, arg_3205) } else { return linked_3202.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3201, arg_3204, arg_3205) } } } else { var pf__4 any; var root_3210 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3210, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3212 lang.IFn; if linked_3211 == nil { ifn_3212 = lang.IFn_Cast(root_3210) } else { ifn_3212 = nil }; var arg_3213 any = s__1685000361__3; if linked_3211 == nil { pf__4 = ifn_3212.Invoke_O__O(arg_3213) } else { pf__4 = linked_3211.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3210, arg_3213) }; var root_3214 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3214, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3216 lang.IFn; if linked_3215 == nil { ifn_3216 = lang.IFn_Cast(root_3214) } else { ifn_3216 = nil }; var arg_3217 any; var root_3219 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3219, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3221 lang.IFn
															if linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = pf__4; if linked_3220 == nil { arg_3217 = ifn_3221.Invoke_O__O(arg_3222) } else { arg_3217 = linked_3220.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3219, arg_3222) }
//line :500:1
	var arg_3218 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000360); var tmp7 any; var root_3223 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3223, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3225 lang.IFn; if linked_3224 == nil { ifn_3225 = lang.IFn_Cast(root_3223) } else { ifn_3225 = nil }; var arg_3226 any = s__1685000361__3; if linked_3224 == nil { tmp7 = ifn_3225.Invoke_O__O(arg_3226) } else { tmp7 = linked_3224.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3223, arg_3226) }; arg_3218 = tmp6.Invoke_O__O(tmp7); if linked_3215 == nil { return ifn_3216.Invoke_O_O__O(arg_3217, arg_3218) } else { return linked_3215.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3214, arg_3217, arg_3218) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000363 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000363 = c__b__1685000363 }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A) Invoke_O__O(self any) any { { var i__1685000362__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000362__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000362__1)); var root_3178 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3178, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3180 lang.IFn; if linked_3179 == nil { ifn_3180 = lang.IFn_Cast(root_3178) } else { ifn_3180 = nil }; var arg_3181 any = t.F_b__1685000363; var arg_3182 any; var root_3183 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3183, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3185 lang.IFn
																if linked_3184 == nil { ifn_3185 = lang.IFn_Cast(root_3183) } else { ifn_3185 = nil }; var arg_3186 any = pf__2; if linked_3184 == nil { arg_3182 = ifn_3185.Invoke_O__O(arg_3186) } else { arg_3182 = linked_3184.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3183, arg_3186) }
//line :500:1
	if linked_3179 == nil { ifn_3180.Invoke_O_O__O(arg_3181, arg_3182) } else { linked_3179.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3178, arg_3181, arg_3182) }; i__1685000362__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000362__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000370_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000370_A{}; t.Ctor_O(p0); return t }
//line :505:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :505:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_3240 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3240, A_arbace_go_check_result_of_A_fn_class); var ifn_3242 lang.IFn
												if linked_3241 == nil { ifn_3242 = lang.IFn_Cast(root_3240) } else { ifn_3242 = nil }; var arg_3243 any; var root_3244 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_3245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3244, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3246 lang.IFn; if linked_3245 == nil { ifn_3246 = lang.IFn_Cast(root_3244) } else { ifn_3246 = nil }; var arg_3247 any = t.F_s; var arg_3248 any = path__1; var arg_3249 any; var arg_3250 any = lang.PersistentVector_EMPTY.Ref(); if linked_3245 == nil { arg_3243 = ifn_3246.Invoke_O_O_O_O__O(arg_3247, arg_3248, arg_3249, arg_3250) } else { arg_3243 = linked_3245.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3244, arg_3247, arg_3248, arg_3249, arg_3250) }; if linked_3241 == nil { or__1927000174__auto____4 = ifn_3242.Invoke_O__O(arg_3243) } else { or__1927000174__auto____4 = linked_3241.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3240, arg_3243) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111, path__1, A_arbace_go_check_A_const_321, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :505:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_3251 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, A_arbace_go_check_error_result_A_fn_class); var ifn_3253 lang.IFn


		if linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any = path__1; var arg_3255 any = ex__4; if linked_3252 == nil { tmp1 = ifn_3253.Invoke_O_O__O(arg_3254, arg_3255) } else { tmp1 = linked_3252.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3251, arg_3254, arg_3255) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000374_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000374_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :514:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :514:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_3279 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3279, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3281 lang.IFn

	if linked_3280 == nil { ifn_3281 = lang.IFn_Cast(root_3279) } else { ifn_3281 = nil }; var arg_3282 any = t.F_root; var arg_3283 any; var arg_3284 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_cc); var arg_3285 any = pf__1; if linked_3280 == nil { src__4 = ifn_3281.Invoke_O_O_O_O__O(arg_3282, arg_3283, arg_3284, arg_3285) } else { src__4 = linked_3280.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3279, arg_3282, arg_3283, arg_3284, arg_3285) }
	var tmp2 any; var root_3286 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_3287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3286, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3288 lang.IFn; if linked_3287 == nil { ifn_3288 = lang.IFn_Cast(root_3286) } else { ifn_3288 = nil }; var arg_3289 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__4); if linked_3287 == nil { tmp2 = ifn_3288.Invoke_O__O(arg_3289) } else { tmp2 = linked_3287.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3286, arg_3289) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_111; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_321, jrt.Boolean_TRUE.Ref())) } else {

		var root_3290 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3290, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3292 lang.IFn; if linked_3291 == nil { ifn_3292 = lang.IFn_Cast(root_3290) } else { ifn_3292 = nil }; var arg_3293 any; var root_3296 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3296, A_arbace_go_check_result_of_A_fn_class); var ifn_3298 lang.IFn; if linked_3297 == nil { ifn_3298 = lang.IFn_Cast(root_3296) } else { ifn_3298 = nil }; var arg_3299 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp5 any; var root_3305 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, A_arbace_go_check_resolver_A_fn_class); var ifn_3307 lang.IFn; if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = t.F_s; var arg_3309 any = src__4; var arg_3310 any = lang.PersistentVector_EMPTY.Ref(); if linked_3306 == nil { tmp5 = ifn_3307.Invoke_O_O_O__O(arg_3308, arg_3309, arg_3310) } else { tmp5 = linked_3306.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3305, arg_3308, arg_3309, arg_3310) }; arg_3299 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_3297 == nil { arg_3293 = ifn_3298.Invoke_O__O(arg_3299) } else { arg_3293 = linked_3297.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3296, arg_3299) }; var arg_3294 any = A_arbace_go_check_A_const_111; var arg_3295 any; var root_3311 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3313 lang.IFn
		if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3315 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_3312 == nil { arg_3295 = ifn_3313.Invoke_O_O__O(arg_3314, arg_3315) } else { arg_3295 = linked_3312.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3311, arg_3314, arg_3315) }
//line :519:1
		if linked_3291 == nil { tmp1 = ifn_3292.Invoke_O_O_O__O(arg_3293, arg_3294, arg_3295) } else { tmp1 = linked_3291.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3290, arg_3293, arg_3294, arg_3295) } } }; return nil }(); if /*line :514:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_3316 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, A_arbace_go_check_error_result_A_fn_class); var ifn_3318 lang.IFn






			if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_3320 any = ex__4; if linked_3317 == nil { tmp1 = ifn_3318.Invoke_O_O__O(arg_3319, arg_3320) } else { tmp1 = linked_3317.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3316, arg_3319, arg_3320) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000378_A_New() *A_arbace_go_check_check_corpus_fn__1685000378_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000378_A{}; t.Ctor(); return t }
//line :528:1
func (t *A_arbace_go_check_check_corpus_fn__1685000378_A) Ctor() {}
//line :528:1
func (t *A_arbace_go_check_check_corpus_fn__1685000378_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_3353 any = A_arbace_go_check_A_const_325.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3355 lang.IFn; if

	linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = A_arbace_go_check_A_const_326; var arg_3357 any = p__2; if linked_3354 == nil { temp__1927000408__auto____3 = ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { temp__1927000408__auto____3 = linked_3354.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000379__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000384_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_A) Invoke_O_O__O(self, p__1685000383__1 any) any { var vec__1685000385__2 any = p__1685000383__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_3374 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3376 lang.IFn

	if linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var arg_3377 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3378 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_New(); var tmp3 *jrt.Class; var fncls__3445 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class; if fncls__3445 == nil { var fncls__3445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class = fncls__3445d; tmp3 = fncls__3445d } else { tmp3 = fncls__3445 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_3378 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_3375 == nil { by_path__7 = ifn_3376.Invoke_O_O__O(arg_3377, arg_3378) } else { by_path__7 = linked_3375.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3374, arg_3377, arg_3378) }
//line :534:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_106.GetRawRoot__O()); var tmp5 any; var root_3454 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3454, A_arbace_go_check_session_A_fn_class); var ifn_3456 lang.IFn



	if linked_3455 == nil { ifn_3456 = lang.IFn_Cast(root_3454) } else { ifn_3456 = nil }; var arg_3457 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__3465 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class; if fncls__3465 == nil { var fncls__3465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class = fncls__3465d; tmp7 = fncls__3465d } else { tmp7 = fncls__3465 }; arg_3457 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_3455 == nil { tmp5 = ifn_3456.Invoke_O__O(arg_3457) } else { tmp5 = linked_3455.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3454, arg_3457) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_266; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_275; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__3471 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class; if fncls__3471 == nil { var fncls__3471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class = fncls__3471d; tmp13 = fncls__3471d } else { tmp13 = fncls__3471 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_3472 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3472, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3474 lang.IFn; if linked_3473 == nil { ifn_3474 = lang.IFn_Cast(root_3472) } else { ifn_3474 = nil }; var arg_3475 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__3590 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class; if fncls__3590 == nil { var fncls__3590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class = fncls__3590d; tmp15 = fncls__3590d } else { tmp15 = fncls__3590 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_3591 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_3592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3591, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3593 lang.IFn; if linked_3592 == nil { ifn_3593 = lang.IFn_Cast(root_3591) } else { ifn_3593 = nil }; var arg_3594 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); var arg_3595 any = by_path__7; if linked_3592 == nil { tmp17 = ifn_3593.Invoke_O_O__O(arg_3594, arg_3595) } else { tmp17 = linked_3592.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3591, arg_3594, arg_3595) }; arg_3475 = tmp16.Invoke_O__O(tmp17); if linked_3473 == nil { tmp1 = ifn_3474.Invoke_O__O(arg_3475) } else { tmp1 = linked_3473.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3472, arg_3475) } }; return nil }(); if /*line :534:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_3596 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3596, A_arbace_go_check_error_result_A_fn_class); var ifn_3598 lang.IFn












		if linked_3597 == nil { ifn_3598 = lang.IFn_Cast(root_3596) } else { ifn_3598 = nil }; var arg_3599 any = tdir__3; var arg_3600 any = ex__7; if linked_3597 == nil { tmp19 = ifn_3598.Invoke_O_O__O(arg_3599, arg_3600) } else { tmp19 = linked_3597.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3596, arg_3599, arg_3600) }
//line :534:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_New() *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A) Ctor() {}
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A) Invoke_O_O__O(self, s__1685000389__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_New_O_O(s__1685000389__1, self); var tmp2 *jrt.Class; var fncls__3444 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class; if fncls__3444 == nil { var fncls__3444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class = fncls__3444d; tmp2 = fncls__3444d } else { tmp2 = fncls__3444 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :536:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A) Ctor_O_O(c__s__1685000389, c__iter__1685000388 any) { t.F_s__1685000389 = c__s__1685000389; t.F_iter__1685000388 = c__iter__1685000388 }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A) Invoke_O__O(self any) any { { var s__1685000389__1 any; var t_ any = t.F_s__1685000389; t.F_s__1685000389 = nil; s__1685000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_3379 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3379, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3381 lang.IFn; if linked_3380 == nil { ifn_3381 = lang.IFn_Cast(root_3379) } else { ifn_3381 = nil }; var arg_3382 any = s__1685000389__1; if linked_3380 == nil { temp__1927000414__auto____2 = ifn_3381.Invoke_O__O(arg_3382) } else { temp__1927000414__auto____2 = linked_3380.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3379, arg_3382) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3383 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3383, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3385 lang.IFn; if linked_3384 == nil { ifn_3385 = lang.IFn_Cast(root_3383) } else { ifn_3385 = nil }; var arg_3386 any = s__1685000389__3; if linked_3384 == nil { tmp1 = ifn_3385.Invoke_O__O(arg_3386) } else { tmp1 = linked_3384.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3383, arg_3386) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3387 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3387, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3389 lang.IFn; if linked_3388 == nil { ifn_3389 = lang.IFn_Cast(root_3387) } else { ifn_3389 = nil }; var arg_3390 any = s__1685000389__3; if linked_3388 == nil { c__1927001037__auto____4 = ifn_3389.Invoke_O__O(arg_3390) } else { c__1927001037__auto____4 = linked_3388.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3387, arg_3390) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000391__6 any; var root_3391 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3391, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3393 lang.IFn; if linked_3392 == nil { ifn_3393 = lang.IFn_Cast(root_3391) } else { ifn_3393 = nil }; var arg_3394 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3392 == nil { b__1685000391__6 = ifn_3393.Invoke_O__O(arg_3394) } else { b__1685000391__6 = linked_3392.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3391, arg_3394) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_New_O_I_O(b__1685000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3404 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class; if fncls__3404 == nil { var fncls__3404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class = fncls__3404d; tmp3 = fncls__3404d } else { tmp3 = fncls__3404 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3405 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3405, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3407 lang.IFn; if linked_3406 == nil { ifn_3407 = lang.IFn_Cast(root_3405) } else { ifn_3407 = nil }; var arg_3408 any; var root_3410 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3410, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3412 lang.IFn; if linked_3411 == nil { ifn_3412 = lang.IFn_Cast(root_3410) } else { ifn_3412 = nil }; var arg_3413 any = b__1685000391__6; if linked_3411 == nil { arg_3408 = ifn_3412.Invoke_O__O(arg_3413) } else { arg_3408 = linked_3411.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3410, arg_3413) }; var arg_3409 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000388); var tmp5 any; var root_3414 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3416 lang.IFn; if linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any = s__1685000389__3; if linked_3415 == nil { tmp5 = ifn_3416.Invoke_O__O(arg_3417) } else { tmp5 = linked_3415.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3414, arg_3417) }; arg_3409 = tmp4.Invoke_O__O(tmp5); if linked_3406 == nil { return ifn_3407.Invoke_O_O__O(arg_3408, arg_3409) } else { return linked_3406.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3405, arg_3408, arg_3409) } } else { var root_3418 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3418, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3420 lang.IFn; if linked_3419 == nil { ifn_3420 = lang.IFn_Cast(root_3418) } else { ifn_3420 = nil }; var arg_3421 any; var root_3423 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3423, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3425 lang.IFn; if linked_3424 == nil { ifn_3425 = lang.IFn_Cast(root_3423) } else { ifn_3425 = nil }; var arg_3426 any = b__1685000391__6; if linked_3424 == nil { arg_3421 = ifn_3425.Invoke_O__O(arg_3426) } else { arg_3421 = linked_3424.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3423, arg_3426) }; var arg_3422 any; if linked_3419 == nil { return ifn_3420.Invoke_O_O__O(arg_3421, arg_3422) } else { return linked_3419.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3418, arg_3421, arg_3422) } } } else { var pf__4 any; var root_3427 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3427, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3429 lang.IFn; if linked_3428 == nil { ifn_3429 = lang.IFn_Cast(root_3427) } else { ifn_3429 = nil }; var arg_3430 any = s__1685000389__3; if linked_3428 == nil { pf__4 = ifn_3429.Invoke_O__O(arg_3430) } else { pf__4 = linked_3428.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3427, arg_3430) }; var root_3431 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3433 lang.IFn; if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any; var tmp6 any; var root_3436 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3438 lang.IFn; if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = pf__4; if linked_3437 == nil { tmp6 = ifn_3438.Invoke_O__O(arg_3439) } else { tmp6 = linked_3437.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3436, arg_3439) }; arg_3434 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_3435 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000388); var tmp8 any; var root_3440 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3442 lang.IFn; if linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any = s__1685000389__3; if linked_3441 == nil { tmp8 = ifn_3442.Invoke_O__O(arg_3443) } else { tmp8 = linked_3441.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3440, arg_3443) }; arg_3435 = tmp7.Invoke_O__O(tmp8); if linked_3432 == nil { return ifn_3433.Invoke_O_O__O(arg_3434, arg_3435) } else { return linked_3432.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3431, arg_3434, arg_3435) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :536:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A) Ctor_O_I_O(c__b__1685000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000391 = c__b__1685000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A) Invoke_O__O(self any) any { { var i__1685000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000390__1)); var root_3395 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = t.F_b__1685000391; var arg_3399 any; var tmp2 any; var root_3400 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = pf__2; if linked_3401 == nil { tmp2 = ifn_3402.Invoke_O__O(arg_3403) } else { tmp2 = linked_3401.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3400, arg_3403) }; arg_3399 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_3396 == nil { ifn_3397.Invoke_O_O__O(arg_3398, arg_3399) } else { linked_3396.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3395, arg_3398, arg_3399) }; i__1685000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_3458 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3458, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3460 lang.IFn
																	if linked_3459 == nil { ifn_3460 = lang.IFn_Cast(root_3458) } else { ifn_3460 = nil }; var arg_3461 any = t.F_root; var arg_3462 any = path__1; var arg_3463 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_cc); var arg_3464 any = pf__4; if linked_3459 == nil { return ifn_3460.Invoke_O_O_O_O__O(arg_3461, arg_3462, arg_3463, arg_3464) } else { return linked_3459.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3458, arg_3461, arg_3462, arg_3463, arg_3464) } } else {
//line :539:1
			return nil } }
//line :538:1
func A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A{}; t.Ctor_O(p0); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A) Invoke_O_O__O(self, p1__1685000359_SHARP___1 any) any {


	var root_3466 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_3467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3466, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3468 lang.IFn; if linked_3467 == nil { ifn_3468 = lang.IFn_Cast(root_3466) } else { ifn_3468 = nil }; var arg_3469 any = t.F_by_path; var arg_3470 any = p1__1685000359_SHARP___1; if linked_3467 == nil { return ifn_3468.Invoke_O_O__O(arg_3469, arg_3470) } else { return linked_3467.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3466, arg_3469, arg_3470) } }
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A) Invoke_O_O__O(self, s__1685000403__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_New_O_O_O_O_O(self, t.F_dir, t.F_tdir, t.F_ts, s__1685000403__1); var tmp2 *jrt.Class; var fncls__3589 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class; if fncls__3589 == nil { var fncls__3589d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class = fncls__3589d; tmp2 = fncls__3589d } else { tmp2 = fncls__3589 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A) Ctor_O_O_O_O_O(c__iter__1685000402, c__dir, c__tdir, c__ts, c__s__1685000403 any) { t.F_iter__1685000402 = c__iter__1685000402; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1685000403 = c__s__1685000403 }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A) Invoke_O__O(self any) any { { var s__1685000403__1 any; var t_ any = t.F_s__1685000403; t.F_s__1685000403 = nil; s__1685000403__1 = t_; for { var temp__1927000414__auto____2 any; var root_3476 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3476, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3478 lang.IFn; if linked_3477 == nil { ifn_3478 = lang.IFn_Cast(root_3476) } else { ifn_3478 = nil }; var arg_3479 any = s__1685000403__1; if linked_3477 == nil { temp__1927000414__auto____2 = ifn_3478.Invoke_O__O(arg_3479) } else { temp__1927000414__auto____2 = linked_3477.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3476, arg_3479) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000403__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3480 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3480, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3482 lang.IFn; if linked_3481 == nil { ifn_3482 = lang.IFn_Cast(root_3480) } else { ifn_3482 = nil }; var arg_3483 any = s__1685000403__3; if linked_3481 == nil { tmp1 = ifn_3482.Invoke_O__O(arg_3483) } else { tmp1 = linked_3481.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3480, arg_3483) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3484 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3484, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3486 lang.IFn; if linked_3485 == nil { ifn_3486 = lang.IFn_Cast(root_3484) } else { ifn_3486 = nil }; var arg_3487 any = s__1685000403__3; if linked_3485 == nil { c__1927001037__auto____4 = ifn_3486.Invoke_O__O(arg_3487) } else { c__1927001037__auto____4 = linked_3485.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3484, arg_3487) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000405__6 any; var root_3488 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3490 lang.IFn; if linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3489 == nil { b__1685000405__6 = ifn_3490.Invoke_O__O(arg_3491) } else { b__1685000405__6 = linked_3489.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3488, arg_3491) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_New_O_O_O_O_I_O(t.F_dir, b__1685000405__6, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3525 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class; if fncls__3525 == nil { var fncls__3525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class = fncls__3525d; tmp3 = fncls__3525d } else { tmp3 = fncls__3525 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3526 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any; var root_3531 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3531, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3533 lang.IFn; if linked_3532 == nil { ifn_3533 = lang.IFn_Cast(root_3531) } else { ifn_3533 = nil }; var arg_3534 any = b__1685000405__6; if linked_3532 == nil { arg_3529 = ifn_3533.Invoke_O__O(arg_3534) } else { arg_3529 = linked_3532.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3531, arg_3534) }; var arg_3530 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000402); var tmp5 any; var root_3535 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3535, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3537 lang.IFn; if linked_3536 == nil { ifn_3537 = lang.IFn_Cast(root_3535) } else { ifn_3537 = nil }; var arg_3538 any = s__1685000403__3; if linked_3536 == nil { tmp5 = ifn_3537.Invoke_O__O(arg_3538) } else { tmp5 = linked_3536.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3535, arg_3538) }; arg_3530 = tmp4.Invoke_O__O(tmp5); if linked_3527 == nil { return ifn_3528.Invoke_O_O__O(arg_3529, arg_3530) } else { return linked_3527.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3526, arg_3529, arg_3530) } } else { var root_3539 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3539, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3541 lang.IFn; if linked_3540 == nil { ifn_3541 = lang.IFn_Cast(root_3539) } else { ifn_3541 = nil }; var arg_3542 any; var root_3544 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3544, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3546 lang.IFn; if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = b__1685000405__6; if linked_3545 == nil { arg_3542 = ifn_3546.Invoke_O__O(arg_3547) } else { arg_3542 = linked_3545.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3544, arg_3547) }; var arg_3543 any; if linked_3540 == nil { return ifn_3541.Invoke_O_O__O(arg_3542, arg_3543) } else { return linked_3540.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3539, arg_3542, arg_3543) } } } else { var vec__1685000415__4 any; var root_3548 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3548, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3550 lang.IFn; if linked_3549 == nil { ifn_3550 = lang.IFn_Cast(root_3548) } else { ifn_3550 = nil }; var arg_3551 any = s__1685000403__3; if linked_3549 == nil { vec__1685000415__4 = ifn_3550.Invoke_O__O(arg_3551) } else { vec__1685000415__4 = linked_3549.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3548, arg_3551) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000415__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000415__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3552 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3552, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3554 lang.IFn; _ = pf__6; if linked_3553 == nil { ifn_3554 = lang.IFn_Cast(root_3552) } else { ifn_3554 = nil }; var arg_3555 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3584 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class
																if fncls__3584 == nil { var fncls__3584d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class = fncls__3584d; tmp7 = fncls__3584d } else { tmp7 = fncls__3584 }; arg_3555 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :542:1
	var arg_3556 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000402); var tmp9 any; var root_3585 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3585, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3587 lang.IFn; if linked_3586 == nil { ifn_3587 = lang.IFn_Cast(root_3585) } else { ifn_3587 = nil }; var arg_3588 any = s__1685000403__3; if linked_3586 == nil { tmp9 = ifn_3587.Invoke_O__O(arg_3588) } else { tmp9 = linked_3586.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3585, arg_3588) }; arg_3556 = tmp8.Invoke_O__O(tmp9); if linked_3553 == nil { return ifn_3554.Invoke_O_O__O(arg_3555, arg_3556) } else { return linked_3553.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3552, arg_3555, arg_3556) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A) Ctor_O_O_O_O_I_O(c__dir, c__b__1685000405, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__1685000405 = c__b__1685000405; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A) Invoke_O__O(self any) any { { var i__1685000404__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000404__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000409__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000404__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000409__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000409__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3492 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3492, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3494 lang.IFn; _ = pf__4; if linked_3493 == nil { ifn_3494 = lang.IFn_Cast(root_3492) } else { ifn_3494 = nil }; var arg_3495 any = t.F_b__1685000405; var arg_3496 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3524 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class
																		if fncls__3524 == nil { var fncls__3524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class = fncls__3524d; tmp3 = fncls__3524d } else { tmp3 = fncls__3524 }; arg_3496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :542:1
	if linked_3493 == nil { ifn_3494.Invoke_O_O__O(arg_3495, arg_3496) } else { linked_3493.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3492, arg_3495, arg_3496) }; i__1685000404__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000404__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_3497 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3497, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3499 lang.IFn; if linked_3498 == nil { ifn_3499 = lang.IFn_Cast(root_3497) } else { ifn_3499 = nil }; var arg_3500 any; var or__1927000174__auto____3 any; var root_3503 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3503, A_arbace_go_check_result_of_A_fn_class); var ifn_3505 lang.IFn; if linked_3504 == nil { ifn_3505 = lang.IFn_Cast(root_3503) } else { ifn_3505 = nil }; var arg_3506 any; var root_3507 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_3508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3507, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3509 lang.IFn; if linked_3508 == nil { ifn_3509 = lang.IFn_Cast(root_3507) } else { ifn_3509 = nil }; var arg_3510 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3510 = t_; var arg_3511 any = t.F_path; var arg_3512 any; var arg_3513 any = lang.PersistentVector_EMPTY.Ref(); if linked_3508 == nil { arg_3506 = ifn_3509.Invoke_O_O_O_O__O(arg_3510, arg_3511, arg_3512, arg_3513) } else { arg_3506 = linked_3508.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3507, arg_3510, arg_3511, arg_3512, arg_3513) }; if linked_3504 == nil { or__1927000174__auto____3 = ifn_3505.Invoke_O__O(arg_3506) } else { or__1927000174__auto____3 = linked_3504.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3503, arg_3506) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3500 = or__1927000174__auto____3 } else { arg_3500 = A_arbace_go_check_A_const_328 }; var arg_3501 any = A_arbace_go_check_A_const_111; var arg_3502 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3514 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3514, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3516 lang.IFn
																					if linked_3515 == nil { ifn_3516 = lang.IFn_Cast(root_3514) } else { ifn_3516 = nil }; var arg_3517 any = t.F_tdir; var arg_3518 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3518 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3515 == nil { tmp3 = ifn_3516.Invoke_O_O__O(arg_3517, arg_3518) } else { tmp3 = linked_3515.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3514, arg_3517, arg_3518) }; arg_3502 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :544:1
		if linked_3498 == nil { tmp1 = ifn_3499.Invoke_O_O_O__O(arg_3500, arg_3501, arg_3502) } else { tmp1 = linked_3498.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3497, arg_3500, arg_3501, arg_3502) } }
//line :543:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3519 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3519, A_arbace_go_check_error_result_A_fn_class); var ifn_3521 lang.IFn


		if linked_3520 == nil { ifn_3521 = lang.IFn_Cast(root_3519) } else { ifn_3521 = nil }; var arg_3522 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3522 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3523 any = ex__3; if linked_3520 == nil { tmp1 = ifn_3521.Invoke_O_O__O(arg_3522, arg_3523) } else { tmp1 = linked_3520.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3519, arg_3522, arg_3523) } } }; return tmp1 }
//line :543:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3557 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any; var or__1927000174__auto____3 any; var root_3563 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3563, A_arbace_go_check_result_of_A_fn_class); var ifn_3565 lang.IFn; if linked_3564 == nil { ifn_3565 = lang.IFn_Cast(root_3563) } else { ifn_3565 = nil }; var arg_3566 any; var root_3567 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_3568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3567, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3569 lang.IFn; if linked_3568 == nil { ifn_3569 = lang.IFn_Cast(root_3567) } else { ifn_3569 = nil }; var arg_3570 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3570 = t_; var arg_3571 any = t.F_path; var arg_3572 any; var arg_3573 any = lang.PersistentVector_EMPTY.Ref(); if linked_3568 == nil { arg_3566 = ifn_3569.Invoke_O_O_O_O__O(arg_3570, arg_3571, arg_3572, arg_3573) } else { arg_3566 = linked_3568.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3567, arg_3570, arg_3571, arg_3572, arg_3573) }; if linked_3564 == nil { or__1927000174__auto____3 = ifn_3565.Invoke_O__O(arg_3566) } else { or__1927000174__auto____3 = linked_3564.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3563, arg_3566) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3560 = or__1927000174__auto____3 } else { arg_3560 = A_arbace_go_check_A_const_329 }; var arg_3561 any = A_arbace_go_check_A_const_111; var arg_3562 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3574 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3574, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3576 lang.IFn
																			if linked_3575 == nil { ifn_3576 = lang.IFn_Cast(root_3574) } else { ifn_3576 = nil }; var arg_3577 any = t.F_tdir; var arg_3578 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3578 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3575 == nil { tmp3 = ifn_3576.Invoke_O_O__O(arg_3577, arg_3578) } else { tmp3 = linked_3575.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3574, arg_3577, arg_3578) }; arg_3562 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :544:1
		if linked_3558 == nil { tmp1 = ifn_3559.Invoke_O_O_O__O(arg_3560, arg_3561, arg_3562) } else { tmp1 = linked_3558.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3557, arg_3560, arg_3561, arg_3562) } }
//line :543:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3579 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, A_arbace_go_check_error_result_A_fn_class); var ifn_3581 lang.IFn


		if linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3582 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3583 any = ex__3; if linked_3580 == nil { tmp1 = ifn_3581.Invoke_O_O__O(arg_3582, arg_3583) } else { tmp1 = linked_3580.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3579, arg_3582, arg_3583) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :550:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :550:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3607 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3607, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3609 lang.IFn; if


	linked_3608 == nil { ifn_3609 = lang.IFn_Cast(root_3607) } else { ifn_3609 = nil }; var arg_3610 any = A_arbace_go_check_A_const_321; var arg_3611 any = results__1; if linked_3608 == nil { rs__3 = ifn_3609.Invoke_O_O__O(arg_3610, arg_3611) } else { rs__3 = linked_3608.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3607, arg_3610, arg_3611) }; var sum__4 any; var tmp1 any = /*line :550:1*/A_arbace_go_check_summarize_sum__1685000430_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3623 *jrt.Class = A_arbace_go_check_summarize_sum__1685000430_A_fn_class; if



	fncls__3623 == nil { var fncls__3623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_go_check_summarize_sum__1685000430_A_fn_class = fncls__3623d; tmp2 = fncls__3623d } else { tmp2 = fncls__3623 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :550:1*/A_arbace_go_check_summarize_msum__1685000432_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__3636 *jrt.Class = A_arbace_go_check_summarize_msum__1685000432_A_fn_class; if




	fncls__3636 == nil { var fncls__3636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_check_summarize_msum__1685000432_A_fn_class = fncls__3636d; tmp4 = fncls__3636d } else { tmp4 = fncls__3636 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_295; var tmp6 any = A_arbace_go_check_A_const_331; var tmp7 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_332; var tmp9 any = A_arbace_go_check_A_const_333; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_83); var tmp11 any = A_arbace_go_check_A_const_164; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_164); var tmp13 any = A_arbace_go_check_A_const_150; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_155); var tmp15 any = A_arbace_go_check_A_const_153; var tmp16 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_153); var tmp17 any = A_arbace_go_check_A_const_145; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_156))); var tmp19 any = A_arbace_go_check_A_const_238; var tmp20 lang.IFn = lang.IFn_Cast(sum__4); var tmp21 any = A_arbace_go_check_summarize_fn__1685000434_A_New(); var tmp22 *jrt.Class; var fncls__3719 *jrt.Class = A_arbace_go_check_summarize_fn__1685000434_A_fn_class; if












	fncls__3719 == nil { var fncls__3719d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_go_check_summarize_fn__1685000434_A_fn_class = fncls__3719d; tmp22 = fncls__3719d } else { tmp22 = fncls__3719 }; var tmp23 any = /*line :550:1*/tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)); var tmp24 any = A_arbace_go_check_A_const_334; var tmp25 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_241); var tmp26 any = A_arbace_go_check_A_const_335; var tmp27 any; var root_3637 any = A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3637, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3639 lang.IFn; if














	linked_3638 == nil { ifn_3639 = lang.IFn_Cast(root_3637) } else { ifn_3639 = nil }; var arg_3640 any; var tmp28 any = A_arbace_go_check_summarize_fn__1685000436_A_New(); var tmp29 *jrt.Class; var fncls__3642 *jrt.Class = A_arbace_go_check_summarize_fn__1685000436_A_fn_class; if fncls__3642 == nil { var fncls__3642d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_go_check_summarize_fn__1685000436_A_fn_class = fncls__3642d; tmp29 = fncls__3642d } else { tmp29 = fncls__3642 }; arg_3640 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_3641 any = rs__3; if linked_3638 == nil { tmp27 = ifn_3639.Invoke_O_O__O(arg_3640, arg_3641) } else { tmp27 = linked_3638.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3637, arg_3640, arg_3641) }; var tmp30 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref(); var tmp31 any = A_arbace_go_check_A_const_337; var tmp32 any; var root_3643 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3645 lang.IFn; if















	linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any; var root_3647 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3649 lang.IFn; if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any; var tmp33 any = A_arbace_go_check_summarize_fn__1685000438_A_New(); var tmp34 *jrt.Class; var fncls__3652 *jrt.Class = A_arbace_go_check_summarize_fn__1685000438_A_fn_class; if fncls__3652 == nil { var fncls__3652d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_go_check_summarize_fn__1685000438_A_fn_class = fncls__3652d; tmp34 = fncls__3652d } else { tmp34 = fncls__3652 }; arg_3650 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3651 any = rs__3; if linked_3648 == nil { arg_3646 = ifn_3649.Invoke_O_O__O(arg_3650, arg_3651) } else { arg_3646 = linked_3648.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3647, arg_3650, arg_3651) }; if linked_3644 == nil { tmp32 = ifn_3645.Invoke_O__O(arg_3646) } else { tmp32 = linked_3644.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3643, arg_3646) }; var tmp35 any = tmp32; var tmp36 any = A_arbace_go_check_A_const_338; var tmp37 any = A_arbace_go_check_A_const_140; var tmp38 any; var root_3653 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3653, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3655 lang.IFn; if
















	linked_3654 == nil { ifn_3655 = lang.IFn_Cast(root_3653) } else { ifn_3655 = nil }; var arg_3656 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3657 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_140); if linked_3654 == nil { tmp38 = ifn_3655.Invoke_O_O__O(arg_3656, arg_3657) } else { tmp38 = linked_3654.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3653, arg_3656, arg_3657) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_go_check_A_const_165; var tmp41 any; var root_3661 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3661, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3663 lang.IFn; if

















	linked_3662 == nil { ifn_3663 = lang.IFn_Cast(root_3661) } else { ifn_3663 = nil }; var arg_3664 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3665 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_165); if linked_3662 == nil { tmp41 = ifn_3663.Invoke_O_O__O(arg_3664, arg_3665) } else { tmp41 = linked_3662.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3661, arg_3664, arg_3665) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_go_check_A_const_166; var tmp44 any; var root_3669 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3669, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3671 lang.IFn; if


















	linked_3670 == nil { ifn_3671 = lang.IFn_Cast(root_3669) } else { ifn_3671 = nil }; var arg_3672 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3673 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_166); if linked_3670 == nil { tmp44 = ifn_3671.Invoke_O_O__O(arg_3672, arg_3673) } else { tmp44 = linked_3670.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3669, arg_3672, arg_3673) }; var tmp45 any = tmp44; var tmp46 any = A_arbace_go_check_A_const_340; var tmp47 any; var root_3677 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3677, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3679 lang.IFn; if



















	linked_3678 == nil { ifn_3679 = lang.IFn_Cast(root_3677) } else { ifn_3679 = nil }; var arg_3680 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3681 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_157); if linked_3678 == nil { tmp47 = ifn_3679.Invoke_O_O__O(arg_3680, arg_3681) } else { tmp47 = linked_3678.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3677, arg_3680, arg_3681) }; var tmp48 any = tmp47; var tmp49 any = A_arbace_go_check_A_const_242; var tmp50 any = A_arbace_go_check_A_const_331; var tmp51 any; var root_3685 any = /*line :550:1*/A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3685, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3687 lang.IFn; if




















	linked_3686 == nil { ifn_3687 = lang.IFn_Cast(root_3685) } else { ifn_3687 = nil }; var arg_3688 any; var tmp52 any = A_arbace_go_check_summarize_fn__1685000440_A_New(); var tmp53 *jrt.Class; var fncls__3695 *jrt.Class = A_arbace_go_check_summarize_fn__1685000440_A_fn_class; if fncls__3695 == nil { var fncls__3695d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_go_check_summarize_fn__1685000440_A_fn_class = fncls__3695d; tmp53 = fncls__3695d } else { tmp53 = fncls__3695 }; arg_3688 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var arg_3689 any = rs__3; if linked_3686 == nil { tmp51 = ifn_3687.Invoke_O_O__O(arg_3688, arg_3689) } else { tmp51 = linked_3686.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3685, arg_3688, arg_3689) }; var tmp54 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp51)).Ref(); var tmp55 any = A_arbace_go_check_A_const_342; var tmp56 lang.IFn = lang.IFn_Cast(sum__4); var tmp57 any = A_arbace_go_check_summarize_fn__1685000442_A_New(); var tmp58 *jrt.Class; var fncls__3726 *jrt.Class = A_arbace_go_check_summarize_fn__1685000442_A_fn_class; if





















	fncls__3726 == nil { var fncls__3726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_go_check_summarize_fn__1685000442_A_fn_class = fncls__3726d; tmp58 = fncls__3726d } else { tmp58 = fncls__3726 }; var tmp59 any = /*line :550:1*/tmp56.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil)); var tmp60 any = A_arbace_go_check_A_const_343; var tmp61 any; var root_3696 any = A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3696, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3698 lang.IFn; if






















	linked_3697 == nil { ifn_3698 = lang.IFn_Cast(root_3696) } else { ifn_3698 = nil }; var arg_3699 any; var tmp62 any = A_arbace_go_check_summarize_fn__1685000444_A_New(); var tmp63 *jrt.Class; var fncls__3710 *jrt.Class = A_arbace_go_check_summarize_fn__1685000444_A_fn_class; if fncls__3710 == nil { var fncls__3710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_check_summarize_fn__1685000444_A_fn_class = fncls__3710d; tmp63 = fncls__3710d } else { tmp63 = fncls__3710 }; arg_3699 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil); var arg_3700 any = rs__3; if linked_3697 == nil { tmp61 = ifn_3698.Invoke_O_O__O(arg_3699, arg_3700) } else { tmp61 = linked_3697.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3696, arg_3699, arg_3700) }; var tmp64 any = /*line :550:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, tmp40, tmp42, tmp43, tmp45, tmp46, tmp48, tmp49, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp54, tmp55, tmp59, tmp60, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp61)).Ref())))); var tmp65 any = A_arbace_go_check_A_const_145; var tmp66 any; var root_3711 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3711, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3713 lang.IFn; if























	linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3715 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_145); if linked_3712 == nil { tmp66 = ifn_3713.Invoke_O_O__O(arg_3714, arg_3715) } else { tmp66 = linked_3712.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3711, arg_3714, arg_3715) }; return /*line :550:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp18, tmp19, tmp23, tmp24, tmp25, tmp26, tmp30, tmp31, tmp35, tmp36, tmp64, tmp65, tmp66)) }



func A_arbace_go_check_summarize_sum__1685000430_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000430_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000430_A{}; t.Ctor_O(p0); return t }
//line :554:1
func (t *A_arbace_go_check_summarize_sum__1685000430_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :554:1
func (t *A_arbace_go_check_summarize_sum__1685000430_A) Invoke_O_O__O(self, k__1 any) any { var root_3612 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3612, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3614 lang.IFn; if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3616 any = A_arbace_go_check_A_const_22; var arg_3617 any; var root_3618 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3620 lang.IFn; if linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any = k__1; var arg_3622 any = t.F_rs; if linked_3619 == nil { arg_3617 = ifn_3620.Invoke_O_O__O(arg_3621, arg_3622) } else { arg_3617 = linked_3619.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3618, arg_3621, arg_3622) }; if linked_3613 == nil { return ifn_3614.Invoke_O_O_O__O(arg_3615, arg_3616, arg_3617) } else { return linked_3613.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3612, arg_3615, arg_3616, arg_3617) } }
func A_arbace_go_check_summarize_msum__1685000432_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000432_A{}; t.Ctor_O(p0); return t }
//line :555:1
func (t *A_arbace_go_check_summarize_msum__1685000432_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :555:1
func (t *A_arbace_go_check_summarize_msum__1685000432_A) Invoke_O_O__O(self, k__1 any) any { var root_3624 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3625 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3624, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3626 lang.IFn; if linked_3625 == nil { ifn_3626 = lang.IFn_Cast(root_3624) } else { ifn_3626 = nil }; var arg_3627 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var arg_3628 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3629 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3630 any; var root_3631 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3631, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3633 lang.IFn; if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any = k__1; var arg_3635 any = t.F_rs; if linked_3632 == nil { arg_3630 = ifn_3633.Invoke_O_O__O(arg_3634, arg_3635) } else { arg_3630 = linked_3632.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3631, arg_3634, arg_3635) }; if linked_3625 == nil { return ifn_3626.Invoke_O_O_O_O__O(arg_3627, arg_3628, arg_3629, arg_3630) } else { return linked_3625.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3624, arg_3627, arg_3628, arg_3629, arg_3630) } }







func A_arbace_go_check_summarize_fn__1685000434_A_New() *A_arbace_go_check_summarize_fn__1685000434_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000434_A{}; t.Ctor(); return t }
//line :563:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Ctor() {}
//line :563:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Invoke_O_O__O(self, p1__1685000424_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_238.Invoke_O__O(p1__1685000424_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000436_A_New() *A_arbace_go_check_summarize_fn__1685000436_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000436_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Ctor() {}
//line :565:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Invoke_O_O__O(self, p1__1685000425_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_311.Invoke_O__O(p1__1685000425_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_83.Invoke_O__O(p1__1685000425_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000438_A_New() *A_arbace_go_check_summarize_fn__1685000438_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000438_A{}; t.Ctor(); return t }
//line :566:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Ctor() {}
//line :566:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Invoke_O_O__O(self, p1__1685000426_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_311.Invoke_O__O(p1__1685000426_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_83.Invoke_O__O(p1__1685000426_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_111.Invoke_O__O(p1__1685000426_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000440_A_New() *A_arbace_go_check_summarize_fn__1685000440_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000440_A{}; t.Ctor(); return t }
//line :571:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Ctor() {}
//line :571:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Invoke_O_O__O(self, p1__1685000427_SHARP___1 any) any { var root_3690 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3690, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3692 lang.IFn; if linked_3691 == nil { ifn_3692 = lang.IFn_Cast(root_3690) } else { ifn_3692 = nil }; var arg_3693 any = p1__1685000427_SHARP___1; var arg_3694 any = A_arbace_go_check_A_const_341; if linked_3691 == nil { return ifn_3692.Invoke_O_O__O(arg_3693, arg_3694) } else { return linked_3691.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3690, arg_3693, arg_3694) } }
func A_arbace_go_check_summarize_fn__1685000442_A_New() *A_arbace_go_check_summarize_fn__1685000442_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000442_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_go_check_summarize_fn__1685000442_A) Ctor() {}
//line :572:1
func (t *A_arbace_go_check_summarize_fn__1685000442_A) Invoke_O_O__O(self, p1__1685000428_SHARP___1 any) any { var root_3720 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3720, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3722 lang.IFn; if linked_3721 == nil { ifn_3722 = lang.IFn_Cast(root_3720) } else { ifn_3722 = nil }; var arg_3723 any = p1__1685000428_SHARP___1; var arg_3724 any = A_arbace_go_check_A_const_346; var arg_3725 any = A_arbace_go_check_A_const_22; if linked_3721 == nil { return ifn_3722.Invoke_O_O_O__O(arg_3723, arg_3724, arg_3725) } else { return linked_3721.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3720, arg_3723, arg_3724, arg_3725) } }
func A_arbace_go_check_summarize_fn__1685000444_A_New() *A_arbace_go_check_summarize_fn__1685000444_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000444_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_summarize_fn__1685000444_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_summarize_fn__1685000444_A) Invoke_O_O__O(self, p1__1685000429_SHARP___1 any) any { var root_3701 any = A_arbace_go_check_A_const_344.GetRawRoot__O(); var linked_3702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3701, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3703 lang.IFn; if linked_3702 == nil { ifn_3703 = lang.IFn_Cast(root_3701) } else { ifn_3703 = nil }; var arg_3704 any; var root_3705 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3705, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3707 lang.IFn; if linked_3706 == nil { ifn_3707 = lang.IFn_Cast(root_3705) } else { ifn_3707 = nil }; var arg_3708 any = p1__1685000429_SHARP___1; var arg_3709 any = A_arbace_go_check_A_const_345; if linked_3706 == nil { arg_3704 = ifn_3707.Invoke_O_O__O(arg_3708, arg_3709) } else { arg_3704 = linked_3706.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3705, arg_3708, arg_3709) }; if linked_3702 == nil { return ifn_3703.Invoke_O__O(arg_3704) } else { return linked_3702.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3701, arg_3704) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :576:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_New(); var tmp2 *jrt.Class; var fncls__3812 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class; if


	fncls__3812 == nil { var fncls__3812d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class = fncls__3812d; tmp2 = fncls__3812d } else { tmp2 = fncls__3812 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_New() *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_A{}; t.Ctor(); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A) Ctor() {}
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A) Invoke_O_O__O(self, s__1685000448__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_New_O_O(self, s__1685000448__1); var tmp2 *jrt.Class; var fncls__3811 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class; if fncls__3811 == nil { var fncls__3811d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class = fncls__3811d; tmp2 = fncls__3811d } else { tmp2 = fncls__3811 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A{}; t.Ctor_O_O(p0, p1); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A) Ctor_O_O(c__iter__1685000447, c__s__1685000448 any) { t.F_iter__1685000447 = c__iter__1685000447; t.F_s__1685000448 = c__s__1685000448 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A) Invoke_O__O(self any) any { { var s__1685000448__1 any; var t_ any = t.F_s__1685000448; t.F_s__1685000448 = nil; s__1685000448__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3727 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3727, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3729 lang.IFn; if linked_3728 == nil { ifn_3729 = lang.IFn_Cast(root_3727) } else { ifn_3729 = nil }; var arg_3730 any = s__1685000448__1; if linked_3728 == nil { temp__1927000414__auto____2 = ifn_3729.Invoke_O__O(arg_3730) } else { temp__1927000414__auto____2 = linked_3728.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3727, arg_3730) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3731 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3731, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3733 lang.IFn; if linked_3732 == nil { ifn_3733 = lang.IFn_Cast(root_3731) } else { ifn_3733 = nil }; var arg_3734 any = xs__1927001018__auto____3; if linked_3732 == nil { r__4 = ifn_3733.Invoke_O__O(arg_3734) } else { r__4 = linked_3732.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3731, arg_3734) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3793 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class; if fncls__3793 == nil { var fncls__3793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class = fncls__3793d; tmp2 = fncls__3793d } else { tmp2 = fncls__3793 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3794 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3794, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3796 lang.IFn; if linked_3795 == nil { ifn_3796 = lang.IFn_Cast(root_3794) } else { ifn_3796 = nil }; var arg_3797 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_238.Invoke_O__O(r__4)); if linked_3795 == nil { fs__1927001036__auto____6 = ifn_3796.Invoke_O__O(arg_3797) } else { fs__1927001036__auto____6 = linked_3795.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3794, arg_3797) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3798 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var linked_3799 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3798, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3800 lang.IFn; if linked_3799 == nil { ifn_3800 = lang.IFn_Cast(root_3798) } else { ifn_3800 = nil }; var arg_3801 any = fs__1927001036__auto____6; var arg_3802 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000447); var tmp4 any; var root_3803 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3803, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3805 lang.IFn; if linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; var arg_3806 any = s__1685000448__1; if linked_3804 == nil { tmp4 = ifn_3805.Invoke_O__O(arg_3806) } else { tmp4 = linked_3804.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3803, arg_3806) }; arg_3802 = tmp3.Invoke_O__O(tmp4); if linked_3799 == nil { return ifn_3800.Invoke_O_O__O(arg_3801, arg_3802) } else { return linked_3799.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3798, arg_3801, arg_3802) } } else { var tmp5 any; var root_3807 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = s__1685000448__1; if linked_3808 == nil { tmp5 = ifn_3809.Invoke_O__O(arg_3810) } else { tmp5 = linked_3808.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3807, arg_3810) }; s__1685000448__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A{}; t.Ctor_O(p0); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A) Invoke_O_O__O(self, s__1685000450__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_New_O_O_O(self, t.F_r, s__1685000450__1); var tmp2 *jrt.Class; var fncls__3792 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class; if fncls__3792 == nil { var fncls__3792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class = fncls__3792d; tmp2 = fncls__3792d } else { tmp2 = fncls__3792 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A) Ctor_O_O_O(c__iter__1685000449, c__r, c__s__1685000450 any) { t.F_iter__1685000449 = c__iter__1685000449; t.F_r = c__r; t.F_s__1685000450 = c__s__1685000450 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A) Invoke_O__O(self any) any { { var s__1685000450__1 any; var t_ any = t.F_s__1685000450; t.F_s__1685000450 = nil; s__1685000450__1 = t_; for { var temp__1927000414__auto____2 any; var root_3735 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3735, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3737 lang.IFn; if linked_3736 == nil { ifn_3737 = lang.IFn_Cast(root_3735) } else { ifn_3737 = nil }; var arg_3738 any = s__1685000450__1; if linked_3736 == nil { temp__1927000414__auto____2 = ifn_3737.Invoke_O__O(arg_3738) } else { temp__1927000414__auto____2 = linked_3736.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3735, arg_3738) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000450__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3739 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3739, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3741 lang.IFn; if linked_3740 == nil { ifn_3741 = lang.IFn_Cast(root_3739) } else { ifn_3741 = nil }; var arg_3742 any = s__1685000450__3; if linked_3740 == nil { tmp1 = ifn_3741.Invoke_O__O(arg_3742) } else { tmp1 = linked_3740.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3739, arg_3742) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3743 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3743, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3745 lang.IFn; if linked_3744 == nil { ifn_3745 = lang.IFn_Cast(root_3743) } else { ifn_3745 = nil }; var arg_3746 any = s__1685000450__3; if linked_3744 == nil { c__1927001037__auto____4 = ifn_3745.Invoke_O__O(arg_3746) } else { c__1927001037__auto____4 = linked_3744.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3743, arg_3746) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000452__6 any; var root_3747 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3747, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3749 lang.IFn; if linked_3748 == nil { ifn_3749 = lang.IFn_Cast(root_3747) } else { ifn_3749 = nil }; var arg_3750 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3748 == nil { b__1685000452__6 = ifn_3749.Invoke_O__O(arg_3750) } else { b__1685000452__6 = linked_3748.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3747, arg_3750) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000452__6); var tmp3 *jrt.Class; var fncls__3756 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class; if fncls__3756 == nil { var fncls__3756d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class = fncls__3756d; tmp3 = fncls__3756d } else { tmp3 = fncls__3756 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3757 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3757, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3759 lang.IFn; if linked_3758 == nil { ifn_3759 = lang.IFn_Cast(root_3757) } else { ifn_3759 = nil }; var arg_3760 any; var root_3762 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3762, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3764 lang.IFn; if linked_3763 == nil { ifn_3764 = lang.IFn_Cast(root_3762) } else { ifn_3764 = nil }; var arg_3765 any = b__1685000452__6; if linked_3763 == nil { arg_3760 = ifn_3764.Invoke_O__O(arg_3765) } else { arg_3760 = linked_3763.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3762, arg_3765) }; var arg_3761 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000449); var tmp5 any; var root_3766 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3766, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3768 lang.IFn; if linked_3767 == nil { ifn_3768 = lang.IFn_Cast(root_3766) } else { ifn_3768 = nil }; var arg_3769 any = s__1685000450__3; if linked_3767 == nil { tmp5 = ifn_3768.Invoke_O__O(arg_3769) } else { tmp5 = linked_3767.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3766, arg_3769) }; arg_3761 = tmp4.Invoke_O__O(tmp5); if linked_3758 == nil { return ifn_3759.Invoke_O_O__O(arg_3760, arg_3761) } else { return linked_3758.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3757, arg_3760, arg_3761) } } else { var root_3770 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3770, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3772 lang.IFn; if linked_3771 == nil { ifn_3772 = lang.IFn_Cast(root_3770) } else { ifn_3772 = nil }; var arg_3773 any; var root_3775 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3775, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3777 lang.IFn; if linked_3776 == nil { ifn_3777 = lang.IFn_Cast(root_3775) } else { ifn_3777 = nil }; var arg_3778 any = b__1685000452__6; if linked_3776 == nil { arg_3773 = ifn_3777.Invoke_O__O(arg_3778) } else { arg_3773 = linked_3776.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3775, arg_3778) }; var arg_3774 any; if linked_3771 == nil { return ifn_3772.Invoke_O_O__O(arg_3773, arg_3774) } else { return linked_3771.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3770, arg_3773, arg_3774) } } } else { var e__4 any; var root_3779 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3779, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3781 lang.IFn; if linked_3780 == nil { ifn_3781 = lang.IFn_Cast(root_3779) } else { ifn_3781 = nil }; var arg_3782 any = s__1685000450__3; if linked_3780 == nil { e__4 = ifn_3781.Invoke_O__O(arg_3782) } else { e__4 = linked_3780.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3779, arg_3782) }; var root_3783 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3783, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3785 lang.IFn; if linked_3784 == nil { ifn_3785 = lang.IFn_Cast(root_3783) } else { ifn_3785 = nil }; var arg_3786 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_74.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_79.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_312.Invoke_O__O(e__4))).Ref(); var arg_3787 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000449); var tmp7 any; var root_3788 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3788, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3790 lang.IFn; if linked_3789 == nil { ifn_3790 = lang.IFn_Cast(root_3788) } else { ifn_3790 = nil }; var arg_3791 any = s__1685000450__3; if linked_3789 == nil { tmp7 = ifn_3790.Invoke_O__O(arg_3791) } else { tmp7 = linked_3789.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3788, arg_3791) }; arg_3787 = tmp6.Invoke_O__O(tmp7); if linked_3784 == nil { return ifn_3785.Invoke_O_O__O(arg_3786, arg_3787) } else { return linked_3784.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3783, arg_3786, arg_3787) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000452 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000452 = c__b__1685000452 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A) Invoke_O__O(self any) any { { var i__1685000451__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000451__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000451__1)); var root_3751 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3751, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3753 lang.IFn; if linked_3752 == nil { ifn_3753 = lang.IFn_Cast(root_3751) } else { ifn_3753 = nil }; var arg_3754 any = t.F_b__1685000452; var arg_3755 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_74.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_79.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_312.Invoke_O__O(e__2))).Ref(); if linked_3752 == nil { ifn_3753.Invoke_O_O__O(arg_3754, arg_3755) } else { linked_3752.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3751, arg_3754, arg_3755) }; i__1685000451__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000451__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :584:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000465__3 any; var root_3813 any = A_arbace_go_check_A_const_347.GetRawRoot__O(); var linked_3814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3813, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3815 lang.IFn; if



	linked_3814 == nil { ifn_3815 = lang.IFn_Cast(root_3813) } else { ifn_3815 = nil }; var arg_3816 any = forms__0; if linked_3814 == nil { map__1685000465__3 = ifn_3815.Invoke_O__O(arg_3816) } else { map__1685000465__3 = linked_3814.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3813, arg_3816) }; var map__1685000465__4 any; if lang.ISeq_InstanceOf(map__1685000465__3) { var tmp1 any; var root_3817 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3817, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3819 lang.IFn; if linked_3818 == nil { ifn_3819 = lang.IFn_Cast(root_3817) } else { ifn_3819 = nil }; var arg_3820 any = map__1685000465__3; if linked_3818 == nil { tmp1 = ifn_3819.Invoke_O__O(arg_3820) } else { tmp1 = linked_3818.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3817, arg_3820) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3821 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3823 lang.IFn; if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any = map__1685000465__3; if linked_3822 == nil { tmp2 = ifn_3823.Invoke_O__O(arg_3824) } else { tmp2 = linked_3822.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3821, arg_3824) }; map__1685000465__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_3825 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = map__1685000465__3; if linked_3826 == nil { tmp3 = ifn_3827.Invoke_O__O(arg_3828) } else { tmp3 = linked_3826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3825, arg_3828) }; if jrt.J2g_Truth(tmp3) { var root_3829 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3829, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3831 lang.IFn; if linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any = map__1685000465__3; if linked_3830 == nil { map__1685000465__4 = ifn_3831.Invoke_O__O(arg_3832) } else { map__1685000465__4 = linked_3830.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3829, arg_3832) } } else { map__1685000465__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000465__4 = map__1685000465__3 }; var package__5 any = /*line :584:1*/lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_110); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_71); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_125); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_348.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_349; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_112.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_111; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_111.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_118 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_71; var tmp10 any; var root_3839 any = /*line :584:1*/A_arbace_go_check_A_const_350.GetRawRoot__O(); var linked_3840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3839, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3841 lang.IFn; if





	linked_3840 == nil { ifn_3841 = lang.IFn_Cast(root_3839) } else { ifn_3841 = nil }; var arg_3842 any = name__6; if linked_3840 == nil { tmp10 = ifn_3841.Invoke_O__O(arg_3842) } else { tmp10 = linked_3840.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3839, arg_3842) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_112; var tmp13 any = A_arbace_go_check_A_const_82; var tmp14 any = A_arbace_go_check_A_const_233; var tmp15 any; var root_3843 any = /*line :584:1*/A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3843, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3845 lang.IFn; if






	linked_3844 == nil { ifn_3845 = lang.IFn_Cast(root_3843) } else { ifn_3845 = nil }; var arg_3846 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000467_A_New(); var tmp17 *jrt.Class; var fncls__3860 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000467_A_fn_class; if fncls__3860 == nil { var fncls__3860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_forms_source_fn__1685000467_A_fn_class = fncls__3860d; tmp17 = fncls__3860d } else { tmp17 = fncls__3860 }; arg_3846 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3847 any = forms__0; if linked_3844 == nil { tmp15 = ifn_3845.Invoke_O_O__O(arg_3846, arg_3847) } else { tmp15 = linked_3844.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3843, arg_3846, arg_3847) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_125; var tmp20 any; var root_3861 any = /*line :584:1*/A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3861, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3863 lang.IFn; if







	linked_3862 == nil { ifn_3863 = lang.IFn_Cast(root_3861) } else { ifn_3863 = nil }; var arg_3864 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_New(); var tmp22 *jrt.Class; var fncls__3935 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class; if fncls__3935 == nil { var fncls__3935d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class = fncls__3935d; tmp22 = fncls__3935d } else { tmp22 = fncls__3935 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3864 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3862 == nil { tmp20 = ifn_3863.Invoke_O__O(arg_3864) } else { tmp20 = linked_3862.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3861, arg_3864) }; return /*line :584:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000467_A_New() *A_arbace_go_check_forms_source_fn__1685000467_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000467_A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_go_check_forms_source_fn__1685000467_A) Ctor() {}
//line :591:1
func (t *A_arbace_go_check_forms_source_fn__1685000467_A) Invoke_O_O__O(self, p1__1685000464_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3848 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3848, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3850 lang.IFn; if linked_3849 == nil { ifn_3850 = lang.IFn_Cast(root_3848) } else { ifn_3850 = nil }; var arg_3851 any = p1__1685000464_SHARP___1; if linked_3849 == nil { and__1927000168__auto____2 = ifn_3850.Invoke_O__O(arg_3851) } else { and__1927000168__auto____2 = linked_3849.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3848, arg_3851) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_351; var tmp3 any; var root_3852 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3852, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3854 lang.IFn; if linked_3853 == nil { ifn_3854 = lang.IFn_Cast(root_3852) } else { ifn_3854 = nil }; var arg_3855 any = p1__1685000464_SHARP___1; if linked_3853 == nil { tmp3 = ifn_3854.Invoke_O__O(arg_3855) } else { tmp3 = linked_3853.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3852, arg_3855) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3856 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_3857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3856, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3858 lang.IFn; if linked_3857 == nil { ifn_3858 = lang.IFn_Cast(root_3856) } else { ifn_3858 = nil }; var arg_3859 any = p1__1685000464_SHARP___1; if linked_3857 == nil { return ifn_3858.Invoke_O__O(arg_3859) } else { return linked_3857.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3856, arg_3859) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_New() *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_A{}; t.Ctor(); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A) Ctor() {}
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A) Invoke_O_O__O(self, s__1685000470__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_New_O_O(self, s__1685000470__1); var tmp2 *jrt.Class; var fncls__3934 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class; if fncls__3934 == nil { var fncls__3934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class = fncls__3934d; tmp2 = fncls__3934d } else { tmp2 = fncls__3934 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :592:1
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A{}; t.Ctor_O_O(p0, p1); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A) Ctor_O_O(c__iter__1685000469, c__s__1685000470 any) { t.F_iter__1685000469 = c__iter__1685000469; t.F_s__1685000470 = c__s__1685000470 }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A) Invoke_O__O(self any) any { { var s__1685000470__1 any; var t_ any = t.F_s__1685000470; t.F_s__1685000470 = nil; s__1685000470__1 = t_; for { var temp__1927000414__auto____2 any; var root_3865 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3865, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3867 lang.IFn; if linked_3866 == nil { ifn_3867 = lang.IFn_Cast(root_3865) } else { ifn_3867 = nil }; var arg_3868 any = s__1685000470__1; if linked_3866 == nil { temp__1927000414__auto____2 = ifn_3867.Invoke_O__O(arg_3868) } else { temp__1927000414__auto____2 = linked_3866.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3865, arg_3868) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000470__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3869 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3869, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3871 lang.IFn; if linked_3870 == nil { ifn_3871 = lang.IFn_Cast(root_3869) } else { ifn_3871 = nil }; var arg_3872 any = s__1685000470__3; if linked_3870 == nil { tmp1 = ifn_3871.Invoke_O__O(arg_3872) } else { tmp1 = linked_3870.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3869, arg_3872) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3873 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3873, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3875 lang.IFn; if linked_3874 == nil { ifn_3875 = lang.IFn_Cast(root_3873) } else { ifn_3875 = nil }; var arg_3876 any = s__1685000470__3; if linked_3874 == nil { c__1927001037__auto____4 = ifn_3875.Invoke_O__O(arg_3876) } else { c__1927001037__auto____4 = linked_3874.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3873, arg_3876) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000472__6 any; var root_3877 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3877, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3879 lang.IFn; if linked_3878 == nil { ifn_3879 = lang.IFn_Cast(root_3877) } else { ifn_3879 = nil }; var arg_3880 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3878 == nil { b__1685000472__6 = ifn_3879.Invoke_O__O(arg_3880) } else { b__1685000472__6 = linked_3878.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3877, arg_3880) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_New_I_O_O(size__1927001038__auto____5, b__1685000472__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3892 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class; if fncls__3892 == nil { var fncls__3892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class = fncls__3892d; tmp3 = fncls__3892d } else { tmp3 = fncls__3892 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3893 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3893, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3895 lang.IFn; if linked_3894 == nil { ifn_3895 = lang.IFn_Cast(root_3893) } else { ifn_3895 = nil }; var arg_3896 any; var root_3898 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3898, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3900 lang.IFn; if linked_3899 == nil { ifn_3900 = lang.IFn_Cast(root_3898) } else { ifn_3900 = nil }; var arg_3901 any = b__1685000472__6; if linked_3899 == nil { arg_3896 = ifn_3900.Invoke_O__O(arg_3901) } else { arg_3896 = linked_3899.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3898, arg_3901) }; var arg_3897 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000469); var tmp5 any; var root_3902 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = s__1685000470__3; if linked_3903 == nil { tmp5 = ifn_3904.Invoke_O__O(arg_3905) } else { tmp5 = linked_3903.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3902, arg_3905) }; arg_3897 = tmp4.Invoke_O__O(tmp5); if linked_3894 == nil { return ifn_3895.Invoke_O_O__O(arg_3896, arg_3897) } else { return linked_3894.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3893, arg_3896, arg_3897) } } else { var root_3906 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3908 lang.IFn; if linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any; var root_3911 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3911, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3913 lang.IFn; if linked_3912 == nil { ifn_3913 = lang.IFn_Cast(root_3911) } else { ifn_3913 = nil }; var arg_3914 any = b__1685000472__6; if linked_3912 == nil { arg_3909 = ifn_3913.Invoke_O__O(arg_3914) } else { arg_3909 = linked_3912.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3911, arg_3914) }; var arg_3910 any; if linked_3907 == nil { return ifn_3908.Invoke_O_O__O(arg_3909, arg_3910) } else { return linked_3907.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3906, arg_3909, arg_3910) } } } else { var fi__4 any; var root_3915 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3915, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3917 lang.IFn; if linked_3916 == nil { ifn_3917 = lang.IFn_Cast(root_3915) } else { ifn_3917 = nil }; var arg_3918 any = s__1685000470__3; if linked_3916 == nil { fi__4 = ifn_3917.Invoke_O__O(arg_3918) } else { fi__4 = linked_3916.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3915, arg_3918) }; var root_3919 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3919, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3921 lang.IFn; if linked_3920 == nil { ifn_3921 = lang.IFn_Cast(root_3919) } else { ifn_3921 = nil }; var arg_3922 any; var root_3924 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3925 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3924, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3926 lang.IFn; if linked_3925 == nil { ifn_3926 = lang.IFn_Cast(root_3924) } else { ifn_3926 = nil }; var arg_3927 any = fi__4; var arg_3928 any = A_arbace_go_check_A_const_82; var arg_3929 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__4); if linked_3925 == nil { arg_3922 = ifn_3926.Invoke_O_O_O__O(arg_3927, arg_3928, arg_3929) } else { arg_3922 = linked_3925.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3924, arg_3927, arg_3928, arg_3929) }; var arg_3923 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000469); var tmp7 any; var root_3930 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3930, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3932 lang.IFn; if linked_3931 == nil { ifn_3932 = lang.IFn_Cast(root_3930) } else { ifn_3932 = nil }; var arg_3933 any = s__1685000470__3; if linked_3931 == nil { tmp7 = ifn_3932.Invoke_O__O(arg_3933) } else { tmp7 = linked_3931.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3930, arg_3933) }; arg_3923 = tmp6.Invoke_O__O(tmp7); if linked_3920 == nil { return ifn_3921.Invoke_O_O__O(arg_3922, arg_3923) } else { return linked_3920.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3919, arg_3922, arg_3923) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :592:1
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1685000472, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000472 = c__b__1685000472; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A) Invoke_O__O(self any) any { { var i__1685000471__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000471__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000471__1)); var root_3881 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3881, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3883 lang.IFn; if linked_3882 == nil { ifn_3883 = lang.IFn_Cast(root_3881) } else { ifn_3883 = nil }; var arg_3884 any = t.F_b__1685000472; var arg_3885 any; var root_3886 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3886, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3888 lang.IFn; if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any = fi__2; var arg_3890 any = A_arbace_go_check_A_const_82; var arg_3891 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__2); if linked_3887 == nil { arg_3885 = ifn_3888.Invoke_O_O_O__O(arg_3889, arg_3890, arg_3891) } else { arg_3885 = linked_3887.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3886, arg_3889, arg_3890, arg_3891) }; if linked_3882 == nil { ifn_3883.Invoke_O_O__O(arg_3884, arg_3885) } else { linked_3882.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3881, arg_3884, arg_3885) }; i__1685000471__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000471__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :594:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3945 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_3946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3945, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3947 lang.IFn; if




	linked_3946 == nil { ifn_3947 = lang.IFn_Cast(root_3945) } else { ifn_3947 = nil }; var arg_3948 any = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_353, jrt.Boolean_FALSE.Ref()); if linked_3946 == nil { ifn_3947.Invoke_O__O(arg_3948) } else { linked_3946.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3945, arg_3948) }; var tmp1 any; tmp3 := /*line :594:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3936 any = A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_3937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3936, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3938 lang.IFn






		if linked_3937 == nil { ifn_3938 = lang.IFn_Cast(root_3936) } else { ifn_3938 = nil }; var arg_3939 any = r__2; var arg_3940 any = jrt.Boolean_FALSE.Ref(); var arg_3941 any = eof__3; if linked_3937 == nil { f__7 = ifn_3938.Invoke_O_O_O__O(arg_3939, arg_3940, arg_3941) } else { f__7 = linked_3937.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3936, arg_3939, arg_3940, arg_3941) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3954 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3954, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3956 lang.IFn; if linked_3955 == nil { ifn_3956 = lang.IFn_Cast(root_3954) } else { ifn_3956 = nil }; var arg_3957 any = acc__6; var arg_3958 any = f__7; if linked_3955 == nil { tmp2 = ifn_3956.Invoke_O_O__O(arg_3957, arg_3958) } else { tmp2 = linked_3955.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3954, arg_3957, arg_3958) }; acc__6 = tmp2; continue L1 }
//line :594:1
		break L1 } }; return nil }(); var root_3942 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_3943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3942, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3944 lang.IFn; if




	linked_3943 == nil { ifn_3944 = lang.IFn_Cast(root_3942) } else { ifn_3944 = nil }; if linked_3943 == nil { ifn_3944.Invoke__O() } else { linked_3943.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3942) }; if /*line :594:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :606:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :606:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3959 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3959, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3961 lang.IFn; if


	linked_3960 == nil { ifn_3961 = lang.IFn_Cast(root_3959) } else { ifn_3961 = nil }; var arg_3962 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); if linked_3960 == nil { tmp1 = ifn_3961.Invoke_O__O(arg_3962) } else { tmp1 = linked_3960.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3959, arg_3962) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3963 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3963, A_arbace_go_check_std_session_A_fn_class); var ifn_3965 lang.IFn
		if linked_3964 == nil { ifn_3965 = lang.IFn_Cast(root_3963) } else { ifn_3965 = nil }; var arg_3966 any; var root_3967 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3967, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3969 lang.IFn; if linked_3968 == nil { ifn_3969 = lang.IFn_Cast(root_3967) } else { ifn_3969 = nil }; var arg_3970 any = corpus__0; if linked_3968 == nil { arg_3966 = ifn_3969.Invoke_O__O(arg_3970) } else { arg_3966 = linked_3968.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3967, arg_3970) }; if linked_3964 == nil { s__3 = ifn_3965.Invoke_O__O(arg_3966) } else { s__3 = linked_3964.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3963, arg_3966) }
		var root_3971 any = A_arbace_go_check_A_const_284.GetRawRoot__O(); var linked_3972 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3971, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3973 lang.IFn; if linked_3972 == nil { ifn_3973 = lang.IFn_Cast(root_3971) } else { ifn_3973 = nil }; var arg_3974 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); var arg_3975 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var arg_3976 any = corpus__0; var arg_3977 any = s__3; if linked_3972 == nil { ifn_3973.Invoke_O_O_O_O__O(arg_3974, arg_3975, arg_3976, arg_3977) } else { linked_3972.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3971, arg_3974, arg_3975, arg_3976, arg_3977) }
//line :609:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3978 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3978, A_arbace_go_check_std_A_fn_class); var ifn_3980 lang.IFn; if




	linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; var arg_3981 any = corpus__1; if linked_3979 == nil { s__4 = ifn_3980.Invoke_O__O(arg_3981) } else { s__4 = linked_3979.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3978, arg_3981) }; var src__5 any; var root_3982 any = /*line :614:1*/A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_3983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3982, A_arbace_go_check_forms_source_A_fn_class); var ifn_3984 lang.IFn; if





	linked_3983 == nil { ifn_3984 = lang.IFn_Cast(root_3982) } else { ifn_3984 = nil }; var arg_3985 any = forms__0; var arg_3986 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_112; var tmp2 any; var root_3987 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3987, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3989 lang.IFn; if linked_3988 == nil { ifn_3989 = lang.IFn_Cast(root_3987) } else { ifn_3989 = nil }; var arg_3990 any = corpus__1; if linked_3988 == nil { tmp2 = ifn_3989.Invoke_O__O(arg_3990) } else { tmp2 = linked_3988.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3987, arg_3990) }; arg_3986 = tmp1.Invoke_O__O(tmp2); if linked_3983 == nil { src__5 = ifn_3984.Invoke_O_O__O(arg_3985, arg_3986) } else { src__5 = linked_3983.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3982, arg_3985, arg_3986) }; var pkg__6 any; var tmp3 lang.IFn = /*line :614:1*/lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp4 any; var root_3998 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_3999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3998, A_arbace_go_check_resolver_A_fn_class); var ifn_4000 lang.IFn; if






	linked_3999 == nil { ifn_4000 = lang.IFn_Cast(root_3998) } else { ifn_4000 = nil }; var arg_4001 any = s__4; var arg_4002 any = src__5; var arg_4003 any = lang.PersistentVector_EMPTY.Ref(); if linked_3999 == nil { tmp4 = ifn_4000.Invoke_O_O_O__O(arg_4001, arg_4002, arg_4003) } else { tmp4 = linked_3999.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3998, arg_4001, arg_4002, arg_4003) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_109; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_109.Invoke_O__O(opts__2)); var root_4004 any =
	A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_4005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4004, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_4006 lang.IFn; if linked_4005 == nil { ifn_4006 = lang.IFn_Cast(root_4004) } else { ifn_4006 = nil }; var arg_4007 any = pkg__6; var arg_4008 any = A_arbace_go_check_A_const_237; if linked_4005 == nil { return ifn_4006.Invoke_O_O__O(arg_4007, arg_4008) } else { return linked_4005.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_4004, arg_4007, arg_4008) } }
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_4009 any = A_arbace_go_check_A_const_357.GetRawRoot__O(); var linked_4010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4009, A_arbace_go_check_check_forms_A_fn_class); var ifn_4011 lang.IFn; if linked_4010 == nil { ifn_4011 = lang.IFn_Cast(root_4009) } else { ifn_4011 = nil }; var arg_4012 any = forms__0; var arg_4013 any = Lit_54; var arg_4014 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4010 == nil { return ifn_4011.Invoke_O_O_O__O(arg_4012, arg_4013, arg_4014) } else { return linked_4010.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_4009, arg_4012, arg_4013, arg_4014)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :630:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_362.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_358.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_4032 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_4033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4032, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4034 lang.IFn; if linked_4033 == nil { ifn_4034 = lang.IFn_Cast(root_4032) } else { ifn_4034 = nil }; var arg_4035 any = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_361, s__1927001093__auto____3); if linked_4033 == nil { ifn_4034.Invoke_O__O(arg_4035) } else { linked_4033.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4032, arg_4035) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000483_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__4031 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000483_A_fn_class; if fncls__4031 == nil { var fncls__4031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_go_check_write_edn_fn__1685000483_A_fn_class = fncls__4031d; tmp4 = fncls__4031d } else { tmp4 = fncls__4031 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :632:1
func A_arbace_go_check_write_edn_fn__1685000483_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000483_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000483_A{}; t.Ctor_O_O(p0, p1); return t }
//line :632:1
func (t *A_arbace_go_check_write_edn_fn__1685000483_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :632:1
func (t *A_arbace_go_check_write_edn_fn__1685000483_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4027 any = A_arbace_go_check_A_const_360.GetRawRoot__O(); var linked_4028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4027, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_4029 lang.IFn; if linked_4028 == nil { ifn_4029 = lang.IFn_Cast(root_4027) } else { ifn_4029 = nil }; var arg_4030 any; var t_ any = t.F_x; t.F_x = nil; arg_4030 = t_; if linked_4028 == nil { ifn_4029.Invoke_O__O(arg_4030) } else { linked_4028.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_4027, arg_4030) }; var root_4020 any = A_arbace_go_check_A_const_359.GetRawRoot__O(); var linked_4021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4020, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4022 lang.IFn; if linked_4021 == nil { ifn_4022 = lang.IFn_Cast(root_4020) } else { ifn_4022 = nil }; var arg_4023 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_4023 = t__2; if linked_4021 == nil { tmp1 = ifn_4022.Invoke_O__O(arg_4023) } else { tmp1 = linked_4021.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4020, arg_4023) } }; return nil }(); var root_4024 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4024, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4026 lang.IFn; if linked_4025 == nil { ifn_4026 = lang.IFn_Cast(root_4024) } else { ifn_4026 = nil }; if linked_4025 == nil { ifn_4026.Invoke__O() } else { linked_4025.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4024) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }






func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :639:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :639:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any {
	if jrt.J2g_Truth(A_arbace_go_check_A_const_363.Get__O()) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_363.Get__O(), nil, corpus__0, nil)).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil, Lit_129), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil, corpus__0, nil)).Ref()
		} }
func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :644:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000487__1 any) any { var map__1685000488__3 any = p__1685000487__1; var map__1685000488__4 any; if lang.ISeq_InstanceOf(map__1685000488__3) { var tmp1 any; var root_4045 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4045, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4047 lang.IFn; if linked_4046 == nil { ifn_4047 = lang.IFn_Cast(root_4045) } else { ifn_4047 = nil }; var arg_4048 any = map__1685000488__3; if linked_4046 == nil { tmp1 = ifn_4047.Invoke_O__O(arg_4048) } else { tmp1 = linked_4046.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4045, arg_4048) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_4049 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any = map__1685000488__3; if linked_4050 == nil { tmp2 = ifn_4051.Invoke_O__O(arg_4052) } else { tmp2 = linked_4050.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4049, arg_4052) }; map__1685000488__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_4053 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4053, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4055 lang.IFn; if linked_4054 == nil { ifn_4055 = lang.IFn_Cast(root_4053) } else { ifn_4055 = nil }; var arg_4056 any = map__1685000488__3; if linked_4054 == nil { tmp3 = ifn_4055.Invoke_O__O(arg_4056) } else { tmp3 = linked_4054.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4053, arg_4056) }; if jrt.J2g_Truth(tmp3) { var root_4057 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4057, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4059 lang.IFn; if linked_4058 == nil { ifn_4059 = lang.IFn_Cast(root_4057) } else { ifn_4059 = nil }; var arg_4060 any = map__1685000488__3; if linked_4058 == nil { map__1685000488__4 = ifn_4059.Invoke_O__O(arg_4060) } else { map__1685000488__4 = linked_4058.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4057, arg_4060) } } else { map__1685000488__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000488__4 = map__1685000488__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_364); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_365); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_366); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_4061 any = A_arbace_go_check_A_const_367.GetRawRoot__O(); var linked_4062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4061, A_arbace_go_check_check_corpus_A_fn_class); var ifn_4063 lang.IFn; if






	linked_4062 == nil { ifn_4063 = lang.IFn_Cast(root_4061) } else { ifn_4063 = nil }; var arg_4064 any = corpus__0; var arg_4065 any = jobs__5; if linked_4062 == nil { rs__9 = ifn_4063.Invoke_O_O__O(arg_4064, arg_4065) } else { rs__9 = linked_4062.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_4061, arg_4064, arg_4065) }; var sm__10 any; var root_4066 any = /*line :644:1*/A_arbace_go_check_A_const_368.GetRawRoot__O(); var linked_4067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4066, A_arbace_go_check_summarize_A_fn_class); var ifn_4068 lang.IFn; if







	linked_4067 == nil { ifn_4068 = lang.IFn_Cast(root_4066) } else { ifn_4068 = nil }; var arg_4069 any = corpus__0; var arg_4070 any = rs__9; if linked_4067 == nil { sm__10 = ifn_4068.Invoke_O_O__O(arg_4069, arg_4070) } else { sm__10 = linked_4067.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_4066, arg_4069, arg_4070) }; var secs__11 float64 = /*line :644:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_369; var tmp5 any; var root_4071 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4071, A_arbace_go_check_reference_path_A_fn_class); var ifn_4073 lang.IFn; if









	linked_4072 == nil { ifn_4073 = lang.IFn_Cast(root_4071) } else { ifn_4073 = nil }; var arg_4074 any = corpus__0; if linked_4072 == nil { tmp5 = ifn_4073.Invoke_O__O(arg_4074) } else { tmp5 = linked_4072.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4071, arg_4074) }; ref_file__12 = /*line :644:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var r__13 any; var root_4075 any = A_arbace_go_check_A_const_371.GetRawRoot__O(); var linked_4076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4075, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_4077 lang.IFn
		if linked_4076 == nil { ifn_4077 = lang.IFn_Cast(root_4075) } else { ifn_4077 = nil }; var arg_4078 any = lang.IFn_Cast(A_arbace_go_check_A_const_372.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_4076 == nil { r__13 = ifn_4077.Invoke_O__O(arg_4078) } else { r__13 = linked_4076.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_4075, arg_4078) }; if jrt.J2g_Truth(A_arbace_go_check_A_const_363.Get__O()) { var root_4083 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4083, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4085 lang.IFn; if linked_4084 == nil { ifn_4085 = lang.IFn_Cast(root_4083) } else { ifn_4085 = nil }; var arg_4086 any = A_arbace_go_check_A_const_373.Invoke_O__O(r__13); var arg_4087 any = A_arbace_go_check_A_const_337; if linked_4084 == nil { ref__13 = ifn_4085.Invoke_O_O__O(arg_4086, arg_4087) } else { ref__13 = linked_4084.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4083, arg_4086, arg_4087) } } else { ref__13 = r__13 } } else {
//line :655:1
			ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_4088 any = /*line :644:1*/A_arbace_go_check_A_const_238.Invoke_O__O(sm__10); if












	jrt.Long_InstanceOf(na_4088) { var n0_4089 int64 = jrt.NN(jrt.Long_Cast(na_4088)).LongValue__J(); and__1927000168__auto____14 = n0_4089 == 0 } else { if jrt.Double_InstanceOf(na_4088) { var n0_4089_2 float64 = jrt.NN(jrt.Double_Cast(na_4088)).DoubleValue__D(); and__1927000168__auto____14 = n0_4089_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_4088) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_4090 any = A_arbace_go_check_A_const_335.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_4090) { var n0_4091 int64 = jrt.NN(jrt.Long_Cast(na_4090)).LongValue__J(); and__1927000168__auto____15 = n0_4091 == 0 } else { if jrt.Double_InstanceOf(na_4090) { var n0_4091_2 float64 = jrt.NN(jrt.Double_Cast(na_4090)).DoubleValue__D(); and__1927000168__auto____15 = n0_4091_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_4090) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_4092 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_4093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4092, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4094 lang.IFn; if linked_4093 == nil { ifn_4094 = lang.IFn_Cast(root_4092) } else { ifn_4094 = nil }; var arg_4095 any; var root_4096 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4096, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4098 lang.IFn; if linked_4097 == nil { ifn_4098 = lang.IFn_Cast(root_4096) } else { ifn_4098 = nil }; var arg_4099 any = sm__10; var arg_4100 any = A_arbace_go_check_A_const_374; if linked_4097 == nil { arg_4095 = ifn_4098.Invoke_O_O__O(arg_4099, arg_4100) } else { arg_4095 = linked_4097.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4096, arg_4099, arg_4100) }; if linked_4093 == nil { and__1927000168__auto____16 = ifn_4094.Invoke_O__O(arg_4095) } else { and__1927000168__auto____16 = linked_4093.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4092, arg_4095) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_4101 any; var root_4102 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4102, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4104 lang.IFn
		if linked_4103 == nil { ifn_4104 = lang.IFn_Cast(root_4102) } else { ifn_4104 = nil }; var arg_4105 any = sm__10; var arg_4106 any = A_arbace_go_check_A_const_375; if linked_4103 == nil { na_4101 = ifn_4104.Invoke_O_O__O(arg_4105, arg_4106) } else { na_4101 = linked_4103.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4102, arg_4105, arg_4106) }; if jrt.Long_InstanceOf(na_4101) { var n0_4107 int64 = jrt.NN(jrt.Long_Cast(na_4101)).LongValue__J(); and__1927000168__auto____17 = n0_4107 == 0 } else { if jrt.Double_InstanceOf(na_4101) { var n0_4107_2 float64 = jrt.NN(jrt.Double_Cast(na_4101)).DoubleValue__D(); and__1927000168__auto____17 = n0_4107_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_4101) } }
//line :657:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_4108 any; var root_4109 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4109, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4111 lang.IFn; if linked_4110 == nil { ifn_4111 = lang.IFn_Cast(root_4109) } else { ifn_4111 = nil }; var arg_4112 any = sm__10; var arg_4113 any = A_arbace_go_check_A_const_376; if linked_4110 == nil { na_4108 = ifn_4111.Invoke_O_O__O(arg_4112, arg_4113) } else { na_4108 = linked_4110.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4109, arg_4112, arg_4113) }; if jrt.Long_InstanceOf(na_4108) { var n0_4114 int64 = jrt.NN(jrt.Long_Cast(na_4108)).LongValue__J(); tmp6 = n0_4114 == 0 } else { if jrt.Double_InstanceOf(na_4108) { var n0_4114_2 float64 = jrt.NN(jrt.Double_Cast(na_4108)).DoubleValue__D(); tmp6 = n0_4114_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_4108) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :657:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_4115 any = /*line :644:1*/A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4116 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4115, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4117 lang.IFn; if















	linked_4116 == nil { ifn_4117 = lang.IFn_Cast(root_4115) } else { ifn_4117 = nil }; var arg_4118 any = ref__13; var arg_4119 any = A_arbace_go_check_A_const_377; if linked_4116 == nil { tmp7 = ifn_4117.Invoke_O_O__O(arg_4118, arg_4119) } else { tmp7 = linked_4116.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4115, arg_4118, arg_4119) }; var tmp8 any = tmp7; var tmp9 any; var root_4120 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4120, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4122 lang.IFn; if linked_4121 == nil { ifn_4122 = lang.IFn_Cast(root_4120) } else { ifn_4122 = nil }; var arg_4123 any = sm__10; var arg_4124 any = A_arbace_go_check_A_const_337; if linked_4121 == nil { tmp9 = ifn_4122.Invoke_O_O__O(arg_4123, arg_4124) } else { tmp9 = linked_4121.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4120, arg_4123, arg_4124) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_4133 any =
	A_arbace_go_check_A_const_378.GetRawRoot__O(); var linked_4134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4133, A_arbace_go_check_write_edn_A_fn_class); var ifn_4135 lang.IFn; if linked_4134 == nil { ifn_4135 = lang.IFn_Cast(root_4133) } else { ifn_4135 = nil }; var arg_4136 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_4137 any; var tmp10 any = A_arbace_go_check_A_const_373; var tmp11 any = A_arbace_go_check_A_const_379; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_238; var tmp14 any; var root_4138 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4138, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4140 lang.IFn; if

	linked_4139 == nil { ifn_4140 = lang.IFn_Cast(root_4138) } else { ifn_4140 = nil }; var arg_4141 any; var root_4142 any = A_arbace_go_check_A_const_380.GetRawRoot__O(); var linked_4143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4142, A_arbace_go_check_report_errors_A_fn_class); var ifn_4144 lang.IFn; if linked_4143 == nil { ifn_4144 = lang.IFn_Cast(root_4142) } else { ifn_4144 = nil }; var arg_4145 any = rs__9; if linked_4143 == nil { arg_4141 = ifn_4144.Invoke_O__O(arg_4145) } else { arg_4141 = linked_4143.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4142, arg_4145) }; if linked_4139 == nil { tmp14 = ifn_4140.Invoke_O__O(arg_4141) } else { tmp14 = linked_4139.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4138, arg_4141) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_166; var tmp17 any; var root_4146 any = /*line :661:1*/A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4146, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4148 lang.IFn; if


	linked_4147 == nil { ifn_4148 = lang.IFn_Cast(root_4146) } else { ifn_4148 = nil }; var arg_4149 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_A_New(); var tmp19 *jrt.Class; var fncls__4235 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class; if fncls__4235 == nil { var fncls__4235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class = fncls__4235d; tmp19 = fncls__4235d } else { tmp19 = fncls__4235 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_4149 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_4147 == nil { tmp17 = ifn_4148.Invoke_O__O(arg_4149) } else { tmp17 = linked_4147.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4146, arg_4149) }; arg_4137 = /*line :661:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_4134 == nil { ifn_4135.Invoke_O_O__O(arg_4136, arg_4137) } else { linked_4134.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4133, arg_4136, arg_4137) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_331.Invoke_O__O(sm__10); var tmp23 any; var root_4254 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4254, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4256 lang.IFn; if
	linked_4255 == nil { ifn_4256 = lang.IFn_Cast(root_4254) } else { ifn_4256 = nil }; var arg_4257 any = sm__10; var arg_4258 any = A_arbace_go_check_A_const_382; if linked_4255 == nil { tmp23 = ifn_4256.Invoke_O_O__O(arg_4257, arg_4258) } else { tmp23 = linked_4255.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4254, arg_4257, arg_4258) }; var tmp24 any = tmp23; var tmp25 any; var root_4259 any = /*line :665:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4259, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4261 lang.IFn; if
	linked_4260 == nil { ifn_4261 = lang.IFn_Cast(root_4259) } else { ifn_4261 = nil }; var arg_4262 any = sm__10; var arg_4263 any = A_arbace_go_check_A_const_383; if linked_4260 == nil { tmp25 = ifn_4261.Invoke_O_O__O(arg_4262, arg_4263) } else { tmp25 = linked_4260.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4259, arg_4262, arg_4263) }; var tmp26 any = tmp25; var tmp27 any; var root_4264 any = /*line :665:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4264, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4266 lang.IFn; if

	linked_4265 == nil { ifn_4266 = lang.IFn_Cast(root_4264) } else { ifn_4266 = nil }; var arg_4267 any = sm__10; var arg_4268 any = A_arbace_go_check_A_const_384; if linked_4265 == nil { tmp27 = ifn_4266.Invoke_O_O__O(arg_4267, arg_4268) } else { tmp27 = linked_4265.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4264, arg_4267, arg_4268) }; var tmp28 any = tmp27; var tmp29 any = /*line :665:1*/A_arbace_go_check_A_const_238.Invoke_O__O(sm__10); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp31 any; var root_4273 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4273, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4275 lang.IFn; if


	linked_4274 == nil { ifn_4275 = lang.IFn_Cast(root_4273) } else { ifn_4275 = nil }; var arg_4276 any = sm__10; var arg_4277 any = A_arbace_go_check_A_const_385; if linked_4274 == nil { tmp31 = ifn_4275.Invoke_O_O__O(arg_4276, arg_4277) } else { tmp31 = linked_4274.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4273, arg_4276, arg_4277) }; var tmp32 any = /*line :665:1*/tmp30.Invoke_O__O(tmp31); var tmp33 any; var root_4278 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4278, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4280 lang.IFn; if



	linked_4279 == nil { ifn_4280 = lang.IFn_Cast(root_4278) } else { ifn_4280 = nil }; var arg_4281 any = sm__10; var arg_4282 any = A_arbace_go_check_A_const_386; if linked_4279 == nil { tmp33 = ifn_4280.Invoke_O_O__O(arg_4281, arg_4282) } else { tmp33 = linked_4279.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4278, arg_4281, arg_4282) }; var tmp34 any = tmp33; var tmp35 any; var root_4283 any = /*line :665:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4283, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4285 lang.IFn; if



	linked_4284 == nil { ifn_4285 = lang.IFn_Cast(root_4283) } else { ifn_4285 = nil }; var arg_4286 any = sm__10; var arg_4287 any = A_arbace_go_check_A_const_387; if linked_4284 == nil { tmp35 = ifn_4285.Invoke_O_O__O(arg_4286, arg_4287) } else { tmp35 = linked_4284.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4283, arg_4286, arg_4287) }; /*line :665:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_17, corpus__0, tmp22, tmp24, tmp26, tmp28, tmp29, tmp32, tmp34, tmp35, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000506__16 any; var root_4288 any = /*line :644:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4288, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4290 lang.IFn; if

























	linked_4289 == nil { ifn_4290 = lang.IFn_Cast(root_4288) } else { ifn_4290 = nil }; var arg_4291 any; var root_4292 any = A_arbace_go_check_A_const_388.GetRawRoot__O(); var linked_4293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4292, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4294 lang.IFn; if linked_4293 == nil { ifn_4294 = lang.IFn_Cast(root_4292) } else { ifn_4294 = nil }; var arg_4295 any = A_arbace_go_check_A_const_389; var arg_4296 any; var root_4297 any = A_arbace_go_check_A_const_380.GetRawRoot__O(); var linked_4298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4297, A_arbace_go_check_report_errors_A_fn_class); var ifn_4299 lang.IFn; if linked_4298 == nil { ifn_4299 = lang.IFn_Cast(root_4297) } else { ifn_4299 = nil }; var arg_4300 any = rs__9; if linked_4298 == nil { arg_4296 = ifn_4299.Invoke_O__O(arg_4300) } else { arg_4296 = linked_4298.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4297, arg_4300) }; if linked_4293 == nil { arg_4291 = ifn_4294.Invoke_O_O__O(arg_4295, arg_4296) } else { arg_4291 = linked_4293.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4292, arg_4295, arg_4296) }; if linked_4289 == nil { seq_1685000506__16 = ifn_4290.Invoke_O__O(arg_4291) } else { seq_1685000506__16 = linked_4289.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4288, arg_4291) }; var chunk_1685000507__17 any; var count_1685000508__18 int64 = 0; var i_1685000509__19 int64 = 0; L1:
//line :644:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000509__19, count_1685000508__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000507__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000509__19)); lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__20); seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000509__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_4301 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4303 lang.IFn; if linked_4302 == nil { ifn_4303 = lang.IFn_Cast(root_4301) } else { ifn_4303 = nil }; var arg_4304 any = seq_1685000506__16; if linked_4302 == nil { temp__1927000414__auto____20 = ifn_4303.Invoke_O__O(arg_4304) } else { temp__1927000414__auto____20 = linked_4302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4301, arg_4304) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000506__21 any = temp__1927000414__auto____20; var tmp36 any; var root_4305 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4305, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4307 lang.IFn; if linked_4306 == nil { ifn_4307 = lang.IFn_Cast(root_4305) } else { ifn_4307 = nil }; var arg_4308 any = seq_1685000506__21; if linked_4306 == nil { tmp36 = ifn_4307.Invoke_O__O(arg_4308) } else { tmp36 = linked_4306.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4305, arg_4308) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____22 any; var root_4309 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4309, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4311 lang.IFn; if linked_4310 == nil { ifn_4311 = lang.IFn_Cast(root_4309) } else { ifn_4311 = nil }; var arg_4312 any = seq_1685000506__21; if linked_4310 == nil { c__1927000678__auto____22 = ifn_4311.Invoke_O__O(arg_4312) } else { c__1927000678__auto____22 = linked_4310.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4309, arg_4312) }; var tmp37 any; var root_4358 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4358, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4360 lang.IFn; if linked_4359 == nil { ifn_4360 = lang.IFn_Cast(root_4358) } else { ifn_4360 = nil }; var arg_4361 any = seq_1685000506__21; if linked_4359 == nil { tmp37 = ifn_4360.Invoke_O__O(arg_4361) } else { tmp37 = linked_4359.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4358, arg_4361) }; seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = tmp37, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_4313 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4313, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4315 lang.IFn; if linked_4314 == nil { ifn_4315 = lang.IFn_Cast(root_4313) } else { ifn_4315 = nil }; var arg_4316 any = seq_1685000506__21; if linked_4314 == nil { l__22 = ifn_4315.Invoke_O__O(arg_4316) } else { l__22 = linked_4314.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4313, arg_4316) }; lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__22); var tmp38 any; var root_4367 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4367, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4369 lang.IFn; if linked_4368 == nil { ifn_4369 = lang.IFn_Cast(root_4367) } else { ifn_4369 = nil }; var arg_4370 any = seq_1685000506__21; if linked_4368 == nil { tmp38 = ifn_4369.Invoke_O__O(arg_4370) } else { tmp38 = linked_4368.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4367, arg_4370) }; seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = tmp38, nil, 0, 0; continue L1 } } }
//line :644:1
		break L1 }; var tmp39 any; var root_4317 any =


























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4317, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4319 lang.IFn; if linked_4318 == nil { ifn_4319 = lang.IFn_Cast(root_4317) } else { ifn_4319 = nil }; var arg_4320 any; var root_4321 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4321, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4323 lang.IFn; if linked_4322 == nil { ifn_4323 = lang.IFn_Cast(root_4321) } else { ifn_4323 = nil }; var arg_4324 any = sm__10; var arg_4325 any = A_arbace_go_check_A_const_390; if linked_4322 == nil { arg_4320 = ifn_4323.Invoke_O_O__O(arg_4324, arg_4325) } else { arg_4320 = linked_4322.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4321, arg_4324, arg_4325) }; if linked_4318 == nil { tmp39 = ifn_4319.Invoke_O__O(arg_4320) } else { tmp39 = linked_4318.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4317, arg_4320) }; if jrt.J2g_Truth(tmp39) {
		var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp42 any; var root_4335 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4335, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4337 lang.IFn; if linked_4336 == nil { ifn_4337 = lang.IFn_Cast(root_4335) } else { ifn_4337 = nil }; var arg_4338 any = sm__10; var arg_4339 any = A_arbace_go_check_A_const_391; if linked_4336 == nil { tmp42 = ifn_4337.Invoke_O_O__O(arg_4338, arg_4339) } else { tmp42 = linked_4336.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4335, arg_4338, arg_4339) }; tmp40.Invoke_O_O__O(Lit_19, tmp41.Invoke_O__O(tmp42)) }; var tmp43 any; var root_4340 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4342 lang.IFn; if linked_4341 == nil { ifn_4342 = lang.IFn_Cast(root_4340) } else { ifn_4342 = nil }; var arg_4343 any = A_arbace_go_check_A_const_145.Invoke_O__O(sm__10); if linked_4341 == nil { tmp43 = ifn_4342.Invoke_O__O(arg_4343) } else { tmp43 = linked_4341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4340, arg_4343) }; if jrt.J2g_Truth(tmp43) {
		lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O_O__O(Lit_20, lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_145.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_4371 any = A_arbace_go_check_A_const_378.GetRawRoot__O(); var linked_4372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4371, A_arbace_go_check_write_edn_A_fn_class); var ifn_4373 lang.IFn; if linked_4372 == nil { ifn_4373 = lang.IFn_Cast(root_4371) } else { ifn_4373 = nil }; var arg_4374 any; var root_4376 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4376, A_arbace_go_check_reference_path_A_fn_class); var ifn_4378 lang.IFn; if linked_4377 == nil { ifn_4378 = lang.IFn_Cast(root_4376) } else { ifn_4378 = nil }; var arg_4379 any = corpus__0; if linked_4377 == nil { arg_4374 = ifn_4378.Invoke_O__O(arg_4379) } else { arg_4374 = linked_4377.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4376, arg_4379) }; var arg_4375 any; var root_4380 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4380, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4382 lang.IFn; if linked_4381 == nil { ifn_4382 = lang.IFn_Cast(root_4380) } else { ifn_4382 = nil }; var arg_4383 any; var root_4386 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4386, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4388 lang.IFn; if linked_4387 == nil { ifn_4388 = lang.IFn_Cast(root_4386) } else { ifn_4388 = nil }; var arg_4389 any = sm__10; var arg_4390 any = A_arbace_go_check_A_const_337; if linked_4387 == nil { arg_4383 = ifn_4388.Invoke_O_O__O(arg_4389, arg_4390) } else { arg_4383 = linked_4387.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4386, arg_4389, arg_4390) }; var arg_4384 any = A_arbace_go_check_A_const_377; var arg_4385 any = Lit_21; if linked_4381 == nil { arg_4375 = ifn_4382.Invoke_O_O_O__O(arg_4383, arg_4384, arg_4385) } else { arg_4375 = linked_4381.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4380, arg_4383, arg_4384, arg_4385) }; if linked_4372 == nil { ifn_4373.Invoke_O_O__O(arg_4374, arg_4375) } else { linked_4372.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4371, arg_4374, arg_4375) }
		var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp45 any; var root_4396 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4396, A_arbace_go_check_reference_path_A_fn_class); var ifn_4398 lang.IFn; if linked_4397 == nil { ifn_4398 = lang.IFn_Cast(root_4396) } else { ifn_4398 = nil }; var arg_4399 any = corpus__0; if linked_4397 == nil { tmp45 = ifn_4398.Invoke_O__O(arg_4399) } else { tmp45 = linked_4397.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4396, arg_4399) }; tmp44.Invoke_O_O__O(Lit_22, tmp45)
//line :675:1
		return clean__14 } else { var tmp46 any; var root_4125 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4125, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4127 lang.IFn



			if linked_4126 == nil { ifn_4127 = lang.IFn_Cast(root_4125) } else { ifn_4127 = nil }; var arg_4128 any = clean__14; if linked_4126 == nil { tmp46 = ifn_4127.Invoke_O__O(arg_4128) } else { tmp46 = linked_4126.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4125, arg_4128) }
//line :675:1
			if jrt.J2g_Truth(tmp46) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp48 any; var root_4406 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4406, A_arbace_go_check_reference_path_A_fn_class); var ifn_4408 lang.IFn; if linked_4407 == nil { ifn_4408 = lang.IFn_Cast(root_4406) } else { ifn_4408 = nil }; var arg_4409 any = corpus__0; if linked_4407 == nil { tmp48 = ifn_4408.Invoke_O__O(arg_4409) } else { tmp48 = linked_4407.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4406, arg_4409) }; tmp47.Invoke_O_O_O__O(Lit_23, tmp48, Lit_24)
//line :675:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp49 any; var root_4129 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4129, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4131 lang.IFn





					if linked_4130 == nil { ifn_4131 = lang.IFn_Cast(root_4129) } else { ifn_4131 = nil }; var arg_4132 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_4130 == nil { tmp49 = ifn_4131.Invoke_O__O(arg_4132) } else { tmp49 = linked_4130.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4129, arg_4132) }
//line :675:1
					if jrt.J2g_Truth(tmp49) {





						var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp51 any; var root_4416 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4416, A_arbace_go_check_reference_path_A_fn_class); var ifn_4418 lang.IFn; if linked_4417 == nil { ifn_4418 = lang.IFn_Cast(root_4416) } else { ifn_4418 = nil }; var arg_4419 any = corpus__0; if linked_4417 == nil { tmp51 = ifn_4418.Invoke_O__O(arg_4419) } else { tmp51 = linked_4417.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4416, arg_4419) }; tmp50.Invoke_O_O_O__O(Lit_25, tmp51, Lit_26)
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp54 any; var root_4429 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4430 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4429, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4431 lang.IFn; if linked_4430 == nil { ifn_4431 = lang.IFn_Cast(root_4429) } else { ifn_4431 = nil }; var arg_4432 any = ref__13; var arg_4433 any = A_arbace_go_check_A_const_377; if linked_4430 == nil { tmp54 = ifn_4431.Invoke_O_O__O(arg_4432, arg_4433) } else { tmp54 = linked_4430.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4429, arg_4432, arg_4433) }; tmp52.Invoke_O_O__O(Lit_27, tmp53.Invoke_O__O(tmp54))
						var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp57 any; var root_4443 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4443, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4445 lang.IFn; if linked_4444 == nil { ifn_4445 = lang.IFn_Cast(root_4443) } else { ifn_4445 = nil }; var arg_4446 any = sm__10; var arg_4447 any = A_arbace_go_check_A_const_337; if linked_4444 == nil { tmp57 = ifn_4445.Invoke_O_O__O(arg_4446, arg_4447) } else { tmp57 = linked_4444.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4443, arg_4446, arg_4447) }; tmp55.Invoke_O_O__O(Lit_28, tmp56.Invoke_O__O(tmp57))
//line :675:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_A_New() *A_arbace_go_check_annotations_iter__1685000490__1685000496_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_A) Ctor() {}
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_A) Invoke_O_O__O(self, s__1685000491__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_New_O_O(s__1685000491__1, self); var tmp2 *jrt.Class; var fncls__4234 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class; if fncls__4234 == nil { var fncls__4234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class = fncls__4234d; tmp2 = fncls__4234d } else { tmp2 = fncls__4234 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A{}; t.Ctor_O_O(p0, p1); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A) Ctor_O_O(c__s__1685000491, c__iter__1685000490 any) { t.F_s__1685000491 = c__s__1685000491; t.F_iter__1685000490 = c__iter__1685000490 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A) Invoke_O__O(self any) any { { var s__1685000491__1 any; var t_ any = t.F_s__1685000491; t.F_s__1685000491 = nil; s__1685000491__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4150 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4152 lang.IFn; if linked_4151 == nil { ifn_4152 = lang.IFn_Cast(root_4150) } else { ifn_4152 = nil }; var arg_4153 any = s__1685000491__1; if linked_4151 == nil { temp__1927000414__auto____2 = ifn_4152.Invoke_O__O(arg_4153) } else { temp__1927000414__auto____2 = linked_4151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4150, arg_4153) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_4154 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4154, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4156 lang.IFn; if linked_4155 == nil { ifn_4156 = lang.IFn_Cast(root_4154) } else { ifn_4156 = nil }; var arg_4157 any = xs__1927001018__auto____3; if linked_4155 == nil { r__4 = ifn_4156.Invoke_O__O(arg_4157) } else { r__4 = linked_4155.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4154, arg_4157) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__4216 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class; if fncls__4216 == nil { var fncls__4216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class = fncls__4216d; tmp2 = fncls__4216d } else { tmp2 = fncls__4216 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_4217 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4219 lang.IFn; if linked_4218 == nil { ifn_4219 = lang.IFn_Cast(root_4217) } else { ifn_4219 = nil }; var arg_4220 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_167.Invoke_O__O(r__4)); if linked_4218 == nil { fs__1927001036__auto____6 = ifn_4219.Invoke_O__O(arg_4220) } else { fs__1927001036__auto____6 = linked_4218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4217, arg_4220) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_4221 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var linked_4222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4221, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4223 lang.IFn; if linked_4222 == nil { ifn_4223 = lang.IFn_Cast(root_4221) } else { ifn_4223 = nil }; var arg_4224 any = fs__1927001036__auto____6; var arg_4225 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000490); var tmp4 any; var root_4226 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4226, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4228 lang.IFn; if linked_4227 == nil { ifn_4228 = lang.IFn_Cast(root_4226) } else { ifn_4228 = nil }; var arg_4229 any = s__1685000491__1; if linked_4227 == nil { tmp4 = ifn_4228.Invoke_O__O(arg_4229) } else { tmp4 = linked_4227.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4226, arg_4229) }; arg_4225 = tmp3.Invoke_O__O(tmp4); if linked_4222 == nil { return ifn_4223.Invoke_O_O__O(arg_4224, arg_4225) } else { return linked_4222.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4221, arg_4224, arg_4225) } } else { var tmp5 any; var root_4230 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4230, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4232 lang.IFn; if linked_4231 == nil { ifn_4232 = lang.IFn_Cast(root_4230) } else { ifn_4232 = nil }; var arg_4233 any = s__1685000491__1; if linked_4231 == nil { tmp5 = ifn_4232.Invoke_O__O(arg_4233) } else { tmp5 = linked_4231.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4230, arg_4233) }; s__1685000491__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A{}; t.Ctor_O(p0); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A) Invoke_O_O__O(self, s__1685000493__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_New_O_O_O(t.F_r, s__1685000493__1, self); var tmp2 *jrt.Class; var fncls__4215 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class; if fncls__4215 == nil { var fncls__4215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class = fncls__4215d; tmp2 = fncls__4215d } else { tmp2 = fncls__4215 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A) Ctor_O_O_O(c__r, c__s__1685000493, c__iter__1685000492 any) { t.F_r = c__r; t.F_s__1685000493 = c__s__1685000493; t.F_iter__1685000492 = c__iter__1685000492 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A) Invoke_O__O(self any) any { { var s__1685000493__1 any; var t_ any = t.F_s__1685000493; t.F_s__1685000493 = nil; s__1685000493__1 = t_; for { var temp__1927000414__auto____2 any; var root_4158 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4158, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4160 lang.IFn; if linked_4159 == nil { ifn_4160 = lang.IFn_Cast(root_4158) } else { ifn_4160 = nil }; var arg_4161 any = s__1685000493__1; if linked_4159 == nil { temp__1927000414__auto____2 = ifn_4160.Invoke_O__O(arg_4161) } else { temp__1927000414__auto____2 = linked_4159.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4158, arg_4161) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000493__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4162 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4162, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4164 lang.IFn; if linked_4163 == nil { ifn_4164 = lang.IFn_Cast(root_4162) } else { ifn_4164 = nil }; var arg_4165 any = s__1685000493__3; if linked_4163 == nil { tmp1 = ifn_4164.Invoke_O__O(arg_4165) } else { tmp1 = linked_4163.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4162, arg_4165) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4166 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4166, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4168 lang.IFn; if linked_4167 == nil { ifn_4168 = lang.IFn_Cast(root_4166) } else { ifn_4168 = nil }; var arg_4169 any = s__1685000493__3; if linked_4167 == nil { c__1927001037__auto____4 = ifn_4168.Invoke_O__O(arg_4169) } else { c__1927001037__auto____4 = linked_4167.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4166, arg_4169) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000495__6 any; var root_4170 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4170, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4172 lang.IFn; if linked_4171 == nil { ifn_4172 = lang.IFn_Cast(root_4170) } else { ifn_4172 = nil }; var arg_4173 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4171 == nil { b__1685000495__6 = ifn_4172.Invoke_O__O(arg_4173) } else { b__1685000495__6 = linked_4171.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4170, arg_4173) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000495__6); var tmp3 *jrt.Class; var fncls__4179 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class; if fncls__4179 == nil { var fncls__4179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class = fncls__4179d; tmp3 = fncls__4179d } else { tmp3 = fncls__4179 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4180 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4180, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4182 lang.IFn; if linked_4181 == nil { ifn_4182 = lang.IFn_Cast(root_4180) } else { ifn_4182 = nil }; var arg_4183 any; var root_4185 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4185, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4187 lang.IFn; if linked_4186 == nil { ifn_4187 = lang.IFn_Cast(root_4185) } else { ifn_4187 = nil }; var arg_4188 any = b__1685000495__6; if linked_4186 == nil { arg_4183 = ifn_4187.Invoke_O__O(arg_4188) } else { arg_4183 = linked_4186.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4185, arg_4188) }; var arg_4184 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000492); var tmp5 any; var root_4189 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4189, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4191 lang.IFn; if linked_4190 == nil { ifn_4191 = lang.IFn_Cast(root_4189) } else { ifn_4191 = nil }; var arg_4192 any = s__1685000493__3; if linked_4190 == nil { tmp5 = ifn_4191.Invoke_O__O(arg_4192) } else { tmp5 = linked_4190.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4189, arg_4192) }; arg_4184 = tmp4.Invoke_O__O(tmp5); if linked_4181 == nil { return ifn_4182.Invoke_O_O__O(arg_4183, arg_4184) } else { return linked_4181.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4180, arg_4183, arg_4184) } } else { var root_4193 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4193, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4195 lang.IFn; if linked_4194 == nil { ifn_4195 = lang.IFn_Cast(root_4193) } else { ifn_4195 = nil }; var arg_4196 any; var root_4198 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4198, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4200 lang.IFn; if linked_4199 == nil { ifn_4200 = lang.IFn_Cast(root_4198) } else { ifn_4200 = nil }; var arg_4201 any = b__1685000495__6; if linked_4199 == nil { arg_4196 = ifn_4200.Invoke_O__O(arg_4201) } else { arg_4196 = linked_4199.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4198, arg_4201) }; var arg_4197 any; if linked_4194 == nil { return ifn_4195.Invoke_O_O__O(arg_4196, arg_4197) } else { return linked_4194.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4193, arg_4196, arg_4197) } } } else { var u__4 any; var root_4202 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4202, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4204 lang.IFn; if linked_4203 == nil { ifn_4204 = lang.IFn_Cast(root_4202) } else { ifn_4204 = nil }; var arg_4205 any = s__1685000493__3; if linked_4203 == nil { u__4 = ifn_4204.Invoke_O__O(arg_4205) } else { u__4 = linked_4203.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4202, arg_4205) }; var root_4206 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4206, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4208 lang.IFn; if linked_4207 == nil { ifn_4208 = lang.IFn_Cast(root_4206) } else { ifn_4208 = nil }; var arg_4209 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), u__4); var arg_4210 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000492); var tmp7 any; var root_4211 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4211, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4213 lang.IFn; if linked_4212 == nil { ifn_4213 = lang.IFn_Cast(root_4211) } else { ifn_4213 = nil }; var arg_4214 any = s__1685000493__3; if linked_4212 == nil { tmp7 = ifn_4213.Invoke_O__O(arg_4214) } else { tmp7 = linked_4212.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4211, arg_4214) }; arg_4210 = tmp6.Invoke_O__O(tmp7); if linked_4207 == nil { return ifn_4208.Invoke_O_O__O(arg_4209, arg_4210) } else { return linked_4207.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4206, arg_4209, arg_4210) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000495 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000495 = c__b__1685000495 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A) Invoke_O__O(self any) any { { var i__1685000494__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000494__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000494__1)); var root_4174 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4174, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4176 lang.IFn; if linked_4175 == nil { ifn_4176 = lang.IFn_Cast(root_4174) } else { ifn_4176 = nil }; var arg_4177 any = t.F_b__1685000495; var arg_4178 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), u__2); if linked_4175 == nil { ifn_4176.Invoke_O_O__O(arg_4177, arg_4178) } else { linked_4175.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4174, arg_4177, arg_4178) }; i__1685000494__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000494__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :687:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :687:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000511__2 any = args__0; var seq__1685000512__3 any; var root_4448 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4448, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4450 lang.IFn; if


	linked_4449 == nil { ifn_4450 = lang.IFn_Cast(root_4448) } else { ifn_4450 = nil }; var arg_4451 any = vec__1685000511__2; if linked_4449 == nil { seq__1685000512__3 = ifn_4450.Invoke_O__O(arg_4451) } else { seq__1685000512__3 = linked_4449.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4448, arg_4451) }; var first__1685000513__4 any; var root_4452 any = /*line :687:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4452, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4454 lang.IFn; if


	linked_4453 == nil { ifn_4454 = lang.IFn_Cast(root_4452) } else { ifn_4454 = nil }; var arg_4455 any = seq__1685000512__3; if linked_4453 == nil { first__1685000513__4 = ifn_4454.Invoke_O__O(arg_4455) } else { first__1685000513__4 = linked_4453.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4452, arg_4455) }; var seq__1685000512__5 any; var root_4456 any = /*line :687:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4456, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4458 lang.IFn; if


	linked_4457 == nil { ifn_4458 = lang.IFn_Cast(root_4456) } else { ifn_4458 = nil }; var arg_4459 any = seq__1685000512__3; if linked_4457 == nil { seq__1685000512__5 = ifn_4458.Invoke_O__O(arg_4459) } else { seq__1685000512__5 = linked_4457.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4456, arg_4459) }; var cmd__6 any = first__1685000513__4; var args__7 any = seq__1685000512__5; var G__1685000514__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000514__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000514__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000515_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4551 /*line :691:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000515_A_fn_class

		if fncls__4551 == nil { var fncls__4551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000515_A_fn_class = fncls__4551d; tmp2 = fncls__4551d } else { tmp2 = fncls__4551 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :691:1
		var cs__10 any; var tmp3 any; var root_4552 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4552, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4554 lang.IFn











		if linked_4553 == nil { ifn_4554 = lang.IFn_Cast(root_4552) } else { ifn_4554 = nil }; var arg_4555 any = A_arbace_go_check_A_const_393.Invoke_O__O(opts__9); if linked_4553 == nil { tmp3 = ifn_4554.Invoke_O__O(arg_4555) } else { tmp3 = linked_4553.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4552, arg_4555) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_393.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_396.GetRawRoot__O() }
//line :691:1
		var ok__11 any; var root_4638 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_4639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4638, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4640 lang.IFn












		if linked_4639 == nil { ifn_4640 = lang.IFn_Cast(root_4638) } else { ifn_4640 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_285; var tmp6 any = A_arbace_go_check_A_const_164.Invoke_O__O(opts__9); var tmp7 any = A_arbace_go_check_A_const_363; var arg_4641 any = tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, A_arbace_go_check_A_const_395.Invoke_O__O(opts__9)); if linked_4639 == nil { ifn_4640.Invoke_O__O(arg_4641) } else { linked_4639.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4638, arg_4641) }; var tmp8 any = A_arbace_go_check__main_fn__1685000518_A_New_O_O(cs__10, opts__9); var tmp9 *jrt.Class; var fncls__4632 *jrt.Class = A_arbace_go_check__main_fn__1685000518_A_fn_class; if fncls__4632 == nil { var fncls__4632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_fn__1685000518_A_fn_class = fncls__4632d; tmp9 = fncls__4632d } else { tmp9 = fncls__4632 }; ok__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()


		var root_4649 any = A_arbace_go_check_A_const_400.GetRawRoot__O(); var linked_4650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4649, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4651 lang.IFn; if linked_4650 == nil { ifn_4651 = lang.IFn_Cast(root_4649) } else { ifn_4651 = nil }; if linked_4650 == nil { ifn_4651.Invoke__O() } else { linked_4650.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4649) }
		var tmp10 int64; var tmp11 any; var root_4633 any = A_arbace_go_check_A_const_398.GetRawRoot__O(); var linked_4634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4633, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4635 lang.IFn; if linked_4634 == nil { ifn_4635 = lang.IFn_Cast(root_4633) } else { ifn_4635 = nil }; var arg_4636 any = A_arbace_go_check_A_const_399.GetRawRoot__O(); var arg_4637 any = ok__11; if linked_4634 == nil { tmp11 = ifn_4635.Invoke_O_O__O(arg_4636, arg_4637) } else { tmp11 = linked_4634.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4633, arg_4636, arg_4637) }; if jrt.J2g_Truth(tmp11) { tmp10 = 0 } else { tmp10 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp10)); return nil }
//line :691:1
	default:};

















	lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :693:1
func A_arbace_go_check__main_fn__1685000515_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000515_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000515_A{}; t.Ctor_O(p0); return t }
//line :693:1
func (t *A_arbace_go_check__main_fn__1685000515_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :693:1
func (t *A_arbace_go_check__main_fn__1685000515_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_364; var tmp2 any = A_arbace_go_check_A_const_392; var tmp3 any = A_arbace_go_check_A_const_366; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_393, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_4461 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_4462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4461, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4463 lang.IFn; if linked_4462 == nil { ifn_4463 = lang.IFn_Cast(root_4461) } else { ifn_4463 = nil }; var arg_4464 any = as__1; if linked_4462 == nil { tmp4 = ifn_4463.Invoke_O__O(arg_4464) } else { tmp4 = linked_4462.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4461, arg_4464) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000516__3_ any; var root_4465 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4465, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4467 lang.IFn

		if linked_4466 == nil { ifn_4467 = lang.IFn_Cast(root_4465) } else { ifn_4467 = nil }; var arg_4468 any = as__1; if linked_4466 == nil { G__1685000516__3_ = ifn_4467.Invoke_O__O(arg_4468) } else { G__1685000516__3_ = linked_4466.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4465, arg_4468) }; switch lang.Util_Hash_O__I_NoInit(G__1685000516__3_) >> 10 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_6) {



			var tmp5 any; var root_4470 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4470, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4472 lang.IFn; if linked_4471 == nil { ifn_4472 = lang.IFn_Cast(root_4470) } else { ifn_4472 = nil }; var arg_4473 any = as__1; if linked_4471 == nil { tmp5 = ifn_4472.Invoke_O__O(arg_4473) } else { tmp5 = linked_4471.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4470, arg_4473) }; var tmp6 any = tmp5; var tmp7 any; var root_4474 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4474, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4476 lang.IFn; if linked_4475 == nil { ifn_4476 = lang.IFn_Cast(root_4474) } else { ifn_4476 = nil }; var arg_4477 any = o__2; var arg_4478 any = A_arbace_go_check_A_const_164; var arg_4479 any; var root_4480 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4480, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4482 lang.IFn; if linked_4481 == nil { ifn_4482 = lang.IFn_Cast(root_4480) } else { ifn_4482 = nil }; var arg_4483 any = as__1; if linked_4481 == nil { arg_4479 = ifn_4482.Invoke_O__O(arg_4483) } else { arg_4479 = linked_4481.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4480, arg_4483) }; if linked_4475 == nil { tmp7 = ifn_4476.Invoke_O_O_O__O(arg_4477, arg_4478, arg_4479) } else { tmp7 = linked_4475.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4474, arg_4477, arg_4478, arg_4479) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :696:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_7) {




			var tmp8 any; var root_4484 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4484, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4486 lang.IFn; if linked_4485 == nil { ifn_4486 = lang.IFn_Cast(root_4484) } else { ifn_4486 = nil }; var arg_4487 any = as__1; if linked_4485 == nil { tmp8 = ifn_4486.Invoke_O__O(arg_4487) } else { tmp8 = linked_4485.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4484, arg_4487) }; var tmp9 any = tmp8; var tmp10 any; var root_4488 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4488, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4490 lang.IFn; if linked_4489 == nil { ifn_4490 = lang.IFn_Cast(root_4488) } else { ifn_4490 = nil }; var arg_4491 any = o__2; var arg_4492 any = A_arbace_go_check_A_const_395; var arg_4493 any; var root_4494 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4494, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4496 lang.IFn; if linked_4495 == nil { ifn_4496 = lang.IFn_Cast(root_4494) } else { ifn_4496 = nil }; var arg_4497 any = as__1; if linked_4495 == nil { arg_4493 = ifn_4496.Invoke_O__O(arg_4497) } else { arg_4493 = linked_4495.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4494, arg_4497) }; if linked_4489 == nil { tmp10 = ifn_4490.Invoke_O_O_O__O(arg_4491, arg_4492, arg_4493) } else { tmp10 = linked_4489.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4488, arg_4491, arg_4492, arg_4493) }; as__1, o__2 = tmp9, tmp10; continue L1 }
//line :696:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_8) {

			var tmp11 any; var root_4498 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4498, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4500 lang.IFn; if linked_4499 == nil { ifn_4500 = lang.IFn_Cast(root_4498) } else { ifn_4500 = nil }; var arg_4501 any = as__1; if linked_4499 == nil { tmp11 = ifn_4500.Invoke_O__O(arg_4501) } else { tmp11 = linked_4499.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4498, arg_4501) }; var tmp12 any = tmp11; var tmp13 any; var root_4502 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4503 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4502, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4504 lang.IFn; if linked_4503 == nil { ifn_4504 = lang.IFn_Cast(root_4502) } else { ifn_4504 = nil }; var arg_4505 any = o__2; var arg_4506 any = A_arbace_go_check_A_const_364; var arg_4507 any; var tmp14 any; var root_4508 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4508, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4510 lang.IFn; if linked_4509 == nil { ifn_4510 = lang.IFn_Cast(root_4508) } else { ifn_4510 = nil }; var arg_4511 any = as__1; if linked_4509 == nil { tmp14 = ifn_4510.Invoke_O__O(arg_4511) } else { tmp14 = linked_4509.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4508, arg_4511) }; arg_4507 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp14))).Ref(); if linked_4503 == nil { tmp13 = ifn_4504.Invoke_O_O_O__O(arg_4505, arg_4506, arg_4507) } else { tmp13 = linked_4503.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4502, arg_4505, arg_4506, arg_4507) }; as__1, o__2 = tmp12, tmp13; continue L1 }
//line :696:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_9) {
			var tmp15 any; var root_4512 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4512, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4514 lang.IFn; if linked_4513 == nil { ifn_4514 = lang.IFn_Cast(root_4512) } else { ifn_4514 = nil }; var arg_4515 any = as__1; if linked_4513 == nil { tmp15 = ifn_4514.Invoke_O__O(arg_4515) } else { tmp15 = linked_4513.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4512, arg_4515) }; var tmp16 any = tmp15; var tmp17 any; var root_4516 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4516, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4518 lang.IFn; if linked_4517 == nil { ifn_4518 = lang.IFn_Cast(root_4516) } else { ifn_4518 = nil }; var arg_4519 any = o__2; var arg_4520 any = A_arbace_go_check_A_const_365; var arg_4521 any = jrt.Boolean_TRUE.Ref(); if linked_4517 == nil { tmp17 = ifn_4518.Invoke_O_O_O__O(arg_4519, arg_4520, arg_4521) } else { tmp17 = linked_4517.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4516, arg_4519, arg_4520, arg_4521) }; as__1, o__2 = tmp16, tmp17; continue L1 }
//line :696:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_10) {


			var tmp18 any; var root_4522 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4522, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4524 lang.IFn; if linked_4523 == nil { ifn_4524 = lang.IFn_Cast(root_4522) } else { ifn_4524 = nil }; var arg_4525 any = as__1; if linked_4523 == nil { tmp18 = ifn_4524.Invoke_O__O(arg_4525) } else { tmp18 = linked_4523.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4522, arg_4525) }; var tmp19 any = tmp18; var tmp20 any; var root_4526 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4526, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4528 lang.IFn; if linked_4527 == nil { ifn_4528 = lang.IFn_Cast(root_4526) } else { ifn_4528 = nil }; var arg_4529 any = o__2; var arg_4530 any = A_arbace_go_check_A_const_366; var arg_4531 any; var root_4532 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4532, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4534 lang.IFn; if linked_4533 == nil { ifn_4534 = lang.IFn_Cast(root_4532) } else { ifn_4534 = nil }; var arg_4535 any = as__1; if linked_4533 == nil { arg_4531 = ifn_4534.Invoke_O__O(arg_4535) } else { arg_4531 = linked_4533.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4532, arg_4535) }; if linked_4527 == nil { tmp20 = ifn_4528.Invoke_O_O_O__O(arg_4529, arg_4530, arg_4531) } else { tmp20 = linked_4527.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4526, arg_4529, arg_4530, arg_4531) }; as__1, o__2 = tmp19, tmp20; continue L1 }
//line :696:1
		default:
		}




		var tmp21 any; var root_4536 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4536, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4538 lang.IFn; if linked_4537 == nil { ifn_4538 = lang.IFn_Cast(root_4536) } else { ifn_4538 = nil }; var arg_4539 any = as__1; if linked_4537 == nil { tmp21 = ifn_4538.Invoke_O__O(arg_4539) } else { tmp21 = linked_4537.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4536, arg_4539) }; var tmp22 any = tmp21; var tmp23 any; var root_4540 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4540, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4542 lang.IFn; if linked_4541 == nil { ifn_4542 = lang.IFn_Cast(root_4540) } else { ifn_4542 = nil }; var arg_4543 any = o__2; var arg_4544 any = A_arbace_go_check_A_const_393; var arg_4545 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4546 any; var root_4547 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4547, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4549 lang.IFn; if linked_4548 == nil { ifn_4549 = lang.IFn_Cast(root_4547) } else { ifn_4549 = nil }; var arg_4550 any = as__1; if linked_4548 == nil { arg_4546 = ifn_4549.Invoke_O__O(arg_4550) } else { arg_4546 = linked_4548.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4547, arg_4550) }; if linked_4541 == nil { tmp23 = ifn_4542.Invoke_O_O_O_O__O(arg_4543, arg_4544, arg_4545, arg_4546) } else { tmp23 = linked_4541.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4540, arg_4543, arg_4544, arg_4545, arg_4546) }; as__1, o__2 = tmp22, tmp23; continue L1 } } }; /*line :693:1*/panic("j2g: unreachable") }










func A_arbace_go_check__main_fn__1685000518_A_New_O_O(p0, p1 any) *A_arbace_go_check__main_fn__1685000518_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_A{}; t.Ctor_O_O(p0, p1); return t }
//line :704:1
func (t *A_arbace_go_check__main_fn__1685000518_A) Ctor_O_O(c__cs, c__opts any) { t.F_cs = c__cs; t.F_opts = c__opts }
//line :704:1
func (t *A_arbace_go_check__main_fn__1685000518_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_4556 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_4557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4556, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4558 lang.IFn; if linked_4557 == nil { ifn_4558 = lang.IFn_Cast(root_4556) } else { ifn_4558 = nil }; var arg_4559 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_New_O(t.F_opts); var tmp3 *jrt.Class; var fncls__4628 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class; if fncls__4628 == nil { var fncls__4628d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class = fncls__4628d; tmp3 = fncls__4628d } else { tmp3 = fncls__4628 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var t_ any = t.F_cs; t.F_cs = nil; tmp5 = t_; arg_4559 = tmp4.Invoke_O__O(tmp5); if linked_4557 == nil { tmp1 = ifn_4558.Invoke_O__O(arg_4559) } else { tmp1 = linked_4557.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4556, arg_4559) } }
//line :704:1
	return nil }(); var root_4629 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4629, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4631 lang.IFn; if linked_4630 == nil { ifn_4631 = lang.IFn_Cast(root_4629) } else { ifn_4631 = nil }; if linked_4630 == nil { ifn_4631.Invoke__O() } else { linked_4630.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4629) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }

func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A{}; t.Ctor_O(p0); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A) Invoke_O_O__O(self, s__1685000520__1 any) any { var tmp1 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_New_O_O_O(self, t.F_opts, s__1685000520__1); var tmp2 *jrt.Class; var fncls__4627 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class; if fncls__4627 == nil { var fncls__4627d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class = fncls__4627d; tmp2 = fncls__4627d } else { tmp2 = fncls__4627 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :706:1
func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A) Ctor_O_O_O(c__iter__1685000519, c__opts, c__s__1685000520 any) { t.F_iter__1685000519 = c__iter__1685000519; t.F_opts = c__opts; t.F_s__1685000520 = c__s__1685000520 }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A) Invoke_O__O(self any) any { { var s__1685000520__1 any; var t_ any = t.F_s__1685000520; t.F_s__1685000520 = nil; s__1685000520__1 = t_; for { var temp__1927000414__auto____2 any; var root_4560 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4560, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4562 lang.IFn; if linked_4561 == nil { ifn_4562 = lang.IFn_Cast(root_4560) } else { ifn_4562 = nil }; var arg_4563 any = s__1685000520__1; if linked_4561 == nil { temp__1927000414__auto____2 = ifn_4562.Invoke_O__O(arg_4563) } else { temp__1927000414__auto____2 = linked_4561.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4560, arg_4563) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000520__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4564 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4564, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4566 lang.IFn; if linked_4565 == nil { ifn_4566 = lang.IFn_Cast(root_4564) } else { ifn_4566 = nil }; var arg_4567 any = s__1685000520__3; if linked_4565 == nil { tmp1 = ifn_4566.Invoke_O__O(arg_4567) } else { tmp1 = linked_4565.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4564, arg_4567) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4568 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4568, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4570 lang.IFn; if linked_4569 == nil { ifn_4570 = lang.IFn_Cast(root_4568) } else { ifn_4570 = nil }; var arg_4571 any = s__1685000520__3; if linked_4569 == nil { c__1927001037__auto____4 = ifn_4570.Invoke_O__O(arg_4571) } else { c__1927001037__auto____4 = linked_4569.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4568, arg_4571) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000522__6 any; var root_4572 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4572, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4574 lang.IFn; if linked_4573 == nil { ifn_4574 = lang.IFn_Cast(root_4572) } else { ifn_4574 = nil }; var arg_4575 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4573 == nil { b__1685000522__6 = ifn_4574.Invoke_O__O(arg_4575) } else { b__1685000522__6 = linked_4573.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4572, arg_4575) }; var tmp2 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_New_O_O_I_O(b__1685000522__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4586 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class; if fncls__4586 == nil { var fncls__4586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class = fncls__4586d; tmp3 = fncls__4586d } else { tmp3 = fncls__4586 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4587 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4587, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4589 lang.IFn; if linked_4588 == nil { ifn_4589 = lang.IFn_Cast(root_4587) } else { ifn_4589 = nil }; var arg_4590 any; var root_4592 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4592, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4594 lang.IFn; if linked_4593 == nil { ifn_4594 = lang.IFn_Cast(root_4592) } else { ifn_4594 = nil }; var arg_4595 any = b__1685000522__6; if linked_4593 == nil { arg_4590 = ifn_4594.Invoke_O__O(arg_4595) } else { arg_4590 = linked_4593.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4592, arg_4595) }; var arg_4591 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000519); var tmp5 any; var root_4596 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4596, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4598 lang.IFn; if linked_4597 == nil { ifn_4598 = lang.IFn_Cast(root_4596) } else { ifn_4598 = nil }; var arg_4599 any = s__1685000520__3; if linked_4597 == nil { tmp5 = ifn_4598.Invoke_O__O(arg_4599) } else { tmp5 = linked_4597.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4596, arg_4599) }; arg_4591 = tmp4.Invoke_O__O(tmp5); if linked_4588 == nil { return ifn_4589.Invoke_O_O__O(arg_4590, arg_4591) } else { return linked_4588.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4587, arg_4590, arg_4591) } } else { var root_4600 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4600, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4602 lang.IFn; if linked_4601 == nil { ifn_4602 = lang.IFn_Cast(root_4600) } else { ifn_4602 = nil }; var arg_4603 any; var root_4605 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4605, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4607 lang.IFn; if linked_4606 == nil { ifn_4607 = lang.IFn_Cast(root_4605) } else { ifn_4607 = nil }; var arg_4608 any = b__1685000522__6; if linked_4606 == nil { arg_4603 = ifn_4607.Invoke_O__O(arg_4608) } else { arg_4603 = linked_4606.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4605, arg_4608) }; var arg_4604 any; if linked_4601 == nil { return ifn_4602.Invoke_O_O__O(arg_4603, arg_4604) } else { return linked_4601.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4600, arg_4603, arg_4604) } } } else { var c__4 any; var root_4609 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4611 lang.IFn; if linked_4610 == nil { ifn_4611 = lang.IFn_Cast(root_4609) } else { ifn_4611 = nil }; var arg_4612 any = s__1685000520__3; if linked_4610 == nil { c__4 = ifn_4611.Invoke_O__O(arg_4612) } else { c__4 = linked_4610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4609, arg_4612) }; var root_4613 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4613, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4615 lang.IFn; if linked_4614 == nil { ifn_4615 = lang.IFn_Cast(root_4613) } else { ifn_4615 = nil }; var arg_4616 any; var root_4618 any = A_arbace_go_check_A_const_397.GetRawRoot__O(); var linked_4619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4618, A_arbace_go_check_annotations_A_fn_class); var ifn_4620 lang.IFn; if linked_4619 == nil { ifn_4620 = lang.IFn_Cast(root_4618) } else { ifn_4620 = nil }; var arg_4621 any = c__4; var arg_4622 any = t.F_opts; if linked_4619 == nil { arg_4616 = ifn_4620.Invoke_O_O__O(arg_4621, arg_4622) } else { arg_4616 = linked_4619.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4618, arg_4621, arg_4622) }; var arg_4617 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000519); var tmp7 any; var root_4623 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4623, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4625 lang.IFn; if linked_4624 == nil { ifn_4625 = lang.IFn_Cast(root_4623) } else { ifn_4625 = nil }; var arg_4626 any = s__1685000520__3; if linked_4624 == nil { tmp7 = ifn_4625.Invoke_O__O(arg_4626) } else { tmp7 = linked_4624.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4623, arg_4626) }; arg_4617 = tmp6.Invoke_O__O(tmp7); if linked_4614 == nil { return ifn_4615.Invoke_O_O__O(arg_4616, arg_4617) } else { return linked_4614.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4613, arg_4616, arg_4617) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :706:1
func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A) Ctor_O_O_I_O(c__b__1685000522, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000522 = c__b__1685000522; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A) Invoke_O__O(self any) any { { var i__1685000521__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000521__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000521__1)); var root_4576 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4576, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4578 lang.IFn; if linked_4577 == nil { ifn_4578 = lang.IFn_Cast(root_4576) } else { ifn_4578 = nil }; var arg_4579 any = t.F_b__1685000522; var arg_4580 any; var root_4581 any = A_arbace_go_check_A_const_397.GetRawRoot__O(); var linked_4582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4581, A_arbace_go_check_annotations_A_fn_class); var ifn_4583 lang.IFn; if linked_4582 == nil { ifn_4583 = lang.IFn_Cast(root_4581) } else { ifn_4583 = nil }; var arg_4584 any = c__2; var arg_4585 any = t.F_opts; if linked_4582 == nil { arg_4580 = ifn_4583.Invoke_O_O__O(arg_4584, arg_4585) } else { arg_4580 = linked_4582.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4581, arg_4584, arg_4585) }; if linked_4577 == nil { ifn_4578.Invoke_O_O__O(arg_4579, arg_4580) } else { linked_4577.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4576, arg_4579, arg_4580) }; i__1685000521__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000521__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Var

var A_arbace_go_check_A_const_55 *lang.Keyword

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Var

var A_arbace_go_check_A_const_61 *lang.Keyword

var A_arbace_go_check_A_const_62 *lang.Var

var A_arbace_go_check_A_const_63 *lang.Keyword

var A_arbace_go_check_A_const_64 *lang.Var

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Keyword

var A_arbace_go_check_A_const_67 *lang.Var

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Keyword

var A_arbace_go_check_A_const_73 *lang.Var

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Keyword

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 *lang.Var

var A_arbace_go_check_A_const_78 any

var A_arbace_go_check_A_const_79 *lang.Keyword

var A_arbace_go_check_A_const_80 *lang.Var

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Keyword

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Var

var A_arbace_go_check_A_const_90 *lang.Keyword

var A_arbace_go_check_A_const_91 *lang.Var

var A_arbace_go_check_A_const_92 *lang.Keyword

var A_arbace_go_check_A_const_93 *lang.Var

var A_arbace_go_check_A_const_94 *lang.Keyword

var A_arbace_go_check_A_const_95 any

var A_arbace_go_check_A_const_96 *lang.Keyword

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 *lang.Var

var A_arbace_go_check_A_const_99 any

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Keyword

var A_arbace_go_check_A_const_102 *lang.Var

var A_arbace_go_check_A_const_103 *lang.Var

var A_arbace_go_check_A_const_104 *lang.Var

var A_arbace_go_check_A_const_105 *lang.Var

var A_arbace_go_check_A_const_106 *lang.Var

var A_arbace_go_check_A_const_107 *lang.Keyword

var A_arbace_go_check_A_const_108 *lang.Var

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Keyword

var A_arbace_go_check_A_const_113 *lang.Keyword

var A_arbace_go_check_A_const_114 *lang.Var

var A_arbace_go_check_A_const_115 *lang.Keyword

var A_arbace_go_check_A_const_116 *lang.Keyword

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Keyword

var A_arbace_go_check_A_const_119 *lang.Keyword

var A_arbace_go_check_A_const_120 *lang.Keyword

var A_arbace_go_check_A_const_121 *lang.Keyword

var A_arbace_go_check_A_const_122 *lang.Keyword

var A_arbace_go_check_A_const_123 *lang.Var

var A_arbace_go_check_A_const_124 *lang.Var

var A_arbace_go_check_A_const_125 *lang.Keyword

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Var

var A_arbace_go_check_A_const_128 *lang.Keyword

var A_arbace_go_check_A_const_129 *lang.Var

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Var

var A_arbace_go_check_A_const_133 any

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 any

var A_arbace_go_check_A_const_138 any

var A_arbace_go_check_A_const_139 *lang.Var

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 *lang.Keyword

var A_arbace_go_check_A_const_142 any

var A_arbace_go_check_A_const_143 *lang.Var

var A_arbace_go_check_A_const_144 *lang.Var

var A_arbace_go_check_A_const_145 *lang.Keyword

var A_arbace_go_check_A_const_146 *lang.Keyword

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Keyword

var A_arbace_go_check_A_const_151 *lang.Var

var A_arbace_go_check_A_const_152 *lang.Var

var A_arbace_go_check_A_const_153 *lang.Keyword

var A_arbace_go_check_A_const_154 *lang.Var

var A_arbace_go_check_A_const_155 *lang.Keyword

var A_arbace_go_check_A_const_156 *lang.Keyword

var A_arbace_go_check_A_const_157 *lang.Keyword

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Var

var A_arbace_go_check_A_const_164 *lang.Keyword

var A_arbace_go_check_A_const_165 *lang.Keyword

var A_arbace_go_check_A_const_166 *lang.Keyword

var A_arbace_go_check_A_const_167 *lang.Keyword

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Var

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Var

var A_arbace_go_check_A_const_197 *lang.Var

var A_arbace_go_check_A_const_198 *lang.Keyword

var A_arbace_go_check_A_const_199 *lang.Keyword

var A_arbace_go_check_A_const_200 *lang.Keyword

var A_arbace_go_check_A_const_201 *lang.Keyword

var A_arbace_go_check_A_const_202 *lang.Var

var A_arbace_go_check_A_const_203 *lang.Var

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Keyword

var A_arbace_go_check_A_const_206 *lang.Var

var A_arbace_go_check_A_const_207 *lang.Var

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Var

var A_arbace_go_check_A_const_210 *lang.Keyword

var A_arbace_go_check_A_const_211 *lang.Var

var A_arbace_go_check_A_const_212 *lang.Keyword

var A_arbace_go_check_A_const_213 *lang.Var

var A_arbace_go_check_A_const_214 *lang.Var

var A_arbace_go_check_A_const_215 *lang.Keyword

var A_arbace_go_check_A_const_216 *lang.Keyword

var A_arbace_go_check_A_const_217 *lang.Var

var A_arbace_go_check_A_const_218 *lang.Keyword

var A_arbace_go_check_A_const_219 *lang.Var

var A_arbace_go_check_A_const_220 *lang.Var

var A_arbace_go_check_A_const_221 *lang.Var

var A_arbace_go_check_A_const_222 *lang.Var

var A_arbace_go_check_A_const_223 *lang.Keyword

var A_arbace_go_check_A_const_224 *lang.Var

var A_arbace_go_check_A_const_225 *lang.Var

var A_arbace_go_check_A_const_226 *lang.Keyword

var A_arbace_go_check_A_const_227 *lang.Keyword

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Keyword

var A_arbace_go_check_A_const_230 *lang.Var

var A_arbace_go_check_A_const_231 *lang.Var

var A_arbace_go_check_A_const_232 *lang.Keyword

var A_arbace_go_check_A_const_233 *lang.Keyword

var A_arbace_go_check_A_const_234 *lang.Keyword

var A_arbace_go_check_A_const_235 *lang.Var

var A_arbace_go_check_A_const_236 *lang.Var

var A_arbace_go_check_A_const_237 *lang.Keyword

var A_arbace_go_check_A_const_238 *lang.Keyword

var A_arbace_go_check_A_const_239 *lang.Var

var A_arbace_go_check_A_const_240 *lang.Var

var A_arbace_go_check_A_const_241 *lang.Keyword

var A_arbace_go_check_A_const_242 *lang.Keyword

var A_arbace_go_check_A_const_243 *lang.Keyword

var A_arbace_go_check_A_const_244 *lang.Keyword

var A_arbace_go_check_A_const_245 *lang.Var

var A_arbace_go_check_A_const_246 any

var A_arbace_go_check_A_const_247 any

var A_arbace_go_check_A_const_248 *lang.Keyword

var A_arbace_go_check_A_const_249 *lang.Keyword

var A_arbace_go_check_A_const_250 *lang.Var

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 any

var A_arbace_go_check_A_const_253 any

var A_arbace_go_check_A_const_254 *lang.Keyword

var A_arbace_go_check_A_const_255 *lang.Keyword

var A_arbace_go_check_A_const_256 *lang.Keyword

var A_arbace_go_check_A_const_257 *lang.Var

var A_arbace_go_check_A_const_258 *lang.Keyword

var A_arbace_go_check_A_const_259 *lang.Keyword

var A_arbace_go_check_A_const_260 *lang.Keyword

var A_arbace_go_check_A_const_261 *lang.Keyword

var A_arbace_go_check_A_const_262 *lang.Keyword

var A_arbace_go_check_A_const_263 *lang.Keyword

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Var

var A_arbace_go_check_A_const_266 *lang.Keyword

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 *lang.Var

var A_arbace_go_check_A_const_269 *lang.Keyword

var A_arbace_go_check_A_const_270 *lang.Keyword

var A_arbace_go_check_A_const_271 *lang.Var

var A_arbace_go_check_A_const_272 *lang.Var

var A_arbace_go_check_A_const_273 *lang.Var

var A_arbace_go_check_A_const_274 any

var A_arbace_go_check_A_const_275 *lang.Keyword

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Var

var A_arbace_go_check_A_const_278 *lang.Var

var A_arbace_go_check_A_const_279 *lang.Var

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Keyword

var A_arbace_go_check_A_const_283 *lang.Keyword

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 *lang.Var

var A_arbace_go_check_A_const_286 *lang.Keyword

var A_arbace_go_check_A_const_287 *lang.Keyword

var A_arbace_go_check_A_const_288 *lang.Keyword

var A_arbace_go_check_A_const_289 *lang.Keyword

var A_arbace_go_check_A_const_290 any

var A_arbace_go_check_A_const_291 *lang.Keyword

var A_arbace_go_check_A_const_292 any

var A_arbace_go_check_A_const_293 any

var A_arbace_go_check_A_const_294 any

var A_arbace_go_check_A_const_295 *lang.Keyword

var A_arbace_go_check_A_const_296 *lang.Var

var A_arbace_go_check_A_const_297 any

var A_arbace_go_check_A_const_298 any

var A_arbace_go_check_A_const_299 any

var A_arbace_go_check_A_const_300 any

var A_arbace_go_check_A_const_301 any

var A_arbace_go_check_A_const_302 *lang.Keyword

var A_arbace_go_check_A_const_303 any

var A_arbace_go_check_A_const_304 *lang.Var

var A_arbace_go_check_A_const_305 *lang.Var

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 *lang.Var

var A_arbace_go_check_A_const_309 any

var A_arbace_go_check_A_const_310 *lang.Var

var A_arbace_go_check_A_const_311 *lang.Keyword

var A_arbace_go_check_A_const_312 *lang.Keyword

var A_arbace_go_check_A_const_313 *lang.Keyword

var A_arbace_go_check_A_const_314 *lang.Keyword

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 *lang.Keyword

var A_arbace_go_check_A_const_322 *lang.Var

var A_arbace_go_check_A_const_323 *lang.Var

var A_arbace_go_check_A_const_324 *lang.Var

var A_arbace_go_check_A_const_325 *lang.Var

var A_arbace_go_check_A_const_326 any

var A_arbace_go_check_A_const_327 *lang.Var

var A_arbace_go_check_A_const_328 any

var A_arbace_go_check_A_const_329 any

var A_arbace_go_check_A_const_330 *lang.Var

var A_arbace_go_check_A_const_331 *lang.Keyword

var A_arbace_go_check_A_const_332 *lang.Keyword

var A_arbace_go_check_A_const_333 *lang.Keyword

var A_arbace_go_check_A_const_334 *lang.Keyword

var A_arbace_go_check_A_const_335 *lang.Keyword

var A_arbace_go_check_A_const_336 *lang.Var

var A_arbace_go_check_A_const_337 *lang.Keyword

var A_arbace_go_check_A_const_338 *lang.Keyword

var A_arbace_go_check_A_const_339 *lang.Var

var A_arbace_go_check_A_const_340 *lang.Keyword

var A_arbace_go_check_A_const_341 any

var A_arbace_go_check_A_const_342 *lang.Keyword

var A_arbace_go_check_A_const_343 *lang.Keyword

var A_arbace_go_check_A_const_344 *lang.Var

var A_arbace_go_check_A_const_345 any

var A_arbace_go_check_A_const_346 any

var A_arbace_go_check_A_const_347 *lang.Var

var A_arbace_go_check_A_const_348 *lang.Var

var A_arbace_go_check_A_const_349 any

var A_arbace_go_check_A_const_350 *lang.Var

var A_arbace_go_check_A_const_351 any

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 *lang.Var

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_const_359 *lang.Var

var A_arbace_go_check_A_const_360 *lang.Var

var A_arbace_go_check_A_const_361 *lang.Var

var A_arbace_go_check_A_const_362 *lang.Var

var A_arbace_go_check_A_const_363 *lang.Var

var A_arbace_go_check_A_const_364 *lang.Keyword

var A_arbace_go_check_A_const_365 *lang.Keyword

var A_arbace_go_check_A_const_366 *lang.Keyword

var A_arbace_go_check_A_const_367 *lang.Var

var A_arbace_go_check_A_const_368 *lang.Var

var A_arbace_go_check_A_const_369 *jrt.Class

var A_arbace_go_check_A_const_370 *lang.Var

var A_arbace_go_check_A_const_371 *lang.Var

var A_arbace_go_check_A_const_372 *lang.Var

var A_arbace_go_check_A_const_373 *lang.Keyword

var A_arbace_go_check_A_const_374 any

var A_arbace_go_check_A_const_375 any

var A_arbace_go_check_A_const_376 any

var A_arbace_go_check_A_const_377 *lang.Keyword

var A_arbace_go_check_A_const_378 *lang.Var

var A_arbace_go_check_A_const_379 *lang.Keyword

var A_arbace_go_check_A_const_380 *lang.Var

var A_arbace_go_check_A_const_381 *lang.Var

var A_arbace_go_check_A_const_382 any

var A_arbace_go_check_A_const_383 any

var A_arbace_go_check_A_const_384 any

var A_arbace_go_check_A_const_385 any

var A_arbace_go_check_A_const_386 any

var A_arbace_go_check_A_const_387 any

var A_arbace_go_check_A_const_388 *lang.Var

var A_arbace_go_check_A_const_389 any

var A_arbace_go_check_A_const_390 any

var A_arbace_go_check_A_const_391 any

var A_arbace_go_check_A_const_392 any

var A_arbace_go_check_A_const_393 *lang.Keyword

var A_arbace_go_check_A_const_394 *lang.Var

var A_arbace_go_check_A_const_395 *lang.Keyword

var A_arbace_go_check_A_const_396 *lang.Var

var A_arbace_go_check_A_const_397 *lang.Var

var A_arbace_go_check_A_const_398 *lang.Var

var A_arbace_go_check_A_const_399 *lang.Var

var A_arbace_go_check_A_const_400 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29(); A_arbace_go_check_A_clinit_p30(); A_arbace_go_check_A_clinit_p31(); A_arbace_go_check_A_clinit_p32() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 584); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[183]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[184]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[185]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[186]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[187]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[189]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[190]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[191]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[192]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[193]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[194]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[195]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[196]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[200]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[203]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[204]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[205]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[207]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[208]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[209]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[213]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[214]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[216]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[220] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[221]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[223]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[224]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[226]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[231]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[232]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[233]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_54 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_60 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_61 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_62 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[245]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_64 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_66 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_67 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_72 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_73 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[257]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[259]); A_arbace_go_check_A_const_77 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[260]); A_arbace_go_check_A_const_78 = A_arbace_go_check_A_const_pool.A[261]; A_arbace_go_check_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_80 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[269]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_89 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_91 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_92 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_93 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[276]); A_arbace_go_check_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_95 = A_arbace_go_check_A_const_pool.A[278]; A_arbace_go_check_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_98 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[281]) }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = A_arbace_go_check_A_const_pool.A[282]; A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[283]); A_arbace_go_check_A_const_101 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_102 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[285]); A_arbace_go_check_A_const_103 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_104 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_105 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_106 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[290]); A_arbace_go_check_A_const_108 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[295]); A_arbace_go_check_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_114 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_119 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_122 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[305]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_124 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_125 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_127 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_129 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[312]); A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_132 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_133 = A_arbace_go_check_A_const_pool.A[316]; A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[317]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[319]); A_arbace_go_check_A_const_137 = A_arbace_go_check_A_const_pool.A[320]; A_arbace_go_check_A_const_138 = A_arbace_go_check_A_const_pool.A[321]; A_arbace_go_check_A_const_139 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_141 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[324]); A_arbace_go_check_A_const_142 = A_arbace_go_check_A_const_pool.A[325]; A_arbace_go_check_A_const_143 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_144 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_145 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_146 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[329]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_150 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_151 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_152 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_153 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_154 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_155 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_156 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_157 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_163 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_164 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_165 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_166 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_167 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_191 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[377]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_196 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_197 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_198 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_199 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_200 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_201 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_202 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_203 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_205 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_206 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_209 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_210 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_211 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_213 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_214 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_215 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_216 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_217 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[401]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_220 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_221 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_222 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_223 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_224 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_225 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_230 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[413]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_233 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_235 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_236 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_239 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_240 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_241 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[424]); A_arbace_go_check_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[425]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_244 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_245 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[428]); A_arbace_go_check_A_const_246 = A_arbace_go_check_A_const_pool.A[429]; A_arbace_go_check_A_const_247 = A_arbace_go_check_A_const_pool.A[430]; A_arbace_go_check_A_const_248 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_249 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_250 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[433]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_252 = A_arbace_go_check_A_const_pool.A[435]; A_arbace_go_check_A_const_253 = A_arbace_go_check_A_const_pool.A[436]; A_arbace_go_check_A_const_254 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_255 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_257 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_258 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_260 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_261 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_262 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[445]); A_arbace_go_check_A_const_263 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_265 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_266 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[451]); A_arbace_go_check_A_const_269 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[452]); A_arbace_go_check_A_const_270 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_271 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_272 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_273 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_274 = A_arbace_go_check_A_const_pool.A[457]; A_arbace_go_check_A_const_275 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_277 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_278 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_279 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_282 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_283 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_285 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_286 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_287 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_288 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[471]); A_arbace_go_check_A_const_289 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[472]); A_arbace_go_check_A_const_290 = A_arbace_go_check_A_const_pool.A[473]; A_arbace_go_check_A_const_291 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[474]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = A_arbace_go_check_A_const_pool.A[475]; A_arbace_go_check_A_const_293 = A_arbace_go_check_A_const_pool.A[476]; A_arbace_go_check_A_const_294 = A_arbace_go_check_A_const_pool.A[477]; A_arbace_go_check_A_const_295 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[478]); A_arbace_go_check_A_const_296 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[479]); A_arbace_go_check_A_const_297 = A_arbace_go_check_A_const_pool.A[480]; A_arbace_go_check_A_const_298 = A_arbace_go_check_A_const_pool.A[481]; A_arbace_go_check_A_const_299 = A_arbace_go_check_A_const_pool.A[482]; A_arbace_go_check_A_const_300 = A_arbace_go_check_A_const_pool.A[483]; A_arbace_go_check_A_const_301 = A_arbace_go_check_A_const_pool.A[484]; A_arbace_go_check_A_const_302 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_303 = A_arbace_go_check_A_const_pool.A[486]; A_arbace_go_check_A_const_304 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[487]); A_arbace_go_check_A_const_305 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[488]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_308 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_309 = A_arbace_go_check_A_const_pool.A[492]; A_arbace_go_check_A_const_310 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_311 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[494]); A_arbace_go_check_A_const_312 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[495]); A_arbace_go_check_A_const_313 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_314 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[498]); A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[500]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_321 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_322 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_323 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[506]); A_arbace_go_check_A_const_324 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[507]); A_arbace_go_check_A_const_325 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[508]); A_arbace_go_check_A_const_326 = A_arbace_go_check_A_const_pool.A[509]; A_arbace_go_check_A_const_327 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[510]); A_arbace_go_check_A_const_328 = A_arbace_go_check_A_const_pool.A[511]; A_arbace_go_check_A_const_329 = A_arbace_go_check_A_const_pool.A[512] }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_330 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[513]); A_arbace_go_check_A_const_331 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[514]); A_arbace_go_check_A_const_332 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[515]); A_arbace_go_check_A_const_333 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[516]); A_arbace_go_check_A_const_334 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_335 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_336 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_337 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_338 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[521]); A_arbace_go_check_A_const_339 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[522]); A_arbace_go_check_A_const_340 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[523]); A_arbace_go_check_A_const_341 = A_arbace_go_check_A_const_pool.A[524] }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[525]); A_arbace_go_check_A_const_343 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[526]); A_arbace_go_check_A_const_344 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[527]); A_arbace_go_check_A_const_345 = A_arbace_go_check_A_const_pool.A[528]; A_arbace_go_check_A_const_346 = A_arbace_go_check_A_const_pool.A[529]; A_arbace_go_check_A_const_347 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[530]); A_arbace_go_check_A_const_348 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[531]); A_arbace_go_check_A_const_349 = A_arbace_go_check_A_const_pool.A[532]; A_arbace_go_check_A_const_350 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[533]); A_arbace_go_check_A_const_351 = A_arbace_go_check_A_const_pool.A[534]; A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[535]); A_arbace_go_check_A_const_353 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[536]); A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[537]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[538]); A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[539]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[540]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[541]); A_arbace_go_check_A_const_359 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[542]); A_arbace_go_check_A_const_360 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[543]); A_arbace_go_check_A_const_361 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[544]); A_arbace_go_check_A_const_362 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[545]); A_arbace_go_check_A_const_363 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[546]); A_arbace_go_check_A_const_364 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[547]); A_arbace_go_check_A_const_365 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[548]); A_arbace_go_check_A_const_366 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[549]) }

func A_arbace_go_check_A_clinit_p30() { A_arbace_go_check_A_const_367 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[550]); A_arbace_go_check_A_const_368 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[551]); A_arbace_go_check_A_const_369 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[552]); A_arbace_go_check_A_const_370 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[553]); A_arbace_go_check_A_const_371 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[554]); A_arbace_go_check_A_const_372 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[555]); A_arbace_go_check_A_const_373 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[556]); A_arbace_go_check_A_const_374 = A_arbace_go_check_A_const_pool.A[557]; A_arbace_go_check_A_const_375 = A_arbace_go_check_A_const_pool.A[558]; A_arbace_go_check_A_const_376 = A_arbace_go_check_A_const_pool.A[559]; A_arbace_go_check_A_const_377 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[560]); A_arbace_go_check_A_const_378 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[561]) }

func A_arbace_go_check_A_clinit_p31() { A_arbace_go_check_A_const_379 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[562]); A_arbace_go_check_A_const_380 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[563]); A_arbace_go_check_A_const_381 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[564]); A_arbace_go_check_A_const_382 = A_arbace_go_check_A_const_pool.A[565]; A_arbace_go_check_A_const_383 = A_arbace_go_check_A_const_pool.A[566]; A_arbace_go_check_A_const_384 = A_arbace_go_check_A_const_pool.A[567]; A_arbace_go_check_A_const_385 = A_arbace_go_check_A_const_pool.A[568]; A_arbace_go_check_A_const_386 = A_arbace_go_check_A_const_pool.A[569]; A_arbace_go_check_A_const_387 = A_arbace_go_check_A_const_pool.A[570]; A_arbace_go_check_A_const_388 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[571]); A_arbace_go_check_A_const_389 = A_arbace_go_check_A_const_pool.A[572]; A_arbace_go_check_A_const_390 = A_arbace_go_check_A_const_pool.A[573]; A_arbace_go_check_A_const_391 = A_arbace_go_check_A_const_pool.A[574]; A_arbace_go_check_A_const_392 = A_arbace_go_check_A_const_pool.A[575] }

func A_arbace_go_check_A_clinit_p32() { A_arbace_go_check_A_const_393 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[576]); A_arbace_go_check_A_const_394 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[577]); A_arbace_go_check_A_const_395 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[578]); A_arbace_go_check_A_const_396 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[579]); A_arbace_go_check_A_const_397 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[580]); A_arbace_go_check_A_const_398 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[581]); A_arbace_go_check_A_const_399 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[582]); A_arbace_go_check_A_const_400 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[583]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000515_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000515_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_A struct{ j2g_header uint64; F_cs, F_opts any }

var A_arbace_go_check__main_fn__1685000518_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A struct{ j2g_header uint64; F_iter__1685000519, F_opts, F_s__1685000520 any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A struct{ j2g_header uint64; F_b__1685000522, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A struct{ j2g_header uint64; F_s__1685000491, F_iter__1685000490 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A struct{ j2g_header uint64; F_r, F_s__1685000493, F_iter__1685000492 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000495 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000370_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000374_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000378_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A struct{ j2g_header uint64; F_s__1685000389, F_iter__1685000388 any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A struct{ j2g_header uint64; F_b__1685000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A struct{ j2g_header uint64; F_iter__1685000402, F_dir, F_tdir, F_ts, F_s__1685000403 any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A struct{ j2g_header uint64; F_dir, F_b__1685000405, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A struct{ j2g_header uint64; F_s__1685000361, F_iter__1685000360 any }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000363 any }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000129_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000129_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000131_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000131_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000179_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000186_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000186_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000193_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000203_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000203_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000205_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000205_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000239_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000239_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000241_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000241_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000247_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000247_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_A struct{ j2g_header uint64; F_resolving any }

var A_arbace_go_check_check_package_fn__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A struct{ j2g_header uint64; F_s__1685000267, F_iter__1685000266, F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A struct{ j2g_header uint64; F_b__1685000269 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000299_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000299_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000311_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000311_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000231_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A struct{ j2g_header uint64; F_s__1685000302, F_iter__1685000301 any }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A struct{ j2g_header uint64; F_b__1685000304 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000235_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000235_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class *jrt.Class



type A_arbace_go_check_check_src_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_src_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000321_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000467_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000467_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A struct{ j2g_header uint64; F_iter__1685000469, F_s__1685000470 any }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1685000472, F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A struct{ j2g_header uint64; F_iter__1685000447, F_s__1685000448 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A struct{ j2g_header uint64; F_iter__1685000449, F_r, F_s__1685000450 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000452 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000318_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000318_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A struct{ j2g_header uint64; F_iter__1685000338, F_f, F_out, F_q, F_xs, F_s__1685000339 any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_b__1685000341, F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000333_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000333_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000434_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000434_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000436_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000436_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000438_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000438_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000440_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000440_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000442_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000442_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000444_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000444_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000432_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000432_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000430_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000430_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000483_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000483_A_fn_class *jrt.Class
