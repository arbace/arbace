//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A_New() *A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_117)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1686000008_fn__1686000009_A_New() *A_arbace_go_check_eval1686000008_fn__1686000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1686000008_fn__1686000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1686000008_fn__1686000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1686000008_fn__1686000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var fnbody__45 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1686000012_A_New_O(acc__2); var tmp1 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1686000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__45); A_arbace_go_check_annotations_present_add_BANG___1686000012_A_fn_class = fncls__44d; tmp1 = fncls__44d } else { tmp1 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp1, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1686000014_A = A_arbace_go_check_annotations_present_walk__1686000014_A_New_O(add_BANG___3); var walk__4 any; var fnbody__162 any = any(body_walk__4); var tmp2 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_go_check_annotations_present_walk__1686000014_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__162); A_arbace_go_check_annotations_present_walk__1686000014_A_fn_class = fncls__161d; tmp2 = fncls__161d } else { tmp2 = fncls__161 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp2, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_46 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = acc__2; if linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_46, arg_49) } }
func A_arbace_go_check_annotations_present_add_BANG___1686000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1686000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1686000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1686000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1686000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1686000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1686000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1686000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1686000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1686000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_50 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_52 lang.IFn
	if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = f__1; if linked_51 == nil { tmp1 = ifn_52.Invoke_O__O(arg_53) } else { tmp1 = linked_51.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_50, arg_53) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_90 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = in_meta__2; if linked_91 == nil { and__1927000168__auto____5 = ifn_92.Invoke_O__O(arg_93) } else { and__1927000168__auto____5 = linked_91.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_94 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_go_check_A_const_37; var arg_98 any; var root_99 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = f__1; if linked_100 == nil { arg_98 = ifn_101.Invoke_O__O(arg_102) } else { arg_98 = linked_100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_99, arg_102) }; if linked_95 == nil { tmp2 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { tmp2 = linked_95.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_94, arg_97, arg_98) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_103 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = f__1; if linked_104 == nil { tmp5 = ifn_105.Invoke_O__O(arg_106) } else { tmp5 = linked_104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_103, arg_106) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_107 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = m__3; var arg_111 any = A_arbace_go_check_A_const_40; if linked_108 == nil { tmp3 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { tmp3 = linked_108.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_112 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = f__1; if linked_113 == nil { tmp8 = ifn_114.Invoke_O__O(arg_115) } else { tmp8 = linked_113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_112, arg_115) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_116 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = v__5; if linked_117 == nil { tmp12 = ifn_118.Invoke_O__O(arg_119) } else { tmp12 = linked_117.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_66 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = f__1; if linked_67 == nil { tmp14 = ifn_68.Invoke_O__O(arg_69) } else { tmp14 = linked_67.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1686000015__3 any; var root_70 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_72 lang.IFn







		if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = f__1; if linked_71 == nil { seq_1686000015__3 = ifn_72.Invoke_O__O(arg_73) } else { seq_1686000015__3 = linked_71.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_70, arg_73) }
//line :39:1
		var chunk_1686000016__4 any; var count_1686000017__5 int64 = 0; var i_1686000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000018__6, count_1686000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1686000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1686000015__3, chunk_1686000016__4, count_1686000017__5, i_1686000018__6 = seq_1686000015__3, chunk_1686000016__4, count_1686000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_74 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = seq_1686000015__3; if linked_75 == nil { temp__1927000414__auto____7 = ifn_76.Invoke_O__O(arg_77) } else { temp__1927000414__auto____7 = linked_75.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_74, arg_77) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1686000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_78 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = seq_1686000015__8; if linked_79 == nil { tmp15 = ifn_80.Invoke_O__O(arg_81) } else { tmp15 = linked_79.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_82 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_1686000015__8; if linked_83 == nil { c__1927000678__auto____9 = ifn_84.Invoke_O__O(arg_85) } else { c__1927000678__auto____9 = linked_83.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_82, arg_85) }; var tmp16 any; var root_120 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = seq_1686000015__8; if linked_121 == nil { tmp16 = ifn_122.Invoke_O__O(arg_123) } else { tmp16 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_120, arg_123) }; seq_1686000015__3, chunk_1686000016__4, count_1686000017__5, i_1686000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_86 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_1686000015__8; if linked_87 == nil { x__9 = ifn_88.Invoke_O__O(arg_89) } else { x__9 = linked_87.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_86, arg_89) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_124 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = seq_1686000015__8; if linked_125 == nil { tmp17 = ifn_126.Invoke_O__O(arg_127) } else { tmp17 = linked_125.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_124, arg_127) }; seq_1686000015__3, chunk_1686000016__4, count_1686000017__5, i_1686000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_54 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_56 lang.IFn









			if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = f__1; if linked_55 == nil { tmp19 = ifn_56.Invoke_O__O(arg_57) } else { tmp19 = linked_55.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_54, arg_57) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_128 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_130 lang.IFn











				if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = m__3_2; var arg_132 any = A_arbace_go_check_A_const_40; if linked_129 == nil { tmp20 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { tmp20 = linked_129.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_128, arg_131, arg_132) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_58 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_60 lang.IFn















					if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = f__1; if linked_59 == nil { tmp21 = ifn_60.Invoke_O__O(arg_61) } else { tmp21 = linked_59.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_58, arg_61) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1686000019__3 any; var root_133 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_135 lang.IFn















						if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = f__1; if linked_134 == nil { seq_1686000019__3 = ifn_135.Invoke_O__O(arg_136) } else { seq_1686000019__3 = linked_134.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_133, arg_136) }
//line :39:1
						var chunk_1686000020__4 any; var count_1686000021__5 int64 = 0; var i_1686000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000022__6, count_1686000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1686000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1686000019__3, chunk_1686000020__4, count_1686000021__5, i_1686000022__6 = seq_1686000019__3, chunk_1686000020__4, count_1686000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_137 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = seq_1686000019__3; if linked_138 == nil { temp__1927000414__auto____7_2 = ifn_139.Invoke_O__O(arg_140) } else { temp__1927000414__auto____7_2 = linked_138.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1686000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_141 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = seq_1686000019__8; if linked_142 == nil { tmp22 = ifn_143.Invoke_O__O(arg_144) } else { tmp22 = linked_142.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_145 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = seq_1686000019__8; if linked_146 == nil { c__1927000678__auto____9_2 = ifn_147.Invoke_O__O(arg_148) } else { c__1927000678__auto____9_2 = linked_146.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_145, arg_148) }; var tmp23 any; var root_153 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = seq_1686000019__8; if linked_154 == nil { tmp23 = ifn_155.Invoke_O__O(arg_156) } else { tmp23 = linked_154.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_153, arg_156) }; seq_1686000019__3, chunk_1686000020__4, count_1686000021__5, i_1686000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_149 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = seq_1686000019__8; if linked_150 == nil { x__9_2 = ifn_151.Invoke_O__O(arg_152) } else { x__9_2 = linked_150.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_149, arg_152) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_157 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = seq_1686000019__8; if linked_158 == nil { tmp24 = ifn_159.Invoke_O__O(arg_160) } else { tmp24 = linked_158.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_157, arg_160) }; seq_1686000019__3, chunk_1686000020__4, count_1686000021__5, i_1686000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_62 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_64 lang.IFn

















							if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = f__1; if linked_63 == nil { tmp26 = ifn_64.Invoke_O__O(arg_65) } else { tmp26 = linked_63.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_62, arg_65) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1686000025_A = A_arbace_go_check_nodes_seq_walk__1686000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var fnbody__240 any = any(body_walk__4); var tmp1 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1686000025_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__240); A_arbace_go_check_nodes_seq_walk__1686000025_A_fn_class = fncls__239d; tmp1 = fncls__239d } else { tmp1 = fncls__239 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__240, tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1686000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1686000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1686000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1686000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1686000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_163 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_165 lang.IFn
		if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = x__1; if linked_164 == nil { tmp1 = ifn_165.Invoke_O__O(arg_166) } else { tmp1 = linked_164.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_163, arg_166) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.IdentityHashMap_Cast(t.F_seen).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayList_Cast(t.F_acc).Add_O__Z(x__1)) }
//line :71:1
				var seq_1686000026__2 any; var root_167 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_169 lang.IFn

				if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = x__1; if linked_168 == nil { seq_1686000026__2 = ifn_169.Invoke_O__O(arg_170) } else { seq_1686000026__2 = linked_168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_167, arg_170) }
//line :71:1
				var chunk_1686000027__3 any; var count_1686000028__4 int64 = 0; var i_1686000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000029__5, count_1686000028__4) { var vec__1686000030__6 any = lang.Indexed_Cast(chunk_1686000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_171 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_172 == nil { tmp2 = ifn_173.Invoke_O__O(arg_174) } else { tmp2 = linked_172.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_171, arg_174) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, i_1686000029__5 = seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000029__5); continue L1 } else { seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, i_1686000029__5 = seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_175 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = seq_1686000026__2; if linked_176 == nil { temp__1927000414__auto____6 = ifn_177.Invoke_O__O(arg_178) } else { temp__1927000414__auto____6 = linked_176.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_175, arg_178) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1686000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_179 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = seq_1686000026__7; if linked_180 == nil { tmp3 = ifn_181.Invoke_O__O(arg_182) } else { tmp3 = linked_180.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_179, arg_182) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_183 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = seq_1686000026__7; if linked_184 == nil { c__1927000678__auto____8 = ifn_185.Invoke_O__O(arg_186) } else { c__1927000678__auto____8 = linked_184.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_183, arg_186) }; var tmp4 any; var root_219 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = seq_1686000026__7; if linked_220 == nil { tmp4 = ifn_221.Invoke_O__O(arg_222) } else { tmp4 = linked_220.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_219, arg_222) }; seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, i_1686000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1686000033__8 any; var root_187 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = seq_1686000026__7; if linked_188 == nil { vec__1686000033__8 = ifn_189.Invoke_O__O(arg_190) } else { vec__1686000033__8 = linked_188.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_187, arg_190) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_191 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_192 == nil { tmp5 = ifn_193.Invoke_O__O(arg_194) } else { tmp5 = linked_192.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_223 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = seq_1686000026__7; if linked_224 == nil { tmp6 = ifn_225.Invoke_O__O(arg_226) } else { tmp6 = linked_224.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_223, arg_226) }; seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, i_1686000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_227 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = seq_1686000026__7; if linked_228 == nil { tmp7 = ifn_229.Invoke_O__O(arg_230) } else { tmp7 = linked_228.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_227, arg_230) }; seq_1686000026__2, chunk_1686000027__3, count_1686000028__4, i_1686000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_195 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_197 lang.IFn





									if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = x__1; if linked_196 == nil { tmp8 = ifn_197.Invoke_O__O(arg_198) } else { tmp8 = linked_196.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_195, arg_198) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1686000036__2 any; var root_199 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_201 lang.IFn





										if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = x__1; if linked_200 == nil { seq_1686000036__2 = ifn_201.Invoke_O__O(arg_202) } else { seq_1686000036__2 = linked_200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_199, arg_202) }
//line :70:1
										var chunk_1686000037__3 any; var count_1686000038__4 int64 = 0; var i_1686000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000039__5, count_1686000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1686000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1686000036__2, chunk_1686000037__3, count_1686000038__4, i_1686000039__5 = seq_1686000036__2, chunk_1686000037__3, count_1686000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_203 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = seq_1686000036__2; if linked_204 == nil { temp__1927000414__auto____6_2 = ifn_205.Invoke_O__O(arg_206) } else { temp__1927000414__auto____6_2 = linked_204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1686000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_207 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = seq_1686000036__7; if linked_208 == nil { tmp9 = ifn_209.Invoke_O__O(arg_210) } else { tmp9 = linked_208.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_207, arg_210) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_211 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = seq_1686000036__7; if linked_212 == nil { c__1927000678__auto____8_2 = ifn_213.Invoke_O__O(arg_214) } else { c__1927000678__auto____8_2 = linked_212.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_211, arg_214) }; var tmp10 any; var root_231 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = seq_1686000036__7; if linked_232 == nil { tmp10 = ifn_233.Invoke_O__O(arg_234) } else { tmp10 = linked_232.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_231, arg_234) }; seq_1686000036__2, chunk_1686000037__3, count_1686000038__4, i_1686000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_215 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = seq_1686000036__7; if linked_216 == nil { y__8 = ifn_217.Invoke_O__O(arg_218) } else { y__8 = linked_216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_215, arg_218) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_235 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = seq_1686000036__7; if linked_236 == nil { tmp11 = ifn_237.Invoke_O__O(arg_238) } else { tmp11 = linked_236.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_235, arg_238) }; seq_1686000036__2, chunk_1686000037__3, count_1686000038__4, i_1686000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1686000042__2 any; var root_241 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_243 lang.IFn




	if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any; var root_245 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = tree__0; if linked_246 == nil { arg_244 = ifn_247.Invoke_O__O(arg_248) } else { arg_244 = linked_246.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_245, arg_248) }; if linked_242 == nil { seq_1686000042__2 = ifn_243.Invoke_O__O(arg_244) } else { seq_1686000042__2 = linked_242.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_241, arg_244) }
//line :81:1
	var chunk_1686000043__3 any; var count_1686000044__4 int64 = 0; var i_1686000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000045__5, count_1686000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1686000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { var root_265 any = A_arbace_go_check_A_const_54.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = want__7; var arg_269 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_266 == nil { tmp1 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { tmp1 = linked_266.(*aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_265, arg_268, arg_269) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_270 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = A_arbace_go_check_A_const_24; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_271 == nil { ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { linked_271.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_275 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_276 == nil { tmp2 = ifn_277.Invoke_O__O(arg_278) } else { tmp2 = linked_276.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_275, arg_278) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_283 any = Lit_156; var arg_284 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_288 == nil { arg_284 = ifn_289.Invoke_O__O(arg_290) } else { arg_284 = linked_288.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_287, arg_290) }; var arg_285 any; var root_291 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_293 lang.IFn
							if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = want__7; if linked_292 == nil { arg_285 = ifn_293.Invoke_O__O(arg_294) } else { arg_285 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_291, arg_294) }
//line :93:1
							var arg_286 any; var root_295 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_297 lang.IFn
							if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_296 == nil { arg_286 = ifn_297.Invoke_O__O(arg_298) } else { arg_286 = linked_296.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_295, arg_298) }
//line :93:1
							if linked_280 == nil { ifn_281.Invoke_O_O_O_O_O__O(arg_282, arg_283, arg_284, arg_285, arg_286) } else { linked_280.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_279, arg_282, arg_283, arg_284, arg_285, arg_286) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_61; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_62.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_65; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_299 any = A_arbace_go_check_A_const_67.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_301 lang.IFn
									if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_300 == nil { and__1927000168__auto____11 = ifn_301.Invoke_O__O(arg_302) } else { and__1927000168__auto____11 = linked_300.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_299, arg_302) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_303 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = A_arbace_go_check_A_const_68; var arg_307 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_304 == nil { tmp3 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { tmp3 = linked_304.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__6); var arg_312 any = Lit_156; var arg_313 any; var root_316 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__6); if linked_317 == nil { arg_313 = ifn_318.Invoke_O__O(arg_319) } else { arg_313 = linked_317.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_316, arg_319) }; var arg_314 any = Lit_157; var arg_315 any; var root_320 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_321 == nil { arg_315 = ifn_322.Invoke_O__O(arg_323) } else { arg_315 = linked_321.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_320, arg_323) }; if linked_309 == nil { ifn_310.Invoke_O_O_O_O_O__O(arg_311, arg_312, arg_313, arg_314, arg_315) } else { linked_309.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_308, arg_311, arg_312, arg_313, arg_314, arg_315) } } }
//line :86:1
			seq_1686000042__2, chunk_1686000043__3, count_1686000044__4, i_1686000045__5 = seq_1686000042__2, chunk_1686000043__3, count_1686000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_249 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = seq_1686000042__2; if linked_250 == nil { temp__1927000414__auto____6 = ifn_251.Invoke_O__O(arg_252) } else { temp__1927000414__auto____6 = linked_250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1686000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_253 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = seq_1686000042__7; if linked_254 == nil { tmp7 = ifn_255.Invoke_O__O(arg_256) } else { tmp7 = linked_254.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_257 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = seq_1686000042__7; if linked_258 == nil { c__1927000678__auto____8 = ifn_259.Invoke_O__O(arg_260) } else { c__1927000678__auto____8 = linked_258.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_257, arg_260) }; var tmp8 any; var root_324 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = seq_1686000042__7; if linked_325 == nil { tmp8 = ifn_326.Invoke_O__O(arg_327) } else { tmp8 = linked_325.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_324, arg_327) }; seq_1686000042__2, chunk_1686000043__3, count_1686000044__4, i_1686000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_261 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = seq_1686000042__7; if linked_262 == nil { n__8 = ifn_263.Invoke_O__O(arg_264) } else { n__8 = linked_262.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_261, arg_264) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { var root_328 any = A_arbace_go_check_A_const_54.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = want__9; var arg_332 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_329 == nil { tmp9 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp9 = linked_329.(*aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_328, arg_331, arg_332) } } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_333 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = A_arbace_go_check_A_const_24; var arg_337 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_334 == nil { ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { linked_334.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_333, arg_336, arg_337) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_338 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_339 == nil { tmp10 = ifn_340.Invoke_O__O(arg_341) } else { tmp10 = linked_339.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_338, arg_341) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_342 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_346 any = Lit_156; var arg_347 any; var root_350 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_351 == nil { arg_347 = ifn_352.Invoke_O__O(arg_353) } else { arg_347 = linked_351.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_350, arg_353) }; var arg_348 any; var root_354 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_356 lang.IFn
								if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = want__9; if linked_355 == nil { arg_348 = ifn_356.Invoke_O__O(arg_357) } else { arg_348 = linked_355.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_354, arg_357) }
//line :93:1
								var arg_349 any; var root_358 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_360 lang.IFn
								if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_359 == nil { arg_349 = ifn_360.Invoke_O__O(arg_361) } else { arg_349 = linked_359.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_358, arg_361) }
//line :93:1
								if linked_343 == nil { ifn_344.Invoke_O_O_O_O_O__O(arg_345, arg_346, arg_347, arg_348, arg_349) } else { linked_343.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_342, arg_345, arg_346, arg_347, arg_348, arg_349) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_61; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_62.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_65; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_362 any = A_arbace_go_check_A_const_67.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_364 lang.IFn
										if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_363 == nil { and__1927000168__auto____13 = ifn_364.Invoke_O__O(arg_365) } else { and__1927000168__auto____13 = linked_363.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_362, arg_365) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_366 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68; var arg_370 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_367 == nil { tmp11 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { tmp11 = linked_367.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_371 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__8); var arg_375 any = Lit_156; var arg_376 any; var root_379 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__8); if linked_380 == nil { arg_376 = ifn_381.Invoke_O__O(arg_382) } else { arg_376 = linked_380.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_379, arg_382) }; var arg_377 any = Lit_157; var arg_378 any; var root_383 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_384 == nil { arg_378 = ifn_385.Invoke_O__O(arg_386) } else { arg_378 = linked_384.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_383, arg_386) }; if linked_372 == nil { ifn_373.Invoke_O_O_O_O_O__O(arg_374, arg_375, arg_376, arg_377, arg_378) } else { linked_372.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_371, arg_374, arg_375, arg_376, arg_377, arg_378) } } }
//line :86:1
				var tmp15 any; var root_387 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = seq_1686000042__7; if linked_388 == nil { tmp15 = ifn_389.Invoke_O__O(arg_390) } else { tmp15 = linked_388.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_387, arg_390) }; seq_1686000042__2, chunk_1686000043__3, count_1686000044__4, i_1686000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_71; var tmp2 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_72; var tmp4 any; var root_391 any = A_arbace_go_check_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_393 lang.IFn; if
													linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = pkg_scope__0; var arg_395 any = A_arbace_go_check_A_const_74; if linked_392 == nil { tmp4 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { tmp4 = linked_392.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_75; var tmp7 int64; var root_396 any = /*line :101:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_396, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_398 lang.IFn; if


	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any; var or__1927000174__auto____4 any; var root_400 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = fi__1; var arg_404 any = A_arbace_go_check_A_const_78; if linked_401 == nil { or__1927000174__auto____4 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { or__1927000174__auto____4 = linked_401.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_399 = or__1927000174__auto____4 } else { arg_399 = A_arbace_go_check_A_const_75.Invoke_O__O(config__2) }; if linked_397 == nil { tmp7 = lang.RT_LongCast_O__J_NoInit(ifn_398.Invoke_O__O(arg_399)) } else { tmp7 = linked_397.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_396, arg_399) }; var tmp8 any = /*line :101:1*/jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_J__J_NoInit(tmp7)).Ref(); var tmp9 any = A_arbace_go_check_A_const_79; var tmp10 any; var root_405 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_407 lang.IFn; if



	linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = A_arbace_go_check_A_const_74.Invoke_O__O(fi__1); if linked_406 == nil { tmp10 = ifn_407.Invoke_O__O(arg_408) } else { tmp10 = linked_406.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_405, arg_408) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_81; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_81; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_82.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_83; var tmp16 any = A_arbace_go_check_A_const_83.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_84; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_85; var tmp20 any; var root_409 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_411 lang.IFn; if





	linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = lang.PersistentVector_EMPTY.Ref(); if linked_410 == nil { tmp20 = ifn_411.Invoke_O__O(arg_412) } else { tmp20 = linked_410.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_409, arg_412) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_86; var tmp23 any; var root_413 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_415 lang.IFn; if





	linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = lang.PersistentVector_EMPTY.Ref(); if linked_414 == nil { tmp23 = ifn_415.Invoke_O__O(arg_416) } else { tmp23 = linked_414.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_413, arg_416) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A_New_O(fi__0); var walk__3 any; var fnbody__516 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A_fn_class; if fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__516); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A_fn_class = fncls__515d; tmp1 = fncls__515d } else { tmp1 = fncls__515 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__516, tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_517 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_521 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = A_arbace_go_check_A_const_85.Invoke_O__O(fi__0); if linked_522 == nil { arg_520 = ifn_523.Invoke_O__O(arg_524) } else { arg_520 = linked_522.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_521, arg_524) }; if linked_518 == nil { tmp2 = ifn_519.Invoke_O__O(arg_520) } else { tmp2 = linked_518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_517, arg_520) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A_New_O(fi__0); var walk2__4 any; var fnbody__576 any = any(body_walk2__4); var tmp3 *jrt.Class; var fncls__575 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A_fn_class; if fncls__575 == nil { var fncls__575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__576); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A_fn_class = fncls__575d; tmp3 = fncls__575d } else { tmp3 = fncls__575 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__576, tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_417 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_419 lang.IFn
	if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = f__1; if linked_418 == nil { tmp1 = ifn_419.Invoke_O__O(arg_420) } else { tmp1 = linked_418.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_417, arg_420) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_421 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_423 lang.IFn
		if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = f__1; if linked_422 == nil { temp__1927000414__auto____2 = ifn_423.Invoke_O__O(arg_424) } else { temp__1927000414__auto____2 = linked_422.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_483 any = A_arbace_go_check_A_const_91.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_485 lang.IFn
			if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = A_arbace_go_check_A_const_72.Invoke_O__O(t.F_fi); var arg_487 any = q__3; if linked_484 == nil { temp__1927000414__auto____4 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { temp__1927000414__auto____4 = linked_484.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_92; var tmp3 any; var root_488 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_490 lang.IFn
				if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = x__5; var arg_492 any = A_arbace_go_check_A_const_94; if linked_489 == nil { tmp3 = ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { tmp3 = linked_489.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_493 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = x__5; var arg_497 any = A_arbace_go_check_A_const_90; var arg_498 any = jrt.Boolean_TRUE.Ref(); if linked_494 == nil { ifn_495.Invoke_O_O_O__O(arg_496, arg_497, arg_498) } else { linked_494.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_493, arg_496, arg_497, arg_498) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_84.Invoke_O__O(t.F_fi)); var tmp5 any; var root_425 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_427 lang.IFn


			if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = f__1; if linked_426 == nil { tmp5 = ifn_427.Invoke_O__O(arg_428) } else { tmp5 = linked_426.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_425, arg_428) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1686000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_429 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_431 lang.IFn; _ = ___6; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = imp__7; var arg_433 any = A_arbace_go_check_A_const_90; var arg_434 any = jrt.Boolean_TRUE.Ref(); if linked_430 == nil { ifn_431.Invoke_O_O_O__O(arg_432, arg_433, arg_434) } else { linked_430.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_429, arg_432, arg_433, arg_434) } } } } else {
//line :113:1
				var tmp6 any; var root_435 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_437 lang.IFn




				if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = f__1; if linked_436 == nil { tmp6 = ifn_437.Invoke_O__O(arg_438) } else { tmp6 = linked_436.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_435, arg_438) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1686000052__2 any; var root_439 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn




					if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = f__1; if linked_440 == nil { seq_1686000052__2 = ifn_441.Invoke_O__O(arg_442) } else { seq_1686000052__2 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }
//line :113:1
					var chunk_1686000053__3 any; var count_1686000054__4 int64 = 0; var i_1686000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000055__5, count_1686000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1686000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1686000052__2, chunk_1686000053__3, count_1686000054__4, i_1686000055__5 = seq_1686000052__2, chunk_1686000053__3, count_1686000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_443 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1686000052__2; if linked_444 == nil { temp__1927000414__auto____6 = ifn_445.Invoke_O__O(arg_446) } else { temp__1927000414__auto____6 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1686000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_447 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_1686000052__7; if linked_448 == nil { tmp7 = ifn_449.Invoke_O__O(arg_450) } else { tmp7 = linked_448.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_451 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq_1686000052__7; if linked_452 == nil { c__1927000678__auto____8 = ifn_453.Invoke_O__O(arg_454) } else { c__1927000678__auto____8 = linked_452.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_451, arg_454) }; var tmp8 any; var root_499 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = seq_1686000052__7; if linked_500 == nil { tmp8 = ifn_501.Invoke_O__O(arg_502) } else { tmp8 = linked_500.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_499, arg_502) }; seq_1686000052__2, chunk_1686000053__3, count_1686000054__4, i_1686000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_455 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = seq_1686000052__7; if linked_456 == nil { x__8 = ifn_457.Invoke_O__O(arg_458) } else { x__8 = linked_456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_455, arg_458) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_503 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1686000052__7; if linked_504 == nil { tmp9 = ifn_505.Invoke_O__O(arg_506) } else { tmp9 = linked_504.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_503, arg_506) }; seq_1686000052__2, chunk_1686000053__3, count_1686000054__4, i_1686000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_459 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_461 lang.IFn





							if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = f__1; if linked_460 == nil { tmp10 = ifn_461.Invoke_O__O(arg_462) } else { tmp10 = linked_460.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_459, arg_462) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1686000056__2 any; var root_463 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn





								if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = f__1; if linked_464 == nil { seq_1686000056__2 = ifn_465.Invoke_O__O(arg_466) } else { seq_1686000056__2 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }
//line :113:1
								var chunk_1686000057__3 any; var count_1686000058__4 int64 = 0; var i_1686000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000059__5, count_1686000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1686000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1686000056__2, chunk_1686000057__3, count_1686000058__4, i_1686000059__5 = seq_1686000056__2, chunk_1686000057__3, count_1686000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_467 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_1686000056__2; if linked_468 == nil { temp__1927000414__auto____6_2 = ifn_469.Invoke_O__O(arg_470) } else { temp__1927000414__auto____6_2 = linked_468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1686000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_471 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_1686000056__7; if linked_472 == nil { tmp11 = ifn_473.Invoke_O__O(arg_474) } else { tmp11 = linked_472.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_471, arg_474) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_475 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq_1686000056__7; if linked_476 == nil { c__1927000678__auto____8_2 = ifn_477.Invoke_O__O(arg_478) } else { c__1927000678__auto____8_2 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_475, arg_478) }; var tmp12 any; var root_507 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1686000056__7; if linked_508 == nil { tmp12 = ifn_509.Invoke_O__O(arg_510) } else { tmp12 = linked_508.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_507, arg_510) }; seq_1686000056__2, chunk_1686000057__3, count_1686000058__4, i_1686000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_479 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1686000056__7; if linked_480 == nil { x__8_2 = ifn_481.Invoke_O__O(arg_482) } else { x__8_2 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_511 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1686000056__7; if linked_512 == nil { tmp13 = ifn_513.Invoke_O__O(arg_514) } else { tmp13 = linked_512.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_511, arg_514) }; seq_1686000056__2, chunk_1686000057__3, count_1686000058__4, i_1686000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_525 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_527 lang.IFn
		if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { tmp1 = ifn_527.Invoke_O__O(arg_528) } else { tmp1 = linked_526.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_525, arg_528) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_84.Invoke_O__O(t.F_fi)); var tmp3 any; var root_529 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_531 lang.IFn
			if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp3 = ifn_531.Invoke_O__O(arg_532) } else { tmp3 = linked_530.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_529, arg_532) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1686000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_533 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_535 lang.IFn; _ = ___4; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = imp__5; var arg_537 any = A_arbace_go_check_A_const_90; var arg_538 any = jrt.Boolean_TRUE.Ref(); if linked_534 == nil { return ifn_535.Invoke_O_O_O__O(arg_536, arg_537, arg_538) } else { return linked_534.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_533, arg_536, arg_537, arg_538) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_539 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_541 lang.IFn

				if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = f__1; if linked_540 == nil { or__1927000174__auto____2 = ifn_541.Invoke_O__O(arg_542) } else { or__1927000174__auto____2 = linked_540.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_543 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = f__1; if linked_544 == nil { tmp4 = ifn_545.Invoke_O__O(arg_546) } else { tmp4 = linked_544.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_543, arg_546) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1686000065__2 any; var root_547 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn

					if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = f__1; if linked_548 == nil { seq_1686000065__2 = ifn_549.Invoke_O__O(arg_550) } else { seq_1686000065__2 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }
//line :127:1
					var chunk_1686000066__3 any; var count_1686000067__4 int64 = 0; var i_1686000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000068__5, count_1686000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1686000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1686000065__2, chunk_1686000066__3, count_1686000067__4, i_1686000068__5 = seq_1686000065__2, chunk_1686000066__3, count_1686000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_551 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = seq_1686000065__2; if linked_552 == nil { temp__1927000414__auto____6 = ifn_553.Invoke_O__O(arg_554) } else { temp__1927000414__auto____6 = linked_552.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_551, arg_554) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1686000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_555 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = seq_1686000065__7; if linked_556 == nil { tmp5 = ifn_557.Invoke_O__O(arg_558) } else { tmp5 = linked_556.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_555, arg_558) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_559 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = seq_1686000065__7; if linked_560 == nil { c__1927000678__auto____8 = ifn_561.Invoke_O__O(arg_562) } else { c__1927000678__auto____8 = linked_560.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_559, arg_562) }; var tmp6 any; var root_567 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = seq_1686000065__7; if linked_568 == nil { tmp6 = ifn_569.Invoke_O__O(arg_570) } else { tmp6 = linked_568.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_567, arg_570) }; seq_1686000065__2, chunk_1686000066__3, count_1686000067__4, i_1686000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_563 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = seq_1686000065__7; if linked_564 == nil { x__8 = ifn_565.Invoke_O__O(arg_566) } else { x__8 = linked_564.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_563, arg_566) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_571 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = seq_1686000065__7; if linked_572 == nil { tmp7 = ifn_573.Invoke_O__O(arg_574) } else { tmp7 = linked_572.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_571, arg_574) }; seq_1686000065__2, chunk_1686000066__3, count_1686000067__4, i_1686000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var fnbody__689 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A_fn_class; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, fnbody__689); A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A_fn_class = fncls__688d; tmp1 = fncls__688d } else { tmp1 = fncls__688 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__689, tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_99); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp6 any; var root_698 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = d__0; if linked_699 == nil { tmp6 = ifn_700.Invoke_O__O(arg_701) } else { tmp6 = linked_699.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_698, arg_701) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp8 any; var root_690 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = d__0; if linked_691 == nil { tmp8 = ifn_692.Invoke_O__O(arg_693) } else { tmp8 = linked_691.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_690, arg_693) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp10 any; var root_694 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = d__0; if linked_695 == nil { tmp10 = ifn_696.Invoke_O__O(arg_697) } else { tmp10 = linked_695.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_694, arg_697) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_577 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_579 lang.IFn
		if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = f__1; if linked_578 == nil { and__1927000168__auto____2 = ifn_579.Invoke_O__O(arg_580) } else { and__1927000168__auto____2 = linked_578.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_577, arg_580) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_581 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = f__1; if linked_582 == nil { tmp2 = ifn_583.Invoke_O__O(arg_584) } else { tmp2 = linked_582.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_581, arg_584) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_585 any = A_arbace_go_check_A_const_91.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_587 lang.IFn

			if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = t.F_pkg_scope; var arg_589 any; var root_590 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { arg_589 = ifn_592.Invoke_O__O(arg_593) } else { arg_589 = linked_591.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_590, arg_593) }; if linked_586 == nil { temp__1927000414__auto____2 = ifn_587.Invoke_O_O__O(arg_588, arg_589) } else { temp__1927000414__auto____2 = linked_586.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_585, arg_588, arg_589) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_95); var tmp4 any; var root_649 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_651 lang.IFn
				if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = x__3; var arg_653 any = A_arbace_go_check_A_const_94; if linked_650 == nil { tmp4 = ifn_651.Invoke_O_O__O(arg_652, arg_653) } else { tmp4 = linked_650.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_649, arg_652, arg_653) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_594 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_598 any = A_arbace_go_check_A_const_96; var arg_599 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_600 any = x__3; if linked_595 == nil { tmp6 = ifn_596.Invoke_O_O_O_O__O(arg_597, arg_598, arg_599, arg_600) } else { tmp6 = linked_595.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_594, arg_597, arg_598, arg_599, arg_600) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_601 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_603 lang.IFn




								if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = f__1; if linked_602 == nil { tmp7 = ifn_603.Invoke_O__O(arg_604) } else { tmp7 = linked_602.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_601, arg_604) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_654 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_656 lang.IFn




									if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = f__1; if linked_655 == nil { temp__1927000414__auto____2_2 = ifn_656.Invoke_O__O(arg_657) } else { temp__1927000414__auto____2_2 = linked_655.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_654, arg_657) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_658 any = A_arbace_go_check_A_const_98.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_660 lang.IFn
										if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = h__3; var arg_662 any = Lit_137; if linked_659 == nil { and__1927000168__auto____4 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { and__1927000168__auto____4 = linked_659.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_663 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var root_667 any = A_arbace_go_check_A_const_98.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = h__3; var arg_671 any = Lit_155; if linked_668 == nil { arg_666 = ifn_669.Invoke_O_O__O(arg_670, arg_671) } else { arg_666 = linked_668.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_667, arg_670, arg_671) }; if linked_664 == nil { and__1927000168__auto____5 = ifn_665.Invoke_O__O(arg_666) } else { and__1927000168__auto____5 = linked_664.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1686000072__2 any; var root_605 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_607 lang.IFn








									if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = f__1; if linked_606 == nil { seq_1686000072__2 = ifn_607.Invoke_O__O(arg_608) } else { seq_1686000072__2 = linked_606.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_605, arg_608) }
//line :137:1
									var chunk_1686000073__3 any; var count_1686000074__4 int64 = 0; var i_1686000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000075__5, count_1686000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1686000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1686000072__2, chunk_1686000073__3, count_1686000074__4, i_1686000075__5 = seq_1686000072__2, chunk_1686000073__3, count_1686000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_609 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = seq_1686000072__2; if linked_610 == nil { temp__1927000414__auto____6 = ifn_611.Invoke_O__O(arg_612) } else { temp__1927000414__auto____6 = linked_610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_609, arg_612) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1686000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_613 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = seq_1686000072__7; if linked_614 == nil { tmp9 = ifn_615.Invoke_O__O(arg_616) } else { tmp9 = linked_614.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_613, arg_616) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_617 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = seq_1686000072__7; if linked_618 == nil { c__1927000678__auto____8 = ifn_619.Invoke_O__O(arg_620) } else { c__1927000678__auto____8 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_617, arg_620) }; var tmp10 any; var root_672 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq_1686000072__7; if linked_673 == nil { tmp10 = ifn_674.Invoke_O__O(arg_675) } else { tmp10 = linked_673.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_672, arg_675) }; seq_1686000072__2, chunk_1686000073__3, count_1686000074__4, i_1686000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_621 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = seq_1686000072__7; if linked_622 == nil { x__8 = ifn_623.Invoke_O__O(arg_624) } else { x__8 = linked_622.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_621, arg_624) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_676 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = seq_1686000072__7; if linked_677 == nil { tmp11 = ifn_678.Invoke_O__O(arg_679) } else { tmp11 = linked_677.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_676, arg_679) }; seq_1686000072__2, chunk_1686000073__3, count_1686000074__4, i_1686000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_625 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_627 lang.IFn









											if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = f__1; if linked_626 == nil { tmp12 = ifn_627.Invoke_O__O(arg_628) } else { tmp12 = linked_626.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_625, arg_628) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1686000076__2 any; var root_629 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_631 lang.IFn









												if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = f__1; if linked_630 == nil { seq_1686000076__2 = ifn_631.Invoke_O__O(arg_632) } else { seq_1686000076__2 = linked_630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_629, arg_632) }
//line :137:1
												var chunk_1686000077__3 any; var count_1686000078__4 int64 = 0; var i_1686000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000079__5, count_1686000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1686000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1686000076__2, chunk_1686000077__3, count_1686000078__4, i_1686000079__5 = seq_1686000076__2, chunk_1686000077__3, count_1686000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_633 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seq_1686000076__2; if linked_634 == nil { temp__1927000414__auto____6_2 = ifn_635.Invoke_O__O(arg_636) } else { temp__1927000414__auto____6_2 = linked_634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1686000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_637 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seq_1686000076__7; if linked_638 == nil { tmp13 = ifn_639.Invoke_O__O(arg_640) } else { tmp13 = linked_638.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_637, arg_640) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_641 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = seq_1686000076__7; if linked_642 == nil { c__1927000678__auto____8_2 = ifn_643.Invoke_O__O(arg_644) } else { c__1927000678__auto____8_2 = linked_642.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_641, arg_644) }; var tmp14 any; var root_680 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq_1686000076__7; if linked_681 == nil { tmp14 = ifn_682.Invoke_O__O(arg_683) } else { tmp14 = linked_681.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_680, arg_683) }; seq_1686000076__2, chunk_1686000077__3, count_1686000078__4, i_1686000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_645 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = seq_1686000076__7; if linked_646 == nil { x__8_2 = ifn_647.Invoke_O__O(arg_648) } else { x__8_2 = linked_646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_645, arg_648) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_684 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = seq_1686000076__7; if linked_685 == nil { tmp15 = ifn_686.Invoke_O__O(arg_687) } else { tmp15 = linked_685.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_684, arg_687) }; seq_1686000076__2, chunk_1686000077__3, count_1686000078__4, i_1686000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_number_local_types_BANG__A_New() *A_arbace_go_check_number_local_types_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Invoke_O_O__O(self, lts__0 any) any { { var sorted__2 any; var root_702 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_704 lang.IFn





	if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var fnbody__708 any = A_arbace_go_check_number_local_types_BANG__fn__1686000083_A_New(); var tmp1 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1686000083_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_go_check_number_local_types_BANG__fn__1686000083_A_fn_class = fncls__707d; tmp1 = fncls__707d } else { tmp1 = fncls__707 }; arg_705 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__708, tmp1, nil); var arg_706 any; var root_709 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any; var fnbody__715 any = A_arbace_go_check_number_local_types_BANG__fn__1686000089_A_New(); var tmp2 *jrt.Class; var fncls__714 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1686000089_A_fn_class; if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_go_check_number_local_types_BANG__fn__1686000089_A_fn_class = fncls__714d; tmp2 = fncls__714d } else { tmp2 = fncls__714 }; arg_712 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__715, tmp2, nil); var arg_713 any = lts__0; if linked_710 == nil { arg_706 = ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { arg_706 = linked_710.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) }; if linked_703 == nil { sorted__2 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { sorted__2 = linked_703.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }
//line :151:1
	var seq_1686000094__3 any; var root_716 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn






	if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any; var root_720 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = A_arbace_go_check_A_const_104.GetRawRoot__O(); var arg_724 any = sorted__2; if linked_721 == nil { arg_719 = ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { arg_719 = linked_721.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) }; if linked_717 == nil { seq_1686000094__3 = ifn_718.Invoke_O__O(arg_719) } else { seq_1686000094__3 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }
//line :151:1
	var chunk_1686000095__4 any; var count_1686000096__5 int64 = 0; var i_1686000097__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000097__6, count_1686000096__5) { var vec__1686000098__7 any = lang.Indexed_Cast(chunk_1686000095__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000097__6)); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000098__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1686000101__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000098__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000101__9, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000101__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var tmp5 any = A_arbace_go_check_A_const_107; var tmp6 jrt.Number_I; var na_748 any = n__8; _ = ___10
			if jrt.Long_InstanceOf(na_748) { var n0_749 int64 = jrt.NN(jrt.Long_Cast(na_748)).LongValue__J(); if n0_749 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_748) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_749 + 1)) } } else { if jrt.Double_InstanceOf(na_748) { var n0_749_2 float64 = jrt.NN(jrt.Double_Cast(na_748)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_749_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_748) } }; tmp3.Invoke_O_O_O_O__O(nt__11, tmp4, tmp5, tmp6)
//line :158:1
			seq_1686000094__3, chunk_1686000095__4, count_1686000096__5, i_1686000097__6 = seq_1686000094__3, chunk_1686000095__4, count_1686000096__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000097__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_725 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1686000094__3; if linked_726 == nil { temp__1927000414__auto____7 = ifn_727.Invoke_O__O(arg_728) } else { temp__1927000414__auto____7 = linked_726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_725, arg_728) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1686000094__8 any = temp__1927000414__auto____7; var tmp7 any; var root_729 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_1686000094__8; if linked_730 == nil { tmp7 = ifn_731.Invoke_O__O(arg_732) } else { tmp7 = linked_730.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_733 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = seq_1686000094__8; if linked_734 == nil { c__1927000678__auto____9 = ifn_735.Invoke_O__O(arg_736) } else { c__1927000678__auto____9 = linked_734.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_733, arg_736) }; var tmp8 any; var root_750 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = seq_1686000094__8; if linked_751 == nil { tmp8 = ifn_752.Invoke_O__O(arg_753) } else { tmp8 = linked_751.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_750, arg_753) }; seq_1686000094__3, chunk_1686000095__4, count_1686000096__5, i_1686000097__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1686000104__9 any; var root_737 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = seq_1686000094__8; if linked_738 == nil { vec__1686000104__9 = ifn_739.Invoke_O__O(arg_740) } else { vec__1686000104__9 = linked_738.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_737, arg_740) }; var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000104__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1686000107__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000104__9, lang.RT_IntCast_J__I_NoInit(1), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp10 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var tmp11 any = A_arbace_go_check_A_const_107; var tmp12 jrt.Number_I; var na_761 any = n__10; _ = ___12
				if jrt.Long_InstanceOf(na_761) { var n0_762 int64 = jrt.NN(jrt.Long_Cast(na_761)).LongValue__J(); if n0_762 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_761) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_762 + 1)) } } else { if jrt.Double_InstanceOf(na_761) { var n0_762_2 float64 = jrt.NN(jrt.Double_Cast(na_761)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_762_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_761) } }; tmp9.Invoke_O_O_O_O__O(nt__13, tmp10, tmp11, tmp12)
//line :158:1
				var tmp13 any; var root_763 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = seq_1686000094__8; if linked_764 == nil { tmp13 = ifn_765.Invoke_O__O(arg_766) } else { tmp13 = linked_764.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_763, arg_766) }; seq_1686000094__3, chunk_1686000095__4, count_1686000096__5, i_1686000097__6 = tmp13, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :151:1*/panic("j2g: unreachable") }





func A_arbace_go_check_number_local_types_BANG__fn__1686000083_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1686000083_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1686000083_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1686000083_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1686000083_A) Invoke_O_O__O(self, p__1686000082__1 any) any { var vec__1686000084__2 any = p__1686000082__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000084__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000084__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000084__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(id__3, k__5) }
//line :157:1
func A_arbace_go_check_number_local_types_BANG__fn__1686000089_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1686000089_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1686000089_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1686000089_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1686000089_A) Invoke_O_O_O__O(self, k__1, p__1686000088__2 any) any { var vec__1686000090__3 any = p__1686000088__2; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000090__3, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000090__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(id__4, nt__5, k__1) }



func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1686000126__2 any) any { var map__1686000127__4 any = p__1686000126__2; var map__1686000127__5 any; if lang.ISeq_InstanceOf(map__1686000127__4) { var tmp1 any; var root_767 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = map__1686000127__4; if linked_768 == nil { tmp1 = ifn_769.Invoke_O__O(arg_770) } else { tmp1 = linked_768.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_767, arg_770) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_771 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = map__1686000127__4; if linked_772 == nil { tmp2 = ifn_773.Invoke_O__O(arg_774) } else { tmp2 = linked_772.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_771, arg_774) }; map__1686000127__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_775 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = map__1686000127__4; if linked_776 == nil { tmp3 = ifn_777.Invoke_O__O(arg_778) } else { tmp3 = linked_776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_775, arg_778) }; if jrt.J2g_Truth(tmp3) { var root_779 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = map__1686000127__4; if linked_780 == nil { map__1686000127__5 = ifn_781.Invoke_O__O(arg_782) } else { map__1686000127__5 = linked_780.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_779, arg_782) } } else { map__1686000127__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1686000127__5 = map__1686000127__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1686000127__5, A_arbace_go_check_A_const_109); var pkg_scope__7 any; var root_783 any = A_arbace_go_check_A_const_73.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_785 lang.IFn; if




	linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any; var arg_787 any = A_arbace_go_check_A_const_110; if linked_784 == nil { pkg_scope__7 = ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { pkg_scope__7 = linked_784.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_783, arg_786, arg_787) }; var pkg__8 any; var root_788 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_790 lang.IFn; if





	linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any; var tmp4 any = A_arbace_go_check_A_const_111; var tmp5 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_71; var tmp7 any = A_arbace_go_check_A_const_71.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_72; var tmp9 any = A_arbace_go_check_A_const_112; var tmp10 any = A_arbace_go_check_A_const_112.Invoke_O__O(src__0); var tmp11 any = A_arbace_go_check_A_const_113; var tmp12 any; var root_792 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_794 lang.IFn; if
	linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = lang.PersistentVector_EMPTY.Ref(); if linked_793 == nil { tmp12 = ifn_794.Invoke_O__O(arg_795) } else { tmp12 = linked_793.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_792, arg_795) }; arg_791 = /*line :167:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, tmp10, tmp11, tmp12)); if linked_789 == nil { pkg__8 = ifn_790.Invoke_O__O(arg_791) } else { pkg__8 = linked_789.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_788, arg_791) }; var errors__9 any; var root_796 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_798 lang.IFn; if







	linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = lang.PersistentVector_EMPTY.Ref(); if linked_797 == nil { errors__9 = ifn_798.Invoke_O__O(arg_799) } else { errors__9 = linked_797.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_796, arg_799) }; var resolving__10 any; var root_800 any = /*line :161:1*/A_arbace_go_check_A_const_114.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_802 lang.IFn; if










	linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = A_arbace_go_check_A_const_115.Invoke_O__O(src__0); if linked_801 == nil { resolving__10 = ifn_802.Invoke_O__O(arg_803) } else { resolving__10 = linked_801.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_800, arg_803) }; var annotated__11 any; var and__1927000168__auto____11 any; var root_804 any = /*line :161:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_806 lang.IFn; if











	linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = A_arbace_go_check_A_const_82.Invoke_O__O(src__0); var arg_808 any = A_arbace_go_check_A_const_116; if linked_805 == nil { and__1927000168__auto____11 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { and__1927000168__auto____11 = linked_805.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_809 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = resolving__10; if linked_810 == nil { annotated__11 = ifn_811.Invoke_O__O(arg_812) } else { annotated__11 = linked_810.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_809, arg_812) } } else { annotated__11 = and__1927000168__auto____11 }; var ctx__12 any; var tmp13 any = A_arbace_go_check_A_const_117; var tmp14 any; var root_813 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_815 lang.IFn; if












	linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = lang.PersistentVector_EMPTY.Ref(); if linked_814 == nil { tmp14 = ifn_815.Invoke_O__O(arg_816) } else { tmp14 = linked_814.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_813, arg_816) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_118; var tmp17 any; var root_817 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_819 lang.IFn; if












	linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_818 == nil { tmp17 = ifn_819.Invoke_O__O(arg_820) } else { tmp17 = linked_818.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_817, arg_820) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_119; var tmp20 any; var root_821 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_823 lang.IFn; if












	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = lang.PersistentVector_EMPTY.Ref(); if linked_822 == nil { tmp20 = ifn_823.Invoke_O__O(arg_824) } else { tmp20 = linked_822.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_821, arg_824) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_120; var tmp23 any; var root_825 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_827 lang.IFn; if












	linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = lang.PersistentVector_EMPTY.Ref(); if linked_826 == nil { tmp23 = ifn_827.Invoke_O__O(arg_828) } else { tmp23 = linked_826.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_825, arg_828) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_go_check_A_const_121; ctx__12 = /*line :161:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_61, annotated__11, A_arbace_go_check_A_const_122, resolving__10)))); var fis__13 any; var root_829 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_831 lang.IFn; if














	linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var fnbody__841 any = A_arbace_go_check_check_package_fn__1686000129_A_New_O_O(src__0, pkg_scope__7); var tmp26 *jrt.Class; var fncls__840 *jrt.Class = A_arbace_go_check_check_package_fn__1686000129_A_fn_class; if fncls__840 == nil { var fncls__840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__841); A_arbace_go_check_check_package_fn__1686000129_A_fn_class = fncls__840d; tmp26 = fncls__840d } else { tmp26 = fncls__840 }; arg_832 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__841, tmp26, nil); var arg_833 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__0); if linked_830 == nil { fis__13 = ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { fis__13 = linked_830.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) }; var root_1332 any =
	A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()); var tmp28 any = A_arbace_go_check_A_const_173; var tmp29 any = A_arbace_go_check_A_const_174; var tmp30 any = A_arbace_go_check_A_const_175; var tmp31 any = jrt.IdentityHashMap_New(); var tmp32 any = A_arbace_go_check_A_const_176; var tmp33 any = A_arbace_go_check_A_const_177; var tmp34 any = A_arbace_go_check_A_const_115.Invoke_O__O(src__0); var tmp35 any = A_arbace_go_check_A_const_178; var tmp36 any = jrt.Boolean_TRUE.Ref(); var tmp37 any = A_arbace_go_check_A_const_62; var tmp38 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_61, annotated__11, A_arbace_go_check_A_const_122, resolving__10)); var tmp39 any = A_arbace_go_check_A_const_179; var tmp40 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var tmp41 any = A_arbace_go_check_A_const_181; var tmp42 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var tmp43 any = A_arbace_go_check_A_const_183; var tmp44 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp45 any = A_arbace_go_check_A_const_184; var tmp46 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var tmp47 any = A_arbace_go_check_A_const_186; var tmp48 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var tmp49 any = A_arbace_go_check_A_const_188; var tmp50 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var tmp51 any = A_arbace_go_check_A_const_190; var tmp52 *lang.Compiler_AOTFn; var fnbody__1341 any = A_arbace_go_check_check_package_fn__1686000131_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp53 *jrt.Class; var fncls__1340 *jrt.Class = A_arbace_go_check_check_package_fn__1686000131_A_fn_class; if












	fncls__1340 == nil { var fncls__1340d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__1341); A_arbace_go_check_check_package_fn__1686000131_A_fn_class = fncls__1340d; tmp53 = fncls__1340d } else { tmp53 = fncls__1340 }; tmp52 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1341, tmp53, nil); var tmp54 any = /*line :177:1*/tmp52.Ref(); var tmp55 any = A_arbace_go_check_A_const_192; var tmp56 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var tmp57 any = A_arbace_go_check_A_const_194; var tmp58 any = A_arbace_go_check_A_const_195.GetRawRoot__O(); var tmp59 any = A_arbace_go_check_A_const_196; var tmp60 any = A_arbace_go_check_A_const_197.GetRawRoot__O(); var tmp61 any = A_arbace_go_check_A_const_198; var tmp62 any; var root_1342 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1344 lang.IFn; if

















	linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = lang.PersistentVector_EMPTY.Ref(); if linked_1343 == nil { tmp62 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp62 = linked_1343.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1342, arg_1345) }; var tmp63 any = tmp62; var tmp64 any = A_arbace_go_check_A_const_199; var tmp65 any; var root_1346 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1348 lang.IFn; if


















	linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_200, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_201, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_202, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_203, lang.PersistentArrayMap_EMPTY.Ref())); if linked_1347 == nil { tmp65 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp65 = linked_1347.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1346, arg_1349) }; var tmp66 any = tmp65; var tmp67 any = A_arbace_go_check_A_const_204; var tmp68 any; var root_1350 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1352 lang.IFn; if



















	linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = lang.PersistentVector_EMPTY.Ref(); if linked_1351 == nil { tmp68 = ifn_1352.Invoke_O__O(arg_1353) } else { tmp68 = linked_1351.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1350, arg_1353) }; arg_1335 = /*line :177:1*/tmp27.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp28, pkg__8, tmp29, errors__9, tmp30, tmp31, tmp32, ctx__12, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp63, tmp64, tmp66, tmp67, tmp68)))); if linked_1333 == nil { ifn_1334.Invoke_O__O(arg_1335) } else { linked_1333.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1332, arg_1335) }; var tmp69 any; tmp322 := /*line :161:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





































		if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, A_arbace_go_check_A_const_71.Invoke_O__O(src__0)) { var seq_1686000133__16 any; var root_1354 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1356 lang.IFn
			if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = fis__13; if linked_1355 == nil { seq_1686000133__16 = ifn_1356.Invoke_O__O(arg_1357) } else { seq_1686000133__16 = linked_1355.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1354, arg_1357) }
//line :199:1
			var chunk_1686000134__17 any; var count_1686000135__18 int64 = 0; var i_1686000136__19 int64 = 0; L1: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000136__19, count_1686000135__18) { var fi__20 any = lang.Indexed_Cast(chunk_1686000134__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000136__19)); var root_1437 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__20); var arg_1441 any; var or__1927000174__auto____21 any = A_arbace_go_check_A_const_79.Invoke_O__O(fi__20); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_1441 = or__1927000174__auto____21 } else { arg_1441 = A_arbace_go_check_A_const_43 }; var arg_1442 any = A_arbace_go_check_A_const_207; var arg_1443 any = Lit_58; if linked_1438 == nil { ifn_1439.Invoke_O_O_O_O__O(arg_1440, arg_1441, arg_1442, arg_1443) } else { linked_1438.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1437, arg_1440, arg_1441, arg_1442, arg_1443) }; seq_1686000133__16, chunk_1686000134__17, count_1686000135__18, i_1686000136__19 = seq_1686000133__16, chunk_1686000134__17, count_1686000135__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000136__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_1358 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = seq_1686000133__16; if linked_1359 == nil { temp__1927000414__auto____20 = ifn_1360.Invoke_O__O(arg_1361) } else { temp__1927000414__auto____20 = linked_1359.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1358, arg_1361) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1686000133__21 any = temp__1927000414__auto____20; var tmp70 any; var root_1362 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = seq_1686000133__21; if linked_1363 == nil { tmp70 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp70 = linked_1363.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1362, arg_1365) }; if jrt.J2g_Truth(tmp70) { var c__1927000678__auto____22 any; var root_1366 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = seq_1686000133__21; if linked_1367 == nil { c__1927000678__auto____22 = ifn_1368.Invoke_O__O(arg_1369) } else { c__1927000678__auto____22 = linked_1367.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1366, arg_1369) }; var tmp71 any; var root_1444 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = seq_1686000133__21; if linked_1445 == nil { tmp71 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp71 = linked_1445.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1444, arg_1447) }; seq_1686000133__16, chunk_1686000134__17, count_1686000135__18, i_1686000136__19 = tmp71, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__22 any; var root_1370 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = seq_1686000133__21; if linked_1371 == nil { fi__22 = ifn_1372.Invoke_O__O(arg_1373) } else { fi__22 = linked_1371.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1370, arg_1373) }; var root_1448 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__22); var arg_1452 any; var or__1927000174__auto____23 any = A_arbace_go_check_A_const_79.Invoke_O__O(fi__22); if jrt.J2g_Truth(or__1927000174__auto____23) { arg_1452 = or__1927000174__auto____23 } else { arg_1452 = A_arbace_go_check_A_const_43 }; var arg_1453 any = A_arbace_go_check_A_const_207; var arg_1454 any = Lit_58; if linked_1449 == nil { ifn_1450.Invoke_O_O_O_O__O(arg_1451, arg_1452, arg_1453, arg_1454) } else { linked_1449.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1448, arg_1451, arg_1452, arg_1453, arg_1454) }; var tmp72 any; var root_1455 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = seq_1686000133__21; if linked_1456 == nil { tmp72 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp72 = linked_1456.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1455, arg_1458) }; seq_1686000133__16, chunk_1686000134__17, count_1686000135__18, i_1686000136__19 = tmp72, nil, 0, 0; continue L1 } } }
//line :199:1
				break L1 } }
//line :161:1
		{ var seq_1686000137__16 any; var root_1374 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1376 lang.IFn







































			if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = fis__13; if linked_1375 == nil { seq_1686000137__16 = ifn_1376.Invoke_O__O(arg_1377) } else { seq_1686000137__16 = linked_1375.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1374, arg_1377) }
//line :161:1
			var chunk_1686000138__17 any; var count_1686000139__18 int64 = 0; var i_1686000140__19 int64 = 0; L2: for {







































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000140__19, count_1686000139__18) { var fi__20_2 any = lang.Indexed_Cast(chunk_1686000138__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000140__19)); var root_1459 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = fi__20_2; var arg_1463 any = resolve__1; if linked_1460 == nil { ifn_1461.Invoke_O_O__O(arg_1462, arg_1463) } else { linked_1460.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1459, arg_1462, arg_1463) }; seq_1686000137__16, chunk_1686000138__17, count_1686000139__18, i_1686000140__19 = seq_1686000137__16, chunk_1686000138__17, count_1686000139__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000140__19); continue L2 } else { var temp__1927000414__auto____20_2 any; var root_1378 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = seq_1686000137__16; if linked_1379 == nil { temp__1927000414__auto____20_2 = ifn_1380.Invoke_O__O(arg_1381) } else { temp__1927000414__auto____20_2 = linked_1379.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1378, arg_1381) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1686000137__21 any = temp__1927000414__auto____20_2; var tmp73 any; var root_1382 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = seq_1686000137__21; if linked_1383 == nil { tmp73 = ifn_1384.Invoke_O__O(arg_1385) } else { tmp73 = linked_1383.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1382, arg_1385) }; if jrt.J2g_Truth(tmp73) { var c__1927000678__auto____22_2 any; var root_1386 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = seq_1686000137__21; if linked_1387 == nil { c__1927000678__auto____22_2 = ifn_1388.Invoke_O__O(arg_1389) } else { c__1927000678__auto____22_2 = linked_1387.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1386, arg_1389) }; var tmp74 any; var root_1464 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = seq_1686000137__21; if linked_1465 == nil { tmp74 = ifn_1466.Invoke_O__O(arg_1467) } else { tmp74 = linked_1465.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1464, arg_1467) }; seq_1686000137__16, chunk_1686000138__17, count_1686000139__18, i_1686000140__19 = tmp74, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__22_2 any; var root_1390 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = seq_1686000137__21; if linked_1391 == nil { fi__22_2 = ifn_1392.Invoke_O__O(arg_1393) } else { fi__22_2 = linked_1391.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1390, arg_1393) }; var root_1468 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = fi__22_2; var arg_1472 any = resolve__1; if linked_1469 == nil { ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { linked_1469.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) }; var tmp75 any; var root_1473 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = seq_1686000137__21; if linked_1474 == nil { tmp75 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp75 = linked_1474.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1473, arg_1476) }; seq_1686000137__16, chunk_1686000138__17, count_1686000139__18, i_1686000140__19 = tmp75, nil, 0, 0; continue L2 } } }
//line :161:1
				break L2 }; var seq_1686000141__16 any; var root_1394 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1396 lang.IFn








































			if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = fis__13; if linked_1395 == nil { seq_1686000141__16 = ifn_1396.Invoke_O__O(arg_1397) } else { seq_1686000141__16 = linked_1395.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1394, arg_1397) }
//line :161:1
			var chunk_1686000142__17 any; var count_1686000143__18 int64 = 0; var i_1686000144__19 int64 = 0; L3: for {








































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000144__19, count_1686000143__18) { var fi__20_3 any = lang.Indexed_Cast(chunk_1686000142__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000144__19)); var root_1477 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = fi__20_3; if linked_1478 == nil { ifn_1479.Invoke_O__O(arg_1480) } else { linked_1478.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1477, arg_1480) }; seq_1686000141__16, chunk_1686000142__17, count_1686000143__18, i_1686000144__19 = seq_1686000141__16, chunk_1686000142__17, count_1686000143__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000144__19); continue L3 } else { var temp__1927000414__auto____20_3 any; var root_1398 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = seq_1686000141__16; if linked_1399 == nil { temp__1927000414__auto____20_3 = ifn_1400.Invoke_O__O(arg_1401) } else { temp__1927000414__auto____20_3 = linked_1399.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1398, arg_1401) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1686000141__21 any = temp__1927000414__auto____20_3; var tmp76 any; var root_1402 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = seq_1686000141__21; if linked_1403 == nil { tmp76 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp76 = linked_1403.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1402, arg_1405) }; if jrt.J2g_Truth(tmp76) { var c__1927000678__auto____22_3 any; var root_1406 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = seq_1686000141__21; if linked_1407 == nil { c__1927000678__auto____22_3 = ifn_1408.Invoke_O__O(arg_1409) } else { c__1927000678__auto____22_3 = linked_1407.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1406, arg_1409) }; var tmp77 any; var root_1481 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = seq_1686000141__21; if linked_1482 == nil { tmp77 = ifn_1483.Invoke_O__O(arg_1484) } else { tmp77 = linked_1482.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1481, arg_1484) }; seq_1686000141__16, chunk_1686000142__17, count_1686000143__18, i_1686000144__19 = tmp77, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__22_3 any; var root_1410 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = seq_1686000141__21; if linked_1411 == nil { fi__22_3 = ifn_1412.Invoke_O__O(arg_1413) } else { fi__22_3 = linked_1411.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1410, arg_1413) }; var root_1485 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = fi__22_3; if linked_1486 == nil { ifn_1487.Invoke_O__O(arg_1488) } else { linked_1486.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1485, arg_1488) }; var tmp78 any; var root_1489 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = seq_1686000141__21; if linked_1490 == nil { tmp78 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp78 = linked_1490.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1489, arg_1492) }; seq_1686000141__16, chunk_1686000142__17, count_1686000143__18, i_1686000144__19 = tmp78, nil, 0, 0; continue L3 } } }
//line :161:1
				break L3 }; var seq_1686000145__16 any; var root_1414 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1416 lang.IFn









































			if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = fis__13; if linked_1415 == nil { seq_1686000145__16 = ifn_1416.Invoke_O__O(arg_1417) } else { seq_1686000145__16 = linked_1415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1414, arg_1417) }
//line :161:1
			var chunk_1686000146__17 any; var count_1686000147__18 int64 = 0; var i_1686000148__19 int64 = 0; L4: for {









































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000148__19, count_1686000147__18) { var fi__20_4 any = lang.Indexed_Cast(chunk_1686000146__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000148__19)); var root_1493 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = fi__20_4; if linked_1494 == nil { ifn_1495.Invoke_O__O(arg_1496) } else { linked_1494.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1493, arg_1496) }; seq_1686000145__16, chunk_1686000146__17, count_1686000147__18, i_1686000148__19 = seq_1686000145__16, chunk_1686000146__17, count_1686000147__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000148__19); continue L4 } else { var temp__1927000414__auto____20_4 any; var root_1418 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = seq_1686000145__16; if linked_1419 == nil { temp__1927000414__auto____20_4 = ifn_1420.Invoke_O__O(arg_1421) } else { temp__1927000414__auto____20_4 = linked_1419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1418, arg_1421) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1686000145__21 any = temp__1927000414__auto____20_4; var tmp79 any; var root_1422 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = seq_1686000145__21; if linked_1423 == nil { tmp79 = ifn_1424.Invoke_O__O(arg_1425) } else { tmp79 = linked_1423.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1422, arg_1425) }; if jrt.J2g_Truth(tmp79) { var c__1927000678__auto____22_4 any; var root_1426 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = seq_1686000145__21; if linked_1427 == nil { c__1927000678__auto____22_4 = ifn_1428.Invoke_O__O(arg_1429) } else { c__1927000678__auto____22_4 = linked_1427.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1426, arg_1429) }; var tmp80 any; var root_1497 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = seq_1686000145__21; if linked_1498 == nil { tmp80 = ifn_1499.Invoke_O__O(arg_1500) } else { tmp80 = linked_1498.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1497, arg_1500) }; seq_1686000145__16, chunk_1686000146__17, count_1686000147__18, i_1686000148__19 = tmp80, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var fi__22_4 any; var root_1430 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = seq_1686000145__21; if linked_1431 == nil { fi__22_4 = ifn_1432.Invoke_O__O(arg_1433) } else { fi__22_4 = linked_1431.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1430, arg_1433) }; var root_1501 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = fi__22_4; if linked_1502 == nil { ifn_1503.Invoke_O__O(arg_1504) } else { linked_1502.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1501, arg_1504) }; var tmp81 any; var root_1505 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = seq_1686000145__21; if linked_1506 == nil { tmp81 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp81 = linked_1506.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1505, arg_1508) }; seq_1686000145__16, chunk_1686000146__17, count_1686000147__18, i_1686000148__19 = tmp81, nil, 0, 0; continue L4 } } }
//line :161:1
				break L4
			}









































			var root_1434 any = A_arbace_go_check_A_const_205.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; if linked_1435 == nil { ifn_1436.Invoke__O() } else { linked_1435.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1434) }
//line :161:1
			var objs__16 any; var root_842 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_844 lang.IFn











































			if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = A_arbace_go_check_A_const_117.Invoke_O__O(ctx__12); if linked_843 == nil { objs__16 = ifn_844.Invoke_O__O(arg_845) } else { objs__16 = linked_843.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_842, arg_845) }
//line :161:1
			var seq_1686000149__17 any; var root_1509 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1511 lang.IFn












































			if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any; var root_1513 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = A_arbace_go_check_A_const_104.GetRawRoot__O(); var arg_1517 any = objs__16; if linked_1514 == nil { arg_1512 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { arg_1512 = linked_1514.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }; if linked_1510 == nil { seq_1686000149__17 = ifn_1511.Invoke_O__O(arg_1512) } else { seq_1686000149__17 = linked_1510.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1509, arg_1512) }
//line :161:1
			var chunk_1686000150__18 any; var count_1686000151__19 int64 = 0; var i_1686000152__20 int64 = 0; L5: for {












































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000152__20, count_1686000151__19) { var vec__1686000153__21 any = lang.Indexed_Cast(chunk_1686000150__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000152__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000153__21, lang.RT_IntCast_J__I_NoInit(0), nil); var x__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000153__21, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1711 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = x__23; var arg_1715 any = A_arbace_go_check_A_const_214; var arg_1716 any = i__22; if linked_1712 == nil { ifn_1713.Invoke_O_O_O__O(arg_1714, arg_1715, arg_1716) } else { linked_1712.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1711, arg_1714, arg_1715, arg_1716) }; seq_1686000149__17, chunk_1686000150__18, count_1686000151__19, i_1686000152__20 = seq_1686000149__17, chunk_1686000150__18, count_1686000151__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000152__20); continue L5 } else { var temp__1927000414__auto____21 any; var root_1518 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = seq_1686000149__17; if linked_1519 == nil { temp__1927000414__auto____21 = ifn_1520.Invoke_O__O(arg_1521) } else { temp__1927000414__auto____21 = linked_1519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1518, arg_1521) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1686000149__22 any = temp__1927000414__auto____21; var tmp82 any; var root_1522 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = seq_1686000149__22; if linked_1523 == nil { tmp82 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp82 = linked_1523.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1522, arg_1525) }; if jrt.J2g_Truth(tmp82) { var c__1927000678__auto____23 any; var root_1526 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = seq_1686000149__22; if linked_1527 == nil { c__1927000678__auto____23 = ifn_1528.Invoke_O__O(arg_1529) } else { c__1927000678__auto____23 = linked_1527.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1526, arg_1529) }; var tmp83 any; var root_1717 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = seq_1686000149__22; if linked_1718 == nil { tmp83 = ifn_1719.Invoke_O__O(arg_1720) } else { tmp83 = linked_1718.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1717, arg_1720) }; seq_1686000149__17, chunk_1686000150__18, count_1686000151__19, i_1686000152__20 = tmp83, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1686000156__23 any; var root_1530 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = seq_1686000149__22; if linked_1531 == nil { vec__1686000156__23 = ifn_1532.Invoke_O__O(arg_1533) } else { vec__1686000156__23 = linked_1531.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1530, arg_1533) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000156__23, lang.RT_IntCast_J__I_NoInit(0), nil); var x__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000156__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1721 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = x__25; var arg_1725 any = A_arbace_go_check_A_const_214; var arg_1726 any = i__24; if linked_1722 == nil { ifn_1723.Invoke_O_O_O__O(arg_1724, arg_1725, arg_1726) } else { linked_1722.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1721, arg_1724, arg_1725, arg_1726) }; var tmp84 any; var root_1727 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = seq_1686000149__22; if linked_1728 == nil { tmp84 = ifn_1729.Invoke_O__O(arg_1730) } else { tmp84 = linked_1728.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1727, arg_1730) }; seq_1686000149__17, chunk_1686000150__18, count_1686000151__19, i_1686000152__20 = tmp84, nil, 0, 0; continue L5 } } }
//line :161:1
				break L5
			}













































			var root_1534 any = A_arbace_go_check_A_const_211.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = objs__16; if linked_1535 == nil { ifn_1536.Invoke_O__O(arg_1537) } else { linked_1535.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A).Invoke_O_O__O(root_1534, arg_1537) }
//line :161:1
			var seq_1686000159__17 any; var root_1538 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1540 lang.IFn
















































			if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = objs__16; if linked_1539 == nil { seq_1686000159__17 = ifn_1540.Invoke_O__O(arg_1541) } else { seq_1686000159__17 = linked_1539.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1538, arg_1541) }
//line :161:1
			var chunk_1686000160__18 any; var count_1686000161__19 int64 = 0; var i_1686000162__20 int64 = 0; L6: for {
















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000162__20, count_1686000161__19) { var x__21 any = lang.Indexed_Cast(chunk_1686000160__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000162__20)); var tmp85 any; var and__1927000168__auto____22 bool; var tmp86 any = A_arbace_go_check_A_const_55; var tmp87 any; var root_1542 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = x__21; var arg_1546 any = A_arbace_go_check_A_const_94; if linked_1543 == nil { tmp87 = ifn_1544.Invoke_O_O__O(arg_1545, arg_1546) } else { tmp87 = linked_1543.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1542, arg_1545, arg_1546) }; and__1927000168__auto____22 = lang.Util_Equiv_O_O__Z_NoInit(tmp86, tmp87); if and__1927000168__auto____22 { var root_1547 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any; var root_1551 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = x__21; var arg_1555 any = A_arbace_go_check_A_const_212; if linked_1552 == nil { arg_1550 = ifn_1553.Invoke_O_O__O(arg_1554, arg_1555) } else { arg_1550 = linked_1552.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1551, arg_1554, arg_1555) }; if linked_1548 == nil { tmp85 = ifn_1549.Invoke_O__O(arg_1550) } else { tmp85 = linked_1548.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1547, arg_1550) } } else { tmp85 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22).Ref() }; if jrt.J2g_Truth(tmp85) { var root_1731 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = x__21; if linked_1732 == nil { ifn_1733.Invoke_O__O(arg_1734) } else { linked_1732.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1731, arg_1734) }; seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, i_1686000162__20 = seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000162__20); continue L6 } else { seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, i_1686000162__20 = seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000162__20); continue L6 } } else { var temp__1927000414__auto____21_2 any; var root_1556 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = seq_1686000159__17; if linked_1557 == nil { temp__1927000414__auto____21_2 = ifn_1558.Invoke_O__O(arg_1559) } else { temp__1927000414__auto____21_2 = linked_1557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1556, arg_1559) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1686000159__22 any = temp__1927000414__auto____21_2; var tmp88 any; var root_1560 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = seq_1686000159__22; if linked_1561 == nil { tmp88 = ifn_1562.Invoke_O__O(arg_1563) } else { tmp88 = linked_1561.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1560, arg_1563) }; if jrt.J2g_Truth(tmp88) { var c__1927000678__auto____23_2 any; var root_1564 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = seq_1686000159__22; if linked_1565 == nil { c__1927000678__auto____23_2 = ifn_1566.Invoke_O__O(arg_1567) } else { c__1927000678__auto____23_2 = linked_1565.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1564, arg_1567) }; var tmp89 any; var root_1735 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = seq_1686000159__22; if linked_1736 == nil { tmp89 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp89 = linked_1736.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1735, arg_1738) }; seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, i_1686000162__20 = tmp89, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__23_2 any; var root_1568 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = seq_1686000159__22; if linked_1569 == nil { x__23_2 = ifn_1570.Invoke_O__O(arg_1571) } else { x__23_2 = linked_1569.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1568, arg_1571) }; var tmp90 any; var and__1927000168__auto____24 bool; var tmp91 any = A_arbace_go_check_A_const_55; var tmp92 any; var root_1572 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = x__23_2; var arg_1576 any = A_arbace_go_check_A_const_94; if linked_1573 == nil { tmp92 = ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { tmp92 = linked_1573.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) }; and__1927000168__auto____24 = lang.Util_Equiv_O_O__Z_NoInit(tmp91, tmp92); if and__1927000168__auto____24 { var root_1577 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any; var root_1581 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = x__23_2; var arg_1585 any = A_arbace_go_check_A_const_212; if linked_1582 == nil { arg_1580 = ifn_1583.Invoke_O_O__O(arg_1584, arg_1585) } else { arg_1580 = linked_1582.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1581, arg_1584, arg_1585) }; if linked_1578 == nil { tmp90 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp90 = linked_1578.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1577, arg_1580) } } else { tmp90 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24).Ref() }; if jrt.J2g_Truth(tmp90) { var root_1739 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = x__23_2; if linked_1740 == nil { ifn_1741.Invoke_O__O(arg_1742) } else { linked_1740.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1739, arg_1742) }; var tmp93 any; var root_1743 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1745 lang.IFn; if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any = seq_1686000159__22; if linked_1744 == nil { tmp93 = ifn_1745.Invoke_O__O(arg_1746) } else { tmp93 = linked_1744.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1743, arg_1746) }; seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, i_1686000162__20 = tmp93, nil, 0, 0; continue L6 } else { var tmp94 any; var root_1747 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = seq_1686000159__22; if linked_1748 == nil { tmp94 = ifn_1749.Invoke_O__O(arg_1750) } else { tmp94 = linked_1748.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1747, arg_1750) }; seq_1686000159__17, chunk_1686000160__18, count_1686000161__19, i_1686000162__20 = tmp94, nil, 0, 0; continue L6 } } } }
//line :161:1
				break L6 }; var seq_1686000163__17 any; var root_1586 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1588 lang.IFn

















































			if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = objs__16; if linked_1587 == nil { seq_1686000163__17 = ifn_1588.Invoke_O__O(arg_1589) } else { seq_1686000163__17 = linked_1587.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1586, arg_1589) }
//line :161:1
			var chunk_1686000164__18 any; var count_1686000165__19 int64 = 0; var i_1686000166__20 int64 = 0; L7: for {

















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000166__20, count_1686000165__19) { var x__21_2 any = lang.Indexed_Cast(chunk_1686000164__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000166__20)); var tmp95 any; var and__1927000168__auto____22_2 bool; var tmp96 any = A_arbace_go_check_A_const_55; var tmp97 any; var root_1590 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = x__21_2; var arg_1594 any = A_arbace_go_check_A_const_94; if linked_1591 == nil { tmp97 = ifn_1592.Invoke_O_O__O(arg_1593, arg_1594) } else { tmp97 = linked_1591.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1590, arg_1593, arg_1594) }; and__1927000168__auto____22_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp96, tmp97); if and__1927000168__auto____22_2 { var root_1595 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = x__21_2; var arg_1599 any = A_arbace_go_check_A_const_212; if linked_1596 == nil { tmp95 = ifn_1597.Invoke_O_O__O(arg_1598, arg_1599) } else { tmp95 = linked_1596.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1595, arg_1598, arg_1599) } } else { tmp95 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22_2).Ref() }; if jrt.J2g_Truth(tmp95) { var root_1751 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = x__21_2; if linked_1752 == nil { ifn_1753.Invoke_O__O(arg_1754) } else { linked_1752.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1751, arg_1754) }; seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, i_1686000166__20 = seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000166__20); continue L7 } else { seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, i_1686000166__20 = seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000166__20); continue L7 } } else { var temp__1927000414__auto____21_3 any; var root_1600 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1602 lang.IFn; if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = seq_1686000163__17; if linked_1601 == nil { temp__1927000414__auto____21_3 = ifn_1602.Invoke_O__O(arg_1603) } else { temp__1927000414__auto____21_3 = linked_1601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1600, arg_1603) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1686000163__22 any = temp__1927000414__auto____21_3; var tmp98 any; var root_1604 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = seq_1686000163__22; if linked_1605 == nil { tmp98 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp98 = linked_1605.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1604, arg_1607) }; if jrt.J2g_Truth(tmp98) { var c__1927000678__auto____23_3 any; var root_1608 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = seq_1686000163__22; if linked_1609 == nil { c__1927000678__auto____23_3 = ifn_1610.Invoke_O__O(arg_1611) } else { c__1927000678__auto____23_3 = linked_1609.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1608, arg_1611) }; var tmp99 any; var root_1755 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1757 lang.IFn; if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = seq_1686000163__22; if linked_1756 == nil { tmp99 = ifn_1757.Invoke_O__O(arg_1758) } else { tmp99 = linked_1756.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1755, arg_1758) }; seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, i_1686000166__20 = tmp99, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__23_3 any; var root_1612 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = seq_1686000163__22; if linked_1613 == nil { x__23_3 = ifn_1614.Invoke_O__O(arg_1615) } else { x__23_3 = linked_1613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1612, arg_1615) }; var tmp100 any; var and__1927000168__auto____24_2 bool; var tmp101 any = A_arbace_go_check_A_const_55; var tmp102 any; var root_1616 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = x__23_3; var arg_1620 any = A_arbace_go_check_A_const_94; if linked_1617 == nil { tmp102 = ifn_1618.Invoke_O_O__O(arg_1619, arg_1620) } else { tmp102 = linked_1617.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1616, arg_1619, arg_1620) }; and__1927000168__auto____24_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp101, tmp102); if and__1927000168__auto____24_2 { var root_1621 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = x__23_3; var arg_1625 any = A_arbace_go_check_A_const_212; if linked_1622 == nil { tmp100 = ifn_1623.Invoke_O_O__O(arg_1624, arg_1625) } else { tmp100 = linked_1622.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1621, arg_1624, arg_1625) } } else { tmp100 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24_2).Ref() }; if jrt.J2g_Truth(tmp100) { var root_1759 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = x__23_3; if linked_1760 == nil { ifn_1761.Invoke_O__O(arg_1762) } else { linked_1760.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1759, arg_1762) }; var tmp103 any; var root_1763 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = seq_1686000163__22; if linked_1764 == nil { tmp103 = ifn_1765.Invoke_O__O(arg_1766) } else { tmp103 = linked_1764.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1763, arg_1766) }; seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, i_1686000166__20 = tmp103, nil, 0, 0; continue L7 } else { var tmp104 any; var root_1767 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1769 lang.IFn; if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = seq_1686000163__22; if linked_1768 == nil { tmp104 = ifn_1769.Invoke_O__O(arg_1770) } else { tmp104 = linked_1768.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1767, arg_1770) }; seq_1686000163__17, chunk_1686000164__18, count_1686000165__19, i_1686000166__20 = tmp104, nil, 0, 0; continue L7 } } } }
//line :161:1
				break L7 }; var seq_1686000167__17 any; var root_1626 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1628 lang.IFn


















































			if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = objs__16; if linked_1627 == nil { seq_1686000167__17 = ifn_1628.Invoke_O__O(arg_1629) } else { seq_1686000167__17 = linked_1627.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1626, arg_1629) }
//line :161:1
			var chunk_1686000168__18 any; var count_1686000169__19 int64 = 0; var i_1686000170__20 int64 = 0; L8: for {


















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000170__20, count_1686000169__19) { var x__21_3 any = lang.Indexed_Cast(chunk_1686000168__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000170__20)); var tmp105 any; var root_1630 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = A_arbace_go_check_A_const_55; var arg_1634 any; var root_1635 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = x__21_3; var arg_1639 any = A_arbace_go_check_A_const_94; if linked_1636 == nil { arg_1634 = ifn_1637.Invoke_O_O__O(arg_1638, arg_1639) } else { arg_1634 = linked_1636.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1635, arg_1638, arg_1639) }; if linked_1631 == nil { tmp105 = ifn_1632.Invoke_O_O__O(arg_1633, arg_1634) } else { tmp105 = linked_1631.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1630, arg_1633, arg_1634) }; if jrt.J2g_Truth(tmp105) { var root_1771 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = x__21_3; if linked_1772 == nil { ifn_1773.Invoke_O__O(arg_1774) } else { linked_1772.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1771, arg_1774) }; seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, i_1686000170__20 = seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000170__20); continue L8 } else { seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, i_1686000170__20 = seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000170__20); continue L8 } } else { var temp__1927000414__auto____21_4 any; var root_1640 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = seq_1686000167__17; if linked_1641 == nil { temp__1927000414__auto____21_4 = ifn_1642.Invoke_O__O(arg_1643) } else { temp__1927000414__auto____21_4 = linked_1641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1640, arg_1643) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1686000167__22 any = temp__1927000414__auto____21_4; var tmp106 any; var root_1644 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = seq_1686000167__22; if linked_1645 == nil { tmp106 = ifn_1646.Invoke_O__O(arg_1647) } else { tmp106 = linked_1645.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1644, arg_1647) }; if jrt.J2g_Truth(tmp106) { var c__1927000678__auto____23_4 any; var root_1648 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = seq_1686000167__22; if linked_1649 == nil { c__1927000678__auto____23_4 = ifn_1650.Invoke_O__O(arg_1651) } else { c__1927000678__auto____23_4 = linked_1649.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1648, arg_1651) }; var tmp107 any; var root_1775 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = seq_1686000167__22; if linked_1776 == nil { tmp107 = ifn_1777.Invoke_O__O(arg_1778) } else { tmp107 = linked_1776.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1775, arg_1778) }; seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, i_1686000170__20 = tmp107, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__23_4 any; var root_1652 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = seq_1686000167__22; if linked_1653 == nil { x__23_4 = ifn_1654.Invoke_O__O(arg_1655) } else { x__23_4 = linked_1653.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1652, arg_1655) }; var tmp108 any; var root_1656 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = A_arbace_go_check_A_const_55; var arg_1660 any; var root_1661 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = x__23_4; var arg_1665 any = A_arbace_go_check_A_const_94; if linked_1662 == nil { arg_1660 = ifn_1663.Invoke_O_O__O(arg_1664, arg_1665) } else { arg_1660 = linked_1662.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1661, arg_1664, arg_1665) }; if linked_1657 == nil { tmp108 = ifn_1658.Invoke_O_O__O(arg_1659, arg_1660) } else { tmp108 = linked_1657.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1656, arg_1659, arg_1660) }; if jrt.J2g_Truth(tmp108) { var root_1779 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = x__23_4; if linked_1780 == nil { ifn_1781.Invoke_O__O(arg_1782) } else { linked_1780.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1779, arg_1782) }; var tmp109 any; var root_1783 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = seq_1686000167__22; if linked_1784 == nil { tmp109 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp109 = linked_1784.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1783, arg_1786) }; seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, i_1686000170__20 = tmp109, nil, 0, 0; continue L8 } else { var tmp110 any; var root_1787 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = seq_1686000167__22; if linked_1788 == nil { tmp110 = ifn_1789.Invoke_O__O(arg_1790) } else { tmp110 = linked_1788.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1787, arg_1790) }; seq_1686000167__17, chunk_1686000168__18, count_1686000169__19, i_1686000170__20 = tmp110, nil, 0, 0; continue L8 } } } }
//line :161:1
				break L8 }; var seq_1686000171__17 any; var root_1666 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1668 lang.IFn




















































			if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any; var root_1670 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = A_arbace_go_check_A_const_119.Invoke_O__O(ctx__12); if linked_1671 == nil { arg_1669 = ifn_1672.Invoke_O__O(arg_1673) } else { arg_1669 = linked_1671.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1670, arg_1673) }; if linked_1667 == nil { seq_1686000171__17 = ifn_1668.Invoke_O__O(arg_1669) } else { seq_1686000171__17 = linked_1667.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1666, arg_1669) }
//line :161:1
			var chunk_1686000172__18 any; var count_1686000173__19 int64 = 0; var i_1686000174__20 int64 = 0; L9: for {




















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000174__20, count_1686000173__19) { var x__21_4 any = lang.Indexed_Cast(chunk_1686000172__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000174__20)); var root_1791 any = A_arbace_go_check_A_const_215.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = x__21_4; if linked_1792 == nil { ifn_1793.Invoke_O__O(arg_1794) } else { linked_1792.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1791, arg_1794) }; seq_1686000171__17, chunk_1686000172__18, count_1686000173__19, i_1686000174__20 = seq_1686000171__17, chunk_1686000172__18, count_1686000173__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000174__20); continue L9 } else { var temp__1927000414__auto____21_5 any; var root_1674 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = seq_1686000171__17; if linked_1675 == nil { temp__1927000414__auto____21_5 = ifn_1676.Invoke_O__O(arg_1677) } else { temp__1927000414__auto____21_5 = linked_1675.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1674, arg_1677) }; if jrt.J2g_Truth(temp__1927000414__auto____21_5) { var seq_1686000171__22 any = temp__1927000414__auto____21_5; var tmp111 any; var root_1678 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = seq_1686000171__22; if linked_1679 == nil { tmp111 = ifn_1680.Invoke_O__O(arg_1681) } else { tmp111 = linked_1679.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1678, arg_1681) }; if jrt.J2g_Truth(tmp111) { var c__1927000678__auto____23_5 any; var root_1682 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = seq_1686000171__22; if linked_1683 == nil { c__1927000678__auto____23_5 = ifn_1684.Invoke_O__O(arg_1685) } else { c__1927000678__auto____23_5 = linked_1683.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1682, arg_1685) }; var tmp112 any; var root_1795 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = seq_1686000171__22; if linked_1796 == nil { tmp112 = ifn_1797.Invoke_O__O(arg_1798) } else { tmp112 = linked_1796.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1795, arg_1798) }; seq_1686000171__17, chunk_1686000172__18, count_1686000173__19, i_1686000174__20 = tmp112, c__1927000678__auto____23_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L9 } else { var x__23_5 any; var root_1686 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = seq_1686000171__22; if linked_1687 == nil { x__23_5 = ifn_1688.Invoke_O__O(arg_1689) } else { x__23_5 = linked_1687.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1686, arg_1689) }; var root_1799 any = A_arbace_go_check_A_const_215.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = x__23_5; if linked_1800 == nil { ifn_1801.Invoke_O__O(arg_1802) } else { linked_1800.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1799, arg_1802) }; var tmp113 any; var root_1803 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = seq_1686000171__22; if linked_1804 == nil { tmp113 = ifn_1805.Invoke_O__O(arg_1806) } else { tmp113 = linked_1804.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1803, arg_1806) }; seq_1686000171__17, chunk_1686000172__18, count_1686000173__19, i_1686000174__20 = tmp113, nil, 0, 0; continue L9 } } }
//line :161:1
				break L9 }; L10: for { var vs__17 any; var root_1690 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1692 lang.IFn























































					if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = A_arbace_go_check_A_const_198.Get__O(); if linked_1691 == nil { vs__17 = ifn_1692.Invoke_O__O(arg_1693) } else { vs__17 = linked_1691.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1690, arg_1693) }
					var tmp114 any; var root_1694 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = vs__17; if linked_1695 == nil { tmp114 = ifn_1696.Invoke_O__O(arg_1697) } else { tmp114 = linked_1695.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1694, arg_1697) }; if jrt.J2g_Truth(tmp114) {
						var root_1807 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = A_arbace_go_check_A_const_198.Get__O(); var arg_1811 any = lang.PersistentVector_EMPTY.Ref(); if linked_1808 == nil { ifn_1809.Invoke_O_O__O(arg_1810, arg_1811) } else { linked_1808.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1807, arg_1810, arg_1811) }
//line :218:1
						var seq_1686000175__18 any; var root_1812 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1814 lang.IFn

						if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = vs__17; if linked_1813 == nil { seq_1686000175__18 = ifn_1814.Invoke_O__O(arg_1815) } else { seq_1686000175__18 = linked_1813.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1812, arg_1815) }
//line :218:1
						var chunk_1686000176__19 any; var count_1686000177__20 int64 = 0; var i_1686000178__21 int64 = 0; L11: for {

							if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000178__21, count_1686000177__20) { var v__22 any = lang.Indexed_Cast(chunk_1686000176__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000178__21)); lang.IFn_Cast(v__22).Invoke__O(); seq_1686000175__18, chunk_1686000176__19, count_1686000177__20, i_1686000178__21 = seq_1686000175__18, chunk_1686000176__19, count_1686000177__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000178__21); continue L11 } else { var temp__1927000414__auto____22 any; var root_1816 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1818 lang.IFn; if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any = seq_1686000175__18; if linked_1817 == nil { temp__1927000414__auto____22 = ifn_1818.Invoke_O__O(arg_1819) } else { temp__1927000414__auto____22 = linked_1817.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1816, arg_1819) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1686000175__23 any = temp__1927000414__auto____22; var tmp115 any; var root_1820 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = seq_1686000175__23; if linked_1821 == nil { tmp115 = ifn_1822.Invoke_O__O(arg_1823) } else { tmp115 = linked_1821.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1820, arg_1823) }; if jrt.J2g_Truth(tmp115) { var c__1927000678__auto____24 any; var root_1824 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = seq_1686000175__23; if linked_1825 == nil { c__1927000678__auto____24 = ifn_1826.Invoke_O__O(arg_1827) } else { c__1927000678__auto____24 = linked_1825.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1824, arg_1827) }; var tmp116 any; var root_1832 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = seq_1686000175__23; if linked_1833 == nil { tmp116 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp116 = linked_1833.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1832, arg_1835) }; seq_1686000175__18, chunk_1686000176__19, count_1686000177__20, i_1686000178__21 = tmp116, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var v__24 any; var root_1828 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = seq_1686000175__23; if linked_1829 == nil { v__24 = ifn_1830.Invoke_O__O(arg_1831) } else { v__24 = linked_1829.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1828, arg_1831) }; lang.IFn_Cast(v__24).Invoke__O(); var tmp117 any; var root_1836 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = seq_1686000175__23; if linked_1837 == nil { tmp117 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp117 = linked_1837.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1836, arg_1839) }; seq_1686000175__18, chunk_1686000176__19, count_1686000177__20, i_1686000178__21 = tmp117, nil, 0, 0; continue L11 } } }
//line :218:1
							break L11
						}

						continue L10 }
//line :161:1
					break L10
				}



























































			var root_1698 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, A_arbace_go_check_number_local_types_BANG__A_fn_class); var ifn_1700 lang.IFn; if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any; var root_1702 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1704 lang.IFn; if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any; var root_1706 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = pkg__8; var arg_1710 any = A_arbace_go_check_A_const_113; if linked_1707 == nil { arg_1705 = ifn_1708.Invoke_O_O__O(arg_1709, arg_1710) } else { arg_1705 = linked_1707.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1706, arg_1709, arg_1710) }; if linked_1703 == nil { arg_1701 = ifn_1704.Invoke_O__O(arg_1705) } else { arg_1701 = linked_1703.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1702, arg_1705) }; if linked_1699 == nil { ifn_1700.Invoke_O__O(arg_1701) } else { linked_1699.(*A_arbace_go_check_number_local_types_BANG__A).Invoke_O_O__O(root_1698, arg_1701) }
//line :161:1
			var decls__17 any; var root_846 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_848 lang.IFn





























































			if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var fnbody__861 any = A_arbace_go_check_check_package_fn__1686000179_A_New(); var tmp118 *jrt.Class; var fncls__860 *jrt.Class = A_arbace_go_check_check_package_fn__1686000179_A_fn_class; if fncls__860 == nil { var fncls__860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_go_check_check_package_fn__1686000179_A_fn_class = fncls__860d; tmp118 = fncls__860d } else { tmp118 = fncls__860 }; arg_853 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__861, tmp118, nil); var arg_854 any = objs__16; if linked_851 == nil { arg_849 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_847 == nil { decls__17 = ifn_848.Invoke_O__O(arg_849) } else { decls__17 = linked_847.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_846, arg_849) }
//line :161:1
			var seq_1686000181__18 any; var root_1840 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1842 lang.IFn






























































			if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = decls__17; if linked_1841 == nil { seq_1686000181__18 = ifn_1842.Invoke_O__O(arg_1843) } else { seq_1686000181__18 = linked_1841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1840, arg_1843) }
//line :161:1
			var chunk_1686000182__19 any; var count_1686000183__20 int64 = 0; var i_1686000184__21 int64 = 0; L12: for {






























































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000184__21, count_1686000183__20) { var d__22 any = lang.Indexed_Cast(chunk_1686000182__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000184__21)); L13: for { var ls__23 any; var tmp119 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp120 any; var root_1964 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1966 lang.IFn

					if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = d__22; if linked_1965 == nil { tmp120 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp120 = linked_1965.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1964, arg_1967) }; ls__23 = tmp119.Invoke_O__O(tmp120)
					var tmp121 any; var root_1968 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = ls__23; if linked_1969 == nil { tmp121 = ifn_1970.Invoke_O__O(arg_1971) } else { tmp121 = linked_1969.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1968, arg_1971) }; if jrt.J2g_Truth(tmp121) {
						var tmp122 *lang.Volatile = lang.Volatile_Cast(d__22); var tmp123 any; var root_1972 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = jrt.NN(lang.Volatile_Cast(d__22)).Deref__O(); var arg_1976 any = A_arbace_go_check_A_const_218; var arg_1977 any = lang.PersistentVector_EMPTY.Ref(); if linked_1973 == nil { tmp123 = ifn_1974.Invoke_O_O_O__O(arg_1975, arg_1976, arg_1977) } else { tmp123 = linked_1973.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1972, arg_1975, arg_1976, arg_1977) }; jrt.NN(tmp122).Reset_O__O(tmp123)
						var root_2025 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any; var tmp124 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()); var tmp125 any = A_arbace_go_check_A_const_222; var tmp126 any = A_arbace_go_check_A_const_223; var tmp127 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp128 any; var root_2038 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = d__22; if linked_2039 == nil { tmp128 = ifn_2040.Invoke_O__O(arg_2041) } else { tmp128 = linked_2039.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2038, arg_2041) }; var tmp129 any = tmp127.Invoke_O__O(tmp128); var tmp130 any = A_arbace_go_check_A_const_224; var tmp131 any; var G__1686000185__24_ any; var tmp132 *lang.Keyword = A_arbace_go_check_A_const_225; var tmp133 any; var root_2042 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = d__22; if linked_2043 == nil { tmp133 = ifn_2044.Invoke_O__O(arg_2045) } else { tmp133 = linked_2043.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2042, arg_2045) }; G__1686000185__24_ = tmp132.Invoke_O__O(tmp133); if lang.Util_Identical_O_O__Z_NoInit(G__1686000185__24_, nil) { tmp131 = nil } else { var root_2046 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = G__1686000185__24_; var arg_2050 any = A_arbace_go_check_A_const_79; if linked_2047 == nil { tmp131 = ifn_2048.Invoke_O_O__O(arg_2049, arg_2050) } else { tmp131 = linked_2047.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2046, arg_2049, arg_2050) } }; arg_2028 = tmp124.Invoke_O_O_O_O_O_O__O(tmp125, d__22, tmp126, tmp129, tmp130, tmp131); if linked_2026 == nil { ifn_2027.Invoke_O__O(arg_2028) } else { linked_2026.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2025, arg_2028) }; var tmp134 *lang.Compiler_AOTFn; var fnbody__2024 any = A_arbace_go_check_check_package_fn__1686000186_A_New_O_O(d__22, ls__23); var tmp135 *jrt.Class; var fncls__2023 *jrt.Class = A_arbace_go_check_check_package_fn__1686000186_A_fn_class; if fncls__2023 == nil { var fncls__2023d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__2024); A_arbace_go_check_check_package_fn__1686000186_A_fn_class = fncls__2023d; tmp135 = fncls__2023d } else { tmp135 = fncls__2023 }; tmp134 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2024, tmp135, nil); Up_Compiler_AOTFn_IFn(tmp134).Invoke__O()


						continue L13 }
//line :224:1
					break L13 }; seq_1686000181__18, chunk_1686000182__19, count_1686000183__20, i_1686000184__21 = seq_1686000181__18, chunk_1686000182__19, count_1686000183__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000184__21); continue L12 } else { var temp__1927000414__auto____22_2 any; var root_1844 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = seq_1686000181__18; if linked_1845 == nil { temp__1927000414__auto____22_2 = ifn_1846.Invoke_O__O(arg_1847) } else { temp__1927000414__auto____22_2 = linked_1845.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1844, arg_1847) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1686000181__23 any = temp__1927000414__auto____22_2; var tmp136 any; var root_1848 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = seq_1686000181__23; if linked_1849 == nil { tmp136 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp136 = linked_1849.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1848, arg_1851) }; if jrt.J2g_Truth(tmp136) { var c__1927000678__auto____24_2 any; var root_1852 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = seq_1686000181__23; if linked_1853 == nil { c__1927000678__auto____24_2 = ifn_1854.Invoke_O__O(arg_1855) } else { c__1927000678__auto____24_2 = linked_1853.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1852, arg_1855) }; var tmp137 any; var root_2051 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2051, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2053 lang.IFn; if linked_2052 == nil { ifn_2053 = lang.IFn_Cast(root_2051) } else { ifn_2053 = nil }; var arg_2054 any = seq_1686000181__23; if linked_2052 == nil { tmp137 = ifn_2053.Invoke_O__O(arg_2054) } else { tmp137 = linked_2052.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2051, arg_2054) }; seq_1686000181__18, chunk_1686000182__19, count_1686000183__20, i_1686000184__21 = tmp137, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__24 any; var root_1856 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = seq_1686000181__23; if linked_1857 == nil { d__24 = ifn_1858.Invoke_O__O(arg_1859) } else { d__24 = linked_1857.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1856, arg_1859) }; L14: for { var ls__25 any; var tmp138 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp139 any; var root_2055 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2057 lang.IFn

						if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any = d__24; if linked_2056 == nil { tmp139 = ifn_2057.Invoke_O__O(arg_2058) } else { tmp139 = linked_2056.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2055, arg_2058) }; ls__25 = tmp138.Invoke_O__O(tmp139)
						var tmp140 any; var root_2059 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = ls__25; if linked_2060 == nil { tmp140 = ifn_2061.Invoke_O__O(arg_2062) } else { tmp140 = linked_2060.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2059, arg_2062) }; if jrt.J2g_Truth(tmp140) {
							var tmp141 *lang.Volatile = lang.Volatile_Cast(d__24); var tmp142 any; var root_2063 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = jrt.NN(lang.Volatile_Cast(d__24)).Deref__O(); var arg_2067 any = A_arbace_go_check_A_const_218; var arg_2068 any = lang.PersistentVector_EMPTY.Ref(); if linked_2064 == nil { tmp142 = ifn_2065.Invoke_O_O_O__O(arg_2066, arg_2067, arg_2068) } else { tmp142 = linked_2064.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2063, arg_2066, arg_2067, arg_2068) }; jrt.NN(tmp141).Reset_O__O(tmp142)
							var root_2116 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any; var tmp143 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()); var tmp144 any = A_arbace_go_check_A_const_222; var tmp145 any = A_arbace_go_check_A_const_223; var tmp146 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp147 any; var root_2129 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = d__24; if linked_2130 == nil { tmp147 = ifn_2131.Invoke_O__O(arg_2132) } else { tmp147 = linked_2130.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2129, arg_2132) }; var tmp148 any = tmp146.Invoke_O__O(tmp147); var tmp149 any = A_arbace_go_check_A_const_224; var tmp150 any; var G__1686000192__26_ any; var tmp151 *lang.Keyword = A_arbace_go_check_A_const_225; var tmp152 any; var root_2133 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2133, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2135 lang.IFn; if linked_2134 == nil { ifn_2135 = lang.IFn_Cast(root_2133) } else { ifn_2135 = nil }; var arg_2136 any = d__24; if linked_2134 == nil { tmp152 = ifn_2135.Invoke_O__O(arg_2136) } else { tmp152 = linked_2134.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2133, arg_2136) }; G__1686000192__26_ = tmp151.Invoke_O__O(tmp152); if lang.Util_Identical_O_O__Z_NoInit(G__1686000192__26_, nil) { tmp150 = nil } else { var root_2137 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2137, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2139 lang.IFn; if linked_2138 == nil { ifn_2139 = lang.IFn_Cast(root_2137) } else { ifn_2139 = nil }; var arg_2140 any = G__1686000192__26_; var arg_2141 any = A_arbace_go_check_A_const_79; if linked_2138 == nil { tmp150 = ifn_2139.Invoke_O_O__O(arg_2140, arg_2141) } else { tmp150 = linked_2138.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2137, arg_2140, arg_2141) } }; arg_2119 = tmp143.Invoke_O_O_O_O_O_O__O(tmp144, d__24, tmp145, tmp148, tmp149, tmp150); if linked_2117 == nil { ifn_2118.Invoke_O__O(arg_2119) } else { linked_2117.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2116, arg_2119) }; var tmp153 *lang.Compiler_AOTFn; var fnbody__2115 any = A_arbace_go_check_check_package_fn__1686000193_A_New_O_O(d__24, ls__25); var tmp154 *jrt.Class; var fncls__2114 *jrt.Class = A_arbace_go_check_check_package_fn__1686000193_A_fn_class; if fncls__2114 == nil { var fncls__2114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__2115); A_arbace_go_check_check_package_fn__1686000193_A_fn_class = fncls__2114d; tmp154 = fncls__2114d } else { tmp154 = fncls__2114 }; tmp153 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2115, tmp154, nil); Up_Compiler_AOTFn_IFn(tmp153).Invoke__O()


							continue L14 }
//line :224:1
						break L14 }; var tmp155 any; var root_2142 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = seq_1686000181__23; if linked_2143 == nil { tmp155 = ifn_2144.Invoke_O__O(arg_2145) } else { tmp155 = linked_2143.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2142, arg_2145) }; seq_1686000181__18, chunk_1686000182__19, count_1686000183__20, i_1686000184__21 = tmp155, nil, 0, 0; continue L12 } } }
//line :161:1
				break L12 }; var seq_1686000199__18 any; var root_1860 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1862 lang.IFn








































































			if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = decls__17; if linked_1861 == nil { seq_1686000199__18 = ifn_1862.Invoke_O__O(arg_1863) } else { seq_1686000199__18 = linked_1861.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1860, arg_1863) }
//line :161:1
			var chunk_1686000200__19 any; var count_1686000201__20 int64 = 0; var i_1686000202__21 int64 = 0; L15: for {








































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000202__21, count_1686000201__20) { var d__22_2 any = lang.Indexed_Cast(chunk_1686000200__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000202__21)); var tmp156 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp157 any; var root_1864 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = d__22_2; if linked_1865 == nil { tmp157 = ifn_1866.Invoke_O__O(arg_1867) } else { tmp157 = linked_1865.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1864, arg_1867) }; if jrt.J2g_Truth(tmp156.Invoke_O__O(tmp157)) {
					var root_2159 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any; var tmp158 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()); var tmp159 any = A_arbace_go_check_A_const_222; var tmp160 any = A_arbace_go_check_A_const_223; var tmp161 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp162 any; var root_2170 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any = d__22_2; if linked_2171 == nil { tmp162 = ifn_2172.Invoke_O__O(arg_2173) } else { tmp162 = linked_2171.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2170, arg_2173) }; arg_2162 = tmp158.Invoke_O_O_O_O__O(tmp159, d__22_2, tmp160, tmp161.Invoke_O__O(tmp162)); if linked_2160 == nil { ifn_2161.Invoke_O__O(arg_2162) } else { linked_2160.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2159, arg_2162) }; var tmp163 *lang.Compiler_AOTFn; var fnbody__2158 any = A_arbace_go_check_check_package_fn__1686000203_A_New_O(d__22_2); var tmp164 *jrt.Class; var fncls__2157 *jrt.Class = A_arbace_go_check_check_package_fn__1686000203_A_fn_class; if fncls__2157 == nil { var fncls__2157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__2158); A_arbace_go_check_check_package_fn__1686000203_A_fn_class = fncls__2157d; tmp164 = fncls__2157d } else { tmp164 = fncls__2157 }; tmp163 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2158, tmp164, nil); Up_Compiler_AOTFn_IFn(tmp163).Invoke__O()
//line :234:1
					seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, i_1686000202__21 = seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000202__21); continue L15 } else { seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, i_1686000202__21 = seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000202__21); continue L15 } } else { var temp__1927000414__auto____22_3 any; var root_1868 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1870 lang.IFn; if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any = seq_1686000199__18; if linked_1869 == nil { temp__1927000414__auto____22_3 = ifn_1870.Invoke_O__O(arg_1871) } else { temp__1927000414__auto____22_3 = linked_1869.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1868, arg_1871) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1686000199__23 any = temp__1927000414__auto____22_3; var tmp165 any; var root_1872 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = seq_1686000199__23; if linked_1873 == nil { tmp165 = ifn_1874.Invoke_O__O(arg_1875) } else { tmp165 = linked_1873.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1872, arg_1875) }; if jrt.J2g_Truth(tmp165) { var c__1927000678__auto____24_3 any; var root_1876 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = seq_1686000199__23; if linked_1877 == nil { c__1927000678__auto____24_3 = ifn_1878.Invoke_O__O(arg_1879) } else { c__1927000678__auto____24_3 = linked_1877.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1876, arg_1879) }; var tmp166 any; var root_2174 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2174, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2176 lang.IFn; if linked_2175 == nil { ifn_2176 = lang.IFn_Cast(root_2174) } else { ifn_2176 = nil }; var arg_2177 any = seq_1686000199__23; if linked_2175 == nil { tmp166 = ifn_2176.Invoke_O__O(arg_2177) } else { tmp166 = linked_2175.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2174, arg_2177) }; seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, i_1686000202__21 = tmp166, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__24_2 any; var root_1880 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = seq_1686000199__23; if linked_1881 == nil { d__24_2 = ifn_1882.Invoke_O__O(arg_1883) } else { d__24_2 = linked_1881.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1880, arg_1883) }; var tmp167 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp168 any; var root_1884 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = d__24_2; if linked_1885 == nil { tmp168 = ifn_1886.Invoke_O__O(arg_1887) } else { tmp168 = linked_1885.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1884, arg_1887) }; if jrt.J2g_Truth(tmp167.Invoke_O__O(tmp168)) {
						var root_2191 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any; var tmp169 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()); var tmp170 any = A_arbace_go_check_A_const_222; var tmp171 any = A_arbace_go_check_A_const_223; var tmp172 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp173 any; var root_2202 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = d__24_2; if linked_2203 == nil { tmp173 = ifn_2204.Invoke_O__O(arg_2205) } else { tmp173 = linked_2203.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2202, arg_2205) }; arg_2194 = tmp169.Invoke_O_O_O_O__O(tmp170, d__24_2, tmp171, tmp172.Invoke_O__O(tmp173)); if linked_2192 == nil { ifn_2193.Invoke_O__O(arg_2194) } else { linked_2192.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2191, arg_2194) }; var tmp174 *lang.Compiler_AOTFn; var fnbody__2190 any = A_arbace_go_check_check_package_fn__1686000205_A_New_O(d__24_2); var tmp175 *jrt.Class; var fncls__2189 *jrt.Class = A_arbace_go_check_check_package_fn__1686000205_A_fn_class; if fncls__2189 == nil { var fncls__2189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__2190); A_arbace_go_check_check_package_fn__1686000205_A_fn_class = fncls__2189d; tmp175 = fncls__2189d } else { tmp175 = fncls__2189 }; tmp174 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2190, tmp175, nil); Up_Compiler_AOTFn_IFn(tmp174).Invoke__O()
//line :234:1
						var tmp176 any; var root_2206 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2208 lang.IFn; if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = seq_1686000199__23; if linked_2207 == nil { tmp176 = ifn_2208.Invoke_O__O(arg_2209) } else { tmp176 = linked_2207.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2206, arg_2209) }; seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, i_1686000202__21 = tmp176, nil, 0, 0; continue L15 } else { var tmp177 any; var root_2210 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = seq_1686000199__23; if linked_2211 == nil { tmp177 = ifn_2212.Invoke_O__O(arg_2213) } else { tmp177 = linked_2211.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2210, arg_2213) }; seq_1686000199__18, chunk_1686000200__19, count_1686000201__20, i_1686000202__21 = tmp177, nil, 0, 0; continue L15 } } } }
//line :161:1
				break L15
			}












































































			if jrt.J2g_Truth(resolving__10) { var seq_1686000207__18 any; var root_1888 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1890 lang.IFn
				if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = decls__17; if linked_1889 == nil { seq_1686000207__18 = ifn_1890.Invoke_O__O(arg_1891) } else { seq_1686000207__18 = linked_1889.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1888, arg_1891) }
//line :239:1
				var chunk_1686000208__19 any; var count_1686000209__20 int64 = 0; var i_1686000210__21 int64 = 0; L16: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000210__21, count_1686000209__20) { var d__22_3 any = lang.Indexed_Cast(chunk_1686000208__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000210__21)); var tmp178 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp179 any; var root_1892 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = d__22_3; if linked_1893 == nil { tmp179 = ifn_1894.Invoke_O__O(arg_1895) } else { tmp179 = linked_1893.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1892, arg_1895) }; if jrt.J2g_Truth(tmp178.Invoke_O__O(tmp179)) { var seq_1686000215__23 any; var root_2214 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any; var root_2218 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2220 lang.IFn
						if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any; var tmp180 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp181 any; var root_2222 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2222, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2224 lang.IFn; if linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = d__22_3; if linked_2223 == nil { tmp181 = ifn_2224.Invoke_O__O(arg_2225) } else { tmp181 = linked_2223.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2222, arg_2225) }; arg_2221 = tmp180.Invoke_O__O(tmp181); if linked_2219 == nil { arg_2217 = ifn_2220.Invoke_O__O(arg_2221) } else { arg_2217 = linked_2219.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2218, arg_2221) }
//line :240:1
						if linked_2215 == nil { seq_1686000215__23 = ifn_2216.Invoke_O__O(arg_2217) } else { seq_1686000215__23 = linked_2215.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2214, arg_2217) }; var chunk_1686000216__24 any; var count_1686000217__25 int64 = 0; var i_1686000218__26 int64 = 0; L17: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000218__26, count_1686000217__25) { var n__27 any = lang.Indexed_Cast(chunk_1686000216__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000218__26)); var tmp182 any; var tmp183 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____28 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp183, A_arbace_go_check_A_const_50.Invoke_O__O(n__27))

							if and__1927000168__auto____28 { tmp182 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__27)) } else { tmp182 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____28).Ref() }
//line :240:1
							if jrt.J2g_Truth(tmp182) {


								var root_2242 any = A_arbace_go_check_A_const_227.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__27); var arg_2246 any; var tmp184 any = A_arbace_go_check_A_const_228; var tmp185 any = A_arbace_go_check_A_const_228.Invoke_O__O(n__27); var tmp186 any = A_arbace_go_check_A_const_55; var G__1686000219__28_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp184, tmp185, tmp186, A_arbace_go_check_A_const_55.Invoke_O__O(n__27), A_arbace_go_check_A_const_229, jrt.Boolean_TRUE.Ref())); var tmp187 *lang.Keyword = A_arbace_go_check_A_const_230; if jrt.J2g_Truth(tmp187.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__27))) {

									var root_2247 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = G__1686000219__28_; var arg_2251 any = A_arbace_go_check_A_const_231; var arg_2252 any = jrt.Boolean_TRUE.Ref(); if linked_2248 == nil { arg_2246 = ifn_2249.Invoke_O_O_O__O(arg_2250, arg_2251, arg_2252) } else { arg_2246 = linked_2248.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2247, arg_2250, arg_2251, arg_2252) } } else {
//line :243:1
										arg_2246 = G__1686000219__28_ }; if linked_2243 == nil { ifn_2244.Invoke_O_O__O(arg_2245, arg_2246) } else { linked_2243.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2242, arg_2245, arg_2246) }
//line :240:1
								seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, i_1686000218__26 = seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000218__26); continue L17 } else { seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, i_1686000218__26 = seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000218__26); continue L17 } } else { var temp__1927000414__auto____27 any; var root_2226 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = seq_1686000215__23; if linked_2227 == nil { temp__1927000414__auto____27 = ifn_2228.Invoke_O__O(arg_2229) } else { temp__1927000414__auto____27 = linked_2227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2226, arg_2229) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var seq_1686000215__28 any = temp__1927000414__auto____27; var tmp188 any; var root_2230 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = seq_1686000215__28; if linked_2231 == nil { tmp188 = ifn_2232.Invoke_O__O(arg_2233) } else { tmp188 = linked_2231.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2230, arg_2233) }; if jrt.J2g_Truth(tmp188) { var c__1927000678__auto____29 any; var root_2234 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = seq_1686000215__28; if linked_2235 == nil { c__1927000678__auto____29 = ifn_2236.Invoke_O__O(arg_2237) } else { c__1927000678__auto____29 = linked_2235.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2234, arg_2237) }; var tmp189 any; var root_2253 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = seq_1686000215__28; if linked_2254 == nil { tmp189 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp189 = linked_2254.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2253, arg_2256) }; seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, i_1686000218__26 = tmp189, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L17 } else { var n__29 any; var root_2238 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2240 lang.IFn; if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = seq_1686000215__28; if linked_2239 == nil { n__29 = ifn_2240.Invoke_O__O(arg_2241) } else { n__29 = linked_2239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2238, arg_2241) }; var tmp190 any; var tmp191 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____30 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp191, A_arbace_go_check_A_const_50.Invoke_O__O(n__29))

									if and__1927000168__auto____30 { tmp190 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__29)) } else { tmp190 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30).Ref() }
//line :240:1
									if jrt.J2g_Truth(tmp190) {


										var root_2257 any = A_arbace_go_check_A_const_227.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__29); var arg_2261 any; var tmp192 any = A_arbace_go_check_A_const_228; var tmp193 any = A_arbace_go_check_A_const_228.Invoke_O__O(n__29); var tmp194 any = A_arbace_go_check_A_const_55; var G__1686000220__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp192, tmp193, tmp194, A_arbace_go_check_A_const_55.Invoke_O__O(n__29), A_arbace_go_check_A_const_229, jrt.Boolean_TRUE.Ref())); var tmp195 *lang.Keyword = A_arbace_go_check_A_const_230; if jrt.J2g_Truth(tmp195.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__29))) {

											var root_2262 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = G__1686000220__30_; var arg_2266 any = A_arbace_go_check_A_const_231; var arg_2267 any = jrt.Boolean_TRUE.Ref(); if linked_2263 == nil { arg_2261 = ifn_2264.Invoke_O_O_O__O(arg_2265, arg_2266, arg_2267) } else { arg_2261 = linked_2263.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2262, arg_2265, arg_2266, arg_2267) } } else {
//line :243:1
												arg_2261 = G__1686000220__30_ }; if linked_2258 == nil { ifn_2259.Invoke_O_O__O(arg_2260, arg_2261) } else { linked_2258.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2257, arg_2260, arg_2261) }
//line :240:1
										var tmp196 any; var root_2268 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = seq_1686000215__28; if linked_2269 == nil { tmp196 = ifn_2270.Invoke_O__O(arg_2271) } else { tmp196 = linked_2269.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2268, arg_2271) }; seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, i_1686000218__26 = tmp196, nil, 0, 0; continue L17 } else { var tmp197 any; var root_2272 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = seq_1686000215__28; if linked_2273 == nil { tmp197 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp197 = linked_2273.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2272, arg_2275) }; seq_1686000215__23, chunk_1686000216__24, count_1686000217__25, i_1686000218__26 = tmp197, nil, 0, 0; continue L17 } } } }; break L17 }; seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, i_1686000210__21 = seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000210__21); continue L16 } else { seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, i_1686000210__21 = seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000210__21); continue L16 } } else { var temp__1927000414__auto____22_4 any; var root_1896 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = seq_1686000207__18; if linked_1897 == nil { temp__1927000414__auto____22_4 = ifn_1898.Invoke_O__O(arg_1899) } else { temp__1927000414__auto____22_4 = linked_1897.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1896, arg_1899) }; if jrt.J2g_Truth(temp__1927000414__auto____22_4) { var seq_1686000207__23 any = temp__1927000414__auto____22_4; var tmp198 any; var root_1900 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1900, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1902 lang.IFn; if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = seq_1686000207__23; if linked_1901 == nil { tmp198 = ifn_1902.Invoke_O__O(arg_1903) } else { tmp198 = linked_1901.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1900, arg_1903) }; if jrt.J2g_Truth(tmp198) { var c__1927000678__auto____24_4 any; var root_1904 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = seq_1686000207__23; if linked_1905 == nil { c__1927000678__auto____24_4 = ifn_1906.Invoke_O__O(arg_1907) } else { c__1927000678__auto____24_4 = linked_1905.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1904, arg_1907) }; var tmp199 any; var root_2276 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = seq_1686000207__23; if linked_2277 == nil { tmp199 = ifn_2278.Invoke_O__O(arg_2279) } else { tmp199 = linked_2277.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2276, arg_2279) }; seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, i_1686000210__21 = tmp199, c__1927000678__auto____24_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var d__24_3 any; var root_1908 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1910 lang.IFn; if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any = seq_1686000207__23; if linked_1909 == nil { d__24_3 = ifn_1910.Invoke_O__O(arg_1911) } else { d__24_3 = linked_1909.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1908, arg_1911) }; var tmp200 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp201 any; var root_1912 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1914 lang.IFn; if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = d__24_3; if linked_1913 == nil { tmp201 = ifn_1914.Invoke_O__O(arg_1915) } else { tmp201 = linked_1913.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1912, arg_1915) }; if jrt.J2g_Truth(tmp200.Invoke_O__O(tmp201)) { var seq_1686000211__25 any; var root_2280 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any; var root_2284 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2286 lang.IFn
											if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any; var tmp202 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp203 any; var root_2288 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = d__24_3; if linked_2289 == nil { tmp203 = ifn_2290.Invoke_O__O(arg_2291) } else { tmp203 = linked_2289.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2288, arg_2291) }; arg_2287 = tmp202.Invoke_O__O(tmp203); if linked_2285 == nil { arg_2283 = ifn_2286.Invoke_O__O(arg_2287) } else { arg_2283 = linked_2285.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2284, arg_2287) }
//line :240:1
											if linked_2281 == nil { seq_1686000211__25 = ifn_2282.Invoke_O__O(arg_2283) } else { seq_1686000211__25 = linked_2281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2280, arg_2283) }; var chunk_1686000212__26 any; var count_1686000213__27 int64 = 0; var i_1686000214__28 int64 = 0; L18: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000214__28, count_1686000213__27) { var n__29_2 any = lang.Indexed_Cast(chunk_1686000212__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000214__28)); var tmp204 any; var tmp205 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____30_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp205, A_arbace_go_check_A_const_50.Invoke_O__O(n__29_2))

												if and__1927000168__auto____30_2 { tmp204 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__29_2)) } else { tmp204 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30_2).Ref() }
//line :240:1
												if jrt.J2g_Truth(tmp204) {


													var root_2308 any = A_arbace_go_check_A_const_227.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__29_2); var arg_2312 any; var tmp206 any = A_arbace_go_check_A_const_228; var tmp207 any = A_arbace_go_check_A_const_228.Invoke_O__O(n__29_2); var tmp208 any = A_arbace_go_check_A_const_55; var G__1686000221__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp206, tmp207, tmp208, A_arbace_go_check_A_const_55.Invoke_O__O(n__29_2), A_arbace_go_check_A_const_229, jrt.Boolean_TRUE.Ref())); var tmp209 *lang.Keyword = A_arbace_go_check_A_const_230; if jrt.J2g_Truth(tmp209.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__29_2))) {

														var root_2313 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = G__1686000221__30_; var arg_2317 any = A_arbace_go_check_A_const_231; var arg_2318 any = jrt.Boolean_TRUE.Ref(); if linked_2314 == nil { arg_2312 = ifn_2315.Invoke_O_O_O__O(arg_2316, arg_2317, arg_2318) } else { arg_2312 = linked_2314.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2313, arg_2316, arg_2317, arg_2318) } } else {
//line :243:1
															arg_2312 = G__1686000221__30_ }; if linked_2309 == nil { ifn_2310.Invoke_O_O__O(arg_2311, arg_2312) } else { linked_2309.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2308, arg_2311, arg_2312) }
//line :240:1
													seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, i_1686000214__28 = seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000214__28); continue L18 } else { seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, i_1686000214__28 = seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000214__28); continue L18 } } else { var temp__1927000414__auto____29 any; var root_2292 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = seq_1686000211__25; if linked_2293 == nil { temp__1927000414__auto____29 = ifn_2294.Invoke_O__O(arg_2295) } else { temp__1927000414__auto____29 = linked_2293.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2292, arg_2295) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1686000211__30 any = temp__1927000414__auto____29; var tmp210 any; var root_2296 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = seq_1686000211__30; if linked_2297 == nil { tmp210 = ifn_2298.Invoke_O__O(arg_2299) } else { tmp210 = linked_2297.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2296, arg_2299) }; if jrt.J2g_Truth(tmp210) { var c__1927000678__auto____31 any; var root_2300 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2300, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2302 lang.IFn; if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = seq_1686000211__30; if linked_2301 == nil { c__1927000678__auto____31 = ifn_2302.Invoke_O__O(arg_2303) } else { c__1927000678__auto____31 = linked_2301.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2300, arg_2303) }; var tmp211 any; var root_2319 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = seq_1686000211__30; if linked_2320 == nil { tmp211 = ifn_2321.Invoke_O__O(arg_2322) } else { tmp211 = linked_2320.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2319, arg_2322) }; seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, i_1686000214__28 = tmp211, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L18 } else { var n__31 any; var root_2304 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2304, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2306 lang.IFn; if linked_2305 == nil { ifn_2306 = lang.IFn_Cast(root_2304) } else { ifn_2306 = nil }; var arg_2307 any = seq_1686000211__30; if linked_2305 == nil { n__31 = ifn_2306.Invoke_O__O(arg_2307) } else { n__31 = linked_2305.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2304, arg_2307) }; var tmp212 any; var tmp213 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____32 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp213, A_arbace_go_check_A_const_50.Invoke_O__O(n__31))

														if and__1927000168__auto____32 { tmp212 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__31)) } else { tmp212 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____32).Ref() }
//line :240:1
														if jrt.J2g_Truth(tmp212) {


															var root_2323 any = A_arbace_go_check_A_const_227.GetRawRoot__O(); var linked_2324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2323, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2325 lang.IFn; if linked_2324 == nil { ifn_2325 = lang.IFn_Cast(root_2323) } else { ifn_2325 = nil }; var arg_2326 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__31); var arg_2327 any; var tmp214 any = A_arbace_go_check_A_const_228; var tmp215 any = A_arbace_go_check_A_const_228.Invoke_O__O(n__31); var tmp216 any = A_arbace_go_check_A_const_55; var G__1686000222__32_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp214, tmp215, tmp216, A_arbace_go_check_A_const_55.Invoke_O__O(n__31), A_arbace_go_check_A_const_229, jrt.Boolean_TRUE.Ref())); var tmp217 *lang.Keyword = A_arbace_go_check_A_const_230; if jrt.J2g_Truth(tmp217.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__31))) {

																var root_2328 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2328, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2330 lang.IFn; if linked_2329 == nil { ifn_2330 = lang.IFn_Cast(root_2328) } else { ifn_2330 = nil }; var arg_2331 any = G__1686000222__32_; var arg_2332 any = A_arbace_go_check_A_const_231; var arg_2333 any = jrt.Boolean_TRUE.Ref(); if linked_2329 == nil { arg_2327 = ifn_2330.Invoke_O_O_O__O(arg_2331, arg_2332, arg_2333) } else { arg_2327 = linked_2329.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2328, arg_2331, arg_2332, arg_2333) } } else {
//line :243:1
																	arg_2327 = G__1686000222__32_ }; if linked_2324 == nil { ifn_2325.Invoke_O_O__O(arg_2326, arg_2327) } else { linked_2324.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2323, arg_2326, arg_2327) }
//line :240:1
															var tmp218 any; var root_2334 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = seq_1686000211__30; if linked_2335 == nil { tmp218 = ifn_2336.Invoke_O__O(arg_2337) } else { tmp218 = linked_2335.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2334, arg_2337) }; seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, i_1686000214__28 = tmp218, nil, 0, 0; continue L18 } else { var tmp219 any; var root_2338 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = seq_1686000211__30; if linked_2339 == nil { tmp219 = ifn_2340.Invoke_O__O(arg_2341) } else { tmp219 = linked_2339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2338, arg_2341) }; seq_1686000211__25, chunk_1686000212__26, count_1686000213__27, i_1686000214__28 = tmp219, nil, 0, 0; continue L18 } } } }; break L18 }; var tmp220 any; var root_2342 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2342, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2344 lang.IFn; if linked_2343 == nil { ifn_2344 = lang.IFn_Cast(root_2342) } else { ifn_2344 = nil }; var arg_2345 any = seq_1686000207__23; if linked_2343 == nil { tmp220 = ifn_2344.Invoke_O__O(arg_2345) } else { tmp220 = linked_2343.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2342, arg_2345) }; seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, i_1686000210__21 = tmp220, nil, 0, 0; continue L16 } else { var tmp221 any; var root_2346 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2346, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2348 lang.IFn; if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any = seq_1686000207__23; if linked_2347 == nil { tmp221 = ifn_2348.Invoke_O__O(arg_2349) } else { tmp221 = linked_2347.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2346, arg_2349) }; seq_1686000207__18, chunk_1686000208__19, count_1686000209__20, i_1686000210__21 = tmp221, nil, 0, 0; continue L16 } } } }
//line :239:1
					break L16 } }
//line :161:1
			var seq_1686000223__18 any; var root_1916 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1918 lang.IFn





















































































			if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any = decls__17; if linked_1917 == nil { seq_1686000223__18 = ifn_1918.Invoke_O__O(arg_1919) } else { seq_1686000223__18 = linked_1917.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1916, arg_1919) }
//line :161:1
			var chunk_1686000224__19 any; var count_1686000225__20 int64 = 0; var i_1686000226__21 int64 = 0; L19: for {





















































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000226__21, count_1686000225__20) { var d__22_4 any = lang.Indexed_Cast(chunk_1686000224__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000226__21)); var tmp222 *lang.Keyword = A_arbace_go_check_A_const_147; var tmp223 any; var root_1920 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = d__22_4; if linked_1921 == nil { tmp223 = ifn_1922.Invoke_O__O(arg_1923) } else { tmp223 = linked_1921.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1920, arg_1923) }; if jrt.J2g_Truth(tmp222.Invoke_O__O(tmp223)) {
					var root_2350 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any; var tmp224 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp225 any; var root_2355 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = d__22_4; if linked_2356 == nil { tmp225 = ifn_2357.Invoke_O__O(arg_2358) } else { tmp225 = linked_2356.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2355, arg_2358) }; arg_2353 = tmp224.Invoke_O__O(tmp225); var arg_2354 any; var tmp226 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp227 any; var root_2359 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = d__22_4; if linked_2360 == nil { tmp227 = ifn_2361.Invoke_O__O(arg_2362) } else { tmp227 = linked_2360.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2359, arg_2362) }; arg_2354 = tmp226.Invoke_O__O(tmp227); if linked_2351 == nil { ifn_2352.Invoke_O_O__O(arg_2353, arg_2354) } else { linked_2351.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2350, arg_2353, arg_2354) }
//line :247:1
					seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, i_1686000226__21 = seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000226__21); continue L19 } else { seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, i_1686000226__21 = seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000226__21); continue L19 } } else { var temp__1927000414__auto____22_5 any; var root_1924 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = seq_1686000223__18; if linked_1925 == nil { temp__1927000414__auto____22_5 = ifn_1926.Invoke_O__O(arg_1927) } else { temp__1927000414__auto____22_5 = linked_1925.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1924, arg_1927) }; if jrt.J2g_Truth(temp__1927000414__auto____22_5) { var seq_1686000223__23 any = temp__1927000414__auto____22_5; var tmp228 any; var root_1928 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = seq_1686000223__23; if linked_1929 == nil { tmp228 = ifn_1930.Invoke_O__O(arg_1931) } else { tmp228 = linked_1929.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1928, arg_1931) }; if jrt.J2g_Truth(tmp228) { var c__1927000678__auto____24_5 any; var root_1932 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = seq_1686000223__23; if linked_1933 == nil { c__1927000678__auto____24_5 = ifn_1934.Invoke_O__O(arg_1935) } else { c__1927000678__auto____24_5 = linked_1933.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1932, arg_1935) }; var tmp229 any; var root_2363 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any = seq_1686000223__23; if linked_2364 == nil { tmp229 = ifn_2365.Invoke_O__O(arg_2366) } else { tmp229 = linked_2364.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2363, arg_2366) }; seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, i_1686000226__21 = tmp229, c__1927000678__auto____24_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L19 } else { var d__24_4 any; var root_1936 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1938 lang.IFn; if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = seq_1686000223__23; if linked_1937 == nil { d__24_4 = ifn_1938.Invoke_O__O(arg_1939) } else { d__24_4 = linked_1937.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1936, arg_1939) }; var tmp230 *lang.Keyword = A_arbace_go_check_A_const_147; var tmp231 any; var root_1940 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = d__24_4; if linked_1941 == nil { tmp231 = ifn_1942.Invoke_O__O(arg_1943) } else { tmp231 = linked_1941.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1940, arg_1943) }; if jrt.J2g_Truth(tmp230.Invoke_O__O(tmp231)) {
						var root_2367 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any; var tmp232 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp233 any; var root_2372 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = d__24_4; if linked_2373 == nil { tmp233 = ifn_2374.Invoke_O__O(arg_2375) } else { tmp233 = linked_2373.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2372, arg_2375) }; arg_2370 = tmp232.Invoke_O__O(tmp233); var arg_2371 any; var tmp234 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp235 any; var root_2376 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = d__24_4; if linked_2377 == nil { tmp235 = ifn_2378.Invoke_O__O(arg_2379) } else { tmp235 = linked_2377.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2376, arg_2379) }; arg_2371 = tmp234.Invoke_O__O(tmp235); if linked_2368 == nil { ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { linked_2368.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) }
//line :247:1
						var tmp236 any; var root_2380 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = seq_1686000223__23; if linked_2381 == nil { tmp236 = ifn_2382.Invoke_O__O(arg_2383) } else { tmp236 = linked_2381.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2380, arg_2383) }; seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, i_1686000226__21 = tmp236, nil, 0, 0; continue L19 } else { var tmp237 any; var root_2384 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2386 lang.IFn; if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = seq_1686000223__23; if linked_2385 == nil { tmp237 = ifn_2386.Invoke_O__O(arg_2387) } else { tmp237 = linked_2385.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2384, arg_2387) }; seq_1686000223__18, chunk_1686000224__19, count_1686000225__20, i_1686000226__21 = tmp237, nil, 0, 0; continue L19 } } } }
//line :161:1
				break L19 }; var seq_1686000227__18 any; var root_1944 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1946 lang.IFn























































































			if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = fis__13; if linked_1945 == nil { seq_1686000227__18 = ifn_1946.Invoke_O__O(arg_1947) } else { seq_1686000227__18 = linked_1945.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1944, arg_1947) }
//line :161:1
			var chunk_1686000228__19 any; var count_1686000229__20 int64 = 0; var i_1686000230__21 int64 = 0; L20: for {























































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000230__21, count_1686000229__20) { var fi__22_5 any = lang.Indexed_Cast(chunk_1686000228__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000230__21)); var root_2388 any = A_arbace_go_check_A_const_233.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = fi__22_5; if linked_2389 == nil { ifn_2390.Invoke_O__O(arg_2391) } else { linked_2389.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2388, arg_2391) }; seq_1686000227__18, chunk_1686000228__19, count_1686000229__20, i_1686000230__21 = seq_1686000227__18, chunk_1686000228__19, count_1686000229__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000230__21); continue L20 } else { var temp__1927000414__auto____22_6 any; var root_1948 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = seq_1686000227__18; if linked_1949 == nil { temp__1927000414__auto____22_6 = ifn_1950.Invoke_O__O(arg_1951) } else { temp__1927000414__auto____22_6 = linked_1949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1948, arg_1951) }; if jrt.J2g_Truth(temp__1927000414__auto____22_6) { var seq_1686000227__23 any = temp__1927000414__auto____22_6; var tmp238 any; var root_1952 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = seq_1686000227__23; if linked_1953 == nil { tmp238 = ifn_1954.Invoke_O__O(arg_1955) } else { tmp238 = linked_1953.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1952, arg_1955) }; if jrt.J2g_Truth(tmp238) { var c__1927000678__auto____24_6 any; var root_1956 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = seq_1686000227__23; if linked_1957 == nil { c__1927000678__auto____24_6 = ifn_1958.Invoke_O__O(arg_1959) } else { c__1927000678__auto____24_6 = linked_1957.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1956, arg_1959) }; var tmp239 any; var root_2392 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2392, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2394 lang.IFn; if linked_2393 == nil { ifn_2394 = lang.IFn_Cast(root_2392) } else { ifn_2394 = nil }; var arg_2395 any = seq_1686000227__23; if linked_2393 == nil { tmp239 = ifn_2394.Invoke_O__O(arg_2395) } else { tmp239 = linked_2393.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2392, arg_2395) }; seq_1686000227__18, chunk_1686000228__19, count_1686000229__20, i_1686000230__21 = tmp239, c__1927000678__auto____24_6, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_6))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L20 } else { var fi__24 any; var root_1960 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = seq_1686000227__23; if linked_1961 == nil { fi__24 = ifn_1962.Invoke_O__O(arg_1963) } else { fi__24 = linked_1961.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1960, arg_1963) }; var root_2396 any = A_arbace_go_check_A_const_233.GetRawRoot__O(); var linked_2397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2396, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2398 lang.IFn; if linked_2397 == nil { ifn_2398 = lang.IFn_Cast(root_2396) } else { ifn_2398 = nil }; var arg_2399 any = fi__24; if linked_2397 == nil { ifn_2398.Invoke_O__O(arg_2399) } else { linked_2397.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2396, arg_2399) }; var tmp240 any; var root_2400 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = seq_1686000227__23; if linked_2401 == nil { tmp240 = ifn_2402.Invoke_O__O(arg_2403) } else { tmp240 = linked_2401.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2400, arg_2403) }; seq_1686000227__18, chunk_1686000228__19, count_1686000229__20, i_1686000230__21 = tmp240, nil, 0, 0; continue L20 } } }
//line :161:1
				break L20 }; var order__18 any; var root_862 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_864 lang.IFn

























































































			if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = objs__16; if linked_863 == nil { order__18 = ifn_864.Invoke_O__O(arg_865) } else { order__18 = linked_863.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_862, arg_865) }
//line :161:1
			var ___19 any; var tmp241 any; var root_866 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_868 lang.IFn; _ = ___19



























































































			if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var root_870 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = errors__9; if linked_871 == nil { arg_869 = ifn_872.Invoke_O__O(arg_873) } else { arg_869 = linked_871.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_870, arg_873) }; if linked_867 == nil { tmp241 = ifn_868.Invoke_O__O(arg_869) } else { tmp241 = linked_867.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_866, arg_869) }; if jrt.J2g_Truth(tmp241) { var root_874 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; if linked_875 == nil { ___19 = ifn_876.Invoke__O() } else { ___19 = linked_875.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A).Invoke_O__O(root_874) } } else { ___19 = nil }
//line :161:1
			var ___20 any; var tmp242 any; var root_877 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_879 lang.IFn; _ = ___20





























































































			if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any; var root_881 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = errors__9; if linked_882 == nil { arg_880 = ifn_883.Invoke_O__O(arg_884) } else { arg_880 = linked_882.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_881, arg_884) }; if linked_878 == nil { tmp242 = ifn_879.Invoke_O__O(arg_880) } else { tmp242 = linked_878.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_877, arg_880) }; if jrt.J2g_Truth(tmp242) { var root_885 any = A_arbace_go_check_A_const_132.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; if linked_886 == nil { ___20 = ifn_887.Invoke__O() } else { ___20 = linked_886.(*aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A).Invoke_O__O(root_885) } } else { ___20 = nil }
//line :161:1
			var say__21 any; var root_888 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_890 lang.IFn






























































































			if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = src__0; var arg_892 any = A_arbace_go_check_A_const_133; if linked_889 == nil { say__21 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { say__21 = linked_889.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) }
//line :161:1
			var init_entry__22 any; var fnbody__935 any = A_arbace_go_check_check_package_init_entry__1686000231_A_New(); var tmp243 *jrt.Class
			var fncls__934 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1686000231_A_fn_class































































































			if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); A_arbace_go_check_check_package_init_entry__1686000231_A_fn_class = fncls__934d; tmp243 = fncls__934d } else { tmp243 = fncls__934 }; init_entry__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__935, tmp243, nil)
//line :161:1
			var have__23 any; var root_936 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_938 lang.IFn


































































































			if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = init_entry__22; var arg_940 any = order__18; if linked_937 == nil { have__23 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { have__23 = linked_937.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }
//line :161:1
			var norm__24 any; var fnbody__971 any = A_arbace_go_check_check_package_norm__1686000235_A_New(); var tmp244 *jrt.Class
			var fncls__970 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1686000235_A_fn_class




































































































			if fncls__970 == nil { var fncls__970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_go_check_check_package_norm__1686000235_A_fn_class = fncls__970d; tmp244 = fncls__970d } else { tmp244 = fncls__970 }; norm__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__971, tmp244, nil)
//line :161:1
			var say_here__25 any; var ns__25 any; var root_972 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_974 lang.IFn











































































































			if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = norm__24; var arg_976 any; var or__1927000174__auto____25 any = say__21; if jrt.J2g_Truth(or__1927000174__auto____25) { arg_976 = or__1927000174__auto____25 } else { arg_976 = lang.PersistentVector_EMPTY.Ref() }; if linked_973 == nil { ns__25 = ifn_974.Invoke_O_O__O(arg_975, arg_976) } else { ns__25 = linked_973.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_972, arg_975, arg_976) }
			var tmp245 bool; var na_977 any; var or__1927000174__auto____26 any = A_arbace_go_check_A_const_140.Invoke_O__O(src__0); if jrt.J2g_Truth(or__1927000174__auto____26) { na_977 = or__1927000174__auto____26 } else { na_977 = A_arbace_go_check_A_const_22 }; if jrt.Long_InstanceOf(na_977) { var n0_978 int64 = jrt.NN(jrt.Long_Cast(na_977)).LongValue__J(); tmp245 = n0_978 > 0 } else { if jrt.Double_InstanceOf(na_977) { var n0_978_2 float64 = jrt.NN(jrt.Double_Cast(na_977)).DoubleValue__D(); tmp245 = n0_978_2 > 0.0 } else { tmp245 = lang.Numbers_IsPos_O__Z_NoInit(na_977) } }; if tmp245 { var h__26 any; var root_979 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = have__23; if linked_980 == nil { h__26 = ifn_981.Invoke_O__O(arg_982) } else { h__26 = linked_980.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_979, arg_982) }; var root_983 any = A_arbace_go_check_A_const_142.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = h__26; var arg_987 any = ns__25; if linked_984 == nil { say_here__25 = ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { say_here__25 = linked_984.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) } } else { say_here__25 = ns__25 }
//line :161:1
			var init_result__26 any; var tmp246 any; var root_988 any = A_arbace_go_check_A_const_114.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_990 lang.IFn













































































































			if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = say__21; if linked_989 == nil { tmp246 = ifn_990.Invoke_O__O(arg_991) } else { tmp246 = linked_989.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_988, arg_991) }; if jrt.J2g_Truth(tmp246) {
				if lang.Util_Equiv_O_O__Z_NoInit(say_here__25, have__23) { var tmp247 any = A_arbace_go_check_A_const_143; var tmp248 any = jrt.Boolean_TRUE.Ref(); var tmp249 any = A_arbace_go_check_A_const_144; init_result__26 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp247, tmp248, tmp249, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__21)).Ref())) } else {

					var root_2404 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_2405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2404, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_2406 lang.IFn; if linked_2405 == nil { ifn_2406 = lang.IFn_Cast(root_2404) } else { ifn_2406 = nil }; var arg_2407 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_234.Invoke_O__O(src__0)) { arg_2407 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_234.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp250 *lang.Keyword = A_arbace_go_check_A_const_71; var tmp251 any; var root_2411 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__0); if linked_2412 == nil { tmp251 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp251 = linked_2412.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2411, arg_2414) }; arg_2407 = tmp250.Invoke_O__O(tmp251) }; var arg_2408 any; var or__1927000174__auto____26_2 any = A_arbace_go_check_A_const_235.Invoke_O__O(src__0)
					if jrt.J2g_Truth(or__1927000174__auto____26_2) { arg_2408 = or__1927000174__auto____26_2 } else { arg_2408 = A_arbace_go_check_A_const_22 }
//line :274:1
					var arg_2409 any = A_arbace_go_check_A_const_236; var arg_2410 any = lang.IFn_Cast(A_arbace_go_check_A_const_237.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_66, A_arbace_go_check_A_const_111.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()).Invoke_O__O(say__21), lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()).Invoke_O__O(have__23)); if linked_2405 == nil { ifn_2406.Invoke_O_O_O_O__O(arg_2407, arg_2408, arg_2409, arg_2410) } else { linked_2405.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_2404, arg_2407, arg_2408, arg_2409, arg_2410) }
//line :272:1
					init_result__26 = A_arbace_go_check_A_const_145 } } else {
//line :271:1
						init_result__26 = nil }
//line :161:1
			var generic_ids__27 any; var root_992 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_994 lang.IFn






















































































































			if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any; var root_996 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any; var fnbody__1010 any = A_arbace_go_check_check_package_fn__1686000239_A_New(); var tmp252 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_go_check_check_package_fn__1686000239_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_go_check_check_package_fn__1686000239_A_fn_class = fncls__1009d; tmp252 = fncls__1009d } else { tmp252 = fncls__1009 }; arg_999 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1010, tmp252, nil); var arg_1000 any = decls__17; if linked_997 == nil { arg_995 = ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { arg_995 = linked_997.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) }; if linked_993 == nil { generic_ids__27 = ifn_994.Invoke_O__O(arg_995) } else { generic_ids__27 = linked_993.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_992, arg_995) }
//line :161:1
			var errs__28 any; var root_1011 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1013 lang.IFn

























































































			if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = errors__9; if linked_1012 == nil { errs__28 = ifn_1013.Invoke_O__O(arg_1014) } else { errs__28 = linked_1012.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1011, arg_1014) }
//line :161:1
			var counted__29 any; var root_1015 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1017 lang.IFn
























































































































			if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any; var fnbody__1026 any = A_arbace_go_check_check_package_fn__1686000241_A_New_O(generic_ids__27); var tmp253 *jrt.Class; var fncls__1025 *jrt.Class = A_arbace_go_check_check_package_fn__1686000241_A_fn_class; if fncls__1025 == nil { var fncls__1025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1026); A_arbace_go_check_check_package_fn__1686000241_A_fn_class = fncls__1025d; tmp253 = fncls__1025d } else { tmp253 = fncls__1025 }; arg_1018 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1026, tmp253, nil); var arg_1019 any = errs__28; if linked_1016 == nil { counted__29 = ifn_1017.Invoke_O_O__O(arg_1018, arg_1019) } else { counted__29 = linked_1016.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1015, arg_1018, arg_1019) }
//line :161:1
			var forms__30 any; var m__30 any = jrt.IdentityHashMap_New(); var order__31 any = jrt.ArrayList_New(); var seq_1686000243__32 any; var root_2430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2432 lang.IFn




























































































































			if linked_2431 == nil { ifn_2432 = lang.IFn_Cast(root_2430) } else { ifn_2432 = nil }; var arg_2433 any = decls__17; if linked_2431 == nil { seq_1686000243__32 = ifn_2432.Invoke_O__O(arg_2433) } else { seq_1686000243__32 = linked_2431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2430, arg_2433) }
//line :161:1
			var chunk_1686000244__33 any; var count_1686000245__34 int64 = 0; var i_1686000246__35 int64 = 0; L21: for {




























































































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000246__35, count_1686000245__34) { var d__36 any = lang.Indexed_Cast(chunk_1686000244__33).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000246__35)); var f__37 any; var tmp254 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp255 any; var root_2450 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2452 lang.IFn
					if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any = d__36; if linked_2451 == nil { tmp255 = ifn_2452.Invoke_O__O(arg_2453) } else { tmp255 = linked_2451.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2450, arg_2453) }; f__37 = tmp254.Invoke_O__O(tmp255)
					if jrt.IdentityHashMap_Cast(m__30).ContainsKey_O__Z(f__37) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayList_Cast(order__31).Add_O__Z(f__37)); jrt.IdentityHashMap_Cast(m__30).Put_O_O__O(f__37, lang.PersistentVector_EMPTY.Ref()) }
					var tmp256 jrt.IdentityHashMap_I = jrt.IdentityHashMap_Cast(m__30); var tmp257 any; var root_2454 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = jrt.IdentityHashMap_Cast(m__30).Get_O__O(f__37); var arg_2458 any = d__36; if linked_2455 == nil { tmp257 = ifn_2456.Invoke_O_O__O(arg_2457, arg_2458) } else { tmp257 = linked_2455.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2454, arg_2457, arg_2458) }; tmp256.Put_O_O__O(f__37, tmp257)
//line :286:1
					seq_1686000243__32, chunk_1686000244__33, count_1686000245__34, i_1686000246__35 = seq_1686000243__32, chunk_1686000244__33, count_1686000245__34, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000246__35); continue L21 } else { var temp__1927000414__auto____36 any; var root_2434 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2434, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2436 lang.IFn; if linked_2435 == nil { ifn_2436 = lang.IFn_Cast(root_2434) } else { ifn_2436 = nil }; var arg_2437 any = seq_1686000243__32; if linked_2435 == nil { temp__1927000414__auto____36 = ifn_2436.Invoke_O__O(arg_2437) } else { temp__1927000414__auto____36 = linked_2435.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2434, arg_2437) }; if jrt.J2g_Truth(temp__1927000414__auto____36) { var seq_1686000243__37 any = temp__1927000414__auto____36; var tmp258 any; var root_2438 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2440 lang.IFn; if linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any = seq_1686000243__37; if linked_2439 == nil { tmp258 = ifn_2440.Invoke_O__O(arg_2441) } else { tmp258 = linked_2439.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2438, arg_2441) }; if jrt.J2g_Truth(tmp258) { var c__1927000678__auto____38 any; var root_2442 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2442, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2444 lang.IFn; if linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = seq_1686000243__37; if linked_2443 == nil { c__1927000678__auto____38 = ifn_2444.Invoke_O__O(arg_2445) } else { c__1927000678__auto____38 = linked_2443.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2442, arg_2445) }; var tmp259 any; var root_2459 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = seq_1686000243__37; if linked_2460 == nil { tmp259 = ifn_2461.Invoke_O__O(arg_2462) } else { tmp259 = linked_2460.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2459, arg_2462) }; seq_1686000243__32, chunk_1686000244__33, count_1686000245__34, i_1686000246__35 = tmp259, c__1927000678__auto____38, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____38))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L21 } else { var d__38 any; var root_2446 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = seq_1686000243__37; if linked_2447 == nil { d__38 = ifn_2448.Invoke_O__O(arg_2449) } else { d__38 = linked_2447.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2446, arg_2449) }; var f__39 any; var tmp260 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp261 any; var root_2463 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2465 lang.IFn
						if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = d__38; if linked_2464 == nil { tmp261 = ifn_2465.Invoke_O__O(arg_2466) } else { tmp261 = linked_2464.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2463, arg_2466) }; f__39 = tmp260.Invoke_O__O(tmp261)
						if jrt.IdentityHashMap_Cast(m__30).ContainsKey_O__Z(f__39) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayList_Cast(order__31).Add_O__Z(f__39)); jrt.IdentityHashMap_Cast(m__30).Put_O_O__O(f__39, lang.PersistentVector_EMPTY.Ref()) }
						var tmp262 jrt.IdentityHashMap_I = jrt.IdentityHashMap_Cast(m__30); var tmp263 any; var root_2467 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = jrt.IdentityHashMap_Cast(m__30).Get_O__O(f__39); var arg_2471 any = d__38; if linked_2468 == nil { tmp263 = ifn_2469.Invoke_O_O__O(arg_2470, arg_2471) } else { tmp263 = linked_2468.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2467, arg_2470, arg_2471) }; tmp262.Put_O_O__O(f__39, tmp263)
//line :286:1
						var tmp264 any; var root_2472 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = seq_1686000243__37; if linked_2473 == nil { tmp264 = ifn_2474.Invoke_O__O(arg_2475) } else { tmp264 = linked_2473.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2472, arg_2475) }; seq_1686000243__32, chunk_1686000244__33, count_1686000245__34, i_1686000246__35 = tmp264, nil, 0, 0; continue L21 } } }
//line :161:1
				break L21
			}































































































































			var root_1027 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any; var fnbody__1033 any = A_arbace_go_check_check_package_fn__1686000247_A_New_O(m__30); var tmp265 *jrt.Class; var fncls__1032 *jrt.Class = A_arbace_go_check_check_package_fn__1686000247_A_fn_class; if fncls__1032 == nil { var fncls__1032d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1033); A_arbace_go_check_check_package_fn__1686000247_A_fn_class = fncls__1032d; tmp265 = fncls__1032d } else { tmp265 = fncls__1032 }; arg_1030 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1033, tmp265, nil); var arg_1031 any = order__31; if linked_1028 == nil { forms__30 = ifn_1029.Invoke_O_O__O(arg_1030, arg_1031) } else { forms__30 = linked_1028.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1027, arg_1030, arg_1031) }
//line :161:1
			var stats__31 any; var root_1034 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1036 lang.IFn

































































































































			if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any; var fnbody__1328 any = A_arbace_go_check_check_package_fn__1686000250_A_New_O(resolving__10); var tmp266 *jrt.Class; var fncls__1327 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_A_fn_class
			if fncls__1327 == nil { var fncls__1327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__1328); A_arbace_go_check_check_package_fn__1686000250_A_fn_class = fncls__1327d; tmp266 = fncls__1327d } else { tmp266 = fncls__1327 }; arg_1037 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1328, tmp266, nil)
//line :291:1
			var arg_1038 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_166, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_83, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_155, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_157, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_167, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_143, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_168, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_159, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_147, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_169, lang.PersistentVector_EMPTY.Ref())); var arg_1039 any = forms__30; if linked_1035 == nil { stats__31 = ifn_1036.Invoke_O_O_O__O(arg_1037, arg_1038, arg_1039) } else { stats__31 = linked_1035.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1034, arg_1037, arg_1038, arg_1039)
			}




























			var tmp267 any
			var and__1927000168__auto____32_2 any = resolving__10

			if jrt.J2g_Truth(and__1927000168__auto____32_2) { var root_2476 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = keep_trees__6; if linked_2477 == nil { tmp267 = ifn_2478.Invoke_O__O(arg_2479) } else { tmp267 = linked_2477.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2476, arg_2479) } } else { tmp267 = and__1927000168__auto____32_2 }
//line :321:1
			if jrt.J2g_Truth(tmp267) { var seq_1686000291__32 any; var root_2480 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2482 lang.IFn



				if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = decls__17; if linked_2481 == nil { seq_1686000291__32 = ifn_2482.Invoke_O__O(arg_2483) } else { seq_1686000291__32 = linked_2481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2480, arg_2483) }
//line :321:1
				var chunk_1686000292__33 any; var count_1686000293__34 int64 = 0; var i_1686000294__35 int64 = 0; L22: for {



					if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000294__35, count_1686000293__34) { var d__36_2 any = lang.Indexed_Cast(chunk_1686000292__33).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000294__35)); var root_2685 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2687 lang.IFn; if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any = d__36_2; var arg_2689 any; var root_2690 any = A_arbace_go_check_A_const_247.GetRawRoot__O(); var linked_2691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2690, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2692 lang.IFn; if linked_2691 == nil { ifn_2692 = lang.IFn_Cast(root_2690) } else { ifn_2692 = nil }; var arg_2693 any; var root_2695 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2695, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2697 lang.IFn; if linked_2696 == nil { ifn_2697 = lang.IFn_Cast(root_2695) } else { ifn_2697 = nil }; var arg_2698 any = d__36_2; if linked_2696 == nil { arg_2693 = ifn_2697.Invoke_O__O(arg_2698) } else { arg_2693 = linked_2696.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2695, arg_2698) }; var arg_2694 any = A_arbace_go_check_A_const_254; if linked_2691 == nil { arg_2689 = ifn_2692.Invoke_O_O__O(arg_2693, arg_2694) } else { arg_2689 = linked_2691.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2690, arg_2693, arg_2694) }; if linked_2686 == nil { ifn_2687.Invoke_O_O__O(arg_2688, arg_2689) } else { linked_2686.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2685, arg_2688, arg_2689) }; seq_1686000291__32, chunk_1686000292__33, count_1686000293__34, i_1686000294__35 = seq_1686000291__32, chunk_1686000292__33, count_1686000293__34, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000294__35); continue L22 } else { var temp__1927000414__auto____36_2 any; var root_2484 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = seq_1686000291__32; if linked_2485 == nil { temp__1927000414__auto____36_2 = ifn_2486.Invoke_O__O(arg_2487) } else { temp__1927000414__auto____36_2 = linked_2485.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2484, arg_2487) }; if jrt.J2g_Truth(temp__1927000414__auto____36_2) { var seq_1686000291__37 any = temp__1927000414__auto____36_2; var tmp268 any; var root_2488 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2490 lang.IFn; if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = seq_1686000291__37; if linked_2489 == nil { tmp268 = ifn_2490.Invoke_O__O(arg_2491) } else { tmp268 = linked_2489.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2488, arg_2491) }; if jrt.J2g_Truth(tmp268) { var c__1927000678__auto____38_2 any; var root_2492 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = seq_1686000291__37; if linked_2493 == nil { c__1927000678__auto____38_2 = ifn_2494.Invoke_O__O(arg_2495) } else { c__1927000678__auto____38_2 = linked_2493.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2492, arg_2495) }; var tmp269 any; var root_2699 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any = seq_1686000291__37; if linked_2700 == nil { tmp269 = ifn_2701.Invoke_O__O(arg_2702) } else { tmp269 = linked_2700.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2699, arg_2702) }; seq_1686000291__32, chunk_1686000292__33, count_1686000293__34, i_1686000294__35 = tmp269, c__1927000678__auto____38_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____38_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L22 } else { var d__38_2 any; var root_2496 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2498 lang.IFn; if linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any = seq_1686000291__37; if linked_2497 == nil { d__38_2 = ifn_2498.Invoke_O__O(arg_2499) } else { d__38_2 = linked_2497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2496, arg_2499) }; var root_2703 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = d__38_2; var arg_2707 any; var root_2708 any = A_arbace_go_check_A_const_247.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2710 lang.IFn; if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any; var root_2713 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = d__38_2; if linked_2714 == nil { arg_2711 = ifn_2715.Invoke_O__O(arg_2716) } else { arg_2711 = linked_2714.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2713, arg_2716) }; var arg_2712 any = A_arbace_go_check_A_const_255; if linked_2709 == nil { arg_2707 = ifn_2710.Invoke_O_O__O(arg_2711, arg_2712) } else { arg_2707 = linked_2709.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2708, arg_2711, arg_2712) }; if linked_2704 == nil { ifn_2705.Invoke_O_O__O(arg_2706, arg_2707) } else { linked_2704.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2703, arg_2706, arg_2707) }; var tmp270 any; var root_2717 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = seq_1686000291__37; if linked_2718 == nil { tmp270 = ifn_2719.Invoke_O__O(arg_2720) } else { tmp270 = linked_2718.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2717, arg_2720) }; seq_1686000291__32, chunk_1686000292__33, count_1686000293__34, i_1686000294__35 = tmp270, nil, 0, 0; continue L22 } } }
//line :321:1
					break L22 } } else { var tmp271 any; var root_2500 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2500, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2502 lang.IFn




						if linked_2501 == nil { ifn_2502 = lang.IFn_Cast(root_2500) } else { ifn_2502 = nil }; var arg_2503 any = keep_trees__6; if linked_2501 == nil { tmp271 = ifn_2502.Invoke_O__O(arg_2503) } else { tmp271 = linked_2501.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2500, arg_2503) }
//line :321:1
						if jrt.J2g_Truth(tmp271) { var seq_1686000295__32 any; var root_2504 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2506 lang.IFn





							if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = decls__17; if linked_2505 == nil { seq_1686000295__32 = ifn_2506.Invoke_O__O(arg_2507) } else { seq_1686000295__32 = linked_2505.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2504, arg_2507) }
//line :321:1
							var chunk_1686000296__33 any; var count_1686000297__34 int64 = 0; var i_1686000298__35 int64 = 0; L23: for {





								if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000298__35, count_1686000297__34) { var d__36_3 any = lang.Indexed_Cast(chunk_1686000296__33).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000298__35)); var tmp272 any; var and__1927000168__auto____37 bool; var tmp273 any = A_arbace_go_check_A_const_256; var tmp274 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp275 any; var root_2721 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2723 lang.IFn
									if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = d__36_3; if linked_2722 == nil { tmp275 = ifn_2723.Invoke_O__O(arg_2724) } else { tmp275 = linked_2722.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2721, arg_2724) }; and__1927000168__auto____37 = lang.Util_Equiv_O_O__Z_NoInit(tmp273, tmp274.Invoke_O__O(tmp275)); if and__1927000168__auto____37 { var or__1927000174__auto____38 any; var root_2725 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2727 lang.IFn; if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any; var root_2729 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; var arg_2732 any; var tmp276 *lang.Keyword = A_arbace_go_check_A_const_225; var tmp277 any; var root_2734 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any = d__36_3; if linked_2735 == nil { tmp277 = ifn_2736.Invoke_O__O(arg_2737) } else { tmp277 = linked_2735.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2734, arg_2737) }; arg_2732 = tmp276.Invoke_O__O(tmp277); var arg_2733 any = A_arbace_go_check_A_const_257; if linked_2730 == nil { arg_2728 = ifn_2731.Invoke_O_O__O(arg_2732, arg_2733) } else { arg_2728 = linked_2730.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2729, arg_2732, arg_2733) }; if linked_2726 == nil { or__1927000174__auto____38 = ifn_2727.Invoke_O__O(arg_2728) } else { or__1927000174__auto____38 = linked_2726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2725, arg_2728) }; if jrt.J2g_Truth(or__1927000174__auto____38) { tmp272 = or__1927000174__auto____38 } else { var root_2738 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any; var root_2742 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any; var tmp278 *lang.Keyword = A_arbace_go_check_A_const_225; var tmp279 any; var root_2747 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2749 lang.IFn; if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any = d__36_3; if linked_2748 == nil { tmp279 = ifn_2749.Invoke_O__O(arg_2750) } else { tmp279 = linked_2748.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2747, arg_2750) }; arg_2745 = tmp278.Invoke_O__O(tmp279); var arg_2746 any = A_arbace_go_check_A_const_258; if linked_2743 == nil { arg_2741 = ifn_2744.Invoke_O_O__O(arg_2745, arg_2746) } else { arg_2741 = linked_2743.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2742, arg_2745, arg_2746) }; if linked_2739 == nil { tmp272 = ifn_2740.Invoke_O__O(arg_2741) } else { tmp272 = linked_2739.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2738, arg_2741) } } } else { tmp272 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____37).Ref() }; if jrt.J2g_Truth(tmp272) {
										jrt.NN(lang.Volatile_Cast(d__36_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__36_3)).Deref__O(), A_arbace_go_check_A_const_260, A_arbace_go_check_A_const_261, A_arbace_go_check_A_const_262)) } else {
											jrt.NN(lang.Volatile_Cast(d__36_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__36_3)).Deref__O(), A_arbace_go_check_A_const_217, A_arbace_go_check_A_const_260, A_arbace_go_check_A_const_261, A_arbace_go_check_A_const_262)) }
//line :327:1
									seq_1686000295__32, chunk_1686000296__33, count_1686000297__34, i_1686000298__35 = seq_1686000295__32, chunk_1686000296__33, count_1686000297__34, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000298__35); continue L23 } else { var temp__1927000414__auto____36_3 any; var root_2508 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = seq_1686000295__32; if linked_2509 == nil { temp__1927000414__auto____36_3 = ifn_2510.Invoke_O__O(arg_2511) } else { temp__1927000414__auto____36_3 = linked_2509.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2508, arg_2511) }; if jrt.J2g_Truth(temp__1927000414__auto____36_3) { var seq_1686000295__37 any = temp__1927000414__auto____36_3; var tmp280 any; var root_2512 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any = seq_1686000295__37; if linked_2513 == nil { tmp280 = ifn_2514.Invoke_O__O(arg_2515) } else { tmp280 = linked_2513.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2512, arg_2515) }; if jrt.J2g_Truth(tmp280) { var c__1927000678__auto____38_3 any; var root_2516 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = seq_1686000295__37; if linked_2517 == nil { c__1927000678__auto____38_3 = ifn_2518.Invoke_O__O(arg_2519) } else { c__1927000678__auto____38_3 = linked_2517.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2516, arg_2519) }; var tmp281 any; var root_2766 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = seq_1686000295__37; if linked_2767 == nil { tmp281 = ifn_2768.Invoke_O__O(arg_2769) } else { tmp281 = linked_2767.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2766, arg_2769) }; seq_1686000295__32, chunk_1686000296__33, count_1686000297__34, i_1686000298__35 = tmp281, c__1927000678__auto____38_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____38_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L23 } else { var d__38_3 any; var root_2520 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2520, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2522 lang.IFn; if linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 any = seq_1686000295__37; if linked_2521 == nil { d__38_3 = ifn_2522.Invoke_O__O(arg_2523) } else { d__38_3 = linked_2521.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2520, arg_2523) }
										var tmp282 any; var and__1927000168__auto____39 bool; var tmp283 any = A_arbace_go_check_A_const_256; var tmp284 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp285 any; var root_2770 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = d__38_3; if linked_2771 == nil { tmp285 = ifn_2772.Invoke_O__O(arg_2773) } else { tmp285 = linked_2771.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2770, arg_2773) }; and__1927000168__auto____39 = lang.Util_Equiv_O_O__Z_NoInit(tmp283, tmp284.Invoke_O__O(tmp285)); if and__1927000168__auto____39 { var or__1927000174__auto____40 any; var root_2774 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2774, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2776 lang.IFn; if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any; var root_2778 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2778, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2780 lang.IFn; if linked_2779 == nil { ifn_2780 = lang.IFn_Cast(root_2778) } else { ifn_2780 = nil }; var arg_2781 any; var tmp286 *lang.Keyword = A_arbace_go_check_A_const_225; var tmp287 any; var root_2783 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2785 lang.IFn; if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any = d__38_3; if linked_2784 == nil { tmp287 = ifn_2785.Invoke_O__O(arg_2786) } else { tmp287 = linked_2784.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2783, arg_2786) }; arg_2781 = tmp286.Invoke_O__O(tmp287); var arg_2782 any = A_arbace_go_check_A_const_257; if linked_2779 == nil { arg_2777 = ifn_2780.Invoke_O_O__O(arg_2781, arg_2782) } else { arg_2777 = linked_2779.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2778, arg_2781, arg_2782) }; if linked_2775 == nil { or__1927000174__auto____40 = ifn_2776.Invoke_O__O(arg_2777) } else { or__1927000174__auto____40 = linked_2775.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2774, arg_2777) }; if jrt.J2g_Truth(or__1927000174__auto____40) { tmp282 = or__1927000174__auto____40 } else { var root_2787 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2789 lang.IFn; if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any; var root_2791 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any; var tmp288 *lang.Keyword = A_arbace_go_check_A_const_225; var tmp289 any; var root_2796 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2796, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2798 lang.IFn; if linked_2797 == nil { ifn_2798 = lang.IFn_Cast(root_2796) } else { ifn_2798 = nil }; var arg_2799 any = d__38_3; if linked_2797 == nil { tmp289 = ifn_2798.Invoke_O__O(arg_2799) } else { tmp289 = linked_2797.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2796, arg_2799) }; arg_2794 = tmp288.Invoke_O__O(tmp289); var arg_2795 any = A_arbace_go_check_A_const_258; if linked_2792 == nil { arg_2790 = ifn_2793.Invoke_O_O__O(arg_2794, arg_2795) } else { arg_2790 = linked_2792.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2791, arg_2794, arg_2795) }; if linked_2788 == nil { tmp282 = ifn_2789.Invoke_O__O(arg_2790) } else { tmp282 = linked_2788.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2787, arg_2790) } } } else { tmp282 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____39).Ref() }; if jrt.J2g_Truth(tmp282) {
											jrt.NN(lang.Volatile_Cast(d__38_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__38_3)).Deref__O(), A_arbace_go_check_A_const_260, A_arbace_go_check_A_const_261, A_arbace_go_check_A_const_262)) } else {
												jrt.NN(lang.Volatile_Cast(d__38_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_259.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__38_3)).Deref__O(), A_arbace_go_check_A_const_217, A_arbace_go_check_A_const_260, A_arbace_go_check_A_const_261, A_arbace_go_check_A_const_262)) }
//line :327:1
										var tmp290 any; var root_2815 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = seq_1686000295__37; if linked_2816 == nil { tmp290 = ifn_2817.Invoke_O__O(arg_2818) } else { tmp290 = linked_2816.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2815, arg_2818) }; seq_1686000295__32, chunk_1686000296__33, count_1686000297__34, i_1686000298__35 = tmp290, nil, 0, 0; continue L23 } } }
//line :321:1
								break L23
							}
						}
					}






			var tmp291 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp292 any; var root_2524 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2526 lang.IFn; if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2528 any = A_arbace_go_check_A_const_239; var arg_2529 any; var tmp293 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_106.GetRawRoot__O()); var tmp294 any = A_arbace_go_check_A_const_111; var tmp295 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp296 any = A_arbace_go_check_A_const_240; var tmp297 any; var root_2530 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2532 lang.IFn


			if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any; var root_2534 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any; var root_2539 any = A_arbace_go_check_A_const_242.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = A_arbace_go_check_A_const_74; var arg_2543 any = A_arbace_go_check_A_const_79; if linked_2540 == nil { arg_2537 = ifn_2541.Invoke_O_O__O(arg_2542, arg_2543) } else { arg_2537 = linked_2540.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2539, arg_2542, arg_2543) }; var arg_2538 any = counted__29; if linked_2535 == nil { arg_2533 = ifn_2536.Invoke_O_O__O(arg_2537, arg_2538) } else { arg_2533 = linked_2535.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2534, arg_2537, arg_2538) }; if linked_2531 == nil { tmp297 = ifn_2532.Invoke_O__O(arg_2533) } else { tmp297 = linked_2531.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2530, arg_2533) }
//line :332:1
			var tmp298 any = tmp297; var tmp299 any = A_arbace_go_check_A_const_243; var tmp300 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__28)), int64(lang.RT_Count_O__I_NoInit(counted__29)))).Ref(); var tmp301 any = A_arbace_go_check_A_const_244; var tmp302 any = A_arbace_go_check_A_const_245; var tmp303 any




			if jrt.J2g_Truth(keep_trees__6) { var root_2544 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any; var root_2548 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any; var fnbody__2558 any = A_arbace_go_check_check_package_fn__1686000299_A_New(); var tmp304 *jrt.Class; var fncls__2557 *jrt.Class = A_arbace_go_check_check_package_fn__1686000299_A_fn_class; if fncls__2557 == nil { var fncls__2557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_go_check_check_package_fn__1686000299_A_fn_class = fncls__2557d; tmp304 = fncls__2557d } else { tmp304 = fncls__2557 }; arg_2551 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2558, tmp304, nil); var arg_2552 any = decls__17; if linked_2549 == nil { arg_2547 = ifn_2550.Invoke_O_O__O(arg_2551, arg_2552) } else { arg_2547 = linked_2549.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2548, arg_2551, arg_2552) }; if linked_2545 == nil { tmp303 = ifn_2546.Invoke_O__O(arg_2547) } else { tmp303 = linked_2545.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2544, arg_2547) } } else { tmp303 = nil }
//line :332:1
			var tmp305 any = tmp303; var tmp306 any = A_arbace_go_check_A_const_246; var tmp307 any







			if jrt.J2g_Truth(keep_trees__6) {
				var root_2559 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any; var iter__1927001039__auto____32 any; var fnbody__2642 any = A_arbace_go_check_check_package_iter__1686000301__1686000305_A_New(); var tmp308 *jrt.Class; var fncls__2641 *jrt.Class = A_arbace_go_check_check_package_iter__1686000301__1686000305_A_fn_class; if fncls__2641 == nil { var fncls__2641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_go_check_check_package_iter__1686000301__1686000305_A_fn_class = fncls__2641d; tmp308 = fncls__2641d } else { tmp308 = fncls__2641 }; iter__1927001039__auto____32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2642, tmp308, nil); arg_2562 = lang.IFn_Cast(iter__1927001039__auto____32).Invoke_O__O(decls__17); if linked_2560 == nil { tmp307 = ifn_2561.Invoke_O__O(arg_2562) } else { tmp307 = linked_2560.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2559, arg_2562) } } else {
//line :340:1
					tmp307 = nil }
//line :332:1
			var tmp309 any = tmp307; var tmp310 any = A_arbace_go_check_A_const_250; var tmp311 any











			if jrt.J2g_Truth(keep_trees__6) { tmp311 = order__18 } else { tmp311 = nil }
//line :332:1
			var tmp312 any = tmp311; var tmp313 any = A_arbace_go_check_A_const_251; var tmp314 any













			if jrt.J2g_Truth(resolving__10) {
				var root_2643 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_2644 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2643, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2645 lang.IFn; if linked_2644 == nil { ifn_2645 = lang.IFn_Cast(root_2643) } else { ifn_2645 = nil }; var arg_2646 any; var fnbody__2680 any = A_arbace_go_check_check_package_fn__1686000311_A_New(); var tmp315 *jrt.Class; var fncls__2679 *jrt.Class = A_arbace_go_check_check_package_fn__1686000311_A_fn_class; if fncls__2679 == nil { var fncls__2679d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_go_check_check_package_fn__1686000311_A_fn_class = fncls__2679d; tmp315 = fncls__2679d } else { tmp315 = fncls__2679 }; arg_2646 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2680, tmp315, nil); var arg_2647 any = order__18; if linked_2644 == nil { tmp314 = ifn_2645.Invoke_O_O__O(arg_2646, arg_2647) } else { tmp314 = linked_2644.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2643, arg_2646, arg_2647) } } else {
//line :346:1
					tmp314 = nil }
//line :332:1
			var tmp316 any = tmp314; var tmp317 any = A_arbace_go_check_A_const_72; var tmp318 any
















			if jrt.J2g_Truth(keep_trees__6) { tmp318 = pkg_scope__7 } else { tmp318 = nil }
//line :332:1
			var tmp319 any = tmp318; var tmp320 any = A_arbace_go_check_A_const_120; var tmp321 any

















			if jrt.J2g_Truth(keep_trees__6) { var root_2681 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2683 lang.IFn; if linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; var arg_2684 any = A_arbace_go_check_A_const_120.Invoke_O__O(ctx__12); if linked_2682 == nil { tmp321 = ifn_2683.Invoke_O__O(arg_2684) } else { tmp321 = linked_2682.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2681, arg_2684) } } else { tmp321 = nil }
//line :332:1
			arg_2529 = tmp293.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, stats__31, tmp294, tmp295, tmp296, tmp298, tmp299, tmp300, tmp301, init_result__26, tmp302, tmp305, tmp306, tmp309, tmp310, tmp312, tmp313, tmp316, tmp317, tmp319, tmp320, tmp321))))
//line :331:1
			if linked_2525 == nil { tmp292 = ifn_2526.Invoke_O_O_O__O(arg_2527, arg_2528, arg_2529) } else { tmp292 = linked_2525.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2524, arg_2527, arg_2528, arg_2529) }; jrt.NN(tmp291).Reset_O__O(tmp292)
//line :161:1
			tmp69 = pkg__8 }; return nil }(); var root_1329 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1331 lang.IFn; if















	linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; if linked_1330 == nil { ifn_1331.Invoke__O() } else { linked_1330.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1329) }; if /*line :161:1*/ tmp322 != nil { panic(tmp322) }; return tmp69 }














func A_arbace_go_check_check_package_fn__1686000129_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1686000129_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1686000129_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1686000129_A) Invoke_O_O__O(self, p1__1686000111_SHARP___1 any) any { var root_834 any = A_arbace_go_check_A_const_124.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, A_arbace_go_check_file_info_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = t.F_pkg_scope; var arg_838 any = p1__1686000111_SHARP___1; var arg_839 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_src); if linked_835 == nil { return ifn_836.Invoke_O_O_O__O(arg_837, arg_838, arg_839) } else { return linked_835.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_834, arg_837, arg_838, arg_839) } }













func A_arbace_go_check_check_package_fn__1686000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1686000131_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1686000131_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1686000131_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1336 any = A_arbace_go_check_A_const_191.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src); if linked_1337 == nil { tmp1 = ifn_1338.Invoke_O__O(arg_1339) } else { tmp1 = linked_1337.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1336, arg_1339) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :190:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }
































func A_arbace_go_check_check_package_fn__1686000179_A_New() *A_arbace_go_check_check_package_fn__1686000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000179_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1686000179_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1686000179_A) Invoke_O_O__O(self, p1__1686000112_SHARP___1 any) any { var root_855 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = p1__1686000112_SHARP___1; var arg_859 any = A_arbace_go_check_A_const_128; if linked_856 == nil { return ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { return linked_856.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) } }





func A_arbace_go_check_check_package_fn__1686000186_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1686000186_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1686000186_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1686000186_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1686000187__5 any; var root_1978 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1980 lang.IFn
											if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1981 = t_; if linked_1979 == nil { seq_1686000187__5 = ifn_1980.Invoke_O__O(arg_1981) } else { seq_1686000187__5 = linked_1979.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1978, arg_1981) }
//line :229:1
	var chunk_1686000188__6 any; var count_1686000189__7 int64 = 0; var i_1686000190__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000190__8, count_1686000189__7) { var l__9 any = lang.Indexed_Cast(chunk_1686000188__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000190__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1686000187__5, chunk_1686000188__6, count_1686000189__7, i_1686000190__8 = seq_1686000187__5, chunk_1686000188__6, count_1686000189__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000190__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1982 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = seq_1686000187__5; if linked_1983 == nil { temp__1927000414__auto____9 = ifn_1984.Invoke_O__O(arg_1985) } else { temp__1927000414__auto____9 = linked_1983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1982, arg_1985) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1686000187__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1986 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = seq_1686000187__10; if linked_1987 == nil { tmp2 = ifn_1988.Invoke_O__O(arg_1989) } else { tmp2 = linked_1987.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1986, arg_1989) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1990 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = seq_1686000187__10; if linked_1991 == nil { c__1927000678__auto____11 = ifn_1992.Invoke_O__O(arg_1993) } else { c__1927000678__auto____11 = linked_1991.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1990, arg_1993) }; var tmp3 any; var root_2001 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = seq_1686000187__10; if linked_2002 == nil { tmp3 = ifn_2003.Invoke_O__O(arg_2004) } else { tmp3 = linked_2002.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2001, arg_2004) }; seq_1686000187__5, chunk_1686000188__6, count_1686000189__7, i_1686000190__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1994 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = seq_1686000187__10; if linked_1995 == nil { l__11 = ifn_1996.Invoke_O__O(arg_1997) } else { l__11 = linked_1995.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1994, arg_1997) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_2005 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = seq_1686000187__10; if linked_2006 == nil { tmp4 = ifn_2007.Invoke_O__O(arg_2008) } else { tmp4 = linked_2006.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2005, arg_2008) }; seq_1686000187__5, chunk_1686000188__6, count_1686000189__7, i_1686000190__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_2009 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2011 lang.IFn

			if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = ex__5; if linked_2010 == nil { tmp6 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp6 = linked_2010.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_2009, arg_2012) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2013 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2016 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2017 any = A_arbace_go_check_A_const_147; var arg_2018 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_220; var tmp11 any; var root_2019 any = A_arbace_go_check_A_const_221.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = ex__5; if linked_2020 == nil { tmp11 = ifn_2021.Invoke_O__O(arg_2022) } else { tmp11 = linked_2020.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2019, arg_2022) }; arg_2018 = tmp10.Invoke_O__O(tmp11); if linked_2014 == nil { tmp8 = ifn_2015.Invoke_O_O_O__O(arg_2016, arg_2017, arg_2018) } else { tmp8 = linked_2014.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2013, arg_2016, arg_2017, arg_2018) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_1998 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; if linked_1999 == nil { ifn_2000.Invoke__O() } else { linked_1999.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1998) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :229:1
func A_arbace_go_check_check_package_fn__1686000193_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1686000193_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1686000193_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1686000193_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1686000194__5 any; var root_2069 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2071 lang.IFn
											if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any; var t_ any = t.F_ls; t.F_ls = nil; arg_2072 = t_; if linked_2070 == nil { seq_1686000194__5 = ifn_2071.Invoke_O__O(arg_2072) } else { seq_1686000194__5 = linked_2070.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2069, arg_2072) }
//line :229:1
	var chunk_1686000195__6 any; var count_1686000196__7 int64 = 0; var i_1686000197__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000197__8, count_1686000196__7) { var l__9 any = lang.Indexed_Cast(chunk_1686000195__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000197__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1686000194__5, chunk_1686000195__6, count_1686000196__7, i_1686000197__8 = seq_1686000194__5, chunk_1686000195__6, count_1686000196__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000197__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_2073 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = seq_1686000194__5; if linked_2074 == nil { temp__1927000414__auto____9 = ifn_2075.Invoke_O__O(arg_2076) } else { temp__1927000414__auto____9 = linked_2074.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2073, arg_2076) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1686000194__10 any = temp__1927000414__auto____9; var tmp2 any; var root_2077 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2077, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2079 lang.IFn; if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any = seq_1686000194__10; if linked_2078 == nil { tmp2 = ifn_2079.Invoke_O__O(arg_2080) } else { tmp2 = linked_2078.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2077, arg_2080) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_2081 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = seq_1686000194__10; if linked_2082 == nil { c__1927000678__auto____11 = ifn_2083.Invoke_O__O(arg_2084) } else { c__1927000678__auto____11 = linked_2082.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2081, arg_2084) }; var tmp3 any; var root_2092 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = seq_1686000194__10; if linked_2093 == nil { tmp3 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp3 = linked_2093.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2092, arg_2095) }; seq_1686000194__5, chunk_1686000195__6, count_1686000196__7, i_1686000197__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_2085 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = seq_1686000194__10; if linked_2086 == nil { l__11 = ifn_2087.Invoke_O__O(arg_2088) } else { l__11 = linked_2086.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2085, arg_2088) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_2096 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = seq_1686000194__10; if linked_2097 == nil { tmp4 = ifn_2098.Invoke_O__O(arg_2099) } else { tmp4 = linked_2097.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2096, arg_2099) }; seq_1686000194__5, chunk_1686000195__6, count_1686000196__7, i_1686000197__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_2100 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2102 lang.IFn

			if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = ex__5; if linked_2101 == nil { tmp6 = ifn_2102.Invoke_O__O(arg_2103) } else { tmp6 = linked_2101.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_2100, arg_2103) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2104 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2107 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2108 any = A_arbace_go_check_A_const_147; var arg_2109 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_220; var tmp11 any; var root_2110 any = A_arbace_go_check_A_const_221.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = ex__5; if linked_2111 == nil { tmp11 = ifn_2112.Invoke_O__O(arg_2113) } else { tmp11 = linked_2111.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2110, arg_2113) }; arg_2109 = tmp10.Invoke_O__O(tmp11); if linked_2105 == nil { tmp8 = ifn_2106.Invoke_O_O_O__O(arg_2107, arg_2108, arg_2109) } else { tmp8 = linked_2105.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2104, arg_2107, arg_2108, arg_2109) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_2089 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; if linked_2090 == nil { ifn_2091.Invoke__O() } else { linked_2090.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2089) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1686000203_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000203_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000203_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1686000203_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1686000203_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2146 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp3 any; var root_2150 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any; var t_ any = t.F_d; t.F_d = nil; arg_2153 = t_; if linked_2151 == nil { tmp3 = ifn_2152.Invoke_O__O(arg_2153) } else { tmp3 = linked_2151.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2150, arg_2153) }; arg_2149 = tmp2.Invoke_O__O(tmp3); if linked_2147 == nil { tmp1 = ifn_2148.Invoke_O__O(arg_2149) } else { tmp1 = linked_2147.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2146, arg_2149) } }
//line :235:1
	return nil }(); var root_2154 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; if linked_2155 == nil { ifn_2156.Invoke__O() } else { linked_2155.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2154) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :235:1
func A_arbace_go_check_check_package_fn__1686000205_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000205_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000205_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1686000205_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1686000205_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2178 any = A_arbace_go_check_A_const_226.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp3 any; var root_2182 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any; var t_ any = t.F_d; t.F_d = nil; arg_2185 = t_; if linked_2183 == nil { tmp3 = ifn_2184.Invoke_O__O(arg_2185) } else { tmp3 = linked_2183.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2182, arg_2185) }; arg_2181 = tmp2.Invoke_O__O(tmp3); if linked_2179 == nil { tmp1 = ifn_2180.Invoke_O__O(arg_2181) } else { tmp1 = linked_2179.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2178, arg_2181) } }
//line :235:1
	return nil }(); var root_2186 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; if linked_2187 == nil { ifn_2188.Invoke__O() } else { linked_2187.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2186) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_go_check_check_package_init_entry__1686000231_A_New() *A_arbace_go_check_check_package_init_entry__1686000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1686000231_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1686000231_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1686000231_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var fnbody__918 any = A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A_New(); var tmp1 *jrt.Class; var fncls__917 *jrt.Class = A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A_fn_class; if
													fncls__917 == nil { var fncls__917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A_fn_class = fncls__917d; tmp1 = fncls__917d } else { tmp1 = fncls__917 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__918, tmp1, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp2 lang.IFn = lang.IFn_Cast(one__2); var tmp3 any; var root_930 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = lhs__1; if linked_931 == nil { tmp3 = ifn_932.Invoke_O__O(arg_933) } else { tmp3 = linked_931.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_930, arg_933) }; return tmp2.Invoke_O__O(tmp3) } else { var root_919 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var arg_923 any = A_arbace_go_check_A_const_137; var arg_924 any; var root_925 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = one__2; var arg_929 any = lhs__1; if linked_926 == nil { arg_924 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { arg_924 = linked_926.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }; if linked_920 == nil { return ifn_921.Invoke_O_O_O__O(arg_922, arg_923, arg_924) } else { return linked_920.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_919, arg_922, arg_923, arg_924) } } }
//line :258:1
func A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A_New() *A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_893 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = v__1; var arg_897 any = A_arbace_go_check_A_const_71; if linked_894 == nil { tmp1 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { tmp1 = linked_894.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, tmp1) { var tmp2 any; var root_907 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = v__1; var arg_911 any = A_arbace_go_check_A_const_74; if linked_908 == nil { tmp2 = ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { tmp2 = linked_908.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_907, arg_910, arg_911) }; var tmp3 any = tmp2; var tmp4 any; var root_912 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = v__1; var arg_916 any = A_arbace_go_check_A_const_79; if linked_913 == nil { tmp4 = ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { tmp4 = linked_913.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_912, arg_915, arg_916) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_898 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any; var root_902 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = v__1; var arg_906 any = A_arbace_go_check_A_const_71; if linked_903 == nil { arg_901 = ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { arg_901 = linked_903.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }; if linked_899 == nil { return ifn_900.Invoke_O__O(arg_901) } else { return linked_899.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_898, arg_901) } } }



func A_arbace_go_check_check_package_norm__1686000235_A_New() *A_arbace_go_check_check_package_norm__1686000235_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1686000235_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1686000235_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1686000235_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_941 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_943 lang.IFn; if
												linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = x__1; if linked_942 == nil { tmp1 = ifn_943.Invoke_O__O(arg_944) } else { tmp1 = linked_942.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_941, arg_944) }; if /*line :262:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_945 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_947 lang.IFn

		if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = x__1; if linked_946 == nil { tmp2 = ifn_947.Invoke_O__O(arg_948) } else { tmp2 = linked_946.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_945, arg_948) }
//line :262:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_91, tmp2) {


			var root_949 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var arg_953 any = A_arbace_go_check_A_const_138; var arg_954 any; var root_955 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any; var fnbody__965 any = A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A_New(); var tmp3 *jrt.Class; var fncls__964 *jrt.Class = A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A_fn_class; if fncls__964 == nil { var fncls__964d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A_fn_class = fncls__964d; tmp3 = fncls__964d } else { tmp3 = fncls__964 }; arg_958 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__965, tmp3, nil); var arg_959 any; var root_966 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = x__1; if linked_967 == nil { arg_959 = ifn_968.Invoke_O__O(arg_969) } else { arg_959 = linked_967.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_966, arg_969) }; if linked_956 == nil { arg_954 = ifn_957.Invoke_O_O__O(arg_958, arg_959) } else { arg_954 = linked_956.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_955, arg_958, arg_959) }; if linked_950 == nil { return ifn_951.Invoke_O_O_O__O(arg_952, arg_953, arg_954) } else { return linked_950.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_949, arg_952, arg_953, arg_954) } } else {
//line :262:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A_New() *A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A) Ctor() {}
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A) Invoke_O_O__O(self, p1__1686000113_SHARP___1 any) any { var tmp1 any; var root_960 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = p1__1686000113_SHARP___1; if linked_961 == nil { tmp1 = ifn_962.Invoke_O__O(arg_963) } else { tmp1 = linked_961.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_960, arg_963) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1686000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1686000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1686000113_SHARP___1 } }














func A_arbace_go_check_check_package_fn__1686000239_A_New() *A_arbace_go_check_check_package_fn__1686000239_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000239_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_go_check_check_package_fn__1686000239_A) Ctor() {}
//line :280:1
func (t *A_arbace_go_check_check_package_fn__1686000239_A) Invoke_O_O__O(self, p1__1686000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_147; var tmp2 any; var root_1001 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = p1__1686000114_SHARP___1; if linked_1002 == nil { tmp2 = ifn_1003.Invoke_O__O(arg_1004) } else { tmp2 = linked_1002.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1001, arg_1004) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_148; var tmp4 any; var root_1005 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = p1__1686000114_SHARP___1; if linked_1006 == nil { tmp4 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp4 = linked_1006.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1005, arg_1008) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1686000241_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000241_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000241_A{}; t.Ctor_O(p0); return t }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1686000241_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1686000241_A) Invoke_O_O__O(self, p1__1686000115_SHARP___1 any) any { var root_1020 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = t.F_generic_ids; var arg_1024 any = A_arbace_go_check_A_const_128.Invoke_O__O(p1__1686000115_SHARP___1); if linked_1021 == nil { return ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { return linked_1021.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) } }







func A_arbace_go_check_check_package_fn__1686000247_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000247_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000247_A{}; t.Ctor_O(p0); return t }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1686000247_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1686000247_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.IdentityHashMap_Cast(t.F_m).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1686000250_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_A{}; t.Ctor_O(p0); return t }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1686000250_A) Ctor_O(c__resolving any) { t.F_resolving = c__resolving }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1686000250_A) Invoke_O_O_O__O(self, acc__1, p__1686000249__2 any) any { var vec__1686000251__3 any = p__1686000249__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000251__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000251__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_1040 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1042 lang.IFn; if
															linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any; var fnbody__1050 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A_New(); var tmp1 *jrt.Class; var fncls__1049 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A_fn_class; if fncls__1049 == nil { var fncls__1049d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A_fn_class = fncls__1049d; tmp1 = fncls__1049d } else { tmp1 = fncls__1049 }; arg_1043 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1050, tmp1, nil); var arg_1044 any = ds__5; if linked_1041 == nil { gen__6 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { gen__6 = linked_1041.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) }; var uses_generics__7 any; var root_1051 any = /*line :292:1*/A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1053 lang.IFn; if

	linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any; var fnbody__1061 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A_New(); var tmp2 *jrt.Class; var fncls__1060 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A_fn_class; if fncls__1060 == nil { var fncls__1060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A_fn_class = fncls__1060d; tmp2 = fncls__1060d } else { tmp2 = fncls__1060 }; arg_1054 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1061, tmp2, nil); var arg_1055 any = ds__5; if linked_1052 == nil { uses_generics__7 = ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { uses_generics__7 = linked_1052.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }; var present__8 any; if
	jrt.J2g_Truth(t.F_resolving) { present__8 = lang.PersistentArrayMap_EMPTY.Ref() } else { var root_1062 any = A_arbace_go_check_A_const_153.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, A_arbace_go_check_annotations_present_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = form__4; if linked_1063 == nil { present__8 = ifn_1064.Invoke_O__O(arg_1065) } else { present__8 = linked_1063.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_1062, arg_1065) } }; var verified__9 any; var root_1066 any = /*line :292:1*/A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1068 lang.IFn; if



	linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var arg_1070 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1071 any; var root_1072 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any; var fnbody__1082 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A_New(); var tmp3 *jrt.Class; var fncls__1081 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A_fn_class; if fncls__1081 == nil { var fncls__1081d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A_fn_class = fncls__1081d; tmp3 = fncls__1081d } else { tmp3 = fncls__1081 }; arg_1075 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1082, tmp3, nil); var arg_1076 any = ds__5; if linked_1073 == nil { arg_1071 = ifn_1074.Invoke_O_O__O(arg_1075, arg_1076) } else { arg_1071 = linked_1073.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1072, arg_1075, arg_1076) }; if linked_1067 == nil { verified__9 = ifn_1068.Invoke_O_O_O__O(arg_1069, arg_1070, arg_1071) } else { verified__9 = linked_1067.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1066, arg_1069, arg_1070, arg_1071) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_1083 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any; var root_1090 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = acc__1; var arg_1094 any = A_arbace_go_check_A_const_155; var arg_1095 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); if linked_1091 == nil { arg_1086 = ifn_1092.Invoke_O_O_O__O(arg_1093, arg_1094, arg_1095) } else { arg_1086 = linked_1091.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1090, arg_1093, arg_1094, arg_1095) }; var arg_1087 any = A_arbace_go_check_A_const_157; var arg_1088 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1089 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1084 == nil { acc__10 = ifn_1085.Invoke_O_O_O_O__O(arg_1086, arg_1087, arg_1088, arg_1089) } else { acc__10 = linked_1084.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1083, arg_1086, arg_1087, arg_1088, arg_1089) } } else {
//line :297:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_1096 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1102 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1104 lang.IFn
//line :303:1
		if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any; var root_1108 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1110 lang.IFn
//line :302:1
		if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = acc__10; var arg_1112 any = A_arbace_go_check_A_const_158; var arg_1113 any; var root_1114 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var arg_1118 any = A_arbace_go_check_A_const_22; if linked_1115 == nil { arg_1113 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { arg_1113 = linked_1115.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }; if linked_1109 == nil { arg_1105 = ifn_1110.Invoke_O_O_O__O(arg_1111, arg_1112, arg_1113) } else { arg_1105 = linked_1109.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1108, arg_1111, arg_1112, arg_1113) }
		var arg_1106 any = A_arbace_go_check_A_const_159; var arg_1107 any; var fnbody__1126 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A_New_O(present__8); var tmp4 *jrt.Class; var fncls__1125 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A_fn_class; if fncls__1125 == nil { var fncls__1125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1126); A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A_fn_class = fncls__1125d; tmp4 = fncls__1125d } else { tmp4 = fncls__1125 }; arg_1107 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1126, tmp4, nil); if linked_1103 == nil { arg_1099 = ifn_1104.Invoke_O_O_O__O(arg_1105, arg_1106, arg_1107) } else { arg_1099 = linked_1103.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1102, arg_1105, arg_1106, arg_1107) }
		var arg_1100 any = A_arbace_go_check_A_const_147; var arg_1101 any; var fnbody__1151 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A_New_O(ds__5); var tmp5 *jrt.Class; var fncls__1150 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A_fn_class; if fncls__1150 == nil { var fncls__1150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1151); A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A_fn_class = fncls__1150d; tmp5 = fncls__1150d } else { tmp5 = fncls__1150 }; arg_1101 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1151, tmp5, nil); if linked_1097 == nil { return ifn_1098.Invoke_O_O_O__O(arg_1099, arg_1100, arg_1101) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1096, arg_1099, arg_1100, arg_1101) } } else {
//line :300:1
			var unver__11 any; var root_1152 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1154 lang.IFn




			if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1156 any; var iter__1927001039__auto____11 any; var fnbody__1242 any = A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A_New_O(verified__9); var tmp6 *jrt.Class; var fncls__1241 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A_fn_class; if fncls__1241 == nil { var fncls__1241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1242); A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A_fn_class = fncls__1241d; tmp6 = fncls__1241d } else { tmp6 = fncls__1241 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1242, tmp6, nil); arg_1156 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1153 == nil { unver__11 = ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { unver__11 = linked_1153.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156)
			}








			var root_1243 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any; var root_1249 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1251 lang.IFn
//line :314:1
			if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any; var root_1255 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1257 lang.IFn
//line :313:1
			if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any; var root_1261 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1263 lang.IFn
//line :312:1
			if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var root_1267 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1269 lang.IFn
//line :311:1
			if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any; var root_1274 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1276 lang.IFn
//line :310:1
			if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = acc__10; var arg_1278 any = A_arbace_go_check_A_const_166; var arg_1279 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); if linked_1275 == nil { arg_1270 = ifn_1276.Invoke_O_O_O__O(arg_1277, arg_1278, arg_1279) } else { arg_1270 = linked_1275.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1274, arg_1277, arg_1278, arg_1279) }
			var arg_1271 any = A_arbace_go_check_A_const_83; var arg_1272 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1273 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1268 == nil { arg_1264 = ifn_1269.Invoke_O_O_O_O__O(arg_1270, arg_1271, arg_1272, arg_1273) } else { arg_1264 = linked_1268.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1267, arg_1270, arg_1271, arg_1272, arg_1273) }
			var arg_1265 any = A_arbace_go_check_A_const_167; var arg_1266 any; var fnbody__1287 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A_New_O(present__8); var tmp7 *jrt.Class; var fncls__1286 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A_fn_class; if fncls__1286 == nil { var fncls__1286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1287); A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A_fn_class = fncls__1286d; tmp7 = fncls__1286d } else { tmp7 = fncls__1286 }; arg_1266 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1287, tmp7, nil); if linked_1262 == nil { arg_1258 = ifn_1263.Invoke_O_O_O__O(arg_1264, arg_1265, arg_1266) } else { arg_1258 = linked_1262.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1261, arg_1264, arg_1265, arg_1266) }
			var arg_1259 any = A_arbace_go_check_A_const_143; var arg_1260 any; var fnbody__1295 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A_New_O(verified__9); var tmp8 *jrt.Class; var fncls__1294 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A_fn_class; if fncls__1294 == nil { var fncls__1294d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1295); A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A_fn_class = fncls__1294d; tmp8 = fncls__1294d } else { tmp8 = fncls__1294 }; arg_1260 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1295, tmp8, nil); if linked_1256 == nil { arg_1252 = ifn_1257.Invoke_O_O_O__O(arg_1258, arg_1259, arg_1260) } else { arg_1252 = linked_1256.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1255, arg_1258, arg_1259, arg_1260) }
			var arg_1253 any = A_arbace_go_check_A_const_168; var arg_1254 any; var fnbody__1303 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A_New_O(unver__11); var tmp9 *jrt.Class; var fncls__1302 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A_fn_class; if fncls__1302 == nil { var fncls__1302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1303); A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A_fn_class = fncls__1302d; tmp9 = fncls__1302d } else { tmp9 = fncls__1302 }; arg_1254 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1303, tmp9, nil); if linked_1250 == nil { arg_1246 = ifn_1251.Invoke_O_O_O__O(arg_1252, arg_1253, arg_1254) } else { arg_1246 = linked_1250.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1249, arg_1252, arg_1253, arg_1254) }
			var arg_1247 any = A_arbace_go_check_A_const_169; var arg_1248 any; var fnbody__1326 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A_New_O_O_O(form__4, ds__5, unver__11); var tmp10 *jrt.Class; var fncls__1325 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A_fn_class; if fncls__1325 == nil { var fncls__1325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1326); A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A_fn_class = fncls__1325d; tmp10 = fncls__1325d } else { tmp10 = fncls__1325 }; arg_1248 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1326, tmp10, nil); if linked_1244 == nil { return ifn_1245.Invoke_O_O_O__O(arg_1246, arg_1247, arg_1248) } else { return linked_1244.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1243, arg_1246, arg_1247, arg_1248) } } }
//line :293:1
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A_New() *A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A) Ctor() {}
//line :293:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A) Invoke_O_O__O(self, p1__1686000116_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_147; var tmp2 any; var root_1045 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = p1__1686000116_SHARP___1; if linked_1046 == nil { tmp2 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp2 = linked_1046.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1045, arg_1048) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A_New() *A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A) Ctor() {}
//line :294:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A) Invoke_O_O__O(self, p1__1686000117_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_152; var tmp2 any; var root_1056 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = p1__1686000117_SHARP___1; if linked_1057 == nil { tmp2 = ifn_1058.Invoke_O__O(arg_1059) } else { tmp2 = linked_1057.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1056, arg_1059) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A_New() *A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A) Invoke_O_O__O(self, p1__1686000118_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_143; var tmp2 any; var root_1077 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = p1__1686000118_SHARP___1; if linked_1078 == nil { tmp2 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp2 = linked_1078.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1077, arg_1080) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A{}; t.Ctor_O(p0); return t }
//line :303:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :303:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A) Invoke_O_O__O(self, p1__1686000119_SHARP___1 any) any { var root_1119 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1123 any = p1__1686000119_SHARP___1; var arg_1124 any = t.F_present; if linked_1120 == nil { return ifn_1121.Invoke_O_O_O__O(arg_1122, arg_1123, arg_1124) } else { return linked_1120.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1119, arg_1122, arg_1123, arg_1124) } }
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :304:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A) Invoke_O_O__O(self, p1__1686000120_SHARP___1 any) any { var root_1127 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var fnbody__1149 any = A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A_New(); var tmp1 *jrt.Class; var fncls__1148 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A_fn_class; if fncls__1148 == nil { var fncls__1148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A_fn_class = fncls__1148d; tmp1 = fncls__1148d } else { tmp1 = fncls__1148 }; arg_1130 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1149, tmp1, nil); var arg_1131 any = p1__1686000120_SHARP___1; var arg_1132 any = t.F_ds; if linked_1128 == nil { return ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { return linked_1128.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) } }
//line :304:1
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A_New() *A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A) Ctor() {}
//line :304:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_147; var tmp2 any; var root_1133 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = d__2; if linked_1134 == nil { tmp2 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp2 = linked_1134.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1133, arg_1136) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_1137 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = m__1; var arg_1141 any = u__4; var arg_1142 any; var root_1143 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var arg_1147 any = A_arbace_go_check_A_const_22; if linked_1144 == nil { arg_1142 = ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { arg_1142 = linked_1144.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) }; if linked_1138 == nil { return ifn_1139.Invoke_O_O_O__O(arg_1140, arg_1141, arg_1142) } else { return linked_1138.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1137, arg_1140, arg_1141, arg_1142) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A) Invoke_O_O__O(self, s__1686000267__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1240 any = A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A_New_O_O_O(s__1686000267__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A_fn_class; if fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__1240); A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A_fn_class = fncls__1239d; tmp2 = fncls__1239d } else { tmp2 = fncls__1239 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1240, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :305:1
func A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A) Ctor_O_O_O(c__s__1686000267, c__iter__1686000266, c__verified any) { t.F_s__1686000267 = c__s__1686000267; t.F_iter__1686000266 = c__iter__1686000266; t.F_verified = c__verified }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A) Invoke_O__O(self any) any { { var s__1686000267__1 any; var t_ any = t.F_s__1686000267; t.F_s__1686000267 = nil; s__1686000267__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1157 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = s__1686000267__1; if linked_1158 == nil { temp__1927000414__auto____2 = ifn_1159.Invoke_O__O(arg_1160) } else { temp__1927000414__auto____2 = linked_1158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1157, arg_1160) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000267__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1161 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = s__1686000267__3; if linked_1162 == nil { tmp1 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp1 = linked_1162.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1161, arg_1164) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1165 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = s__1686000267__3; if linked_1166 == nil { c__1927001037__auto____4 = ifn_1167.Invoke_O__O(arg_1168) } else { c__1927001037__auto____4 = linked_1166.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1165, arg_1168) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000269__6 any; var root_1169 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1170 == nil { b__1686000269__6 = ifn_1171.Invoke_O__O(arg_1172) } else { b__1686000269__6 = linked_1170.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1169, arg_1172) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1189 any = A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A_New_O_I_O_O(b__1686000269__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A_fn_class; if fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1189); A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A_fn_class = fncls__1188d; tmp3 = fncls__1188d } else { tmp3 = fncls__1188 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1189, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1190 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any; var root_1195 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = b__1686000269__6; if linked_1196 == nil { arg_1193 = ifn_1197.Invoke_O__O(arg_1198) } else { arg_1193 = linked_1196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1195, arg_1198) }; var arg_1194 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000266); var tmp5 any; var root_1199 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = s__1686000267__3; if linked_1200 == nil { tmp5 = ifn_1201.Invoke_O__O(arg_1202) } else { tmp5 = linked_1200.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1199, arg_1202) }; arg_1194 = tmp4.Invoke_O__O(tmp5); if linked_1191 == nil { return ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { return linked_1191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) } } else { var root_1203 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any; var root_1208 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = b__1686000269__6; if linked_1209 == nil { arg_1206 = ifn_1210.Invoke_O__O(arg_1211) } else { arg_1206 = linked_1209.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1208, arg_1211) }; var arg_1207 any; if linked_1204 == nil { return ifn_1205.Invoke_O_O__O(arg_1206, arg_1207) } else { return linked_1204.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1203, arg_1206, arg_1207) } } } else { var vec__1686000277__4 any; var root_1212 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = s__1686000267__3; if linked_1213 == nil { vec__1686000277__4 = ifn_1214.Invoke_O__O(arg_1215) } else { vec__1686000277__4 = linked_1213.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1212, arg_1215) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000277__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000277__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1216 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1218 lang.IFn

	if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = n__6; var arg_1220 any = v__7; if linked_1217 == nil { tmp6 = ifn_1218.Invoke_O_O__O(arg_1219, arg_1220) } else { tmp6 = linked_1217.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1216, arg_1219, arg_1220) }
//line :305:1
	if jrt.J2g_Truth(tmp6) { var root_1221 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any; var tmp7 jrt.Number_I; var na_1226 any = n__6; var na_1227 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1226); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1227) }; tmp8 = tmp9; if tmp8 { var n0_1228 int64 = jrt.NN(jrt.Long_Cast(na_1226)).LongValue__J(); var n1_1229 int64 = jrt.NN(jrt.Long_Cast(na_1227)).LongValue__J(); var nr_1230 int64 = n0_1228 - n1_1229; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1229 == -9223372036854775808); if tmp11 { tmp11 = (n0_1228^n1_1229)&(n0_1228^nr_1230) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1230)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1226, na_1227) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1226); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1227) }; tmp12 = tmp13; if tmp12 { var n0_1228_2 float64 = jrt.NN(jrt.Double_Cast(na_1226)).DoubleValue__D(); var n1_1229_2 float64 = jrt.NN(jrt.Double_Cast(na_1227)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1228_2 + -n1_1229_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1226, na_1227) } }
//line :305:1
		arg_1224 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1225 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1686000266); var tmp15 any; var root_1231 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = s__1686000267__3; if linked_1232 == nil { tmp15 = ifn_1233.Invoke_O__O(arg_1234) } else { tmp15 = linked_1232.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1231, arg_1234) }; arg_1225 = tmp14.Invoke_O__O(tmp15); if linked_1222 == nil { return ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { return linked_1222.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) } } else { var tmp16 any; var root_1235 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = s__1686000267__3; if linked_1236 == nil { tmp16 = ifn_1237.Invoke_O__O(arg_1238) } else { tmp16 = linked_1236.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1235, arg_1238) }; s__1686000267__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :305:1
func A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A) Ctor_O_I_O_O(c__b__1686000269 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1686000269 = c__b__1686000269; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :305:1
func (t *A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A) Invoke_O__O(self any) any { { var i__1686000268__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000268__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1686000273__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000268__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000273__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000273__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1173 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1175 lang.IFn

	if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = n__4; var arg_1177 any = v__5; if linked_1174 == nil { tmp2 = ifn_1175.Invoke_O_O__O(arg_1176, arg_1177) } else { tmp2 = linked_1174.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1173, arg_1176, arg_1177) }
//line :305:1
	if jrt.J2g_Truth(tmp2) { var root_1178 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = t.F_b__1686000269; var arg_1182 any; var tmp3 jrt.Number_I; var na_1183 any = n__4; var na_1184 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1183); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1184) }; tmp4 = tmp5; if tmp4 { var n0_1185 int64 = jrt.NN(jrt.Long_Cast(na_1183)).LongValue__J(); var n1_1186 int64 = jrt.NN(jrt.Long_Cast(na_1184)).LongValue__J(); var nr_1187 int64 = n0_1185 - n1_1186; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1186 == -9223372036854775808); if tmp7 { tmp7 = (n0_1185^n1_1186)&(n0_1185^nr_1187) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1187)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1183, na_1184) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1183); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1184) }; tmp8 = tmp9; if tmp8 { var n0_1185_2 float64 = jrt.NN(jrt.Double_Cast(na_1183)).DoubleValue__D(); var n1_1186_2 float64 = jrt.NN(jrt.Double_Cast(na_1184)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1185_2 + -n1_1186_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1183, na_1184) } }
//line :305:1
		arg_1182 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1179 == nil { ifn_1180.Invoke_O_O__O(arg_1181, arg_1182) } else { linked_1179.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1178, arg_1181, arg_1182) }; i__1686000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000268__1); continue L1 } else { i__1686000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000268__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A{}; t.Ctor_O(p0); return t }
//line :312:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :312:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A) Invoke_O_O__O(self, p1__1686000121_SHARP___1 any) any { var root_1280 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1284 any = p1__1686000121_SHARP___1; var arg_1285 any = t.F_present; if linked_1281 == nil { return ifn_1282.Invoke_O_O_O__O(arg_1283, arg_1284, arg_1285) } else { return linked_1281.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1280, arg_1283, arg_1284, arg_1285) } }
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A{}; t.Ctor_O(p0); return t }
//line :313:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :313:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A) Invoke_O_O__O(self, p1__1686000122_SHARP___1 any) any { var root_1288 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1292 any = p1__1686000122_SHARP___1; var arg_1293 any = t.F_verified; if linked_1289 == nil { return ifn_1290.Invoke_O_O_O__O(arg_1291, arg_1292, arg_1293) } else { return linked_1289.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1288, arg_1291, arg_1292, arg_1293) } }
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :314:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A) Invoke_O_O__O(self, p1__1686000123_SHARP___1 any) any { var root_1296 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1300 any = p1__1686000123_SHARP___1; var arg_1301 any = t.F_unver; if linked_1297 == nil { return ifn_1298.Invoke_O_O_O__O(arg_1299, arg_1300, arg_1301) } else { return linked_1297.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1296, arg_1299, arg_1300, arg_1301) } }
func A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :315:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :315:1
func (t *A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A) Invoke_O_O__O(self, p1__1686000124_SHARP___1 any) any { var tmp1 any; var root_1304 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = t.F_unver; if linked_1305 == nil { tmp1 = ifn_1306.Invoke_O__O(arg_1307) } else { tmp1 = linked_1305.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1304, arg_1307) }; if jrt.J2g_Truth(tmp1) { var root_1308 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = p1__1686000124_SHARP___1; var arg_1312 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_71; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp4 any; var root_1313 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var root_1317 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = t.F_ds; if linked_1318 == nil { arg_1316 = ifn_1319.Invoke_O__O(arg_1320) } else { arg_1316 = linked_1318.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1317, arg_1320) }; if linked_1314 == nil { tmp4 = ifn_1315.Invoke_O__O(arg_1316) } else { tmp4 = linked_1314.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1313, arg_1316) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1321 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = t.F_form; if linked_1322 == nil { tmp6 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp6 = linked_1322.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1321, arg_1324) }; arg_1312 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1309 == nil { return ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { return linked_1309.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) } } else { return p1__1686000124_SHARP___1 } }





















func A_arbace_go_check_check_package_fn__1686000299_A_New() *A_arbace_go_check_check_package_fn__1686000299_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000299_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_fn__1686000299_A) Ctor() {}
//line :337:1
func (t *A_arbace_go_check_check_package_fn__1686000299_A) Invoke_O_O__O(self, p1__1686000125_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_217; var tmp2 any; var root_2553 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2553, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2555 lang.IFn; if linked_2554 == nil { ifn_2555 = lang.IFn_Cast(root_2553) } else { ifn_2555 = nil }; var arg_2556 any = p1__1686000125_SHARP___1; if linked_2554 == nil { tmp2 = ifn_2555.Invoke_O__O(arg_2556) } else { tmp2 = linked_2554.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2553, arg_2556) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1686000301__1686000305_A_New() *A_arbace_go_check_check_package_iter__1686000301__1686000305_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1686000301__1686000305_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_go_check_check_package_iter__1686000301__1686000305_A) Ctor() {}
//line :341:1
func (t *A_arbace_go_check_check_package_iter__1686000301__1686000305_A) Invoke_O_O__O(self, s__1686000302__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2640 any = A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A_New_O_O(s__1686000302__1, self); var tmp2 *jrt.Class; var fncls__2639 *jrt.Class = A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A_fn_class; if fncls__2639 == nil { var fncls__2639d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__2640); A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A_fn_class = fncls__2639d; tmp2 = fncls__2639d } else { tmp2 = fncls__2639 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2640, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :341:1
func A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :341:1
func (t *A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A) Ctor_O_O(c__s__1686000302, c__iter__1686000301 any) { t.F_s__1686000302 = c__s__1686000302; t.F_iter__1686000301 = c__iter__1686000301 }
//line :341:1
func (t *A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A) Invoke_O__O(self any) any { { var s__1686000302__1 any; var t_ any = t.F_s__1686000302; t.F_s__1686000302 = nil; s__1686000302__1 = t_; for { var temp__1927000414__auto____2 any; var root_2563 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any = s__1686000302__1; if linked_2564 == nil { temp__1927000414__auto____2 = ifn_2565.Invoke_O__O(arg_2566) } else { temp__1927000414__auto____2 = linked_2564.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2563, arg_2566) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000302__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2567 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2569 lang.IFn; if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = s__1686000302__3; if linked_2568 == nil { tmp1 = ifn_2569.Invoke_O__O(arg_2570) } else { tmp1 = linked_2568.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2567, arg_2570) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2571 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = s__1686000302__3; if linked_2572 == nil { c__1927001037__auto____4 = ifn_2573.Invoke_O__O(arg_2574) } else { c__1927001037__auto____4 = linked_2572.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2571, arg_2574) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000304__6 any; var root_2575 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2575, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2577 lang.IFn; if linked_2576 == nil { ifn_2577 = lang.IFn_Cast(root_2575) } else { ifn_2577 = nil }; var arg_2578 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2576 == nil { b__1686000304__6 = ifn_2577.Invoke_O__O(arg_2578) } else { b__1686000304__6 = linked_2576.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2575, arg_2578) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2594 any = A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A_New_O_I_O(b__1686000304__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2593 *jrt.Class = A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A_fn_class; if fncls__2593 == nil { var fncls__2593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__2594); A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A_fn_class = fncls__2593d; tmp3 = fncls__2593d } else { tmp3 = fncls__2593 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2594, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2595 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2597 lang.IFn; if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any; var root_2600 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = b__1686000304__6; if linked_2601 == nil { arg_2598 = ifn_2602.Invoke_O__O(arg_2603) } else { arg_2598 = linked_2601.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2600, arg_2603) }; var arg_2599 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000301); var tmp5 any; var root_2604 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = s__1686000302__3; if linked_2605 == nil { tmp5 = ifn_2606.Invoke_O__O(arg_2607) } else { tmp5 = linked_2605.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2604, arg_2607) }; arg_2599 = tmp4.Invoke_O__O(tmp5); if linked_2596 == nil { return ifn_2597.Invoke_O_O__O(arg_2598, arg_2599) } else { return linked_2596.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2595, arg_2598, arg_2599) } } else { var root_2608 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any; var root_2613 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = b__1686000304__6; if linked_2614 == nil { arg_2611 = ifn_2615.Invoke_O__O(arg_2616) } else { arg_2611 = linked_2614.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2613, arg_2616) }; var arg_2612 any; if linked_2609 == nil { return ifn_2610.Invoke_O_O__O(arg_2611, arg_2612) } else { return linked_2609.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2608, arg_2611, arg_2612) } } } else { var d__4 any; var root_2617 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = s__1686000302__3; if linked_2618 == nil { d__4 = ifn_2619.Invoke_O__O(arg_2620) } else { d__4 = linked_2618.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2617, arg_2620) }; var root_2621 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any; var root_2626 any = A_arbace_go_check_A_const_247.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2628 lang.IFn
															if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any; var root_2631 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = d__4; if linked_2632 == nil { arg_2629 = ifn_2633.Invoke_O__O(arg_2634) } else { arg_2629 = linked_2632.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2631, arg_2634) }; var arg_2630 any = A_arbace_go_check_A_const_249; if linked_2627 == nil { arg_2624 = ifn_2628.Invoke_O_O__O(arg_2629, arg_2630) } else { arg_2624 = linked_2627.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2626, arg_2629, arg_2630) }
//line :341:1
	var arg_2625 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1686000301); var tmp7 any; var root_2635 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = s__1686000302__3; if linked_2636 == nil { tmp7 = ifn_2637.Invoke_O__O(arg_2638) } else { tmp7 = linked_2636.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2635, arg_2638) }; arg_2625 = tmp6.Invoke_O__O(tmp7); if linked_2622 == nil { return ifn_2623.Invoke_O_O__O(arg_2624, arg_2625) } else { return linked_2622.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2621, arg_2624, arg_2625) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :341:1
func A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :341:1
func (t *A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A) Ctor_O_I_O(c__b__1686000304 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1686000304 = c__b__1686000304; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :341:1
func (t *A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A) Invoke_O__O(self any) any { { var i__1686000303__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000303__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000303__1)); var root_2579 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2579, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2581 lang.IFn; if linked_2580 == nil { ifn_2581 = lang.IFn_Cast(root_2579) } else { ifn_2581 = nil }; var arg_2582 any = t.F_b__1686000304; var arg_2583 any; var root_2584 any = A_arbace_go_check_A_const_247.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2586 lang.IFn
																	if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any; var root_2589 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = d__2; if linked_2590 == nil { arg_2587 = ifn_2591.Invoke_O__O(arg_2592) } else { arg_2587 = linked_2590.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2589, arg_2592) }; var arg_2588 any = A_arbace_go_check_A_const_248; if linked_2585 == nil { arg_2583 = ifn_2586.Invoke_O_O__O(arg_2587, arg_2588) } else { arg_2583 = linked_2585.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2584, arg_2587, arg_2588) }
//line :341:1
	if linked_2580 == nil { ifn_2581.Invoke_O_O__O(arg_2582, arg_2583) } else { linked_2580.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2579, arg_2582, arg_2583) }; i__1686000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000303__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_check_package_fn__1686000311_A_New() *A_arbace_go_check_check_package_fn__1686000311_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000311_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_check_check_package_fn__1686000311_A) Ctor() {}
//line :347:1
func (t *A_arbace_go_check_check_package_fn__1686000311_A) Invoke_O_O__O(self, lhs__1 any) any { var root_2648 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any; var fnbody__2678 any = A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A_New(); var tmp1 *jrt.Class; var fncls__2677 *jrt.Class = A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A_fn_class; if fncls__2677 == nil { var fncls__2677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A_fn_class = fncls__2677d; tmp1 = fncls__2677d } else { tmp1 = fncls__2677 }; arg_2651 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2678, tmp1, nil); var arg_2652 any = lhs__1; if linked_2649 == nil { return ifn_2650.Invoke_O_O__O(arg_2651, arg_2652) } else { return linked_2649.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2648, arg_2651, arg_2652) } }
//line :347:1
func A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A_New() *A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A) Ctor() {}
//line :347:1
func (t *A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_2653 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = v__1; var arg_2657 any = A_arbace_go_check_A_const_71; if linked_2654 == nil { tmp1 = ifn_2655.Invoke_O_O__O(arg_2656, arg_2657) } else { tmp1 = linked_2654.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2653, arg_2656, arg_2657) }; var tmp2 any = tmp1; var tmp3 any; var root_2658 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = v__1; var arg_2662 any = A_arbace_go_check_A_const_74; if linked_2659 == nil { tmp3 = ifn_2660.Invoke_O_O__O(arg_2661, arg_2662) } else { tmp3 = linked_2659.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2658, arg_2661, arg_2662) }; var tmp4 any = tmp3; var tmp5 any; var root_2663 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2663, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2665 lang.IFn; if linked_2664 == nil { ifn_2665 = lang.IFn_Cast(root_2663) } else { ifn_2665 = nil }; var arg_2666 any = v__1; var arg_2667 any = A_arbace_go_check_A_const_79; if linked_2664 == nil { tmp5 = ifn_2665.Invoke_O_O__O(arg_2666, arg_2667) } else { tmp5 = linked_2664.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2663, arg_2666, arg_2667) }; var tmp6 any = tmp5; var tmp7 any; var root_2668 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any; var root_2672 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = v__1; var arg_2676 any = A_arbace_go_check_A_const_253; if linked_2673 == nil { arg_2671 = ifn_2674.Invoke_O_O__O(arg_2675, arg_2676) } else { arg_2671 = linked_2673.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2672, arg_2675, arg_2676) }; if linked_2669 == nil { tmp7 = ifn_2670.Invoke_O__O(arg_2671) } else { tmp7 = linked_2669.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2668, arg_2671) }; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :355:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_263; var tmp2 any = A_arbace_go_check_A_const_264; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_265; var tmp5 any; var root_2819 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2821 lang.IFn; if



	linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2820 == nil { tmp5 = ifn_2821.Invoke_O__O(arg_2822) } else { tmp5 = linked_2820.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2819, arg_2822) }; return /*line :355:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :363:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2823 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2823, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2825 lang.IFn; if



	linked_2824 == nil { ifn_2825 = lang.IFn_Cast(root_2823) } else { ifn_2825 = nil }; var arg_2826 any = A_arbace_go_check_A_const_265.Invoke_O__O(s__0); if linked_2824 == nil { tmp1 = ifn_2825.Invoke_O__O(arg_2826) } else { tmp1 = linked_2824.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2823, arg_2826) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_264.Invoke_O__O(s__0)).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2827 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2827, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2829 lang.IFn; if linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any = p__5; if linked_2828 == nil { tmp2 = ifn_2829.Invoke_O__O(arg_2830) } else { tmp2 = linked_2828.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2827, arg_2830) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2831 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2831, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2833 lang.IFn; if linked_2832 == nil { ifn_2833 = lang.IFn_Cast(root_2831) } else { ifn_2833 = nil }; var arg_2834 any = p__5; if linked_2832 == nil { or__1927000174__auto____3 = ifn_2833.Invoke_O__O(arg_2834) } else { or__1927000174__auto____3 = linked_2832.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2831, arg_2834) } } else { or__1927000174__auto____3 = nil } } else {
//line :367:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_268.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2835 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, A_arbace_go_check_ns_package_A_fn_class); var ifn_2837 lang.IFn; if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = d__5; var arg_2839 any = ns_name__1; if linked_2836 == nil { return ifn_2837.Invoke_O_O__O(arg_2838, arg_2839) } else { return linked_2836.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2835, arg_2838, arg_2839) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :372:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var fnbody__2884 any = A_arbace_go_check_resolver_fn__1686000318_A_New_O_O_O(src__1, s__0, chain__2); var tmp1 *jrt.Class; var fncls__2883 *jrt.Class = A_arbace_go_check_resolver_fn__1686000318_A_fn_class; _ = deps__4; if




	fncls__2883 == nil { var fncls__2883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__2884); A_arbace_go_check_resolver_fn__1686000318_A_fn_class = fncls__2883d; tmp1 = fncls__2883d } else { tmp1 = fncls__2883 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2884, tmp1, nil) }
//line :377:1
func A_arbace_go_check_resolver_fn__1686000318_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1686000318_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1686000318_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :377:1
func (t *A_arbace_go_check_resolver_fn__1686000318_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :377:1
func (t *A_arbace_go_check_resolver_fn__1686000318_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_136, path__1) { return A_arbace_go_check_A_const_270.GetRawRoot__O() } else { var lp__3 any; var root_2840 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_2841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2840, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2842 lang.IFn

		if linked_2841 == nil { ifn_2842 = lang.IFn_Cast(root_2840) } else { ifn_2842 = nil }; var arg_2843 any = t.F_src; var arg_2844 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_271, path__1); var arg_2845 any = path__1; if linked_2841 == nil { lp__3 = ifn_2842.Invoke_O_O_O__O(arg_2843, arg_2844, arg_2845) } else { lp__3 = linked_2841.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2840, arg_2843, arg_2844, arg_2845) }
//line :380:1
		var why__4 any; var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_272.Invoke_O__O(t.F_s)



		if jrt.J2g_Truth(temp__1927000414__auto____4) { var rf__5 any = temp__1927000414__auto____4; why__4 = lang.IFn_Cast(rf__5).Invoke_O_O__O(lp__3, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src)) } else { why__4 = nil }
//line :380:1
		var p__5 any
		var or__1927000174__auto____5 any = why__4




		if jrt.J2g_Truth(or__1927000174__auto____5) { p__5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_2846 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2848 lang.IFn
			if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; var arg_2849 any = t.F_s; var arg_2850 any = lp__3; var arg_2851 any = t.F_src; var arg_2852 any = t.F_chain; if linked_2847 == nil { or__1927000174__auto____6 = ifn_2848.Invoke_O_O_O_O__O(arg_2849, arg_2850, arg_2851, arg_2852) } else { or__1927000174__auto____6 = linked_2847.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2846, arg_2849, arg_2850, arg_2851, arg_2852) }
//line :386:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { p__5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 any; var and__1927000168__auto____7 any; var root_2853 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2853, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2855 lang.IFn

				if linked_2854 == nil { ifn_2855 = lang.IFn_Cast(root_2853) } else { ifn_2855 = nil }; var arg_2856 any; var root_2857 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any; var root_2862 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2862, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2864 lang.IFn; if linked_2863 == nil { ifn_2864 = lang.IFn_Cast(root_2862) } else { ifn_2864 = nil }; var arg_2865 any; var root_2866 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2866, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2868 lang.IFn; if linked_2867 == nil { ifn_2868 = lang.IFn_Cast(root_2866) } else { ifn_2868 = nil }; var arg_2869 any = lp__3; var arg_2870 any = A_arbace_go_check_A_const_276; if linked_2867 == nil { arg_2865 = ifn_2868.Invoke_O_O__O(arg_2869, arg_2870) } else { arg_2865 = linked_2867.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2866, arg_2869, arg_2870) }; if linked_2863 == nil { arg_2860 = ifn_2864.Invoke_O__O(arg_2865) } else { arg_2860 = linked_2863.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2862, arg_2865) }; var arg_2861 any = Lit_137; if linked_2858 == nil { arg_2856 = ifn_2859.Invoke_O_O__O(arg_2860, arg_2861) } else { arg_2856 = linked_2858.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2857, arg_2860, arg_2861) }; if linked_2854 == nil { and__1927000168__auto____7 = ifn_2855.Invoke_O__O(arg_2856) } else { and__1927000168__auto____7 = linked_2854.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2853, arg_2856) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____7 = nil } else { or__1927000174__auto____7 = nil }
//line :386:1
				if jrt.J2g_Truth(or__1927000174__auto____7) { p__5 = or__1927000174__auto____7 } else {


					var root_2871 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2871, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any = t.F_s; var arg_2875 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2876 any = t.F_src; var arg_2877 any = t.F_chain; if linked_2872 == nil { p__5 = ifn_2873.Invoke_O_O_O_O__O(arg_2874, arg_2875, arg_2876, arg_2877) } else { p__5 = linked_2872.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2871, arg_2874, arg_2875, arg_2876, arg_2877) } } } }
//line :380:1
		return p__5 } }
//line :377:1
func (t *A_arbace_go_check_resolver_fn__1686000318_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2878 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, A_arbace_go_check_ns_package_A_fn_class); var ifn_2880 lang.IFn; if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = t.F_s; var arg_2882 any = ns_name__1; if linked_2879 == nil { return ifn_2880.Invoke_O_O__O(arg_2881, arg_2882) } else { return linked_2879.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2878, arg_2881, arg_2882)
	}
}











func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :392:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2967 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2971 any = chain__3; if linked_2968 == nil { tmp1 = ifn_2969.Invoke_O_O__O(arg_2970, arg_2971) } else { tmp1 = linked_2968.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2967, arg_2970, arg_2971) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2972 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2972, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2974 lang.IFn
		if linked_2973 == nil { ifn_2974 = lang.IFn_Cast(root_2972) } else { ifn_2974 = nil }; var arg_2975 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_110, nil); var tmp4 any; var root_2977 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = Lit_111; var arg_2981 any; var root_2982 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2984 lang.IFn; if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any = chain__3; var arg_2986 any = path__1; if linked_2983 == nil { arg_2981 = ifn_2984.Invoke_O_O__O(arg_2985, arg_2986) } else { arg_2981 = linked_2983.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2982, arg_2985, arg_2986) }; if linked_2978 == nil { tmp4 = ifn_2979.Invoke_O_O__O(arg_2980, arg_2981) } else { tmp4 = linked_2978.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2977, arg_2980, arg_2981) }; arg_2975 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2976 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111, path__1)); if linked_2973 == nil { tmp2 = ifn_2974.Invoke_O_O__O(arg_2975, arg_2976) } else { tmp2 = linked_2973.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2972, arg_2975, arg_2976) }
//line :395:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :392:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_268.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2885 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = lang.IFn_Cast(A_arbace_go_check_A_const_277.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2886 == nil { and__1927000168__auto____6 = ifn_2887.Invoke_O__O(arg_2888) } else { and__1927000168__auto____6 = linked_2886.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2885, arg_2888) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_268.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2889 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2891 lang.IFn

		if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = d__6; var arg_2893 any = path__1; var arg_2894 any = importer__2; var arg_2895 any = chain__3; if linked_2890 == nil { return ifn_2891.Invoke_O_O_O_O__O(arg_2892, arg_2893, arg_2894, arg_2895) } else { return linked_2890.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2889, arg_2892, arg_2893, arg_2894, arg_2895) } } else {
//line :397:1
			var cache__6 any = A_arbace_go_check_A_const_264.Invoke_O__O(s__0); var p__7 any; var root_2896 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2898 lang.IFn



			if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; if linked_2897 == nil { p__7 = ifn_2898.Invoke__O() } else { p__7 = linked_2897.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2896) }
//line :397:1
			var prev__8 any = jrt.ConcurrentHashMap_Cast(cache__6).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2899 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2901 lang.IFn; if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = prev__8; if linked_2900 == nil { return ifn_2901.Invoke_O__O(arg_2902) } else { return linked_2900.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2899, arg_2902) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_263.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2903 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2903, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2905 lang.IFn; if linked_2904 == nil { ifn_2905 = lang.IFn_Cast(root_2903) } else { ifn_2905 = nil }; var arg_2906 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__9); if linked_2904 == nil { tmp5 = ifn_2905.Invoke_O__O(arg_2906) } else { tmp5 = linked_2904.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2903, arg_2906) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 *lang.Compiler_AOTFn; var fnbody__2966 any = A_arbace_go_check_ensure_package_fn__1686000321_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2965 *jrt.Class = A_arbace_go_check_ensure_package_fn__1686000321_A_fn_class; if fncls__2965 == nil { var fncls__2965d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2966); A_arbace_go_check_ensure_package_fn__1686000321_A_fn_class = fncls__2965d; tmp7 = fncls__2965d } else { tmp7 = fncls__2965 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2966, tmp7, nil); pkg__10 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O() } else {
//line :406:1
						pkg__10 = nil
					}






				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2987 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2988 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2987, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2989 lang.IFn; if linked_2988 == nil { ifn_2989 = lang.IFn_Cast(root_2987) } else { ifn_2989 = nil }; var arg_2990 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2991 any = A_arbace_go_check_A_const_284; var arg_2992 any; var root_2993 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2993, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2995 lang.IFn; if linked_2994 == nil { ifn_2995 = lang.IFn_Cast(root_2993) } else { ifn_2995 = nil }; var arg_2996 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2997 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_285; var tmp11 any; var root_2998 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2998, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3000 lang.IFn; if linked_2999 == nil { ifn_3000 = lang.IFn_Cast(root_2998) } else { ifn_3000 = nil }; var arg_3001 any = pkg__10; var arg_3002 any = A_arbace_go_check_A_const_72; if linked_2999 == nil { tmp11 = ifn_3000.Invoke_O_O__O(arg_3001, arg_3002) } else { tmp11 = linked_2999.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2998, arg_3001, arg_3002) }; arg_2997 = tmp10.Invoke_O__O(tmp11); if linked_2994 == nil { arg_2992 = ifn_2995.Invoke_O_O__O(arg_2996, arg_2997) } else { arg_2992 = linked_2994.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2993, arg_2996, arg_2997) }; if linked_2988 == nil { tmp9 = ifn_2989.Invoke_O_O_O__O(arg_2990, arg_2991, arg_2992) } else { tmp9 = linked_2988.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2987, arg_2990, arg_2991, arg_2992) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_3003 any = A_arbace_go_check_A_const_286.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = A_arbace_go_check_A_const_265.Invoke_O__O(s__0); var arg_3007 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var arg_3008 any; var root_3010 any = A_arbace_go_check_A_const_191.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_3012 lang.IFn; if linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any = path__1; if linked_3011 == nil { arg_3008 = ifn_3012.Invoke_O__O(arg_3013) } else { arg_3008 = linked_3011.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_3010, arg_3013) }; var arg_3009 any = path__1; if linked_3004 == nil { ifn_3005.Invoke_O_O_O_O__O(arg_3006, arg_3007, arg_3008, arg_3009) } else { linked_3004.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3003, arg_3006, arg_3007, arg_3008, arg_3009) }
				var root_3014 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_3015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3014, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_3016 lang.IFn; if linked_3015 == nil { ifn_3016 = lang.IFn_Cast(root_3014) } else { ifn_3016 = nil }; var arg_3017 any = p__7; var arg_3018 any = pkg__10; if linked_3015 == nil { ifn_3016.Invoke_O_O__O(arg_3017, arg_3018) } else { linked_3015.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_3014, arg_3017, arg_3018) }
//line :403:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1686000321_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1686000321_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1686000321_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :407:1
func (t *A_arbace_go_check_ensure_package_fn__1686000321_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :407:1
func (t *A_arbace_go_check_ensure_package_fn__1686000321_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var G__1686000322__3_ any = A_arbace_go_check_A_const_109.Invoke_O__O(t.F_s); if lang.Util_Identical_O_O__Z_NoInit(G__1686000322__3_, nil) { tmp2 = nil } else { var root_2907 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2907, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2909 lang.IFn; if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any = G__1686000322__3_; var arg_2911 any = lang.Tuple_Create_O__IPersistentVector(t.F_path); if linked_2908 == nil { tmp2 = ifn_2909.Invoke_O_O__O(arg_2910, arg_2911) } else { tmp2 = linked_2908.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2907, arg_2910, arg_2911) } }; if jrt.J2g_Truth(tmp2) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_279.GetRawRoot__O()); var tmp4 any = t.F_src; var tmp5 any; var root_2919 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, A_arbace_go_check_resolver_A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any; var t_ any = t.F_s; t.F_s = nil; arg_2922 = t_; var arg_2923 any; var t__2 any = t.F_src; t.F_src = nil; arg_2923 = t__2; var arg_2924 any; var root_2925 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any; var root_2930 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2930, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2932 lang.IFn; if linked_2931 == nil { ifn_2932 = lang.IFn_Cast(root_2930) } else { ifn_2932 = nil }; var arg_2933 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2933 = t__3; if linked_2931 == nil { arg_2928 = ifn_2932.Invoke_O__O(arg_2933) } else { arg_2928 = linked_2931.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2930, arg_2933) }; var arg_2929 any = t.F_path; if linked_2926 == nil { arg_2924 = ifn_2927.Invoke_O_O__O(arg_2928, arg_2929) } else { arg_2924 = linked_2926.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2925, arg_2928, arg_2929) }; if linked_2920 == nil { tmp5 = ifn_2921.Invoke_O_O_O__O(arg_2922, arg_2923, arg_2924) } else { tmp5 = linked_2920.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2919, arg_2922, arg_2923, arg_2924) }; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, A_arbace_go_check_A_const_109, jrt.Boolean_TRUE.Ref()) } else {
													var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_279.GetRawRoot__O()); var tmp7 any = t.F_src; var tmp8 any; var root_2939 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, A_arbace_go_check_resolver_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any; var t__4 any = t.F_s; t.F_s = nil; arg_2942 = t__4; var arg_2943 any; var t__5 any = t.F_src; t.F_src = nil; arg_2943 = t__5; var arg_2944 any; var root_2945 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2945, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2947 lang.IFn; if linked_2946 == nil { ifn_2947 = lang.IFn_Cast(root_2945) } else { ifn_2947 = nil }; var arg_2948 any; var root_2950 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2950, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2952 lang.IFn; if linked_2951 == nil { ifn_2952 = lang.IFn_Cast(root_2950) } else { ifn_2952 = nil }; var arg_2953 any; var t__6 any = t.F_chain; t.F_chain = nil; arg_2953 = t__6; if linked_2951 == nil { arg_2948 = ifn_2952.Invoke_O__O(arg_2953) } else { arg_2948 = linked_2951.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2950, arg_2953) }; var arg_2949 any = t.F_path; if linked_2946 == nil { arg_2944 = ifn_2947.Invoke_O_O__O(arg_2948, arg_2949) } else { arg_2944 = linked_2946.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2945, arg_2948, arg_2949) }; if linked_2940 == nil { tmp8 = ifn_2941.Invoke_O_O_O__O(arg_2942, arg_2943, arg_2944) } else { tmp8 = linked_2940.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2939, arg_2942, arg_2943, arg_2944) }; tmp1 = tmp6.Invoke_O_O__O(tmp7, tmp8) } }
//line :407:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_2960 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_2961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2960, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2962 lang.IFn




		if linked_2961 == nil { ifn_2962 = lang.IFn_Cast(root_2960) } else { ifn_2962 = nil }; var arg_2963 any; var t__7 any = t.F_p; t.F_p = nil; arg_2963 = t__7; var arg_2964 any; if linked_2961 == nil { ifn_2962.Invoke_O_O__O(arg_2963, arg_2964) } else { linked_2961.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2960, arg_2963, arg_2964) }
//line :407:1
		var tmp10 any; var root_2954 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2956 lang.IFn





		if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var tmp11 any = t.F_path; var arg_2957 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2958 any; var tmp12 any = A_arbace_go_check_A_const_111; var tmp13 any; var t__8 any = t.F_path; t.F_path = nil; tmp13 = t__8; arg_2958 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); var arg_2959 any = ex__3; if linked_2955 == nil { tmp10 = ifn_2956.Invoke_O_O_O__O(arg_2957, arg_2958, arg_2959) } else { tmp10 = linked_2955.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2954, arg_2957, arg_2958, arg_2959) }
//line :407:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) } }; return tmp1 }











func A_arbace_go_check_check_src_A_New() *A_arbace_go_check_check_src_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_src_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_go_check_check_src_A) Ctor() {}
//line :419:1
func (t *A_arbace_go_check_check_src_A) Invoke_O_O_O__O(self, s__0, src__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_279.GetRawRoot__O()); var tmp2 any; var root_3024 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, A_arbace_go_check_resolver_A_fn_class); var ifn_3026 lang.IFn; if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = s__0; var arg_3028 any = src__1; var arg_3029 any = lang.PersistentVector_EMPTY.Ref(); if linked_3025 == nil { tmp2 = ifn_3026.Invoke_O_O_O__O(arg_3027, arg_3028, arg_3029) } else { tmp2 = linked_3025.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3024, arg_3027, arg_3028, arg_3029) }; return tmp1.Invoke_O_O__O(src__1, tmp2)
}










func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :434:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var temp__1927000408__auto____2 any = A_arbace_go_check_A_const_287.Get__O(); if
											jrt.J2g_Truth(temp__1927000408__auto____2) { var f__3 any = temp__1927000408__auto____2; var G__1686000326__4_ any = corpus__0
												switch lang.Util_Hash_O__I_NoInit(G__1686000326__4_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000326__4_, Lit_93) { var tmp1 any = A_arbace_go_check_A_const_288; var tmp2 any = A_arbace_go_check_A_const_290; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_289; var tmp5 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_291, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_292)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000326__4_, Lit_97) { var tmp6 any = A_arbace_go_check_A_const_288; var tmp7 any = A_arbace_go_check_A_const_290; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_293; var tmp10 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_291, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_294)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000326__4_, Lit_54) { var tmp11 any = A_arbace_go_check_A_const_288; var tmp12 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_99), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_295)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000326__4_, Lit_100) { var tmp13 any = A_arbace_go_check_A_const_288; var tmp14 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_101), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_296)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000326__4_, Lit_102) { var tmp15 any = A_arbace_go_check_A_const_288; var tmp16 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_303)) }; default:}; var tmp17 any; var root_3031 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3031, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3033 lang.IFn







		if linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_3035 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_297, corpus__0)); if linked_3032 == nil { tmp17 = ifn_3033.Invoke_O_O__O(arg_3034, arg_3035) } else { tmp17 = linked_3032.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3031, arg_3034, arg_3035) }
//line :436:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) } else {
//line :435:1
			var G__1686000327__3_ any = corpus__0









			switch lang.Util_Hash_O__I_NoInit(G__1686000327__3_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000327__3_, Lit_93) { var tmp18 any = A_arbace_go_check_A_const_288; var tmp19 any = A_arbace_go_check_A_const_290; var tmp20 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref()))); var tmp21 any = A_arbace_go_check_A_const_289; var tmp22 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp20, tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_291, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_299)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000327__3_, Lit_97) { var tmp23 any = A_arbace_go_check_A_const_288; var tmp24 any = A_arbace_go_check_A_const_290; var tmp25 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref()))); var tmp26 any = A_arbace_go_check_A_const_293; var tmp27 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp25, tmp26, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_106), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_291, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_300)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000327__3_, Lit_54) { var tmp28 any = A_arbace_go_check_A_const_288; var tmp29 any = A_arbace_go_check_A_const_290; var tmp30 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref(); var tmp31 any = A_arbace_go_check_A_const_304; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_301)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000327__3_, Lit_100) { var tmp32 any = A_arbace_go_check_A_const_288; var tmp33 any = A_arbace_go_check_A_const_290; var tmp34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref(); var tmp35 any = A_arbace_go_check_A_const_304; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_109), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_302)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000327__3_, Lit_102) { var tmp36 any = A_arbace_go_check_A_const_288; var tmp37 any = A_arbace_go_check_A_const_290; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp36, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_305)) }; default:}; var tmp38 any; var root_3037 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3037, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3039 lang.IFn












			if linked_3038 == nil { ifn_3039 = lang.IFn_Cast(root_3037) } else { ifn_3039 = nil }; var arg_3040 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_3041 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_297, corpus__0)); if linked_3038 == nil { tmp38 = ifn_3039.Invoke_O_O__O(arg_3040, arg_3041) } else { tmp38 = linked_3038.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3037, arg_3040, arg_3041) }
//line :445:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp38))) } }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :460:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :460:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1686000330__0 any) any { var map__1686000331__2 any = p__1686000330__0; var map__1686000331__3 any; if lang.ISeq_InstanceOf(map__1686000331__2) { var tmp1 any; var root_3042 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3042, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3044 lang.IFn; if linked_3043 == nil { ifn_3044 = lang.IFn_Cast(root_3042) } else { ifn_3044 = nil }; var arg_3045 any = map__1686000331__2; if linked_3043 == nil { tmp1 = ifn_3044.Invoke_O__O(arg_3045) } else { tmp1 = linked_3043.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3042, arg_3045) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3046 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3046, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3048 lang.IFn; if linked_3047 == nil { ifn_3048 = lang.IFn_Cast(root_3046) } else { ifn_3048 = nil }; var arg_3049 any = map__1686000331__2; if linked_3047 == nil { tmp2 = ifn_3048.Invoke_O__O(arg_3049) } else { tmp2 = linked_3047.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3046, arg_3049) }; map__1686000331__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_3050 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3052 lang.IFn; if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = map__1686000331__2; if linked_3051 == nil { tmp3 = ifn_3052.Invoke_O__O(arg_3053) } else { tmp3 = linked_3051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3050, arg_3053) }; if jrt.J2g_Truth(tmp3) { var root_3054 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3056 lang.IFn; if linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any = map__1686000331__2; if linked_3055 == nil { map__1686000331__3 = ifn_3056.Invoke_O__O(arg_3057) } else { map__1686000331__3 = linked_3055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3054, arg_3057) } } else { map__1686000331__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1686000331__3 = map__1686000331__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1686000331__3, A_arbace_go_check_A_const_288); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1686000331__3, A_arbace_go_check_A_const_112); var root_3058 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, A_arbace_go_check_session_A_fn_class); var ifn_3060 lang.IFn; if
											linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any; var fnbody__3076 any = A_arbace_go_check_std_session_fn__1686000333_A_New_O_O(roots__4, config__5); var tmp4 *jrt.Class; var fncls__3075 *jrt.Class = A_arbace_go_check_std_session_fn__1686000333_A_fn_class; if fncls__3075 == nil { var fncls__3075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__3076); A_arbace_go_check_std_session_fn__1686000333_A_fn_class = fncls__3075d; tmp4 = fncls__3075d } else { tmp4 = fncls__3075 }; arg_3061 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3076, tmp4, nil); if linked_3059 == nil { return ifn_3060.Invoke_O__O(arg_3061) } else { return linked_3059.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3058, arg_3061) } }
//line :461:1
func A_arbace_go_check_std_session_fn__1686000333_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1686000333_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1686000333_A{}; t.Ctor_O_O(p0, p1); return t }
//line :461:1
func (t *A_arbace_go_check_std_session_fn__1686000333_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :461:1
func (t *A_arbace_go_check_std_session_fn__1686000333_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_3062 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3064 lang.IFn; if linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any; var fnbody__3074 any = A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A_New_O_O(path__1, t.F_config); var tmp1 *jrt.Class; var fncls__3073 *jrt.Class = A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A_fn_class; if fncls__3073 == nil { var fncls__3073d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, fnbody__3074); A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A_fn_class = fncls__3073d; tmp1 = fncls__3073d } else { tmp1 = fncls__3073 }; arg_3065 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3074, tmp1, nil); var arg_3066 any = t.F_roots; if linked_3063 == nil { return ifn_3064.Invoke_O_O__O(arg_3065, arg_3066) } else { return linked_3063.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3062, arg_3065, arg_3066) } }
//line :462:1
func A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :462:1
func (t *A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :462:1
func (t *A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A) Invoke_O_O__O(self, p1__1686000329_SHARP___1 any) any { var root_3067 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3069 lang.IFn; if linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any = p1__1686000329_SHARP___1; var arg_3071 any = t.F_path; var arg_3072 any = t.F_config; if linked_3068 == nil { return ifn_3069.Invoke_O_O_O__O(arg_3070, arg_3071, arg_3072) } else { return linked_3068.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_3067, arg_3070, arg_3071, arg_3072) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :468:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_3077 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3079 lang.IFn; if


	linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = xs__2; if linked_3078 == nil { xs__4 = ifn_3079.Invoke_O__O(arg_3080) } else { xs__4 = linked_3078.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3077, arg_3080) }; var q__5 any = /*line :468:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_3081 any = A_arbace_go_check_A_const_308.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3083 lang.IFn; if





	linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any; var iter__1927001039__auto____7 any; var fnbody__3158 any = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp1 *jrt.Class; var fncls__3157 *jrt.Class = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A_fn_class; if fncls__3157 == nil { var fncls__3157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, fnbody__3158); A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A_fn_class = fncls__3157d; tmp1 = fncls__3157d } else { tmp1 = fncls__3157 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3158, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp3 any; var root_3159 any = A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3159, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3161 lang.IFn; if linked_3160 == nil { ifn_3161 = lang.IFn_Cast(root_3159) } else { ifn_3161 = nil }; var arg_3162 any = n__0; if linked_3160 == nil { tmp3 = ifn_3161.Invoke_O__O(arg_3162) } else { tmp3 = linked_3160.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3159, arg_3162) }; arg_3084 = tmp2.Invoke_O__O(tmp3); if linked_3082 == nil { workers__7 = ifn_3083.Invoke_O__O(arg_3084) } else { workers__7 = linked_3082.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3081, arg_3084) }; var seq_1686000352__8 any; var root_3167 any = /*line :468:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3169 lang.IFn; if















	linked_3168 == nil { ifn_3169 = lang.IFn_Cast(root_3167) } else { ifn_3169 = nil }; var arg_3170 any = workers__7; if linked_3168 == nil { seq_1686000352__8 = ifn_3169.Invoke_O__O(arg_3170) } else { seq_1686000352__8 = linked_3168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3167, arg_3170) }; var chunk_1686000353__9 any; var count_1686000354__10 int64 = 0; var i_1686000355__11 int64 = 0; L1:
//line :468:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000355__11, count_1686000354__10) { var w__12 any = lang.Indexed_Cast(chunk_1686000353__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000355__11)); var root_3187 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3187, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3189 lang.IFn; if linked_3188 == nil { ifn_3189 = lang.IFn_Cast(root_3187) } else { ifn_3189 = nil }; var arg_3190 any = w__12; if linked_3188 == nil { ifn_3189.Invoke_O__O(arg_3190) } else { linked_3188.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3187, arg_3190) }; seq_1686000352__8, chunk_1686000353__9, count_1686000354__10, i_1686000355__11 = seq_1686000352__8, chunk_1686000353__9, count_1686000354__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000355__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_3171 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3171, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3173 lang.IFn; if linked_3172 == nil { ifn_3173 = lang.IFn_Cast(root_3171) } else { ifn_3173 = nil }; var arg_3174 any = seq_1686000352__8; if linked_3172 == nil { temp__1927000414__auto____12 = ifn_3173.Invoke_O__O(arg_3174) } else { temp__1927000414__auto____12 = linked_3172.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3171, arg_3174) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1686000352__13 any = temp__1927000414__auto____12; var tmp4 any; var root_3175 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3175, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3177 lang.IFn; if linked_3176 == nil { ifn_3177 = lang.IFn_Cast(root_3175) } else { ifn_3177 = nil }; var arg_3178 any = seq_1686000352__13; if linked_3176 == nil { tmp4 = ifn_3177.Invoke_O__O(arg_3178) } else { tmp4 = linked_3176.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3175, arg_3178) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_3179 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3179, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3181 lang.IFn; if linked_3180 == nil { ifn_3181 = lang.IFn_Cast(root_3179) } else { ifn_3181 = nil }; var arg_3182 any = seq_1686000352__13; if linked_3180 == nil { c__1927000678__auto____14 = ifn_3181.Invoke_O__O(arg_3182) } else { c__1927000678__auto____14 = linked_3180.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3179, arg_3182) }; var tmp5 any; var root_3191 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3193 lang.IFn; if linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any = seq_1686000352__13; if linked_3192 == nil { tmp5 = ifn_3193.Invoke_O__O(arg_3194) } else { tmp5 = linked_3192.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3191, arg_3194) }; seq_1686000352__8, chunk_1686000353__9, count_1686000354__10, i_1686000355__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_3183 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3183, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3185 lang.IFn; if linked_3184 == nil { ifn_3185 = lang.IFn_Cast(root_3183) } else { ifn_3185 = nil }; var arg_3186 any = seq_1686000352__13; if linked_3184 == nil { w__14 = ifn_3185.Invoke_O__O(arg_3186) } else { w__14 = linked_3184.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3183, arg_3186) }; var root_3195 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3195, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3197 lang.IFn; if linked_3196 == nil { ifn_3197 = lang.IFn_Cast(root_3195) } else { ifn_3197 = nil }; var arg_3198 any = w__14; if linked_3196 == nil { ifn_3197.Invoke_O__O(arg_3198) } else { linked_3196.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3195, arg_3198) }; var tmp6 any; var root_3199 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3199, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3201 lang.IFn; if linked_3200 == nil { ifn_3201 = lang.IFn_Cast(root_3199) } else { ifn_3201 = nil }; var arg_3202 any = seq_1686000352__13; if linked_3200 == nil { tmp6 = ifn_3201.Invoke_O__O(arg_3202) } else { tmp6 = linked_3200.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3199, arg_3202) }; seq_1686000352__8, chunk_1686000353__9, count_1686000354__10, i_1686000355__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :468:1
		break L1 }; var root_3163 any =
















	A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3163, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3165 lang.IFn; if linked_3164 == nil { ifn_3165 = lang.IFn_Cast(root_3163) } else { ifn_3165 = nil }; var arg_3166 any = out__6; if linked_3164 == nil { return ifn_3165.Invoke_O__O(arg_3166) } else { return linked_3164.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3163, arg_3166) } }
//line :474:1
func A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :474:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :474:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A) Invoke_O_O__O(self, s__1686000339__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3156 any = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A_New_O_O_O_O_O_O(self, t.F_f, t.F_out, t.F_q, t.F_xs, s__1686000339__1); var tmp2 *jrt.Class; var fncls__3155 *jrt.Class = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A_fn_class; if fncls__3155 == nil { var fncls__3155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, fnbody__3156); A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A_fn_class = fncls__3155d; tmp2 = fncls__3155d } else { tmp2 = fncls__3155 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3156, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :474:1
func A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :474:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A) Ctor_O_O_O_O_O_O(c__iter__1686000338, c__f, c__out, c__q, c__xs, c__s__1686000339 any) { t.F_iter__1686000338 = c__iter__1686000338; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_s__1686000339 = c__s__1686000339 }
//line :474:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A) Invoke_O__O(self any) any { { var s__1686000339__1 any; var t_ any = t.F_s__1686000339; t.F_s__1686000339 = nil; s__1686000339__1 = t_; for { var temp__1927000414__auto____2 any; var root_3085 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3085, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3087 lang.IFn; if linked_3086 == nil { ifn_3087 = lang.IFn_Cast(root_3085) } else { ifn_3087 = nil }; var arg_3088 any = s__1686000339__1; if linked_3086 == nil { temp__1927000414__auto____2 = ifn_3087.Invoke_O__O(arg_3088) } else { temp__1927000414__auto____2 = linked_3086.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3085, arg_3088) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000339__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3089 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3089, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3091 lang.IFn; if linked_3090 == nil { ifn_3091 = lang.IFn_Cast(root_3089) } else { ifn_3091 = nil }; var arg_3092 any = s__1686000339__3; if linked_3090 == nil { tmp1 = ifn_3091.Invoke_O__O(arg_3092) } else { tmp1 = linked_3090.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3089, arg_3092) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3093 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3093, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3095 lang.IFn; if linked_3094 == nil { ifn_3095 = lang.IFn_Cast(root_3093) } else { ifn_3095 = nil }; var arg_3096 any = s__1686000339__3; if linked_3094 == nil { c__1927001037__auto____4 = ifn_3095.Invoke_O__O(arg_3096) } else { c__1927001037__auto____4 = linked_3094.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3093, arg_3096) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000341__6 any; var root_3097 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3097, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3099 lang.IFn; if linked_3098 == nil { ifn_3099 = lang.IFn_Cast(root_3097) } else { ifn_3099 = nil }; var arg_3100 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3098 == nil { b__1686000341__6 = ifn_3099.Invoke_O__O(arg_3100) } else { b__1686000341__6 = linked_3098.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3097, arg_3100) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3113 any = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A_New_O_O_O_O_I_O_O(t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, c__1927001037__auto____4, b__1686000341__6); var tmp3 *jrt.Class; var fncls__3112 *jrt.Class = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A_fn_class; if fncls__3112 == nil { var fncls__3112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, fnbody__3113); A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A_fn_class = fncls__3112d; tmp3 = fncls__3112d } else { tmp3 = fncls__3112 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3113, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3114 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3116 lang.IFn; if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any; var root_3119 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any = b__1686000341__6; if linked_3120 == nil { arg_3117 = ifn_3121.Invoke_O__O(arg_3122) } else { arg_3117 = linked_3120.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3119, arg_3122) }; var arg_3118 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000338); var tmp5 any; var root_3123 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3125 lang.IFn; if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = s__1686000339__3; if linked_3124 == nil { tmp5 = ifn_3125.Invoke_O__O(arg_3126) } else { tmp5 = linked_3124.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3123, arg_3126) }; arg_3118 = tmp4.Invoke_O__O(tmp5); if linked_3115 == nil { return ifn_3116.Invoke_O_O__O(arg_3117, arg_3118) } else { return linked_3115.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3114, arg_3117, arg_3118) } } else { var root_3127 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3127, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3129 lang.IFn; if linked_3128 == nil { ifn_3129 = lang.IFn_Cast(root_3127) } else { ifn_3129 = nil }; var arg_3130 any; var root_3132 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3134 lang.IFn; if linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any = b__1686000341__6; if linked_3133 == nil { arg_3130 = ifn_3134.Invoke_O__O(arg_3135) } else { arg_3130 = linked_3133.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3132, arg_3135) }; var arg_3131 any; if linked_3128 == nil { return ifn_3129.Invoke_O_O__O(arg_3130, arg_3131) } else { return linked_3128.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3127, arg_3130, arg_3131) } } } else { var ___4 any; var root_3136 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3138 lang.IFn; _ = ___4; if linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = s__1686000339__3; if linked_3137 == nil { ___4 = ifn_3138.Invoke_O__O(arg_3139) } else { ___4 = linked_3137.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3136, arg_3139) }; var root_3140 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3140, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3142 lang.IFn; if linked_3141 == nil { ifn_3142 = lang.IFn_Cast(root_3140) } else { ifn_3142 = nil }; var arg_3143 any; var root_3145 any = A_arbace_go_check_A_const_309.GetRawRoot__O(); var linked_3146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3145, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3147 lang.IFn
															if linked_3146 == nil { ifn_3147 = lang.IFn_Cast(root_3145) } else { ifn_3147 = nil }; var arg_3148 any; var fnbody__3150 any = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp6 *jrt.Class; var fncls__3149 *jrt.Class = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A_fn_class; if fncls__3149 == nil { var fncls__3149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__3150); A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A_fn_class = fncls__3149d; tmp6 = fncls__3149d } else { tmp6 = fncls__3149 }; arg_3148 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3150, tmp6, nil); if linked_3146 == nil { arg_3143 = ifn_3147.Invoke_O__O(arg_3148) } else { arg_3143 = linked_3146.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3145, arg_3148) }
//line :474:1
	var arg_3144 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1686000338); var tmp8 any; var root_3151 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3153 lang.IFn; if linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any = s__1686000339__3; if linked_3152 == nil { tmp8 = ifn_3153.Invoke_O__O(arg_3154) } else { tmp8 = linked_3152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3151, arg_3154) }; arg_3144 = tmp7.Invoke_O__O(tmp8); if linked_3141 == nil { return ifn_3142.Invoke_O_O__O(arg_3143, arg_3144) } else { return linked_3141.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3140, arg_3143, arg_3144) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :474:1
func A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :474:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A) Ctor_O_O_O_O_I_O_O(c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1686000341 any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1686000341 = c__b__1686000341 }
//line :474:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A) Invoke_O__O(self any) any { { var i__1686000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000340__1)); var root_3101 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3101, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3103 lang.IFn; _ = ___2; if linked_3102 == nil { ifn_3103 = lang.IFn_Cast(root_3101) } else { ifn_3103 = nil }; var arg_3104 any = t.F_b__1686000341; var arg_3105 any; var root_3106 any = A_arbace_go_check_A_const_309.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3108 lang.IFn
																if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any; var fnbody__3111 any = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp2 *jrt.Class; var fncls__3110 *jrt.Class = A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A_fn_class; if fncls__3110 == nil { var fncls__3110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, fnbody__3111); A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A_fn_class = fncls__3110d; tmp2 = fncls__3110d } else { tmp2 = fncls__3110 }; arg_3109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3111, tmp2, nil); if linked_3107 == nil { arg_3105 = ifn_3108.Invoke_O__O(arg_3109) } else { arg_3105 = linked_3107.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3106, arg_3109) }
//line :474:1
	if linked_3102 == nil { ifn_3103.Invoke_O_O__O(arg_3104, arg_3105) } else { linked_3102.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3101, arg_3104, arg_3105) }; i__1686000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :475:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :475:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_310.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_310.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_311) }
		var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_out); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_310.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_310.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :478:1
			return nil } } }; /*line :475:1*/panic("j2g: unreachable") }
//line :475:1
func A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :475:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :475:1
func (t *A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_310.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_310.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_311) }
		var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_out); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_310.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_310.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :478:1
			return nil } } }; /*line :475:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :487:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_3203 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_3204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3203, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3205 lang.IFn; if linked_3204 == nil { ifn_3205 = lang.IFn_Cast(root_3203) } else { ifn_3205 = nil }; var arg_3206 any = pkg__0; var arg_3207 any = A_arbace_go_check_A_const_239; if linked_3204 == nil { return ifn_3205.Invoke_O_O__O(arg_3206, arg_3207) } else { return linked_3204.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3203, arg_3206, arg_3207) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :489:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_111; var tmp2 any = A_arbace_go_check_A_const_240; var tmp3 any = A_arbace_go_check_A_const_74; var tmp4 any = A_arbace_go_check_A_const_79; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_314; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_115, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :489:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_315, A_arbace_go_check_A_const_316))), A_arbace_go_check_A_const_166, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_83, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_155, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_157, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_167, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_143, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_168, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_159, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_147, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_313, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :496:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_3208 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3208, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3210 lang.IFn; if


	linked_3209 == nil { ifn_3210 = lang.IFn_Cast(root_3208) } else { ifn_3210 = nil }; var arg_3211 any = corpus__0; if linked_3209 == nil { cc__3 = ifn_3210.Invoke_O__O(arg_3211) } else { cc__3 = linked_3209.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3208, arg_3211) }; var s__4 any; var root_3212 any = /*line :496:1*/A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3212, A_arbace_go_check_std_session_A_fn_class); var ifn_3214 lang.IFn; if



	linked_3213 == nil { ifn_3214 = lang.IFn_Cast(root_3212) } else { ifn_3214 = nil }; var arg_3215 any = cc__3; if linked_3213 == nil { s__4 = ifn_3214.Invoke_O__O(arg_3215) } else { s__4 = linked_3213.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3212, arg_3215) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :496:1*/A_arbace_go_check_A_const_293.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_289.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_3216 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3216, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3218 lang.IFn
		if linked_3217 == nil { ifn_3218 = lang.IFn_Cast(root_3216) } else { ifn_3218 = nil }; var arg_3219 any = A_arbace_go_check_A_const_288.Invoke_O__O(cc__3); if linked_3217 == nil { root__5 = ifn_3218.Invoke_O__O(arg_3219) } else { root__5 = linked_3217.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3216, arg_3219) }
		var root_3220 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3220, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3222 lang.IFn; if linked_3221 == nil { ifn_3222 = lang.IFn_Cast(root_3220) } else { ifn_3222 = nil }; var arg_3223 any; var iter__1927001039__auto____6 any; var fnbody__3293 any = A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A_New(); var tmp2 *jrt.Class; var fncls__3292 *jrt.Class = A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A_fn_class; if fncls__3292 == nil { var fncls__3292d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A_fn_class = fncls__3292d; tmp2 = fncls__3292d } else { tmp2 = fncls__3292 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3293, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp4 any; var root_3294 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3294, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3296 lang.IFn; if linked_3295 == nil { ifn_3296 = lang.IFn_Cast(root_3294) } else { ifn_3296 = nil }; var arg_3297 any = root__5; var arg_3298 any = Lit_36; if linked_3295 == nil { tmp4 = ifn_3296.Invoke_O_O__O(arg_3297, arg_3298) } else { tmp4 = linked_3295.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3294, arg_3297, arg_3298) }; arg_3223 = tmp3.Invoke_O__O(tmp4); if linked_3221 == nil { std_pkgs__5 = ifn_3222.Invoke_O__O(arg_3223) } else { std_pkgs__5 = linked_3221.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3220, arg_3223) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_3299 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3299, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3301 lang.IFn; if linked_3300 == nil { ifn_3301 = lang.IFn_Cast(root_3299) } else { ifn_3301 = nil }; var arg_3302 any = jobs__1; var arg_3303 any; var fnbody__3322 any = A_arbace_go_check_check_corpus_fn__1686000370_A_New_O(s__4); var tmp5 *jrt.Class; var fncls__3321 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000370_A_fn_class
		if fncls__3321 == nil { var fncls__3321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__3322); A_arbace_go_check_check_corpus_fn__1686000370_A_fn_class = fncls__3321d; tmp5 = fncls__3321d } else { tmp5 = fncls__3321 }; arg_3303 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3322, tmp5, nil)
//line :508:1
		var arg_3304 any = std_pkgs__5; if linked_3300 == nil { return ifn_3301.Invoke_O_O_O__O(arg_3302, arg_3303, arg_3304) } else { return linked_3300.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3299, arg_3302, arg_3303, arg_3304) } } else {
//line :506:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_293.Invoke_O__O(cc__3)) { var map__1686000372__6 any = A_arbace_go_check_A_const_293.Invoke_O__O(cc__3); var map__1686000372__7 any








				if lang.ISeq_InstanceOf(map__1686000372__6) { var tmp6 any; var root_3323 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3323, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3325 lang.IFn; if linked_3324 == nil { ifn_3325 = lang.IFn_Cast(root_3323) } else { ifn_3325 = nil }; var arg_3326 any = map__1686000372__6; if linked_3324 == nil { tmp6 = ifn_3325.Invoke_O__O(arg_3326) } else { tmp6 = linked_3324.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3323, arg_3326) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_3327 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3327, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3329 lang.IFn; if linked_3328 == nil { ifn_3329 = lang.IFn_Cast(root_3327) } else { ifn_3329 = nil }; var arg_3330 any = map__1686000372__6; if linked_3328 == nil { tmp7 = ifn_3329.Invoke_O__O(arg_3330) } else { tmp7 = linked_3328.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3327, arg_3330) }; map__1686000372__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_3331 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3331, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3333 lang.IFn; if linked_3332 == nil { ifn_3333 = lang.IFn_Cast(root_3331) } else { ifn_3333 = nil }; var arg_3334 any = map__1686000372__6; if linked_3332 == nil { tmp8 = ifn_3333.Invoke_O__O(arg_3334) } else { tmp8 = linked_3332.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3331, arg_3334) }; if jrt.J2g_Truth(tmp8) { var root_3335 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3335, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3337 lang.IFn; if linked_3336 == nil { ifn_3337 = lang.IFn_Cast(root_3335) } else { ifn_3337 = nil }; var arg_3338 any = map__1686000372__6; if linked_3336 == nil { map__1686000372__7 = ifn_3337.Invoke_O__O(arg_3338) } else { map__1686000372__7 = linked_3336.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3335, arg_3338) } } else { map__1686000372__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1686000372__7 = map__1686000372__6 }
//line :506:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1686000372__7, A_arbace_go_check_A_const_290); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1686000372__7, A_arbace_go_check_A_const_291); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_290, dir__8)); var root_3339 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3339, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3341 lang.IFn










				if linked_3340 == nil { ifn_3341 = lang.IFn_Cast(root_3339) } else { ifn_3341 = nil }; var arg_3342 any = jobs__1; var arg_3343 any; var fnbody__3388 any = A_arbace_go_check_check_corpus_fn__1686000374_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp9 *jrt.Class; var fncls__3387 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000374_A_fn_class
				if fncls__3387 == nil { var fncls__3387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__3388); A_arbace_go_check_check_corpus_fn__1686000374_A_fn_class = fncls__3387d; tmp9 = fncls__3387d } else { tmp9 = fncls__3387 }; arg_3343 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3388, tmp9, nil)
//line :517:1
				var arg_3344 any; var root_3389 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3389, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3391 lang.IFn








				if linked_3390 == nil { ifn_3391 = lang.IFn_Cast(root_3389) } else { ifn_3391 = nil }; var arg_3392 any = root__10; var arg_3393 any = sub__9; if linked_3390 == nil { arg_3344 = ifn_3391.Invoke_O_O__O(arg_3392, arg_3393) } else { arg_3344 = linked_3390.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3389, arg_3392, arg_3393) }
//line :517:1
				if linked_3340 == nil { return ifn_3341.Invoke_O_O_O__O(arg_3342, arg_3343, arg_3344) } else { return linked_3340.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3339, arg_3342, arg_3343, arg_3344) } } else {
//line :506:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_289.Invoke_O__O(cc__3)) { var map__1686000376__6 any = A_arbace_go_check_A_const_289.Invoke_O__O(cc__3); var map__1686000376__7 any





















						if lang.ISeq_InstanceOf(map__1686000376__6) { var tmp10 any; var root_3394 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3394, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3396 lang.IFn; if linked_3395 == nil { ifn_3396 = lang.IFn_Cast(root_3394) } else { ifn_3396 = nil }; var arg_3397 any = map__1686000376__6; if linked_3395 == nil { tmp10 = ifn_3396.Invoke_O__O(arg_3397) } else { tmp10 = linked_3395.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3394, arg_3397) }; if jrt.J2g_Truth(tmp10) { var tmp11 any; var root_3398 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3398, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3400 lang.IFn; if linked_3399 == nil { ifn_3400 = lang.IFn_Cast(root_3398) } else { ifn_3400 = nil }; var arg_3401 any = map__1686000376__6; if linked_3399 == nil { tmp11 = ifn_3400.Invoke_O__O(arg_3401) } else { tmp11 = linked_3399.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3398, arg_3401) }; map__1686000376__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp11)).Ref() } else { var tmp12 any; var root_3402 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3404 lang.IFn; if linked_3403 == nil { ifn_3404 = lang.IFn_Cast(root_3402) } else { ifn_3404 = nil }; var arg_3405 any = map__1686000376__6; if linked_3403 == nil { tmp12 = ifn_3404.Invoke_O__O(arg_3405) } else { tmp12 = linked_3403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3402, arg_3405) }; if jrt.J2g_Truth(tmp12) { var root_3406 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3406, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3408 lang.IFn; if linked_3407 == nil { ifn_3408 = lang.IFn_Cast(root_3406) } else { ifn_3408 = nil }; var arg_3409 any = map__1686000376__6; if linked_3407 == nil { map__1686000376__7 = ifn_3408.Invoke_O__O(arg_3409) } else { map__1686000376__7 = linked_3407.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3406, arg_3409) } } else { map__1686000376__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1686000376__7 = map__1686000376__6 }
//line :506:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1686000376__7, A_arbace_go_check_A_const_290); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1686000376__7, A_arbace_go_check_A_const_291); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_290, dir__8_2)); var pfs__11 any; var root_3410 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3410, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3412 lang.IFn























						if linked_3411 == nil { ifn_3412 = lang.IFn_Cast(root_3410) } else { ifn_3412 = nil }; var arg_3413 any = root__10_2; var arg_3414 any = sub__9_2; if linked_3411 == nil { pfs__11 = ifn_3412.Invoke_O_O__O(arg_3413, arg_3414) } else { pfs__11 = linked_3411.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3410, arg_3413, arg_3414) }
//line :506:1
						var tests__12 any; var root_3415 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var linked_3416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3415, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3417 lang.IFn

























						if linked_3416 == nil { ifn_3417 = lang.IFn_Cast(root_3415) } else { ifn_3417 = nil }; var arg_3418 any; var fnbody__3426 any = A_arbace_go_check_check_corpus_fn__1686000378_A_New(); var tmp13 *jrt.Class; var fncls__3425 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000378_A_fn_class; if fncls__3425 == nil { var fncls__3425d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_go_check_check_corpus_fn__1686000378_A_fn_class = fncls__3425d; tmp13 = fncls__3425d } else { tmp13 = fncls__3425 }; arg_3418 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3426, tmp13, nil); var arg_3419 any = pfs__11; if linked_3416 == nil { tests__12 = ifn_3417.Invoke_O_O__O(arg_3418, arg_3419) } else { tests__12 = linked_3416.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3415, arg_3418, arg_3419)
						}


						var root_3427 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3427, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3429 lang.IFn; if linked_3428 == nil { ifn_3429 = lang.IFn_Cast(root_3427) } else { ifn_3429 = nil }; var arg_3430 any; var root_3431 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3433 lang.IFn; if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var arg_3435 any; var root_3436 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3438 lang.IFn
						if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = jobs__1; var arg_3440 any; var fnbody__3680 any = A_arbace_go_check_check_corpus_fn__1686000384_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp14 *jrt.Class; var fncls__3679 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_A_fn_class
						if fncls__3679 == nil { var fncls__3679d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__3680); A_arbace_go_check_check_corpus_fn__1686000384_A_fn_class = fncls__3679d; tmp14 = fncls__3679d } else { tmp14 = fncls__3679 }; arg_3440 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3680, tmp14, nil)
//line :537:1
						var arg_3441 any; var root_3681 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3683 lang.IFn














						if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; var arg_3684 any = A_arbace_go_check_A_const_332.GetRawRoot__O(); var arg_3685 any = tests__12; if linked_3682 == nil { arg_3441 = ifn_3683.Invoke_O_O__O(arg_3684, arg_3685) } else { arg_3441 = linked_3682.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3681, arg_3684, arg_3685) }
//line :537:1
						if linked_3437 == nil { arg_3435 = ifn_3438.Invoke_O_O_O__O(arg_3439, arg_3440, arg_3441) } else { arg_3435 = linked_3437.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3436, arg_3439, arg_3440, arg_3441) }
//line :536:1
						if linked_3432 == nil { arg_3430 = ifn_3433.Invoke_O_O__O(arg_3434, arg_3435) } else { arg_3430 = linked_3432.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3431, arg_3434, arg_3435) }; if linked_3428 == nil { return ifn_3429.Invoke_O__O(arg_3430) } else { return linked_3428.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3427, arg_3430) } } else {
//line :506:1
							return nil } } } }
//line :504:1
func A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A_New() *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A{}; t.Ctor(); return t }
//line :504:1
func (t *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A) Ctor() {}
//line :504:1
func (t *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A) Invoke_O_O__O(self, s__1686000361__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3291 any = A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A_New_O_O(s__1686000361__1, self); var tmp2 *jrt.Class; var fncls__3290 *jrt.Class = A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A_fn_class; if fncls__3290 == nil { var fncls__3290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__3291); A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A_fn_class = fncls__3290d; tmp2 = fncls__3290d } else { tmp2 = fncls__3290 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3291, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :504:1
func A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A{}; t.Ctor_O_O(p0, p1); return t }
//line :504:1
func (t *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A) Ctor_O_O(c__s__1686000361, c__iter__1686000360 any) { t.F_s__1686000361 = c__s__1686000361; t.F_iter__1686000360 = c__iter__1686000360 }
//line :504:1
func (t *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A) Invoke_O__O(self any) any { { var s__1686000361__1 any; var t_ any = t.F_s__1686000361; t.F_s__1686000361 = nil; s__1686000361__1 = t_; for { var temp__1927000414__auto____2 any; var root_3224 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3224, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3226 lang.IFn; if linked_3225 == nil { ifn_3226 = lang.IFn_Cast(root_3224) } else { ifn_3226 = nil }; var arg_3227 any = s__1686000361__1; if linked_3225 == nil { temp__1927000414__auto____2 = ifn_3226.Invoke_O__O(arg_3227) } else { temp__1927000414__auto____2 = linked_3225.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3224, arg_3227) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000361__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3228 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3228, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3230 lang.IFn; if linked_3229 == nil { ifn_3230 = lang.IFn_Cast(root_3228) } else { ifn_3230 = nil }; var arg_3231 any = s__1686000361__3; if linked_3229 == nil { tmp1 = ifn_3230.Invoke_O__O(arg_3231) } else { tmp1 = linked_3229.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3228, arg_3231) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3232 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3232, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3234 lang.IFn; if linked_3233 == nil { ifn_3234 = lang.IFn_Cast(root_3232) } else { ifn_3234 = nil }; var arg_3235 any = s__1686000361__3; if linked_3233 == nil { c__1927001037__auto____4 = ifn_3234.Invoke_O__O(arg_3235) } else { c__1927001037__auto____4 = linked_3233.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3232, arg_3235) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000363__6 any; var root_3236 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3236, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3238 lang.IFn; if linked_3237 == nil { ifn_3238 = lang.IFn_Cast(root_3236) } else { ifn_3238 = nil }; var arg_3239 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3237 == nil { b__1686000363__6 = ifn_3238.Invoke_O__O(arg_3239) } else { b__1686000363__6 = linked_3237.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3236, arg_3239) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3250 any = A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1686000363__6); var tmp3 *jrt.Class; var fncls__3249 *jrt.Class = A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A_fn_class; if fncls__3249 == nil { var fncls__3249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__3250); A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A_fn_class = fncls__3249d; tmp3 = fncls__3249d } else { tmp3 = fncls__3249 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3250, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3251 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3253 lang.IFn; if linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any; var root_3256 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3256, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3258 lang.IFn; if linked_3257 == nil { ifn_3258 = lang.IFn_Cast(root_3256) } else { ifn_3258 = nil }; var arg_3259 any = b__1686000363__6; if linked_3257 == nil { arg_3254 = ifn_3258.Invoke_O__O(arg_3259) } else { arg_3254 = linked_3257.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3256, arg_3259) }; var arg_3255 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000360); var tmp5 any; var root_3260 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3260, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3262 lang.IFn; if linked_3261 == nil { ifn_3262 = lang.IFn_Cast(root_3260) } else { ifn_3262 = nil }; var arg_3263 any = s__1686000361__3; if linked_3261 == nil { tmp5 = ifn_3262.Invoke_O__O(arg_3263) } else { tmp5 = linked_3261.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3260, arg_3263) }; arg_3255 = tmp4.Invoke_O__O(tmp5); if linked_3252 == nil { return ifn_3253.Invoke_O_O__O(arg_3254, arg_3255) } else { return linked_3252.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3251, arg_3254, arg_3255) } } else { var root_3264 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3264, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3266 lang.IFn; if linked_3265 == nil { ifn_3266 = lang.IFn_Cast(root_3264) } else { ifn_3266 = nil }; var arg_3267 any; var root_3269 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3269, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3271 lang.IFn; if linked_3270 == nil { ifn_3271 = lang.IFn_Cast(root_3269) } else { ifn_3271 = nil }; var arg_3272 any = b__1686000363__6; if linked_3270 == nil { arg_3267 = ifn_3271.Invoke_O__O(arg_3272) } else { arg_3267 = linked_3270.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3269, arg_3272) }; var arg_3268 any; if linked_3265 == nil { return ifn_3266.Invoke_O_O__O(arg_3267, arg_3268) } else { return linked_3265.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3264, arg_3267, arg_3268) } } } else { var pf__4 any; var root_3273 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3275 lang.IFn; if linked_3274 == nil { ifn_3275 = lang.IFn_Cast(root_3273) } else { ifn_3275 = nil }; var arg_3276 any = s__1686000361__3; if linked_3274 == nil { pf__4 = ifn_3275.Invoke_O__O(arg_3276) } else { pf__4 = linked_3274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3273, arg_3276) }; var root_3277 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3277, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3279 lang.IFn; if linked_3278 == nil { ifn_3279 = lang.IFn_Cast(root_3277) } else { ifn_3279 = nil }; var arg_3280 any; var root_3282 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3282, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3284 lang.IFn
															if linked_3283 == nil { ifn_3284 = lang.IFn_Cast(root_3282) } else { ifn_3284 = nil }; var arg_3285 any = pf__4; if linked_3283 == nil { arg_3280 = ifn_3284.Invoke_O__O(arg_3285) } else { arg_3280 = linked_3283.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3282, arg_3285) }
//line :504:1
	var arg_3281 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1686000360); var tmp7 any; var root_3286 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3286, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3288 lang.IFn; if linked_3287 == nil { ifn_3288 = lang.IFn_Cast(root_3286) } else { ifn_3288 = nil }; var arg_3289 any = s__1686000361__3; if linked_3287 == nil { tmp7 = ifn_3288.Invoke_O__O(arg_3289) } else { tmp7 = linked_3287.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3286, arg_3289) }; arg_3281 = tmp6.Invoke_O__O(tmp7); if linked_3278 == nil { return ifn_3279.Invoke_O_O__O(arg_3280, arg_3281) } else { return linked_3278.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3277, arg_3280, arg_3281) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :504:1
func A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :504:1
func (t *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1686000363 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1686000363 = c__b__1686000363 }
//line :504:1
func (t *A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A) Invoke_O__O(self any) any { { var i__1686000362__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000362__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000362__1)); var root_3240 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3240, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3242 lang.IFn; if linked_3241 == nil { ifn_3242 = lang.IFn_Cast(root_3240) } else { ifn_3242 = nil }; var arg_3243 any = t.F_b__1686000363; var arg_3244 any; var root_3245 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3245, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3247 lang.IFn
																if linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any = pf__2; if linked_3246 == nil { arg_3244 = ifn_3247.Invoke_O__O(arg_3248) } else { arg_3244 = linked_3246.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3245, arg_3248) }
//line :504:1
	if linked_3241 == nil { ifn_3242.Invoke_O_O__O(arg_3243, arg_3244) } else { linked_3241.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3240, arg_3243, arg_3244) }; i__1686000362__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000362__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1686000370_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1686000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000370_A{}; t.Ctor_O(p0); return t }
//line :509:1
func (t *A_arbace_go_check_check_corpus_fn__1686000370_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :509:1
func (t *A_arbace_go_check_check_corpus_fn__1686000370_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_3305 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, A_arbace_go_check_result_of_A_fn_class); var ifn_3307 lang.IFn
												if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any; var root_3309 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3309, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3311 lang.IFn; if linked_3310 == nil { ifn_3311 = lang.IFn_Cast(root_3309) } else { ifn_3311 = nil }; var arg_3312 any = t.F_s; var arg_3313 any = path__1; var arg_3314 any; var arg_3315 any = lang.PersistentVector_EMPTY.Ref(); if linked_3310 == nil { arg_3308 = ifn_3311.Invoke_O_O_O_O__O(arg_3312, arg_3313, arg_3314, arg_3315) } else { arg_3308 = linked_3310.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3309, arg_3312, arg_3313, arg_3314, arg_3315) }; if linked_3306 == nil { or__1927000174__auto____4 = ifn_3307.Invoke_O__O(arg_3308) } else { or__1927000174__auto____4 = linked_3306.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3305, arg_3308) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111, path__1, A_arbace_go_check_A_const_323, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :509:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_3316 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, A_arbace_go_check_error_result_A_fn_class); var ifn_3318 lang.IFn


		if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any = path__1; var arg_3320 any = ex__4; if linked_3317 == nil { tmp1 = ifn_3318.Invoke_O_O__O(arg_3319, arg_3320) } else { tmp1 = linked_3317.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3316, arg_3319, arg_3320) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1686000374_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1686000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000374_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :518:1
func (t *A_arbace_go_check_check_corpus_fn__1686000374_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :518:1
func (t *A_arbace_go_check_check_corpus_fn__1686000374_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_3345 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3345, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3347 lang.IFn

	if linked_3346 == nil { ifn_3347 = lang.IFn_Cast(root_3345) } else { ifn_3347 = nil }; var arg_3348 any = t.F_root; var arg_3349 any; var arg_3350 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_cc); var arg_3351 any = pf__1; if linked_3346 == nil { src__4 = ifn_3347.Invoke_O_O_O_O__O(arg_3348, arg_3349, arg_3350, arg_3351) } else { src__4 = linked_3346.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3345, arg_3348, arg_3349, arg_3350, arg_3351) }
	var tmp2 any; var root_3352 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3352, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3354 lang.IFn; if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__4); if linked_3353 == nil { tmp2 = ifn_3354.Invoke_O__O(arg_3355) } else { tmp2 = linked_3353.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3352, arg_3355) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_111; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.File_Cast(pf__1).GetPath__String().Ref(), A_arbace_go_check_A_const_323, jrt.Boolean_TRUE.Ref())) } else {

		var root_3356 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3357 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3356, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3358 lang.IFn; if linked_3357 == nil { ifn_3358 = lang.IFn_Cast(root_3356) } else { ifn_3358 = nil }; var arg_3359 any; var root_3362 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3362, A_arbace_go_check_result_of_A_fn_class); var ifn_3364 lang.IFn; if linked_3363 == nil { ifn_3364 = lang.IFn_Cast(root_3362) } else { ifn_3364 = nil }; var arg_3365 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_279.GetRawRoot__O()); var tmp5 any; var root_3371 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, A_arbace_go_check_resolver_A_fn_class); var ifn_3373 lang.IFn; if linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = t.F_s; var arg_3375 any = src__4; var arg_3376 any = lang.PersistentVector_EMPTY.Ref(); if linked_3372 == nil { tmp5 = ifn_3373.Invoke_O_O_O__O(arg_3374, arg_3375, arg_3376) } else { tmp5 = linked_3372.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3371, arg_3374, arg_3375, arg_3376) }; arg_3365 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_3363 == nil { arg_3359 = ifn_3364.Invoke_O__O(arg_3365) } else { arg_3359 = linked_3363.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3362, arg_3365) }; var arg_3360 any = A_arbace_go_check_A_const_111; var arg_3361 any; var root_3377 any = A_arbace_go_check_A_const_325.GetRawRoot__O(); var linked_3378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3377, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3379 lang.IFn
		if linked_3378 == nil { ifn_3379 = lang.IFn_Cast(root_3377) } else { ifn_3379 = nil }; var arg_3380 any = jrt.File_Cast(pf__1).GetPath__String().Ref(); var arg_3381 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_3378 == nil { arg_3361 = ifn_3379.Invoke_O_O__O(arg_3380, arg_3381) } else { arg_3361 = linked_3378.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3377, arg_3380, arg_3381) }
//line :523:1
		if linked_3357 == nil { tmp1 = ifn_3358.Invoke_O_O_O__O(arg_3359, arg_3360, arg_3361) } else { tmp1 = linked_3357.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3356, arg_3359, arg_3360, arg_3361) } } }; return nil }(); if /*line :518:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_3382 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3382, A_arbace_go_check_error_result_A_fn_class); var ifn_3384 lang.IFn






			if linked_3383 == nil { ifn_3384 = lang.IFn_Cast(root_3382) } else { ifn_3384 = nil }; var arg_3385 any = jrt.File_Cast(pf__1).GetPath__String().Ref(); var arg_3386 any = ex__4; if linked_3383 == nil { tmp1 = ifn_3384.Invoke_O_O__O(arg_3385, arg_3386) } else { tmp1 = linked_3383.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3382, arg_3385, arg_3386) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1686000378_A_New() *A_arbace_go_check_check_corpus_fn__1686000378_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000378_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1686000378_A) Ctor() {}
//line :532:1
func (t *A_arbace_go_check_check_corpus_fn__1686000378_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.File_Cast(pf__1).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_3420 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var linked_3421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3420, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3422 lang.IFn; if

	linked_3421 == nil { ifn_3422 = lang.IFn_Cast(root_3420) } else { ifn_3422 = nil }; var arg_3423 any = A_arbace_go_check_A_const_328; var arg_3424 any = p__2; if linked_3421 == nil { temp__1927000408__auto____3 = ifn_3422.Invoke_O_O__O(arg_3423, arg_3424) } else { temp__1927000408__auto____3 = linked_3421.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3420, arg_3423, arg_3424) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1686000379__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000379__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000379__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1686000384_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1686000384_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_A) Invoke_O_O__O(self, p__1686000383__1 any) any { var vec__1686000385__2 any = p__1686000383__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000385__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000385__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_3442 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3442, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3444 lang.IFn

	if linked_3443 == nil { ifn_3444 = lang.IFn_Cast(root_3442) } else { ifn_3444 = nil }; var arg_3445 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3446 any; var iter__1927001039__auto____7 any; var fnbody__3516 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A_New(); var tmp2 *jrt.Class; var fncls__3515 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A_fn_class; if fncls__3515 == nil { var fncls__3515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A_fn_class = fncls__3515d; tmp2 = fncls__3515d } else { tmp2 = fncls__3515 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3516, tmp2, nil); arg_3446 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_3443 == nil { by_path__7 = ifn_3444.Invoke_O_O__O(arg_3445, arg_3446) } else { by_path__7 = linked_3443.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3442, arg_3445, arg_3446) }
//line :538:1
	var ts__8 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_106.GetRawRoot__O()); var tmp4 any; var root_3525 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, A_arbace_go_check_session_A_fn_class); var ifn_3527 lang.IFn



	if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any; var fnbody__3537 any = A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp5 *jrt.Class; var fncls__3536 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A_fn_class; if fncls__3536 == nil { var fncls__3536d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__3537); A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A_fn_class = fncls__3536d; tmp5 = fncls__3536d } else { tmp5 = fncls__3536 }; arg_3528 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3537, tmp5, nil); if linked_3526 == nil { tmp4 = ifn_3527.Invoke_O__O(arg_3528) } else { tmp4 = linked_3526.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3525, arg_3528) }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_A_const_268; var tmp8 any = t.F_s; var tmp9 any = A_arbace_go_check_A_const_277; var tmp10 *lang.Compiler_AOTFn; var fnbody__3544 any = A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A_New_O(by_path__7); var tmp11 *jrt.Class; var fncls__3543 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A_fn_class; if fncls__3543 == nil { var fncls__3543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__3544); A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A_fn_class = fncls__3543d; tmp11 = fncls__3543d } else { tmp11 = fncls__3543 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3544, tmp11, nil); ts__8 = tmp3.Invoke_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9, tmp10.Ref())



	var root_3545 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3545, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3547 lang.IFn; if linked_3546 == nil { ifn_3547 = lang.IFn_Cast(root_3545) } else { ifn_3547 = nil }; var arg_3548 any; var iter__1927001039__auto____9 any; var fnbody__3668 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp12 *jrt.Class; var fncls__3667 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A_fn_class; if fncls__3667 == nil { var fncls__3667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__3668); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A_fn_class = fncls__3667d; tmp12 = fncls__3667d } else { tmp12 = fncls__3667 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3668, tmp12, nil); var tmp13 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp14 any; var root_3669 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_3670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3669, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3671 lang.IFn; if linked_3670 == nil { ifn_3671 = lang.IFn_Cast(root_3669) } else { ifn_3671 = nil }; var arg_3672 any = A_arbace_go_check_A_const_332.GetRawRoot__O(); var arg_3673 any = by_path__7; if linked_3670 == nil { tmp14 = ifn_3671.Invoke_O_O__O(arg_3672, arg_3673) } else { tmp14 = linked_3670.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3669, arg_3672, arg_3673) }; arg_3548 = tmp13.Invoke_O__O(tmp14); if linked_3546 == nil { tmp1 = ifn_3547.Invoke_O__O(arg_3548) } else { tmp1 = linked_3546.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3545, arg_3548) } }; return nil }(); if /*line :538:1*/ tmp15 != nil { if true { var ex__7 jrt.Throwable_I = tmp15; var tmp16 any; var root_3674 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3674, A_arbace_go_check_error_result_A_fn_class); var ifn_3676 lang.IFn












		if linked_3675 == nil { ifn_3676 = lang.IFn_Cast(root_3674) } else { ifn_3676 = nil }; var arg_3677 any = tdir__3; var arg_3678 any = ex__7; if linked_3675 == nil { tmp16 = ifn_3676.Invoke_O_O__O(arg_3677, arg_3678) } else { tmp16 = linked_3675.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3674, arg_3677, arg_3678) }
//line :538:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp16) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A_New() *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A{}; t.Ctor(); return t }
//line :540:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A) Ctor() {}
//line :540:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A) Invoke_O_O__O(self, s__1686000389__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3514 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A_New_O_O(s__1686000389__1, self); var tmp2 *jrt.Class; var fncls__3513 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A_fn_class; if fncls__3513 == nil { var fncls__3513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__3514); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A_fn_class = fncls__3513d; tmp2 = fncls__3513d } else { tmp2 = fncls__3513 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3514, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :540:1
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :540:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A) Ctor_O_O(c__s__1686000389, c__iter__1686000388 any) { t.F_s__1686000389 = c__s__1686000389; t.F_iter__1686000388 = c__iter__1686000388 }
//line :540:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A) Invoke_O__O(self any) any { { var s__1686000389__1 any; var t_ any = t.F_s__1686000389; t.F_s__1686000389 = nil; s__1686000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_3447 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3449 lang.IFn; if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any = s__1686000389__1; if linked_3448 == nil { temp__1927000414__auto____2 = ifn_3449.Invoke_O__O(arg_3450) } else { temp__1927000414__auto____2 = linked_3448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3447, arg_3450) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3451 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3453 lang.IFn; if linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any = s__1686000389__3; if linked_3452 == nil { tmp1 = ifn_3453.Invoke_O__O(arg_3454) } else { tmp1 = linked_3452.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3451, arg_3454) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3455 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any = s__1686000389__3; if linked_3456 == nil { c__1927001037__auto____4 = ifn_3457.Invoke_O__O(arg_3458) } else { c__1927001037__auto____4 = linked_3456.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3455, arg_3458) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000391__6 any; var root_3459 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3459, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3461 lang.IFn; if linked_3460 == nil { ifn_3461 = lang.IFn_Cast(root_3459) } else { ifn_3461 = nil }; var arg_3462 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3460 == nil { b__1686000391__6 = ifn_3461.Invoke_O__O(arg_3462) } else { b__1686000391__6 = linked_3460.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3459, arg_3462) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3473 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A_New_O_I_O(b__1686000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3472 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A_fn_class; if fncls__3472 == nil { var fncls__3472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__3473); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A_fn_class = fncls__3472d; tmp3 = fncls__3472d } else { tmp3 = fncls__3472 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3473, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3474 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any; var root_3479 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3479, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3481 lang.IFn; if linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any = b__1686000391__6; if linked_3480 == nil { arg_3477 = ifn_3481.Invoke_O__O(arg_3482) } else { arg_3477 = linked_3480.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3479, arg_3482) }; var arg_3478 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000388); var tmp5 any; var root_3483 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3483, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3485 lang.IFn; if linked_3484 == nil { ifn_3485 = lang.IFn_Cast(root_3483) } else { ifn_3485 = nil }; var arg_3486 any = s__1686000389__3; if linked_3484 == nil { tmp5 = ifn_3485.Invoke_O__O(arg_3486) } else { tmp5 = linked_3484.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3483, arg_3486) }; arg_3478 = tmp4.Invoke_O__O(tmp5); if linked_3475 == nil { return ifn_3476.Invoke_O_O__O(arg_3477, arg_3478) } else { return linked_3475.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3474, arg_3477, arg_3478) } } else { var root_3487 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3487, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3489 lang.IFn; if linked_3488 == nil { ifn_3489 = lang.IFn_Cast(root_3487) } else { ifn_3489 = nil }; var arg_3490 any; var root_3492 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3492, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3494 lang.IFn; if linked_3493 == nil { ifn_3494 = lang.IFn_Cast(root_3492) } else { ifn_3494 = nil }; var arg_3495 any = b__1686000391__6; if linked_3493 == nil { arg_3490 = ifn_3494.Invoke_O__O(arg_3495) } else { arg_3490 = linked_3493.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3492, arg_3495) }; var arg_3491 any; if linked_3488 == nil { return ifn_3489.Invoke_O_O__O(arg_3490, arg_3491) } else { return linked_3488.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3487, arg_3490, arg_3491) } } } else { var pf__4 any; var root_3496 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3498 lang.IFn; if linked_3497 == nil { ifn_3498 = lang.IFn_Cast(root_3496) } else { ifn_3498 = nil }; var arg_3499 any = s__1686000389__3; if linked_3497 == nil { pf__4 = ifn_3498.Invoke_O__O(arg_3499) } else { pf__4 = linked_3497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3496, arg_3499) }; var root_3500 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3500, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3502 lang.IFn; if linked_3501 == nil { ifn_3502 = lang.IFn_Cast(root_3500) } else { ifn_3502 = nil }; var arg_3503 any; var tmp6 any; var root_3505 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any = pf__4; if linked_3506 == nil { tmp6 = ifn_3507.Invoke_O__O(arg_3508) } else { tmp6 = linked_3506.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3505, arg_3508) }; arg_3503 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_3504 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1686000388); var tmp8 any; var root_3509 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3511 lang.IFn; if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any = s__1686000389__3; if linked_3510 == nil { tmp8 = ifn_3511.Invoke_O__O(arg_3512) } else { tmp8 = linked_3510.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3509, arg_3512) }; arg_3504 = tmp7.Invoke_O__O(tmp8); if linked_3501 == nil { return ifn_3502.Invoke_O_O__O(arg_3503, arg_3504) } else { return linked_3501.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3500, arg_3503, arg_3504) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :540:1
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :540:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A) Ctor_O_I_O(c__b__1686000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1686000391 = c__b__1686000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :540:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A) Invoke_O__O(self any) any { { var i__1686000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000390__1)); var root_3463 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3463, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3465 lang.IFn; if linked_3464 == nil { ifn_3465 = lang.IFn_Cast(root_3463) } else { ifn_3465 = nil }; var arg_3466 any = t.F_b__1686000391; var arg_3467 any; var tmp2 any; var root_3468 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3470 lang.IFn; if linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any = pf__2; if linked_3469 == nil { tmp2 = ifn_3470.Invoke_O__O(arg_3471) } else { tmp2 = linked_3469.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3468, arg_3471) }; arg_3467 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_3464 == nil { ifn_3465.Invoke_O_O__O(arg_3466, arg_3467) } else { linked_3464.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3463, arg_3466, arg_3467) }; i__1686000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_3529 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3529, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3531 lang.IFn
																	if linked_3530 == nil { ifn_3531 = lang.IFn_Cast(root_3529) } else { ifn_3531 = nil }; var arg_3532 any = t.F_root; var arg_3533 any = path__1; var arg_3534 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_cc); var arg_3535 any = pf__4; if linked_3530 == nil { return ifn_3531.Invoke_O_O_O_O__O(arg_3532, arg_3533, arg_3534, arg_3535) } else { return linked_3530.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3529, arg_3532, arg_3533, arg_3534, arg_3535) } } else {
//line :543:1
			return nil } }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A{}; t.Ctor_O(p0); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A) Invoke_O_O__O(self, p1__1686000359_SHARP___1 any) any {


	var root_3538 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_3539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3538, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3540 lang.IFn; if linked_3539 == nil { ifn_3540 = lang.IFn_Cast(root_3538) } else { ifn_3540 = nil }; var arg_3541 any = t.F_by_path; var arg_3542 any = p1__1686000359_SHARP___1; if linked_3539 == nil { return ifn_3540.Invoke_O_O__O(arg_3541, arg_3542) } else { return linked_3539.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3538, arg_3541, arg_3542) } }
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :546:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :546:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A) Invoke_O_O__O(self, s__1686000403__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3666 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A_New_O_O_O_O_O(self, t.F_dir, t.F_tdir, t.F_ts, s__1686000403__1); var tmp2 *jrt.Class; var fncls__3665 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A_fn_class; if fncls__3665 == nil { var fncls__3665d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__3666); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A_fn_class = fncls__3665d; tmp2 = fncls__3665d } else { tmp2 = fncls__3665 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3666, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :546:1
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :546:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A) Ctor_O_O_O_O_O(c__iter__1686000402, c__dir, c__tdir, c__ts, c__s__1686000403 any) { t.F_iter__1686000402 = c__iter__1686000402; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1686000403 = c__s__1686000403 }
//line :546:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A) Invoke_O__O(self any) any { { var s__1686000403__1 any; var t_ any = t.F_s__1686000403; t.F_s__1686000403 = nil; s__1686000403__1 = t_; for { var temp__1927000414__auto____2 any; var root_3549 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3549, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3551 lang.IFn; if linked_3550 == nil { ifn_3551 = lang.IFn_Cast(root_3549) } else { ifn_3551 = nil }; var arg_3552 any = s__1686000403__1; if linked_3550 == nil { temp__1927000414__auto____2 = ifn_3551.Invoke_O__O(arg_3552) } else { temp__1927000414__auto____2 = linked_3550.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3549, arg_3552) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000403__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3553 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3553, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3555 lang.IFn; if linked_3554 == nil { ifn_3555 = lang.IFn_Cast(root_3553) } else { ifn_3555 = nil }; var arg_3556 any = s__1686000403__3; if linked_3554 == nil { tmp1 = ifn_3555.Invoke_O__O(arg_3556) } else { tmp1 = linked_3554.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3553, arg_3556) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3557 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = s__1686000403__3; if linked_3558 == nil { c__1927001037__auto____4 = ifn_3559.Invoke_O__O(arg_3560) } else { c__1927001037__auto____4 = linked_3558.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3557, arg_3560) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000405__6 any; var root_3561 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3561, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3563 lang.IFn; if linked_3562 == nil { ifn_3563 = lang.IFn_Cast(root_3561) } else { ifn_3563 = nil }; var arg_3564 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3562 == nil { b__1686000405__6 = ifn_3563.Invoke_O__O(arg_3564) } else { b__1686000405__6 = linked_3562.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3561, arg_3564) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3600 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A_New_O_O_O_O_I_O(t.F_dir, b__1686000405__6, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3599 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A_fn_class; if fncls__3599 == nil { var fncls__3599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__3600); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A_fn_class = fncls__3599d; tmp3 = fncls__3599d } else { tmp3 = fncls__3599 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3600, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3601 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3601, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3603 lang.IFn; if linked_3602 == nil { ifn_3603 = lang.IFn_Cast(root_3601) } else { ifn_3603 = nil }; var arg_3604 any; var root_3606 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3606, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3608 lang.IFn; if linked_3607 == nil { ifn_3608 = lang.IFn_Cast(root_3606) } else { ifn_3608 = nil }; var arg_3609 any = b__1686000405__6; if linked_3607 == nil { arg_3604 = ifn_3608.Invoke_O__O(arg_3609) } else { arg_3604 = linked_3607.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3606, arg_3609) }; var arg_3605 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000402); var tmp5 any; var root_3610 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3610, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3612 lang.IFn; if linked_3611 == nil { ifn_3612 = lang.IFn_Cast(root_3610) } else { ifn_3612 = nil }; var arg_3613 any = s__1686000403__3; if linked_3611 == nil { tmp5 = ifn_3612.Invoke_O__O(arg_3613) } else { tmp5 = linked_3611.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3610, arg_3613) }; arg_3605 = tmp4.Invoke_O__O(tmp5); if linked_3602 == nil { return ifn_3603.Invoke_O_O__O(arg_3604, arg_3605) } else { return linked_3602.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3601, arg_3604, arg_3605) } } else { var root_3614 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3614, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3616 lang.IFn; if linked_3615 == nil { ifn_3616 = lang.IFn_Cast(root_3614) } else { ifn_3616 = nil }; var arg_3617 any; var root_3619 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3619, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3621 lang.IFn; if linked_3620 == nil { ifn_3621 = lang.IFn_Cast(root_3619) } else { ifn_3621 = nil }; var arg_3622 any = b__1686000405__6; if linked_3620 == nil { arg_3617 = ifn_3621.Invoke_O__O(arg_3622) } else { arg_3617 = linked_3620.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3619, arg_3622) }; var arg_3618 any; if linked_3615 == nil { return ifn_3616.Invoke_O_O__O(arg_3617, arg_3618) } else { return linked_3615.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3614, arg_3617, arg_3618) } } } else { var vec__1686000415__4 any; var root_3623 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3623, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3625 lang.IFn; if linked_3624 == nil { ifn_3625 = lang.IFn_Cast(root_3623) } else { ifn_3625 = nil }; var arg_3626 any = s__1686000403__3; if linked_3624 == nil { vec__1686000415__4 = ifn_3625.Invoke_O__O(arg_3626) } else { vec__1686000415__4 = linked_3624.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3623, arg_3626) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000415__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000415__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3627 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3627, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3629 lang.IFn; _ = pf__6; if linked_3628 == nil { ifn_3629 = lang.IFn_Cast(root_3627) } else { ifn_3629 = nil }; var arg_3630 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__3660 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3659 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A_fn_class
																if fncls__3659 == nil { var fncls__3659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__3660); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A_fn_class = fncls__3659d; tmp7 = fncls__3659d } else { tmp7 = fncls__3659 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3660, tmp7, nil); arg_3630 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :546:1
	var arg_3631 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1686000402); var tmp9 any; var root_3661 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3661, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3663 lang.IFn; if linked_3662 == nil { ifn_3663 = lang.IFn_Cast(root_3661) } else { ifn_3663 = nil }; var arg_3664 any = s__1686000403__3; if linked_3662 == nil { tmp9 = ifn_3663.Invoke_O__O(arg_3664) } else { tmp9 = linked_3662.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3661, arg_3664) }; arg_3631 = tmp8.Invoke_O__O(tmp9); if linked_3628 == nil { return ifn_3629.Invoke_O_O__O(arg_3630, arg_3631) } else { return linked_3628.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3627, arg_3630, arg_3631) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :546:1
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :546:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A) Ctor_O_O_O_O_I_O(c__dir, c__b__1686000405, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__1686000405 = c__b__1686000405; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :546:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A) Invoke_O__O(self any) any { { var i__1686000404__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000404__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1686000409__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000404__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000409__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1686000409__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3565 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3565, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3567 lang.IFn; _ = pf__4; if linked_3566 == nil { ifn_3567 = lang.IFn_Cast(root_3565) } else { ifn_3567 = nil }; var arg_3568 any = t.F_b__1686000405; var arg_3569 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__3598 any = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3597 *jrt.Class = A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A_fn_class
																		if fncls__3597 == nil { var fncls__3597d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__3598); A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A_fn_class = fncls__3597d; tmp3 = fncls__3597d } else { tmp3 = fncls__3597 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3598, tmp3, nil); arg_3569 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :546:1
	if linked_3566 == nil { ifn_3567.Invoke_O_O__O(arg_3568, arg_3569) } else { linked_3566.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3565, arg_3568, arg_3569) }; i__1686000404__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000404__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :547:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :547:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_3570 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3570, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3572 lang.IFn; if linked_3571 == nil { ifn_3572 = lang.IFn_Cast(root_3570) } else { ifn_3572 = nil }; var arg_3573 any; var or__1927000174__auto____3 any; var root_3576 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3576, A_arbace_go_check_result_of_A_fn_class); var ifn_3578 lang.IFn; if linked_3577 == nil { ifn_3578 = lang.IFn_Cast(root_3576) } else { ifn_3578 = nil }; var arg_3579 any; var root_3580 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3580, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3582 lang.IFn; if linked_3581 == nil { ifn_3582 = lang.IFn_Cast(root_3580) } else { ifn_3582 = nil }; var arg_3583 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3583 = t_; var arg_3584 any = t.F_path; var arg_3585 any; var arg_3586 any = lang.PersistentVector_EMPTY.Ref(); if linked_3581 == nil { arg_3579 = ifn_3582.Invoke_O_O_O_O__O(arg_3583, arg_3584, arg_3585, arg_3586) } else { arg_3579 = linked_3581.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3580, arg_3583, arg_3584, arg_3585, arg_3586) }; if linked_3577 == nil { or__1927000174__auto____3 = ifn_3578.Invoke_O__O(arg_3579) } else { or__1927000174__auto____3 = linked_3577.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3576, arg_3579) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3573 = or__1927000174__auto____3 } else { arg_3573 = A_arbace_go_check_A_const_330 }; var arg_3574 any = A_arbace_go_check_A_const_111; var arg_3575 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3587 any = A_arbace_go_check_A_const_325.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3589 lang.IFn
																					if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any = t.F_tdir; var arg_3591 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3591 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3588 == nil { tmp3 = ifn_3589.Invoke_O_O__O(arg_3590, arg_3591) } else { tmp3 = linked_3588.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3587, arg_3590, arg_3591) }; arg_3575 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :548:1
		if linked_3571 == nil { tmp1 = ifn_3572.Invoke_O_O_O__O(arg_3573, arg_3574, arg_3575) } else { tmp1 = linked_3571.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3570, arg_3573, arg_3574, arg_3575) } }
//line :547:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3592 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3592, A_arbace_go_check_error_result_A_fn_class); var ifn_3594 lang.IFn


		if linked_3593 == nil { ifn_3594 = lang.IFn_Cast(root_3592) } else { ifn_3594 = nil }; var arg_3595 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3595 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3596 any = ex__3; if linked_3593 == nil { tmp1 = ifn_3594.Invoke_O_O__O(arg_3595, arg_3596) } else { tmp1 = linked_3593.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3592, arg_3595, arg_3596) } } }; return tmp1 }
//line :547:1
func A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :547:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :547:1
func (t *A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3632 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3633 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3632, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3634 lang.IFn; if linked_3633 == nil { ifn_3634 = lang.IFn_Cast(root_3632) } else { ifn_3634 = nil }; var arg_3635 any; var or__1927000174__auto____3 any; var root_3638 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3638, A_arbace_go_check_result_of_A_fn_class); var ifn_3640 lang.IFn; if linked_3639 == nil { ifn_3640 = lang.IFn_Cast(root_3638) } else { ifn_3640 = nil }; var arg_3641 any; var root_3642 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3642, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3644 lang.IFn; if linked_3643 == nil { ifn_3644 = lang.IFn_Cast(root_3642) } else { ifn_3644 = nil }; var arg_3645 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3645 = t_; var arg_3646 any = t.F_path; var arg_3647 any; var arg_3648 any = lang.PersistentVector_EMPTY.Ref(); if linked_3643 == nil { arg_3641 = ifn_3644.Invoke_O_O_O_O__O(arg_3645, arg_3646, arg_3647, arg_3648) } else { arg_3641 = linked_3643.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3642, arg_3645, arg_3646, arg_3647, arg_3648) }; if linked_3639 == nil { or__1927000174__auto____3 = ifn_3640.Invoke_O__O(arg_3641) } else { or__1927000174__auto____3 = linked_3639.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3638, arg_3641) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3635 = or__1927000174__auto____3 } else { arg_3635 = A_arbace_go_check_A_const_331 }; var arg_3636 any = A_arbace_go_check_A_const_111; var arg_3637 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3649 any = A_arbace_go_check_A_const_325.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3651 lang.IFn
																			if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any = t.F_tdir; var arg_3653 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3653 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3650 == nil { tmp3 = ifn_3651.Invoke_O_O__O(arg_3652, arg_3653) } else { tmp3 = linked_3650.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3649, arg_3652, arg_3653) }; arg_3637 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :548:1
		if linked_3633 == nil { tmp1 = ifn_3634.Invoke_O_O_O__O(arg_3635, arg_3636, arg_3637) } else { tmp1 = linked_3633.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3632, arg_3635, arg_3636, arg_3637) } }
//line :547:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3654 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3654, A_arbace_go_check_error_result_A_fn_class); var ifn_3656 lang.IFn


		if linked_3655 == nil { ifn_3656 = lang.IFn_Cast(root_3654) } else { ifn_3656 = nil }; var arg_3657 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3657 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3658 any = ex__3; if linked_3655 == nil { tmp1 = ifn_3656.Invoke_O_O__O(arg_3657, arg_3658) } else { tmp1 = linked_3655.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3654, arg_3657, arg_3658) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :554:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :554:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3686 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3686, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3688 lang.IFn; if


	linked_3687 == nil { ifn_3688 = lang.IFn_Cast(root_3686) } else { ifn_3688 = nil }; var arg_3689 any = A_arbace_go_check_A_const_323; var arg_3690 any = results__1; if linked_3687 == nil { rs__3 = ifn_3688.Invoke_O_O__O(arg_3689, arg_3690) } else { rs__3 = linked_3687.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3686, arg_3689, arg_3690) }; var sum__4 any; var fnbody__3703 any = /*line :554:1*/A_arbace_go_check_summarize_sum__1686000430_A_New_O(rs__3); var tmp1 *jrt.Class; var fncls__3702 *jrt.Class = A_arbace_go_check_summarize_sum__1686000430_A_fn_class; if



	fncls__3702 == nil { var fncls__3702d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__3703); A_arbace_go_check_summarize_sum__1686000430_A_fn_class = fncls__3702d; tmp1 = fncls__3702d } else { tmp1 = fncls__3702 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3703, tmp1, nil); var msum__5 any; var fnbody__3717 any = /*line :554:1*/A_arbace_go_check_summarize_msum__1686000432_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3716 *jrt.Class = A_arbace_go_check_summarize_msum__1686000432_A_fn_class; if




	fncls__3716 == nil { var fncls__3716d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__3717); A_arbace_go_check_summarize_msum__1686000432_A_fn_class = fncls__3716d; tmp2 = fncls__3716d } else { tmp2 = fncls__3716 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3717, tmp2, nil); var tmp3 any = A_arbace_go_check_A_const_297; var tmp4 any = A_arbace_go_check_A_const_333; var tmp5 any = /*line :554:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp6 any = A_arbace_go_check_A_const_334; var tmp7 any = A_arbace_go_check_A_const_335; var tmp8 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_83); var tmp9 any = A_arbace_go_check_A_const_166; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_166); var tmp11 any = A_arbace_go_check_A_const_152; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_157); var tmp13 any = A_arbace_go_check_A_const_155; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_155); var tmp15 any = A_arbace_go_check_A_const_147; var tmp16 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_158))); var tmp17 any = A_arbace_go_check_A_const_240; var tmp18 lang.IFn = lang.IFn_Cast(sum__4); var tmp19 *lang.Compiler_AOTFn; var fnbody__3805 any = A_arbace_go_check_summarize_fn__1686000434_A_New(); var tmp20 *jrt.Class; var fncls__3804 *jrt.Class = A_arbace_go_check_summarize_fn__1686000434_A_fn_class; if












	fncls__3804 == nil { var fncls__3804d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_go_check_summarize_fn__1686000434_A_fn_class = fncls__3804d; tmp20 = fncls__3804d } else { tmp20 = fncls__3804 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3805, tmp20, nil); var tmp21 any = /*line :554:1*/tmp18.Invoke_O__O(tmp19.Ref()); var tmp22 any = A_arbace_go_check_A_const_336; var tmp23 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_243); var tmp24 any = A_arbace_go_check_A_const_337; var tmp25 any; var root_3718 any = A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3718, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3720 lang.IFn; if














	linked_3719 == nil { ifn_3720 = lang.IFn_Cast(root_3718) } else { ifn_3720 = nil }; var arg_3721 any; var fnbody__3724 any = A_arbace_go_check_summarize_fn__1686000436_A_New(); var tmp26 *jrt.Class; var fncls__3723 *jrt.Class = A_arbace_go_check_summarize_fn__1686000436_A_fn_class; if fncls__3723 == nil { var fncls__3723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, nil); A_arbace_go_check_summarize_fn__1686000436_A_fn_class = fncls__3723d; tmp26 = fncls__3723d } else { tmp26 = fncls__3723 }; arg_3721 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3724, tmp26, nil); var arg_3722 any = rs__3; if linked_3719 == nil { tmp25 = ifn_3720.Invoke_O_O__O(arg_3721, arg_3722) } else { tmp25 = linked_3719.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3718, arg_3721, arg_3722) }; var tmp27 any = /*line :554:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp25)).Ref(); var tmp28 any = A_arbace_go_check_A_const_339; var tmp29 any; var root_3725 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3725, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3727 lang.IFn; if















	linked_3726 == nil { ifn_3727 = lang.IFn_Cast(root_3725) } else { ifn_3727 = nil }; var arg_3728 any; var root_3729 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3729, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3731 lang.IFn; if linked_3730 == nil { ifn_3731 = lang.IFn_Cast(root_3729) } else { ifn_3731 = nil }; var arg_3732 any; var fnbody__3735 any = A_arbace_go_check_summarize_fn__1686000438_A_New(); var tmp30 *jrt.Class; var fncls__3734 *jrt.Class = A_arbace_go_check_summarize_fn__1686000438_A_fn_class; if fncls__3734 == nil { var fncls__3734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_go_check_summarize_fn__1686000438_A_fn_class = fncls__3734d; tmp30 = fncls__3734d } else { tmp30 = fncls__3734 }; arg_3732 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3735, tmp30, nil); var arg_3733 any = rs__3; if linked_3730 == nil { arg_3728 = ifn_3731.Invoke_O_O__O(arg_3732, arg_3733) } else { arg_3728 = linked_3730.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3729, arg_3732, arg_3733) }; if linked_3726 == nil { tmp29 = ifn_3727.Invoke_O__O(arg_3728) } else { tmp29 = linked_3726.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3725, arg_3728) }; var tmp31 any = tmp29; var tmp32 any = A_arbace_go_check_A_const_340; var tmp33 any = A_arbace_go_check_A_const_143; var tmp34 any; var root_3736 any = /*line :554:1*/A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3736, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3738 lang.IFn; if
















	linked_3737 == nil { ifn_3738 = lang.IFn_Cast(root_3736) } else { ifn_3738 = nil }; var arg_3739 any = lang.IFn_Cast(A_arbace_go_check_A_const_341.GetRawRoot__O()).Invoke__O(); var arg_3740 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_143); if linked_3737 == nil { tmp34 = ifn_3738.Invoke_O_O__O(arg_3739, arg_3740) } else { tmp34 = linked_3737.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3736, arg_3739, arg_3740) }; var tmp35 any = tmp34; var tmp36 any = A_arbace_go_check_A_const_167; var tmp37 any; var root_3744 any = /*line :554:1*/A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3744, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3746 lang.IFn; if

















	linked_3745 == nil { ifn_3746 = lang.IFn_Cast(root_3744) } else { ifn_3746 = nil }; var arg_3747 any = lang.IFn_Cast(A_arbace_go_check_A_const_341.GetRawRoot__O()).Invoke__O(); var arg_3748 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_167); if linked_3745 == nil { tmp37 = ifn_3746.Invoke_O_O__O(arg_3747, arg_3748) } else { tmp37 = linked_3745.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3744, arg_3747, arg_3748) }; var tmp38 any = tmp37; var tmp39 any = A_arbace_go_check_A_const_168; var tmp40 any; var root_3752 any = /*line :554:1*/A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3752, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3754 lang.IFn; if


















	linked_3753 == nil { ifn_3754 = lang.IFn_Cast(root_3752) } else { ifn_3754 = nil }; var arg_3755 any = lang.IFn_Cast(A_arbace_go_check_A_const_341.GetRawRoot__O()).Invoke__O(); var arg_3756 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_168); if linked_3753 == nil { tmp40 = ifn_3754.Invoke_O_O__O(arg_3755, arg_3756) } else { tmp40 = linked_3753.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3752, arg_3755, arg_3756) }; var tmp41 any = tmp40; var tmp42 any = A_arbace_go_check_A_const_342; var tmp43 any; var root_3760 any = /*line :554:1*/A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3760, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3762 lang.IFn; if



















	linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any = lang.IFn_Cast(A_arbace_go_check_A_const_341.GetRawRoot__O()).Invoke__O(); var arg_3764 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_159); if linked_3761 == nil { tmp43 = ifn_3762.Invoke_O_O__O(arg_3763, arg_3764) } else { tmp43 = linked_3761.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3760, arg_3763, arg_3764) }; var tmp44 any = tmp43; var tmp45 any = A_arbace_go_check_A_const_244; var tmp46 any = A_arbace_go_check_A_const_333; var tmp47 any; var root_3768 any = /*line :554:1*/A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3768, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3770 lang.IFn; if




















	linked_3769 == nil { ifn_3770 = lang.IFn_Cast(root_3768) } else { ifn_3770 = nil }; var arg_3771 any; var fnbody__3779 any = A_arbace_go_check_summarize_fn__1686000440_A_New(); var tmp48 *jrt.Class; var fncls__3778 *jrt.Class = A_arbace_go_check_summarize_fn__1686000440_A_fn_class; if fncls__3778 == nil { var fncls__3778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_go_check_summarize_fn__1686000440_A_fn_class = fncls__3778d; tmp48 = fncls__3778d } else { tmp48 = fncls__3778 }; arg_3771 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3779, tmp48, nil); var arg_3772 any = rs__3; if linked_3769 == nil { tmp47 = ifn_3770.Invoke_O_O__O(arg_3771, arg_3772) } else { tmp47 = linked_3769.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3768, arg_3771, arg_3772) }; var tmp49 any = /*line :554:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp47)).Ref(); var tmp50 any = A_arbace_go_check_A_const_344; var tmp51 lang.IFn = lang.IFn_Cast(sum__4); var tmp52 *lang.Compiler_AOTFn; var fnbody__3813 any = A_arbace_go_check_summarize_fn__1686000442_A_New(); var tmp53 *jrt.Class; var fncls__3812 *jrt.Class = A_arbace_go_check_summarize_fn__1686000442_A_fn_class; if





















	fncls__3812 == nil { var fncls__3812d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_go_check_summarize_fn__1686000442_A_fn_class = fncls__3812d; tmp53 = fncls__3812d } else { tmp53 = fncls__3812 }; tmp52 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3813, tmp53, nil); var tmp54 any = /*line :554:1*/tmp51.Invoke_O__O(tmp52.Ref()); var tmp55 any = A_arbace_go_check_A_const_345; var tmp56 any; var root_3780 any = A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3780, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3782 lang.IFn; if






















	linked_3781 == nil { ifn_3782 = lang.IFn_Cast(root_3780) } else { ifn_3782 = nil }; var arg_3783 any; var fnbody__3795 any = A_arbace_go_check_summarize_fn__1686000444_A_New(); var tmp57 *jrt.Class; var fncls__3794 *jrt.Class = A_arbace_go_check_summarize_fn__1686000444_A_fn_class; if fncls__3794 == nil { var fncls__3794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_go_check_summarize_fn__1686000444_A_fn_class = fncls__3794d; tmp57 = fncls__3794d } else { tmp57 = fncls__3794 }; arg_3783 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3795, tmp57, nil); var arg_3784 any = rs__3; if linked_3781 == nil { tmp56 = ifn_3782.Invoke_O_O__O(arg_3783, arg_3784) } else { tmp56 = linked_3781.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3780, arg_3783, arg_3784) }; var tmp58 any = /*line :554:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp35, tmp36, tmp38, tmp39, tmp41, tmp42, tmp44, tmp45, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp49, tmp50, tmp54, tmp55, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp56)).Ref())))); var tmp59 any = A_arbace_go_check_A_const_147; var tmp60 any; var root_3796 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3796, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3798 lang.IFn; if























	linked_3797 == nil { ifn_3798 = lang.IFn_Cast(root_3796) } else { ifn_3798 = nil }; var arg_3799 any = lang.IFn_Cast(A_arbace_go_check_A_const_341.GetRawRoot__O()).Invoke__O(); var arg_3800 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_147); if linked_3797 == nil { tmp60 = ifn_3798.Invoke_O_O__O(arg_3799, arg_3800) } else { tmp60 = linked_3797.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3796, arg_3799, arg_3800) }; return /*line :554:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, corpus__0, tmp4, tmp5, tmp6, tmp16, tmp17, tmp21, tmp22, tmp23, tmp24, tmp27, tmp28, tmp31, tmp32, tmp58, tmp59, tmp60)) }



func A_arbace_go_check_summarize_sum__1686000430_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1686000430_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1686000430_A{}; t.Ctor_O(p0); return t }
//line :558:1
func (t *A_arbace_go_check_summarize_sum__1686000430_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :558:1
func (t *A_arbace_go_check_summarize_sum__1686000430_A) Invoke_O_O__O(self, k__1 any) any { var root_3691 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3691, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3693 lang.IFn; if linked_3692 == nil { ifn_3693 = lang.IFn_Cast(root_3691) } else { ifn_3693 = nil }; var arg_3694 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3695 any = A_arbace_go_check_A_const_22; var arg_3696 any; var root_3697 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3697, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3699 lang.IFn; if linked_3698 == nil { ifn_3699 = lang.IFn_Cast(root_3697) } else { ifn_3699 = nil }; var arg_3700 any = k__1; var arg_3701 any = t.F_rs; if linked_3698 == nil { arg_3696 = ifn_3699.Invoke_O_O__O(arg_3700, arg_3701) } else { arg_3696 = linked_3698.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3697, arg_3700, arg_3701) }; if linked_3692 == nil { return ifn_3693.Invoke_O_O_O__O(arg_3694, arg_3695, arg_3696) } else { return linked_3692.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3691, arg_3694, arg_3695, arg_3696) } }
func A_arbace_go_check_summarize_msum__1686000432_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1686000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1686000432_A{}; t.Ctor_O(p0); return t }
//line :559:1
func (t *A_arbace_go_check_summarize_msum__1686000432_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :559:1
func (t *A_arbace_go_check_summarize_msum__1686000432_A) Invoke_O_O__O(self, k__1 any) any { var root_3704 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3705 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3704, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3706 lang.IFn; if linked_3705 == nil { ifn_3706 = lang.IFn_Cast(root_3704) } else { ifn_3706 = nil }; var arg_3707 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var arg_3708 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3709 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3710 any; var root_3711 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3711, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3713 lang.IFn; if linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any = k__1; var arg_3715 any = t.F_rs; if linked_3712 == nil { arg_3710 = ifn_3713.Invoke_O_O__O(arg_3714, arg_3715) } else { arg_3710 = linked_3712.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3711, arg_3714, arg_3715) }; if linked_3705 == nil { return ifn_3706.Invoke_O_O_O_O__O(arg_3707, arg_3708, arg_3709, arg_3710) } else { return linked_3705.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3704, arg_3707, arg_3708, arg_3709, arg_3710) } }







func A_arbace_go_check_summarize_fn__1686000434_A_New() *A_arbace_go_check_summarize_fn__1686000434_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1686000434_A{}; t.Ctor(); return t }
//line :567:1
func (t *A_arbace_go_check_summarize_fn__1686000434_A) Ctor() {}
//line :567:1
func (t *A_arbace_go_check_summarize_fn__1686000434_A) Invoke_O_O__O(self, p1__1686000424_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_240.Invoke_O__O(p1__1686000424_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1686000436_A_New() *A_arbace_go_check_summarize_fn__1686000436_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1686000436_A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_go_check_summarize_fn__1686000436_A) Ctor() {}
//line :569:1
func (t *A_arbace_go_check_summarize_fn__1686000436_A) Invoke_O_O__O(self, p1__1686000425_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_313.Invoke_O__O(p1__1686000425_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_83.Invoke_O__O(p1__1686000425_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1686000438_A_New() *A_arbace_go_check_summarize_fn__1686000438_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1686000438_A{}; t.Ctor(); return t }
//line :570:1
func (t *A_arbace_go_check_summarize_fn__1686000438_A) Ctor() {}
//line :570:1
func (t *A_arbace_go_check_summarize_fn__1686000438_A) Invoke_O_O__O(self, p1__1686000426_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_313.Invoke_O__O(p1__1686000426_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_83.Invoke_O__O(p1__1686000426_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_111.Invoke_O__O(p1__1686000426_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1686000440_A_New() *A_arbace_go_check_summarize_fn__1686000440_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1686000440_A{}; t.Ctor(); return t }
//line :575:1
func (t *A_arbace_go_check_summarize_fn__1686000440_A) Ctor() {}
//line :575:1
func (t *A_arbace_go_check_summarize_fn__1686000440_A) Invoke_O_O__O(self, p1__1686000427_SHARP___1 any) any { var root_3773 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3775 lang.IFn; if linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = p1__1686000427_SHARP___1; var arg_3777 any = A_arbace_go_check_A_const_343; if linked_3774 == nil { return ifn_3775.Invoke_O_O__O(arg_3776, arg_3777) } else { return linked_3774.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3773, arg_3776, arg_3777) } }
func A_arbace_go_check_summarize_fn__1686000442_A_New() *A_arbace_go_check_summarize_fn__1686000442_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1686000442_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_go_check_summarize_fn__1686000442_A) Ctor() {}
//line :576:1
func (t *A_arbace_go_check_summarize_fn__1686000442_A) Invoke_O_O__O(self, p1__1686000428_SHARP___1 any) any { var root_3806 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3806, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3808 lang.IFn; if linked_3807 == nil { ifn_3808 = lang.IFn_Cast(root_3806) } else { ifn_3808 = nil }; var arg_3809 any = p1__1686000428_SHARP___1; var arg_3810 any = A_arbace_go_check_A_const_348; var arg_3811 any = A_arbace_go_check_A_const_22; if linked_3807 == nil { return ifn_3808.Invoke_O_O_O__O(arg_3809, arg_3810, arg_3811) } else { return linked_3807.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3806, arg_3809, arg_3810, arg_3811) } }
func A_arbace_go_check_summarize_fn__1686000444_A_New() *A_arbace_go_check_summarize_fn__1686000444_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1686000444_A{}; t.Ctor(); return t }
//line :577:1
func (t *A_arbace_go_check_summarize_fn__1686000444_A) Ctor() {}
//line :577:1
func (t *A_arbace_go_check_summarize_fn__1686000444_A) Invoke_O_O__O(self, p1__1686000429_SHARP___1 any) any { var root_3785 any = A_arbace_go_check_A_const_346.GetRawRoot__O(); var linked_3786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3785, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3787 lang.IFn; if linked_3786 == nil { ifn_3787 = lang.IFn_Cast(root_3785) } else { ifn_3787 = nil }; var arg_3788 any; var root_3789 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3789, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3791 lang.IFn; if linked_3790 == nil { ifn_3791 = lang.IFn_Cast(root_3789) } else { ifn_3791 = nil }; var arg_3792 any = p1__1686000429_SHARP___1; var arg_3793 any = A_arbace_go_check_A_const_347; if linked_3790 == nil { arg_3788 = ifn_3791.Invoke_O_O__O(arg_3792, arg_3793) } else { arg_3788 = linked_3790.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3789, arg_3792, arg_3793) }; if linked_3786 == nil { return ifn_3787.Invoke_O__O(arg_3788) } else { return linked_3786.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3785, arg_3788) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :580:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :580:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var fnbody__3904 any = A_arbace_go_check_report_errors_iter__1686000447__1686000453_A_New(); var tmp1 *jrt.Class; var fncls__3903 *jrt.Class = A_arbace_go_check_report_errors_iter__1686000447__1686000453_A_fn_class; if


	fncls__3903 == nil { var fncls__3903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_go_check_report_errors_iter__1686000447__1686000453_A_fn_class = fncls__3903d; tmp1 = fncls__3903d } else { tmp1 = fncls__3903 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3904, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :583:1
func A_arbace_go_check_report_errors_iter__1686000447__1686000453_A_New() *A_arbace_go_check_report_errors_iter__1686000447__1686000453_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1686000447__1686000453_A{}; t.Ctor(); return t }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_A) Ctor() {}
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_A) Invoke_O_O__O(self, s__1686000448__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3902 any = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A_New_O_O(self, s__1686000448__1); var tmp2 *jrt.Class; var fncls__3901 *jrt.Class = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A_fn_class; if fncls__3901 == nil { var fncls__3901d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, fnbody__3902); A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A_fn_class = fncls__3901d; tmp2 = fncls__3901d } else { tmp2 = fncls__3901 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3902, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :583:1
func A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A{}; t.Ctor_O_O(p0, p1); return t }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A) Ctor_O_O(c__iter__1686000447, c__s__1686000448 any) { t.F_iter__1686000447 = c__iter__1686000447; t.F_s__1686000448 = c__s__1686000448 }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A) Invoke_O__O(self any) any { { var s__1686000448__1 any; var t_ any = t.F_s__1686000448; t.F_s__1686000448 = nil; s__1686000448__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3814 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3814, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3816 lang.IFn; if linked_3815 == nil { ifn_3816 = lang.IFn_Cast(root_3814) } else { ifn_3816 = nil }; var arg_3817 any = s__1686000448__1; if linked_3815 == nil { temp__1927000414__auto____2 = ifn_3816.Invoke_O__O(arg_3817) } else { temp__1927000414__auto____2 = linked_3815.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3814, arg_3817) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3818 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3818, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3820 lang.IFn; if linked_3819 == nil { ifn_3820 = lang.IFn_Cast(root_3818) } else { ifn_3820 = nil }; var arg_3821 any = xs__1927001018__auto____3; if linked_3819 == nil { r__4 = ifn_3820.Invoke_O__O(arg_3821) } else { r__4 = linked_3819.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3818, arg_3821) }; var iterys__1927001035__auto____5 any; var fnbody__3883 any = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A_New_O(r__4); var tmp1 *jrt.Class; var fncls__3882 *jrt.Class = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A_fn_class; if fncls__3882 == nil { var fncls__3882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__3883); A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A_fn_class = fncls__3882d; tmp1 = fncls__3882d } else { tmp1 = fncls__3882 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3883, tmp1, nil); var fs__1927001036__auto____6 any; var root_3884 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3884, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3886 lang.IFn; if linked_3885 == nil { ifn_3886 = lang.IFn_Cast(root_3884) } else { ifn_3886 = nil }; var arg_3887 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_240.Invoke_O__O(r__4)); if linked_3885 == nil { fs__1927001036__auto____6 = ifn_3886.Invoke_O__O(arg_3887) } else { fs__1927001036__auto____6 = linked_3885.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3884, arg_3887) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3888 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3889 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3888, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3890 lang.IFn; if linked_3889 == nil { ifn_3890 = lang.IFn_Cast(root_3888) } else { ifn_3890 = nil }; var arg_3891 any = fs__1927001036__auto____6; var arg_3892 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1686000447); var tmp3 any; var root_3893 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3893, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3895 lang.IFn; if linked_3894 == nil { ifn_3895 = lang.IFn_Cast(root_3893) } else { ifn_3895 = nil }; var arg_3896 any = s__1686000448__1; if linked_3894 == nil { tmp3 = ifn_3895.Invoke_O__O(arg_3896) } else { tmp3 = linked_3894.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3893, arg_3896) }; arg_3892 = tmp2.Invoke_O__O(tmp3); if linked_3889 == nil { return ifn_3890.Invoke_O_O__O(arg_3891, arg_3892) } else { return linked_3889.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3888, arg_3891, arg_3892) } } else { var tmp4 any; var root_3897 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3897, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3899 lang.IFn; if linked_3898 == nil { ifn_3899 = lang.IFn_Cast(root_3897) } else { ifn_3899 = nil }; var arg_3900 any = s__1686000448__1; if linked_3898 == nil { tmp4 = ifn_3899.Invoke_O__O(arg_3900) } else { tmp4 = linked_3898.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3897, arg_3900) }; s__1686000448__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :583:1
func A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A{}; t.Ctor_O(p0); return t }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A) Invoke_O_O__O(self, s__1686000450__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3881 any = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A_New_O_O_O(self, t.F_r, s__1686000450__1); var tmp2 *jrt.Class; var fncls__3880 *jrt.Class = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A_fn_class; if fncls__3880 == nil { var fncls__3880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, fnbody__3881); A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A_fn_class = fncls__3880d; tmp2 = fncls__3880d } else { tmp2 = fncls__3880 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3881, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :583:1
func A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A) Ctor_O_O_O(c__iter__1686000449, c__r, c__s__1686000450 any) { t.F_iter__1686000449 = c__iter__1686000449; t.F_r = c__r; t.F_s__1686000450 = c__s__1686000450 }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A) Invoke_O__O(self any) any { { var s__1686000450__1 any; var t_ any = t.F_s__1686000450; t.F_s__1686000450 = nil; s__1686000450__1 = t_; for { var temp__1927000414__auto____2 any; var root_3822 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3822, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3824 lang.IFn; if linked_3823 == nil { ifn_3824 = lang.IFn_Cast(root_3822) } else { ifn_3824 = nil }; var arg_3825 any = s__1686000450__1; if linked_3823 == nil { temp__1927000414__auto____2 = ifn_3824.Invoke_O__O(arg_3825) } else { temp__1927000414__auto____2 = linked_3823.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3822, arg_3825) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000450__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3826 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3826, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3828 lang.IFn; if linked_3827 == nil { ifn_3828 = lang.IFn_Cast(root_3826) } else { ifn_3828 = nil }; var arg_3829 any = s__1686000450__3; if linked_3827 == nil { tmp1 = ifn_3828.Invoke_O__O(arg_3829) } else { tmp1 = linked_3827.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3826, arg_3829) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3830 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3830, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3832 lang.IFn; if linked_3831 == nil { ifn_3832 = lang.IFn_Cast(root_3830) } else { ifn_3832 = nil }; var arg_3833 any = s__1686000450__3; if linked_3831 == nil { c__1927001037__auto____4 = ifn_3832.Invoke_O__O(arg_3833) } else { c__1927001037__auto____4 = linked_3831.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3830, arg_3833) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000452__6 any; var root_3834 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3834, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3836 lang.IFn; if linked_3835 == nil { ifn_3836 = lang.IFn_Cast(root_3834) } else { ifn_3836 = nil }; var arg_3837 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3835 == nil { b__1686000452__6 = ifn_3836.Invoke_O__O(arg_3837) } else { b__1686000452__6 = linked_3835.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3834, arg_3837) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3844 any = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A_New_O_O_I_O(b__1686000452__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3843 *jrt.Class = A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A_fn_class; if fncls__3843 == nil { var fncls__3843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__3844); A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A_fn_class = fncls__3843d; tmp3 = fncls__3843d } else { tmp3 = fncls__3843 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3844, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3845 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3845, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3847 lang.IFn; if linked_3846 == nil { ifn_3847 = lang.IFn_Cast(root_3845) } else { ifn_3847 = nil }; var arg_3848 any; var root_3850 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3850, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3852 lang.IFn; if linked_3851 == nil { ifn_3852 = lang.IFn_Cast(root_3850) } else { ifn_3852 = nil }; var arg_3853 any = b__1686000452__6; if linked_3851 == nil { arg_3848 = ifn_3852.Invoke_O__O(arg_3853) } else { arg_3848 = linked_3851.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3850, arg_3853) }; var arg_3849 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000449); var tmp5 any; var root_3854 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3854, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3856 lang.IFn; if linked_3855 == nil { ifn_3856 = lang.IFn_Cast(root_3854) } else { ifn_3856 = nil }; var arg_3857 any = s__1686000450__3; if linked_3855 == nil { tmp5 = ifn_3856.Invoke_O__O(arg_3857) } else { tmp5 = linked_3855.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3854, arg_3857) }; arg_3849 = tmp4.Invoke_O__O(tmp5); if linked_3846 == nil { return ifn_3847.Invoke_O_O__O(arg_3848, arg_3849) } else { return linked_3846.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3845, arg_3848, arg_3849) } } else { var root_3858 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3858, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3860 lang.IFn; if linked_3859 == nil { ifn_3860 = lang.IFn_Cast(root_3858) } else { ifn_3860 = nil }; var arg_3861 any; var root_3863 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3863, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3865 lang.IFn; if linked_3864 == nil { ifn_3865 = lang.IFn_Cast(root_3863) } else { ifn_3865 = nil }; var arg_3866 any = b__1686000452__6; if linked_3864 == nil { arg_3861 = ifn_3865.Invoke_O__O(arg_3866) } else { arg_3861 = linked_3864.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3863, arg_3866) }; var arg_3862 any; if linked_3859 == nil { return ifn_3860.Invoke_O_O__O(arg_3861, arg_3862) } else { return linked_3859.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3858, arg_3861, arg_3862) } } } else { var e__4 any; var root_3867 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3867, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3869 lang.IFn; if linked_3868 == nil { ifn_3869 = lang.IFn_Cast(root_3867) } else { ifn_3869 = nil }; var arg_3870 any = s__1686000450__3; if linked_3868 == nil { e__4 = ifn_3869.Invoke_O__O(arg_3870) } else { e__4 = linked_3868.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3867, arg_3870) }; var root_3871 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_3872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3871, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3873 lang.IFn; if linked_3872 == nil { ifn_3873 = lang.IFn_Cast(root_3871) } else { ifn_3873 = nil }; var arg_3874 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_74.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_79.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_314.Invoke_O__O(e__4))).Ref(); var arg_3875 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1686000449); var tmp7 any; var root_3876 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = s__1686000450__3; if linked_3877 == nil { tmp7 = ifn_3878.Invoke_O__O(arg_3879) } else { tmp7 = linked_3877.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3876, arg_3879) }; arg_3875 = tmp6.Invoke_O__O(tmp7); if linked_3872 == nil { return ifn_3873.Invoke_O_O__O(arg_3874, arg_3875) } else { return linked_3872.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3871, arg_3874, arg_3875) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :583:1
func A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A) Ctor_O_O_I_O(c__b__1686000452, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1686000452 = c__b__1686000452; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :583:1
func (t *A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A) Invoke_O__O(self any) any { { var i__1686000451__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000451__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000451__1)); var root_3838 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3838, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3840 lang.IFn; if linked_3839 == nil { ifn_3840 = lang.IFn_Cast(root_3838) } else { ifn_3840 = nil }; var arg_3841 any = t.F_b__1686000452; var arg_3842 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_74.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_79.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_314.Invoke_O__O(e__2))).Ref(); if linked_3839 == nil { ifn_3840.Invoke_O_O__O(arg_3841, arg_3842) } else { linked_3839.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3838, arg_3841, arg_3842) }; i__1686000451__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000451__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :588:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :588:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1686000465__3 any; var root_3905 any = A_arbace_go_check_A_const_349.GetRawRoot__O(); var linked_3906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3905, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3907 lang.IFn; if



	linked_3906 == nil { ifn_3907 = lang.IFn_Cast(root_3905) } else { ifn_3907 = nil }; var arg_3908 any = forms__0; if linked_3906 == nil { map__1686000465__3 = ifn_3907.Invoke_O__O(arg_3908) } else { map__1686000465__3 = linked_3906.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3905, arg_3908) }; var map__1686000465__4 any; if lang.ISeq_InstanceOf(map__1686000465__3) { var tmp1 any; var root_3909 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3909, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3911 lang.IFn; if linked_3910 == nil { ifn_3911 = lang.IFn_Cast(root_3909) } else { ifn_3911 = nil }; var arg_3912 any = map__1686000465__3; if linked_3910 == nil { tmp1 = ifn_3911.Invoke_O__O(arg_3912) } else { tmp1 = linked_3910.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3909, arg_3912) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3913 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3913, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3915 lang.IFn; if linked_3914 == nil { ifn_3915 = lang.IFn_Cast(root_3913) } else { ifn_3915 = nil }; var arg_3916 any = map__1686000465__3; if linked_3914 == nil { tmp2 = ifn_3915.Invoke_O__O(arg_3916) } else { tmp2 = linked_3914.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3913, arg_3916) }; map__1686000465__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_3917 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3917, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3919 lang.IFn; if linked_3918 == nil { ifn_3919 = lang.IFn_Cast(root_3917) } else { ifn_3919 = nil }; var arg_3920 any = map__1686000465__3; if linked_3918 == nil { tmp3 = ifn_3919.Invoke_O__O(arg_3920) } else { tmp3 = linked_3918.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3917, arg_3920) }; if jrt.J2g_Truth(tmp3) { var root_3921 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3921, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3923 lang.IFn; if linked_3922 == nil { ifn_3923 = lang.IFn_Cast(root_3921) } else { ifn_3923 = nil }; var arg_3924 any = map__1686000465__3; if linked_3922 == nil { map__1686000465__4 = ifn_3923.Invoke_O__O(arg_3924) } else { map__1686000465__4 = linked_3922.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3921, arg_3924) } } else { map__1686000465__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1686000465__4 = map__1686000465__3 }; var package__5 any = /*line :588:1*/lang.RT_Get_O_O__O_NoInit(map__1686000465__4, A_arbace_go_check_A_const_110); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1686000465__4, A_arbace_go_check_A_const_71); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1686000465__4, A_arbace_go_check_A_const_125); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_350.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_351; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_112.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_111; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_111.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_118 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_71; var tmp10 any; var root_3931 any = /*line :588:1*/A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_3932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3931, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3933 lang.IFn; if





	linked_3932 == nil { ifn_3933 = lang.IFn_Cast(root_3931) } else { ifn_3933 = nil }; var arg_3934 any = name__6; if linked_3932 == nil { tmp10 = ifn_3933.Invoke_O__O(arg_3934) } else { tmp10 = linked_3932.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3931, arg_3934) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_112; var tmp13 any = A_arbace_go_check_A_const_82; var tmp14 any = A_arbace_go_check_A_const_235; var tmp15 any; var root_3935 any = /*line :588:1*/A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3935, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3937 lang.IFn; if






	linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; var arg_3938 any; var fnbody__3953 any = A_arbace_go_check_forms_source_fn__1686000467_A_New(); var tmp16 *jrt.Class; var fncls__3952 *jrt.Class = A_arbace_go_check_forms_source_fn__1686000467_A_fn_class; if fncls__3952 == nil { var fncls__3952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, nil); A_arbace_go_check_forms_source_fn__1686000467_A_fn_class = fncls__3952d; tmp16 = fncls__3952d } else { tmp16 = fncls__3952 }; arg_3938 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3953, tmp16, nil); var arg_3939 any = forms__0; if linked_3936 == nil { tmp15 = ifn_3937.Invoke_O_O__O(arg_3938, arg_3939) } else { tmp15 = linked_3936.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3935, arg_3938, arg_3939) }; var tmp17 any = tmp15; var tmp18 any = A_arbace_go_check_A_const_125; var tmp19 any; var root_3954 any = /*line :588:1*/A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_3955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3954, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3956 lang.IFn; if







	linked_3955 == nil { ifn_3956 = lang.IFn_Cast(root_3954) } else { ifn_3956 = nil }; var arg_3957 any; var iter__1927001039__auto____9 any; var fnbody__4031 any = A_arbace_go_check_forms_source_iter__1686000469__1686000473_A_New(); var tmp20 *jrt.Class; var fncls__4030 *jrt.Class = A_arbace_go_check_forms_source_iter__1686000469__1686000473_A_fn_class; if fncls__4030 == nil { var fncls__4030d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_go_check_forms_source_iter__1686000469__1686000473_A_fn_class = fncls__4030d; tmp20 = fncls__4030d } else { tmp20 = fncls__4030 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4031, tmp20, nil); arg_3957 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3955 == nil { tmp19 = ifn_3956.Invoke_O__O(arg_3957) } else { tmp19 = linked_3955.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3954, arg_3957) }; return /*line :588:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp17, tmp18, tmp19)) }






func A_arbace_go_check_forms_source_fn__1686000467_A_New() *A_arbace_go_check_forms_source_fn__1686000467_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1686000467_A{}; t.Ctor(); return t }
//line :595:1
func (t *A_arbace_go_check_forms_source_fn__1686000467_A) Ctor() {}
//line :595:1
func (t *A_arbace_go_check_forms_source_fn__1686000467_A) Invoke_O_O__O(self, p1__1686000464_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3940 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3940, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3942 lang.IFn; if linked_3941 == nil { ifn_3942 = lang.IFn_Cast(root_3940) } else { ifn_3942 = nil }; var arg_3943 any = p1__1686000464_SHARP___1; if linked_3941 == nil { and__1927000168__auto____2 = ifn_3942.Invoke_O__O(arg_3943) } else { and__1927000168__auto____2 = linked_3941.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3940, arg_3943) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_353; var tmp3 any; var root_3944 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3944, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3946 lang.IFn; if linked_3945 == nil { ifn_3946 = lang.IFn_Cast(root_3944) } else { ifn_3946 = nil }; var arg_3947 any = p1__1686000464_SHARP___1; if linked_3945 == nil { tmp3 = ifn_3946.Invoke_O__O(arg_3947) } else { tmp3 = linked_3945.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3944, arg_3947) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3948 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_3949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3948, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3950 lang.IFn; if linked_3949 == nil { ifn_3950 = lang.IFn_Cast(root_3948) } else { ifn_3950 = nil }; var arg_3951 any = p1__1686000464_SHARP___1; if linked_3949 == nil { return ifn_3950.Invoke_O__O(arg_3951) } else { return linked_3949.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3948, arg_3951) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1686000469__1686000473_A_New() *A_arbace_go_check_forms_source_iter__1686000469__1686000473_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1686000469__1686000473_A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_go_check_forms_source_iter__1686000469__1686000473_A) Ctor() {}
//line :596:1
func (t *A_arbace_go_check_forms_source_iter__1686000469__1686000473_A) Invoke_O_O__O(self, s__1686000470__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4029 any = A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A_New_O_O(self, s__1686000470__1); var tmp2 *jrt.Class; var fncls__4028 *jrt.Class = A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A_fn_class; if fncls__4028 == nil { var fncls__4028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__4029); A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A_fn_class = fncls__4028d; tmp2 = fncls__4028d } else { tmp2 = fncls__4028 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4029, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :596:1
func A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A{}; t.Ctor_O_O(p0, p1); return t }
//line :596:1
func (t *A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A) Ctor_O_O(c__iter__1686000469, c__s__1686000470 any) { t.F_iter__1686000469 = c__iter__1686000469; t.F_s__1686000470 = c__s__1686000470 }
//line :596:1
func (t *A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A) Invoke_O__O(self any) any { { var s__1686000470__1 any; var t_ any = t.F_s__1686000470; t.F_s__1686000470 = nil; s__1686000470__1 = t_; for { var temp__1927000414__auto____2 any; var root_3958 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3958, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3960 lang.IFn; if linked_3959 == nil { ifn_3960 = lang.IFn_Cast(root_3958) } else { ifn_3960 = nil }; var arg_3961 any = s__1686000470__1; if linked_3959 == nil { temp__1927000414__auto____2 = ifn_3960.Invoke_O__O(arg_3961) } else { temp__1927000414__auto____2 = linked_3959.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3958, arg_3961) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000470__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3962 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3962, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3964 lang.IFn; if linked_3963 == nil { ifn_3964 = lang.IFn_Cast(root_3962) } else { ifn_3964 = nil }; var arg_3965 any = s__1686000470__3; if linked_3963 == nil { tmp1 = ifn_3964.Invoke_O__O(arg_3965) } else { tmp1 = linked_3963.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3962, arg_3965) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3966 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3966, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3968 lang.IFn; if linked_3967 == nil { ifn_3968 = lang.IFn_Cast(root_3966) } else { ifn_3968 = nil }; var arg_3969 any = s__1686000470__3; if linked_3967 == nil { c__1927001037__auto____4 = ifn_3968.Invoke_O__O(arg_3969) } else { c__1927001037__auto____4 = linked_3967.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3966, arg_3969) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000472__6 any; var root_3970 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3970, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3972 lang.IFn; if linked_3971 == nil { ifn_3972 = lang.IFn_Cast(root_3970) } else { ifn_3972 = nil }; var arg_3973 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3971 == nil { b__1686000472__6 = ifn_3972.Invoke_O__O(arg_3973) } else { b__1686000472__6 = linked_3971.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3970, arg_3973) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3986 any = A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A_New_I_O_O(size__1927001038__auto____5, b__1686000472__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3985 *jrt.Class = A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A_fn_class; if fncls__3985 == nil { var fncls__3985d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__3986); A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A_fn_class = fncls__3985d; tmp3 = fncls__3985d } else { tmp3 = fncls__3985 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3986, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3987 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3987, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3989 lang.IFn; if linked_3988 == nil { ifn_3989 = lang.IFn_Cast(root_3987) } else { ifn_3989 = nil }; var arg_3990 any; var root_3992 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_3993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3992, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3994 lang.IFn; if linked_3993 == nil { ifn_3994 = lang.IFn_Cast(root_3992) } else { ifn_3994 = nil }; var arg_3995 any = b__1686000472__6; if linked_3993 == nil { arg_3990 = ifn_3994.Invoke_O__O(arg_3995) } else { arg_3990 = linked_3993.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3992, arg_3995) }; var arg_3991 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000469); var tmp5 any; var root_3996 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3996, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3998 lang.IFn; if linked_3997 == nil { ifn_3998 = lang.IFn_Cast(root_3996) } else { ifn_3998 = nil }; var arg_3999 any = s__1686000470__3; if linked_3997 == nil { tmp5 = ifn_3998.Invoke_O__O(arg_3999) } else { tmp5 = linked_3997.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3996, arg_3999) }; arg_3991 = tmp4.Invoke_O__O(tmp5); if linked_3988 == nil { return ifn_3989.Invoke_O_O__O(arg_3990, arg_3991) } else { return linked_3988.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3987, arg_3990, arg_3991) } } else { var root_4000 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4000, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4002 lang.IFn; if linked_4001 == nil { ifn_4002 = lang.IFn_Cast(root_4000) } else { ifn_4002 = nil }; var arg_4003 any; var root_4005 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_4006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4005, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4007 lang.IFn; if linked_4006 == nil { ifn_4007 = lang.IFn_Cast(root_4005) } else { ifn_4007 = nil }; var arg_4008 any = b__1686000472__6; if linked_4006 == nil { arg_4003 = ifn_4007.Invoke_O__O(arg_4008) } else { arg_4003 = linked_4006.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4005, arg_4008) }; var arg_4004 any; if linked_4001 == nil { return ifn_4002.Invoke_O_O__O(arg_4003, arg_4004) } else { return linked_4001.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4000, arg_4003, arg_4004) } } } else { var fi__4 any; var root_4009 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4009, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4011 lang.IFn; if linked_4010 == nil { ifn_4011 = lang.IFn_Cast(root_4009) } else { ifn_4011 = nil }; var arg_4012 any = s__1686000470__3; if linked_4010 == nil { fi__4 = ifn_4011.Invoke_O__O(arg_4012) } else { fi__4 = linked_4010.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4009, arg_4012) }; var root_4013 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_4014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4013, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4015 lang.IFn; if linked_4014 == nil { ifn_4015 = lang.IFn_Cast(root_4013) } else { ifn_4015 = nil }; var arg_4016 any; var root_4018 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4018, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4020 lang.IFn; if linked_4019 == nil { ifn_4020 = lang.IFn_Cast(root_4018) } else { ifn_4020 = nil }; var arg_4021 any = fi__4; var arg_4022 any = A_arbace_go_check_A_const_82; var arg_4023 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__4); if linked_4019 == nil { arg_4016 = ifn_4020.Invoke_O_O_O__O(arg_4021, arg_4022, arg_4023) } else { arg_4016 = linked_4019.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4018, arg_4021, arg_4022, arg_4023) }; var arg_4017 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1686000469); var tmp7 any; var root_4024 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4024, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4026 lang.IFn; if linked_4025 == nil { ifn_4026 = lang.IFn_Cast(root_4024) } else { ifn_4026 = nil }; var arg_4027 any = s__1686000470__3; if linked_4025 == nil { tmp7 = ifn_4026.Invoke_O__O(arg_4027) } else { tmp7 = linked_4025.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4024, arg_4027) }; arg_4017 = tmp6.Invoke_O__O(tmp7); if linked_4014 == nil { return ifn_4015.Invoke_O_O__O(arg_4016, arg_4017) } else { return linked_4014.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4013, arg_4016, arg_4017) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :596:1
func A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :596:1
func (t *A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1686000472, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1686000472 = c__b__1686000472; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :596:1
func (t *A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A) Invoke_O__O(self any) any { { var i__1686000471__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000471__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000471__1)); var root_3974 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3974, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3976 lang.IFn; if linked_3975 == nil { ifn_3976 = lang.IFn_Cast(root_3974) } else { ifn_3976 = nil }; var arg_3977 any = t.F_b__1686000472; var arg_3978 any; var root_3979 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3980 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3979, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3981 lang.IFn; if linked_3980 == nil { ifn_3981 = lang.IFn_Cast(root_3979) } else { ifn_3981 = nil }; var arg_3982 any = fi__2; var arg_3983 any = A_arbace_go_check_A_const_82; var arg_3984 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__2); if linked_3980 == nil { arg_3978 = ifn_3981.Invoke_O_O_O__O(arg_3982, arg_3983, arg_3984) } else { arg_3978 = linked_3980.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3979, arg_3982, arg_3983, arg_3984) }; if linked_3975 == nil { ifn_3976.Invoke_O_O__O(arg_3977, arg_3978) } else { linked_3975.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3974, arg_3977, arg_3978) }; i__1686000471__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000471__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :598:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :598:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_4041 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_4042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4041, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4043 lang.IFn; if




	linked_4042 == nil { ifn_4043 = lang.IFn_Cast(root_4041) } else { ifn_4043 = nil }; var arg_4044 any = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_355, jrt.Boolean_FALSE.Ref()); if linked_4042 == nil { ifn_4043.Invoke_O__O(arg_4044) } else { linked_4042.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4041, arg_4044) }; var tmp1 any; tmp3 := /*line :598:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_4032 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); var linked_4033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4032, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_4034 lang.IFn






		if linked_4033 == nil { ifn_4034 = lang.IFn_Cast(root_4032) } else { ifn_4034 = nil }; var arg_4035 any = r__2; var arg_4036 any = jrt.Boolean_FALSE.Ref(); var arg_4037 any = eof__3; if linked_4033 == nil { f__7 = ifn_4034.Invoke_O_O_O__O(arg_4035, arg_4036, arg_4037) } else { f__7 = linked_4033.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_4032, arg_4035, arg_4036, arg_4037) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_4050 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_4051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4050, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_4052 lang.IFn; if linked_4051 == nil { ifn_4052 = lang.IFn_Cast(root_4050) } else { ifn_4052 = nil }; var arg_4053 any = acc__6; var arg_4054 any = f__7; if linked_4051 == nil { tmp2 = ifn_4052.Invoke_O_O__O(arg_4053, arg_4054) } else { tmp2 = linked_4051.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_4050, arg_4053, arg_4054) }; acc__6 = tmp2; continue L1 }
//line :598:1
		break L1 } }; return nil }(); var root_4038 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_4039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4038, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4040 lang.IFn; if




	linked_4039 == nil { ifn_4040 = lang.IFn_Cast(root_4038) } else { ifn_4040 = nil }; if linked_4039 == nil { ifn_4040.Invoke__O() } else { linked_4039.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4038) }; if /*line :598:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :610:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :610:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_4055 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_4056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4055, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4057 lang.IFn; if


	linked_4056 == nil { ifn_4057 = lang.IFn_Cast(root_4055) } else { ifn_4057 = nil }; var arg_4058 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); if linked_4056 == nil { tmp1 = ifn_4057.Invoke_O__O(arg_4058) } else { tmp1 = linked_4056.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4055, arg_4058) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_4059 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_4060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4059, A_arbace_go_check_std_session_A_fn_class); var ifn_4061 lang.IFn
		if linked_4060 == nil { ifn_4061 = lang.IFn_Cast(root_4059) } else { ifn_4061 = nil }; var arg_4062 any; var root_4063 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_4064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4063, A_arbace_go_check_corpus_config_A_fn_class); var ifn_4065 lang.IFn; if linked_4064 == nil { ifn_4065 = lang.IFn_Cast(root_4063) } else { ifn_4065 = nil }; var arg_4066 any = corpus__0; if linked_4064 == nil { arg_4062 = ifn_4065.Invoke_O__O(arg_4066) } else { arg_4062 = linked_4064.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_4063, arg_4066) }; if linked_4060 == nil { s__3 = ifn_4061.Invoke_O__O(arg_4062) } else { s__3 = linked_4060.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_4059, arg_4062) }
		var root_4067 any = A_arbace_go_check_A_const_286.GetRawRoot__O(); var linked_4068 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4067, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4069 lang.IFn; if linked_4068 == nil { ifn_4069 = lang.IFn_Cast(root_4067) } else { ifn_4069 = nil }; var arg_4070 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); var arg_4071 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var arg_4072 any = corpus__0; var arg_4073 any = s__3; if linked_4068 == nil { ifn_4069.Invoke_O_O_O_O__O(arg_4070, arg_4071, arg_4072, arg_4073) } else { linked_4068.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4067, arg_4070, arg_4071, arg_4072, arg_4073) }
//line :613:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :618:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_4074 any = A_arbace_go_check_A_const_357.GetRawRoot__O(); var linked_4075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4074, A_arbace_go_check_std_A_fn_class); var ifn_4076 lang.IFn; if




	linked_4075 == nil { ifn_4076 = lang.IFn_Cast(root_4074) } else { ifn_4076 = nil }; var arg_4077 any = corpus__1; if linked_4075 == nil { s__4 = ifn_4076.Invoke_O__O(arg_4077) } else { s__4 = linked_4075.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_4074, arg_4077) }; var src__5 any; var root_4078 any = /*line :618:1*/A_arbace_go_check_A_const_358.GetRawRoot__O(); var linked_4079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4078, A_arbace_go_check_forms_source_A_fn_class); var ifn_4080 lang.IFn; if





	linked_4079 == nil { ifn_4080 = lang.IFn_Cast(root_4078) } else { ifn_4080 = nil }; var arg_4081 any = forms__0; var arg_4082 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_112; var tmp2 any; var root_4083 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_4084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4083, A_arbace_go_check_corpus_config_A_fn_class); var ifn_4085 lang.IFn; if linked_4084 == nil { ifn_4085 = lang.IFn_Cast(root_4083) } else { ifn_4085 = nil }; var arg_4086 any = corpus__1; if linked_4084 == nil { tmp2 = ifn_4085.Invoke_O__O(arg_4086) } else { tmp2 = linked_4084.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_4083, arg_4086) }; arg_4082 = tmp1.Invoke_O__O(tmp2); if linked_4079 == nil { src__5 = ifn_4080.Invoke_O_O__O(arg_4081, arg_4082) } else { src__5 = linked_4079.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_4078, arg_4081, arg_4082) }; var pkg__6 any; var tmp3 lang.IFn = /*line :618:1*/lang.IFn_Cast(A_arbace_go_check_A_const_279.GetRawRoot__O()); var tmp4 any; var root_4094 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_4095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4094, A_arbace_go_check_resolver_A_fn_class); var ifn_4096 lang.IFn; if






	linked_4095 == nil { ifn_4096 = lang.IFn_Cast(root_4094) } else { ifn_4096 = nil }; var arg_4097 any = s__4; var arg_4098 any = src__5; var arg_4099 any = lang.PersistentVector_EMPTY.Ref(); if linked_4095 == nil { tmp4 = ifn_4096.Invoke_O_O_O__O(arg_4097, arg_4098, arg_4099) } else { tmp4 = linked_4095.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_4094, arg_4097, arg_4098, arg_4099) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_109; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_109.Invoke_O__O(opts__2)); var root_4100 any =
	A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_4101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4100, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_4102 lang.IFn; if linked_4101 == nil { ifn_4102 = lang.IFn_Cast(root_4100) } else { ifn_4102 = nil }; var arg_4103 any = pkg__6; var arg_4104 any = A_arbace_go_check_A_const_239; if linked_4101 == nil { return ifn_4102.Invoke_O_O__O(arg_4103, arg_4104) } else { return linked_4101.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_4100, arg_4103, arg_4104) } }
//line :618:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_4105 any = A_arbace_go_check_A_const_359.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4105, A_arbace_go_check_check_forms_A_fn_class); var ifn_4107 lang.IFn; if linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any = forms__0; var arg_4109 any = Lit_54; var arg_4110 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4106 == nil { return ifn_4107.Invoke_O_O_O__O(arg_4108, arg_4109, arg_4110) } else { return linked_4106.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_4105, arg_4108, arg_4109, arg_4110)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :634:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :634:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_364.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_360.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_4129 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_4130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4129, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4131 lang.IFn; if linked_4130 == nil { ifn_4131 = lang.IFn_Cast(root_4129) } else { ifn_4131 = nil }; var arg_4132 any = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_363, s__1927001093__auto____3); if linked_4130 == nil { ifn_4131.Invoke_O__O(arg_4132) } else { linked_4130.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4129, arg_4132) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__4128 any = A_arbace_go_check_write_edn_fn__1686000483_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__4127 *jrt.Class = A_arbace_go_check_write_edn_fn__1686000483_A_fn_class; if fncls__4127 == nil { var fncls__4127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__4128); A_arbace_go_check_write_edn_fn__1686000483_A_fn_class = fncls__4127d; tmp4 = fncls__4127d } else { tmp4 = fncls__4127 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4128, tmp4, nil); tmp2 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :636:1
func A_arbace_go_check_write_edn_fn__1686000483_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1686000483_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1686000483_A{}; t.Ctor_O_O(p0, p1); return t }
//line :636:1
func (t *A_arbace_go_check_write_edn_fn__1686000483_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :636:1
func (t *A_arbace_go_check_write_edn_fn__1686000483_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4123 any = A_arbace_go_check_A_const_362.GetRawRoot__O(); var linked_4124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4123, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_4125 lang.IFn; if linked_4124 == nil { ifn_4125 = lang.IFn_Cast(root_4123) } else { ifn_4125 = nil }; var arg_4126 any; var t_ any = t.F_x; t.F_x = nil; arg_4126 = t_; if linked_4124 == nil { ifn_4125.Invoke_O__O(arg_4126) } else { linked_4124.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_4123, arg_4126) }; var root_4116 any = A_arbace_go_check_A_const_361.GetRawRoot__O(); var linked_4117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4116, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4118 lang.IFn; if linked_4117 == nil { ifn_4118 = lang.IFn_Cast(root_4116) } else { ifn_4118 = nil }; var arg_4119 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_4119 = t__2; if linked_4117 == nil { tmp1 = ifn_4118.Invoke_O__O(arg_4119) } else { tmp1 = linked_4117.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4116, arg_4119) } }; return nil }(); var root_4120 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_4121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4120, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4122 lang.IFn; if linked_4121 == nil { ifn_4122 = lang.IFn_Cast(root_4120) } else { ifn_4122 = nil }; if linked_4121 == nil { ifn_4122.Invoke__O() } else { linked_4121.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4120) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }






func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :643:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :643:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any {
	if jrt.J2g_Truth(A_arbace_go_check_A_const_365.Get__O()) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_365.Get__O(), nil, corpus__0, nil)).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil, Lit_129), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil, corpus__0, nil)).Ref()
		} }
func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :648:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :648:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1686000487__1 any) any { var map__1686000488__3 any = p__1686000487__1; var map__1686000488__4 any; if lang.ISeq_InstanceOf(map__1686000488__3) { var tmp1 any; var root_4142 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4142, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4144 lang.IFn; if linked_4143 == nil { ifn_4144 = lang.IFn_Cast(root_4142) } else { ifn_4144 = nil }; var arg_4145 any = map__1686000488__3; if linked_4143 == nil { tmp1 = ifn_4144.Invoke_O__O(arg_4145) } else { tmp1 = linked_4143.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4142, arg_4145) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_4146 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_4147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4146, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4148 lang.IFn; if linked_4147 == nil { ifn_4148 = lang.IFn_Cast(root_4146) } else { ifn_4148 = nil }; var arg_4149 any = map__1686000488__3; if linked_4147 == nil { tmp2 = ifn_4148.Invoke_O__O(arg_4149) } else { tmp2 = linked_4147.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4146, arg_4149) }; map__1686000488__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_4150 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4152 lang.IFn; if linked_4151 == nil { ifn_4152 = lang.IFn_Cast(root_4150) } else { ifn_4152 = nil }; var arg_4153 any = map__1686000488__3; if linked_4151 == nil { tmp3 = ifn_4152.Invoke_O__O(arg_4153) } else { tmp3 = linked_4151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4150, arg_4153) }; if jrt.J2g_Truth(tmp3) { var root_4154 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4154, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4156 lang.IFn; if linked_4155 == nil { ifn_4156 = lang.IFn_Cast(root_4154) } else { ifn_4156 = nil }; var arg_4157 any = map__1686000488__3; if linked_4155 == nil { map__1686000488__4 = ifn_4156.Invoke_O__O(arg_4157) } else { map__1686000488__4 = linked_4155.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4154, arg_4157) } } else { map__1686000488__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1686000488__4 = map__1686000488__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1686000488__4, A_arbace_go_check_A_const_366); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1686000488__4, A_arbace_go_check_A_const_367); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1686000488__4, A_arbace_go_check_A_const_368); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_4158 any = A_arbace_go_check_A_const_369.GetRawRoot__O(); var linked_4159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4158, A_arbace_go_check_check_corpus_A_fn_class); var ifn_4160 lang.IFn; if






	linked_4159 == nil { ifn_4160 = lang.IFn_Cast(root_4158) } else { ifn_4160 = nil }; var arg_4161 any = corpus__0; var arg_4162 any = jobs__5; if linked_4159 == nil { rs__9 = ifn_4160.Invoke_O_O__O(arg_4161, arg_4162) } else { rs__9 = linked_4159.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_4158, arg_4161, arg_4162) }; var sm__10 any; var root_4163 any = /*line :648:1*/A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4163, A_arbace_go_check_summarize_A_fn_class); var ifn_4165 lang.IFn; if







	linked_4164 == nil { ifn_4165 = lang.IFn_Cast(root_4163) } else { ifn_4165 = nil }; var arg_4166 any = corpus__0; var arg_4167 any = rs__9; if linked_4164 == nil { sm__10 = ifn_4165.Invoke_O_O__O(arg_4166, arg_4167) } else { sm__10 = linked_4164.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_4163, arg_4166, arg_4167) }; var secs__11 float64 = /*line :648:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_371; var tmp5 any; var root_4168 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4168, A_arbace_go_check_reference_path_A_fn_class); var ifn_4170 lang.IFn; if









	linked_4169 == nil { ifn_4170 = lang.IFn_Cast(root_4168) } else { ifn_4170 = nil }; var arg_4171 any = corpus__0; if linked_4169 == nil { tmp5 = ifn_4170.Invoke_O__O(arg_4171) } else { tmp5 = linked_4169.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4168, arg_4171) }; ref_file__12 = /*line :648:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.File_Cast(ref_file__12).IsFile__Z() { var r__13 any; var root_4172 any = A_arbace_go_check_A_const_373.GetRawRoot__O(); var linked_4173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4172, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_4174 lang.IFn
		if linked_4173 == nil { ifn_4174 = lang.IFn_Cast(root_4172) } else { ifn_4174 = nil }; var arg_4175 any = lang.IFn_Cast(A_arbace_go_check_A_const_374.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_4173 == nil { r__13 = ifn_4174.Invoke_O__O(arg_4175) } else { r__13 = linked_4173.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_4172, arg_4175) }; if jrt.J2g_Truth(A_arbace_go_check_A_const_365.Get__O()) { var root_4180 any = A_arbace_go_check_A_const_259.GetRawRoot__O(); var linked_4181 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4180, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4182 lang.IFn; if linked_4181 == nil { ifn_4182 = lang.IFn_Cast(root_4180) } else { ifn_4182 = nil }; var arg_4183 any = A_arbace_go_check_A_const_375.Invoke_O__O(r__13); var arg_4184 any = A_arbace_go_check_A_const_339; if linked_4181 == nil { ref__13 = ifn_4182.Invoke_O_O__O(arg_4183, arg_4184) } else { ref__13 = linked_4181.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4180, arg_4183, arg_4184) } } else { ref__13 = r__13 } } else {
//line :659:1
			ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_4185 any = /*line :648:1*/A_arbace_go_check_A_const_240.Invoke_O__O(sm__10); if












	jrt.Long_InstanceOf(na_4185) { var n0_4186 int64 = jrt.NN(jrt.Long_Cast(na_4185)).LongValue__J(); and__1927000168__auto____14 = n0_4186 == 0 } else { if jrt.Double_InstanceOf(na_4185) { var n0_4186_2 float64 = jrt.NN(jrt.Double_Cast(na_4185)).DoubleValue__D(); and__1927000168__auto____14 = n0_4186_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_4185) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_4187 any = A_arbace_go_check_A_const_337.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_4187) { var n0_4188 int64 = jrt.NN(jrt.Long_Cast(na_4187)).LongValue__J(); and__1927000168__auto____15 = n0_4188 == 0 } else { if jrt.Double_InstanceOf(na_4187) { var n0_4188_2 float64 = jrt.NN(jrt.Double_Cast(na_4187)).DoubleValue__D(); and__1927000168__auto____15 = n0_4188_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_4187) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_4189 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_4190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4189, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4191 lang.IFn; if linked_4190 == nil { ifn_4191 = lang.IFn_Cast(root_4189) } else { ifn_4191 = nil }; var arg_4192 any; var root_4193 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4193, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4195 lang.IFn; if linked_4194 == nil { ifn_4195 = lang.IFn_Cast(root_4193) } else { ifn_4195 = nil }; var arg_4196 any = sm__10; var arg_4197 any = A_arbace_go_check_A_const_376; if linked_4194 == nil { arg_4192 = ifn_4195.Invoke_O_O__O(arg_4196, arg_4197) } else { arg_4192 = linked_4194.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4193, arg_4196, arg_4197) }; if linked_4190 == nil { and__1927000168__auto____16 = ifn_4191.Invoke_O__O(arg_4192) } else { and__1927000168__auto____16 = linked_4190.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4189, arg_4192) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_4198 any; var root_4199 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4199, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4201 lang.IFn
		if linked_4200 == nil { ifn_4201 = lang.IFn_Cast(root_4199) } else { ifn_4201 = nil }; var arg_4202 any = sm__10; var arg_4203 any = A_arbace_go_check_A_const_377; if linked_4200 == nil { na_4198 = ifn_4201.Invoke_O_O__O(arg_4202, arg_4203) } else { na_4198 = linked_4200.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4199, arg_4202, arg_4203) }; if jrt.Long_InstanceOf(na_4198) { var n0_4204 int64 = jrt.NN(jrt.Long_Cast(na_4198)).LongValue__J(); and__1927000168__auto____17 = n0_4204 == 0 } else { if jrt.Double_InstanceOf(na_4198) { var n0_4204_2 float64 = jrt.NN(jrt.Double_Cast(na_4198)).DoubleValue__D(); and__1927000168__auto____17 = n0_4204_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_4198) } }
//line :661:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_4205 any; var root_4206 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4206, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4208 lang.IFn; if linked_4207 == nil { ifn_4208 = lang.IFn_Cast(root_4206) } else { ifn_4208 = nil }; var arg_4209 any = sm__10; var arg_4210 any = A_arbace_go_check_A_const_378; if linked_4207 == nil { na_4205 = ifn_4208.Invoke_O_O__O(arg_4209, arg_4210) } else { na_4205 = linked_4207.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4206, arg_4209, arg_4210) }; if jrt.Long_InstanceOf(na_4205) { var n0_4211 int64 = jrt.NN(jrt.Long_Cast(na_4205)).LongValue__J(); tmp6 = n0_4211 == 0 } else { if jrt.Double_InstanceOf(na_4205) { var n0_4211_2 float64 = jrt.NN(jrt.Double_Cast(na_4205)).DoubleValue__D(); tmp6 = n0_4211_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_4205) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :661:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_4212 any = /*line :648:1*/A_arbace_go_check_A_const_259.GetRawRoot__O(); var linked_4213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4212, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4214 lang.IFn; if















	linked_4213 == nil { ifn_4214 = lang.IFn_Cast(root_4212) } else { ifn_4214 = nil }; var arg_4215 any = ref__13; var arg_4216 any = A_arbace_go_check_A_const_379; if linked_4213 == nil { tmp7 = ifn_4214.Invoke_O_O__O(arg_4215, arg_4216) } else { tmp7 = linked_4213.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4212, arg_4215, arg_4216) }; var tmp8 any = tmp7; var tmp9 any; var root_4217 any = A_arbace_go_check_A_const_259.GetRawRoot__O(); var linked_4218 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4217, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4219 lang.IFn; if linked_4218 == nil { ifn_4219 = lang.IFn_Cast(root_4217) } else { ifn_4219 = nil }; var arg_4220 any = sm__10; var arg_4221 any = A_arbace_go_check_A_const_339; if linked_4218 == nil { tmp9 = ifn_4219.Invoke_O_O__O(arg_4220, arg_4221) } else { tmp9 = linked_4218.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4217, arg_4220, arg_4221) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_4230 any =
	A_arbace_go_check_A_const_380.GetRawRoot__O(); var linked_4231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4230, A_arbace_go_check_write_edn_A_fn_class); var ifn_4232 lang.IFn; if linked_4231 == nil { ifn_4232 = lang.IFn_Cast(root_4230) } else { ifn_4232 = nil }; var arg_4233 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_4234 any; var tmp10 any = A_arbace_go_check_A_const_375; var tmp11 any = A_arbace_go_check_A_const_381; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_240; var tmp14 any; var root_4235 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_4236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4235, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4237 lang.IFn; if

	linked_4236 == nil { ifn_4237 = lang.IFn_Cast(root_4235) } else { ifn_4237 = nil }; var arg_4238 any; var root_4239 any = A_arbace_go_check_A_const_382.GetRawRoot__O(); var linked_4240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4239, A_arbace_go_check_report_errors_A_fn_class); var ifn_4241 lang.IFn; if linked_4240 == nil { ifn_4241 = lang.IFn_Cast(root_4239) } else { ifn_4241 = nil }; var arg_4242 any = rs__9; if linked_4240 == nil { arg_4238 = ifn_4241.Invoke_O__O(arg_4242) } else { arg_4238 = linked_4240.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4239, arg_4242) }; if linked_4236 == nil { tmp14 = ifn_4237.Invoke_O__O(arg_4238) } else { tmp14 = linked_4236.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4235, arg_4238) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_168; var tmp17 any; var root_4243 any = /*line :665:1*/A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_4244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4243, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4245 lang.IFn; if


	linked_4244 == nil { ifn_4245 = lang.IFn_Cast(root_4243) } else { ifn_4245 = nil }; var arg_4246 any; var iter__1927001039__auto____16 any; var fnbody__4337 any = A_arbace_go_check_annotations_iter__1686000490__1686000496_A_New(); var tmp18 *jrt.Class; var fncls__4336 *jrt.Class = A_arbace_go_check_annotations_iter__1686000490__1686000496_A_fn_class; if fncls__4336 == nil { var fncls__4336d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_go_check_annotations_iter__1686000490__1686000496_A_fn_class = fncls__4336d; tmp18 = fncls__4336d } else { tmp18 = fncls__4336 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4337, tmp18, nil); arg_4246 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_4244 == nil { tmp17 = ifn_4245.Invoke_O__O(arg_4246) } else { tmp17 = linked_4244.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4243, arg_4246) }; arg_4234 = /*line :665:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_4231 == nil { ifn_4232.Invoke_O_O__O(arg_4233, arg_4234) } else { linked_4231.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4230, arg_4233, arg_4234) }; var tmp19 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_237.GetRawRoot__O()); var tmp21 any = A_arbace_go_check_A_const_333.Invoke_O__O(sm__10); var tmp22 any; var root_4356 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4356, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4358 lang.IFn; if
	linked_4357 == nil { ifn_4358 = lang.IFn_Cast(root_4356) } else { ifn_4358 = nil }; var arg_4359 any = sm__10; var arg_4360 any = A_arbace_go_check_A_const_384; if linked_4357 == nil { tmp22 = ifn_4358.Invoke_O_O__O(arg_4359, arg_4360) } else { tmp22 = linked_4357.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4356, arg_4359, arg_4360) }; var tmp23 any = tmp22; var tmp24 any; var root_4361 any = /*line :669:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4361, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4363 lang.IFn; if
	linked_4362 == nil { ifn_4363 = lang.IFn_Cast(root_4361) } else { ifn_4363 = nil }; var arg_4364 any = sm__10; var arg_4365 any = A_arbace_go_check_A_const_385; if linked_4362 == nil { tmp24 = ifn_4363.Invoke_O_O__O(arg_4364, arg_4365) } else { tmp24 = linked_4362.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4361, arg_4364, arg_4365) }; var tmp25 any = tmp24; var tmp26 any; var root_4366 any = /*line :669:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4366, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4368 lang.IFn; if

	linked_4367 == nil { ifn_4368 = lang.IFn_Cast(root_4366) } else { ifn_4368 = nil }; var arg_4369 any = sm__10; var arg_4370 any = A_arbace_go_check_A_const_386; if linked_4367 == nil { tmp26 = ifn_4368.Invoke_O_O__O(arg_4369, arg_4370) } else { tmp26 = linked_4367.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4366, arg_4369, arg_4370) }; var tmp27 any = tmp26; var tmp28 any = /*line :669:1*/A_arbace_go_check_A_const_240.Invoke_O__O(sm__10); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()); var tmp30 any; var root_4375 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4375, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4377 lang.IFn; if


	linked_4376 == nil { ifn_4377 = lang.IFn_Cast(root_4375) } else { ifn_4377 = nil }; var arg_4378 any = sm__10; var arg_4379 any = A_arbace_go_check_A_const_387; if linked_4376 == nil { tmp30 = ifn_4377.Invoke_O_O__O(arg_4378, arg_4379) } else { tmp30 = linked_4376.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4375, arg_4378, arg_4379) }; var tmp31 any = /*line :669:1*/tmp29.Invoke_O__O(tmp30); var tmp32 any; var root_4380 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4380, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4382 lang.IFn; if



	linked_4381 == nil { ifn_4382 = lang.IFn_Cast(root_4380) } else { ifn_4382 = nil }; var arg_4383 any = sm__10; var arg_4384 any = A_arbace_go_check_A_const_388; if linked_4381 == nil { tmp32 = ifn_4382.Invoke_O_O__O(arg_4383, arg_4384) } else { tmp32 = linked_4381.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4380, arg_4383, arg_4384) }; var tmp33 any = tmp32; var tmp34 any; var root_4385 any = /*line :669:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4385, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4387 lang.IFn; if



	linked_4386 == nil { ifn_4387 = lang.IFn_Cast(root_4385) } else { ifn_4387 = nil }; var arg_4388 any = sm__10; var arg_4389 any = A_arbace_go_check_A_const_389; if linked_4386 == nil { tmp34 = ifn_4387.Invoke_O_O__O(arg_4388, arg_4389) } else { tmp34 = linked_4386.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4385, arg_4388, arg_4389) }; /*line :669:1*/tmp19.Invoke_O__O(tmp20.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_17, corpus__0, tmp21, tmp23, tmp25, tmp27, tmp28, tmp31, tmp33, tmp34, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1686000506__16 any; var root_4390 any = /*line :648:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4390, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4392 lang.IFn; if

























	linked_4391 == nil { ifn_4392 = lang.IFn_Cast(root_4390) } else { ifn_4392 = nil }; var arg_4393 any; var root_4394 any = A_arbace_go_check_A_const_390.GetRawRoot__O(); var linked_4395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4394, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4396 lang.IFn; if linked_4395 == nil { ifn_4396 = lang.IFn_Cast(root_4394) } else { ifn_4396 = nil }; var arg_4397 any = A_arbace_go_check_A_const_391; var arg_4398 any; var root_4399 any = A_arbace_go_check_A_const_382.GetRawRoot__O(); var linked_4400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4399, A_arbace_go_check_report_errors_A_fn_class); var ifn_4401 lang.IFn; if linked_4400 == nil { ifn_4401 = lang.IFn_Cast(root_4399) } else { ifn_4401 = nil }; var arg_4402 any = rs__9; if linked_4400 == nil { arg_4398 = ifn_4401.Invoke_O__O(arg_4402) } else { arg_4398 = linked_4400.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4399, arg_4402) }; if linked_4395 == nil { arg_4393 = ifn_4396.Invoke_O_O__O(arg_4397, arg_4398) } else { arg_4393 = linked_4395.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4394, arg_4397, arg_4398) }; if linked_4391 == nil { seq_1686000506__16 = ifn_4392.Invoke_O__O(arg_4393) } else { seq_1686000506__16 = linked_4391.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4390, arg_4393) }; var chunk_1686000507__17 any; var count_1686000508__18 int64 = 0; var i_1686000509__19 int64 = 0; L1:
//line :648:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1686000509__19, count_1686000508__18) { var l__20 any = lang.Indexed_Cast(chunk_1686000507__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1686000509__19)); lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__20); seq_1686000506__16, chunk_1686000507__17, count_1686000508__18, i_1686000509__19 = seq_1686000506__16, chunk_1686000507__17, count_1686000508__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1686000509__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_4403 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4405 lang.IFn; if linked_4404 == nil { ifn_4405 = lang.IFn_Cast(root_4403) } else { ifn_4405 = nil }; var arg_4406 any = seq_1686000506__16; if linked_4404 == nil { temp__1927000414__auto____20 = ifn_4405.Invoke_O__O(arg_4406) } else { temp__1927000414__auto____20 = linked_4404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4403, arg_4406) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1686000506__21 any = temp__1927000414__auto____20; var tmp35 any; var root_4407 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4407, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4409 lang.IFn; if linked_4408 == nil { ifn_4409 = lang.IFn_Cast(root_4407) } else { ifn_4409 = nil }; var arg_4410 any = seq_1686000506__21; if linked_4408 == nil { tmp35 = ifn_4409.Invoke_O__O(arg_4410) } else { tmp35 = linked_4408.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4407, arg_4410) }; if jrt.J2g_Truth(tmp35) { var c__1927000678__auto____22 any; var root_4411 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4411, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4413 lang.IFn; if linked_4412 == nil { ifn_4413 = lang.IFn_Cast(root_4411) } else { ifn_4413 = nil }; var arg_4414 any = seq_1686000506__21; if linked_4412 == nil { c__1927000678__auto____22 = ifn_4413.Invoke_O__O(arg_4414) } else { c__1927000678__auto____22 = linked_4412.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4411, arg_4414) }; var tmp36 any; var root_4460 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4460, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4462 lang.IFn; if linked_4461 == nil { ifn_4462 = lang.IFn_Cast(root_4460) } else { ifn_4462 = nil }; var arg_4463 any = seq_1686000506__21; if linked_4461 == nil { tmp36 = ifn_4462.Invoke_O__O(arg_4463) } else { tmp36 = linked_4461.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4460, arg_4463) }; seq_1686000506__16, chunk_1686000507__17, count_1686000508__18, i_1686000509__19 = tmp36, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_4415 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4415, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4417 lang.IFn; if linked_4416 == nil { ifn_4417 = lang.IFn_Cast(root_4415) } else { ifn_4417 = nil }; var arg_4418 any = seq_1686000506__21; if linked_4416 == nil { l__22 = ifn_4417.Invoke_O__O(arg_4418) } else { l__22 = linked_4416.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4415, arg_4418) }; lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__22); var tmp37 any; var root_4469 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4469, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4471 lang.IFn; if linked_4470 == nil { ifn_4471 = lang.IFn_Cast(root_4469) } else { ifn_4471 = nil }; var arg_4472 any = seq_1686000506__21; if linked_4470 == nil { tmp37 = ifn_4471.Invoke_O__O(arg_4472) } else { tmp37 = linked_4470.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4469, arg_4472) }; seq_1686000506__16, chunk_1686000507__17, count_1686000508__18, i_1686000509__19 = tmp37, nil, 0, 0; continue L1 } } }
//line :648:1
		break L1 }; var tmp38 any; var root_4419 any =


























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4421 lang.IFn; if linked_4420 == nil { ifn_4421 = lang.IFn_Cast(root_4419) } else { ifn_4421 = nil }; var arg_4422 any; var root_4423 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4423, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4425 lang.IFn; if linked_4424 == nil { ifn_4425 = lang.IFn_Cast(root_4423) } else { ifn_4425 = nil }; var arg_4426 any = sm__10; var arg_4427 any = A_arbace_go_check_A_const_392; if linked_4424 == nil { arg_4422 = ifn_4425.Invoke_O_O__O(arg_4426, arg_4427) } else { arg_4422 = linked_4424.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4423, arg_4426, arg_4427) }; if linked_4420 == nil { tmp38 = ifn_4421.Invoke_O__O(arg_4422) } else { tmp38 = linked_4420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4419, arg_4422) }; if jrt.J2g_Truth(tmp38) {
		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()); var tmp41 any; var root_4437 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4437, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4439 lang.IFn; if linked_4438 == nil { ifn_4439 = lang.IFn_Cast(root_4437) } else { ifn_4439 = nil }; var arg_4440 any = sm__10; var arg_4441 any = A_arbace_go_check_A_const_393; if linked_4438 == nil { tmp41 = ifn_4439.Invoke_O_O__O(arg_4440, arg_4441) } else { tmp41 = linked_4438.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4437, arg_4440, arg_4441) }; tmp39.Invoke_O_O__O(Lit_19, tmp40.Invoke_O__O(tmp41)) }; var tmp42 any; var root_4442 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4442, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4444 lang.IFn; if linked_4443 == nil { ifn_4444 = lang.IFn_Cast(root_4442) } else { ifn_4444 = nil }; var arg_4445 any = A_arbace_go_check_A_const_147.Invoke_O__O(sm__10); if linked_4443 == nil { tmp42 = ifn_4444.Invoke_O__O(arg_4445) } else { tmp42 = linked_4443.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4442, arg_4445) }; if jrt.J2g_Truth(tmp42) {
		lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()).Invoke_O_O__O(Lit_20, lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_147.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_4473 any = A_arbace_go_check_A_const_380.GetRawRoot__O(); var linked_4474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4473, A_arbace_go_check_write_edn_A_fn_class); var ifn_4475 lang.IFn; if linked_4474 == nil { ifn_4475 = lang.IFn_Cast(root_4473) } else { ifn_4475 = nil }; var arg_4476 any; var root_4478 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4478, A_arbace_go_check_reference_path_A_fn_class); var ifn_4480 lang.IFn; if linked_4479 == nil { ifn_4480 = lang.IFn_Cast(root_4478) } else { ifn_4480 = nil }; var arg_4481 any = corpus__0; if linked_4479 == nil { arg_4476 = ifn_4480.Invoke_O__O(arg_4481) } else { arg_4476 = linked_4479.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4478, arg_4481) }; var arg_4477 any; var root_4482 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4483 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4482, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4484 lang.IFn; if linked_4483 == nil { ifn_4484 = lang.IFn_Cast(root_4482) } else { ifn_4484 = nil }; var arg_4485 any; var root_4488 any = A_arbace_go_check_A_const_259.GetRawRoot__O(); var linked_4489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4488, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4490 lang.IFn; if linked_4489 == nil { ifn_4490 = lang.IFn_Cast(root_4488) } else { ifn_4490 = nil }; var arg_4491 any = sm__10; var arg_4492 any = A_arbace_go_check_A_const_339; if linked_4489 == nil { arg_4485 = ifn_4490.Invoke_O_O__O(arg_4491, arg_4492) } else { arg_4485 = linked_4489.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4488, arg_4491, arg_4492) }; var arg_4486 any = A_arbace_go_check_A_const_379; var arg_4487 any = Lit_21; if linked_4483 == nil { arg_4477 = ifn_4484.Invoke_O_O_O__O(arg_4485, arg_4486, arg_4487) } else { arg_4477 = linked_4483.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4482, arg_4485, arg_4486, arg_4487) }; if linked_4474 == nil { ifn_4475.Invoke_O_O__O(arg_4476, arg_4477) } else { linked_4474.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4473, arg_4476, arg_4477) }
		var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp44 any; var root_4498 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4498, A_arbace_go_check_reference_path_A_fn_class); var ifn_4500 lang.IFn; if linked_4499 == nil { ifn_4500 = lang.IFn_Cast(root_4498) } else { ifn_4500 = nil }; var arg_4501 any = corpus__0; if linked_4499 == nil { tmp44 = ifn_4500.Invoke_O__O(arg_4501) } else { tmp44 = linked_4499.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4498, arg_4501) }; tmp43.Invoke_O_O__O(Lit_22, tmp44)
//line :679:1
		return clean__14 } else { var tmp45 any; var root_4222 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4222, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4224 lang.IFn



			if linked_4223 == nil { ifn_4224 = lang.IFn_Cast(root_4222) } else { ifn_4224 = nil }; var arg_4225 any = clean__14; if linked_4223 == nil { tmp45 = ifn_4224.Invoke_O__O(arg_4225) } else { tmp45 = linked_4223.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4222, arg_4225) }
//line :679:1
			if jrt.J2g_Truth(tmp45) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp47 any; var root_4508 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4508, A_arbace_go_check_reference_path_A_fn_class); var ifn_4510 lang.IFn; if linked_4509 == nil { ifn_4510 = lang.IFn_Cast(root_4508) } else { ifn_4510 = nil }; var arg_4511 any = corpus__0; if linked_4509 == nil { tmp47 = ifn_4510.Invoke_O__O(arg_4511) } else { tmp47 = linked_4509.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4508, arg_4511) }; tmp46.Invoke_O_O_O__O(Lit_23, tmp47, Lit_24)
//line :679:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp48 any; var root_4226 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4226, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4228 lang.IFn





					if linked_4227 == nil { ifn_4228 = lang.IFn_Cast(root_4226) } else { ifn_4228 = nil }; var arg_4229 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_4227 == nil { tmp48 = ifn_4228.Invoke_O__O(arg_4229) } else { tmp48 = linked_4227.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4226, arg_4229) }
//line :679:1
					if jrt.J2g_Truth(tmp48) {





						var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp50 any; var root_4518 any = A_arbace_go_check_A_const_372.GetRawRoot__O(); var linked_4519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4518, A_arbace_go_check_reference_path_A_fn_class); var ifn_4520 lang.IFn; if linked_4519 == nil { ifn_4520 = lang.IFn_Cast(root_4518) } else { ifn_4520 = nil }; var arg_4521 any = corpus__0; if linked_4519 == nil { tmp50 = ifn_4520.Invoke_O__O(arg_4521) } else { tmp50 = linked_4519.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4518, arg_4521) }; tmp49.Invoke_O_O_O__O(Lit_25, tmp50, Lit_26)
						var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()); var tmp53 any; var root_4531 any = A_arbace_go_check_A_const_259.GetRawRoot__O(); var linked_4532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4531, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4533 lang.IFn; if linked_4532 == nil { ifn_4533 = lang.IFn_Cast(root_4531) } else { ifn_4533 = nil }; var arg_4534 any = ref__13; var arg_4535 any = A_arbace_go_check_A_const_379; if linked_4532 == nil { tmp53 = ifn_4533.Invoke_O_O__O(arg_4534, arg_4535) } else { tmp53 = linked_4532.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4531, arg_4534, arg_4535) }; tmp51.Invoke_O_O__O(Lit_27, tmp52.Invoke_O__O(tmp53))
						var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()); var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_238.GetRawRoot__O()); var tmp56 any; var root_4545 any = A_arbace_go_check_A_const_259.GetRawRoot__O(); var linked_4546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4545, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4547 lang.IFn; if linked_4546 == nil { ifn_4547 = lang.IFn_Cast(root_4545) } else { ifn_4547 = nil }; var arg_4548 any = sm__10; var arg_4549 any = A_arbace_go_check_A_const_339; if linked_4546 == nil { tmp56 = ifn_4547.Invoke_O_O__O(arg_4548, arg_4549) } else { tmp56 = linked_4546.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4545, arg_4548, arg_4549) }; tmp54.Invoke_O_O__O(Lit_28, tmp55.Invoke_O__O(tmp56))
//line :679:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :668:1
func A_arbace_go_check_annotations_iter__1686000490__1686000496_A_New() *A_arbace_go_check_annotations_iter__1686000490__1686000496_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1686000490__1686000496_A{}; t.Ctor(); return t }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_A) Ctor() {}
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_A) Invoke_O_O__O(self, s__1686000491__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4335 any = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A_New_O_O(s__1686000491__1, self); var tmp2 *jrt.Class; var fncls__4334 *jrt.Class = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A_fn_class; if fncls__4334 == nil { var fncls__4334d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__4335); A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A_fn_class = fncls__4334d; tmp2 = fncls__4334d } else { tmp2 = fncls__4334 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4335, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :668:1
func A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A{}; t.Ctor_O_O(p0, p1); return t }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A) Ctor_O_O(c__s__1686000491, c__iter__1686000490 any) { t.F_s__1686000491 = c__s__1686000491; t.F_iter__1686000490 = c__iter__1686000490 }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A) Invoke_O__O(self any) any { { var s__1686000491__1 any; var t_ any = t.F_s__1686000491; t.F_s__1686000491 = nil; s__1686000491__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4247 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4249 lang.IFn; if linked_4248 == nil { ifn_4249 = lang.IFn_Cast(root_4247) } else { ifn_4249 = nil }; var arg_4250 any = s__1686000491__1; if linked_4248 == nil { temp__1927000414__auto____2 = ifn_4249.Invoke_O__O(arg_4250) } else { temp__1927000414__auto____2 = linked_4248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4247, arg_4250) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_4251 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4251, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4253 lang.IFn; if linked_4252 == nil { ifn_4253 = lang.IFn_Cast(root_4251) } else { ifn_4253 = nil }; var arg_4254 any = xs__1927001018__auto____3; if linked_4252 == nil { r__4 = ifn_4253.Invoke_O__O(arg_4254) } else { r__4 = linked_4252.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4251, arg_4254) }; var iterys__1927001035__auto____5 any; var fnbody__4316 any = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A_New_O(r__4); var tmp1 *jrt.Class; var fncls__4315 *jrt.Class = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A_fn_class; if fncls__4315 == nil { var fncls__4315d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__4316); A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A_fn_class = fncls__4315d; tmp1 = fncls__4315d } else { tmp1 = fncls__4315 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4316, tmp1, nil); var fs__1927001036__auto____6 any; var root_4317 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4317, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4319 lang.IFn; if linked_4318 == nil { ifn_4319 = lang.IFn_Cast(root_4317) } else { ifn_4319 = nil }; var arg_4320 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_169.Invoke_O__O(r__4)); if linked_4318 == nil { fs__1927001036__auto____6 = ifn_4319.Invoke_O__O(arg_4320) } else { fs__1927001036__auto____6 = linked_4318.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4317, arg_4320) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_4321 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_4322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4321, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4323 lang.IFn; if linked_4322 == nil { ifn_4323 = lang.IFn_Cast(root_4321) } else { ifn_4323 = nil }; var arg_4324 any = fs__1927001036__auto____6; var arg_4325 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1686000490); var tmp3 any; var root_4326 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4326, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4328 lang.IFn; if linked_4327 == nil { ifn_4328 = lang.IFn_Cast(root_4326) } else { ifn_4328 = nil }; var arg_4329 any = s__1686000491__1; if linked_4327 == nil { tmp3 = ifn_4328.Invoke_O__O(arg_4329) } else { tmp3 = linked_4327.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4326, arg_4329) }; arg_4325 = tmp2.Invoke_O__O(tmp3); if linked_4322 == nil { return ifn_4323.Invoke_O_O__O(arg_4324, arg_4325) } else { return linked_4322.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4321, arg_4324, arg_4325) } } else { var tmp4 any; var root_4330 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4330, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4332 lang.IFn; if linked_4331 == nil { ifn_4332 = lang.IFn_Cast(root_4330) } else { ifn_4332 = nil }; var arg_4333 any = s__1686000491__1; if linked_4331 == nil { tmp4 = ifn_4332.Invoke_O__O(arg_4333) } else { tmp4 = linked_4331.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4330, arg_4333) }; s__1686000491__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :668:1
func A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A{}; t.Ctor_O(p0); return t }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A) Invoke_O_O__O(self, s__1686000493__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4314 any = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A_New_O_O_O(t.F_r, s__1686000493__1, self); var tmp2 *jrt.Class; var fncls__4313 *jrt.Class = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A_fn_class; if fncls__4313 == nil { var fncls__4313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__4314); A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A_fn_class = fncls__4313d; tmp2 = fncls__4313d } else { tmp2 = fncls__4313 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4314, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :668:1
func A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A) Ctor_O_O_O(c__r, c__s__1686000493, c__iter__1686000492 any) { t.F_r = c__r; t.F_s__1686000493 = c__s__1686000493; t.F_iter__1686000492 = c__iter__1686000492 }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A) Invoke_O__O(self any) any { { var s__1686000493__1 any; var t_ any = t.F_s__1686000493; t.F_s__1686000493 = nil; s__1686000493__1 = t_; for { var temp__1927000414__auto____2 any; var root_4255 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4257 lang.IFn; if linked_4256 == nil { ifn_4257 = lang.IFn_Cast(root_4255) } else { ifn_4257 = nil }; var arg_4258 any = s__1686000493__1; if linked_4256 == nil { temp__1927000414__auto____2 = ifn_4257.Invoke_O__O(arg_4258) } else { temp__1927000414__auto____2 = linked_4256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4255, arg_4258) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000493__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4259 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4259, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4261 lang.IFn; if linked_4260 == nil { ifn_4261 = lang.IFn_Cast(root_4259) } else { ifn_4261 = nil }; var arg_4262 any = s__1686000493__3; if linked_4260 == nil { tmp1 = ifn_4261.Invoke_O__O(arg_4262) } else { tmp1 = linked_4260.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4259, arg_4262) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4263 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4263, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4265 lang.IFn; if linked_4264 == nil { ifn_4265 = lang.IFn_Cast(root_4263) } else { ifn_4265 = nil }; var arg_4266 any = s__1686000493__3; if linked_4264 == nil { c__1927001037__auto____4 = ifn_4265.Invoke_O__O(arg_4266) } else { c__1927001037__auto____4 = linked_4264.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4263, arg_4266) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000495__6 any; var root_4267 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4267, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4269 lang.IFn; if linked_4268 == nil { ifn_4269 = lang.IFn_Cast(root_4267) } else { ifn_4269 = nil }; var arg_4270 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4268 == nil { b__1686000495__6 = ifn_4269.Invoke_O__O(arg_4270) } else { b__1686000495__6 = linked_4268.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4267, arg_4270) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4277 any = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1686000495__6); var tmp3 *jrt.Class; var fncls__4276 *jrt.Class = A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A_fn_class; if fncls__4276 == nil { var fncls__4276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__4277); A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A_fn_class = fncls__4276d; tmp3 = fncls__4276d } else { tmp3 = fncls__4276 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4277, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4278 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4278, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4280 lang.IFn; if linked_4279 == nil { ifn_4280 = lang.IFn_Cast(root_4278) } else { ifn_4280 = nil }; var arg_4281 any; var root_4283 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_4284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4283, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4285 lang.IFn; if linked_4284 == nil { ifn_4285 = lang.IFn_Cast(root_4283) } else { ifn_4285 = nil }; var arg_4286 any = b__1686000495__6; if linked_4284 == nil { arg_4281 = ifn_4285.Invoke_O__O(arg_4286) } else { arg_4281 = linked_4284.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4283, arg_4286) }; var arg_4282 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000492); var tmp5 any; var root_4287 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4287, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4289 lang.IFn; if linked_4288 == nil { ifn_4289 = lang.IFn_Cast(root_4287) } else { ifn_4289 = nil }; var arg_4290 any = s__1686000493__3; if linked_4288 == nil { tmp5 = ifn_4289.Invoke_O__O(arg_4290) } else { tmp5 = linked_4288.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4287, arg_4290) }; arg_4282 = tmp4.Invoke_O__O(tmp5); if linked_4279 == nil { return ifn_4280.Invoke_O_O__O(arg_4281, arg_4282) } else { return linked_4279.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4278, arg_4281, arg_4282) } } else { var root_4291 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4291, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4293 lang.IFn; if linked_4292 == nil { ifn_4293 = lang.IFn_Cast(root_4291) } else { ifn_4293 = nil }; var arg_4294 any; var root_4296 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_4297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4296, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4298 lang.IFn; if linked_4297 == nil { ifn_4298 = lang.IFn_Cast(root_4296) } else { ifn_4298 = nil }; var arg_4299 any = b__1686000495__6; if linked_4297 == nil { arg_4294 = ifn_4298.Invoke_O__O(arg_4299) } else { arg_4294 = linked_4297.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4296, arg_4299) }; var arg_4295 any; if linked_4292 == nil { return ifn_4293.Invoke_O_O__O(arg_4294, arg_4295) } else { return linked_4292.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4291, arg_4294, arg_4295) } } } else { var u__4 any; var root_4300 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4302 lang.IFn; if linked_4301 == nil { ifn_4302 = lang.IFn_Cast(root_4300) } else { ifn_4302 = nil }; var arg_4303 any = s__1686000493__3; if linked_4301 == nil { u__4 = ifn_4302.Invoke_O__O(arg_4303) } else { u__4 = linked_4301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4300, arg_4303) }; var root_4304 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_4305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4304, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4306 lang.IFn; if linked_4305 == nil { ifn_4306 = lang.IFn_Cast(root_4304) } else { ifn_4306 = nil }; var arg_4307 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), u__4); var arg_4308 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1686000492); var tmp7 any; var root_4309 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4309, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4311 lang.IFn; if linked_4310 == nil { ifn_4311 = lang.IFn_Cast(root_4309) } else { ifn_4311 = nil }; var arg_4312 any = s__1686000493__3; if linked_4310 == nil { tmp7 = ifn_4311.Invoke_O__O(arg_4312) } else { tmp7 = linked_4310.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4309, arg_4312) }; arg_4308 = tmp6.Invoke_O__O(tmp7); if linked_4305 == nil { return ifn_4306.Invoke_O_O__O(arg_4307, arg_4308) } else { return linked_4305.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4304, arg_4307, arg_4308) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :668:1
func A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1686000495 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1686000495 = c__b__1686000495 }
//line :668:1
func (t *A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A) Invoke_O__O(self any) any { { var i__1686000494__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000494__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000494__1)); var root_4271 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4271, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4273 lang.IFn; if linked_4272 == nil { ifn_4273 = lang.IFn_Cast(root_4271) } else { ifn_4273 = nil }; var arg_4274 any = t.F_b__1686000495; var arg_4275 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), u__2); if linked_4272 == nil { ifn_4273.Invoke_O_O__O(arg_4274, arg_4275) } else { linked_4272.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4271, arg_4274, arg_4275) }; i__1686000494__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000494__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :691:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :691:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1686000511__2 any = args__0; var seq__1686000512__3 any; var root_4550 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4550, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4552 lang.IFn; if


	linked_4551 == nil { ifn_4552 = lang.IFn_Cast(root_4550) } else { ifn_4552 = nil }; var arg_4553 any = vec__1686000511__2; if linked_4551 == nil { seq__1686000512__3 = ifn_4552.Invoke_O__O(arg_4553) } else { seq__1686000512__3 = linked_4551.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4550, arg_4553) }; var first__1686000513__4 any; var root_4554 any = /*line :691:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4554, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4556 lang.IFn; if


	linked_4555 == nil { ifn_4556 = lang.IFn_Cast(root_4554) } else { ifn_4556 = nil }; var arg_4557 any = seq__1686000512__3; if linked_4555 == nil { first__1686000513__4 = ifn_4556.Invoke_O__O(arg_4557) } else { first__1686000513__4 = linked_4555.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4554, arg_4557) }; var seq__1686000512__5 any; var root_4558 any = /*line :691:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4558, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4560 lang.IFn; if


	linked_4559 == nil { ifn_4560 = lang.IFn_Cast(root_4558) } else { ifn_4560 = nil }; var arg_4561 any = seq__1686000512__3; if linked_4559 == nil { seq__1686000512__5 = ifn_4560.Invoke_O__O(arg_4561) } else { seq__1686000512__5 = linked_4559.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4558, arg_4561) }; var cmd__6 any = first__1686000513__4; var args__7 any = seq__1686000512__5; var G__1686000514__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1686000514__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000514__8_, Lit_1) { var opts__9 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__4654 any = A_arbace_go_check__main_fn__1686000515_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4653 /*line :695:1*/*jrt.Class = A_arbace_go_check__main_fn__1686000515_A_fn_class

		if fncls__4653 == nil { var fncls__4653d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__4654); A_arbace_go_check__main_fn__1686000515_A_fn_class = fncls__4653d; tmp2 = fncls__4653d } else { tmp2 = fncls__4653 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4654, tmp2, nil); opts__9 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :695:1
		var cs__10 any; var tmp3 any; var root_4655 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4655, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4657 lang.IFn











		if linked_4656 == nil { ifn_4657 = lang.IFn_Cast(root_4655) } else { ifn_4657 = nil }; var arg_4658 any = A_arbace_go_check_A_const_395.Invoke_O__O(opts__9); if linked_4656 == nil { tmp3 = ifn_4657.Invoke_O__O(arg_4658) } else { tmp3 = linked_4656.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4655, arg_4658) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_395.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_398.GetRawRoot__O() }
//line :695:1
		var ok__11 any; var root_4745 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var linked_4746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4745, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4747 lang.IFn












		if linked_4746 == nil { ifn_4747 = lang.IFn_Cast(root_4745) } else { ifn_4747 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_172.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_287; var tmp6 any = A_arbace_go_check_A_const_166.Invoke_O__O(opts__9); var tmp7 any = A_arbace_go_check_A_const_365; var arg_4748 any = tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, A_arbace_go_check_A_const_397.Invoke_O__O(opts__9)); if linked_4746 == nil { ifn_4747.Invoke_O__O(arg_4748) } else { linked_4746.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4745, arg_4748) }; var tmp8 *lang.Compiler_AOTFn; var fnbody__4739 any = A_arbace_go_check__main_fn__1686000518_A_New_O_O(cs__10, opts__9); var tmp9 *jrt.Class; var fncls__4738 *jrt.Class = A_arbace_go_check__main_fn__1686000518_A_fn_class; if fncls__4738 == nil { var fncls__4738d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__4739); A_arbace_go_check__main_fn__1686000518_A_fn_class = fncls__4738d; tmp9 = fncls__4738d } else { tmp9 = fncls__4738 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4739, tmp9, nil); ok__11 = Up_Compiler_AOTFn_IFn(tmp8).Invoke__O()


		var root_4756 any = A_arbace_go_check_A_const_402.GetRawRoot__O(); var linked_4757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4756, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4758 lang.IFn; if linked_4757 == nil { ifn_4758 = lang.IFn_Cast(root_4756) } else { ifn_4758 = nil }; if linked_4757 == nil { ifn_4758.Invoke__O() } else { linked_4757.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4756) }
		var tmp10 int64; var tmp11 any; var root_4740 any = A_arbace_go_check_A_const_400.GetRawRoot__O(); var linked_4741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4740, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4742 lang.IFn; if linked_4741 == nil { ifn_4742 = lang.IFn_Cast(root_4740) } else { ifn_4742 = nil }; var arg_4743 any = A_arbace_go_check_A_const_401.GetRawRoot__O(); var arg_4744 any = ok__11; if linked_4741 == nil { tmp11 = ifn_4742.Invoke_O_O__O(arg_4743, arg_4744) } else { tmp11 = linked_4741.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4740, arg_4743, arg_4744) }; if jrt.J2g_Truth(tmp11) { tmp10 = 0 } else { tmp10 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp10)); return nil }
//line :695:1
	default:};

















	lang.IFn_Cast(A_arbace_go_check_A_const_383.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :697:1
func A_arbace_go_check__main_fn__1686000515_A_New_O(p0 any) *A_arbace_go_check__main_fn__1686000515_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1686000515_A{}; t.Ctor_O(p0); return t }
//line :697:1
func (t *A_arbace_go_check__main_fn__1686000515_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :697:1
func (t *A_arbace_go_check__main_fn__1686000515_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_366; var tmp2 any = A_arbace_go_check_A_const_394; var tmp3 any = A_arbace_go_check_A_const_368; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_298.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_395, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_4563 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_4564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4563, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4565 lang.IFn; if linked_4564 == nil { ifn_4565 = lang.IFn_Cast(root_4563) } else { ifn_4565 = nil }; var arg_4566 any = as__1; if linked_4564 == nil { tmp4 = ifn_4565.Invoke_O__O(arg_4566) } else { tmp4 = linked_4564.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4563, arg_4566) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1686000516__3_ any; var root_4567 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4567, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4569 lang.IFn

		if linked_4568 == nil { ifn_4569 = lang.IFn_Cast(root_4567) } else { ifn_4569 = nil }; var arg_4570 any = as__1; if linked_4568 == nil { G__1686000516__3_ = ifn_4569.Invoke_O__O(arg_4570) } else { G__1686000516__3_ = linked_4568.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4567, arg_4570) }; switch lang.Util_Hash_O__I_NoInit(G__1686000516__3_) >> 10 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000516__3_, Lit_6) {



			var tmp5 any; var root_4572 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4572, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4574 lang.IFn; if linked_4573 == nil { ifn_4574 = lang.IFn_Cast(root_4572) } else { ifn_4574 = nil }; var arg_4575 any = as__1; if linked_4573 == nil { tmp5 = ifn_4574.Invoke_O__O(arg_4575) } else { tmp5 = linked_4573.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4572, arg_4575) }; var tmp6 any = tmp5; var tmp7 any; var root_4576 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4576, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4578 lang.IFn; if linked_4577 == nil { ifn_4578 = lang.IFn_Cast(root_4576) } else { ifn_4578 = nil }; var arg_4579 any = o__2; var arg_4580 any = A_arbace_go_check_A_const_166; var arg_4581 any; var root_4582 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_4583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4582, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4584 lang.IFn; if linked_4583 == nil { ifn_4584 = lang.IFn_Cast(root_4582) } else { ifn_4584 = nil }; var arg_4585 any = as__1; if linked_4583 == nil { arg_4581 = ifn_4584.Invoke_O__O(arg_4585) } else { arg_4581 = linked_4583.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4582, arg_4585) }; if linked_4577 == nil { tmp7 = ifn_4578.Invoke_O_O_O__O(arg_4579, arg_4580, arg_4581) } else { tmp7 = linked_4577.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4576, arg_4579, arg_4580, arg_4581) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :700:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000516__3_, Lit_7) {




			var tmp8 any; var root_4586 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4586, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4588 lang.IFn; if linked_4587 == nil { ifn_4588 = lang.IFn_Cast(root_4586) } else { ifn_4588 = nil }; var arg_4589 any = as__1; if linked_4587 == nil { tmp8 = ifn_4588.Invoke_O__O(arg_4589) } else { tmp8 = linked_4587.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4586, arg_4589) }; var tmp9 any = tmp8; var tmp10 any; var root_4590 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4591 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4590, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4592 lang.IFn; if linked_4591 == nil { ifn_4592 = lang.IFn_Cast(root_4590) } else { ifn_4592 = nil }; var arg_4593 any = o__2; var arg_4594 any = A_arbace_go_check_A_const_397; var arg_4595 any; var root_4596 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_4597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4596, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4598 lang.IFn; if linked_4597 == nil { ifn_4598 = lang.IFn_Cast(root_4596) } else { ifn_4598 = nil }; var arg_4599 any = as__1; if linked_4597 == nil { arg_4595 = ifn_4598.Invoke_O__O(arg_4599) } else { arg_4595 = linked_4597.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4596, arg_4599) }; if linked_4591 == nil { tmp10 = ifn_4592.Invoke_O_O_O__O(arg_4593, arg_4594, arg_4595) } else { tmp10 = linked_4591.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4590, arg_4593, arg_4594, arg_4595) }; as__1, o__2 = tmp9, tmp10; continue L1 }
//line :700:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000516__3_, Lit_8) {

			var tmp11 any; var root_4600 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4600, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4602 lang.IFn; if linked_4601 == nil { ifn_4602 = lang.IFn_Cast(root_4600) } else { ifn_4602 = nil }; var arg_4603 any = as__1; if linked_4601 == nil { tmp11 = ifn_4602.Invoke_O__O(arg_4603) } else { tmp11 = linked_4601.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4600, arg_4603) }; var tmp12 any = tmp11; var tmp13 any; var root_4604 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4604, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4606 lang.IFn; if linked_4605 == nil { ifn_4606 = lang.IFn_Cast(root_4604) } else { ifn_4606 = nil }; var arg_4607 any = o__2; var arg_4608 any = A_arbace_go_check_A_const_366; var arg_4609 any; var tmp14 any; var root_4610 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_4611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4610, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4612 lang.IFn; if linked_4611 == nil { ifn_4612 = lang.IFn_Cast(root_4610) } else { ifn_4612 = nil }; var arg_4613 any = as__1; if linked_4611 == nil { tmp14 = ifn_4612.Invoke_O__O(arg_4613) } else { tmp14 = linked_4611.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4610, arg_4613) }; arg_4609 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp14))).Ref(); if linked_4605 == nil { tmp13 = ifn_4606.Invoke_O_O_O__O(arg_4607, arg_4608, arg_4609) } else { tmp13 = linked_4605.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4604, arg_4607, arg_4608, arg_4609) }; as__1, o__2 = tmp12, tmp13; continue L1 }
//line :700:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000516__3_, Lit_9) {
			var tmp15 any; var root_4614 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4614, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4616 lang.IFn; if linked_4615 == nil { ifn_4616 = lang.IFn_Cast(root_4614) } else { ifn_4616 = nil }; var arg_4617 any = as__1; if linked_4615 == nil { tmp15 = ifn_4616.Invoke_O__O(arg_4617) } else { tmp15 = linked_4615.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4614, arg_4617) }; var tmp16 any = tmp15; var tmp17 any; var root_4618 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4619 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4618, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4620 lang.IFn; if linked_4619 == nil { ifn_4620 = lang.IFn_Cast(root_4618) } else { ifn_4620 = nil }; var arg_4621 any = o__2; var arg_4622 any = A_arbace_go_check_A_const_367; var arg_4623 any = jrt.Boolean_TRUE.Ref(); if linked_4619 == nil { tmp17 = ifn_4620.Invoke_O_O_O__O(arg_4621, arg_4622, arg_4623) } else { tmp17 = linked_4619.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4618, arg_4621, arg_4622, arg_4623) }; as__1, o__2 = tmp16, tmp17; continue L1 }
//line :700:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1686000516__3_, Lit_10) {


			var tmp18 any; var root_4624 any = A_arbace_go_check_A_const_396.GetRawRoot__O(); var linked_4625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4624, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4626 lang.IFn; if linked_4625 == nil { ifn_4626 = lang.IFn_Cast(root_4624) } else { ifn_4626 = nil }; var arg_4627 any = as__1; if linked_4625 == nil { tmp18 = ifn_4626.Invoke_O__O(arg_4627) } else { tmp18 = linked_4625.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4624, arg_4627) }; var tmp19 any = tmp18; var tmp20 any; var root_4628 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4628, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4630 lang.IFn; if linked_4629 == nil { ifn_4630 = lang.IFn_Cast(root_4628) } else { ifn_4630 = nil }; var arg_4631 any = o__2; var arg_4632 any = A_arbace_go_check_A_const_368; var arg_4633 any; var root_4634 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_4635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4634, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4636 lang.IFn; if linked_4635 == nil { ifn_4636 = lang.IFn_Cast(root_4634) } else { ifn_4636 = nil }; var arg_4637 any = as__1; if linked_4635 == nil { arg_4633 = ifn_4636.Invoke_O__O(arg_4637) } else { arg_4633 = linked_4635.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4634, arg_4637) }; if linked_4629 == nil { tmp20 = ifn_4630.Invoke_O_O_O__O(arg_4631, arg_4632, arg_4633) } else { tmp20 = linked_4629.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4628, arg_4631, arg_4632, arg_4633) }; as__1, o__2 = tmp19, tmp20; continue L1 }
//line :700:1
		default:
		}




		var tmp21 any; var root_4638 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4638, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4640 lang.IFn; if linked_4639 == nil { ifn_4640 = lang.IFn_Cast(root_4638) } else { ifn_4640 = nil }; var arg_4641 any = as__1; if linked_4639 == nil { tmp21 = ifn_4640.Invoke_O__O(arg_4641) } else { tmp21 = linked_4639.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4638, arg_4641) }; var tmp22 any = tmp21; var tmp23 any; var root_4642 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4643 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4642, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4644 lang.IFn; if linked_4643 == nil { ifn_4644 = lang.IFn_Cast(root_4642) } else { ifn_4644 = nil }; var arg_4645 any = o__2; var arg_4646 any = A_arbace_go_check_A_const_395; var arg_4647 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4648 any; var root_4649 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4649, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4651 lang.IFn; if linked_4650 == nil { ifn_4651 = lang.IFn_Cast(root_4649) } else { ifn_4651 = nil }; var arg_4652 any = as__1; if linked_4650 == nil { arg_4648 = ifn_4651.Invoke_O__O(arg_4652) } else { arg_4648 = linked_4650.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4649, arg_4652) }; if linked_4643 == nil { tmp23 = ifn_4644.Invoke_O_O_O_O__O(arg_4645, arg_4646, arg_4647, arg_4648) } else { tmp23 = linked_4643.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4642, arg_4645, arg_4646, arg_4647, arg_4648) }; as__1, o__2 = tmp22, tmp23; continue L1 } } }; /*line :697:1*/panic("j2g: unreachable") }










func A_arbace_go_check__main_fn__1686000518_A_New_O_O(p0, p1 any) *A_arbace_go_check__main_fn__1686000518_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1686000518_A{}; t.Ctor_O_O(p0, p1); return t }
//line :708:1
func (t *A_arbace_go_check__main_fn__1686000518_A) Ctor_O_O(c__cs, c__opts any) { t.F_cs = c__cs; t.F_opts = c__opts }
//line :708:1
func (t *A_arbace_go_check__main_fn__1686000518_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_4659 any = A_arbace_go_check_A_const_308.GetRawRoot__O(); var linked_4660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4659, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4661 lang.IFn; if linked_4660 == nil { ifn_4661 = lang.IFn_Cast(root_4659) } else { ifn_4661 = nil }; var arg_4662 any; var iter__1927001039__auto____3 any; var fnbody__4734 any = A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A_New_O(t.F_opts); var tmp2 *jrt.Class; var fncls__4733 *jrt.Class = A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A_fn_class; if fncls__4733 == nil { var fncls__4733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__4734); A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A_fn_class = fncls__4733d; tmp2 = fncls__4733d } else { tmp2 = fncls__4733 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4734, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var t_ any = t.F_cs; t.F_cs = nil; tmp4 = t_; arg_4662 = tmp3.Invoke_O__O(tmp4); if linked_4660 == nil { tmp1 = ifn_4661.Invoke_O__O(arg_4662) } else { tmp1 = linked_4660.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4659, arg_4662) } }
//line :708:1
	return nil }(); var root_4735 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_4736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4735, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4737 lang.IFn; if linked_4736 == nil { ifn_4737 = lang.IFn_Cast(root_4735) } else { ifn_4737 = nil }; if linked_4736 == nil { ifn_4737.Invoke__O() } else { linked_4736.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4735) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A_New_O(p0 any) *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A{}; t.Ctor_O(p0); return t }
//line :710:1
func (t *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :710:1
func (t *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A) Invoke_O_O__O(self, s__1686000520__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4732 any = A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A_New_O_O_O(self, t.F_opts, s__1686000520__1); var tmp2 *jrt.Class; var fncls__4731 *jrt.Class = A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A_fn_class; if fncls__4731 == nil { var fncls__4731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__4732); A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A_fn_class = fncls__4731d; tmp2 = fncls__4731d } else { tmp2 = fncls__4731 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4732, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :710:1
func A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :710:1
func (t *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A) Ctor_O_O_O(c__iter__1686000519, c__opts, c__s__1686000520 any) { t.F_iter__1686000519 = c__iter__1686000519; t.F_opts = c__opts; t.F_s__1686000520 = c__s__1686000520 }
//line :710:1
func (t *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A) Invoke_O__O(self any) any { { var s__1686000520__1 any; var t_ any = t.F_s__1686000520; t.F_s__1686000520 = nil; s__1686000520__1 = t_; for { var temp__1927000414__auto____2 any; var root_4663 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4663, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4665 lang.IFn; if linked_4664 == nil { ifn_4665 = lang.IFn_Cast(root_4663) } else { ifn_4665 = nil }; var arg_4666 any = s__1686000520__1; if linked_4664 == nil { temp__1927000414__auto____2 = ifn_4665.Invoke_O__O(arg_4666) } else { temp__1927000414__auto____2 = linked_4664.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4663, arg_4666) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1686000520__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4667 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4667, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4669 lang.IFn; if linked_4668 == nil { ifn_4669 = lang.IFn_Cast(root_4667) } else { ifn_4669 = nil }; var arg_4670 any = s__1686000520__3; if linked_4668 == nil { tmp1 = ifn_4669.Invoke_O__O(arg_4670) } else { tmp1 = linked_4668.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4667, arg_4670) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4671 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4671, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4673 lang.IFn; if linked_4672 == nil { ifn_4673 = lang.IFn_Cast(root_4671) } else { ifn_4673 = nil }; var arg_4674 any = s__1686000520__3; if linked_4672 == nil { c__1927001037__auto____4 = ifn_4673.Invoke_O__O(arg_4674) } else { c__1927001037__auto____4 = linked_4672.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4671, arg_4674) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1686000522__6 any; var root_4675 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4675, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4677 lang.IFn; if linked_4676 == nil { ifn_4677 = lang.IFn_Cast(root_4675) } else { ifn_4677 = nil }; var arg_4678 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4676 == nil { b__1686000522__6 = ifn_4677.Invoke_O__O(arg_4678) } else { b__1686000522__6 = linked_4676.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4675, arg_4678) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4690 any = A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A_New_O_O_I_O(b__1686000522__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4689 *jrt.Class = A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A_fn_class; if fncls__4689 == nil { var fncls__4689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__4690); A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A_fn_class = fncls__4689d; tmp3 = fncls__4689d } else { tmp3 = fncls__4689 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4690, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4691 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4691, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4693 lang.IFn; if linked_4692 == nil { ifn_4693 = lang.IFn_Cast(root_4691) } else { ifn_4693 = nil }; var arg_4694 any; var root_4696 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_4697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4696, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4698 lang.IFn; if linked_4697 == nil { ifn_4698 = lang.IFn_Cast(root_4696) } else { ifn_4698 = nil }; var arg_4699 any = b__1686000522__6; if linked_4697 == nil { arg_4694 = ifn_4698.Invoke_O__O(arg_4699) } else { arg_4694 = linked_4697.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4696, arg_4699) }; var arg_4695 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1686000519); var tmp5 any; var root_4700 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4700, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4702 lang.IFn; if linked_4701 == nil { ifn_4702 = lang.IFn_Cast(root_4700) } else { ifn_4702 = nil }; var arg_4703 any = s__1686000520__3; if linked_4701 == nil { tmp5 = ifn_4702.Invoke_O__O(arg_4703) } else { tmp5 = linked_4701.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4700, arg_4703) }; arg_4695 = tmp4.Invoke_O__O(tmp5); if linked_4692 == nil { return ifn_4693.Invoke_O_O__O(arg_4694, arg_4695) } else { return linked_4692.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4691, arg_4694, arg_4695) } } else { var root_4704 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4704, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4706 lang.IFn; if linked_4705 == nil { ifn_4706 = lang.IFn_Cast(root_4704) } else { ifn_4706 = nil }; var arg_4707 any; var root_4709 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var linked_4710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4709, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4711 lang.IFn; if linked_4710 == nil { ifn_4711 = lang.IFn_Cast(root_4709) } else { ifn_4711 = nil }; var arg_4712 any = b__1686000522__6; if linked_4710 == nil { arg_4707 = ifn_4711.Invoke_O__O(arg_4712) } else { arg_4707 = linked_4710.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4709, arg_4712) }; var arg_4708 any; if linked_4705 == nil { return ifn_4706.Invoke_O_O__O(arg_4707, arg_4708) } else { return linked_4705.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4704, arg_4707, arg_4708) } } } else { var c__4 any; var root_4713 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4713, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4715 lang.IFn; if linked_4714 == nil { ifn_4715 = lang.IFn_Cast(root_4713) } else { ifn_4715 = nil }; var arg_4716 any = s__1686000520__3; if linked_4714 == nil { c__4 = ifn_4715.Invoke_O__O(arg_4716) } else { c__4 = linked_4714.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4713, arg_4716) }; var root_4717 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var linked_4718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4717, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4719 lang.IFn; if linked_4718 == nil { ifn_4719 = lang.IFn_Cast(root_4717) } else { ifn_4719 = nil }; var arg_4720 any; var root_4722 any = A_arbace_go_check_A_const_399.GetRawRoot__O(); var linked_4723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4722, A_arbace_go_check_annotations_A_fn_class); var ifn_4724 lang.IFn; if linked_4723 == nil { ifn_4724 = lang.IFn_Cast(root_4722) } else { ifn_4724 = nil }; var arg_4725 any = c__4; var arg_4726 any = t.F_opts; if linked_4723 == nil { arg_4720 = ifn_4724.Invoke_O_O__O(arg_4725, arg_4726) } else { arg_4720 = linked_4723.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4722, arg_4725, arg_4726) }; var arg_4721 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1686000519); var tmp7 any; var root_4727 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4727, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4729 lang.IFn; if linked_4728 == nil { ifn_4729 = lang.IFn_Cast(root_4727) } else { ifn_4729 = nil }; var arg_4730 any = s__1686000520__3; if linked_4728 == nil { tmp7 = ifn_4729.Invoke_O__O(arg_4730) } else { tmp7 = linked_4728.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4727, arg_4730) }; arg_4721 = tmp6.Invoke_O__O(tmp7); if linked_4718 == nil { return ifn_4719.Invoke_O_O__O(arg_4720, arg_4721) } else { return linked_4718.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4717, arg_4720, arg_4721) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :710:1
func A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :710:1
func (t *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A) Ctor_O_O_I_O(c__b__1686000522, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1686000522 = c__b__1686000522; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :710:1
func (t *A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A) Invoke_O__O(self any) any { { var i__1686000521__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1686000521__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1686000521__1)); var root_4679 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4679, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4681 lang.IFn; if linked_4680 == nil { ifn_4681 = lang.IFn_Cast(root_4679) } else { ifn_4681 = nil }; var arg_4682 any = t.F_b__1686000522; var arg_4683 any; var root_4684 any = A_arbace_go_check_A_const_399.GetRawRoot__O(); var linked_4685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4684, A_arbace_go_check_annotations_A_fn_class); var ifn_4686 lang.IFn; if linked_4685 == nil { ifn_4686 = lang.IFn_Cast(root_4684) } else { ifn_4686 = nil }; var arg_4687 any = c__2; var arg_4688 any = t.F_opts; if linked_4685 == nil { arg_4683 = ifn_4686.Invoke_O_O__O(arg_4687, arg_4688) } else { arg_4683 = linked_4685.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4684, arg_4687, arg_4688) }; if linked_4680 == nil { ifn_4681.Invoke_O_O__O(arg_4682, arg_4683) } else { linked_4680.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4679, arg_4682, arg_4683) }; i__1686000521__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1686000521__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Var

var A_arbace_go_check_A_const_55 *lang.Keyword

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Var

var A_arbace_go_check_A_const_61 *lang.Keyword

var A_arbace_go_check_A_const_62 *lang.Var

var A_arbace_go_check_A_const_63 *lang.Keyword

var A_arbace_go_check_A_const_64 *lang.Var

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Keyword

var A_arbace_go_check_A_const_67 *lang.Var

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Keyword

var A_arbace_go_check_A_const_73 *lang.Var

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Keyword

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 *lang.Var

var A_arbace_go_check_A_const_78 any

var A_arbace_go_check_A_const_79 *lang.Keyword

var A_arbace_go_check_A_const_80 *lang.Var

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Keyword

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Var

var A_arbace_go_check_A_const_90 *lang.Keyword

var A_arbace_go_check_A_const_91 *lang.Var

var A_arbace_go_check_A_const_92 *lang.Keyword

var A_arbace_go_check_A_const_93 *lang.Var

var A_arbace_go_check_A_const_94 *lang.Keyword

var A_arbace_go_check_A_const_95 any

var A_arbace_go_check_A_const_96 *lang.Keyword

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 *lang.Var

var A_arbace_go_check_A_const_99 any

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Keyword

var A_arbace_go_check_A_const_102 *lang.Var

var A_arbace_go_check_A_const_103 *lang.Var

var A_arbace_go_check_A_const_104 *lang.Var

var A_arbace_go_check_A_const_105 *lang.Var

var A_arbace_go_check_A_const_106 *lang.Var

var A_arbace_go_check_A_const_107 *lang.Keyword

var A_arbace_go_check_A_const_108 *lang.Var

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Keyword

var A_arbace_go_check_A_const_113 *lang.Keyword

var A_arbace_go_check_A_const_114 *lang.Var

var A_arbace_go_check_A_const_115 *lang.Keyword

var A_arbace_go_check_A_const_116 *lang.Keyword

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Keyword

var A_arbace_go_check_A_const_119 *lang.Keyword

var A_arbace_go_check_A_const_120 *lang.Keyword

var A_arbace_go_check_A_const_121 *lang.Keyword

var A_arbace_go_check_A_const_122 *lang.Keyword

var A_arbace_go_check_A_const_123 *lang.Var

var A_arbace_go_check_A_const_124 *lang.Var

var A_arbace_go_check_A_const_125 *lang.Keyword

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Var

var A_arbace_go_check_A_const_128 *lang.Keyword

var A_arbace_go_check_A_const_129 *lang.Var

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Var

var A_arbace_go_check_A_const_133 any

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 any

var A_arbace_go_check_A_const_138 any

var A_arbace_go_check_A_const_139 *lang.Var

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 *lang.Var

var A_arbace_go_check_A_const_142 *lang.Var

var A_arbace_go_check_A_const_143 *lang.Keyword

var A_arbace_go_check_A_const_144 *lang.Keyword

var A_arbace_go_check_A_const_145 any

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Keyword

var A_arbace_go_check_A_const_148 *lang.Keyword

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Var

var A_arbace_go_check_A_const_151 *lang.Var

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Var

var A_arbace_go_check_A_const_154 *lang.Var

var A_arbace_go_check_A_const_155 *lang.Keyword

var A_arbace_go_check_A_const_156 *lang.Var

var A_arbace_go_check_A_const_157 *lang.Keyword

var A_arbace_go_check_A_const_158 *lang.Keyword

var A_arbace_go_check_A_const_159 *lang.Keyword

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Var

var A_arbace_go_check_A_const_164 *lang.Var

var A_arbace_go_check_A_const_165 *lang.Var

var A_arbace_go_check_A_const_166 *lang.Keyword

var A_arbace_go_check_A_const_167 *lang.Keyword

var A_arbace_go_check_A_const_168 *lang.Keyword

var A_arbace_go_check_A_const_169 *lang.Keyword

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Var

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Var

var A_arbace_go_check_A_const_197 *lang.Var

var A_arbace_go_check_A_const_198 *lang.Var

var A_arbace_go_check_A_const_199 *lang.Var

var A_arbace_go_check_A_const_200 *lang.Keyword

var A_arbace_go_check_A_const_201 *lang.Keyword

var A_arbace_go_check_A_const_202 *lang.Keyword

var A_arbace_go_check_A_const_203 *lang.Keyword

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Var

var A_arbace_go_check_A_const_206 *lang.Var

var A_arbace_go_check_A_const_207 *lang.Keyword

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Var

var A_arbace_go_check_A_const_210 *lang.Var

var A_arbace_go_check_A_const_211 *lang.Var

var A_arbace_go_check_A_const_212 *lang.Keyword

var A_arbace_go_check_A_const_213 *lang.Var

var A_arbace_go_check_A_const_214 *lang.Keyword

var A_arbace_go_check_A_const_215 *lang.Var

var A_arbace_go_check_A_const_216 *lang.Var

var A_arbace_go_check_A_const_217 *lang.Keyword

var A_arbace_go_check_A_const_218 *lang.Keyword

var A_arbace_go_check_A_const_219 *lang.Var

var A_arbace_go_check_A_const_220 *lang.Keyword

var A_arbace_go_check_A_const_221 *lang.Var

var A_arbace_go_check_A_const_222 *lang.Var

var A_arbace_go_check_A_const_223 *lang.Var

var A_arbace_go_check_A_const_224 *lang.Var

var A_arbace_go_check_A_const_225 *lang.Keyword

var A_arbace_go_check_A_const_226 *lang.Var

var A_arbace_go_check_A_const_227 *lang.Var

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Keyword

var A_arbace_go_check_A_const_230 *lang.Keyword

var A_arbace_go_check_A_const_231 *lang.Keyword

var A_arbace_go_check_A_const_232 *lang.Var

var A_arbace_go_check_A_const_233 *lang.Var

var A_arbace_go_check_A_const_234 *lang.Keyword

var A_arbace_go_check_A_const_235 *lang.Keyword

var A_arbace_go_check_A_const_236 *lang.Keyword

var A_arbace_go_check_A_const_237 *lang.Var

var A_arbace_go_check_A_const_238 *lang.Var

var A_arbace_go_check_A_const_239 *lang.Keyword

var A_arbace_go_check_A_const_240 *lang.Keyword

var A_arbace_go_check_A_const_241 *lang.Var

var A_arbace_go_check_A_const_242 *lang.Var

var A_arbace_go_check_A_const_243 *lang.Keyword

var A_arbace_go_check_A_const_244 *lang.Keyword

var A_arbace_go_check_A_const_245 *lang.Keyword

var A_arbace_go_check_A_const_246 *lang.Keyword

var A_arbace_go_check_A_const_247 *lang.Var

var A_arbace_go_check_A_const_248 any

var A_arbace_go_check_A_const_249 any

var A_arbace_go_check_A_const_250 *lang.Keyword

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 *lang.Var

var A_arbace_go_check_A_const_253 *lang.Keyword

var A_arbace_go_check_A_const_254 any

var A_arbace_go_check_A_const_255 any

var A_arbace_go_check_A_const_256 *lang.Keyword

var A_arbace_go_check_A_const_257 *lang.Keyword

var A_arbace_go_check_A_const_258 *lang.Keyword

var A_arbace_go_check_A_const_259 *lang.Var

var A_arbace_go_check_A_const_260 *lang.Keyword

var A_arbace_go_check_A_const_261 *lang.Keyword

var A_arbace_go_check_A_const_262 *lang.Keyword

var A_arbace_go_check_A_const_263 *lang.Keyword

var A_arbace_go_check_A_const_264 *lang.Keyword

var A_arbace_go_check_A_const_265 *lang.Keyword

var A_arbace_go_check_A_const_266 *lang.Var

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 *lang.Keyword

var A_arbace_go_check_A_const_269 *lang.Var

var A_arbace_go_check_A_const_270 *lang.Var

var A_arbace_go_check_A_const_271 *lang.Keyword

var A_arbace_go_check_A_const_272 *lang.Keyword

var A_arbace_go_check_A_const_273 *lang.Var

var A_arbace_go_check_A_const_274 *lang.Var

var A_arbace_go_check_A_const_275 *lang.Var

var A_arbace_go_check_A_const_276 any

var A_arbace_go_check_A_const_277 *lang.Keyword

var A_arbace_go_check_A_const_278 *lang.Var

var A_arbace_go_check_A_const_279 *lang.Var

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Var

var A_arbace_go_check_A_const_283 *lang.Var

var A_arbace_go_check_A_const_284 *lang.Keyword

var A_arbace_go_check_A_const_285 *lang.Keyword

var A_arbace_go_check_A_const_286 *lang.Var

var A_arbace_go_check_A_const_287 *lang.Var

var A_arbace_go_check_A_const_288 *lang.Keyword

var A_arbace_go_check_A_const_289 *lang.Keyword

var A_arbace_go_check_A_const_290 *lang.Keyword

var A_arbace_go_check_A_const_291 *lang.Keyword

var A_arbace_go_check_A_const_292 any

var A_arbace_go_check_A_const_293 *lang.Keyword

var A_arbace_go_check_A_const_294 any

var A_arbace_go_check_A_const_295 any

var A_arbace_go_check_A_const_296 any

var A_arbace_go_check_A_const_297 *lang.Keyword

var A_arbace_go_check_A_const_298 *lang.Var

var A_arbace_go_check_A_const_299 any

var A_arbace_go_check_A_const_300 any

var A_arbace_go_check_A_const_301 any

var A_arbace_go_check_A_const_302 any

var A_arbace_go_check_A_const_303 any

var A_arbace_go_check_A_const_304 *lang.Keyword

var A_arbace_go_check_A_const_305 any

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 *lang.Var

var A_arbace_go_check_A_const_309 *lang.Var

var A_arbace_go_check_A_const_310 *lang.Var

var A_arbace_go_check_A_const_311 any

var A_arbace_go_check_A_const_312 *lang.Var

var A_arbace_go_check_A_const_313 *lang.Keyword

var A_arbace_go_check_A_const_314 *lang.Keyword

var A_arbace_go_check_A_const_315 *lang.Keyword

var A_arbace_go_check_A_const_316 *lang.Keyword

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 *lang.Var

var A_arbace_go_check_A_const_322 *lang.Var

var A_arbace_go_check_A_const_323 *lang.Keyword

var A_arbace_go_check_A_const_324 *lang.Var

var A_arbace_go_check_A_const_325 *lang.Var

var A_arbace_go_check_A_const_326 *lang.Var

var A_arbace_go_check_A_const_327 *lang.Var

var A_arbace_go_check_A_const_328 any

var A_arbace_go_check_A_const_329 *lang.Var

var A_arbace_go_check_A_const_330 any

var A_arbace_go_check_A_const_331 any

var A_arbace_go_check_A_const_332 *lang.Var

var A_arbace_go_check_A_const_333 *lang.Keyword

var A_arbace_go_check_A_const_334 *lang.Keyword

var A_arbace_go_check_A_const_335 *lang.Keyword

var A_arbace_go_check_A_const_336 *lang.Keyword

var A_arbace_go_check_A_const_337 *lang.Keyword

var A_arbace_go_check_A_const_338 *lang.Var

var A_arbace_go_check_A_const_339 *lang.Keyword

var A_arbace_go_check_A_const_340 *lang.Keyword

var A_arbace_go_check_A_const_341 *lang.Var

var A_arbace_go_check_A_const_342 *lang.Keyword

var A_arbace_go_check_A_const_343 any

var A_arbace_go_check_A_const_344 *lang.Keyword

var A_arbace_go_check_A_const_345 *lang.Keyword

var A_arbace_go_check_A_const_346 *lang.Var

var A_arbace_go_check_A_const_347 any

var A_arbace_go_check_A_const_348 any

var A_arbace_go_check_A_const_349 *lang.Var

var A_arbace_go_check_A_const_350 *lang.Var

var A_arbace_go_check_A_const_351 any

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 any

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_const_359 *lang.Var

var A_arbace_go_check_A_const_360 *lang.Var

var A_arbace_go_check_A_const_361 *lang.Var

var A_arbace_go_check_A_const_362 *lang.Var

var A_arbace_go_check_A_const_363 *lang.Var

var A_arbace_go_check_A_const_364 *lang.Var

var A_arbace_go_check_A_const_365 *lang.Var

var A_arbace_go_check_A_const_366 *lang.Keyword

var A_arbace_go_check_A_const_367 *lang.Keyword

var A_arbace_go_check_A_const_368 *lang.Keyword

var A_arbace_go_check_A_const_369 *lang.Var

var A_arbace_go_check_A_const_370 *lang.Var

var A_arbace_go_check_A_const_371 *jrt.Class

var A_arbace_go_check_A_const_372 *lang.Var

var A_arbace_go_check_A_const_373 *lang.Var

var A_arbace_go_check_A_const_374 *lang.Var

var A_arbace_go_check_A_const_375 *lang.Keyword

var A_arbace_go_check_A_const_376 any

var A_arbace_go_check_A_const_377 any

var A_arbace_go_check_A_const_378 any

var A_arbace_go_check_A_const_379 *lang.Keyword

var A_arbace_go_check_A_const_380 *lang.Var

var A_arbace_go_check_A_const_381 *lang.Keyword

var A_arbace_go_check_A_const_382 *lang.Var

var A_arbace_go_check_A_const_383 *lang.Var

var A_arbace_go_check_A_const_384 any

var A_arbace_go_check_A_const_385 any

var A_arbace_go_check_A_const_386 any

var A_arbace_go_check_A_const_387 any

var A_arbace_go_check_A_const_388 any

var A_arbace_go_check_A_const_389 any

var A_arbace_go_check_A_const_390 *lang.Var

var A_arbace_go_check_A_const_391 any

var A_arbace_go_check_A_const_392 any

var A_arbace_go_check_A_const_393 any

var A_arbace_go_check_A_const_394 any

var A_arbace_go_check_A_const_395 *lang.Keyword

var A_arbace_go_check_A_const_396 *lang.Var

var A_arbace_go_check_A_const_397 *lang.Keyword

var A_arbace_go_check_A_const_398 *lang.Var

var A_arbace_go_check_A_const_399 *lang.Var

var A_arbace_go_check_A_const_400 *lang.Var

var A_arbace_go_check_A_const_401 *lang.Var

var A_arbace_go_check_A_const_402 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29(); A_arbace_go_check_A_clinit_p30(); A_arbace_go_check_A_clinit_p31(); A_arbace_go_check_A_clinit_p32() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 587); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[184]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[185]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[186]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[187]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[189]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[190]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[191]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[192]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[193]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[194]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[195]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[196]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[200]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[201]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[203]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[204]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[205]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[206]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[207]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[208]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[209]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[213]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[214]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[216]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[220]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[221] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[222]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[223]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[224]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[225]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[226]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[227]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[231]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[232]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[233]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[234]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_54 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_60 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_61 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[245]); A_arbace_go_check_A_const_62 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[246]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_64 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_66 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_67 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_72 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_73 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[257]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[258]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[259]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[260]); A_arbace_go_check_A_const_77 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_78 = A_arbace_go_check_A_const_pool.A[262]; A_arbace_go_check_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_80 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[269]); A_arbace_go_check_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[270]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_89 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_91 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_92 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[276]); A_arbace_go_check_A_const_93 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_95 = A_arbace_go_check_A_const_pool.A[279]; A_arbace_go_check_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[281]); A_arbace_go_check_A_const_98 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[282]) }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = A_arbace_go_check_A_const_pool.A[283]; A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_101 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[285]); A_arbace_go_check_A_const_102 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_103 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_104 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_105 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_106 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[290]); A_arbace_go_check_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_108 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[295]); A_arbace_go_check_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_114 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_119 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[305]); A_arbace_go_check_A_const_122 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[306]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_124 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_125 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_127 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[312]); A_arbace_go_check_A_const_129 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_132 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[316]); A_arbace_go_check_A_const_133 = A_arbace_go_check_A_const_pool.A[317]; A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[318]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[319]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[320]); A_arbace_go_check_A_const_137 = A_arbace_go_check_A_const_pool.A[321]; A_arbace_go_check_A_const_138 = A_arbace_go_check_A_const_pool.A[322]; A_arbace_go_check_A_const_139 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[324]); A_arbace_go_check_A_const_141 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_142 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_144 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_145 = A_arbace_go_check_A_const_pool.A[329]; A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_148 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_150 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_151 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_153 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_154 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_155 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_156 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_157 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[341]); A_arbace_go_check_A_const_158 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[342]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_163 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_164 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_165 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_166 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_167 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_168 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_169 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[353]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_191 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[377]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[378]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_196 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_197 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_198 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_199 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_200 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_201 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_202 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_203 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_205 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]); A_arbace_go_check_A_const_206 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_209 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_210 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_211 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_213 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_215 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_216 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_217 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[401]); A_arbace_go_check_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[402]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_221 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_222 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_223 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_224 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_226 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_227 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[413]); A_arbace_go_check_A_const_230 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[414]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_232 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_233 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_237 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_238 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_239 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[424]); A_arbace_go_check_A_const_241 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[425]); A_arbace_go_check_A_const_242 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[426]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_244 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[428]); A_arbace_go_check_A_const_245 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[429]); A_arbace_go_check_A_const_246 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[430]); A_arbace_go_check_A_const_247 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_248 = A_arbace_go_check_A_const_pool.A[432]; A_arbace_go_check_A_const_249 = A_arbace_go_check_A_const_pool.A[433]; A_arbace_go_check_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[435]); A_arbace_go_check_A_const_252 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[436]); A_arbace_go_check_A_const_253 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_254 = A_arbace_go_check_A_const_pool.A[438]; A_arbace_go_check_A_const_255 = A_arbace_go_check_A_const_pool.A[439] }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_258 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_259 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_260 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_261 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[445]); A_arbace_go_check_A_const_262 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_263 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_264 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_265 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_266 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]); A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[451]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[452]); A_arbace_go_check_A_const_269 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_270 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_271 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_272 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_273 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[457]); A_arbace_go_check_A_const_274 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_275 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_276 = A_arbace_go_check_A_const_pool.A[460]; A_arbace_go_check_A_const_277 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_278 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]); A_arbace_go_check_A_const_279 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[463]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_282 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_283 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_284 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_285 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_286 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_287 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[471]); A_arbace_go_check_A_const_288 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[472]); A_arbace_go_check_A_const_289 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[473]); A_arbace_go_check_A_const_290 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[474]); A_arbace_go_check_A_const_291 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[475]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = A_arbace_go_check_A_const_pool.A[476]; A_arbace_go_check_A_const_293 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[477]); A_arbace_go_check_A_const_294 = A_arbace_go_check_A_const_pool.A[478]; A_arbace_go_check_A_const_295 = A_arbace_go_check_A_const_pool.A[479]; A_arbace_go_check_A_const_296 = A_arbace_go_check_A_const_pool.A[480]; A_arbace_go_check_A_const_297 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[481]); A_arbace_go_check_A_const_298 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[482]); A_arbace_go_check_A_const_299 = A_arbace_go_check_A_const_pool.A[483]; A_arbace_go_check_A_const_300 = A_arbace_go_check_A_const_pool.A[484]; A_arbace_go_check_A_const_301 = A_arbace_go_check_A_const_pool.A[485]; A_arbace_go_check_A_const_302 = A_arbace_go_check_A_const_pool.A[486]; A_arbace_go_check_A_const_303 = A_arbace_go_check_A_const_pool.A[487]; A_arbace_go_check_A_const_304 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[488]); A_arbace_go_check_A_const_305 = A_arbace_go_check_A_const_pool.A[489] }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_308 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_309 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_310 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[494]); A_arbace_go_check_A_const_311 = A_arbace_go_check_A_const_pool.A[495]; A_arbace_go_check_A_const_312 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_313 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_314 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[498]); A_arbace_go_check_A_const_315 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_316 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[500]); A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_321 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_322 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[506]); A_arbace_go_check_A_const_323 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[507]); A_arbace_go_check_A_const_324 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[508]); A_arbace_go_check_A_const_325 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[509]); A_arbace_go_check_A_const_326 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[510]); A_arbace_go_check_A_const_327 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[511]); A_arbace_go_check_A_const_328 = A_arbace_go_check_A_const_pool.A[512]; A_arbace_go_check_A_const_329 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[513]) }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_330 = A_arbace_go_check_A_const_pool.A[514]; A_arbace_go_check_A_const_331 = A_arbace_go_check_A_const_pool.A[515]; A_arbace_go_check_A_const_332 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[516]); A_arbace_go_check_A_const_333 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_334 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_335 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_336 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_337 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[521]); A_arbace_go_check_A_const_338 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[522]); A_arbace_go_check_A_const_339 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[523]); A_arbace_go_check_A_const_340 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[524]); A_arbace_go_check_A_const_341 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[525]) }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[526]); A_arbace_go_check_A_const_343 = A_arbace_go_check_A_const_pool.A[527]; A_arbace_go_check_A_const_344 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[528]); A_arbace_go_check_A_const_345 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[529]); A_arbace_go_check_A_const_346 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[530]); A_arbace_go_check_A_const_347 = A_arbace_go_check_A_const_pool.A[531]; A_arbace_go_check_A_const_348 = A_arbace_go_check_A_const_pool.A[532]; A_arbace_go_check_A_const_349 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[533]); A_arbace_go_check_A_const_350 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[534]); A_arbace_go_check_A_const_351 = A_arbace_go_check_A_const_pool.A[535]; A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[536]); A_arbace_go_check_A_const_353 = A_arbace_go_check_A_const_pool.A[537]; A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[538]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[539]); A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[540]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[541]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[542]); A_arbace_go_check_A_const_359 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[543]); A_arbace_go_check_A_const_360 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[544]); A_arbace_go_check_A_const_361 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[545]); A_arbace_go_check_A_const_362 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[546]); A_arbace_go_check_A_const_363 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[547]); A_arbace_go_check_A_const_364 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[548]); A_arbace_go_check_A_const_365 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[549]); A_arbace_go_check_A_const_366 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[550]) }

func A_arbace_go_check_A_clinit_p30() { A_arbace_go_check_A_const_367 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[551]); A_arbace_go_check_A_const_368 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[552]); A_arbace_go_check_A_const_369 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[553]); A_arbace_go_check_A_const_370 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[554]); A_arbace_go_check_A_const_371 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[555]); A_arbace_go_check_A_const_372 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[556]); A_arbace_go_check_A_const_373 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[557]); A_arbace_go_check_A_const_374 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[558]); A_arbace_go_check_A_const_375 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[559]); A_arbace_go_check_A_const_376 = A_arbace_go_check_A_const_pool.A[560]; A_arbace_go_check_A_const_377 = A_arbace_go_check_A_const_pool.A[561]; A_arbace_go_check_A_const_378 = A_arbace_go_check_A_const_pool.A[562] }

func A_arbace_go_check_A_clinit_p31() { A_arbace_go_check_A_const_379 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[563]); A_arbace_go_check_A_const_380 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[564]); A_arbace_go_check_A_const_381 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[565]); A_arbace_go_check_A_const_382 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[566]); A_arbace_go_check_A_const_383 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[567]); A_arbace_go_check_A_const_384 = A_arbace_go_check_A_const_pool.A[568]; A_arbace_go_check_A_const_385 = A_arbace_go_check_A_const_pool.A[569]; A_arbace_go_check_A_const_386 = A_arbace_go_check_A_const_pool.A[570]; A_arbace_go_check_A_const_387 = A_arbace_go_check_A_const_pool.A[571]; A_arbace_go_check_A_const_388 = A_arbace_go_check_A_const_pool.A[572]; A_arbace_go_check_A_const_389 = A_arbace_go_check_A_const_pool.A[573]; A_arbace_go_check_A_const_390 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[574]); A_arbace_go_check_A_const_391 = A_arbace_go_check_A_const_pool.A[575]; A_arbace_go_check_A_const_392 = A_arbace_go_check_A_const_pool.A[576] }

func A_arbace_go_check_A_clinit_p32() { A_arbace_go_check_A_const_393 = A_arbace_go_check_A_const_pool.A[577]; A_arbace_go_check_A_const_394 = A_arbace_go_check_A_const_pool.A[578]; A_arbace_go_check_A_const_395 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[579]); A_arbace_go_check_A_const_396 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[580]); A_arbace_go_check_A_const_397 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[581]); A_arbace_go_check_A_const_398 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[582]); A_arbace_go_check_A_const_399 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[583]); A_arbace_go_check_A_const_400 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[584]); A_arbace_go_check_A_const_401 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[585]); A_arbace_go_check_A_const_402 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[586]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1686000515_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1686000515_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1686000518_A struct{ j2g_header uint64; F_cs, F_opts any }

var A_arbace_go_check__main_fn__1686000518_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A struct{ j2g_header uint64; F_iter__1686000519, F_opts, F_s__1686000520 any }

var A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A struct{ j2g_header uint64; F_b__1686000522, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_fn__1686000518_iter__1686000519__1686000523_fn__1686000524_fn__1686000525_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1686000490__1686000496_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1686000490__1686000496_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A struct{ j2g_header uint64; F_s__1686000491, F_iter__1686000490 any }

var A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A struct{ j2g_header uint64; F_r, F_s__1686000493, F_iter__1686000492 any }

var A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1686000495 any }

var A_arbace_go_check_annotations_iter__1686000490__1686000496_fn__1686000497_iter__1686000492__1686000498_fn__1686000499_fn__1686000500_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1686000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1686000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1686000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1686000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000370_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1686000370_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000374_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1686000374_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000378_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1686000378_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1686000384_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000398_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1686000384_fn__1686000400_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A struct{ j2g_header uint64; F_s__1686000389, F_iter__1686000388 any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A struct{ j2g_header uint64; F_b__1686000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000388__1686000392_fn__1686000393_fn__1686000394_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A struct{ j2g_header uint64; F_iter__1686000402, F_dir, F_tdir, F_ts, F_s__1686000403 any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A struct{ j2g_header uint64; F_dir, F_b__1686000405, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000408_fn__1686000412_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1686000384_iter__1686000402__1686000406_fn__1686000407_fn__1686000418_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1686000360__1686000364_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A struct{ j2g_header uint64; F_s__1686000361, F_iter__1686000360 any }

var A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1686000363 any }

var A_arbace_go_check_check_corpus_iter__1686000360__1686000364_fn__1686000365_fn__1686000366_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000129_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1686000129_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000131_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1686000131_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000179_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000186_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1686000186_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000193_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1686000193_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000203_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1686000203_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000205_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1686000205_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000239_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000239_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000241_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1686000241_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000247_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1686000247_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_A struct{ j2g_header uint64; F_resolving any }

var A_arbace_go_check_check_package_fn__1686000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000254_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000256_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000258_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000260_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000262_fn__1686000263_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000282_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000284_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000286_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1686000250_fn__1686000288_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A struct{ j2g_header uint64; F_s__1686000267, F_iter__1686000266, F_verified any }

var A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A struct{ j2g_header uint64; F_b__1686000269 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1686000250_iter__1686000266__1686000270_fn__1686000271_fn__1686000272_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000299_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000299_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000311_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000311_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1686000311_fn__1686000312_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1686000231_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1686000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1686000231_one__1686000232_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1686000301__1686000305_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1686000301__1686000305_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A struct{ j2g_header uint64; F_s__1686000302, F_iter__1686000301 any }

var A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A struct{ j2g_header uint64; F_b__1686000304 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1686000301__1686000305_fn__1686000306_fn__1686000307_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1686000235_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1686000235_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1686000235_fn__1686000236_A_fn_class *jrt.Class



type A_arbace_go_check_check_src_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_src_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1686000321_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1686000321_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1686000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1686000004_A_New() *A_arbace_go_check_eval1686000004_A { t := &A_arbace_go_check_eval1686000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1686000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1686000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1686000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1686000004_A_class }

func (t *A_arbace_go_check_eval1686000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1686000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1686000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1686000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1686000004_A); return ok }

func A_arbace_go_check_eval1686000004_A_Cast(x any) *A_arbace_go_check_eval1686000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1686000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1686000004_A_class)) }; return v }



type A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1686000004_loading__1927001464__auto____1686000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1686000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1686000008_A_New() *A_arbace_go_check_eval1686000008_A { t := &A_arbace_go_check_eval1686000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1686000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1686000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1686000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1686000008_A_class }

func (t *A_arbace_go_check_eval1686000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1686000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1686000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1686000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1686000008_A); return ok }

func A_arbace_go_check_eval1686000008_A_Cast(x any) *A_arbace_go_check_eval1686000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1686000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1686000008_A_class)) }; return v }



type A_arbace_go_check_eval1686000008_fn__1686000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1686000008_fn__1686000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1686000467_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1686000467_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1686000469__1686000473_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1686000469__1686000473_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A struct{ j2g_header uint64; F_iter__1686000469, F_s__1686000470 any }

var A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1686000472, F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1686000469__1686000473_fn__1686000474_fn__1686000475_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1686000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1686000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1686000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1686000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1686000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1686000083_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1686000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1686000089_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1686000447__1686000453_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1686000447__1686000453_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A struct{ j2g_header uint64; F_iter__1686000447, F_s__1686000448 any }

var A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A struct{ j2g_header uint64; F_iter__1686000449, F_r, F_s__1686000450 any }

var A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A struct{ j2g_header uint64; F_b__1686000452, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_report_errors_iter__1686000447__1686000453_fn__1686000454_iter__1686000449__1686000455_fn__1686000456_fn__1686000457_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1686000318_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1686000318_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1686000338__1686000342_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A struct{ j2g_header uint64; F_iter__1686000338, F_f, F_out, F_q, F_xs, F_s__1686000339 any }

var A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1686000341 any }

var A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000344_fn__1686000345_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1686000338__1686000342_fn__1686000343_fn__1686000348_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1686000333_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1686000333_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1686000333_fn__1686000334_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1686000434_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1686000434_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1686000436_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1686000436_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1686000438_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1686000438_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1686000440_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1686000440_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1686000442_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1686000442_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1686000444_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1686000444_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1686000432_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1686000432_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1686000430_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1686000430_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1686000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1686000483_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1686000483_A_fn_class *jrt.Class
