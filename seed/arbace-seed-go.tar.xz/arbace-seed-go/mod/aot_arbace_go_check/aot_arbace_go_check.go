//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_106)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__7, A_arbace_go_check_A_const_54.Invoke_O__O(n__6))).Ref() } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_262 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_go_check_A_const_24; var arg_266 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_268 == nil { tmp2 = ifn_269.Invoke_O__O(arg_270) } else { tmp2 = linked_268.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_267, arg_270) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_271 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_275 any = Lit_143; var arg_276 any; var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_280 == nil { arg_276 = ifn_281.Invoke_O__O(arg_282) } else { arg_276 = linked_280.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_279, arg_282) }; var arg_277 any; var root_283 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_285 lang.IFn
							if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = want__7; if linked_284 == nil { arg_277 = ifn_285.Invoke_O__O(arg_286) } else { arg_277 = linked_284.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_283, arg_286) }
//line :93:1
							var arg_278 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_289 lang.IFn
							if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_288 == nil { arg_278 = ifn_289.Invoke_O__O(arg_290) } else { arg_278 = linked_288.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_287, arg_290) }
//line :93:1
							if linked_272 == nil { ifn_273.Invoke_O_O_O_O_O__O(arg_274, arg_275, arg_276, arg_277, arg_278) } else { linked_272.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_271, arg_274, arg_275, arg_276, arg_277, arg_278) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_291 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_293 lang.IFn
									if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_292 == nil { and__1927000168__auto____11 = ifn_293.Invoke_O__O(arg_294) } else { and__1927000168__auto____11 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_295 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_67; var arg_299 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_300 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); var arg_304 any = Lit_143; var arg_305 any; var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); if linked_309 == nil { arg_305 = ifn_310.Invoke_O__O(arg_311) } else { arg_305 = linked_309.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_308, arg_311) }; var arg_306 any = Lit_144; var arg_307 any; var root_312 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_313 == nil { arg_307 = ifn_314.Invoke_O__O(arg_315) } else { arg_307 = linked_313.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_312, arg_315) }; if linked_301 == nil { ifn_302.Invoke_O_O_O_O_O__O(arg_303, arg_304, arg_305, arg_306, arg_307) } else { linked_301.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_300, arg_303, arg_304, arg_305, arg_306, arg_307) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1685000042__7; if linked_317 == nil { tmp8 = ifn_318.Invoke_O__O(arg_319) } else { tmp8 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_316, arg_319) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__9, A_arbace_go_check_A_const_54.Invoke_O__O(n__8))).Ref() } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_320 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_24; var arg_324 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_321 == nil { ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { linked_321.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_325 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_326 == nil { tmp10 = ifn_327.Invoke_O__O(arg_328) } else { tmp10 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_325, arg_328) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_329 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_333 any = Lit_143; var arg_334 any; var root_337 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_338 == nil { arg_334 = ifn_339.Invoke_O__O(arg_340) } else { arg_334 = linked_338.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_337, arg_340) }; var arg_335 any; var root_341 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_343 lang.IFn
								if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = want__9; if linked_342 == nil { arg_335 = ifn_343.Invoke_O__O(arg_344) } else { arg_335 = linked_342.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_341, arg_344) }
//line :93:1
								var arg_336 any; var root_345 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_347 lang.IFn
								if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_346 == nil { arg_336 = ifn_347.Invoke_O__O(arg_348) } else { arg_336 = linked_346.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_345, arg_348) }
//line :93:1
								if linked_330 == nil { ifn_331.Invoke_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336) } else { linked_330.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_349 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_351 lang.IFn
										if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_350 == nil { and__1927000168__auto____13 = ifn_351.Invoke_O__O(arg_352) } else { and__1927000168__auto____13 = linked_350.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_353 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_go_check_A_const_67; var arg_357 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_354 == nil { tmp11 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp11 = linked_354.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_358 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); var arg_362 any = Lit_143; var arg_363 any; var root_366 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); if linked_367 == nil { arg_363 = ifn_368.Invoke_O__O(arg_369) } else { arg_363 = linked_367.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_366, arg_369) }; var arg_364 any = Lit_144; var arg_365 any; var root_370 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_371 == nil { arg_365 = ifn_372.Invoke_O__O(arg_373) } else { arg_365 = linked_371.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_370, arg_373) }; if linked_359 == nil { ifn_360.Invoke_O_O_O_O_O__O(arg_361, arg_362, arg_363, arg_364, arg_365) } else { linked_359.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_358, arg_361, arg_362, arg_363, arg_364, arg_365) } } }
//line :86:1
				var tmp15 any; var root_374 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1685000042__7; if linked_375 == nil { tmp15 = ifn_376.Invoke_O__O(arg_377) } else { tmp15 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_70; var tmp2 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_71; var tmp4 any; var root_378 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_380 lang.IFn; if
													linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = pkg_scope__0; var arg_382 any = A_arbace_go_check_A_const_73; if linked_379 == nil { tmp4 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp4 = linked_379.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_74; var tmp7 any; var root_383 any = /*line :101:1*/A_arbace_go_check_A_const_75.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_385 lang.IFn; if


	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var or__1927000174__auto____4 any; var root_387 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = fi__1; var arg_391 any = A_arbace_go_check_A_const_77; if linked_388 == nil { or__1927000174__auto____4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { or__1927000174__auto____4 = linked_388.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_386 = or__1927000174__auto____4 } else { arg_386 = A_arbace_go_check_A_const_74.Invoke_O__O(config__2) }; if linked_384 == nil { tmp7 = ifn_385.Invoke_O__O(arg_386) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_384.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_383, arg_386)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_78; var tmp10 any; var root_392 any = /*line :101:1*/A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_394 lang.IFn; if



	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_go_check_A_const_73.Invoke_O__O(fi__1); if linked_393 == nil { tmp10 = ifn_394.Invoke_O__O(arg_395) } else { tmp10 = linked_393.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_392, arg_395) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_80; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_80; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_81.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_82; var tmp16 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_83; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_84; var tmp20 any; var root_396 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_398 lang.IFn; if





	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.PersistentVector_EMPTY.Ref(); if linked_397 == nil { tmp20 = ifn_398.Invoke_O__O(arg_399) } else { tmp20 = linked_397.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_396, arg_399) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_85; var tmp23 any; var root_400 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_402 lang.IFn; if





	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.PersistentVector_EMPTY.Ref(); if linked_401 == nil { tmp23 = ifn_402.Invoke_O__O(arg_403) } else { tmp23 = linked_401.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_400, arg_403) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__502d; tmp1 = fncls__502d } else { tmp1 = fncls__502 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_503 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_A_const_84.Invoke_O__O(fi__0); if linked_508 == nil { arg_506 = ifn_509.Invoke_O__O(arg_510) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_507, arg_510) }; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__561d; tmp3 = fncls__561d } else { tmp3 = fncls__561 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_404 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_406 lang.IFn
	if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = f__1; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_404, arg_407) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_408 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = f__1; if linked_409 == nil { temp__1927000414__auto____2 = ifn_410.Invoke_O__O(arg_411) } else { temp__1927000414__auto____2 = linked_409.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_470 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_472 lang.IFn
			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_go_check_A_const_71.Invoke_O__O(t.F_fi); var arg_474 any = q__3; if linked_471 == nil { temp__1927000414__auto____4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { temp__1927000414__auto____4 = linked_471.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_91; var tmp3 any; var root_475 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_477 lang.IFn
				if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__5; var arg_479 any = A_arbace_go_check_A_const_93; if linked_476 == nil { tmp3 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp3 = linked_476.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_480 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = x__5; var arg_484 any = A_arbace_go_check_A_const_89; var arg_485 any = jrt.Boolean_TRUE.Ref(); if linked_481 == nil { ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp5 any; var root_412 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_414 lang.IFn


			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; if linked_413 == nil { tmp5 = ifn_414.Invoke_O__O(arg_415) } else { tmp5 = linked_413.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_412, arg_415) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_416 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_418 lang.IFn; _ = ___6; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = imp__7; var arg_420 any = A_arbace_go_check_A_const_89; var arg_421 any = jrt.Boolean_TRUE.Ref(); if linked_417 == nil { ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { linked_417.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } } } else {
//line :113:1
				var tmp6 any; var root_422 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_424 lang.IFn




				if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp6 = ifn_424.Invoke_O__O(arg_425) } else { tmp6 = linked_423.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_422, arg_425) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_426 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn




					if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = f__1; if linked_427 == nil { seq_1685000052__2 = ifn_428.Invoke_O__O(arg_429) } else { seq_1685000052__2 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1685000052__2; if linked_431 == nil { temp__1927000414__auto____6 = ifn_432.Invoke_O__O(arg_433) } else { temp__1927000414__auto____6 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1685000052__7; if linked_435 == nil { tmp7 = ifn_436.Invoke_O__O(arg_437) } else { tmp7 = linked_435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_1685000052__7; if linked_439 == nil { c__1927000678__auto____8 = ifn_440.Invoke_O__O(arg_441) } else { c__1927000678__auto____8 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_438, arg_441) }; var tmp8 any; var root_486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1685000052__7; if linked_487 == nil { tmp8 = ifn_488.Invoke_O__O(arg_489) } else { tmp8 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1685000052__7; if linked_443 == nil { x__8 = ifn_444.Invoke_O__O(arg_445) } else { x__8 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_1685000052__7; if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_490, arg_493) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_446 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_448 lang.IFn





							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; if linked_447 == nil { tmp10 = ifn_448.Invoke_O__O(arg_449) } else { tmp10 = linked_447.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_446, arg_449) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_450 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn





								if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = f__1; if linked_451 == nil { seq_1685000056__2 = ifn_452.Invoke_O__O(arg_453) } else { seq_1685000056__2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1685000056__2; if linked_455 == nil { temp__1927000414__auto____6_2 = ifn_456.Invoke_O__O(arg_457) } else { temp__1927000414__auto____6_2 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_458 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1685000056__7; if linked_459 == nil { tmp11 = ifn_460.Invoke_O__O(arg_461) } else { tmp11 = linked_459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_462 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1685000056__7; if linked_463 == nil { c__1927000678__auto____8_2 = ifn_464.Invoke_O__O(arg_465) } else { c__1927000678__auto____8_2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_462, arg_465) }; var tmp12 any; var root_494 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1685000056__7; if linked_495 == nil { tmp12 = ifn_496.Invoke_O__O(arg_497) } else { tmp12 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_466 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1685000056__7; if linked_467 == nil { x__8_2 = ifn_468.Invoke_O__O(arg_469) } else { x__8_2 = linked_467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_466, arg_469) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1685000056__7; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_511 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_513 lang.IFn
		if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = f__1; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp3 any; var root_515 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn
			if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__1; if linked_516 == nil { tmp3 = ifn_517.Invoke_O__O(arg_518) } else { tmp3 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_521 lang.IFn; _ = ___4; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = imp__5; var arg_523 any = A_arbace_go_check_A_const_89; var arg_524 any = jrt.Boolean_TRUE.Ref(); if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_525 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_527 lang.IFn

				if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { or__1927000174__auto____2 = ifn_527.Invoke_O__O(arg_528) } else { or__1927000174__auto____2 = linked_526.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_529 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_529, arg_532) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__1; if linked_534 == nil { seq_1685000065__2 = ifn_535.Invoke_O__O(arg_536) } else { seq_1685000065__2 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1685000065__2; if linked_538 == nil { temp__1927000414__auto____6 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000414__auto____6 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1685000065__7; if linked_542 == nil { tmp5 = ifn_543.Invoke_O__O(arg_544) } else { tmp5 = linked_542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_541, arg_544) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = seq_1685000065__7; if linked_546 == nil { c__1927000678__auto____8 = ifn_547.Invoke_O__O(arg_548) } else { c__1927000678__auto____8 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_545, arg_548) }; var tmp6 any; var root_553 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = seq_1685000065__7; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1685000065__7; if linked_550 == nil { x__8 = ifn_551.Invoke_O__O(arg_552) } else { x__8 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_557 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1685000065__7; if linked_558 == nil { tmp7 = ifn_559.Invoke_O__O(arg_560) } else { tmp7 = linked_558.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_557, arg_560) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_98); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp6 any; var root_682 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = d__0; if linked_683 == nil { tmp6 = ifn_684.Invoke_O__O(arg_685) } else { tmp6 = linked_683.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_99; var tmp8 any; var root_674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { tmp8 = ifn_676.Invoke_O__O(arg_677) } else { tmp8 = linked_675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_674, arg_677) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp10 any; var root_678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = d__0; if linked_679 == nil { tmp10 = ifn_680.Invoke_O__O(arg_681) } else { tmp10 = linked_679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_678, arg_681) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_564 lang.IFn
		if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = f__1; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_566 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = f__1; if linked_567 == nil { tmp2 = ifn_568.Invoke_O__O(arg_569) } else { tmp2 = linked_567.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_566, arg_569) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_572 lang.IFn

			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = t.F_pkg_scope; var arg_574 any; var root_575 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = f__1; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_575, arg_578) }; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_94); var tmp4 any; var root_634 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_636 lang.IFn
				if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__3; var arg_638 any = A_arbace_go_check_A_const_93; if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp4 = linked_635.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_579 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_583 any = A_arbace_go_check_A_const_95; var arg_584 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_585 any = x__3; if linked_580 == nil { tmp6 = ifn_581.Invoke_O_O_O_O__O(arg_582, arg_583, arg_584, arg_585) } else { tmp6 = linked_580.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_579, arg_582, arg_583, arg_584, arg_585) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_586 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_588 lang.IFn




								if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = f__1; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_586, arg_589) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_639 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_641 lang.IFn




									if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = f__1; if linked_640 == nil { temp__1927000414__auto____2_2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2_2 = linked_640.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_643 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_645 lang.IFn
										if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = h__3; var arg_647 any = Lit_124; if linked_644 == nil { and__1927000168__auto____4 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { and__1927000168__auto____4 = linked_644.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_648 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = h__3; var arg_656 any = Lit_142; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { and__1927000168__auto____5 = ifn_650.Invoke_O__O(arg_651) } else { and__1927000168__auto____5 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn








									if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { seq_1685000072__2 = ifn_592.Invoke_O__O(arg_593) } else { seq_1685000072__2 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_1685000072__2; if linked_595 == nil { temp__1927000414__auto____6 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____6 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_1685000072__7; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_1685000072__7; if linked_603 == nil { c__1927000678__auto____8 = ifn_604.Invoke_O__O(arg_605) } else { c__1927000678__auto____8 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_602, arg_605) }; var tmp10 any; var root_657 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1685000072__7; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_657, arg_660) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1685000072__7; if linked_607 == nil { x__8 = ifn_608.Invoke_O__O(arg_609) } else { x__8 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_661 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1685000072__7; if linked_662 == nil { tmp11 = ifn_663.Invoke_O__O(arg_664) } else { tmp11 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_610 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_612 lang.IFn









											if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = f__1; if linked_611 == nil { tmp12 = ifn_612.Invoke_O__O(arg_613) } else { tmp12 = linked_611.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_610, arg_613) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_614 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn









												if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = f__1; if linked_615 == nil { seq_1685000076__2 = ifn_616.Invoke_O__O(arg_617) } else { seq_1685000076__2 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_1685000076__2; if linked_619 == nil { temp__1927000414__auto____6_2 = ifn_620.Invoke_O__O(arg_621) } else { temp__1927000414__auto____6_2 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_622 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_1685000076__7; if linked_623 == nil { tmp13 = ifn_624.Invoke_O__O(arg_625) } else { tmp13 = linked_623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_626 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = seq_1685000076__7; if linked_627 == nil { c__1927000678__auto____8_2 = ifn_628.Invoke_O__O(arg_629) } else { c__1927000678__auto____8_2 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any; var root_665 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1685000076__7; if linked_666 == nil { tmp14 = ifn_667.Invoke_O__O(arg_668) } else { tmp14 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_630 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1685000076__7; if linked_631 == nil { x__8_2 = ifn_632.Invoke_O__O(arg_633) } else { x__8_2 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_669 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = seq_1685000076__7; if linked_670 == nil { tmp15 = ifn_671.Invoke_O__O(arg_672) } else { tmp15 = linked_670.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_669, arg_672) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000097__2 any) any { var map__1685000098__4 any = p__1685000097__2; var map__1685000098__5 any; if lang.ISeq_InstanceOf(map__1685000098__4) { var tmp1 any; var root_686 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = map__1685000098__4; if linked_687 == nil { tmp1 = ifn_688.Invoke_O__O(arg_689) } else { tmp1 = linked_687.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_690 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = map__1685000098__4; if linked_691 == nil { tmp2 = ifn_692.Invoke_O__O(arg_693) } else { tmp2 = linked_691.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_690, arg_693) }; map__1685000098__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_694 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = map__1685000098__4; if linked_695 == nil { tmp3 = ifn_696.Invoke_O__O(arg_697) } else { tmp3 = linked_695.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp3) { var root_698 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = map__1685000098__4; if linked_699 == nil { map__1685000098__5 = ifn_700.Invoke_O__O(arg_701) } else { map__1685000098__5 = linked_699.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_698, arg_701) } } else { map__1685000098__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000098__5 = map__1685000098__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000098__5, A_arbace_go_check_A_const_102); var pkg_scope__7 any; var root_702 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_704 lang.IFn; if




	linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var arg_706 any = A_arbace_go_check_A_const_103; if linked_703 == nil { pkg_scope__7 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { pkg_scope__7 = linked_703.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; var pkg__8 any; var root_707 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_709 lang.IFn; if





	linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var tmp4 any = A_arbace_go_check_A_const_104; var tmp5 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_70; var tmp7 any = A_arbace_go_check_A_const_70.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_71; var tmp9 any = A_arbace_go_check_A_const_105; var arg_710 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, A_arbace_go_check_A_const_105.Invoke_O__O(src__0))); if linked_708 == nil { pkg__8 = ifn_709.Invoke_O__O(arg_710) } else { pkg__8 = linked_708.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_707, arg_710) }; var errors__9 any; var root_711 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_713 lang.IFn; if






	linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = lang.PersistentVector_EMPTY.Ref(); if linked_712 == nil { errors__9 = ifn_713.Invoke_O__O(arg_714) } else { errors__9 = linked_712.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_711, arg_714) }; var annotated__10 any; var root_715 any = /*line :151:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_717 lang.IFn; if







	linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = A_arbace_go_check_A_const_81.Invoke_O__O(src__0); var arg_719 any = A_arbace_go_check_A_const_106; if linked_716 == nil { annotated__10 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { annotated__10 = linked_716.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_715, arg_718, arg_719) }; var ctx__11 any; var tmp10 any = A_arbace_go_check_A_const_107; var tmp11 any; var root_720 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_722 lang.IFn; if








	linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = lang.PersistentVector_EMPTY.Ref(); if linked_721 == nil { tmp11 = ifn_722.Invoke_O__O(arg_723) } else { tmp11 = linked_721.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_720, arg_723) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_go_check_A_const_108; var tmp14 any; var root_724 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_726 lang.IFn; if








	linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_725 == nil { tmp14 = ifn_726.Invoke_O__O(arg_727) } else { tmp14 = linked_725.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_724, arg_727) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_109; var tmp17 any; var root_728 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_730 lang.IFn; if








	linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = lang.PersistentVector_EMPTY.Ref(); if linked_729 == nil { tmp17 = ifn_730.Invoke_O__O(arg_731) } else { tmp17 = linked_729.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_728, arg_731) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_110; var tmp20 any; var root_732 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_734 lang.IFn; if








	linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = lang.PersistentVector_EMPTY.Ref(); if linked_733 == nil { tmp20 = ifn_734.Invoke_O__O(arg_735) } else { tmp20 = linked_733.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_732, arg_735) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_111; ctx__11 = /*line :151:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)))); var fis__12 any; var root_736 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_738 lang.IFn; if










	linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var tmp23 any = A_arbace_go_check_check_package_fn__1685000100_A_New_O_O(src__0, pkg_scope__7); var tmp24 *jrt.Class; var fncls__747 *jrt.Class = A_arbace_go_check_check_package_fn__1685000100_A_fn_class; if fncls__747 == nil { var fncls__747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_package_fn__1685000100_A_fn_class = fncls__747d; tmp24 = fncls__747d } else { tmp24 = fncls__747 }; arg_739 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_740 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_737 == nil { fis__12 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { fis__12 = linked_737.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }; var root_1183 any =
	A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp26 any = A_arbace_go_check_A_const_158; var tmp27 any = A_arbace_go_check_A_const_159; var tmp28 any = A_arbace_go_check_A_const_160; var tmp29 any = jrt.IdentityHashMap_New(); var tmp30 any = A_arbace_go_check_A_const_161; var tmp31 any = A_arbace_go_check_A_const_61; var tmp32 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)); var tmp33 any = A_arbace_go_check_A_const_162; var tmp34 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var tmp35 any = A_arbace_go_check_A_const_164; var tmp36 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var tmp37 any = A_arbace_go_check_A_const_166; var tmp38 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp39 any = A_arbace_go_check_A_const_167; var tmp40 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var tmp41 any = A_arbace_go_check_A_const_169; var tmp42 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var tmp43 any = A_arbace_go_check_A_const_171; var tmp44 any = A_arbace_go_check_check_package_fn__1685000102_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp45 *jrt.Class; var fncls__1191 *jrt.Class = A_arbace_go_check_check_package_fn__1685000102_A_fn_class; if









	fncls__1191 == nil { var fncls__1191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_package_fn__1685000102_A_fn_class = fncls__1191d; tmp45 = fncls__1191d } else { tmp45 = fncls__1191 }; var tmp46 any = /*line :163:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp47 any = A_arbace_go_check_A_const_173; var tmp48 any = A_arbace_go_check_A_const_174.GetRawRoot__O(); var tmp49 any = A_arbace_go_check_A_const_175; var tmp50 any = A_arbace_go_check_A_const_176.GetRawRoot__O(); var tmp51 any = A_arbace_go_check_A_const_177; arg_1186 = tmp25.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp26, pkg__8, tmp27, errors__9, tmp28, tmp29, tmp30, ctx__11, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, A_arbace_go_check_A_const_178.GetRawRoot__O())))); if linked_1184 == nil { ifn_1185.Invoke_O__O(arg_1186) } else { linked_1184.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1183, arg_1186) }; var tmp52 any; tmp249 := /*line :151:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000104__15 any; var root_1192 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1194 lang.IFn


























		if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = fis__12; if linked_1193 == nil { seq_1685000104__15 = ifn_1194.Invoke_O__O(arg_1195) } else { seq_1685000104__15 = linked_1193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1192, arg_1195) }
//line :151:1
		var chunk_1685000105__16 any; var count_1685000106__17 int64 = 0; var i_1685000107__18 int64 = 0; L1: for {


























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000107__18, count_1685000106__17) { var fi__19 any = lang.Indexed_Cast(chunk_1685000105__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000107__18)); var root_1235 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = fi__19; var arg_1239 any = resolve__1; if linked_1236 == nil { ifn_1237.Invoke_O_O__O(arg_1238, arg_1239) } else { linked_1236.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1235, arg_1238, arg_1239) }; seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, i_1685000107__18 = seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000107__18); continue L1 } else { var temp__1927000414__auto____19 any; var root_1196 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq_1685000104__15; if linked_1197 == nil { temp__1927000414__auto____19 = ifn_1198.Invoke_O__O(arg_1199) } else { temp__1927000414__auto____19 = linked_1197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1196, arg_1199) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_1685000104__20 any = temp__1927000414__auto____19; var tmp53 any; var root_1200 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = seq_1685000104__20; if linked_1201 == nil { tmp53 = ifn_1202.Invoke_O__O(arg_1203) } else { tmp53 = linked_1201.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1200, arg_1203) }; if jrt.J2g_Truth(tmp53) { var c__1927000678__auto____21 any; var root_1204 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = seq_1685000104__20; if linked_1205 == nil { c__1927000678__auto____21 = ifn_1206.Invoke_O__O(arg_1207) } else { c__1927000678__auto____21 = linked_1205.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1204, arg_1207) }; var tmp54 any; var root_1240 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = seq_1685000104__20; if linked_1241 == nil { tmp54 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp54 = linked_1241.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1240, arg_1243) }; seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, i_1685000107__18 = tmp54, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__21 any; var root_1208 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = seq_1685000104__20; if linked_1209 == nil { fi__21 = ifn_1210.Invoke_O__O(arg_1211) } else { fi__21 = linked_1209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1208, arg_1211) }; var root_1244 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = fi__21; var arg_1248 any = resolve__1; if linked_1245 == nil { ifn_1246.Invoke_O_O__O(arg_1247, arg_1248) } else { linked_1245.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1244, arg_1247, arg_1248) }; var tmp55 any; var root_1249 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = seq_1685000104__20; if linked_1250 == nil { tmp55 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp55 = linked_1250.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1249, arg_1252) }; seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, i_1685000107__18 = tmp55, nil, 0, 0; continue L1 } } }
//line :151:1
			break L1 }; var seq_1685000108__15 any; var root_1212 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1214 lang.IFn



























		if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = fis__12; if linked_1213 == nil { seq_1685000108__15 = ifn_1214.Invoke_O__O(arg_1215) } else { seq_1685000108__15 = linked_1213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1212, arg_1215) }
//line :151:1
		var chunk_1685000109__16 any; var count_1685000110__17 int64 = 0; var i_1685000111__18 int64 = 0; L2: for {



























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000111__18, count_1685000110__17) { var fi__19_2 any = lang.Indexed_Cast(chunk_1685000109__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000111__18)); var root_1253 any = A_arbace_go_check_A_const_181.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = fi__19_2; if linked_1254 == nil { ifn_1255.Invoke_O__O(arg_1256) } else { linked_1254.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1253, arg_1256) }; seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, i_1685000111__18 = seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000111__18); continue L2 } else { var temp__1927000414__auto____19_2 any; var root_1216 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = seq_1685000108__15; if linked_1217 == nil { temp__1927000414__auto____19_2 = ifn_1218.Invoke_O__O(arg_1219) } else { temp__1927000414__auto____19_2 = linked_1217.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1216, arg_1219) }; if jrt.J2g_Truth(temp__1927000414__auto____19_2) { var seq_1685000108__20 any = temp__1927000414__auto____19_2; var tmp56 any; var root_1220 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = seq_1685000108__20; if linked_1221 == nil { tmp56 = ifn_1222.Invoke_O__O(arg_1223) } else { tmp56 = linked_1221.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1220, arg_1223) }; if jrt.J2g_Truth(tmp56) { var c__1927000678__auto____21_2 any; var root_1224 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = seq_1685000108__20; if linked_1225 == nil { c__1927000678__auto____21_2 = ifn_1226.Invoke_O__O(arg_1227) } else { c__1927000678__auto____21_2 = linked_1225.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1224, arg_1227) }; var tmp57 any; var root_1257 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = seq_1685000108__20; if linked_1258 == nil { tmp57 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp57 = linked_1258.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1257, arg_1260) }; seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, i_1685000111__18 = tmp57, c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__21_2 any; var root_1228 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = seq_1685000108__20; if linked_1229 == nil { fi__21_2 = ifn_1230.Invoke_O__O(arg_1231) } else { fi__21_2 = linked_1229.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1228, arg_1231) }; var root_1261 any = A_arbace_go_check_A_const_181.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = fi__21_2; if linked_1262 == nil { ifn_1263.Invoke_O__O(arg_1264) } else { linked_1262.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1261, arg_1264) }; var tmp58 any; var root_1265 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = seq_1685000108__20; if linked_1266 == nil { tmp58 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp58 = linked_1266.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1265, arg_1268) }; seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, i_1685000111__18 = tmp58, nil, 0, 0; continue L2 } } }
//line :151:1
			break L2
		}



























		var root_1232 any = A_arbace_go_check_A_const_179.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; if linked_1233 == nil { ifn_1234.Invoke__O() } else { linked_1233.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1232) }
//line :151:1
		var objs__15 any; var root_748 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_750 lang.IFn





























		if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = A_arbace_go_check_A_const_107.Invoke_O__O(ctx__11); if linked_749 == nil { objs__15 = ifn_750.Invoke_O__O(arg_751) } else { objs__15 = linked_749.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_748, arg_751) }
//line :151:1
		var seq_1685000112__16 any; var root_1269 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1271 lang.IFn






























		if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any; var root_1273 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = A_arbace_go_check_A_const_183.GetRawRoot__O(); var arg_1277 any = objs__15; if linked_1274 == nil { arg_1272 = ifn_1275.Invoke_O_O__O(arg_1276, arg_1277) } else { arg_1272 = linked_1274.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1273, arg_1276, arg_1277) }; if linked_1270 == nil { seq_1685000112__16 = ifn_1271.Invoke_O__O(arg_1272) } else { seq_1685000112__16 = linked_1270.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1269, arg_1272) }
//line :151:1
		var chunk_1685000113__17 any; var count_1685000114__18 int64 = 0; var i_1685000115__19 int64 = 0; L3: for {






























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000115__19, count_1685000114__18) { var vec__1685000116__20 any = lang.Indexed_Cast(chunk_1685000113__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000115__19)); var i__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000116__20, lang.RT_IntCast_J__I_NoInit(0), nil); var x__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000116__20, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1446 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = x__22; var arg_1450 any = A_arbace_go_check_A_const_185; var arg_1451 any = i__21; if linked_1447 == nil { ifn_1448.Invoke_O_O_O__O(arg_1449, arg_1450, arg_1451) } else { linked_1447.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1446, arg_1449, arg_1450, arg_1451) }; seq_1685000112__16, chunk_1685000113__17, count_1685000114__18, i_1685000115__19 = seq_1685000112__16, chunk_1685000113__17, count_1685000114__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000115__19); continue L3 } else { var temp__1927000414__auto____20 any; var root_1278 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = seq_1685000112__16; if linked_1279 == nil { temp__1927000414__auto____20 = ifn_1280.Invoke_O__O(arg_1281) } else { temp__1927000414__auto____20 = linked_1279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1278, arg_1281) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000112__21 any = temp__1927000414__auto____20; var tmp59 any; var root_1282 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = seq_1685000112__21; if linked_1283 == nil { tmp59 = ifn_1284.Invoke_O__O(arg_1285) } else { tmp59 = linked_1283.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1282, arg_1285) }; if jrt.J2g_Truth(tmp59) { var c__1927000678__auto____22 any; var root_1286 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = seq_1685000112__21; if linked_1287 == nil { c__1927000678__auto____22 = ifn_1288.Invoke_O__O(arg_1289) } else { c__1927000678__auto____22 = linked_1287.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1286, arg_1289) }; var tmp60 any; var root_1452 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = seq_1685000112__21; if linked_1453 == nil { tmp60 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp60 = linked_1453.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1452, arg_1455) }; seq_1685000112__16, chunk_1685000113__17, count_1685000114__18, i_1685000115__19 = tmp60, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1685000119__22 any; var root_1290 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = seq_1685000112__21; if linked_1291 == nil { vec__1685000119__22 = ifn_1292.Invoke_O__O(arg_1293) } else { vec__1685000119__22 = linked_1291.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1290, arg_1293) }; var i__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000119__22, lang.RT_IntCast_J__I_NoInit(0), nil); var x__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000119__22, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1456 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = x__24; var arg_1460 any = A_arbace_go_check_A_const_185; var arg_1461 any = i__23; if linked_1457 == nil { ifn_1458.Invoke_O_O_O__O(arg_1459, arg_1460, arg_1461) } else { linked_1457.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1456, arg_1459, arg_1460, arg_1461) }; var tmp61 any; var root_1462 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = seq_1685000112__21; if linked_1463 == nil { tmp61 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp61 = linked_1463.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1462, arg_1465) }; seq_1685000112__16, chunk_1685000113__17, count_1685000114__18, i_1685000115__19 = tmp61, nil, 0, 0; continue L3 } } }
//line :151:1
			break L3 }; var seq_1685000122__16 any; var root_1294 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1296 lang.IFn
































		if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = objs__15; if linked_1295 == nil { seq_1685000122__16 = ifn_1296.Invoke_O__O(arg_1297) } else { seq_1685000122__16 = linked_1295.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1294, arg_1297) }
//line :151:1
		var chunk_1685000123__17 any; var count_1685000124__18 int64 = 0; var i_1685000125__19 int64 = 0; L4: for {
































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000125__19, count_1685000124__18) { var x__20 any = lang.Indexed_Cast(chunk_1685000123__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000125__19)); var tmp62 any; var and__1927000168__auto____21 bool; var tmp63 any = A_arbace_go_check_A_const_54; var tmp64 any; var root_1298 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = x__20; var arg_1302 any = A_arbace_go_check_A_const_93; if linked_1299 == nil { tmp64 = ifn_1300.Invoke_O_O__O(arg_1301, arg_1302) } else { tmp64 = linked_1299.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1298, arg_1301, arg_1302) }; and__1927000168__auto____21 = lang.Util_Equiv_O_O__Z_NoInit(tmp63, tmp64); if and__1927000168__auto____21 { var root_1303 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any; var root_1307 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = x__20; var arg_1311 any = A_arbace_go_check_A_const_184; if linked_1308 == nil { arg_1306 = ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { arg_1306 = linked_1308.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) }; if linked_1304 == nil { tmp62 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp62 = linked_1304.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1303, arg_1306) } } else { tmp62 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }; if jrt.J2g_Truth(tmp62) { var root_1466 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = x__20; if linked_1467 == nil { ifn_1468.Invoke_O__O(arg_1469) } else { linked_1467.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1466, arg_1469) }; seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, i_1685000125__19 = seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000125__19); continue L4 } else { seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, i_1685000125__19 = seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000125__19); continue L4 } } else { var temp__1927000414__auto____20_2 any; var root_1312 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = seq_1685000122__16; if linked_1313 == nil { temp__1927000414__auto____20_2 = ifn_1314.Invoke_O__O(arg_1315) } else { temp__1927000414__auto____20_2 = linked_1313.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1312, arg_1315) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000122__21 any = temp__1927000414__auto____20_2; var tmp65 any; var root_1316 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = seq_1685000122__21; if linked_1317 == nil { tmp65 = ifn_1318.Invoke_O__O(arg_1319) } else { tmp65 = linked_1317.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1316, arg_1319) }; if jrt.J2g_Truth(tmp65) { var c__1927000678__auto____22_2 any; var root_1320 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = seq_1685000122__21; if linked_1321 == nil { c__1927000678__auto____22_2 = ifn_1322.Invoke_O__O(arg_1323) } else { c__1927000678__auto____22_2 = linked_1321.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1320, arg_1323) }; var tmp66 any; var root_1470 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = seq_1685000122__21; if linked_1471 == nil { tmp66 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp66 = linked_1471.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1470, arg_1473) }; seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, i_1685000125__19 = tmp66, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__22_2 any; var root_1324 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = seq_1685000122__21; if linked_1325 == nil { x__22_2 = ifn_1326.Invoke_O__O(arg_1327) } else { x__22_2 = linked_1325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1324, arg_1327) }; var tmp67 any; var and__1927000168__auto____23 bool; var tmp68 any = A_arbace_go_check_A_const_54; var tmp69 any; var root_1328 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = x__22_2; var arg_1332 any = A_arbace_go_check_A_const_93; if linked_1329 == nil { tmp69 = ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { tmp69 = linked_1329.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; and__1927000168__auto____23 = lang.Util_Equiv_O_O__Z_NoInit(tmp68, tmp69); if and__1927000168__auto____23 { var root_1333 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any; var root_1337 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = x__22_2; var arg_1341 any = A_arbace_go_check_A_const_184; if linked_1338 == nil { arg_1336 = ifn_1339.Invoke_O_O__O(arg_1340, arg_1341) } else { arg_1336 = linked_1338.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1337, arg_1340, arg_1341) }; if linked_1334 == nil { tmp67 = ifn_1335.Invoke_O__O(arg_1336) } else { tmp67 = linked_1334.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1333, arg_1336) } } else { tmp67 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }; if jrt.J2g_Truth(tmp67) { var root_1474 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = x__22_2; if linked_1475 == nil { ifn_1476.Invoke_O__O(arg_1477) } else { linked_1475.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1474, arg_1477) }; var tmp70 any; var root_1478 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = seq_1685000122__21; if linked_1479 == nil { tmp70 = ifn_1480.Invoke_O__O(arg_1481) } else { tmp70 = linked_1479.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1478, arg_1481) }; seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, i_1685000125__19 = tmp70, nil, 0, 0; continue L4 } else { var tmp71 any; var root_1482 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = seq_1685000122__21; if linked_1483 == nil { tmp71 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp71 = linked_1483.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1482, arg_1485) }; seq_1685000122__16, chunk_1685000123__17, count_1685000124__18, i_1685000125__19 = tmp71, nil, 0, 0; continue L4 } } } }
//line :151:1
			break L4 }; var seq_1685000126__16 any; var root_1342 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1344 lang.IFn

































		if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = objs__15; if linked_1343 == nil { seq_1685000126__16 = ifn_1344.Invoke_O__O(arg_1345) } else { seq_1685000126__16 = linked_1343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1342, arg_1345) }
//line :151:1
		var chunk_1685000127__17 any; var count_1685000128__18 int64 = 0; var i_1685000129__19 int64 = 0; L5: for {

































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000129__19, count_1685000128__18) { var x__20_2 any = lang.Indexed_Cast(chunk_1685000127__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000129__19)); var tmp72 any; var and__1927000168__auto____21_2 bool; var tmp73 any = A_arbace_go_check_A_const_54; var tmp74 any; var root_1346 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = x__20_2; var arg_1350 any = A_arbace_go_check_A_const_93; if linked_1347 == nil { tmp74 = ifn_1348.Invoke_O_O__O(arg_1349, arg_1350) } else { tmp74 = linked_1347.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1346, arg_1349, arg_1350) }; and__1927000168__auto____21_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp73, tmp74); if and__1927000168__auto____21_2 { var root_1351 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = x__20_2; var arg_1355 any = A_arbace_go_check_A_const_184; if linked_1352 == nil { tmp72 = ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { tmp72 = linked_1352.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) } } else { tmp72 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }; if jrt.J2g_Truth(tmp72) { var root_1486 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = x__20_2; if linked_1487 == nil { ifn_1488.Invoke_O__O(arg_1489) } else { linked_1487.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1486, arg_1489) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000129__19); continue L5 } else { seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000129__19); continue L5 } } else { var temp__1927000414__auto____20_3 any; var root_1356 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = seq_1685000126__16; if linked_1357 == nil { temp__1927000414__auto____20_3 = ifn_1358.Invoke_O__O(arg_1359) } else { temp__1927000414__auto____20_3 = linked_1357.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1356, arg_1359) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000126__21 any = temp__1927000414__auto____20_3; var tmp75 any; var root_1360 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = seq_1685000126__21; if linked_1361 == nil { tmp75 = ifn_1362.Invoke_O__O(arg_1363) } else { tmp75 = linked_1361.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1360, arg_1363) }; if jrt.J2g_Truth(tmp75) { var c__1927000678__auto____22_3 any; var root_1364 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = seq_1685000126__21; if linked_1365 == nil { c__1927000678__auto____22_3 = ifn_1366.Invoke_O__O(arg_1367) } else { c__1927000678__auto____22_3 = linked_1365.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1364, arg_1367) }; var tmp76 any; var root_1490 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = seq_1685000126__21; if linked_1491 == nil { tmp76 = ifn_1492.Invoke_O__O(arg_1493) } else { tmp76 = linked_1491.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1490, arg_1493) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = tmp76, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var x__22_3 any; var root_1368 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = seq_1685000126__21; if linked_1369 == nil { x__22_3 = ifn_1370.Invoke_O__O(arg_1371) } else { x__22_3 = linked_1369.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1368, arg_1371) }; var tmp77 any; var and__1927000168__auto____23_2 bool; var tmp78 any = A_arbace_go_check_A_const_54; var tmp79 any; var root_1372 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = x__22_3; var arg_1376 any = A_arbace_go_check_A_const_93; if linked_1373 == nil { tmp79 = ifn_1374.Invoke_O_O__O(arg_1375, arg_1376) } else { tmp79 = linked_1373.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1372, arg_1375, arg_1376) }; and__1927000168__auto____23_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp78, tmp79); if and__1927000168__auto____23_2 { var root_1377 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = x__22_3; var arg_1381 any = A_arbace_go_check_A_const_184; if linked_1378 == nil { tmp77 = ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { tmp77 = linked_1378.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) } } else { tmp77 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23_2).Ref() }; if jrt.J2g_Truth(tmp77) { var root_1494 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = x__22_3; if linked_1495 == nil { ifn_1496.Invoke_O__O(arg_1497) } else { linked_1495.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1494, arg_1497) }; var tmp80 any; var root_1498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = seq_1685000126__21; if linked_1499 == nil { tmp80 = ifn_1500.Invoke_O__O(arg_1501) } else { tmp80 = linked_1499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1498, arg_1501) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = tmp80, nil, 0, 0; continue L5 } else { var tmp81 any; var root_1502 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = seq_1685000126__21; if linked_1503 == nil { tmp81 = ifn_1504.Invoke_O__O(arg_1505) } else { tmp81 = linked_1503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1502, arg_1505) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = tmp81, nil, 0, 0; continue L5 } } } }
//line :151:1
			break L5 }; var seq_1685000130__16 any; var root_1382 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1384 lang.IFn


































		if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = objs__15; if linked_1383 == nil { seq_1685000130__16 = ifn_1384.Invoke_O__O(arg_1385) } else { seq_1685000130__16 = linked_1383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1382, arg_1385) }
//line :151:1
		var chunk_1685000131__17 any; var count_1685000132__18 int64 = 0; var i_1685000133__19 int64 = 0; L6: for {


































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000133__19, count_1685000132__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1685000131__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000133__19)); var tmp82 any; var root_1386 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = A_arbace_go_check_A_const_54; var arg_1390 any; var root_1391 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = x__20_3; var arg_1395 any = A_arbace_go_check_A_const_93; if linked_1392 == nil { arg_1390 = ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { arg_1390 = linked_1392.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) }; if linked_1387 == nil { tmp82 = ifn_1388.Invoke_O_O__O(arg_1389, arg_1390) } else { tmp82 = linked_1387.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1386, arg_1389, arg_1390) }; if jrt.J2g_Truth(tmp82) { var root_1506 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = x__20_3; if linked_1507 == nil { ifn_1508.Invoke_O__O(arg_1509) } else { linked_1507.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1506, arg_1509) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000133__19); continue L6 } else { seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000133__19); continue L6 } } else { var temp__1927000414__auto____20_4 any; var root_1396 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = seq_1685000130__16; if linked_1397 == nil { temp__1927000414__auto____20_4 = ifn_1398.Invoke_O__O(arg_1399) } else { temp__1927000414__auto____20_4 = linked_1397.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000130__21 any = temp__1927000414__auto____20_4; var tmp83 any; var root_1400 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = seq_1685000130__21; if linked_1401 == nil { tmp83 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp83 = linked_1401.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1400, arg_1403) }; if jrt.J2g_Truth(tmp83) { var c__1927000678__auto____22_4 any; var root_1404 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = seq_1685000130__21; if linked_1405 == nil { c__1927000678__auto____22_4 = ifn_1406.Invoke_O__O(arg_1407) } else { c__1927000678__auto____22_4 = linked_1405.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1404, arg_1407) }; var tmp84 any; var root_1510 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = seq_1685000130__21; if linked_1511 == nil { tmp84 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp84 = linked_1511.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1510, arg_1513) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = tmp84, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__22_4 any; var root_1408 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = seq_1685000130__21; if linked_1409 == nil { x__22_4 = ifn_1410.Invoke_O__O(arg_1411) } else { x__22_4 = linked_1409.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1408, arg_1411) }; var tmp85 any; var root_1412 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = A_arbace_go_check_A_const_54; var arg_1416 any; var root_1417 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = x__22_4; var arg_1421 any = A_arbace_go_check_A_const_93; if linked_1418 == nil { arg_1416 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { arg_1416 = linked_1418.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; if linked_1413 == nil { tmp85 = ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { tmp85 = linked_1413.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) }; if jrt.J2g_Truth(tmp85) { var root_1514 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = x__22_4; if linked_1515 == nil { ifn_1516.Invoke_O__O(arg_1517) } else { linked_1515.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1514, arg_1517) }; var tmp86 any; var root_1518 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = seq_1685000130__21; if linked_1519 == nil { tmp86 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp86 = linked_1519.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1518, arg_1521) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = tmp86, nil, 0, 0; continue L6 } else { var tmp87 any; var root_1522 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = seq_1685000130__21; if linked_1523 == nil { tmp87 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp87 = linked_1523.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1522, arg_1525) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = tmp87, nil, 0, 0; continue L6 } } } }
//line :151:1
			break L6 }; var seq_1685000134__16 any; var root_1422 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1424 lang.IFn




































		if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any; var root_1426 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = A_arbace_go_check_A_const_109.Invoke_O__O(ctx__11); if linked_1427 == nil { arg_1425 = ifn_1428.Invoke_O__O(arg_1429) } else { arg_1425 = linked_1427.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1426, arg_1429) }; if linked_1423 == nil { seq_1685000134__16 = ifn_1424.Invoke_O__O(arg_1425) } else { seq_1685000134__16 = linked_1423.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1422, arg_1425) }
//line :151:1
		var chunk_1685000135__17 any; var count_1685000136__18 int64 = 0; var i_1685000137__19 int64 = 0; L7: for {




































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000137__19, count_1685000136__18) { var x__20_4 any = lang.Indexed_Cast(chunk_1685000135__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000137__19)); var root_1526 any = A_arbace_go_check_A_const_186.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = x__20_4; if linked_1527 == nil { ifn_1528.Invoke_O__O(arg_1529) } else { linked_1527.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1526, arg_1529) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000137__19); continue L7 } else { var temp__1927000414__auto____20_5 any; var root_1430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = seq_1685000134__16; if linked_1431 == nil { temp__1927000414__auto____20_5 = ifn_1432.Invoke_O__O(arg_1433) } else { temp__1927000414__auto____20_5 = linked_1431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1430, arg_1433) }; if jrt.J2g_Truth(temp__1927000414__auto____20_5) { var seq_1685000134__21 any = temp__1927000414__auto____20_5; var tmp88 any; var root_1434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = seq_1685000134__21; if linked_1435 == nil { tmp88 = ifn_1436.Invoke_O__O(arg_1437) } else { tmp88 = linked_1435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1434, arg_1437) }; if jrt.J2g_Truth(tmp88) { var c__1927000678__auto____22_5 any; var root_1438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = seq_1685000134__21; if linked_1439 == nil { c__1927000678__auto____22_5 = ifn_1440.Invoke_O__O(arg_1441) } else { c__1927000678__auto____22_5 = linked_1439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1438, arg_1441) }; var tmp89 any; var root_1530 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = seq_1685000134__21; if linked_1531 == nil { tmp89 = ifn_1532.Invoke_O__O(arg_1533) } else { tmp89 = linked_1531.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1530, arg_1533) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = tmp89, c__1927000678__auto____22_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22_5 any; var root_1442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = seq_1685000134__21; if linked_1443 == nil { x__22_5 = ifn_1444.Invoke_O__O(arg_1445) } else { x__22_5 = linked_1443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1442, arg_1445) }; var root_1534 any = A_arbace_go_check_A_const_186.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = x__22_5; if linked_1535 == nil { ifn_1536.Invoke_O__O(arg_1537) } else { linked_1535.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1534, arg_1537) }; var tmp90 any; var root_1538 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = seq_1685000134__21; if linked_1539 == nil { tmp90 = ifn_1540.Invoke_O__O(arg_1541) } else { tmp90 = linked_1539.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1538, arg_1541) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = tmp90, nil, 0, 0; continue L7 } } }
//line :151:1
			break L7 }; var decls__16 any; var root_752 any = A_arbace_go_check_A_const_115.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_754 lang.IFn





































		if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp91 any = A_arbace_go_check_check_package_fn__1685000138_A_New(); var tmp92 *jrt.Class; var fncls__766 *jrt.Class = A_arbace_go_check_check_package_fn__1685000138_A_fn_class; if fncls__766 == nil { var fncls__766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_check_package_fn__1685000138_A_fn_class = fncls__766d; tmp92 = fncls__766d } else { tmp92 = fncls__766 }; arg_759 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp91, tmp92, nil); var arg_760 any = objs__15; if linked_757 == nil { arg_755 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { arg_755 = linked_757.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if linked_753 == nil { decls__16 = ifn_754.Invoke_O__O(arg_755) } else { decls__16 = linked_753.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_752, arg_755) }
//line :151:1
		var seq_1685000140__17 any; var root_1542 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1544 lang.IFn






































		if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = decls__16; if linked_1543 == nil { seq_1685000140__17 = ifn_1544.Invoke_O__O(arg_1545) } else { seq_1685000140__17 = linked_1543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1542, arg_1545) }
//line :151:1
		var chunk_1685000141__18 any; var count_1685000142__19 int64 = 0; var i_1685000143__20 int64 = 0; L8: for {






































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000143__20, count_1685000142__19) { var d__21 any = lang.Indexed_Cast(chunk_1685000141__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000143__20)); L9: for { var ls__22 any; var tmp93 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp94 any; var root_1638 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1640 lang.IFn

				if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = d__21; if linked_1639 == nil { tmp94 = ifn_1640.Invoke_O__O(arg_1641) } else { tmp94 = linked_1639.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1638, arg_1641) }; ls__22 = tmp93.Invoke_O__O(tmp94)
				var tmp95 any; var root_1642 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = ls__22; if linked_1643 == nil { tmp95 = ifn_1644.Invoke_O__O(arg_1645) } else { tmp95 = linked_1643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1642, arg_1645) }; if jrt.J2g_Truth(tmp95) {
					var tmp96 *lang.Volatile = lang.Volatile_Cast(d__21); var tmp97 any; var root_1646 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = jrt.NN(lang.Volatile_Cast(d__21)).Deref__O(); var arg_1650 any = A_arbace_go_check_A_const_188; var arg_1651 any = lang.PersistentVector_EMPTY.Ref(); if linked_1647 == nil { tmp97 = ifn_1648.Invoke_O_O_O__O(arg_1649, arg_1650, arg_1651) } else { tmp97 = linked_1647.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1646, arg_1649, arg_1650, arg_1651) }; jrt.NN(tmp96).Reset_O__O(tmp97)
					var root_1698 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1700 lang.IFn; if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any; var tmp98 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp99 any = A_arbace_go_check_A_const_193; var tmp100 any = A_arbace_go_check_A_const_194; var tmp101 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp102 any; var root_1711 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = d__21; if linked_1712 == nil { tmp102 = ifn_1713.Invoke_O__O(arg_1714) } else { tmp102 = linked_1712.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1711, arg_1714) }; var tmp103 any = tmp101.Invoke_O__O(tmp102); var tmp104 any = A_arbace_go_check_A_const_195; var tmp105 any; var G__1685000144__23_ any; var tmp106 *lang.Keyword = A_arbace_go_check_A_const_196; var tmp107 any; var root_1715 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = d__21; if linked_1716 == nil { tmp107 = ifn_1717.Invoke_O__O(arg_1718) } else { tmp107 = linked_1716.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1715, arg_1718) }; G__1685000144__23_ = tmp106.Invoke_O__O(tmp107); if lang.Util_Identical_O_O__Z_NoInit(G__1685000144__23_, nil) { tmp105 = nil } else { var root_1719 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = G__1685000144__23_; var arg_1723 any = A_arbace_go_check_A_const_78; if linked_1720 == nil { tmp105 = ifn_1721.Invoke_O_O__O(arg_1722, arg_1723) } else { tmp105 = linked_1720.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1719, arg_1722, arg_1723) } }; arg_1701 = tmp98.Invoke_O_O_O_O_O_O__O(tmp99, d__21, tmp100, tmp103, tmp104, tmp105); if linked_1699 == nil { ifn_1700.Invoke_O__O(arg_1701) } else { linked_1699.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1698, arg_1701) }; var tmp108 any = A_arbace_go_check_check_package_fn__1685000145_A_New_O_O(d__21, ls__22); var tmp109 *jrt.Class; var fncls__1697 *jrt.Class = A_arbace_go_check_check_package_fn__1685000145_A_fn_class; if fncls__1697 == nil { var fncls__1697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000145_A_fn_class = fncls__1697d; tmp109 = fncls__1697d } else { tmp109 = fncls__1697 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp108, tmp109, nil).Invoke__O()


					continue L9 }
//line :190:1
				break L9 }; seq_1685000140__17, chunk_1685000141__18, count_1685000142__19, i_1685000143__20 = seq_1685000140__17, chunk_1685000141__18, count_1685000142__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000143__20); continue L8 } else { var temp__1927000414__auto____21 any; var root_1546 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = seq_1685000140__17; if linked_1547 == nil { temp__1927000414__auto____21 = ifn_1548.Invoke_O__O(arg_1549) } else { temp__1927000414__auto____21 = linked_1547.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1546, arg_1549) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000140__22 any = temp__1927000414__auto____21; var tmp110 any; var root_1550 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = seq_1685000140__22; if linked_1551 == nil { tmp110 = ifn_1552.Invoke_O__O(arg_1553) } else { tmp110 = linked_1551.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1550, arg_1553) }; if jrt.J2g_Truth(tmp110) { var c__1927000678__auto____23 any; var root_1554 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = seq_1685000140__22; if linked_1555 == nil { c__1927000678__auto____23 = ifn_1556.Invoke_O__O(arg_1557) } else { c__1927000678__auto____23 = linked_1555.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1554, arg_1557) }; var tmp111 any; var root_1724 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = seq_1685000140__22; if linked_1725 == nil { tmp111 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp111 = linked_1725.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1724, arg_1727) }; seq_1685000140__17, chunk_1685000141__18, count_1685000142__19, i_1685000143__20 = tmp111, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var d__23 any; var root_1558 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = seq_1685000140__22; if linked_1559 == nil { d__23 = ifn_1560.Invoke_O__O(arg_1561) } else { d__23 = linked_1559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1558, arg_1561) }; L10: for { var ls__24 any; var tmp112 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp113 any; var root_1728 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1730 lang.IFn

					if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = d__23; if linked_1729 == nil { tmp113 = ifn_1730.Invoke_O__O(arg_1731) } else { tmp113 = linked_1729.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1728, arg_1731) }; ls__24 = tmp112.Invoke_O__O(tmp113)
					var tmp114 any; var root_1732 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = ls__24; if linked_1733 == nil { tmp114 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp114 = linked_1733.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1732, arg_1735) }; if jrt.J2g_Truth(tmp114) {
						var tmp115 *lang.Volatile = lang.Volatile_Cast(d__23); var tmp116 any; var root_1736 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = jrt.NN(lang.Volatile_Cast(d__23)).Deref__O(); var arg_1740 any = A_arbace_go_check_A_const_188; var arg_1741 any = lang.PersistentVector_EMPTY.Ref(); if linked_1737 == nil { tmp116 = ifn_1738.Invoke_O_O_O__O(arg_1739, arg_1740, arg_1741) } else { tmp116 = linked_1737.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1736, arg_1739, arg_1740, arg_1741) }; jrt.NN(tmp115).Reset_O__O(tmp116)
						var root_1788 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any; var tmp117 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp118 any = A_arbace_go_check_A_const_193; var tmp119 any = A_arbace_go_check_A_const_194; var tmp120 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp121 any; var root_1801 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = d__23; if linked_1802 == nil { tmp121 = ifn_1803.Invoke_O__O(arg_1804) } else { tmp121 = linked_1802.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1801, arg_1804) }; var tmp122 any = tmp120.Invoke_O__O(tmp121); var tmp123 any = A_arbace_go_check_A_const_195; var tmp124 any; var G__1685000151__25_ any; var tmp125 *lang.Keyword = A_arbace_go_check_A_const_196; var tmp126 any; var root_1805 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = d__23; if linked_1806 == nil { tmp126 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp126 = linked_1806.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1805, arg_1808) }; G__1685000151__25_ = tmp125.Invoke_O__O(tmp126); if lang.Util_Identical_O_O__Z_NoInit(G__1685000151__25_, nil) { tmp124 = nil } else { var root_1809 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = G__1685000151__25_; var arg_1813 any = A_arbace_go_check_A_const_78; if linked_1810 == nil { tmp124 = ifn_1811.Invoke_O_O__O(arg_1812, arg_1813) } else { tmp124 = linked_1810.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1809, arg_1812, arg_1813) } }; arg_1791 = tmp117.Invoke_O_O_O_O_O_O__O(tmp118, d__23, tmp119, tmp122, tmp123, tmp124); if linked_1789 == nil { ifn_1790.Invoke_O__O(arg_1791) } else { linked_1789.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1788, arg_1791) }; var tmp127 any = A_arbace_go_check_check_package_fn__1685000152_A_New_O_O(d__23, ls__24); var tmp128 *jrt.Class; var fncls__1787 *jrt.Class = A_arbace_go_check_check_package_fn__1685000152_A_fn_class; if fncls__1787 == nil { var fncls__1787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000152_A_fn_class = fncls__1787d; tmp128 = fncls__1787d } else { tmp128 = fncls__1787 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp127, tmp128, nil).Invoke__O()


						continue L10 }
//line :190:1
					break L10 }; var tmp129 any; var root_1814 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = seq_1685000140__22; if linked_1815 == nil { tmp129 = ifn_1816.Invoke_O__O(arg_1817) } else { tmp129 = linked_1815.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1814, arg_1817) }; seq_1685000140__17, chunk_1685000141__18, count_1685000142__19, i_1685000143__20 = tmp129, nil, 0, 0; continue L8 } } }
//line :151:1
			break L8 }; var seq_1685000158__17 any; var root_1562 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1564 lang.IFn
















































		if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = decls__16; if linked_1563 == nil { seq_1685000158__17 = ifn_1564.Invoke_O__O(arg_1565) } else { seq_1685000158__17 = linked_1563.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1562, arg_1565) }
//line :151:1
		var chunk_1685000159__18 any; var count_1685000160__19 int64 = 0; var i_1685000161__20 int64 = 0; L11: for {
















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000161__20, count_1685000160__19) { var d__21_2 any = lang.Indexed_Cast(chunk_1685000159__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000161__20)); var tmp130 *lang.Keyword = A_arbace_go_check_A_const_187; var tmp131 any; var root_1566 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = d__21_2; if linked_1567 == nil { tmp131 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp131 = linked_1567.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1566, arg_1569) }; if jrt.J2g_Truth(tmp130.Invoke_O__O(tmp131)) {
				var root_1830 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any; var tmp132 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp133 any = A_arbace_go_check_A_const_193; var tmp134 any = A_arbace_go_check_A_const_194; var tmp135 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp136 any; var root_1841 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = d__21_2; if linked_1842 == nil { tmp136 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp136 = linked_1842.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1841, arg_1844) }; arg_1833 = tmp132.Invoke_O_O_O_O__O(tmp133, d__21_2, tmp134, tmp135.Invoke_O__O(tmp136)); if linked_1831 == nil { ifn_1832.Invoke_O__O(arg_1833) } else { linked_1831.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1830, arg_1833) }; var tmp137 any = A_arbace_go_check_check_package_fn__1685000162_A_New_O(d__21_2); var tmp138 *jrt.Class; var fncls__1829 *jrt.Class = A_arbace_go_check_check_package_fn__1685000162_A_fn_class; if fncls__1829 == nil { var fncls__1829d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_check_check_package_fn__1685000162_A_fn_class = fncls__1829d; tmp138 = fncls__1829d } else { tmp138 = fncls__1829 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp137, tmp138, nil).Invoke__O()
//line :200:1
				seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, i_1685000161__20 = seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000161__20); continue L11 } else { seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, i_1685000161__20 = seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000161__20); continue L11 } } else { var temp__1927000414__auto____21_2 any; var root_1570 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = seq_1685000158__17; if linked_1571 == nil { temp__1927000414__auto____21_2 = ifn_1572.Invoke_O__O(arg_1573) } else { temp__1927000414__auto____21_2 = linked_1571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1570, arg_1573) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000158__22 any = temp__1927000414__auto____21_2; var tmp139 any; var root_1574 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = seq_1685000158__22; if linked_1575 == nil { tmp139 = ifn_1576.Invoke_O__O(arg_1577) } else { tmp139 = linked_1575.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1574, arg_1577) }; if jrt.J2g_Truth(tmp139) { var c__1927000678__auto____23_2 any; var root_1578 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = seq_1685000158__22; if linked_1579 == nil { c__1927000678__auto____23_2 = ifn_1580.Invoke_O__O(arg_1581) } else { c__1927000678__auto____23_2 = linked_1579.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1578, arg_1581) }; var tmp140 any; var root_1845 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = seq_1685000158__22; if linked_1846 == nil { tmp140 = ifn_1847.Invoke_O__O(arg_1848) } else { tmp140 = linked_1846.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1845, arg_1848) }; seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, i_1685000161__20 = tmp140, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var d__23_2 any; var root_1582 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = seq_1685000158__22; if linked_1583 == nil { d__23_2 = ifn_1584.Invoke_O__O(arg_1585) } else { d__23_2 = linked_1583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1582, arg_1585) }; var tmp141 *lang.Keyword = A_arbace_go_check_A_const_187; var tmp142 any; var root_1586 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = d__23_2; if linked_1587 == nil { tmp142 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp142 = linked_1587.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1586, arg_1589) }; if jrt.J2g_Truth(tmp141.Invoke_O__O(tmp142)) {
					var root_1861 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any; var tmp143 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp144 any = A_arbace_go_check_A_const_193; var tmp145 any = A_arbace_go_check_A_const_194; var tmp146 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp147 any; var root_1872 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = d__23_2; if linked_1873 == nil { tmp147 = ifn_1874.Invoke_O__O(arg_1875) } else { tmp147 = linked_1873.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1872, arg_1875) }; arg_1864 = tmp143.Invoke_O_O_O_O__O(tmp144, d__23_2, tmp145, tmp146.Invoke_O__O(tmp147)); if linked_1862 == nil { ifn_1863.Invoke_O__O(arg_1864) } else { linked_1862.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1861, arg_1864) }; var tmp148 any = A_arbace_go_check_check_package_fn__1685000164_A_New_O(d__23_2); var tmp149 *jrt.Class; var fncls__1860 *jrt.Class = A_arbace_go_check_check_package_fn__1685000164_A_fn_class; if fncls__1860 == nil { var fncls__1860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_check_check_package_fn__1685000164_A_fn_class = fncls__1860d; tmp149 = fncls__1860d } else { tmp149 = fncls__1860 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp148, tmp149, nil).Invoke__O()
//line :200:1
					var tmp150 any; var root_1876 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = seq_1685000158__22; if linked_1877 == nil { tmp150 = ifn_1878.Invoke_O__O(arg_1879) } else { tmp150 = linked_1877.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1876, arg_1879) }; seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, i_1685000161__20 = tmp150, nil, 0, 0; continue L11 } else { var tmp151 any; var root_1880 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = seq_1685000158__22; if linked_1881 == nil { tmp151 = ifn_1882.Invoke_O__O(arg_1883) } else { tmp151 = linked_1881.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1880, arg_1883) }; seq_1685000158__17, chunk_1685000159__18, count_1685000160__19, i_1685000161__20 = tmp151, nil, 0, 0; continue L11 } } } }
//line :151:1
			break L11 }; var seq_1685000166__17 any; var root_1590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1592 lang.IFn




















































		if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = decls__16; if linked_1591 == nil { seq_1685000166__17 = ifn_1592.Invoke_O__O(arg_1593) } else { seq_1685000166__17 = linked_1591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1590, arg_1593) }
//line :151:1
		var chunk_1685000167__18 any; var count_1685000168__19 int64 = 0; var i_1685000169__20 int64 = 0; L12: for {




















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000169__20, count_1685000168__19) { var d__21_3 any = lang.Indexed_Cast(chunk_1685000167__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000169__20)); var tmp152 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp153 any; var root_1594 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = d__21_3; if linked_1595 == nil { tmp153 = ifn_1596.Invoke_O__O(arg_1597) } else { tmp153 = linked_1595.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1594, arg_1597) }; if jrt.J2g_Truth(tmp152.Invoke_O__O(tmp153)) {
				var root_1884 any = A_arbace_go_check_A_const_198.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any; var tmp154 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp155 any; var root_1889 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = d__21_3; if linked_1890 == nil { tmp155 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp155 = linked_1890.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1889, arg_1892) }; arg_1887 = tmp154.Invoke_O__O(tmp155); var arg_1888 any; var tmp156 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp157 any; var root_1893 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = d__21_3; if linked_1894 == nil { tmp157 = ifn_1895.Invoke_O__O(arg_1896) } else { tmp157 = linked_1894.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1893, arg_1896) }; arg_1888 = tmp156.Invoke_O__O(tmp157); if linked_1885 == nil { ifn_1886.Invoke_O_O__O(arg_1887, arg_1888) } else { linked_1885.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_1884, arg_1887, arg_1888) }
//line :204:1
				seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, i_1685000169__20 = seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000169__20); continue L12 } else { seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, i_1685000169__20 = seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000169__20); continue L12 } } else { var temp__1927000414__auto____21_3 any; var root_1598 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = seq_1685000166__17; if linked_1599 == nil { temp__1927000414__auto____21_3 = ifn_1600.Invoke_O__O(arg_1601) } else { temp__1927000414__auto____21_3 = linked_1599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1598, arg_1601) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000166__22 any = temp__1927000414__auto____21_3; var tmp158 any; var root_1602 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = seq_1685000166__22; if linked_1603 == nil { tmp158 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp158 = linked_1603.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1602, arg_1605) }; if jrt.J2g_Truth(tmp158) { var c__1927000678__auto____23_3 any; var root_1606 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = seq_1685000166__22; if linked_1607 == nil { c__1927000678__auto____23_3 = ifn_1608.Invoke_O__O(arg_1609) } else { c__1927000678__auto____23_3 = linked_1607.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1606, arg_1609) }; var tmp159 any; var root_1897 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = seq_1685000166__22; if linked_1898 == nil { tmp159 = ifn_1899.Invoke_O__O(arg_1900) } else { tmp159 = linked_1898.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1897, arg_1900) }; seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, i_1685000169__20 = tmp159, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__23_3 any; var root_1610 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = seq_1685000166__22; if linked_1611 == nil { d__23_3 = ifn_1612.Invoke_O__O(arg_1613) } else { d__23_3 = linked_1611.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1610, arg_1613) }; var tmp160 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp161 any; var root_1614 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = d__23_3; if linked_1615 == nil { tmp161 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp161 = linked_1615.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1614, arg_1617) }; if jrt.J2g_Truth(tmp160.Invoke_O__O(tmp161)) {
					var root_1901 any = A_arbace_go_check_A_const_198.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any; var tmp162 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp163 any; var root_1906 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = d__23_3; if linked_1907 == nil { tmp163 = ifn_1908.Invoke_O__O(arg_1909) } else { tmp163 = linked_1907.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1906, arg_1909) }; arg_1904 = tmp162.Invoke_O__O(tmp163); var arg_1905 any; var tmp164 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp165 any; var root_1910 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = d__23_3; if linked_1911 == nil { tmp165 = ifn_1912.Invoke_O__O(arg_1913) } else { tmp165 = linked_1911.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1910, arg_1913) }; arg_1905 = tmp164.Invoke_O__O(tmp165); if linked_1902 == nil { ifn_1903.Invoke_O_O__O(arg_1904, arg_1905) } else { linked_1902.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_1901, arg_1904, arg_1905) }
//line :204:1
					var tmp166 any; var root_1914 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = seq_1685000166__22; if linked_1915 == nil { tmp166 = ifn_1916.Invoke_O__O(arg_1917) } else { tmp166 = linked_1915.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1914, arg_1917) }; seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, i_1685000169__20 = tmp166, nil, 0, 0; continue L12 } else { var tmp167 any; var root_1918 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = seq_1685000166__22; if linked_1919 == nil { tmp167 = ifn_1920.Invoke_O__O(arg_1921) } else { tmp167 = linked_1919.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1918, arg_1921) }; seq_1685000166__17, chunk_1685000167__18, count_1685000168__19, i_1685000169__20 = tmp167, nil, 0, 0; continue L12 } } } }
//line :151:1
			break L12 }; var seq_1685000170__17 any; var root_1618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1620 lang.IFn






















































		if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = fis__12; if linked_1619 == nil { seq_1685000170__17 = ifn_1620.Invoke_O__O(arg_1621) } else { seq_1685000170__17 = linked_1619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1618, arg_1621) }
//line :151:1
		var chunk_1685000171__18 any; var count_1685000172__19 int64 = 0; var i_1685000173__20 int64 = 0; L13: for {






















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000173__20, count_1685000172__19) { var fi__21_3 any = lang.Indexed_Cast(chunk_1685000171__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000173__20)); var root_1922 any = A_arbace_go_check_A_const_199.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = fi__21_3; if linked_1923 == nil { ifn_1924.Invoke_O__O(arg_1925) } else { linked_1923.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_1922, arg_1925) }; seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000173__20); continue L13 } else { var temp__1927000414__auto____21_4 any; var root_1622 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = seq_1685000170__17; if linked_1623 == nil { temp__1927000414__auto____21_4 = ifn_1624.Invoke_O__O(arg_1625) } else { temp__1927000414__auto____21_4 = linked_1623.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1622, arg_1625) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000170__22 any = temp__1927000414__auto____21_4; var tmp168 any; var root_1626 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = seq_1685000170__22; if linked_1627 == nil { tmp168 = ifn_1628.Invoke_O__O(arg_1629) } else { tmp168 = linked_1627.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1626, arg_1629) }; if jrt.J2g_Truth(tmp168) { var c__1927000678__auto____23_4 any; var root_1630 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = seq_1685000170__22; if linked_1631 == nil { c__1927000678__auto____23_4 = ifn_1632.Invoke_O__O(arg_1633) } else { c__1927000678__auto____23_4 = linked_1631.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1630, arg_1633) }; var tmp169 any; var root_1926 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = seq_1685000170__22; if linked_1927 == nil { tmp169 = ifn_1928.Invoke_O__O(arg_1929) } else { tmp169 = linked_1927.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1926, arg_1929) }; seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = tmp169, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L13 } else { var fi__23 any; var root_1634 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = seq_1685000170__22; if linked_1635 == nil { fi__23 = ifn_1636.Invoke_O__O(arg_1637) } else { fi__23 = linked_1635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1634, arg_1637) }; var root_1930 any = A_arbace_go_check_A_const_199.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = fi__23; if linked_1931 == nil { ifn_1932.Invoke_O__O(arg_1933) } else { linked_1931.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_1930, arg_1933) }; var tmp170 any; var root_1934 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = seq_1685000170__22; if linked_1935 == nil { tmp170 = ifn_1936.Invoke_O__O(arg_1937) } else { tmp170 = linked_1935.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1934, arg_1937) }; seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = tmp170, nil, 0, 0; continue L13 } } }
//line :151:1
			break L13 }; var order__17 any; var root_767 any = A_arbace_go_check_A_const_118.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_769 lang.IFn
























































		if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = objs__15; if linked_768 == nil { order__17 = ifn_769.Invoke_O__O(arg_770) } else { order__17 = linked_768.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_767, arg_770) }
//line :151:1
		var say__18 any; var root_771 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_773 lang.IFn

























































		if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = src__0; var arg_775 any = A_arbace_go_check_A_const_119; if linked_772 == nil { say__18 = ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { say__18 = linked_772.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }
//line :151:1
		var init_entry__19 any; var tmp171 any = A_arbace_go_check_check_package_init_entry__1685000174_A_New(); var tmp172 *jrt.Class
		var fncls__816 /*line :151:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000174_A_fn_class


























































		if fncls__816 == nil { var fncls__816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_check_package_init_entry__1685000174_A_fn_class = fncls__816d; tmp172 = fncls__816d } else { tmp172 = fncls__816 }; init_entry__19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp171, tmp172, nil)
//line :151:1
		var have__20 any; var root_817 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_819 lang.IFn





























































		if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = init_entry__19; var arg_821 any = order__17; if linked_818 == nil { have__20 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { have__20 = linked_818.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }
//line :151:1
		var norm__21 any; var tmp173 any = A_arbace_go_check_check_package_norm__1685000178_A_New(); var tmp174 *jrt.Class
		var fncls__850 /*line :151:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000178_A_fn_class































































		if fncls__850 == nil { var fncls__850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_norm__1685000178_A_fn_class = fncls__850d; tmp174 = fncls__850d } else { tmp174 = fncls__850 }; norm__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp173, tmp174, nil)
//line :151:1
		var init_result__22 any; var tmp175 any; var root_851 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_853 lang.IFn




































































		if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = say__18; if linked_852 == nil { tmp175 = ifn_853.Invoke_O__O(arg_854) } else { tmp175 = linked_852.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_851, arg_854) }; if jrt.J2g_Truth(tmp175) {
			var tmp176 any; var root_855 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = norm__21; var arg_859 any = say__18; if linked_856 == nil { tmp176 = ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { tmp176 = linked_856.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp176, have__20) { var tmp177 any = A_arbace_go_check_A_const_127; var tmp178 any = jrt.Boolean_TRUE.Ref(); var tmp179 any = A_arbace_go_check_A_const_128; init_result__22 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp177, tmp178, tmp179, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__18)).Ref())) } else {

				var root_1938 any = A_arbace_go_check_A_const_200.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_201.Invoke_O__O(src__0)) { arg_1941 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_201.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp180 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp181 any; var root_1945 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_1946 == nil { tmp181 = ifn_1947.Invoke_O__O(arg_1948) } else { tmp181 = linked_1946.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1945, arg_1948) }; arg_1941 = tmp180.Invoke_O__O(tmp181) }; var arg_1942 any; var or__1927000174__auto____22 any = A_arbace_go_check_A_const_202.Invoke_O__O(src__0)
				if jrt.J2g_Truth(or__1927000174__auto____22) { arg_1942 = or__1927000174__auto____22 } else { arg_1942 = A_arbace_go_check_A_const_22 }
//line :223:1
				var arg_1943 any = A_arbace_go_check_A_const_203; var arg_1944 any = lang.IFn_Cast(A_arbace_go_check_A_const_204.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_61, A_arbace_go_check_A_const_104.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()).Invoke_O__O(say__18), lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()).Invoke_O__O(have__20)); if linked_1939 == nil { ifn_1940.Invoke_O_O_O_O__O(arg_1941, arg_1942, arg_1943, arg_1944) } else { linked_1939.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1938, arg_1941, arg_1942, arg_1943, arg_1944) }
//line :221:1
				init_result__22 = A_arbace_go_check_A_const_129 } } else {
//line :220:1
					init_result__22 = nil }
//line :151:1
		var generic_ids__23 any; var root_860 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_862 lang.IFn













































































		if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var root_864 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var tmp182 any = A_arbace_go_check_check_package_fn__1685000182_A_New(); var tmp183 *jrt.Class; var fncls__877 *jrt.Class = A_arbace_go_check_check_package_fn__1685000182_A_fn_class; if fncls__877 == nil { var fncls__877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_fn__1685000182_A_fn_class = fncls__877d; tmp183 = fncls__877d } else { tmp183 = fncls__877 }; arg_867 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp182, tmp183, nil); var arg_868 any = decls__16; if linked_865 == nil { arg_863 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { arg_863 = linked_865.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }; if linked_861 == nil { generic_ids__23 = ifn_862.Invoke_O__O(arg_863) } else { generic_ids__23 = linked_861.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_860, arg_863) }
//line :151:1
		var errs__24 any; var root_878 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_880 lang.IFn
























































		if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = errors__9; if linked_879 == nil { errs__24 = ifn_880.Invoke_O__O(arg_881) } else { errs__24 = linked_879.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_878, arg_881) }
//line :151:1
		var counted__25 any; var root_882 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_884 lang.IFn















































































		if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var tmp184 any = A_arbace_go_check_check_package_fn__1685000184_A_New_O(generic_ids__23); var tmp185 *jrt.Class; var fncls__892 *jrt.Class = A_arbace_go_check_check_package_fn__1685000184_A_fn_class; if fncls__892 == nil { var fncls__892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_fn__1685000184_A_fn_class = fncls__892d; tmp185 = fncls__892d } else { tmp185 = fncls__892 }; arg_885 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp184, tmp185, nil); var arg_886 any = errs__24; if linked_883 == nil { counted__25 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { counted__25 = linked_883.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }
//line :151:1
		var forms__26 any; var m__26 any = jrt.IdentityHashMap_New(); var order__27 any = jrt.ArrayList_New(); var seq_1685000186__28 any; var root_1964 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1966 lang.IFn



















































































		if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = decls__16; if linked_1965 == nil { seq_1685000186__28 = ifn_1966.Invoke_O__O(arg_1967) } else { seq_1685000186__28 = linked_1965.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1964, arg_1967) }
//line :151:1
		var chunk_1685000187__29 any; var count_1685000188__30 int64 = 0; var i_1685000189__31 int64 = 0; L14: for {



















































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000189__31, count_1685000188__30) { var d__32 any = lang.Indexed_Cast(chunk_1685000187__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000189__31)); var f__33 any; var tmp186 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp187 any; var root_1984 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1986 lang.IFn
				if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = d__32; if linked_1985 == nil { tmp187 = ifn_1986.Invoke_O__O(arg_1987) } else { tmp187 = linked_1985.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1984, arg_1987) }; f__33 = tmp186.Invoke_O__O(tmp187)
				if jrt.NN(jrt.IdentityHashMap_Cast(m__26)).ContainsKey_O__Z(f__33) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__27)).Add_O__Z(f__33)); jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Put_O_O__O(f__33, lang.PersistentVector_EMPTY.Ref()) }
				var tmp188 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__26); var tmp189 any; var root_1988 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1988, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1990 lang.IFn; if linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Get_O__O(f__33); var arg_1992 any = d__32; if linked_1989 == nil { tmp189 = ifn_1990.Invoke_O_O__O(arg_1991, arg_1992) } else { tmp189 = linked_1989.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1988, arg_1991, arg_1992) }; jrt.NN(tmp188).Put_O_O__O(f__33, tmp189)
//line :235:1
				seq_1685000186__28, chunk_1685000187__29, count_1685000188__30, i_1685000189__31 = seq_1685000186__28, chunk_1685000187__29, count_1685000188__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000189__31); continue L14 } else { var temp__1927000414__auto____32 any; var root_1968 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = seq_1685000186__28; if linked_1969 == nil { temp__1927000414__auto____32 = ifn_1970.Invoke_O__O(arg_1971) } else { temp__1927000414__auto____32 = linked_1969.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1968, arg_1971) }; if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_1685000186__33 any = temp__1927000414__auto____32; var tmp190 any; var root_1972 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = seq_1685000186__33; if linked_1973 == nil { tmp190 = ifn_1974.Invoke_O__O(arg_1975) } else { tmp190 = linked_1973.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1972, arg_1975) }; if jrt.J2g_Truth(tmp190) { var c__1927000678__auto____34 any; var root_1976 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = seq_1685000186__33; if linked_1977 == nil { c__1927000678__auto____34 = ifn_1978.Invoke_O__O(arg_1979) } else { c__1927000678__auto____34 = linked_1977.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1976, arg_1979) }; var tmp191 any; var root_1993 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = seq_1685000186__33; if linked_1994 == nil { tmp191 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp191 = linked_1994.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1993, arg_1996) }; seq_1685000186__28, chunk_1685000187__29, count_1685000188__30, i_1685000189__31 = tmp191, c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var d__34 any; var root_1980 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = seq_1685000186__33; if linked_1981 == nil { d__34 = ifn_1982.Invoke_O__O(arg_1983) } else { d__34 = linked_1981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1980, arg_1983) }; var f__35 any; var tmp192 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp193 any; var root_1997 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1999 lang.IFn
					if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = d__34; if linked_1998 == nil { tmp193 = ifn_1999.Invoke_O__O(arg_2000) } else { tmp193 = linked_1998.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1997, arg_2000) }; f__35 = tmp192.Invoke_O__O(tmp193)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__26)).ContainsKey_O__Z(f__35) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__27)).Add_O__Z(f__35)); jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Put_O_O__O(f__35, lang.PersistentVector_EMPTY.Ref()) }
					var tmp194 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__26); var tmp195 any; var root_2001 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Get_O__O(f__35); var arg_2005 any = d__34; if linked_2002 == nil { tmp195 = ifn_2003.Invoke_O_O__O(arg_2004, arg_2005) } else { tmp195 = linked_2002.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2001, arg_2004, arg_2005) }; jrt.NN(tmp194).Put_O_O__O(f__35, tmp195)
//line :235:1
					var tmp196 any; var root_2006 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = seq_1685000186__33; if linked_2007 == nil { tmp196 = ifn_2008.Invoke_O__O(arg_2009) } else { tmp196 = linked_2007.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2006, arg_2009) }; seq_1685000186__28, chunk_1685000187__29, count_1685000188__30, i_1685000189__31 = tmp196, nil, 0, 0; continue L14 } } }
//line :151:1
			break L14
		}






















































































		var root_893 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any; var tmp197 any = A_arbace_go_check_check_package_fn__1685000190_A_New_O(m__26); var tmp198 *jrt.Class; var fncls__898 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_A_fn_class; if fncls__898 == nil { var fncls__898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_check_check_package_fn__1685000190_A_fn_class = fncls__898d; tmp198 = fncls__898d } else { tmp198 = fncls__898 }; arg_896 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp197, tmp198, nil); var arg_897 any = order__27; if linked_894 == nil { forms__26 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { forms__26 = linked_894.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }
//line :151:1
		var stats__27 any; var root_899 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_901 lang.IFn
























































































		if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var tmp199 any = A_arbace_go_check_check_package_fn__1685000193_A_New(); var tmp200 *jrt.Class; var fncls__1179 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_A_fn_class
		if fncls__1179 == nil { var fncls__1179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_fn__1685000193_A_fn_class = fncls__1179d; tmp200 = fncls__1179d } else { tmp200 = fncls__1179 }; arg_902 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp199, tmp200, nil)
//line :240:1
		var arg_903 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_151, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_140, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_142, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_127, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_153, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_132, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_154, lang.PersistentVector_EMPTY.Ref())); var arg_904 any = forms__26; if linked_900 == nil { stats__27 = ifn_901.Invoke_O_O_O__O(arg_902, arg_903, arg_904) } else { stats__27 = linked_900.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_899, arg_902, arg_903, arg_904)
		}




























		if jrt.J2g_Truth(keep_trees__6) { } else { var seq_1685000234__28 any; var root_2010 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2010, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2012 lang.IFn
			if linked_2011 == nil { ifn_2012 = lang.IFn_Cast(root_2010) } else { ifn_2012 = nil }; var arg_2013 any = decls__16; if linked_2011 == nil { seq_1685000234__28 = ifn_2012.Invoke_O__O(arg_2013) } else { seq_1685000234__28 = linked_2011.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2010, arg_2013) }
//line :270:1
			var chunk_1685000235__29 any; var count_1685000236__30 int64 = 0; var i_1685000237__31 int64 = 0; L15: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000237__31, count_1685000236__30) { var d__32_2 any = lang.Indexed_Cast(chunk_1685000235__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000237__31)); var tmp201 any; var and__1927000168__auto____33 bool; var tmp202 any = A_arbace_go_check_A_const_219; var tmp203 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp204 any; var root_2171 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2173 lang.IFn
					if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any = d__32_2; if linked_2172 == nil { tmp204 = ifn_2173.Invoke_O__O(arg_2174) } else { tmp204 = linked_2172.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2171, arg_2174) }; and__1927000168__auto____33 = lang.Util_Equiv_O_O__Z_NoInit(tmp202, tmp203.Invoke_O__O(tmp204)); if and__1927000168__auto____33 { var or__1927000174__auto____34 any; var root_2175 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any; var root_2179 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any; var tmp205 *lang.Keyword = A_arbace_go_check_A_const_196; var tmp206 any; var root_2184 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2186 lang.IFn; if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any = d__32_2; if linked_2185 == nil { tmp206 = ifn_2186.Invoke_O__O(arg_2187) } else { tmp206 = linked_2185.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2184, arg_2187) }; arg_2182 = tmp205.Invoke_O__O(tmp206); var arg_2183 any = A_arbace_go_check_A_const_220; if linked_2180 == nil { arg_2178 = ifn_2181.Invoke_O_O__O(arg_2182, arg_2183) } else { arg_2178 = linked_2180.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2179, arg_2182, arg_2183) }; if linked_2176 == nil { or__1927000174__auto____34 = ifn_2177.Invoke_O__O(arg_2178) } else { or__1927000174__auto____34 = linked_2176.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2175, arg_2178) }; if jrt.J2g_Truth(or__1927000174__auto____34) { tmp201 = or__1927000174__auto____34 } else { var root_2188 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2190 lang.IFn; if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any; var root_2192 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any; var tmp207 *lang.Keyword = A_arbace_go_check_A_const_196; var tmp208 any; var root_2197 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = d__32_2; if linked_2198 == nil { tmp208 = ifn_2199.Invoke_O__O(arg_2200) } else { tmp208 = linked_2198.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2197, arg_2200) }; arg_2195 = tmp207.Invoke_O__O(tmp208); var arg_2196 any = A_arbace_go_check_A_const_221; if linked_2193 == nil { arg_2191 = ifn_2194.Invoke_O_O__O(arg_2195, arg_2196) } else { arg_2191 = linked_2193.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2192, arg_2195, arg_2196) }; if linked_2189 == nil { tmp201 = ifn_2190.Invoke_O__O(arg_2191) } else { tmp201 = linked_2189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2188, arg_2191) } } } else { tmp201 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____33).Ref() }; if jrt.J2g_Truth(tmp201) {
						jrt.NN(lang.Volatile_Cast(d__32_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_222.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__32_2)).Deref__O(), A_arbace_go_check_A_const_223, A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225)) } else {
							jrt.NN(lang.Volatile_Cast(d__32_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_222.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__32_2)).Deref__O(), A_arbace_go_check_A_const_187, A_arbace_go_check_A_const_223, A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225)) }
//line :271:1
					seq_1685000234__28, chunk_1685000235__29, count_1685000236__30, i_1685000237__31 = seq_1685000234__28, chunk_1685000235__29, count_1685000236__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000237__31); continue L15 } else { var temp__1927000414__auto____32_2 any; var root_2014 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = seq_1685000234__28; if linked_2015 == nil { temp__1927000414__auto____32_2 = ifn_2016.Invoke_O__O(arg_2017) } else { temp__1927000414__auto____32_2 = linked_2015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2014, arg_2017) }; if jrt.J2g_Truth(temp__1927000414__auto____32_2) { var seq_1685000234__33 any = temp__1927000414__auto____32_2; var tmp209 any; var root_2018 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any = seq_1685000234__33; if linked_2019 == nil { tmp209 = ifn_2020.Invoke_O__O(arg_2021) } else { tmp209 = linked_2019.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2018, arg_2021) }; if jrt.J2g_Truth(tmp209) { var c__1927000678__auto____34_2 any; var root_2022 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = seq_1685000234__33; if linked_2023 == nil { c__1927000678__auto____34_2 = ifn_2024.Invoke_O__O(arg_2025) } else { c__1927000678__auto____34_2 = linked_2023.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2022, arg_2025) }; var tmp210 any; var root_2216 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = seq_1685000234__33; if linked_2217 == nil { tmp210 = ifn_2218.Invoke_O__O(arg_2219) } else { tmp210 = linked_2217.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2216, arg_2219) }; seq_1685000234__28, chunk_1685000235__29, count_1685000236__30, i_1685000237__31 = tmp210, c__1927000678__auto____34_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__34_2 any; var root_2026 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = seq_1685000234__33; if linked_2027 == nil { d__34_2 = ifn_2028.Invoke_O__O(arg_2029) } else { d__34_2 = linked_2027.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2026, arg_2029) }
						var tmp211 any; var and__1927000168__auto____35 bool; var tmp212 any = A_arbace_go_check_A_const_219; var tmp213 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp214 any; var root_2220 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = d__34_2; if linked_2221 == nil { tmp214 = ifn_2222.Invoke_O__O(arg_2223) } else { tmp214 = linked_2221.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2220, arg_2223) }; and__1927000168__auto____35 = lang.Util_Equiv_O_O__Z_NoInit(tmp212, tmp213.Invoke_O__O(tmp214)); if and__1927000168__auto____35 { var or__1927000174__auto____36 any; var root_2224 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any; var root_2228 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2230 lang.IFn; if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any; var tmp215 *lang.Keyword = A_arbace_go_check_A_const_196; var tmp216 any; var root_2233 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = d__34_2; if linked_2234 == nil { tmp216 = ifn_2235.Invoke_O__O(arg_2236) } else { tmp216 = linked_2234.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2233, arg_2236) }; arg_2231 = tmp215.Invoke_O__O(tmp216); var arg_2232 any = A_arbace_go_check_A_const_220; if linked_2229 == nil { arg_2227 = ifn_2230.Invoke_O_O__O(arg_2231, arg_2232) } else { arg_2227 = linked_2229.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2228, arg_2231, arg_2232) }; if linked_2225 == nil { or__1927000174__auto____36 = ifn_2226.Invoke_O__O(arg_2227) } else { or__1927000174__auto____36 = linked_2225.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2224, arg_2227) }; if jrt.J2g_Truth(or__1927000174__auto____36) { tmp211 = or__1927000174__auto____36 } else { var root_2237 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any; var root_2241 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any; var tmp217 *lang.Keyword = A_arbace_go_check_A_const_196; var tmp218 any; var root_2246 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = d__34_2; if linked_2247 == nil { tmp218 = ifn_2248.Invoke_O__O(arg_2249) } else { tmp218 = linked_2247.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2246, arg_2249) }; arg_2244 = tmp217.Invoke_O__O(tmp218); var arg_2245 any = A_arbace_go_check_A_const_221; if linked_2242 == nil { arg_2240 = ifn_2243.Invoke_O_O__O(arg_2244, arg_2245) } else { arg_2240 = linked_2242.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2241, arg_2244, arg_2245) }; if linked_2238 == nil { tmp211 = ifn_2239.Invoke_O__O(arg_2240) } else { tmp211 = linked_2238.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2237, arg_2240) } } } else { tmp211 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____35).Ref() }; if jrt.J2g_Truth(tmp211) {
							jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_222.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_223, A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225)) } else {
								jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_222.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_187, A_arbace_go_check_A_const_223, A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225)) }
//line :271:1
						var tmp219 any; var root_2265 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any = seq_1685000234__33; if linked_2266 == nil { tmp219 = ifn_2267.Invoke_O__O(arg_2268) } else { tmp219 = linked_2266.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2265, arg_2268) }; seq_1685000234__28, chunk_1685000235__29, count_1685000236__30, i_1685000237__31 = tmp219, nil, 0, 0; continue L15 } } }
//line :270:1
				break L15
			}
		}


		var tmp220 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp221 any; var root_2030 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2030, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2032 lang.IFn; if linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2034 any = A_arbace_go_check_A_const_206; var arg_2035 any; var tmp222 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_189.GetRawRoot__O()); var tmp223 any = A_arbace_go_check_A_const_104; var tmp224 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp225 any = A_arbace_go_check_A_const_207; var tmp226 any; var root_2058 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2060 lang.IFn


		if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any; var root_2062 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any; var root_2067 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = A_arbace_go_check_A_const_73; var arg_2071 any = A_arbace_go_check_A_const_78; if linked_2068 == nil { arg_2065 = ifn_2069.Invoke_O_O__O(arg_2070, arg_2071) } else { arg_2065 = linked_2068.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2067, arg_2070, arg_2071) }; var arg_2066 any = counted__25; if linked_2063 == nil { arg_2061 = ifn_2064.Invoke_O_O__O(arg_2065, arg_2066) } else { arg_2061 = linked_2063.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2062, arg_2065, arg_2066) }; if linked_2059 == nil { tmp226 = ifn_2060.Invoke_O__O(arg_2061) } else { tmp226 = linked_2059.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2058, arg_2061) }
//line :276:1
		var tmp227 any = tmp226; var tmp228 any = A_arbace_go_check_A_const_211; var tmp229 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__24)), int64(lang.RT_Count_O__I_NoInit(counted__25)))).Ref(); var tmp230 any = A_arbace_go_check_A_const_212; var tmp231 any = A_arbace_go_check_A_const_213; var tmp232 any




		if jrt.J2g_Truth(keep_trees__6) { var root_2072 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any; var root_2076 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any; var tmp233 any = A_arbace_go_check_check_package_fn__1685000238_A_New(); var tmp234 *jrt.Class; var fncls__2085 *jrt.Class = A_arbace_go_check_check_package_fn__1685000238_A_fn_class; if fncls__2085 == nil { var fncls__2085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_check_package_fn__1685000238_A_fn_class = fncls__2085d; tmp234 = fncls__2085d } else { tmp234 = fncls__2085 }; arg_2079 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp233, tmp234, nil); var arg_2080 any = decls__16; if linked_2077 == nil { arg_2075 = ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { arg_2075 = linked_2077.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) }; if linked_2073 == nil { tmp232 = ifn_2074.Invoke_O__O(arg_2075) } else { tmp232 = linked_2073.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2072, arg_2075) } } else { tmp232 = nil }
//line :276:1
		var tmp235 any = tmp232; var tmp236 any = A_arbace_go_check_A_const_214; var tmp237 any







		if jrt.J2g_Truth(keep_trees__6) {
			var root_2086 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var iter__1927001039__auto____28 any; var tmp238 any = A_arbace_go_check_check_package_iter__1685000240__1685000244_A_New(); var tmp239 *jrt.Class; var fncls__2166 *jrt.Class = A_arbace_go_check_check_package_iter__1685000240__1685000244_A_fn_class; if fncls__2166 == nil { var fncls__2166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_iter__1685000240__1685000244_A_fn_class = fncls__2166d; tmp239 = fncls__2166d } else { tmp239 = fncls__2166 }; iter__1927001039__auto____28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp238, tmp239, nil); arg_2089 = lang.IFn_Cast(iter__1927001039__auto____28).Invoke_O__O(decls__16); if linked_2087 == nil { tmp237 = ifn_2088.Invoke_O__O(arg_2089) } else { tmp237 = linked_2087.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2086, arg_2089) } } else {
//line :284:1
				tmp237 = nil }
//line :276:1
		var tmp240 any = tmp237; var tmp241 any = A_arbace_go_check_A_const_218; var tmp242 any











		if jrt.J2g_Truth(keep_trees__6) { tmp242 = order__17 } else { tmp242 = nil }
//line :276:1
		var tmp243 any = tmp242; var tmp244 any = A_arbace_go_check_A_const_71; var tmp245 any












		if jrt.J2g_Truth(keep_trees__6) { tmp245 = pkg_scope__7 } else { tmp245 = nil }
//line :276:1
		var tmp246 any = tmp245; var tmp247 any = A_arbace_go_check_A_const_110; var tmp248 any













		if jrt.J2g_Truth(keep_trees__6) { var root_2167 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = A_arbace_go_check_A_const_110.Invoke_O__O(ctx__11); if linked_2168 == nil { tmp248 = ifn_2169.Invoke_O__O(arg_2170) } else { tmp248 = linked_2168.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2167, arg_2170) } } else { tmp248 = nil }
//line :276:1
		arg_2035 = tmp222.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(stats__27, tmp223, tmp224, tmp225, tmp227, tmp228, tmp229, tmp230, init_result__22, tmp231, tmp235, tmp236, tmp240, tmp241, tmp243, tmp244, tmp246, tmp247, tmp248)
//line :275:1
		if linked_2031 == nil { tmp221 = ifn_2032.Invoke_O_O_O__O(arg_2033, arg_2034, arg_2035) } else { tmp221 = linked_2031.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2030, arg_2033, arg_2034, arg_2035) }; jrt.NN(tmp220).Reset_O__O(tmp221)
//line :151:1
		tmp52 = pkg__8 }; return nil }(); var root_1180 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1182 lang.IFn; if











	linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; if linked_1181 == nil { ifn_1182.Invoke__O() } else { linked_1181.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1180) }; if /*line :151:1*/ tmp249 != nil { panic(tmp249) }; return tmp52 }










func A_arbace_go_check_check_package_fn__1685000100_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000100_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000100_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_go_check_check_package_fn__1685000100_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :162:1
func (t *A_arbace_go_check_check_package_fn__1685000100_A) Invoke_O_O__O(self, p1__1685000082_SHARP___1 any) any { var root_741 any = A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_go_check_file_info_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t.F_pkg_scope; var arg_745 any = p1__1685000082_SHARP___1; var arg_746 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_src); if linked_742 == nil { return ifn_743.Invoke_O_O_O__O(arg_744, arg_745, arg_746) } else { return linked_742.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_741, arg_744, arg_745, arg_746) } }










func A_arbace_go_check_check_package_fn__1685000102_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000102_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000102_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :173:1
func (t *A_arbace_go_check_check_package_fn__1685000102_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :173:1
func (t *A_arbace_go_check_check_package_fn__1685000102_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1187 any = A_arbace_go_check_A_const_172.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = A_arbace_go_check_A_const_104.Invoke_O__O(t.F_src); if linked_1188 == nil { tmp1 = ifn_1189.Invoke_O__O(arg_1190) } else { tmp1 = linked_1188.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1187, arg_1190) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :173:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }















func A_arbace_go_check_check_package_fn__1685000138_A_New() *A_arbace_go_check_check_package_fn__1685000138_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000138_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_go_check_check_package_fn__1685000138_A) Ctor() {}
//line :189:1
func (t *A_arbace_go_check_check_package_fn__1685000138_A) Invoke_O_O__O(self, p1__1685000083_SHARP___1 any) any { var root_761 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = p1__1685000083_SHARP___1; var arg_765 any = A_arbace_go_check_A_const_117; if linked_762 == nil { return ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { return linked_762.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) } }





func A_arbace_go_check_check_package_fn__1685000145_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000145_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_go_check_check_package_fn__1685000145_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :195:1
func (t *A_arbace_go_check_check_package_fn__1685000145_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000146__5 any; var root_1652 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn
											if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1655 = t_; if linked_1653 == nil { seq_1685000146__5 = ifn_1654.Invoke_O__O(arg_1655) } else { seq_1685000146__5 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }
//line :195:1
	var chunk_1685000147__6 any; var count_1685000148__7 int64 = 0; var i_1685000149__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000149__8, count_1685000148__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000147__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000149__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000146__5, chunk_1685000147__6, count_1685000148__7, i_1685000149__8 = seq_1685000146__5, chunk_1685000147__6, count_1685000148__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000149__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1656 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = seq_1685000146__5; if linked_1657 == nil { temp__1927000414__auto____9 = ifn_1658.Invoke_O__O(arg_1659) } else { temp__1927000414__auto____9 = linked_1657.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1656, arg_1659) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000146__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1660 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = seq_1685000146__10; if linked_1661 == nil { tmp2 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp2 = linked_1661.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1660, arg_1663) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1664 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = seq_1685000146__10; if linked_1665 == nil { c__1927000678__auto____11 = ifn_1666.Invoke_O__O(arg_1667) } else { c__1927000678__auto____11 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1664, arg_1667) }; var tmp3 any; var root_1675 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = seq_1685000146__10; if linked_1676 == nil { tmp3 = ifn_1677.Invoke_O__O(arg_1678) } else { tmp3 = linked_1676.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1675, arg_1678) }; seq_1685000146__5, chunk_1685000147__6, count_1685000148__7, i_1685000149__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1668 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = seq_1685000146__10; if linked_1669 == nil { l__11 = ifn_1670.Invoke_O__O(arg_1671) } else { l__11 = linked_1669.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1668, arg_1671) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1679 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = seq_1685000146__10; if linked_1680 == nil { tmp4 = ifn_1681.Invoke_O__O(arg_1682) } else { tmp4 = linked_1680.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1679, arg_1682) }; seq_1685000146__5, chunk_1685000147__6, count_1685000148__7, i_1685000149__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :195:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1683 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1685 lang.IFn

			if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = ex__5; if linked_1684 == nil { tmp6 = ifn_1685.Invoke_O__O(arg_1686) } else { tmp6 = linked_1684.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1683, arg_1686) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1687 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1690 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1691 any = A_arbace_go_check_A_const_132; var arg_1692 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_191; var tmp11 any; var root_1693 any = A_arbace_go_check_A_const_192.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = ex__5; if linked_1694 == nil { tmp11 = ifn_1695.Invoke_O__O(arg_1696) } else { tmp11 = linked_1694.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1693, arg_1696) }; arg_1692 = tmp10.Invoke_O__O(tmp11); if linked_1688 == nil { tmp8 = ifn_1689.Invoke_O_O_O__O(arg_1690, arg_1691, arg_1692) } else { tmp8 = linked_1688.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1687, arg_1690, arg_1691, arg_1692) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :195:1
				panic(tmp5) } } }; return nil }(); var root_1672 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; if linked_1673 == nil { ifn_1674.Invoke__O() } else { linked_1673.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1672) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :195:1
func A_arbace_go_check_check_package_fn__1685000152_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000152_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000152_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_go_check_check_package_fn__1685000152_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :195:1
func (t *A_arbace_go_check_check_package_fn__1685000152_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000153__5 any; var root_1742 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1744 lang.IFn
											if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1745 = t_; if linked_1743 == nil { seq_1685000153__5 = ifn_1744.Invoke_O__O(arg_1745) } else { seq_1685000153__5 = linked_1743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1742, arg_1745) }
//line :195:1
	var chunk_1685000154__6 any; var count_1685000155__7 int64 = 0; var i_1685000156__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000156__8, count_1685000155__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000154__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000156__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000153__5, chunk_1685000154__6, count_1685000155__7, i_1685000156__8 = seq_1685000153__5, chunk_1685000154__6, count_1685000155__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000156__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1746 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = seq_1685000153__5; if linked_1747 == nil { temp__1927000414__auto____9 = ifn_1748.Invoke_O__O(arg_1749) } else { temp__1927000414__auto____9 = linked_1747.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1746, arg_1749) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000153__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1750 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = seq_1685000153__10; if linked_1751 == nil { tmp2 = ifn_1752.Invoke_O__O(arg_1753) } else { tmp2 = linked_1751.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1750, arg_1753) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1754 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = seq_1685000153__10; if linked_1755 == nil { c__1927000678__auto____11 = ifn_1756.Invoke_O__O(arg_1757) } else { c__1927000678__auto____11 = linked_1755.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1754, arg_1757) }; var tmp3 any; var root_1765 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = seq_1685000153__10; if linked_1766 == nil { tmp3 = ifn_1767.Invoke_O__O(arg_1768) } else { tmp3 = linked_1766.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1765, arg_1768) }; seq_1685000153__5, chunk_1685000154__6, count_1685000155__7, i_1685000156__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1758 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = seq_1685000153__10; if linked_1759 == nil { l__11 = ifn_1760.Invoke_O__O(arg_1761) } else { l__11 = linked_1759.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1758, arg_1761) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1769 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = seq_1685000153__10; if linked_1770 == nil { tmp4 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp4 = linked_1770.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1769, arg_1772) }; seq_1685000153__5, chunk_1685000154__6, count_1685000155__7, i_1685000156__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :195:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1773 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1775 lang.IFn

			if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = ex__5; if linked_1774 == nil { tmp6 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp6 = linked_1774.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1773, arg_1776) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1777 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1780 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1781 any = A_arbace_go_check_A_const_132; var arg_1782 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_191; var tmp11 any; var root_1783 any = A_arbace_go_check_A_const_192.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = ex__5; if linked_1784 == nil { tmp11 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp11 = linked_1784.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1783, arg_1786) }; arg_1782 = tmp10.Invoke_O__O(tmp11); if linked_1778 == nil { tmp8 = ifn_1779.Invoke_O_O_O__O(arg_1780, arg_1781, arg_1782) } else { tmp8 = linked_1778.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1777, arg_1780, arg_1781, arg_1782) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :195:1
				panic(tmp5) } } }; return nil }(); var root_1762 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; if linked_1763 == nil { ifn_1764.Invoke__O() } else { linked_1763.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1762) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000162_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000162_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000162_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_go_check_check_package_fn__1685000162_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :201:1
func (t *A_arbace_go_check_check_package_fn__1685000162_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1818 any = A_arbace_go_check_A_const_197.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_187; var tmp3 any; var root_1822 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any; var t_ any = t.F_d; t.F_d = nil; arg_1825 = t_; if linked_1823 == nil { tmp3 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp3 = linked_1823.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1822, arg_1825) }; arg_1821 = tmp2.Invoke_O__O(tmp3); if linked_1819 == nil { tmp1 = ifn_1820.Invoke_O__O(arg_1821) } else { tmp1 = linked_1819.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_1818, arg_1821) } }
//line :201:1
	return nil }(); var root_1826 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; if linked_1827 == nil { ifn_1828.Invoke__O() } else { linked_1827.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1826) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :201:1
func A_arbace_go_check_check_package_fn__1685000164_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000164_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000164_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_go_check_check_package_fn__1685000164_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :201:1
func (t *A_arbace_go_check_check_package_fn__1685000164_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1849 any = A_arbace_go_check_A_const_197.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_187; var tmp3 any; var root_1853 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any; var t_ any = t.F_d; t.F_d = nil; arg_1856 = t_; if linked_1854 == nil { tmp3 = ifn_1855.Invoke_O__O(arg_1856) } else { tmp3 = linked_1854.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1853, arg_1856) }; arg_1852 = tmp2.Invoke_O__O(tmp3); if linked_1850 == nil { tmp1 = ifn_1851.Invoke_O__O(arg_1852) } else { tmp1 = linked_1850.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_1849, arg_1852) } }
//line :201:1
	return nil }(); var root_1857 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; if linked_1858 == nil { ifn_1859.Invoke__O() } else { linked_1858.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1857) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }








func A_arbace_go_check_check_package_init_entry__1685000174_A_New() *A_arbace_go_check_check_package_init_entry__1685000174_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000174_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_go_check_check_package_init_entry__1685000174_A) Ctor() {}
//line :210:1
func (t *A_arbace_go_check_check_package_init_entry__1685000174_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A_New(); var tmp2 *jrt.Class; var fncls__800 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A_fn_class; if
													fncls__800 == nil { var fncls__800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A_fn_class = fncls__800d; tmp2 = fncls__800d } else { tmp2 = fncls__800 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_812 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = lhs__1; if linked_813 == nil { tmp4 = ifn_814.Invoke_O__O(arg_815) } else { tmp4 = linked_813.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_812, arg_815) }; return tmp3.Invoke_O__O(tmp4) } else { var root_801 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var arg_805 any = A_arbace_go_check_A_const_123; var arg_806 any; var root_807 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = one__2; var arg_811 any = lhs__1; if linked_808 == nil { arg_806 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { arg_806 = linked_808.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; if linked_802 == nil { return ifn_803.Invoke_O_O_O__O(arg_804, arg_805, arg_806) } else { return linked_802.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_801, arg_804, arg_805, arg_806) } } }
//line :211:1
func A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A_New() *A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A) Ctor() {}
//line :211:1
func (t *A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_776 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = v__1; var arg_780 any = A_arbace_go_check_A_const_70; if linked_777 == nil { tmp1 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { tmp1 = linked_777.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_82, tmp1) { var tmp2 any; var root_790 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = v__1; var arg_794 any = A_arbace_go_check_A_const_73; if linked_791 == nil { tmp2 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { tmp2 = linked_791.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }; var tmp3 any = tmp2; var tmp4 any; var root_795 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = v__1; var arg_799 any = A_arbace_go_check_A_const_78; if linked_796 == nil { tmp4 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp4 = linked_796.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_781 any = A_arbace_go_check_A_const_120.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_785 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = v__1; var arg_789 any = A_arbace_go_check_A_const_70; if linked_786 == nil { arg_784 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { arg_784 = linked_786.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; if linked_782 == nil { return ifn_783.Invoke_O__O(arg_784) } else { return linked_782.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_781, arg_784) } } }



func A_arbace_go_check_check_package_norm__1685000178_A_New() *A_arbace_go_check_check_package_norm__1685000178_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000178_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_go_check_check_package_norm__1685000178_A) Ctor() {}
//line :215:1
func (t *A_arbace_go_check_check_package_norm__1685000178_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_822 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_824 lang.IFn; if
												linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = x__1; if linked_823 == nil { tmp1 = ifn_824.Invoke_O__O(arg_825) } else { tmp1 = linked_823.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_822, arg_825) }; if /*line :215:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_826 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_828 lang.IFn

		if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = x__1; if linked_827 == nil { tmp2 = ifn_828.Invoke_O__O(arg_829) } else { tmp2 = linked_827.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_826, arg_829) }
//line :215:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_85, tmp2) {


			var root_830 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var arg_834 any = A_arbace_go_check_A_const_124; var arg_835 any; var root_836 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A_New(); var tmp4 *jrt.Class; var fncls__845 *jrt.Class = A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A_fn_class; if fncls__845 == nil { var fncls__845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A_fn_class = fncls__845d; tmp4 = fncls__845d } else { tmp4 = fncls__845 }; arg_839 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_840 any; var root_846 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = x__1; if linked_847 == nil { arg_840 = ifn_848.Invoke_O__O(arg_849) } else { arg_840 = linked_847.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_846, arg_849) }; if linked_837 == nil { arg_835 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { arg_835 = linked_837.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; if linked_831 == nil { return ifn_832.Invoke_O_O_O__O(arg_833, arg_834, arg_835) } else { return linked_831.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_830, arg_833, arg_834, arg_835) } } else {
//line :215:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A_New() *A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A) Invoke_O_O__O(self, p1__1685000084_SHARP___1 any) any { var tmp1 any; var root_841 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = p1__1685000084_SHARP___1; if linked_842 == nil { tmp1 = ifn_843.Invoke_O__O(arg_844) } else { tmp1 = linked_842.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000084_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000084_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000084_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000182_A_New() *A_arbace_go_check_check_package_fn__1685000182_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000182_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000182_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000182_A) Invoke_O_O__O(self, p1__1685000085_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_869 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = p1__1685000085_SHARP___1; if linked_870 == nil { tmp2 = ifn_871.Invoke_O__O(arg_872) } else { tmp2 = linked_870.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp4 any; var root_873 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = p1__1685000085_SHARP___1; if linked_874 == nil { tmp4 = ifn_875.Invoke_O__O(arg_876) } else { tmp4 = linked_874.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_873, arg_876) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000184_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000184_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000184_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_go_check_check_package_fn__1685000184_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :231:1
func (t *A_arbace_go_check_check_package_fn__1685000184_A) Invoke_O_O__O(self, p1__1685000086_SHARP___1 any) any { var root_887 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = t.F_generic_ids; var arg_891 any = A_arbace_go_check_A_const_117.Invoke_O__O(p1__1685000086_SHARP___1); if linked_888 == nil { return ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { return linked_888.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_887, arg_890, arg_891) } }







func A_arbace_go_check_check_package_fn__1685000190_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_A{}; t.Ctor_O(p0); return t }
//line :239:1
func (t *A_arbace_go_check_check_package_fn__1685000190_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :239:1
func (t *A_arbace_go_check_check_package_fn__1685000190_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000193_A_New() *A_arbace_go_check_check_package_fn__1685000193_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Invoke_O_O_O__O(self, acc__1, p__1685000192__2 any) any { var vec__1685000194__3 any = p__1685000192__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000194__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000194__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_905 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_907 lang.IFn; if
															linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A_New(); var tmp2 *jrt.Class; var fncls__914 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A_fn_class; if fncls__914 == nil { var fncls__914d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A_fn_class = fncls__914d; tmp2 = fncls__914d } else { tmp2 = fncls__914 }; arg_908 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_909 any = ds__5; if linked_906 == nil { gen__6 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { gen__6 = linked_906.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; var uses_generics__7 any; var root_915 any = /*line :241:1*/A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_917 lang.IFn; if

	linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A_New(); var tmp4 *jrt.Class; var fncls__924 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A_fn_class; if fncls__924 == nil { var fncls__924d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A_fn_class = fncls__924d; tmp4 = fncls__924d } else { tmp4 = fncls__924 }; arg_918 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_919 any = ds__5; if linked_916 == nil { uses_generics__7 = ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { uses_generics__7 = linked_916.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) }; var present__8 any; var root_925 any = /*line :241:1*/A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, A_arbace_go_check_annotations_present_A_fn_class); var ifn_927 lang.IFn; if


	linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = form__4; if linked_926 == nil { present__8 = ifn_927.Invoke_O__O(arg_928) } else { present__8 = linked_926.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_925, arg_928) }; var verified__9 any; var root_929 any = /*line :241:1*/A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_931 lang.IFn; if



	linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var arg_933 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_934 any; var root_935 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A_New(); var tmp6 *jrt.Class; var fncls__944 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A_fn_class; if fncls__944 == nil { var fncls__944d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A_fn_class = fncls__944d; tmp6 = fncls__944d } else { tmp6 = fncls__944 }; arg_938 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_939 any = ds__5; if linked_936 == nil { arg_934 = ifn_937.Invoke_O_O__O(arg_938, arg_939) } else { arg_934 = linked_936.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_935, arg_938, arg_939) }; if linked_930 == nil { verified__9 = ifn_931.Invoke_O_O_O__O(arg_932, arg_933, arg_934) } else { verified__9 = linked_930.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_929, arg_932, arg_933, arg_934) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_945 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any; var root_952 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = acc__1; var arg_956 any = A_arbace_go_check_A_const_140; var arg_957 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); if linked_953 == nil { arg_948 = ifn_954.Invoke_O_O_O__O(arg_955, arg_956, arg_957) } else { arg_948 = linked_953.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_952, arg_955, arg_956, arg_957) }; var arg_949 any = A_arbace_go_check_A_const_142; var arg_950 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_951 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_946 == nil { acc__10 = ifn_947.Invoke_O_O_O_O__O(arg_948, arg_949, arg_950, arg_951) } else { acc__10 = linked_946.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_945, arg_948, arg_949, arg_950, arg_951) } } else {
//line :246:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_958 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_964 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_966 lang.IFn
//line :252:1
		if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any; var root_970 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_972 lang.IFn
//line :251:1
		if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = acc__10; var arg_974 any = A_arbace_go_check_A_const_143; var arg_975 any; var root_976 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var arg_980 any = A_arbace_go_check_A_const_22; if linked_977 == nil { arg_975 = ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { arg_975 = linked_977.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_976, arg_979, arg_980) }; if linked_971 == nil { arg_967 = ifn_972.Invoke_O_O_O__O(arg_973, arg_974, arg_975) } else { arg_967 = linked_971.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_970, arg_973, arg_974, arg_975) }
		var arg_968 any = A_arbace_go_check_A_const_144; var arg_969 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A_New_O(present__8); var tmp8 *jrt.Class; var fncls__987 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A_fn_class; if fncls__987 == nil { var fncls__987d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A_fn_class = fncls__987d; tmp8 = fncls__987d } else { tmp8 = fncls__987 }; arg_969 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_965 == nil { arg_961 = ifn_966.Invoke_O_O_O__O(arg_967, arg_968, arg_969) } else { arg_961 = linked_965.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_964, arg_967, arg_968, arg_969) }
		var arg_962 any = A_arbace_go_check_A_const_132; var arg_963 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A_New_O(ds__5); var tmp10 *jrt.Class; var fncls__1010 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A_fn_class; if fncls__1010 == nil { var fncls__1010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A_fn_class = fncls__1010d; tmp10 = fncls__1010d } else { tmp10 = fncls__1010 }; arg_963 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_959 == nil { return ifn_960.Invoke_O_O_O__O(arg_961, arg_962, arg_963) } else { return linked_959.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_958, arg_961, arg_962, arg_963) } } else {
//line :249:1
			var unver__11 any; var root_1011 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1013 lang.IFn




			if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1015 any; var iter__1927001039__auto____11 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A_New_O(verified__9); var tmp12 *jrt.Class; var fncls__1098 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A_fn_class; if fncls__1098 == nil { var fncls__1098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A_fn_class = fncls__1098d; tmp12 = fncls__1098d } else { tmp12 = fncls__1098 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1015 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1012 == nil { unver__11 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { unver__11 = linked_1012.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015)
			}








			var root_1099 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var root_1105 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1107 lang.IFn
//line :263:1
			if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var root_1111 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1113 lang.IFn
//line :262:1
			if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var root_1117 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1119 lang.IFn
//line :261:1
			if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any; var root_1123 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1125 lang.IFn
//line :260:1
			if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any; var root_1130 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1132 lang.IFn
//line :259:1
			if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = acc__10; var arg_1134 any = A_arbace_go_check_A_const_151; var arg_1135 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); if linked_1131 == nil { arg_1126 = ifn_1132.Invoke_O_O_O__O(arg_1133, arg_1134, arg_1135) } else { arg_1126 = linked_1131.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1130, arg_1133, arg_1134, arg_1135) }
			var arg_1127 any = A_arbace_go_check_A_const_82; var arg_1128 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1129 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1124 == nil { arg_1120 = ifn_1125.Invoke_O_O_O_O__O(arg_1126, arg_1127, arg_1128, arg_1129) } else { arg_1120 = linked_1124.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1123, arg_1126, arg_1127, arg_1128, arg_1129) }
			var arg_1121 any = A_arbace_go_check_A_const_152; var arg_1122 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A_New_O(present__8); var tmp14 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A_fn_class = fncls__1142d; tmp14 = fncls__1142d } else { tmp14 = fncls__1142 }; arg_1122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1118 == nil { arg_1114 = ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { arg_1114 = linked_1118.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }
			var arg_1115 any = A_arbace_go_check_A_const_127; var arg_1116 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A_New_O(verified__9); var tmp16 *jrt.Class; var fncls__1149 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A_fn_class; if fncls__1149 == nil { var fncls__1149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A_fn_class = fncls__1149d; tmp16 = fncls__1149d } else { tmp16 = fncls__1149 }; arg_1116 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1112 == nil { arg_1108 = ifn_1113.Invoke_O_O_O__O(arg_1114, arg_1115, arg_1116) } else { arg_1108 = linked_1112.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1111, arg_1114, arg_1115, arg_1116) }
			var arg_1109 any = A_arbace_go_check_A_const_153; var arg_1110 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A_New_O(unver__11); var tmp18 *jrt.Class; var fncls__1156 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A_fn_class; if fncls__1156 == nil { var fncls__1156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A_fn_class = fncls__1156d; tmp18 = fncls__1156d } else { tmp18 = fncls__1156 }; arg_1110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1106 == nil { arg_1102 = ifn_1107.Invoke_O_O_O__O(arg_1108, arg_1109, arg_1110) } else { arg_1102 = linked_1106.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1105, arg_1108, arg_1109, arg_1110) }
			var arg_1103 any = A_arbace_go_check_A_const_154; var arg_1104 any; var tmp19 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A_New_O_O_O(form__4, ds__5, unver__11); var tmp20 *jrt.Class; var fncls__1178 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A_fn_class; if fncls__1178 == nil { var fncls__1178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A_fn_class = fncls__1178d; tmp20 = fncls__1178d } else { tmp20 = fncls__1178 }; arg_1104 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); if linked_1100 == nil { return ifn_1101.Invoke_O_O_O__O(arg_1102, arg_1103, arg_1104) } else { return linked_1100.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1099, arg_1102, arg_1103, arg_1104) } } }
//line :242:1
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A_New() *A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A) Invoke_O_O__O(self, p1__1685000087_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_910 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = p1__1685000087_SHARP___1; if linked_911 == nil { tmp2 = ifn_912.Invoke_O__O(arg_913) } else { tmp2 = linked_911.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_910, arg_913) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A_New() *A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A) Invoke_O_O__O(self, p1__1685000088_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_137; var tmp2 any; var root_920 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = p1__1685000088_SHARP___1; if linked_921 == nil { tmp2 = ifn_922.Invoke_O__O(arg_923) } else { tmp2 = linked_921.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_920, arg_923) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A_New() *A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A) Ctor() {}
//line :245:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A) Invoke_O_O__O(self, p1__1685000089_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_127; var tmp2 any; var root_940 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = p1__1685000089_SHARP___1; if linked_941 == nil { tmp2 = ifn_942.Invoke_O__O(arg_943) } else { tmp2 = linked_941.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_940, arg_943) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A{}; t.Ctor_O(p0); return t }
//line :252:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :252:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A) Invoke_O_O__O(self, p1__1685000090_SHARP___1 any) any { var root_981 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_985 any = p1__1685000090_SHARP___1; var arg_986 any = t.F_present; if linked_982 == nil { return ifn_983.Invoke_O_O_O__O(arg_984, arg_985, arg_986) } else { return linked_982.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_981, arg_984, arg_985, arg_986) } }
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A{}; t.Ctor_O(p0); return t }
//line :253:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :253:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A) Invoke_O_O__O(self, p1__1685000091_SHARP___1 any) any { var root_988 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A_New(); var tmp2 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A_fn_class = fncls__1009d; tmp2 = fncls__1009d } else { tmp2 = fncls__1009 }; arg_991 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_992 any = p1__1685000091_SHARP___1; var arg_993 any = t.F_ds; if linked_989 == nil { return ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { return linked_989.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993) } }
//line :253:1
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A_New() *A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A) Ctor() {}
//line :253:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_994 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = d__2; if linked_995 == nil { tmp2 = ifn_996.Invoke_O__O(arg_997) } else { tmp2 = linked_995.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_994, arg_997) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_998 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = m__1; var arg_1002 any = u__4; var arg_1003 any; var root_1004 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var arg_1008 any = A_arbace_go_check_A_const_22; if linked_1005 == nil { arg_1003 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { arg_1003 = linked_1005.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }; if linked_999 == nil { return ifn_1000.Invoke_O_O_O__O(arg_1001, arg_1002, arg_1003) } else { return linked_999.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_998, arg_1001, arg_1002, arg_1003) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A{}; t.Ctor_O(p0); return t }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A) Invoke_O_O__O(self, s__1685000210__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A_New_O_O_O(self, s__1685000210__1, t.F_verified); var tmp2 *jrt.Class; var fncls__1097 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A_fn_class; if fncls__1097 == nil { var fncls__1097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A_fn_class = fncls__1097d; tmp2 = fncls__1097d } else { tmp2 = fncls__1097 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :254:1
func A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A) Ctor_O_O_O(c__iter__1685000209, c__s__1685000210, c__verified any) { t.F_iter__1685000209 = c__iter__1685000209; t.F_s__1685000210 = c__s__1685000210; t.F_verified = c__verified }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A) Invoke_O__O(self any) any { { var s__1685000210__1 any; var t_ any = t.F_s__1685000210; t.F_s__1685000210 = nil; s__1685000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1016 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__1685000210__1; if linked_1017 == nil { temp__1927000414__auto____2 = ifn_1018.Invoke_O__O(arg_1019) } else { temp__1927000414__auto____2 = linked_1017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1016, arg_1019) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1020 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = s__1685000210__3; if linked_1021 == nil { tmp1 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp1 = linked_1021.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1020, arg_1023) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1024 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = s__1685000210__3; if linked_1025 == nil { c__1927001037__auto____4 = ifn_1026.Invoke_O__O(arg_1027) } else { c__1927001037__auto____4 = linked_1025.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1024, arg_1027) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000212__6 any; var root_1028 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1029 == nil { b__1685000212__6 = ifn_1030.Invoke_O__O(arg_1031) } else { b__1685000212__6 = linked_1029.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1028, arg_1031) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A_New_O_I_O_O(b__1685000212__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1047 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A_fn_class; if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A_fn_class = fncls__1047d; tmp3 = fncls__1047d } else { tmp3 = fncls__1047 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1048 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any; var root_1053 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = b__1685000212__6; if linked_1054 == nil { arg_1051 = ifn_1055.Invoke_O__O(arg_1056) } else { arg_1051 = linked_1054.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1053, arg_1056) }; var arg_1052 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000209); var tmp5 any; var root_1057 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = s__1685000210__3; if linked_1058 == nil { tmp5 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp5 = linked_1058.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1057, arg_1060) }; arg_1052 = tmp4.Invoke_O__O(tmp5); if linked_1049 == nil { return ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { return linked_1049.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) } } else { var root_1061 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1066 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = b__1685000212__6; if linked_1067 == nil { arg_1064 = ifn_1068.Invoke_O__O(arg_1069) } else { arg_1064 = linked_1067.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1066, arg_1069) }; var arg_1065 any; if linked_1062 == nil { return ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { return linked_1062.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) } } } else { var vec__1685000220__4 any; var root_1070 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = s__1685000210__3; if linked_1071 == nil { vec__1685000220__4 = ifn_1072.Invoke_O__O(arg_1073) } else { vec__1685000220__4 = linked_1071.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1070, arg_1073) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000220__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000220__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1074 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1076 lang.IFn

	if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = n__6; var arg_1078 any = v__7; if linked_1075 == nil { tmp6 = ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { tmp6 = linked_1075.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) }
//line :254:1
	if jrt.J2g_Truth(tmp6) { var root_1079 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var tmp7 jrt.Number_I; var na_1084 any = n__6; var na_1085 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1084); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1085) }; tmp8 = tmp9; if tmp8 { var n0_1086 int64 = jrt.NN(jrt.Long_Cast(na_1084)).LongValue__J(); var n1_1087 int64 = jrt.NN(jrt.Long_Cast(na_1085)).LongValue__J(); var nr_1088 int64 = n0_1086 - n1_1087; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1087 == -9223372036854775808); if tmp11 { tmp11 = (n0_1086^n1_1087)&(n0_1086^nr_1088) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1088)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1084, na_1085) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1084); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1085) }; tmp12 = tmp13; if tmp12 { var n0_1086_2 float64 = jrt.NN(jrt.Double_Cast(na_1084)).DoubleValue__D(); var n1_1087_2 float64 = jrt.NN(jrt.Double_Cast(na_1085)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1086_2 + -n1_1087_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1084, na_1085) } }
//line :254:1
		arg_1082 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1083 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000209); var tmp15 any; var root_1089 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__1685000210__3; if linked_1090 == nil { tmp15 = ifn_1091.Invoke_O__O(arg_1092) } else { tmp15 = linked_1090.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1089, arg_1092) }; arg_1083 = tmp14.Invoke_O__O(tmp15); if linked_1080 == nil { return ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { return linked_1080.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) } } else { var tmp16 any; var root_1093 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = s__1685000210__3; if linked_1094 == nil { tmp16 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp16 = linked_1094.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1093, arg_1096) }; s__1685000210__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :254:1
func A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A) Ctor_O_I_O_O(c__b__1685000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1685000212 = c__b__1685000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A) Invoke_O__O(self any) any { { var i__1685000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000216__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000211__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000216__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000216__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1032 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1034 lang.IFn

	if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = n__4; var arg_1036 any = v__5; if linked_1033 == nil { tmp2 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { tmp2 = linked_1033.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }
//line :254:1
	if jrt.J2g_Truth(tmp2) { var root_1037 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = t.F_b__1685000212; var arg_1041 any; var tmp3 jrt.Number_I; var na_1042 any = n__4; var na_1043 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1042); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1043) }; tmp4 = tmp5; if tmp4 { var n0_1044 int64 = jrt.NN(jrt.Long_Cast(na_1042)).LongValue__J(); var n1_1045 int64 = jrt.NN(jrt.Long_Cast(na_1043)).LongValue__J(); var nr_1046 int64 = n0_1044 - n1_1045; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1045 == -9223372036854775808); if tmp7 { tmp7 = (n0_1044^n1_1045)&(n0_1044^nr_1046) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1046)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1042, na_1043) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1042); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1043) }; tmp8 = tmp9; if tmp8 { var n0_1044_2 float64 = jrt.NN(jrt.Double_Cast(na_1042)).DoubleValue__D(); var n1_1045_2 float64 = jrt.NN(jrt.Double_Cast(na_1043)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1044_2 + -n1_1045_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1042, na_1043) } }
//line :254:1
		arg_1041 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1038 == nil { ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { linked_1038.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) }; i__1685000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000211__1); continue L1 } else { i__1685000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A{}; t.Ctor_O(p0); return t }
//line :261:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :261:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A) Invoke_O_O__O(self, p1__1685000092_SHARP___1 any) any { var root_1136 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1140 any = p1__1685000092_SHARP___1; var arg_1141 any = t.F_present; if linked_1137 == nil { return ifn_1138.Invoke_O_O_O__O(arg_1139, arg_1140, arg_1141) } else { return linked_1137.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1136, arg_1139, arg_1140, arg_1141) } }
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A{}; t.Ctor_O(p0); return t }
//line :262:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :262:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A) Invoke_O_O__O(self, p1__1685000093_SHARP___1 any) any { var root_1143 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1147 any = p1__1685000093_SHARP___1; var arg_1148 any = t.F_verified; if linked_1144 == nil { return ifn_1145.Invoke_O_O_O__O(arg_1146, arg_1147, arg_1148) } else { return linked_1144.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1143, arg_1146, arg_1147, arg_1148) } }
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :263:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A) Invoke_O_O__O(self, p1__1685000094_SHARP___1 any) any { var root_1150 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1154 any = p1__1685000094_SHARP___1; var arg_1155 any = t.F_unver; if linked_1151 == nil { return ifn_1152.Invoke_O_O_O__O(arg_1153, arg_1154, arg_1155) } else { return linked_1151.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1150, arg_1153, arg_1154, arg_1155) } }
func A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :264:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :264:1
func (t *A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A) Invoke_O_O__O(self, p1__1685000095_SHARP___1 any) any { var tmp1 any; var root_1157 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = t.F_unver; if linked_1158 == nil { tmp1 = ifn_1159.Invoke_O__O(arg_1160) } else { tmp1 = linked_1158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1157, arg_1160) }; if jrt.J2g_Truth(tmp1) { var root_1161 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = p1__1685000095_SHARP___1; var arg_1165 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp4 any; var root_1166 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any; var root_1170 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = t.F_ds; if linked_1171 == nil { arg_1169 = ifn_1172.Invoke_O__O(arg_1173) } else { arg_1169 = linked_1171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1170, arg_1173) }; if linked_1167 == nil { tmp4 = ifn_1168.Invoke_O__O(arg_1169) } else { tmp4 = linked_1167.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1166, arg_1169) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1174 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = t.F_form; if linked_1175 == nil { tmp6 = ifn_1176.Invoke_O__O(arg_1177) } else { tmp6 = linked_1175.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1174, arg_1177) }; arg_1165 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1162 == nil { return ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { return linked_1162.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) } } else { return p1__1685000095_SHARP___1 } }
















func A_arbace_go_check_check_package_fn__1685000238_A_New() *A_arbace_go_check_check_package_fn__1685000238_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000238_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_go_check_check_package_fn__1685000238_A) Ctor() {}
//line :281:1
func (t *A_arbace_go_check_check_package_fn__1685000238_A) Invoke_O_O__O(self, p1__1685000096_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_187; var tmp2 any; var root_2081 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = p1__1685000096_SHARP___1; if linked_2082 == nil { tmp2 = ifn_2083.Invoke_O__O(arg_2084) } else { tmp2 = linked_2082.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2081, arg_2084) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000240__1685000244_A_New() *A_arbace_go_check_check_package_iter__1685000240__1685000244_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000240__1685000244_A{}; t.Ctor(); return t }
//line :285:1
func (t *A_arbace_go_check_check_package_iter__1685000240__1685000244_A) Ctor() {}
//line :285:1
func (t *A_arbace_go_check_check_package_iter__1685000240__1685000244_A) Invoke_O_O__O(self, s__1685000241__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A_New_O_O(s__1685000241__1, self); var tmp2 *jrt.Class; var fncls__2165 *jrt.Class = A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A_fn_class; if fncls__2165 == nil { var fncls__2165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A_fn_class = fncls__2165d; tmp2 = fncls__2165d } else { tmp2 = fncls__2165 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A{}; t.Ctor_O_O(p0, p1); return t }
//line :285:1
func (t *A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A) Ctor_O_O(c__s__1685000241, c__iter__1685000240 any) { t.F_s__1685000241 = c__s__1685000241; t.F_iter__1685000240 = c__iter__1685000240 }
//line :285:1
func (t *A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A) Invoke_O__O(self any) any { { var s__1685000241__1 any; var t_ any = t.F_s__1685000241; t.F_s__1685000241 = nil; s__1685000241__1 = t_; for { var temp__1927000414__auto____2 any; var root_2090 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = s__1685000241__1; if linked_2091 == nil { temp__1927000414__auto____2 = ifn_2092.Invoke_O__O(arg_2093) } else { temp__1927000414__auto____2 = linked_2091.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2090, arg_2093) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000241__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2094 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = s__1685000241__3; if linked_2095 == nil { tmp1 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp1 = linked_2095.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2098 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = s__1685000241__3; if linked_2099 == nil { c__1927001037__auto____4 = ifn_2100.Invoke_O__O(arg_2101) } else { c__1927001037__auto____4 = linked_2099.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2098, arg_2101) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000243__6 any; var root_2102 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2103 == nil { b__1685000243__6 = ifn_2104.Invoke_O__O(arg_2105) } else { b__1685000243__6 = linked_2103.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2102, arg_2105) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1685000243__6); var tmp3 *jrt.Class; var fncls__2120 *jrt.Class = A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A_fn_class; if fncls__2120 == nil { var fncls__2120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A_fn_class = fncls__2120d; tmp3 = fncls__2120d } else { tmp3 = fncls__2120 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2121 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any; var root_2126 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = b__1685000243__6; if linked_2127 == nil { arg_2124 = ifn_2128.Invoke_O__O(arg_2129) } else { arg_2124 = linked_2127.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2126, arg_2129) }; var arg_2125 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000240); var tmp5 any; var root_2130 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = s__1685000241__3; if linked_2131 == nil { tmp5 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp5 = linked_2131.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2130, arg_2133) }; arg_2125 = tmp4.Invoke_O__O(tmp5); if linked_2122 == nil { return ifn_2123.Invoke_O_O__O(arg_2124, arg_2125) } else { return linked_2122.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2121, arg_2124, arg_2125) } } else { var root_2134 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var root_2139 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = b__1685000243__6; if linked_2140 == nil { arg_2137 = ifn_2141.Invoke_O__O(arg_2142) } else { arg_2137 = linked_2140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2139, arg_2142) }; var arg_2138 any; if linked_2135 == nil { return ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { return linked_2135.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) } } } else { var d__4 any; var root_2143 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__1685000241__3; if linked_2144 == nil { d__4 = ifn_2145.Invoke_O__O(arg_2146) } else { d__4 = linked_2144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2143, arg_2146) }; var root_2147 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2152 any = A_arbace_go_check_A_const_215.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2154 lang.IFn
															if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any; var root_2157 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = d__4; if linked_2158 == nil { arg_2155 = ifn_2159.Invoke_O__O(arg_2160) } else { arg_2155 = linked_2158.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2157, arg_2160) }; var arg_2156 any = A_arbace_go_check_A_const_217; if linked_2153 == nil { arg_2150 = ifn_2154.Invoke_O_O__O(arg_2155, arg_2156) } else { arg_2150 = linked_2153.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2152, arg_2155, arg_2156) }
//line :285:1
	var arg_2151 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000240); var tmp7 any; var root_2161 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = s__1685000241__3; if linked_2162 == nil { tmp7 = ifn_2163.Invoke_O__O(arg_2164) } else { tmp7 = linked_2162.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2161, arg_2164) }; arg_2151 = tmp6.Invoke_O__O(tmp7); if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :285:1
func A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000243 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000243 = c__b__1685000243 }
//line :285:1
func (t *A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A) Invoke_O__O(self any) any { { var i__1685000242__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000242__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000242__1)); var root_2106 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = t.F_b__1685000243; var arg_2110 any; var root_2111 any = A_arbace_go_check_A_const_215.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2113 lang.IFn
																	if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any; var root_2116 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = d__2; if linked_2117 == nil { arg_2114 = ifn_2118.Invoke_O__O(arg_2119) } else { arg_2114 = linked_2117.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2116, arg_2119) }; var arg_2115 any = A_arbace_go_check_A_const_216; if linked_2112 == nil { arg_2110 = ifn_2113.Invoke_O_O__O(arg_2114, arg_2115) } else { arg_2110 = linked_2112.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2111, arg_2114, arg_2115) }
//line :285:1
	if linked_2107 == nil { ifn_2108.Invoke_O_O__O(arg_2109, arg_2110) } else { linked_2107.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2106, arg_2109, arg_2110) }; i__1685000242__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000242__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :295:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_226; var tmp2 any = A_arbace_go_check_A_const_227; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_228; var tmp5 any; var root_2269 any = A_arbace_go_check_A_const_229.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2271 lang.IFn; if



	linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2270 == nil { tmp5 = ifn_2271.Invoke_O__O(arg_2272) } else { tmp5 = linked_2270.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2269, arg_2272) }; return /*line :295:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2273 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2275 lang.IFn; if



	linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = A_arbace_go_check_A_const_228.Invoke_O__O(s__0); if linked_2274 == nil { tmp1 = ifn_2275.Invoke_O__O(arg_2276) } else { tmp1 = linked_2274.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2273, arg_2276) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_227.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2277 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = p__5; if linked_2278 == nil { tmp2 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp2 = linked_2278.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2277, arg_2280) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2281 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = p__5; if linked_2282 == nil { or__1927000174__auto____3 = ifn_2283.Invoke_O__O(arg_2284) } else { or__1927000174__auto____3 = linked_2282.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2281, arg_2284) } } else { or__1927000174__auto____3 = nil } } else {
//line :307:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_231.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2285 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, A_arbace_go_check_ns_package_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = d__5; var arg_2289 any = ns_name__1; if linked_2286 == nil { return ifn_2287.Invoke_O_O__O(arg_2288, arg_2289) } else { return linked_2286.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2285, arg_2288, arg_2289) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :312:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000253_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2333 *jrt.Class = A_arbace_go_check_resolver_fn__1685000253_A_fn_class; _ = deps__4; if




	fncls__2333 == nil { var fncls__2333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_resolver_fn__1685000253_A_fn_class = fncls__2333d; tmp2 = fncls__2333d } else { tmp2 = fncls__2333 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :317:1
func A_arbace_go_check_resolver_fn__1685000253_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000253_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000253_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :317:1
func (t *A_arbace_go_check_resolver_fn__1685000253_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :317:1
func (t *A_arbace_go_check_resolver_fn__1685000253_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_123, path__1) { return A_arbace_go_check_A_const_233.GetRawRoot__O() } else { var lp__3 any; var root_2290 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2292 lang.IFn

		if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = t.F_src; var arg_2294 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_81, A_arbace_go_check_A_const_234, path__1); var arg_2295 any = path__1; if linked_2291 == nil { lp__3 = ifn_2292.Invoke_O_O_O__O(arg_2293, arg_2294, arg_2295) } else { lp__3 = linked_2291.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2290, arg_2293, arg_2294, arg_2295) }
//line :320:1
		var p__4 any; var or__1927000174__auto____4 any; var root_2296 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2298 lang.IFn



		if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = t.F_s; var arg_2300 any = lp__3; var arg_2301 any = t.F_src; var arg_2302 any = t.F_chain; if linked_2297 == nil { or__1927000174__auto____4 = ifn_2298.Invoke_O_O_O_O__O(arg_2299, arg_2300, arg_2301, arg_2302) } else { or__1927000174__auto____4 = linked_2297.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2296, arg_2299, arg_2300, arg_2301, arg_2302) }; if jrt.J2g_Truth(or__1927000174__auto____4) { p__4 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp1 any; var and__1927000168__auto____5 any; var root_2303 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2305 lang.IFn
			if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any; var root_2307 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any; var root_2312 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any; var root_2316 any = A_arbace_go_check_A_const_237.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = lp__3; var arg_2320 any = A_arbace_go_check_A_const_238; if linked_2317 == nil { arg_2315 = ifn_2318.Invoke_O_O__O(arg_2319, arg_2320) } else { arg_2315 = linked_2317.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2316, arg_2319, arg_2320) }; if linked_2313 == nil { arg_2310 = ifn_2314.Invoke_O__O(arg_2315) } else { arg_2310 = linked_2313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2312, arg_2315) }; var arg_2311 any = Lit_124; if linked_2308 == nil { arg_2306 = ifn_2309.Invoke_O_O__O(arg_2310, arg_2311) } else { arg_2306 = linked_2308.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2307, arg_2310, arg_2311) }; if linked_2304 == nil { and__1927000168__auto____5 = ifn_2305.Invoke_O__O(arg_2306) } else { and__1927000168__auto____5 = linked_2304.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2303, arg_2306) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____5 = nil } else { or__1927000174__auto____5 = nil }
//line :324:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { p__4 = or__1927000174__auto____5 } else {

				var root_2321 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = t.F_s; var arg_2325 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_125, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2326 any = t.F_src; var arg_2327 any = t.F_chain; if linked_2322 == nil { p__4 = ifn_2323.Invoke_O_O_O_O__O(arg_2324, arg_2325, arg_2326, arg_2327) } else { p__4 = linked_2322.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2321, arg_2324, arg_2325, arg_2326, arg_2327) } } }
//line :320:1
		return p__4 } }
//line :317:1
func (t *A_arbace_go_check_resolver_fn__1685000253_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2328 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2328, A_arbace_go_check_ns_package_A_fn_class); var ifn_2330 lang.IFn; if linked_2329 == nil { ifn_2330 = lang.IFn_Cast(root_2328) } else { ifn_2330 = nil }; var arg_2331 any = t.F_s; var arg_2332 any = ns_name__1; if linked_2329 == nil { return ifn_2330.Invoke_O_O__O(arg_2331, arg_2332) } else { return linked_2329.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2328, arg_2331, arg_2332)
	}
}








func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :329:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2388 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2392 any = chain__3; if linked_2389 == nil { tmp1 = ifn_2390.Invoke_O_O__O(arg_2391, arg_2392) } else { tmp1 = linked_2389.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2388, arg_2391, arg_2392) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2393 any = A_arbace_go_check_A_const_243.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2395 lang.IFn
		if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil); var tmp4 any; var root_2398 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = Lit_100; var arg_2402 any; var root_2403 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = chain__3; var arg_2407 any = path__1; if linked_2404 == nil { arg_2402 = ifn_2405.Invoke_O_O__O(arg_2406, arg_2407) } else { arg_2402 = linked_2404.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2403, arg_2406, arg_2407) }; if linked_2399 == nil { tmp4 = ifn_2400.Invoke_O_O__O(arg_2401, arg_2402) } else { tmp4 = linked_2399.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2398, arg_2401, arg_2402) }; arg_2396 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2397 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104, path__1)); if linked_2394 == nil { tmp2 = ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { tmp2 = linked_2394.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) }
//line :332:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :329:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_231.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2334 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = lang.IFn_Cast(A_arbace_go_check_A_const_239.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2335 == nil { and__1927000168__auto____6 = ifn_2336.Invoke_O__O(arg_2337) } else { and__1927000168__auto____6 = linked_2335.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2334, arg_2337) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_231.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2338 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2340 lang.IFn

		if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = d__6; var arg_2342 any = path__1; var arg_2343 any = importer__2; var arg_2344 any = chain__3; if linked_2339 == nil { return ifn_2340.Invoke_O_O_O_O__O(arg_2341, arg_2342, arg_2343, arg_2344) } else { return linked_2339.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2338, arg_2341, arg_2342, arg_2343, arg_2344) } } else {
//line :334:1
			var cache__6 any = A_arbace_go_check_A_const_227.Invoke_O__O(s__0); var p__7 any; var root_2345 any = A_arbace_go_check_A_const_240.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2347 lang.IFn



			if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; if linked_2346 == nil { p__7 = ifn_2347.Invoke__O() } else { p__7 = linked_2346.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2345) }
//line :334:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2348 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = prev__8; if linked_2349 == nil { return ifn_2350.Invoke_O__O(arg_2351) } else { return linked_2349.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2348, arg_2351) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_226.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2352 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__9); if linked_2353 == nil { tmp5 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp5 = linked_2353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2352, arg_2355) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000256_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2387 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000256_A_fn_class; if fncls__2387 == nil { var fncls__2387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_go_check_ensure_package_fn__1685000256_A_fn_class = fncls__2387d; tmp7 = fncls__2387d } else { tmp7 = fncls__2387 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :343:1
						pkg__10 = nil
					}




				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2408 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2412 any = A_arbace_go_check_A_const_246; var arg_2413 any; var root_2414 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2416 lang.IFn; if linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2418 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_247; var tmp11 any; var root_2419 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = pkg__10; var arg_2423 any = A_arbace_go_check_A_const_71; if linked_2420 == nil { tmp11 = ifn_2421.Invoke_O_O__O(arg_2422, arg_2423) } else { tmp11 = linked_2420.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2419, arg_2422, arg_2423) }; arg_2418 = tmp10.Invoke_O__O(tmp11); if linked_2415 == nil { arg_2413 = ifn_2416.Invoke_O_O__O(arg_2417, arg_2418) } else { arg_2413 = linked_2415.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2414, arg_2417, arg_2418) }; if linked_2409 == nil { tmp9 = ifn_2410.Invoke_O_O_O__O(arg_2411, arg_2412, arg_2413) } else { tmp9 = linked_2409.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2408, arg_2411, arg_2412, arg_2413) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2424 any = A_arbace_go_check_A_const_248.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = A_arbace_go_check_A_const_228.Invoke_O__O(s__0); var arg_2428 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var arg_2429 any; var root_2431 any = A_arbace_go_check_A_const_172.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_2433 lang.IFn; if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = path__1; if linked_2432 == nil { arg_2429 = ifn_2433.Invoke_O__O(arg_2434) } else { arg_2429 = linked_2432.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2431, arg_2434) }; var arg_2430 any = path__1; if linked_2425 == nil { ifn_2426.Invoke_O_O_O_O__O(arg_2427, arg_2428, arg_2429, arg_2430) } else { linked_2425.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2424, arg_2427, arg_2428, arg_2429, arg_2430) }
				var root_2435 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = p__7; var arg_2439 any = pkg__10; if linked_2436 == nil { ifn_2437.Invoke_O_O__O(arg_2438, arg_2439) } else { linked_2436.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2435, arg_2438, arg_2439) }
//line :340:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000256_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000256_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000256_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :344:1
func (t *A_arbace_go_check_ensure_package_fn__1685000256_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :344:1
func (t *A_arbace_go_check_ensure_package_fn__1685000256_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_241.GetRawRoot__O()); var tmp3 any = t.F_src; var tmp4 any; var root_2361 any = A_arbace_go_check_A_const_242.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, A_arbace_go_check_resolver_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any; var t_ any = t.F_s; t.F_s = nil; arg_2364 = t_; var arg_2365 any; var t__2 any = t.F_src; t.F_src = nil; arg_2365 = t__2; var arg_2366 any; var root_2367 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any; var root_2372 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2375 = t__3; if linked_2373 == nil { arg_2370 = ifn_2374.Invoke_O__O(arg_2375) } else { arg_2370 = linked_2373.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2372, arg_2375) }; var arg_2371 any = t.F_path; if linked_2368 == nil { arg_2366 = ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { arg_2366 = linked_2368.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) }; if linked_2362 == nil { tmp4 = ifn_2363.Invoke_O_O_O__O(arg_2364, arg_2365, arg_2366) } else { tmp4 = linked_2362.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2361, arg_2364, arg_2365, arg_2366) }; tmp1 = tmp2.Invoke_O_O__O(tmp3, tmp4) }
//line :344:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_2382 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2382, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2384 lang.IFn


		if linked_2383 == nil { ifn_2384 = lang.IFn_Cast(root_2382) } else { ifn_2384 = nil }; var arg_2385 any; var t__4 any = t.F_p; t.F_p = nil; arg_2385 = t__4; var arg_2386 any; if linked_2383 == nil { ifn_2384.Invoke_O_O__O(arg_2385, arg_2386) } else { linked_2383.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2382, arg_2385, arg_2386) }
//line :344:1
		var tmp6 any; var root_2376 any = A_arbace_go_check_A_const_243.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2378 lang.IFn



		if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var tmp7 any = t.F_path; var arg_2379 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2380 any; var tmp8 any = A_arbace_go_check_A_const_104; var tmp9 any; var t__5 any = t.F_path; t.F_path = nil; tmp9 = t__5; arg_2380 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)); var arg_2381 any = ex__3; if linked_2377 == nil { tmp6 = ifn_2378.Invoke_O_O_O__O(arg_2379, arg_2380, arg_2381) } else { tmp6 = linked_2377.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2376, arg_2379, arg_2380, arg_2381) }
//line :344:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) } }; return tmp1 }













func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :358:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :358:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var G__1685000259__2_ any = corpus__0; switch
											lang.Util_Hash_O__I_NoInit(G__1685000259__2_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000259__2_, Lit_87) { var tmp1 any = A_arbace_go_check_A_const_249; var tmp2 any = A_arbace_go_check_A_const_251; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_250; var tmp5 any = A_arbace_go_check_A_const_251; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_89), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_253, Lit_90)), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_254)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000259__2_, Lit_91) { var tmp6 any = A_arbace_go_check_A_const_249; var tmp7 any = A_arbace_go_check_A_const_251; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_255; var tmp10 any = A_arbace_go_check_A_const_251; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_92), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_253, Lit_90)), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_256)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000259__2_, Lit_51) { var tmp11 any = A_arbace_go_check_A_const_249; var tmp12 any = A_arbace_go_check_A_const_251; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref(); var tmp14 any = A_arbace_go_check_A_const_260; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_257)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000259__2_, Lit_95) { var tmp15 any = A_arbace_go_check_A_const_249; var tmp16 any = A_arbace_go_check_A_const_251; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref(); var tmp18 any = A_arbace_go_check_A_const_260; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_96), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_258)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000259__2_, Lit_97) { var tmp19 any = A_arbace_go_check_A_const_249; var tmp20 any = A_arbace_go_check_A_const_251; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_261)) }; default:}; var tmp21 any; var root_2441 any = A_arbace_go_check_A_const_243.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2443 lang.IFn; if












	linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2445 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_259, corpus__0)); if linked_2442 == nil { tmp21 = ifn_2443.Invoke_O_O__O(arg_2444, arg_2445) } else { tmp21 = linked_2442.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2441, arg_2444, arg_2445) }; /*line :359:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp21))) }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :374:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000262__0 any) any { var map__1685000263__2 any = p__1685000262__0; var map__1685000263__3 any; if lang.ISeq_InstanceOf(map__1685000263__2) { var tmp1 any; var root_2446 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = map__1685000263__2; if linked_2447 == nil { tmp1 = ifn_2448.Invoke_O__O(arg_2449) } else { tmp1 = linked_2447.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2446, arg_2449) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2450 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2452 lang.IFn; if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any = map__1685000263__2; if linked_2451 == nil { tmp2 = ifn_2452.Invoke_O__O(arg_2453) } else { tmp2 = linked_2451.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2450, arg_2453) }; map__1685000263__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = map__1685000263__2; if linked_2455 == nil { tmp3 = ifn_2456.Invoke_O__O(arg_2457) } else { tmp3 = linked_2455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2454, arg_2457) }; if jrt.J2g_Truth(tmp3) { var root_2458 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2460 lang.IFn; if linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any = map__1685000263__2; if linked_2459 == nil { map__1685000263__3 = ifn_2460.Invoke_O__O(arg_2461) } else { map__1685000263__3 = linked_2459.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2458, arg_2461) } } else { map__1685000263__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000263__3 = map__1685000263__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000263__3, A_arbace_go_check_A_const_249); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000263__3, A_arbace_go_check_A_const_105); var root_2462 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2462, A_arbace_go_check_session_A_fn_class); var ifn_2464 lang.IFn; if
											linked_2463 == nil { ifn_2464 = lang.IFn_Cast(root_2462) } else { ifn_2464 = nil }; var arg_2465 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000265_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__2478 *jrt.Class = A_arbace_go_check_std_session_fn__1685000265_A_fn_class; if fncls__2478 == nil { var fncls__2478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_std_session_fn__1685000265_A_fn_class = fncls__2478d; tmp5 = fncls__2478d } else { tmp5 = fncls__2478 }; arg_2465 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_2463 == nil { return ifn_2464.Invoke_O__O(arg_2465) } else { return linked_2463.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2462, arg_2465) } }
//line :375:1
func A_arbace_go_check_std_session_fn__1685000265_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000265_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000265_A{}; t.Ctor_O_O(p0, p1); return t }
//line :375:1
func (t *A_arbace_go_check_std_session_fn__1685000265_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :375:1
func (t *A_arbace_go_check_std_session_fn__1685000265_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_2466 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_2467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2466, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2468 lang.IFn; if linked_2467 == nil { ifn_2468 = lang.IFn_Cast(root_2466) } else { ifn_2468 = nil }; var arg_2469 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__2477 *jrt.Class = A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A_fn_class; if fncls__2477 == nil { var fncls__2477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A_fn_class = fncls__2477d; tmp2 = fncls__2477d } else { tmp2 = fncls__2477 }; arg_2469 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2470 any = t.F_roots; if linked_2467 == nil { return ifn_2468.Invoke_O_O__O(arg_2469, arg_2470) } else { return linked_2467.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2466, arg_2469, arg_2470) } }
//line :376:1
func A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A{}; t.Ctor_O_O(p0, p1); return t }
//line :376:1
func (t *A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :376:1
func (t *A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A) Invoke_O_O__O(self, p1__1685000261_SHARP___1 any) any { var root_2471 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = p1__1685000261_SHARP___1; var arg_2475 any = t.F_path; var arg_2476 any = t.F_config; if linked_2472 == nil { return ifn_2473.Invoke_O_O_O__O(arg_2474, arg_2475, arg_2476) } else { return linked_2472.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_2471, arg_2474, arg_2475, arg_2476) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :382:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :382:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_2479 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2481 lang.IFn; if


	linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any = xs__2; if linked_2480 == nil { xs__4 = ifn_2481.Invoke_O__O(arg_2482) } else { xs__4 = linked_2480.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2479, arg_2482) }; var q__5 any = /*line :382:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_2483 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2483, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2485 lang.IFn; if





	linked_2484 == nil { ifn_2485 = lang.IFn_Cast(root_2483) } else { ifn_2485 = nil }; var arg_2486 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__2555 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A_fn_class; if fncls__2555 == nil { var fncls__2555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A_fn_class = fncls__2555d; tmp2 = fncls__2555d } else { tmp2 = fncls__2555 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_2556 any = A_arbace_go_check_A_const_268.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = n__0; if linked_2557 == nil { tmp4 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp4 = linked_2557.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2556, arg_2559) }; arg_2486 = tmp3.Invoke_O__O(tmp4); if linked_2484 == nil { workers__7 = ifn_2485.Invoke_O__O(arg_2486) } else { workers__7 = linked_2484.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2483, arg_2486) }; var seq_1685000284__8 any; var root_2564 any = /*line :382:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2566 lang.IFn; if















	linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = workers__7; if linked_2565 == nil { seq_1685000284__8 = ifn_2566.Invoke_O__O(arg_2567) } else { seq_1685000284__8 = linked_2565.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2564, arg_2567) }; var chunk_1685000285__9 any; var count_1685000286__10 int64 = 0; var i_1685000287__11 int64 = 0; L1:
//line :382:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000287__11, count_1685000286__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000285__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000287__11)); var root_2584 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any = w__12; if linked_2585 == nil { ifn_2586.Invoke_O__O(arg_2587) } else { linked_2585.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2584, arg_2587) }; seq_1685000284__8, chunk_1685000285__9, count_1685000286__10, i_1685000287__11 = seq_1685000284__8, chunk_1685000285__9, count_1685000286__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000287__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_2568 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = seq_1685000284__8; if linked_2569 == nil { temp__1927000414__auto____12 = ifn_2570.Invoke_O__O(arg_2571) } else { temp__1927000414__auto____12 = linked_2569.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2568, arg_2571) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000284__13 any = temp__1927000414__auto____12; var tmp5 any; var root_2572 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = seq_1685000284__13; if linked_2573 == nil { tmp5 = ifn_2574.Invoke_O__O(arg_2575) } else { tmp5 = linked_2573.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2572, arg_2575) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_2576 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = seq_1685000284__13; if linked_2577 == nil { c__1927000678__auto____14 = ifn_2578.Invoke_O__O(arg_2579) } else { c__1927000678__auto____14 = linked_2577.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2576, arg_2579) }; var tmp6 any; var root_2588 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = seq_1685000284__13; if linked_2589 == nil { tmp6 = ifn_2590.Invoke_O__O(arg_2591) } else { tmp6 = linked_2589.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2588, arg_2591) }; seq_1685000284__8, chunk_1685000285__9, count_1685000286__10, i_1685000287__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_2580 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = seq_1685000284__13; if linked_2581 == nil { w__14 = ifn_2582.Invoke_O__O(arg_2583) } else { w__14 = linked_2581.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2580, arg_2583) }; var root_2592 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = w__14; if linked_2593 == nil { ifn_2594.Invoke_O__O(arg_2595) } else { linked_2593.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2592, arg_2595) }; var tmp7 any; var root_2596 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = seq_1685000284__13; if linked_2597 == nil { tmp7 = ifn_2598.Invoke_O__O(arg_2599) } else { tmp7 = linked_2597.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2596, arg_2599) }; seq_1685000284__8, chunk_1685000285__9, count_1685000286__10, i_1685000287__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :382:1
		break L1 }; var root_2560 any =
















	A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = out__6; if linked_2561 == nil { return ifn_2562.Invoke_O__O(arg_2563) } else { return linked_2561.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2560, arg_2563) } }
//line :388:1
func A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :388:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :388:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A) Invoke_O_O__O(self, s__1685000271__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A_New_O_O_O_O_O_O(t.F_f, t.F_out, t.F_q, s__1685000271__1, self, t.F_xs); var tmp2 *jrt.Class; var fncls__2554 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A_fn_class; if fncls__2554 == nil { var fncls__2554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A_fn_class = fncls__2554d; tmp2 = fncls__2554d } else { tmp2 = fncls__2554 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :388:1
func A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :388:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A) Ctor_O_O_O_O_O_O(c__f, c__out, c__q, c__s__1685000271, c__iter__1685000270, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_s__1685000271 = c__s__1685000271; t.F_iter__1685000270 = c__iter__1685000270; t.F_xs = c__xs }
//line :388:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A) Invoke_O__O(self any) any { { var s__1685000271__1 any; var t_ any = t.F_s__1685000271; t.F_s__1685000271 = nil; s__1685000271__1 = t_; for { var temp__1927000414__auto____2 any; var root_2487 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2489 lang.IFn; if linked_2488 == nil { ifn_2489 = lang.IFn_Cast(root_2487) } else { ifn_2489 = nil }; var arg_2490 any = s__1685000271__1; if linked_2488 == nil { temp__1927000414__auto____2 = ifn_2489.Invoke_O__O(arg_2490) } else { temp__1927000414__auto____2 = linked_2488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2487, arg_2490) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000271__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2491 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2491, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2493 lang.IFn; if linked_2492 == nil { ifn_2493 = lang.IFn_Cast(root_2491) } else { ifn_2493 = nil }; var arg_2494 any = s__1685000271__3; if linked_2492 == nil { tmp1 = ifn_2493.Invoke_O__O(arg_2494) } else { tmp1 = linked_2492.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2491, arg_2494) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2495 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2495, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2497 lang.IFn; if linked_2496 == nil { ifn_2497 = lang.IFn_Cast(root_2495) } else { ifn_2497 = nil }; var arg_2498 any = s__1685000271__3; if linked_2496 == nil { c__1927001037__auto____4 = ifn_2497.Invoke_O__O(arg_2498) } else { c__1927001037__auto____4 = linked_2496.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2495, arg_2498) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000273__6 any; var root_2499 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2500 == nil { b__1685000273__6 = ifn_2501.Invoke_O__O(arg_2502) } else { b__1685000273__6 = linked_2500.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2499, arg_2502) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A_New_O_O_O_O_I_O_O(t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, b__1685000273__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2513 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A_fn_class; if fncls__2513 == nil { var fncls__2513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A_fn_class = fncls__2513d; tmp3 = fncls__2513d } else { tmp3 = fncls__2513 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2514 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any; var root_2519 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = b__1685000273__6; if linked_2520 == nil { arg_2517 = ifn_2521.Invoke_O__O(arg_2522) } else { arg_2517 = linked_2520.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2519, arg_2522) }; var arg_2518 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000270); var tmp5 any; var root_2523 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = s__1685000271__3; if linked_2524 == nil { tmp5 = ifn_2525.Invoke_O__O(arg_2526) } else { tmp5 = linked_2524.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2523, arg_2526) }; arg_2518 = tmp4.Invoke_O__O(tmp5); if linked_2515 == nil { return ifn_2516.Invoke_O_O__O(arg_2517, arg_2518) } else { return linked_2515.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2514, arg_2517, arg_2518) } } else { var root_2527 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any; var root_2532 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = b__1685000273__6; if linked_2533 == nil { arg_2530 = ifn_2534.Invoke_O__O(arg_2535) } else { arg_2530 = linked_2533.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2532, arg_2535) }; var arg_2531 any; if linked_2528 == nil { return ifn_2529.Invoke_O_O__O(arg_2530, arg_2531) } else { return linked_2528.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2527, arg_2530, arg_2531) } } } else { var ___4 any; var root_2536 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2538 lang.IFn; _ = ___4; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = s__1685000271__3; if linked_2537 == nil { ___4 = ifn_2538.Invoke_O__O(arg_2539) } else { ___4 = linked_2537.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2536, arg_2539) }; var root_2540 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any; var root_2545 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2547 lang.IFn
															if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__2549 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A_fn_class; if fncls__2549 == nil { var fncls__2549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A_fn_class = fncls__2549d; tmp7 = fncls__2549d } else { tmp7 = fncls__2549 }; arg_2548 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2546 == nil { arg_2543 = ifn_2547.Invoke_O__O(arg_2548) } else { arg_2543 = linked_2546.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2545, arg_2548) }
//line :388:1
	var arg_2544 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000270); var tmp9 any; var root_2550 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any = s__1685000271__3; if linked_2551 == nil { tmp9 = ifn_2552.Invoke_O__O(arg_2553) } else { tmp9 = linked_2551.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2550, arg_2553) }; arg_2544 = tmp8.Invoke_O__O(tmp9); if linked_2541 == nil { return ifn_2542.Invoke_O_O__O(arg_2543, arg_2544) } else { return linked_2541.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2540, arg_2543, arg_2544) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :388:1
func A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :388:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A) Ctor_O_O_O_O_I_O_O(c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__b__1685000273, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000273 = c__b__1685000273; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :388:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A) Invoke_O__O(self any) any { { var i__1685000272__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000272__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000272__1)); var root_2503 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2505 lang.IFn; _ = ___2; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = t.F_b__1685000273; var arg_2507 any; var root_2508 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2510 lang.IFn
																if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__2512 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A_fn_class; if fncls__2512 == nil { var fncls__2512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A_fn_class = fncls__2512d; tmp3 = fncls__2512d } else { tmp3 = fncls__2512 }; arg_2511 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2509 == nil { arg_2507 = ifn_2510.Invoke_O__O(arg_2511) } else { arg_2507 = linked_2509.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2508, arg_2511) }
//line :388:1
	if linked_2504 == nil { ifn_2505.Invoke_O_O__O(arg_2506, arg_2507) } else { linked_2504.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2503, arg_2506, arg_2507) }; i__1685000272__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000272__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_266.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_266.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_267) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_266.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_266.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :392:1
			return nil } } }; /*line :389:1*/panic("j2g: unreachable") }
//line :389:1
func A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_266.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_266.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_267) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_266.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_266.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :392:1
			return nil } } }; /*line :389:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :401:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :401:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_2600 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = pkg__0; var arg_2604 any = A_arbace_go_check_A_const_206; if linked_2601 == nil { return ifn_2602.Invoke_O_O__O(arg_2603, arg_2604) } else { return linked_2601.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2600, arg_2603, arg_2604) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :403:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_104; var tmp2 any = A_arbace_go_check_A_const_207; var tmp3 any = A_arbace_go_check_A_const_73; var tmp4 any = A_arbace_go_check_A_const_78; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_270; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_104, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :403:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_271, A_arbace_go_check_A_const_272))), A_arbace_go_check_A_const_151, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_140, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_142, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_127, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_153, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_132, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_269, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :410:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_2605 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, A_arbace_go_check_corpus_config_A_fn_class); var ifn_2607 lang.IFn; if


	linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = corpus__0; if linked_2606 == nil { cc__3 = ifn_2607.Invoke_O__O(arg_2608) } else { cc__3 = linked_2606.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_2605, arg_2608) }; var s__4 any; var root_2609 any = /*line :410:1*/A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2609, A_arbace_go_check_std_session_A_fn_class); var ifn_2611 lang.IFn; if



	linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = cc__3; if linked_2610 == nil { s__4 = ifn_2611.Invoke_O__O(arg_2612) } else { s__4 = linked_2610.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_2609, arg_2612) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :410:1*/A_arbace_go_check_A_const_255.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_250.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_2613 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2615 lang.IFn
		if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = A_arbace_go_check_A_const_249.Invoke_O__O(cc__3); if linked_2614 == nil { root__5 = ifn_2615.Invoke_O__O(arg_2616) } else { root__5 = linked_2614.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2613, arg_2616) }
		var root_2617 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A_New(); var tmp3 *jrt.Class; var fncls__2687 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A_fn_class; if fncls__2687 == nil { var fncls__2687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A_fn_class = fncls__2687d; tmp3 = fncls__2687d } else { tmp3 = fncls__2687 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_2688 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2688, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2690 lang.IFn; if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = root__5; var arg_2692 any = Lit_33; if linked_2689 == nil { tmp5 = ifn_2690.Invoke_O_O__O(arg_2691, arg_2692) } else { tmp5 = linked_2689.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2688, arg_2691, arg_2692) }; arg_2620 = tmp4.Invoke_O__O(tmp5); if linked_2618 == nil { std_pkgs__5 = ifn_2619.Invoke_O__O(arg_2620) } else { std_pkgs__5 = linked_2618.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2617, arg_2620) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_2693 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2695 lang.IFn; if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = jobs__1; var arg_2697 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000302_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__2715 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000302_A_fn_class
		if fncls__2715 == nil { var fncls__2715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_check_corpus_fn__1685000302_A_fn_class = fncls__2715d; tmp7 = fncls__2715d } else { tmp7 = fncls__2715 }; arg_2697 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :422:1
		var arg_2698 any = std_pkgs__5; if linked_2694 == nil { return ifn_2695.Invoke_O_O_O__O(arg_2696, arg_2697, arg_2698) } else { return linked_2694.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2693, arg_2696, arg_2697, arg_2698) } } else {
//line :420:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_255.Invoke_O__O(cc__3)) { var map__1685000304__6 any = A_arbace_go_check_A_const_255.Invoke_O__O(cc__3); var map__1685000304__7 any








				if lang.ISeq_InstanceOf(map__1685000304__6) { var tmp8 any; var root_2716 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = map__1685000304__6; if linked_2717 == nil { tmp8 = ifn_2718.Invoke_O__O(arg_2719) } else { tmp8 = linked_2717.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2716, arg_2719) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2720 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2720, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2722 lang.IFn; if linked_2721 == nil { ifn_2722 = lang.IFn_Cast(root_2720) } else { ifn_2722 = nil }; var arg_2723 any = map__1685000304__6; if linked_2721 == nil { tmp9 = ifn_2722.Invoke_O__O(arg_2723) } else { tmp9 = linked_2721.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2720, arg_2723) }; map__1685000304__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_2724 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = map__1685000304__6; if linked_2725 == nil { tmp10 = ifn_2726.Invoke_O__O(arg_2727) } else { tmp10 = linked_2725.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2724, arg_2727) }; if jrt.J2g_Truth(tmp10) { var root_2728 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = map__1685000304__6; if linked_2729 == nil { map__1685000304__7 = ifn_2730.Invoke_O__O(arg_2731) } else { map__1685000304__7 = linked_2729.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2728, arg_2731) } } else { map__1685000304__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000304__7 = map__1685000304__6 }
//line :420:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000304__7, A_arbace_go_check_A_const_251); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000304__7, A_arbace_go_check_A_const_253); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_251, dir__8)); var root_2732 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2732, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2734 lang.IFn










				if linked_2733 == nil { ifn_2734 = lang.IFn_Cast(root_2732) } else { ifn_2734 = nil }; var arg_2735 any = jobs__1; var arg_2736 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000306_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__2780 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000306_A_fn_class
				if fncls__2780 == nil { var fncls__2780d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_fn__1685000306_A_fn_class = fncls__2780d; tmp12 = fncls__2780d } else { tmp12 = fncls__2780 }; arg_2736 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :431:1
				var arg_2737 any; var root_2781 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2783 lang.IFn








				if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = root__10; var arg_2785 any = sub__9; if linked_2782 == nil { arg_2737 = ifn_2783.Invoke_O_O__O(arg_2784, arg_2785) } else { arg_2737 = linked_2782.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2781, arg_2784, arg_2785) }
//line :431:1
				if linked_2733 == nil { return ifn_2734.Invoke_O_O_O__O(arg_2735, arg_2736, arg_2737) } else { return linked_2733.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2732, arg_2735, arg_2736, arg_2737) } } else {
//line :420:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_250.Invoke_O__O(cc__3)) { var map__1685000308__6 any = A_arbace_go_check_A_const_250.Invoke_O__O(cc__3); var map__1685000308__7 any





















						if lang.ISeq_InstanceOf(map__1685000308__6) { var tmp13 any; var root_2786 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2788 lang.IFn; if linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any = map__1685000308__6; if linked_2787 == nil { tmp13 = ifn_2788.Invoke_O__O(arg_2789) } else { tmp13 = linked_2787.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2786, arg_2789) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_2790 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any = map__1685000308__6; if linked_2791 == nil { tmp14 = ifn_2792.Invoke_O__O(arg_2793) } else { tmp14 = linked_2791.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2790, arg_2793) }; map__1685000308__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp14, jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 any; var root_2794 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any = map__1685000308__6; if linked_2795 == nil { tmp15 = ifn_2796.Invoke_O__O(arg_2797) } else { tmp15 = linked_2795.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2794, arg_2797) }; if jrt.J2g_Truth(tmp15) { var root_2798 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2798, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2800 lang.IFn; if linked_2799 == nil { ifn_2800 = lang.IFn_Cast(root_2798) } else { ifn_2800 = nil }; var arg_2801 any = map__1685000308__6; if linked_2799 == nil { map__1685000308__7 = ifn_2800.Invoke_O__O(arg_2801) } else { map__1685000308__7 = linked_2799.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2798, arg_2801) } } else { map__1685000308__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000308__7 = map__1685000308__6 }
//line :420:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000308__7, A_arbace_go_check_A_const_251); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000308__7, A_arbace_go_check_A_const_253); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_251, dir__8_2)); var pfs__11 any; var root_2802 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2804 lang.IFn























						if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any = root__10_2; var arg_2806 any = sub__9_2; if linked_2803 == nil { pfs__11 = ifn_2804.Invoke_O_O__O(arg_2805, arg_2806) } else { pfs__11 = linked_2803.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2802, arg_2805, arg_2806) }
//line :420:1
						var tests__12 any; var root_2807 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_2808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2807, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2809 lang.IFn

























						if linked_2808 == nil { ifn_2809 = lang.IFn_Cast(root_2807) } else { ifn_2809 = nil }; var arg_2810 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000310_A_New(); var tmp17 *jrt.Class; var fncls__2817 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class; if fncls__2817 == nil { var fncls__2817d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class = fncls__2817d; tmp17 = fncls__2817d } else { tmp17 = fncls__2817 }; arg_2810 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_2811 any = pfs__11; if linked_2808 == nil { tests__12 = ifn_2809.Invoke_O_O__O(arg_2810, arg_2811) } else { tests__12 = linked_2808.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2807, arg_2810, arg_2811)
						}


						var root_2818 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2818, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2820 lang.IFn; if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any; var root_2822 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_2823 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2822, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2824 lang.IFn; if linked_2823 == nil { ifn_2824 = lang.IFn_Cast(root_2822) } else { ifn_2824 = nil }; var arg_2825 any = A_arbace_go_check_A_const_286.GetRawRoot__O(); var arg_2826 any; var root_2827 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2827, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2829 lang.IFn
						if linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any = jobs__1; var arg_2831 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000316_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__3060 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_A_fn_class
						if fncls__3060 == nil { var fncls__3060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000316_A_fn_class = fncls__3060d; tmp19 = fncls__3060d } else { tmp19 = fncls__3060 }; arg_2831 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :451:1
						var arg_2832 any; var root_3061 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_3062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3061, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3063 lang.IFn














						if linked_3062 == nil { ifn_3063 = lang.IFn_Cast(root_3061) } else { ifn_3063 = nil }; var arg_3064 any = A_arbace_go_check_A_const_289.GetRawRoot__O(); var arg_3065 any = tests__12; if linked_3062 == nil { arg_2832 = ifn_3063.Invoke_O_O__O(arg_3064, arg_3065) } else { arg_2832 = linked_3062.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3061, arg_3064, arg_3065) }
//line :451:1
						if linked_2828 == nil { arg_2826 = ifn_2829.Invoke_O_O_O__O(arg_2830, arg_2831, arg_2832) } else { arg_2826 = linked_2828.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2827, arg_2830, arg_2831, arg_2832) }
//line :450:1
						if linked_2823 == nil { arg_2821 = ifn_2824.Invoke_O_O__O(arg_2825, arg_2826) } else { arg_2821 = linked_2823.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2822, arg_2825, arg_2826) }; if linked_2819 == nil { return ifn_2820.Invoke_O__O(arg_2821) } else { return linked_2819.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2818, arg_2821) } } else {
//line :420:1
							return nil } } } }
//line :418:1
func A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A_New() *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A) Ctor() {}
//line :418:1
func (t *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A) Invoke_O_O__O(self, s__1685000293__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A_New_O_O(s__1685000293__1, self); var tmp2 *jrt.Class; var fncls__2686 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A_fn_class; if fncls__2686 == nil { var fncls__2686d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A_fn_class = fncls__2686d; tmp2 = fncls__2686d } else { tmp2 = fncls__2686 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :418:1
func A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A{}; t.Ctor_O_O(p0, p1); return t }
//line :418:1
func (t *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A) Ctor_O_O(c__s__1685000293, c__iter__1685000292 any) { t.F_s__1685000293 = c__s__1685000293; t.F_iter__1685000292 = c__iter__1685000292 }
//line :418:1
func (t *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A) Invoke_O__O(self any) any { { var s__1685000293__1 any; var t_ any = t.F_s__1685000293; t.F_s__1685000293 = nil; s__1685000293__1 = t_; for { var temp__1927000414__auto____2 any; var root_2621 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = s__1685000293__1; if linked_2622 == nil { temp__1927000414__auto____2 = ifn_2623.Invoke_O__O(arg_2624) } else { temp__1927000414__auto____2 = linked_2622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2621, arg_2624) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000293__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2625 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = s__1685000293__3; if linked_2626 == nil { tmp1 = ifn_2627.Invoke_O__O(arg_2628) } else { tmp1 = linked_2626.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2625, arg_2628) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2629 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = s__1685000293__3; if linked_2630 == nil { c__1927001037__auto____4 = ifn_2631.Invoke_O__O(arg_2632) } else { c__1927001037__auto____4 = linked_2630.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2629, arg_2632) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000295__6 any; var root_2633 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2634 == nil { b__1685000295__6 = ifn_2635.Invoke_O__O(arg_2636) } else { b__1685000295__6 = linked_2634.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2633, arg_2636) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A_New_I_O_O(size__1927001038__auto____5, b__1685000295__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2646 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A_fn_class; if fncls__2646 == nil { var fncls__2646d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A_fn_class = fncls__2646d; tmp3 = fncls__2646d } else { tmp3 = fncls__2646 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2647 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2647, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2649 lang.IFn; if linked_2648 == nil { ifn_2649 = lang.IFn_Cast(root_2647) } else { ifn_2649 = nil }; var arg_2650 any; var root_2652 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = b__1685000295__6; if linked_2653 == nil { arg_2650 = ifn_2654.Invoke_O__O(arg_2655) } else { arg_2650 = linked_2653.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2652, arg_2655) }; var arg_2651 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000292); var tmp5 any; var root_2656 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2656, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2658 lang.IFn; if linked_2657 == nil { ifn_2658 = lang.IFn_Cast(root_2656) } else { ifn_2658 = nil }; var arg_2659 any = s__1685000293__3; if linked_2657 == nil { tmp5 = ifn_2658.Invoke_O__O(arg_2659) } else { tmp5 = linked_2657.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2656, arg_2659) }; arg_2651 = tmp4.Invoke_O__O(tmp5); if linked_2648 == nil { return ifn_2649.Invoke_O_O__O(arg_2650, arg_2651) } else { return linked_2648.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2647, arg_2650, arg_2651) } } else { var root_2660 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any; var root_2665 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = b__1685000295__6; if linked_2666 == nil { arg_2663 = ifn_2667.Invoke_O__O(arg_2668) } else { arg_2663 = linked_2666.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2665, arg_2668) }; var arg_2664 any; if linked_2661 == nil { return ifn_2662.Invoke_O_O__O(arg_2663, arg_2664) } else { return linked_2661.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2660, arg_2663, arg_2664) } } } else { var pf__4 any; var root_2669 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2671 lang.IFn; if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any = s__1685000293__3; if linked_2670 == nil { pf__4 = ifn_2671.Invoke_O__O(arg_2672) } else { pf__4 = linked_2670.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2669, arg_2672) }; var root_2673 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2675 lang.IFn; if linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any; var root_2678 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2680 lang.IFn
															if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = pf__4; if linked_2679 == nil { arg_2676 = ifn_2680.Invoke_O__O(arg_2681) } else { arg_2676 = linked_2679.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2678, arg_2681) }
//line :418:1
	var arg_2677 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000292); var tmp7 any; var root_2682 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = s__1685000293__3; if linked_2683 == nil { tmp7 = ifn_2684.Invoke_O__O(arg_2685) } else { tmp7 = linked_2683.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2682, arg_2685) }; arg_2677 = tmp6.Invoke_O__O(tmp7); if linked_2674 == nil { return ifn_2675.Invoke_O_O__O(arg_2676, arg_2677) } else { return linked_2674.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2673, arg_2676, arg_2677) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :418:1
func A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :418:1
func (t *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1685000295, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000295 = c__b__1685000295; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :418:1
func (t *A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A) Invoke_O__O(self any) any { { var i__1685000294__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000294__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000294__1)); var root_2637 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = t.F_b__1685000295; var arg_2641 any; var root_2642 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2644 lang.IFn
																if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = pf__2; if linked_2643 == nil { arg_2641 = ifn_2644.Invoke_O__O(arg_2645) } else { arg_2641 = linked_2643.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2642, arg_2645) }
//line :418:1
	if linked_2638 == nil { ifn_2639.Invoke_O_O__O(arg_2640, arg_2641) } else { linked_2638.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2637, arg_2640, arg_2641) }; i__1685000294__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000294__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000302_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000302_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000302_A{}; t.Ctor_O(p0); return t }
//line :423:1
func (t *A_arbace_go_check_check_corpus_fn__1685000302_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :423:1
func (t *A_arbace_go_check_check_corpus_fn__1685000302_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_2699 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, A_arbace_go_check_result_of_A_fn_class); var ifn_2701 lang.IFn
												if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any; var root_2703 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = t.F_s; var arg_2707 any = path__1; var arg_2708 any; var arg_2709 any = lang.PersistentVector_EMPTY.Ref(); if linked_2704 == nil { arg_2702 = ifn_2705.Invoke_O_O_O_O__O(arg_2706, arg_2707, arg_2708, arg_2709) } else { arg_2702 = linked_2704.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2703, arg_2706, arg_2707, arg_2708, arg_2709) }; if linked_2700 == nil { or__1927000174__auto____4 = ifn_2701.Invoke_O__O(arg_2702) } else { or__1927000174__auto____4 = linked_2700.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2699, arg_2702) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104, path__1, A_arbace_go_check_A_const_279, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :423:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_2710 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2710, A_arbace_go_check_error_result_A_fn_class); var ifn_2712 lang.IFn


		if linked_2711 == nil { ifn_2712 = lang.IFn_Cast(root_2710) } else { ifn_2712 = nil }; var arg_2713 any = path__1; var arg_2714 any = ex__4; if linked_2711 == nil { tmp1 = ifn_2712.Invoke_O_O__O(arg_2713, arg_2714) } else { tmp1 = linked_2711.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2710, arg_2713, arg_2714) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000306_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000306_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000306_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :432:1
func (t *A_arbace_go_check_check_corpus_fn__1685000306_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :432:1
func (t *A_arbace_go_check_check_corpus_fn__1685000306_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_2738 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2740 lang.IFn

	if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any = t.F_root; var arg_2742 any; var arg_2743 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_cc); var arg_2744 any = pf__1; if linked_2739 == nil { src__4 = ifn_2740.Invoke_O_O_O_O__O(arg_2741, arg_2742, arg_2743, arg_2744) } else { src__4 = linked_2739.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2738, arg_2741, arg_2742, arg_2743, arg_2744) }
	var tmp2 any; var root_2745 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2745, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2747 lang.IFn; if linked_2746 == nil { ifn_2747 = lang.IFn_Cast(root_2745) } else { ifn_2747 = nil }; var arg_2748 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__4); if linked_2746 == nil { tmp2 = ifn_2747.Invoke_O__O(arg_2748) } else { tmp2 = linked_2746.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2745, arg_2748) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_104; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_279, jrt.Boolean_TRUE.Ref())) } else {

		var root_2749 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_2750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2749, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2751 lang.IFn; if linked_2750 == nil { ifn_2751 = lang.IFn_Cast(root_2749) } else { ifn_2751 = nil }; var arg_2752 any; var root_2755 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2755, A_arbace_go_check_result_of_A_fn_class); var ifn_2757 lang.IFn; if linked_2756 == nil { ifn_2757 = lang.IFn_Cast(root_2755) } else { ifn_2757 = nil }; var arg_2758 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_241.GetRawRoot__O()); var tmp5 any; var root_2764 any = A_arbace_go_check_A_const_242.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, A_arbace_go_check_resolver_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = t.F_s; var arg_2768 any = src__4; var arg_2769 any = lang.PersistentVector_EMPTY.Ref(); if linked_2765 == nil { tmp5 = ifn_2766.Invoke_O_O_O__O(arg_2767, arg_2768, arg_2769) } else { tmp5 = linked_2765.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2764, arg_2767, arg_2768, arg_2769) }; arg_2758 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_2756 == nil { arg_2752 = ifn_2757.Invoke_O__O(arg_2758) } else { arg_2752 = linked_2756.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2755, arg_2758) }; var arg_2753 any = A_arbace_go_check_A_const_104; var arg_2754 any; var root_2770 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2772 lang.IFn
		if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2774 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_2771 == nil { arg_2754 = ifn_2772.Invoke_O_O__O(arg_2773, arg_2774) } else { arg_2754 = linked_2771.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2770, arg_2773, arg_2774) }
//line :437:1
		if linked_2750 == nil { tmp1 = ifn_2751.Invoke_O_O_O__O(arg_2752, arg_2753, arg_2754) } else { tmp1 = linked_2750.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2749, arg_2752, arg_2753, arg_2754) } } }; return nil }(); if /*line :432:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_2775 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2775, A_arbace_go_check_error_result_A_fn_class); var ifn_2777 lang.IFn






			if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2779 any = ex__4; if linked_2776 == nil { tmp1 = ifn_2777.Invoke_O_O__O(arg_2778, arg_2779) } else { tmp1 = linked_2776.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2775, arg_2778, arg_2779) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000310_A_New() *A_arbace_go_check_check_corpus_fn__1685000310_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_A) Ctor() {}
//line :446:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_2812 any = A_arbace_go_check_A_const_284.GetRawRoot__O(); var linked_2813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2812, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2814 lang.IFn; if

	linked_2813 == nil { ifn_2814 = lang.IFn_Cast(root_2812) } else { ifn_2814 = nil }; var arg_2815 any = A_arbace_go_check_A_const_285; var arg_2816 any = p__2; if linked_2813 == nil { temp__1927000408__auto____3 = ifn_2814.Invoke_O_O__O(arg_2815, arg_2816) } else { temp__1927000408__auto____3 = linked_2813.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2812, arg_2815, arg_2816) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000311__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000311__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000311__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000316_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000316_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :452:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :452:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_A) Invoke_O_O__O(self, p__1685000315__1 any) any { var vec__1685000317__2 any = p__1685000315__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000317__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000317__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_2833 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2835 lang.IFn

	if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var arg_2836 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2837 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A_New(); var tmp3 *jrt.Class; var fncls__2904 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A_fn_class; if fncls__2904 == nil { var fncls__2904d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A_fn_class = fncls__2904d; tmp3 = fncls__2904d } else { tmp3 = fncls__2904 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_2837 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_2834 == nil { by_path__7 = ifn_2835.Invoke_O_O__O(arg_2836, arg_2837) } else { by_path__7 = linked_2834.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2833, arg_2836, arg_2837) }
//line :452:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_189.GetRawRoot__O()); var tmp5 any; var root_2913 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2913, A_arbace_go_check_session_A_fn_class); var ifn_2915 lang.IFn



	if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__2924 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A_fn_class; if fncls__2924 == nil { var fncls__2924d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A_fn_class = fncls__2924d; tmp7 = fncls__2924d } else { tmp7 = fncls__2924 }; arg_2916 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2914 == nil { tmp5 = ifn_2915.Invoke_O__O(arg_2916) } else { tmp5 = linked_2914.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2913, arg_2916) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_231; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_239; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__2930 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A_fn_class; if fncls__2930 == nil { var fncls__2930d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A_fn_class = fncls__2930d; tmp13 = fncls__2930d } else { tmp13 = fncls__2930 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_2931 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2931, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2933 lang.IFn; if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__3049 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A_fn_class; if fncls__3049 == nil { var fncls__3049d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A_fn_class = fncls__3049d; tmp15 = fncls__3049d } else { tmp15 = fncls__3049 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_3050 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3052 lang.IFn; if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = A_arbace_go_check_A_const_289.GetRawRoot__O(); var arg_3054 any = by_path__7; if linked_3051 == nil { tmp17 = ifn_3052.Invoke_O_O__O(arg_3053, arg_3054) } else { tmp17 = linked_3051.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3050, arg_3053, arg_3054) }; arg_2934 = tmp16.Invoke_O__O(tmp17); if linked_2932 == nil { tmp1 = ifn_2933.Invoke_O__O(arg_2934) } else { tmp1 = linked_2932.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2931, arg_2934) } }; return nil }(); if /*line :452:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_3055 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, A_arbace_go_check_error_result_A_fn_class); var ifn_3057 lang.IFn












		if linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any = tdir__3; var arg_3059 any = ex__7; if linked_3056 == nil { tmp19 = ifn_3057.Invoke_O_O__O(arg_3058, arg_3059) } else { tmp19 = linked_3056.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3055, arg_3058, arg_3059) }
//line :452:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A_New() *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A) Ctor() {}
//line :454:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A) Invoke_O_O__O(self, s__1685000321__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A_New_O_O(s__1685000321__1, self); var tmp2 *jrt.Class; var fncls__2903 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A_fn_class; if fncls__2903 == nil { var fncls__2903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A_fn_class = fncls__2903d; tmp2 = fncls__2903d } else { tmp2 = fncls__2903 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :454:1
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A{}; t.Ctor_O_O(p0, p1); return t }
//line :454:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A) Ctor_O_O(c__s__1685000321, c__iter__1685000320 any) { t.F_s__1685000321 = c__s__1685000321; t.F_iter__1685000320 = c__iter__1685000320 }
//line :454:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A) Invoke_O__O(self any) any { { var s__1685000321__1 any; var t_ any = t.F_s__1685000321; t.F_s__1685000321 = nil; s__1685000321__1 = t_; for { var temp__1927000414__auto____2 any; var root_2838 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2840 lang.IFn; if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any = s__1685000321__1; if linked_2839 == nil { temp__1927000414__auto____2 = ifn_2840.Invoke_O__O(arg_2841) } else { temp__1927000414__auto____2 = linked_2839.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2838, arg_2841) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000321__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2842 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2842, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2844 lang.IFn; if linked_2843 == nil { ifn_2844 = lang.IFn_Cast(root_2842) } else { ifn_2844 = nil }; var arg_2845 any = s__1685000321__3; if linked_2843 == nil { tmp1 = ifn_2844.Invoke_O__O(arg_2845) } else { tmp1 = linked_2843.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2842, arg_2845) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2846 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2848 lang.IFn; if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; var arg_2849 any = s__1685000321__3; if linked_2847 == nil { c__1927001037__auto____4 = ifn_2848.Invoke_O__O(arg_2849) } else { c__1927001037__auto____4 = linked_2847.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2846, arg_2849) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000323__6 any; var root_2850 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2850, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2852 lang.IFn; if linked_2851 == nil { ifn_2852 = lang.IFn_Cast(root_2850) } else { ifn_2852 = nil }; var arg_2853 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2851 == nil { b__1685000323__6 = ifn_2852.Invoke_O__O(arg_2853) } else { b__1685000323__6 = linked_2851.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2850, arg_2853) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A_New_O_I_O(b__1685000323__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2863 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A_fn_class; if fncls__2863 == nil { var fncls__2863d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A_fn_class = fncls__2863d; tmp3 = fncls__2863d } else { tmp3 = fncls__2863 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2864 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2864, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2866 lang.IFn; if linked_2865 == nil { ifn_2866 = lang.IFn_Cast(root_2864) } else { ifn_2866 = nil }; var arg_2867 any; var root_2869 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2871 lang.IFn; if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any = b__1685000323__6; if linked_2870 == nil { arg_2867 = ifn_2871.Invoke_O__O(arg_2872) } else { arg_2867 = linked_2870.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2869, arg_2872) }; var arg_2868 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000320); var tmp5 any; var root_2873 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2873, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2875 lang.IFn; if linked_2874 == nil { ifn_2875 = lang.IFn_Cast(root_2873) } else { ifn_2875 = nil }; var arg_2876 any = s__1685000321__3; if linked_2874 == nil { tmp5 = ifn_2875.Invoke_O__O(arg_2876) } else { tmp5 = linked_2874.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2873, arg_2876) }; arg_2868 = tmp4.Invoke_O__O(tmp5); if linked_2865 == nil { return ifn_2866.Invoke_O_O__O(arg_2867, arg_2868) } else { return linked_2865.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2864, arg_2867, arg_2868) } } else { var root_2877 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2877, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2879 lang.IFn; if linked_2878 == nil { ifn_2879 = lang.IFn_Cast(root_2877) } else { ifn_2879 = nil }; var arg_2880 any; var root_2882 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2882, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2884 lang.IFn; if linked_2883 == nil { ifn_2884 = lang.IFn_Cast(root_2882) } else { ifn_2884 = nil }; var arg_2885 any = b__1685000323__6; if linked_2883 == nil { arg_2880 = ifn_2884.Invoke_O__O(arg_2885) } else { arg_2880 = linked_2883.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2882, arg_2885) }; var arg_2881 any; if linked_2878 == nil { return ifn_2879.Invoke_O_O__O(arg_2880, arg_2881) } else { return linked_2878.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2877, arg_2880, arg_2881) } } } else { var pf__4 any; var root_2886 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any = s__1685000321__3; if linked_2887 == nil { pf__4 = ifn_2888.Invoke_O__O(arg_2889) } else { pf__4 = linked_2887.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2886, arg_2889) }; var root_2890 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2890, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2892 lang.IFn; if linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var arg_2893 any; var tmp6 any; var root_2895 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = pf__4; if linked_2896 == nil { tmp6 = ifn_2897.Invoke_O__O(arg_2898) } else { tmp6 = linked_2896.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2895, arg_2898) }; arg_2893 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_2894 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000320); var tmp8 any; var root_2899 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2901 lang.IFn; if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = s__1685000321__3; if linked_2900 == nil { tmp8 = ifn_2901.Invoke_O__O(arg_2902) } else { tmp8 = linked_2900.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2899, arg_2902) }; arg_2894 = tmp7.Invoke_O__O(tmp8); if linked_2891 == nil { return ifn_2892.Invoke_O_O__O(arg_2893, arg_2894) } else { return linked_2891.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2890, arg_2893, arg_2894) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :454:1
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :454:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A) Ctor_O_I_O(c__b__1685000323 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000323 = c__b__1685000323; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :454:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A) Invoke_O__O(self any) any { { var i__1685000322__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000322__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000322__1)); var root_2854 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2856 lang.IFn; if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any = t.F_b__1685000323; var arg_2858 any; var tmp2 any; var root_2859 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2861 lang.IFn; if linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any = pf__2; if linked_2860 == nil { tmp2 = ifn_2861.Invoke_O__O(arg_2862) } else { tmp2 = linked_2860.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2859, arg_2862) }; arg_2858 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_2855 == nil { ifn_2856.Invoke_O_O__O(arg_2857, arg_2858) } else { linked_2855.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2854, arg_2857, arg_2858) }; i__1685000322__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000322__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :456:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :456:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_2917 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2917, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2919 lang.IFn
																	if linked_2918 == nil { ifn_2919 = lang.IFn_Cast(root_2917) } else { ifn_2919 = nil }; var arg_2920 any = t.F_root; var arg_2921 any = path__1; var arg_2922 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_cc); var arg_2923 any = pf__4; if linked_2918 == nil { return ifn_2919.Invoke_O_O_O_O__O(arg_2920, arg_2921, arg_2922, arg_2923) } else { return linked_2918.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2917, arg_2920, arg_2921, arg_2922, arg_2923) } } else {
//line :457:1
			return nil } }
//line :456:1
func A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A{}; t.Ctor_O(p0); return t }
//line :456:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :456:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A) Invoke_O_O__O(self, p1__1685000291_SHARP___1 any) any {


	var root_2925 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = t.F_by_path; var arg_2929 any = p1__1685000291_SHARP___1; if linked_2926 == nil { return ifn_2927.Invoke_O_O__O(arg_2928, arg_2929) } else { return linked_2926.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2925, arg_2928, arg_2929) } }
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :460:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :460:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A) Invoke_O_O__O(self, s__1685000335__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A_New_O_O_O_O_O(t.F_dir, t.F_tdir, t.F_ts, s__1685000335__1, self); var tmp2 *jrt.Class; var fncls__3048 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A_fn_class; if fncls__3048 == nil { var fncls__3048d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A_fn_class = fncls__3048d; tmp2 = fncls__3048d } else { tmp2 = fncls__3048 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :460:1
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :460:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A) Ctor_O_O_O_O_O(c__dir, c__tdir, c__ts, c__s__1685000335, c__iter__1685000334 any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1685000335 = c__s__1685000335; t.F_iter__1685000334 = c__iter__1685000334 }
//line :460:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A) Invoke_O__O(self any) any { { var s__1685000335__1 any; var t_ any = t.F_s__1685000335; t.F_s__1685000335 = nil; s__1685000335__1 = t_; for { var temp__1927000414__auto____2 any; var root_2935 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2935, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2937 lang.IFn; if linked_2936 == nil { ifn_2937 = lang.IFn_Cast(root_2935) } else { ifn_2937 = nil }; var arg_2938 any = s__1685000335__1; if linked_2936 == nil { temp__1927000414__auto____2 = ifn_2937.Invoke_O__O(arg_2938) } else { temp__1927000414__auto____2 = linked_2936.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2935, arg_2938) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000335__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2939 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = s__1685000335__3; if linked_2940 == nil { tmp1 = ifn_2941.Invoke_O__O(arg_2942) } else { tmp1 = linked_2940.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2939, arg_2942) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2943 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = s__1685000335__3; if linked_2944 == nil { c__1927001037__auto____4 = ifn_2945.Invoke_O__O(arg_2946) } else { c__1927001037__auto____4 = linked_2944.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2943, arg_2946) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000337__6 any; var root_2947 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2948 == nil { b__1685000337__6 = ifn_2949.Invoke_O__O(arg_2950) } else { b__1685000337__6 = linked_2948.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2947, arg_2950) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_New_O_O_O_O_I_O(t.F_dir, b__1685000337__6, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2984 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_fn_class; if fncls__2984 == nil { var fncls__2984d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_fn_class = fncls__2984d; tmp3 = fncls__2984d } else { tmp3 = fncls__2984 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2985 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2985, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2987 lang.IFn; if linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 any; var root_2990 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2990, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2992 lang.IFn; if linked_2991 == nil { ifn_2992 = lang.IFn_Cast(root_2990) } else { ifn_2992 = nil }; var arg_2993 any = b__1685000337__6; if linked_2991 == nil { arg_2988 = ifn_2992.Invoke_O__O(arg_2993) } else { arg_2988 = linked_2991.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2990, arg_2993) }; var arg_2989 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000334); var tmp5 any; var root_2994 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2994, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2996 lang.IFn; if linked_2995 == nil { ifn_2996 = lang.IFn_Cast(root_2994) } else { ifn_2996 = nil }; var arg_2997 any = s__1685000335__3; if linked_2995 == nil { tmp5 = ifn_2996.Invoke_O__O(arg_2997) } else { tmp5 = linked_2995.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2994, arg_2997) }; arg_2989 = tmp4.Invoke_O__O(tmp5); if linked_2986 == nil { return ifn_2987.Invoke_O_O__O(arg_2988, arg_2989) } else { return linked_2986.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2985, arg_2988, arg_2989) } } else { var root_2998 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2998, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3000 lang.IFn; if linked_2999 == nil { ifn_3000 = lang.IFn_Cast(root_2998) } else { ifn_3000 = nil }; var arg_3001 any; var root_3003 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = b__1685000337__6; if linked_3004 == nil { arg_3001 = ifn_3005.Invoke_O__O(arg_3006) } else { arg_3001 = linked_3004.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3003, arg_3006) }; var arg_3002 any; if linked_2999 == nil { return ifn_3000.Invoke_O_O__O(arg_3001, arg_3002) } else { return linked_2999.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2998, arg_3001, arg_3002) } } } else { var vec__1685000347__4 any; var root_3007 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3007, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3009 lang.IFn; if linked_3008 == nil { ifn_3009 = lang.IFn_Cast(root_3007) } else { ifn_3009 = nil }; var arg_3010 any = s__1685000335__3; if linked_3008 == nil { vec__1685000347__4 = ifn_3009.Invoke_O__O(arg_3010) } else { vec__1685000347__4 = linked_3008.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3007, arg_3010) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000347__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000347__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3011 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3011, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3013 lang.IFn; _ = pf__6; if linked_3012 == nil { ifn_3013 = lang.IFn_Cast(root_3011) } else { ifn_3013 = nil }; var arg_3014 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3043 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A_fn_class
																if fncls__3043 == nil { var fncls__3043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A_fn_class = fncls__3043d; tmp7 = fncls__3043d } else { tmp7 = fncls__3043 }; arg_3014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :460:1
	var arg_3015 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000334); var tmp9 any; var root_3044 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = s__1685000335__3; if linked_3045 == nil { tmp9 = ifn_3046.Invoke_O__O(arg_3047) } else { tmp9 = linked_3045.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3044, arg_3047) }; arg_3015 = tmp8.Invoke_O__O(tmp9); if linked_3012 == nil { return ifn_3013.Invoke_O_O__O(arg_3014, arg_3015) } else { return linked_3012.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3011, arg_3014, arg_3015) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :460:1
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :460:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A) Ctor_O_O_O_O_I_O(c__dir, c__b__1685000337, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__1685000337 = c__b__1685000337; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :460:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A) Invoke_O__O(self any) any { { var i__1685000336__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000336__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000341__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000336__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000341__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000341__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2951 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2951, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2953 lang.IFn; _ = pf__4; if linked_2952 == nil { ifn_2953 = lang.IFn_Cast(root_2951) } else { ifn_2953 = nil }; var arg_2954 any = t.F_b__1685000337; var arg_2955 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__2983 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A_fn_class
																		if fncls__2983 == nil { var fncls__2983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A_fn_class = fncls__2983d; tmp3 = fncls__2983d } else { tmp3 = fncls__2983 }; arg_2955 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :460:1
	if linked_2952 == nil { ifn_2953.Invoke_O_O__O(arg_2954, arg_2955) } else { linked_2952.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2951, arg_2954, arg_2955) }; i__1685000336__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000336__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_2956 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_2957 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2956, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2958 lang.IFn; if linked_2957 == nil { ifn_2958 = lang.IFn_Cast(root_2956) } else { ifn_2958 = nil }; var arg_2959 any; var or__1927000174__auto____3 any; var root_2962 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2962, A_arbace_go_check_result_of_A_fn_class); var ifn_2964 lang.IFn; if linked_2963 == nil { ifn_2964 = lang.IFn_Cast(root_2962) } else { ifn_2964 = nil }; var arg_2965 any; var root_2966 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2968 lang.IFn; if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any; var t_ any = t.F_ts; t.F_ts = nil; arg_2969 = t_; var arg_2970 any = t.F_path; var arg_2971 any; var arg_2972 any = lang.PersistentVector_EMPTY.Ref(); if linked_2967 == nil { arg_2965 = ifn_2968.Invoke_O_O_O_O__O(arg_2969, arg_2970, arg_2971, arg_2972) } else { arg_2965 = linked_2967.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2966, arg_2969, arg_2970, arg_2971, arg_2972) }; if linked_2963 == nil { or__1927000174__auto____3 = ifn_2964.Invoke_O__O(arg_2965) } else { or__1927000174__auto____3 = linked_2963.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2962, arg_2965) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_2959 = or__1927000174__auto____3 } else { arg_2959 = A_arbace_go_check_A_const_287 }; var arg_2960 any = A_arbace_go_check_A_const_104; var arg_2961 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp3 any; var root_2973 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_2974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2973, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2975 lang.IFn
																					if linked_2974 == nil { ifn_2975 = lang.IFn_Cast(root_2973) } else { ifn_2975 = nil }; var arg_2976 any = t.F_tdir; var arg_2977 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_2977 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_2974 == nil { tmp3 = ifn_2975.Invoke_O_O__O(arg_2976, arg_2977) } else { tmp3 = linked_2974.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2973, arg_2976, arg_2977) }; arg_2961 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :462:1
		if linked_2957 == nil { tmp1 = ifn_2958.Invoke_O_O_O__O(arg_2959, arg_2960, arg_2961) } else { tmp1 = linked_2957.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2956, arg_2959, arg_2960, arg_2961) } }
//line :461:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_2978 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2978, A_arbace_go_check_error_result_A_fn_class); var ifn_2980 lang.IFn


		if linked_2979 == nil { ifn_2980 = lang.IFn_Cast(root_2978) } else { ifn_2980 = nil }; var arg_2981 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_2981 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_2982 any = ex__3; if linked_2979 == nil { tmp1 = ifn_2980.Invoke_O_O__O(arg_2981, arg_2982) } else { tmp1 = linked_2979.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2978, arg_2981, arg_2982) } } }; return tmp1 }
//line :461:1
func A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3016 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any; var or__1927000174__auto____3 any; var root_3022 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_3023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3022, A_arbace_go_check_result_of_A_fn_class); var ifn_3024 lang.IFn; if linked_3023 == nil { ifn_3024 = lang.IFn_Cast(root_3022) } else { ifn_3024 = nil }; var arg_3025 any; var root_3026 any = A_arbace_go_check_A_const_235.GetRawRoot__O(); var linked_3027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3026, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3028 lang.IFn; if linked_3027 == nil { ifn_3028 = lang.IFn_Cast(root_3026) } else { ifn_3028 = nil }; var arg_3029 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3029 = t_; var arg_3030 any = t.F_path; var arg_3031 any; var arg_3032 any = lang.PersistentVector_EMPTY.Ref(); if linked_3027 == nil { arg_3025 = ifn_3028.Invoke_O_O_O_O__O(arg_3029, arg_3030, arg_3031, arg_3032) } else { arg_3025 = linked_3027.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3026, arg_3029, arg_3030, arg_3031, arg_3032) }; if linked_3023 == nil { or__1927000174__auto____3 = ifn_3024.Invoke_O__O(arg_3025) } else { or__1927000174__auto____3 = linked_3023.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3022, arg_3025) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3019 = or__1927000174__auto____3 } else { arg_3019 = A_arbace_go_check_A_const_288 }; var arg_3020 any = A_arbace_go_check_A_const_104; var arg_3021 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp3 any; var root_3033 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3035 lang.IFn
																			if linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any = t.F_tdir; var arg_3037 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3037 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3034 == nil { tmp3 = ifn_3035.Invoke_O_O__O(arg_3036, arg_3037) } else { tmp3 = linked_3034.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3033, arg_3036, arg_3037) }; arg_3021 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :462:1
		if linked_3017 == nil { tmp1 = ifn_3018.Invoke_O_O_O__O(arg_3019, arg_3020, arg_3021) } else { tmp1 = linked_3017.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3016, arg_3019, arg_3020, arg_3021) } }
//line :461:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3038 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3038, A_arbace_go_check_error_result_A_fn_class); var ifn_3040 lang.IFn


		if linked_3039 == nil { ifn_3040 = lang.IFn_Cast(root_3038) } else { ifn_3040 = nil }; var arg_3041 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3041 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3042 any = ex__3; if linked_3039 == nil { tmp1 = ifn_3040.Invoke_O_O__O(arg_3041, arg_3042) } else { tmp1 = linked_3039.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3038, arg_3041, arg_3042) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :468:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3066 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_3067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3066, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3068 lang.IFn; if


	linked_3067 == nil { ifn_3068 = lang.IFn_Cast(root_3066) } else { ifn_3068 = nil }; var arg_3069 any = A_arbace_go_check_A_const_279; var arg_3070 any = results__1; if linked_3067 == nil { rs__3 = ifn_3068.Invoke_O_O__O(arg_3069, arg_3070) } else { rs__3 = linked_3067.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3066, arg_3069, arg_3070) }; var sum__4 any; var tmp1 any = /*line :468:1*/A_arbace_go_check_summarize_sum__1685000362_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3082 *jrt.Class = A_arbace_go_check_summarize_sum__1685000362_A_fn_class; if



	fncls__3082 == nil { var fncls__3082d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_summarize_sum__1685000362_A_fn_class = fncls__3082d; tmp2 = fncls__3082d } else { tmp2 = fncls__3082 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :468:1*/A_arbace_go_check_summarize_msum__1685000364_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__3095 *jrt.Class = A_arbace_go_check_summarize_msum__1685000364_A_fn_class; if




	fncls__3095 == nil { var fncls__3095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_summarize_msum__1685000364_A_fn_class = fncls__3095d; tmp4 = fncls__3095d } else { tmp4 = fncls__3095 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_259; var tmp6 any = A_arbace_go_check_A_const_290; var tmp7 any = /*line :468:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_291; var tmp9 any = A_arbace_go_check_A_const_292; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_82); var tmp11 any = A_arbace_go_check_A_const_151; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_151); var tmp13 any = A_arbace_go_check_A_const_137; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_142); var tmp15 any = A_arbace_go_check_A_const_140; var tmp16 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_140); var tmp17 any = A_arbace_go_check_A_const_132; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_143))); var tmp19 any = A_arbace_go_check_A_const_207; var tmp20 lang.IFn = lang.IFn_Cast(sum__4); var tmp21 any = A_arbace_go_check_summarize_fn__1685000366_A_New(); var tmp22 *jrt.Class; var fncls__3178 *jrt.Class = A_arbace_go_check_summarize_fn__1685000366_A_fn_class; if












	fncls__3178 == nil { var fncls__3178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_summarize_fn__1685000366_A_fn_class = fncls__3178d; tmp22 = fncls__3178d } else { tmp22 = fncls__3178 }; var tmp23 any = /*line :468:1*/tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)); var tmp24 any = A_arbace_go_check_A_const_293; var tmp25 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_211); var tmp26 any = A_arbace_go_check_A_const_294; var tmp27 any; var root_3096 any = A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_3097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3096, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3098 lang.IFn; if














	linked_3097 == nil { ifn_3098 = lang.IFn_Cast(root_3096) } else { ifn_3098 = nil }; var arg_3099 any; var tmp28 any = A_arbace_go_check_summarize_fn__1685000368_A_New(); var tmp29 *jrt.Class; var fncls__3101 *jrt.Class = A_arbace_go_check_summarize_fn__1685000368_A_fn_class; if fncls__3101 == nil { var fncls__3101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_go_check_summarize_fn__1685000368_A_fn_class = fncls__3101d; tmp29 = fncls__3101d } else { tmp29 = fncls__3101 }; arg_3099 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_3100 any = rs__3; if linked_3097 == nil { tmp27 = ifn_3098.Invoke_O_O__O(arg_3099, arg_3100) } else { tmp27 = linked_3097.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3096, arg_3099, arg_3100) }; var tmp30 any = /*line :468:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref(); var tmp31 any = A_arbace_go_check_A_const_296; var tmp32 any; var root_3102 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_3103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3102, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3104 lang.IFn; if















	linked_3103 == nil { ifn_3104 = lang.IFn_Cast(root_3102) } else { ifn_3104 = nil }; var arg_3105 any; var root_3106 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any; var tmp33 any = A_arbace_go_check_summarize_fn__1685000370_A_New(); var tmp34 *jrt.Class; var fncls__3111 *jrt.Class = A_arbace_go_check_summarize_fn__1685000370_A_fn_class; if fncls__3111 == nil { var fncls__3111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_go_check_summarize_fn__1685000370_A_fn_class = fncls__3111d; tmp34 = fncls__3111d } else { tmp34 = fncls__3111 }; arg_3109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3110 any = rs__3; if linked_3107 == nil { arg_3105 = ifn_3108.Invoke_O_O__O(arg_3109, arg_3110) } else { arg_3105 = linked_3107.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3106, arg_3109, arg_3110) }; if linked_3103 == nil { tmp32 = ifn_3104.Invoke_O__O(arg_3105) } else { tmp32 = linked_3103.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3102, arg_3105) }; var tmp35 any = tmp32; var tmp36 any = A_arbace_go_check_A_const_297; var tmp37 any = A_arbace_go_check_A_const_127; var tmp38 any; var root_3112 any = /*line :468:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3112, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3114 lang.IFn; if
















	linked_3113 == nil { ifn_3114 = lang.IFn_Cast(root_3112) } else { ifn_3114 = nil }; var arg_3115 any = lang.IFn_Cast(A_arbace_go_check_A_const_298.GetRawRoot__O()).Invoke__O(); var arg_3116 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_127); if linked_3113 == nil { tmp38 = ifn_3114.Invoke_O_O__O(arg_3115, arg_3116) } else { tmp38 = linked_3113.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3112, arg_3115, arg_3116) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_go_check_A_const_152; var tmp41 any; var root_3120 any = /*line :468:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3120, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3122 lang.IFn; if

















	linked_3121 == nil { ifn_3122 = lang.IFn_Cast(root_3120) } else { ifn_3122 = nil }; var arg_3123 any = lang.IFn_Cast(A_arbace_go_check_A_const_298.GetRawRoot__O()).Invoke__O(); var arg_3124 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_152); if linked_3121 == nil { tmp41 = ifn_3122.Invoke_O_O__O(arg_3123, arg_3124) } else { tmp41 = linked_3121.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3120, arg_3123, arg_3124) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_go_check_A_const_153; var tmp44 any; var root_3128 any = /*line :468:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3128, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3130 lang.IFn; if


















	linked_3129 == nil { ifn_3130 = lang.IFn_Cast(root_3128) } else { ifn_3130 = nil }; var arg_3131 any = lang.IFn_Cast(A_arbace_go_check_A_const_298.GetRawRoot__O()).Invoke__O(); var arg_3132 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_153); if linked_3129 == nil { tmp44 = ifn_3130.Invoke_O_O__O(arg_3131, arg_3132) } else { tmp44 = linked_3129.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3128, arg_3131, arg_3132) }; var tmp45 any = tmp44; var tmp46 any = A_arbace_go_check_A_const_299; var tmp47 any; var root_3136 any = /*line :468:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3138 lang.IFn; if



















	linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = lang.IFn_Cast(A_arbace_go_check_A_const_298.GetRawRoot__O()).Invoke__O(); var arg_3140 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_144); if linked_3137 == nil { tmp47 = ifn_3138.Invoke_O_O__O(arg_3139, arg_3140) } else { tmp47 = linked_3137.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3136, arg_3139, arg_3140) }; var tmp48 any = tmp47; var tmp49 any = A_arbace_go_check_A_const_212; var tmp50 any = A_arbace_go_check_A_const_290; var tmp51 any; var root_3144 any = /*line :468:1*/A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_3145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3144, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3146 lang.IFn; if




















	linked_3145 == nil { ifn_3146 = lang.IFn_Cast(root_3144) } else { ifn_3146 = nil }; var arg_3147 any; var tmp52 any = A_arbace_go_check_summarize_fn__1685000372_A_New(); var tmp53 *jrt.Class; var fncls__3154 *jrt.Class = A_arbace_go_check_summarize_fn__1685000372_A_fn_class; if fncls__3154 == nil { var fncls__3154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_check_summarize_fn__1685000372_A_fn_class = fncls__3154d; tmp53 = fncls__3154d } else { tmp53 = fncls__3154 }; arg_3147 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var arg_3148 any = rs__3; if linked_3145 == nil { tmp51 = ifn_3146.Invoke_O_O__O(arg_3147, arg_3148) } else { tmp51 = linked_3145.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3144, arg_3147, arg_3148) }; var tmp54 any = /*line :468:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp51)).Ref(); var tmp55 any = A_arbace_go_check_A_const_301; var tmp56 lang.IFn = lang.IFn_Cast(sum__4); var tmp57 any = A_arbace_go_check_summarize_fn__1685000374_A_New(); var tmp58 *jrt.Class; var fncls__3185 *jrt.Class = A_arbace_go_check_summarize_fn__1685000374_A_fn_class; if





















	fncls__3185 == nil { var fncls__3185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_summarize_fn__1685000374_A_fn_class = fncls__3185d; tmp58 = fncls__3185d } else { tmp58 = fncls__3185 }; var tmp59 any = /*line :468:1*/tmp56.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil)); var tmp60 any = A_arbace_go_check_A_const_302; var tmp61 any; var root_3155 any = A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_3156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3155, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3157 lang.IFn; if






















	linked_3156 == nil { ifn_3157 = lang.IFn_Cast(root_3155) } else { ifn_3157 = nil }; var arg_3158 any; var tmp62 any = A_arbace_go_check_summarize_fn__1685000376_A_New(); var tmp63 *jrt.Class; var fncls__3169 *jrt.Class = A_arbace_go_check_summarize_fn__1685000376_A_fn_class; if fncls__3169 == nil { var fncls__3169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_summarize_fn__1685000376_A_fn_class = fncls__3169d; tmp63 = fncls__3169d } else { tmp63 = fncls__3169 }; arg_3158 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil); var arg_3159 any = rs__3; if linked_3156 == nil { tmp61 = ifn_3157.Invoke_O_O__O(arg_3158, arg_3159) } else { tmp61 = linked_3156.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3155, arg_3158, arg_3159) }; var tmp64 any = /*line :468:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, tmp40, tmp42, tmp43, tmp45, tmp46, tmp48, tmp49, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp54, tmp55, tmp59, tmp60, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp61)).Ref())))); var tmp65 any = A_arbace_go_check_A_const_132; var tmp66 any; var root_3170 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3170, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3172 lang.IFn; if























	linked_3171 == nil { ifn_3172 = lang.IFn_Cast(root_3170) } else { ifn_3172 = nil }; var arg_3173 any = lang.IFn_Cast(A_arbace_go_check_A_const_298.GetRawRoot__O()).Invoke__O(); var arg_3174 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_132); if linked_3171 == nil { tmp66 = ifn_3172.Invoke_O_O__O(arg_3173, arg_3174) } else { tmp66 = linked_3171.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3170, arg_3173, arg_3174) }; return /*line :468:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp18, tmp19, tmp23, tmp24, tmp25, tmp26, tmp30, tmp31, tmp35, tmp36, tmp64, tmp65, tmp66)) }



func A_arbace_go_check_summarize_sum__1685000362_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000362_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000362_A{}; t.Ctor_O(p0); return t }
//line :472:1
func (t *A_arbace_go_check_summarize_sum__1685000362_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :472:1
func (t *A_arbace_go_check_summarize_sum__1685000362_A) Invoke_O_O__O(self, k__1 any) any { var root_3071 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3073 lang.IFn; if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3075 any = A_arbace_go_check_A_const_22; var arg_3076 any; var root_3077 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3079 lang.IFn; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = k__1; var arg_3081 any = t.F_rs; if linked_3078 == nil { arg_3076 = ifn_3079.Invoke_O_O__O(arg_3080, arg_3081) } else { arg_3076 = linked_3078.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3077, arg_3080, arg_3081) }; if linked_3072 == nil { return ifn_3073.Invoke_O_O_O__O(arg_3074, arg_3075, arg_3076) } else { return linked_3072.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3071, arg_3074, arg_3075, arg_3076) } }
func A_arbace_go_check_summarize_msum__1685000364_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000364_A{}; t.Ctor_O(p0); return t }
//line :473:1
func (t *A_arbace_go_check_summarize_msum__1685000364_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :473:1
func (t *A_arbace_go_check_summarize_msum__1685000364_A) Invoke_O_O__O(self, k__1 any) any { var root_3083 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_3084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3083, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3085 lang.IFn; if linked_3084 == nil { ifn_3085 = lang.IFn_Cast(root_3083) } else { ifn_3085 = nil }; var arg_3086 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var arg_3087 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3088 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3089 any; var root_3090 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_3091 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3090, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3092 lang.IFn; if linked_3091 == nil { ifn_3092 = lang.IFn_Cast(root_3090) } else { ifn_3092 = nil }; var arg_3093 any = k__1; var arg_3094 any = t.F_rs; if linked_3091 == nil { arg_3089 = ifn_3092.Invoke_O_O__O(arg_3093, arg_3094) } else { arg_3089 = linked_3091.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3090, arg_3093, arg_3094) }; if linked_3084 == nil { return ifn_3085.Invoke_O_O_O_O__O(arg_3086, arg_3087, arg_3088, arg_3089) } else { return linked_3084.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3083, arg_3086, arg_3087, arg_3088, arg_3089) } }







func A_arbace_go_check_summarize_fn__1685000366_A_New() *A_arbace_go_check_summarize_fn__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000366_A{}; t.Ctor(); return t }
//line :481:1
func (t *A_arbace_go_check_summarize_fn__1685000366_A) Ctor() {}
//line :481:1
func (t *A_arbace_go_check_summarize_fn__1685000366_A) Invoke_O_O__O(self, p1__1685000356_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_207.Invoke_O__O(p1__1685000356_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000368_A_New() *A_arbace_go_check_summarize_fn__1685000368_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000368_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_go_check_summarize_fn__1685000368_A) Ctor() {}
//line :483:1
func (t *A_arbace_go_check_summarize_fn__1685000368_A) Invoke_O_O__O(self, p1__1685000357_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_269.Invoke_O__O(p1__1685000357_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000357_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000370_A_New() *A_arbace_go_check_summarize_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000370_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_go_check_summarize_fn__1685000370_A) Ctor() {}
//line :484:1
func (t *A_arbace_go_check_summarize_fn__1685000370_A) Invoke_O_O__O(self, p1__1685000358_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_269.Invoke_O__O(p1__1685000358_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000358_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_104.Invoke_O__O(p1__1685000358_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000372_A_New() *A_arbace_go_check_summarize_fn__1685000372_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000372_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_go_check_summarize_fn__1685000372_A) Ctor() {}
//line :489:1
func (t *A_arbace_go_check_summarize_fn__1685000372_A) Invoke_O_O__O(self, p1__1685000359_SHARP___1 any) any { var root_3149 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3149, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3151 lang.IFn; if linked_3150 == nil { ifn_3151 = lang.IFn_Cast(root_3149) } else { ifn_3151 = nil }; var arg_3152 any = p1__1685000359_SHARP___1; var arg_3153 any = A_arbace_go_check_A_const_300; if linked_3150 == nil { return ifn_3151.Invoke_O_O__O(arg_3152, arg_3153) } else { return linked_3150.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3149, arg_3152, arg_3153) } }
func A_arbace_go_check_summarize_fn__1685000374_A_New() *A_arbace_go_check_summarize_fn__1685000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000374_A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_go_check_summarize_fn__1685000374_A) Ctor() {}
//line :490:1
func (t *A_arbace_go_check_summarize_fn__1685000374_A) Invoke_O_O__O(self, p1__1685000360_SHARP___1 any) any { var root_3179 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3179, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3181 lang.IFn; if linked_3180 == nil { ifn_3181 = lang.IFn_Cast(root_3179) } else { ifn_3181 = nil }; var arg_3182 any = p1__1685000360_SHARP___1; var arg_3183 any = A_arbace_go_check_A_const_305; var arg_3184 any = A_arbace_go_check_A_const_22; if linked_3180 == nil { return ifn_3181.Invoke_O_O_O__O(arg_3182, arg_3183, arg_3184) } else { return linked_3180.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3179, arg_3182, arg_3183, arg_3184) } }
func A_arbace_go_check_summarize_fn__1685000376_A_New() *A_arbace_go_check_summarize_fn__1685000376_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000376_A{}; t.Ctor(); return t }
//line :491:1
func (t *A_arbace_go_check_summarize_fn__1685000376_A) Ctor() {}
//line :491:1
func (t *A_arbace_go_check_summarize_fn__1685000376_A) Invoke_O_O__O(self, p1__1685000361_SHARP___1 any) any { var root_3160 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_3161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3160, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3162 lang.IFn; if linked_3161 == nil { ifn_3162 = lang.IFn_Cast(root_3160) } else { ifn_3162 = nil }; var arg_3163 any; var root_3164 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3164, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3166 lang.IFn; if linked_3165 == nil { ifn_3166 = lang.IFn_Cast(root_3164) } else { ifn_3166 = nil }; var arg_3167 any = p1__1685000361_SHARP___1; var arg_3168 any = A_arbace_go_check_A_const_304; if linked_3165 == nil { arg_3163 = ifn_3166.Invoke_O_O__O(arg_3167, arg_3168) } else { arg_3163 = linked_3165.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3164, arg_3167, arg_3168) }; if linked_3161 == nil { return ifn_3162.Invoke_O__O(arg_3163) } else { return linked_3161.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3160, arg_3163) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :494:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000379__1685000385_A_New(); var tmp2 *jrt.Class; var fncls__3271 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000379__1685000385_A_fn_class; if


	fncls__3271 == nil { var fncls__3271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_go_check_report_errors_iter__1685000379__1685000385_A_fn_class = fncls__3271d; tmp2 = fncls__3271d } else { tmp2 = fncls__3271 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :497:1
func A_arbace_go_check_report_errors_iter__1685000379__1685000385_A_New() *A_arbace_go_check_report_errors_iter__1685000379__1685000385_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000379__1685000385_A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_A) Ctor() {}
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_A) Invoke_O_O__O(self, s__1685000380__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A_New_O_O(s__1685000380__1, self); var tmp2 *jrt.Class; var fncls__3270 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A_fn_class; if fncls__3270 == nil { var fncls__3270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A_fn_class = fncls__3270d; tmp2 = fncls__3270d } else { tmp2 = fncls__3270 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :497:1
func A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A{}; t.Ctor_O_O(p0, p1); return t }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A) Ctor_O_O(c__s__1685000380, c__iter__1685000379 any) { t.F_s__1685000380 = c__s__1685000380; t.F_iter__1685000379 = c__iter__1685000379 }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A) Invoke_O__O(self any) any { { var s__1685000380__1 any; var t_ any = t.F_s__1685000380; t.F_s__1685000380 = nil; s__1685000380__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3186 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var arg_3189 any = s__1685000380__1; if linked_3187 == nil { temp__1927000414__auto____2 = ifn_3188.Invoke_O__O(arg_3189) } else { temp__1927000414__auto____2 = linked_3187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3186, arg_3189) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3190 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3190, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3192 lang.IFn; if linked_3191 == nil { ifn_3192 = lang.IFn_Cast(root_3190) } else { ifn_3192 = nil }; var arg_3193 any = xs__1927001018__auto____3; if linked_3191 == nil { r__4 = ifn_3192.Invoke_O__O(arg_3193) } else { r__4 = linked_3191.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3190, arg_3193) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3252 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A_fn_class; if fncls__3252 == nil { var fncls__3252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A_fn_class = fncls__3252d; tmp2 = fncls__3252d } else { tmp2 = fncls__3252 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3253 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3253, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3255 lang.IFn; if linked_3254 == nil { ifn_3255 = lang.IFn_Cast(root_3253) } else { ifn_3255 = nil }; var arg_3256 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_207.Invoke_O__O(r__4)); if linked_3254 == nil { fs__1927001036__auto____6 = ifn_3255.Invoke_O__O(arg_3256) } else { fs__1927001036__auto____6 = linked_3254.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3253, arg_3256) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3257 any = A_arbace_go_check_A_const_286.GetRawRoot__O(); var linked_3258 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3257, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3259 lang.IFn; if linked_3258 == nil { ifn_3259 = lang.IFn_Cast(root_3257) } else { ifn_3259 = nil }; var arg_3260 any = fs__1927001036__auto____6; var arg_3261 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000379); var tmp4 any; var root_3262 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3262, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = s__1685000380__1; if linked_3263 == nil { tmp4 = ifn_3264.Invoke_O__O(arg_3265) } else { tmp4 = linked_3263.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3262, arg_3265) }; arg_3261 = tmp3.Invoke_O__O(tmp4); if linked_3258 == nil { return ifn_3259.Invoke_O_O__O(arg_3260, arg_3261) } else { return linked_3258.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3257, arg_3260, arg_3261) } } else { var tmp5 any; var root_3266 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3266, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3268 lang.IFn; if linked_3267 == nil { ifn_3268 = lang.IFn_Cast(root_3266) } else { ifn_3268 = nil }; var arg_3269 any = s__1685000380__1; if linked_3267 == nil { tmp5 = ifn_3268.Invoke_O__O(arg_3269) } else { tmp5 = linked_3267.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3266, arg_3269) }; s__1685000380__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :497:1
func A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A{}; t.Ctor_O(p0); return t }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A) Invoke_O_O__O(self, s__1685000382__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A_New_O_O_O(t.F_r, s__1685000382__1, self); var tmp2 *jrt.Class; var fncls__3251 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A_fn_class; if fncls__3251 == nil { var fncls__3251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A_fn_class = fncls__3251d; tmp2 = fncls__3251d } else { tmp2 = fncls__3251 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :497:1
func A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A) Ctor_O_O_O(c__r, c__s__1685000382, c__iter__1685000381 any) { t.F_r = c__r; t.F_s__1685000382 = c__s__1685000382; t.F_iter__1685000381 = c__iter__1685000381 }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A) Invoke_O__O(self any) any { { var s__1685000382__1 any; var t_ any = t.F_s__1685000382; t.F_s__1685000382 = nil; s__1685000382__1 = t_; for { var temp__1927000414__auto____2 any; var root_3194 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3194, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3196 lang.IFn; if linked_3195 == nil { ifn_3196 = lang.IFn_Cast(root_3194) } else { ifn_3196 = nil }; var arg_3197 any = s__1685000382__1; if linked_3195 == nil { temp__1927000414__auto____2 = ifn_3196.Invoke_O__O(arg_3197) } else { temp__1927000414__auto____2 = linked_3195.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3194, arg_3197) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000382__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3198 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3198, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3200 lang.IFn; if linked_3199 == nil { ifn_3200 = lang.IFn_Cast(root_3198) } else { ifn_3200 = nil }; var arg_3201 any = s__1685000382__3; if linked_3199 == nil { tmp1 = ifn_3200.Invoke_O__O(arg_3201) } else { tmp1 = linked_3199.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3198, arg_3201) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3202 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3202, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3204 lang.IFn; if linked_3203 == nil { ifn_3204 = lang.IFn_Cast(root_3202) } else { ifn_3204 = nil }; var arg_3205 any = s__1685000382__3; if linked_3203 == nil { c__1927001037__auto____4 = ifn_3204.Invoke_O__O(arg_3205) } else { c__1927001037__auto____4 = linked_3203.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3202, arg_3205) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000384__6 any; var root_3206 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3206, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3208 lang.IFn; if linked_3207 == nil { ifn_3208 = lang.IFn_Cast(root_3206) } else { ifn_3208 = nil }; var arg_3209 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3207 == nil { b__1685000384__6 = ifn_3208.Invoke_O__O(arg_3209) } else { b__1685000384__6 = linked_3207.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3206, arg_3209) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, b__1685000384__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3215 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A_fn_class; if fncls__3215 == nil { var fncls__3215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A_fn_class = fncls__3215d; tmp3 = fncls__3215d } else { tmp3 = fncls__3215 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3216 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3216, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3218 lang.IFn; if linked_3217 == nil { ifn_3218 = lang.IFn_Cast(root_3216) } else { ifn_3218 = nil }; var arg_3219 any; var root_3221 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3223 lang.IFn; if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = b__1685000384__6; if linked_3222 == nil { arg_3219 = ifn_3223.Invoke_O__O(arg_3224) } else { arg_3219 = linked_3222.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3221, arg_3224) }; var arg_3220 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000381); var tmp5 any; var root_3225 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3225, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3227 lang.IFn; if linked_3226 == nil { ifn_3227 = lang.IFn_Cast(root_3225) } else { ifn_3227 = nil }; var arg_3228 any = s__1685000382__3; if linked_3226 == nil { tmp5 = ifn_3227.Invoke_O__O(arg_3228) } else { tmp5 = linked_3226.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3225, arg_3228) }; arg_3220 = tmp4.Invoke_O__O(tmp5); if linked_3217 == nil { return ifn_3218.Invoke_O_O__O(arg_3219, arg_3220) } else { return linked_3217.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3216, arg_3219, arg_3220) } } else { var root_3229 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3229, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3231 lang.IFn; if linked_3230 == nil { ifn_3231 = lang.IFn_Cast(root_3229) } else { ifn_3231 = nil }; var arg_3232 any; var root_3234 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3236 lang.IFn; if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = b__1685000384__6; if linked_3235 == nil { arg_3232 = ifn_3236.Invoke_O__O(arg_3237) } else { arg_3232 = linked_3235.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3234, arg_3237) }; var arg_3233 any; if linked_3230 == nil { return ifn_3231.Invoke_O_O__O(arg_3232, arg_3233) } else { return linked_3230.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3229, arg_3232, arg_3233) } } } else { var e__4 any; var root_3238 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3240 lang.IFn; if linked_3239 == nil { ifn_3240 = lang.IFn_Cast(root_3238) } else { ifn_3240 = nil }; var arg_3241 any = s__1685000382__3; if linked_3239 == nil { e__4 = ifn_3240.Invoke_O__O(arg_3241) } else { e__4 = linked_3239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3238, arg_3241) }; var root_3242 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3242, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3244 lang.IFn; if linked_3243 == nil { ifn_3244 = lang.IFn_Cast(root_3242) } else { ifn_3244 = nil }; var arg_3245 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_23, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_270.Invoke_O__O(e__4))).Ref(); var arg_3246 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000381); var tmp7 any; var root_3247 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3247, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3249 lang.IFn; if linked_3248 == nil { ifn_3249 = lang.IFn_Cast(root_3247) } else { ifn_3249 = nil }; var arg_3250 any = s__1685000382__3; if linked_3248 == nil { tmp7 = ifn_3249.Invoke_O__O(arg_3250) } else { tmp7 = linked_3248.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3247, arg_3250) }; arg_3246 = tmp6.Invoke_O__O(tmp7); if linked_3243 == nil { return ifn_3244.Invoke_O_O__O(arg_3245, arg_3246) } else { return linked_3243.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3242, arg_3245, arg_3246) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :497:1
func A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__b__1685000384, c__c__1927001037__auto__ any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000384 = c__b__1685000384; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :497:1
func (t *A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A) Invoke_O__O(self any) any { { var i__1685000383__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000383__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000383__1)); var root_3210 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3210, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3212 lang.IFn; if linked_3211 == nil { ifn_3212 = lang.IFn_Cast(root_3210) } else { ifn_3212 = nil }; var arg_3213 any = t.F_b__1685000384; var arg_3214 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_23, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_270.Invoke_O__O(e__2))).Ref(); if linked_3211 == nil { ifn_3212.Invoke_O_O__O(arg_3213, arg_3214) } else { linked_3211.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3210, arg_3213, arg_3214) }; i__1685000383__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000383__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :502:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000397__3 any; var root_3272 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3274 lang.IFn; if



	linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = forms__0; if linked_3273 == nil { map__1685000397__3 = ifn_3274.Invoke_O__O(arg_3275) } else { map__1685000397__3 = linked_3273.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3272, arg_3275) }; var map__1685000397__4 any; if lang.ISeq_InstanceOf(map__1685000397__3) { var tmp1 any; var root_3276 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any = map__1685000397__3; if linked_3277 == nil { tmp1 = ifn_3278.Invoke_O__O(arg_3279) } else { tmp1 = linked_3277.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3276, arg_3279) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3280 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3280, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3282 lang.IFn; if linked_3281 == nil { ifn_3282 = lang.IFn_Cast(root_3280) } else { ifn_3282 = nil }; var arg_3283 any = map__1685000397__3; if linked_3281 == nil { tmp2 = ifn_3282.Invoke_O__O(arg_3283) } else { tmp2 = linked_3281.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3280, arg_3283) }; map__1685000397__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3284 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3284, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3286 lang.IFn; if linked_3285 == nil { ifn_3286 = lang.IFn_Cast(root_3284) } else { ifn_3286 = nil }; var arg_3287 any = map__1685000397__3; if linked_3285 == nil { tmp3 = ifn_3286.Invoke_O__O(arg_3287) } else { tmp3 = linked_3285.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3284, arg_3287) }; if jrt.J2g_Truth(tmp3) { var root_3288 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = map__1685000397__3; if linked_3289 == nil { map__1685000397__4 = ifn_3290.Invoke_O__O(arg_3291) } else { map__1685000397__4 = linked_3289.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3288, arg_3291) } } else { map__1685000397__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000397__4 = map__1685000397__3 }; var package__5 any = /*line :502:1*/lang.RT_Get_O_O__O_NoInit(map__1685000397__4, A_arbace_go_check_A_const_103); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000397__4, A_arbace_go_check_A_const_70); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000397__4, A_arbace_go_check_A_const_114); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_307.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_308; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_105.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_104; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_104.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_107 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_70; var tmp10 any; var root_3298 any = /*line :502:1*/A_arbace_go_check_A_const_309.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3300 lang.IFn; if





	linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any = name__6; if linked_3299 == nil { tmp10 = ifn_3300.Invoke_O__O(arg_3301) } else { tmp10 = linked_3299.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3298, arg_3301) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_105; var tmp13 any = A_arbace_go_check_A_const_81; var tmp14 any = A_arbace_go_check_A_const_202; var tmp15 any; var root_3302 any = /*line :502:1*/A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3304 lang.IFn; if






	linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000399_A_New(); var tmp17 *jrt.Class; var fncls__3319 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000399_A_fn_class; if fncls__3319 == nil { var fncls__3319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_check_forms_source_fn__1685000399_A_fn_class = fncls__3319d; tmp17 = fncls__3319d } else { tmp17 = fncls__3319 }; arg_3305 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3306 any = forms__0; if linked_3303 == nil { tmp15 = ifn_3304.Invoke_O_O__O(arg_3305, arg_3306) } else { tmp15 = linked_3303.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3302, arg_3305, arg_3306) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_114; var tmp20 any; var root_3320 any = /*line :502:1*/A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3322 lang.IFn; if







	linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000401__1685000405_A_New(); var tmp22 *jrt.Class; var fncls__3394 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000401__1685000405_A_fn_class; if fncls__3394 == nil { var fncls__3394d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_go_check_forms_source_iter__1685000401__1685000405_A_fn_class = fncls__3394d; tmp22 = fncls__3394d } else { tmp22 = fncls__3394 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3323 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3321 == nil { tmp20 = ifn_3322.Invoke_O__O(arg_3323) } else { tmp20 = linked_3321.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3320, arg_3323) }; return /*line :502:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000399_A_New() *A_arbace_go_check_forms_source_fn__1685000399_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000399_A{}; t.Ctor(); return t }
//line :509:1
func (t *A_arbace_go_check_forms_source_fn__1685000399_A) Ctor() {}
//line :509:1
func (t *A_arbace_go_check_forms_source_fn__1685000399_A) Invoke_O_O__O(self, p1__1685000396_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3307 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3307, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3309 lang.IFn; if linked_3308 == nil { ifn_3309 = lang.IFn_Cast(root_3307) } else { ifn_3309 = nil }; var arg_3310 any = p1__1685000396_SHARP___1; if linked_3308 == nil { and__1927000168__auto____2 = ifn_3309.Invoke_O__O(arg_3310) } else { and__1927000168__auto____2 = linked_3308.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3307, arg_3310) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_310; var tmp3 any; var root_3311 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3313 lang.IFn; if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any = p1__1685000396_SHARP___1; if linked_3312 == nil { tmp3 = ifn_3313.Invoke_O__O(arg_3314) } else { tmp3 = linked_3312.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3311, arg_3314) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3315 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_3316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3315, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3317 lang.IFn; if linked_3316 == nil { ifn_3317 = lang.IFn_Cast(root_3315) } else { ifn_3317 = nil }; var arg_3318 any = p1__1685000396_SHARP___1; if linked_3316 == nil { return ifn_3317.Invoke_O__O(arg_3318) } else { return linked_3316.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3315, arg_3318) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000401__1685000405_A_New() *A_arbace_go_check_forms_source_iter__1685000401__1685000405_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000401__1685000405_A{}; t.Ctor(); return t }
//line :510:1
func (t *A_arbace_go_check_forms_source_iter__1685000401__1685000405_A) Ctor() {}
//line :510:1
func (t *A_arbace_go_check_forms_source_iter__1685000401__1685000405_A) Invoke_O_O__O(self, s__1685000402__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A_New_O_O(s__1685000402__1, self); var tmp2 *jrt.Class; var fncls__3393 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A_fn_class; if fncls__3393 == nil { var fncls__3393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A_fn_class = fncls__3393d; tmp2 = fncls__3393d } else { tmp2 = fncls__3393 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :510:1
func A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A{}; t.Ctor_O_O(p0, p1); return t }
//line :510:1
func (t *A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A) Ctor_O_O(c__s__1685000402, c__iter__1685000401 any) { t.F_s__1685000402 = c__s__1685000402; t.F_iter__1685000401 = c__iter__1685000401 }
//line :510:1
func (t *A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A) Invoke_O__O(self any) any { { var s__1685000402__1 any; var t_ any = t.F_s__1685000402; t.F_s__1685000402 = nil; s__1685000402__1 = t_; for { var temp__1927000414__auto____2 any; var root_3324 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3326 lang.IFn; if linked_3325 == nil { ifn_3326 = lang.IFn_Cast(root_3324) } else { ifn_3326 = nil }; var arg_3327 any = s__1685000402__1; if linked_3325 == nil { temp__1927000414__auto____2 = ifn_3326.Invoke_O__O(arg_3327) } else { temp__1927000414__auto____2 = linked_3325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3324, arg_3327) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000402__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3328 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3330 lang.IFn; if linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any = s__1685000402__3; if linked_3329 == nil { tmp1 = ifn_3330.Invoke_O__O(arg_3331) } else { tmp1 = linked_3329.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3328, arg_3331) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3332 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3332, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3334 lang.IFn; if linked_3333 == nil { ifn_3334 = lang.IFn_Cast(root_3332) } else { ifn_3334 = nil }; var arg_3335 any = s__1685000402__3; if linked_3333 == nil { c__1927001037__auto____4 = ifn_3334.Invoke_O__O(arg_3335) } else { c__1927001037__auto____4 = linked_3333.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3332, arg_3335) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000404__6 any; var root_3336 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3336, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3338 lang.IFn; if linked_3337 == nil { ifn_3338 = lang.IFn_Cast(root_3336) } else { ifn_3338 = nil }; var arg_3339 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3337 == nil { b__1685000404__6 = ifn_3338.Invoke_O__O(arg_3339) } else { b__1685000404__6 = linked_3337.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3336, arg_3339) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A_New_O_I_O(b__1685000404__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3351 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A_fn_class; if fncls__3351 == nil { var fncls__3351d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A_fn_class = fncls__3351d; tmp3 = fncls__3351d } else { tmp3 = fncls__3351 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3352 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3352, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3354 lang.IFn; if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any; var root_3357 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3357, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3359 lang.IFn; if linked_3358 == nil { ifn_3359 = lang.IFn_Cast(root_3357) } else { ifn_3359 = nil }; var arg_3360 any = b__1685000404__6; if linked_3358 == nil { arg_3355 = ifn_3359.Invoke_O__O(arg_3360) } else { arg_3355 = linked_3358.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3357, arg_3360) }; var arg_3356 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000401); var tmp5 any; var root_3361 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3361, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3363 lang.IFn; if linked_3362 == nil { ifn_3363 = lang.IFn_Cast(root_3361) } else { ifn_3363 = nil }; var arg_3364 any = s__1685000402__3; if linked_3362 == nil { tmp5 = ifn_3363.Invoke_O__O(arg_3364) } else { tmp5 = linked_3362.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3361, arg_3364) }; arg_3356 = tmp4.Invoke_O__O(tmp5); if linked_3353 == nil { return ifn_3354.Invoke_O_O__O(arg_3355, arg_3356) } else { return linked_3353.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3352, arg_3355, arg_3356) } } else { var root_3365 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3365, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3367 lang.IFn; if linked_3366 == nil { ifn_3367 = lang.IFn_Cast(root_3365) } else { ifn_3367 = nil }; var arg_3368 any; var root_3370 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3370, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3372 lang.IFn; if linked_3371 == nil { ifn_3372 = lang.IFn_Cast(root_3370) } else { ifn_3372 = nil }; var arg_3373 any = b__1685000404__6; if linked_3371 == nil { arg_3368 = ifn_3372.Invoke_O__O(arg_3373) } else { arg_3368 = linked_3371.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3370, arg_3373) }; var arg_3369 any; if linked_3366 == nil { return ifn_3367.Invoke_O_O__O(arg_3368, arg_3369) } else { return linked_3366.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3365, arg_3368, arg_3369) } } } else { var fi__4 any; var root_3374 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3376 lang.IFn; if linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var arg_3377 any = s__1685000402__3; if linked_3375 == nil { fi__4 = ifn_3376.Invoke_O__O(arg_3377) } else { fi__4 = linked_3375.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3374, arg_3377) }; var root_3378 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3380 lang.IFn; if linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any; var root_3383 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3383, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3385 lang.IFn; if linked_3384 == nil { ifn_3385 = lang.IFn_Cast(root_3383) } else { ifn_3385 = nil }; var arg_3386 any = fi__4; var arg_3387 any = A_arbace_go_check_A_const_81; var arg_3388 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__4); if linked_3384 == nil { arg_3381 = ifn_3385.Invoke_O_O_O__O(arg_3386, arg_3387, arg_3388) } else { arg_3381 = linked_3384.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3383, arg_3386, arg_3387, arg_3388) }; var arg_3382 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000401); var tmp7 any; var root_3389 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3389, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3391 lang.IFn; if linked_3390 == nil { ifn_3391 = lang.IFn_Cast(root_3389) } else { ifn_3391 = nil }; var arg_3392 any = s__1685000402__3; if linked_3390 == nil { tmp7 = ifn_3391.Invoke_O__O(arg_3392) } else { tmp7 = linked_3390.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3389, arg_3392) }; arg_3382 = tmp6.Invoke_O__O(tmp7); if linked_3379 == nil { return ifn_3380.Invoke_O_O__O(arg_3381, arg_3382) } else { return linked_3379.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3378, arg_3381, arg_3382) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :510:1
func A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :510:1
func (t *A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A) Ctor_O_I_O(c__b__1685000404 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000404 = c__b__1685000404; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :510:1
func (t *A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A) Invoke_O__O(self any) any { { var i__1685000403__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000403__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000403__1)); var root_3340 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3340, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3342 lang.IFn; if linked_3341 == nil { ifn_3342 = lang.IFn_Cast(root_3340) } else { ifn_3342 = nil }; var arg_3343 any = t.F_b__1685000404; var arg_3344 any; var root_3345 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3346 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3345, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3347 lang.IFn; if linked_3346 == nil { ifn_3347 = lang.IFn_Cast(root_3345) } else { ifn_3347 = nil }; var arg_3348 any = fi__2; var arg_3349 any = A_arbace_go_check_A_const_81; var arg_3350 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__2); if linked_3346 == nil { arg_3344 = ifn_3347.Invoke_O_O_O__O(arg_3348, arg_3349, arg_3350) } else { arg_3344 = linked_3346.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3345, arg_3348, arg_3349, arg_3350) }; if linked_3341 == nil { ifn_3342.Invoke_O_O__O(arg_3343, arg_3344) } else { linked_3341.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3340, arg_3343, arg_3344) }; i__1685000403__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000403__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :512:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :512:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3404 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3406 lang.IFn; if




	linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var arg_3407 any = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_312, jrt.Boolean_FALSE.Ref()); if linked_3405 == nil { ifn_3406.Invoke_O__O(arg_3407) } else { linked_3405.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3404, arg_3407) }; var tmp1 any; tmp3 := /*line :512:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3395 any = A_arbace_go_check_A_const_311.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3397 lang.IFn






		if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = r__2; var arg_3399 any = jrt.Boolean_FALSE.Ref(); var arg_3400 any = eof__3; if linked_3396 == nil { f__7 = ifn_3397.Invoke_O_O_O__O(arg_3398, arg_3399, arg_3400) } else { f__7 = linked_3396.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3395, arg_3398, arg_3399, arg_3400) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3413 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3413, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = acc__6; var arg_3417 any = f__7; if linked_3414 == nil { tmp2 = ifn_3415.Invoke_O_O__O(arg_3416, arg_3417) } else { tmp2 = linked_3414.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3413, arg_3416, arg_3417) }; acc__6 = tmp2; continue L1 }
//line :512:1
		break L1 } }; return nil }(); var root_3401 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3403 lang.IFn; if




	linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; if linked_3402 == nil { ifn_3403.Invoke__O() } else { linked_3402.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3401) }; if /*line :512:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :524:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3418 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3418, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3420 lang.IFn; if


	linked_3419 == nil { ifn_3420 = lang.IFn_Cast(root_3418) } else { ifn_3420 = nil }; var arg_3421 any = A_arbace_go_check_A_const_313.GetRawRoot__O(); if linked_3419 == nil { tmp1 = ifn_3420.Invoke_O__O(arg_3421) } else { tmp1 = linked_3419.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3418, arg_3421) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3422 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_3423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3422, A_arbace_go_check_std_session_A_fn_class); var ifn_3424 lang.IFn
		if linked_3423 == nil { ifn_3424 = lang.IFn_Cast(root_3422) } else { ifn_3424 = nil }; var arg_3425 any; var root_3426 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3428 lang.IFn; if linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any = corpus__0; if linked_3427 == nil { arg_3425 = ifn_3428.Invoke_O__O(arg_3429) } else { arg_3425 = linked_3427.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3426, arg_3429) }; if linked_3423 == nil { s__3 = ifn_3424.Invoke_O__O(arg_3425) } else { s__3 = linked_3423.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3422, arg_3425) }
		var root_3430 any = A_arbace_go_check_A_const_248.GetRawRoot__O(); var linked_3431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3430, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3432 lang.IFn; if linked_3431 == nil { ifn_3432 = lang.IFn_Cast(root_3430) } else { ifn_3432 = nil }; var arg_3433 any = A_arbace_go_check_A_const_313.GetRawRoot__O(); var arg_3434 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var arg_3435 any = corpus__0; var arg_3436 any = s__3; if linked_3431 == nil { ifn_3432.Invoke_O_O_O_O__O(arg_3433, arg_3434, arg_3435, arg_3436) } else { linked_3431.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3430, arg_3433, arg_3434, arg_3435, arg_3436) }
//line :527:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :532:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3437 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var linked_3438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3437, A_arbace_go_check_std_A_fn_class); var ifn_3439 lang.IFn; if




	linked_3438 == nil { ifn_3439 = lang.IFn_Cast(root_3437) } else { ifn_3439 = nil }; var arg_3440 any = corpus__1; if linked_3438 == nil { s__4 = ifn_3439.Invoke_O__O(arg_3440) } else { s__4 = linked_3438.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3437, arg_3440) }; var src__5 any; var root_3441 any = /*line :532:1*/A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3441, A_arbace_go_check_forms_source_A_fn_class); var ifn_3443 lang.IFn; if





	linked_3442 == nil { ifn_3443 = lang.IFn_Cast(root_3441) } else { ifn_3443 = nil }; var arg_3444 any = forms__0; var arg_3445 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_105; var tmp2 any; var root_3446 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3446, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3448 lang.IFn; if linked_3447 == nil { ifn_3448 = lang.IFn_Cast(root_3446) } else { ifn_3448 = nil }; var arg_3449 any = corpus__1; if linked_3447 == nil { tmp2 = ifn_3448.Invoke_O__O(arg_3449) } else { tmp2 = linked_3447.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3446, arg_3449) }; arg_3445 = tmp1.Invoke_O__O(tmp2); if linked_3442 == nil { src__5 = ifn_3443.Invoke_O_O__O(arg_3444, arg_3445) } else { src__5 = linked_3442.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3441, arg_3444, arg_3445) }; var pkg__6 any; var tmp3 lang.IFn = /*line :532:1*/lang.IFn_Cast(A_arbace_go_check_A_const_241.GetRawRoot__O()); var tmp4 any; var root_3457 any = A_arbace_go_check_A_const_242.GetRawRoot__O(); var linked_3458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3457, A_arbace_go_check_resolver_A_fn_class); var ifn_3459 lang.IFn; if






	linked_3458 == nil { ifn_3459 = lang.IFn_Cast(root_3457) } else { ifn_3459 = nil }; var arg_3460 any = s__4; var arg_3461 any = src__5; var arg_3462 any = lang.PersistentVector_EMPTY.Ref(); if linked_3458 == nil { tmp4 = ifn_3459.Invoke_O_O_O__O(arg_3460, arg_3461, arg_3462) } else { tmp4 = linked_3458.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3457, arg_3460, arg_3461, arg_3462) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_102; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_102.Invoke_O__O(opts__2)); var root_3463 any =
	A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3463, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3465 lang.IFn; if linked_3464 == nil { ifn_3465 = lang.IFn_Cast(root_3463) } else { ifn_3465 = nil }; var arg_3466 any = pkg__6; var arg_3467 any = A_arbace_go_check_A_const_206; if linked_3464 == nil { return ifn_3465.Invoke_O_O__O(arg_3466, arg_3467) } else { return linked_3464.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3463, arg_3466, arg_3467) } }
//line :532:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_3468 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, A_arbace_go_check_check_forms_A_fn_class); var ifn_3470 lang.IFn; if linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any = forms__0; var arg_3472 any = Lit_51; var arg_3473 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3469 == nil { return ifn_3470.Invoke_O_O_O__O(arg_3471, arg_3472, arg_3473) } else { return linked_3469.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_3468, arg_3471, arg_3472, arg_3473)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :548:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_321.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_317.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_3491 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3491, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3493 lang.IFn; if linked_3492 == nil { ifn_3493 = lang.IFn_Cast(root_3491) } else { ifn_3493 = nil }; var arg_3494 any = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_320, s__1927001093__auto____3); if linked_3492 == nil { ifn_3493.Invoke_O__O(arg_3494) } else { linked_3492.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3491, arg_3494) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000415_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__3490 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000415_A_fn_class; if fncls__3490 == nil { var fncls__3490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_check_write_edn_fn__1685000415_A_fn_class = fncls__3490d; tmp4 = fncls__3490d } else { tmp4 = fncls__3490 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :550:1
func A_arbace_go_check_write_edn_fn__1685000415_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000415_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000415_A{}; t.Ctor_O_O(p0, p1); return t }
//line :550:1
func (t *A_arbace_go_check_write_edn_fn__1685000415_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :550:1
func (t *A_arbace_go_check_write_edn_fn__1685000415_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3486 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3486, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_3488 lang.IFn; if linked_3487 == nil { ifn_3488 = lang.IFn_Cast(root_3486) } else { ifn_3488 = nil }; var arg_3489 any; var t_ any = t.F_x; t.F_x = nil; arg_3489 = t_; if linked_3487 == nil { ifn_3488.Invoke_O__O(arg_3489) } else { linked_3487.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_3486, arg_3489) }; var root_3479 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3479, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3481 lang.IFn; if linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_3482 = t__2; if linked_3480 == nil { tmp1 = ifn_3481.Invoke_O__O(arg_3482) } else { tmp1 = linked_3480.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3479, arg_3482) } }; return nil }(); var root_3483 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3483, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3485 lang.IFn; if linked_3484 == nil { ifn_3485 = lang.IFn_Cast(root_3483) } else { ifn_3485 = nil }; if linked_3484 == nil { ifn_3485.Invoke__O() } else { linked_3484.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3483) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :552:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_115, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil, corpus__0, nil)).Ref() }

func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :554:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :554:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000419__1 any) any { var map__1685000420__3 any = p__1685000419__1; var map__1685000420__4 any; if lang.ISeq_InstanceOf(map__1685000420__3) { var tmp1 any; var root_3504 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3504, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3506 lang.IFn; if linked_3505 == nil { ifn_3506 = lang.IFn_Cast(root_3504) } else { ifn_3506 = nil }; var arg_3507 any = map__1685000420__3; if linked_3505 == nil { tmp1 = ifn_3506.Invoke_O__O(arg_3507) } else { tmp1 = linked_3505.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3504, arg_3507) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3508 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3508, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3510 lang.IFn; if linked_3509 == nil { ifn_3510 = lang.IFn_Cast(root_3508) } else { ifn_3510 = nil }; var arg_3511 any = map__1685000420__3; if linked_3509 == nil { tmp2 = ifn_3510.Invoke_O__O(arg_3511) } else { tmp2 = linked_3509.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3508, arg_3511) }; map__1685000420__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3512 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3512, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3514 lang.IFn; if linked_3513 == nil { ifn_3514 = lang.IFn_Cast(root_3512) } else { ifn_3514 = nil }; var arg_3515 any = map__1685000420__3; if linked_3513 == nil { tmp3 = ifn_3514.Invoke_O__O(arg_3515) } else { tmp3 = linked_3513.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3512, arg_3515) }; if jrt.J2g_Truth(tmp3) { var root_3516 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3516, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3518 lang.IFn; if linked_3517 == nil { ifn_3518 = lang.IFn_Cast(root_3516) } else { ifn_3518 = nil }; var arg_3519 any = map__1685000420__3; if linked_3517 == nil { map__1685000420__4 = ifn_3518.Invoke_O__O(arg_3519) } else { map__1685000420__4 = linked_3517.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3516, arg_3519) } } else { map__1685000420__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000420__4 = map__1685000420__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000420__4, A_arbace_go_check_A_const_322); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000420__4, A_arbace_go_check_A_const_323); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000420__4, A_arbace_go_check_A_const_324); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_3520 any = A_arbace_go_check_A_const_325.GetRawRoot__O(); var linked_3521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3520, A_arbace_go_check_check_corpus_A_fn_class); var ifn_3522 lang.IFn; if






	linked_3521 == nil { ifn_3522 = lang.IFn_Cast(root_3520) } else { ifn_3522 = nil }; var arg_3523 any = corpus__0; var arg_3524 any = jobs__5; if linked_3521 == nil { rs__9 = ifn_3522.Invoke_O_O__O(arg_3523, arg_3524) } else { rs__9 = linked_3521.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_3520, arg_3523, arg_3524) }; var sm__10 any; var root_3525 any = /*line :554:1*/A_arbace_go_check_A_const_326.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, A_arbace_go_check_summarize_A_fn_class); var ifn_3527 lang.IFn; if







	linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any = corpus__0; var arg_3529 any = rs__9; if linked_3526 == nil { sm__10 = ifn_3527.Invoke_O_O__O(arg_3528, arg_3529) } else { sm__10 = linked_3526.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_3525, arg_3528, arg_3529) }; var secs__11 float64 = /*line :554:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_327; var tmp5 any; var root_3530 any = A_arbace_go_check_A_const_328.GetRawRoot__O(); var linked_3531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3530, A_arbace_go_check_reference_path_A_fn_class); var ifn_3532 lang.IFn; if









	linked_3531 == nil { ifn_3532 = lang.IFn_Cast(root_3530) } else { ifn_3532 = nil }; var arg_3533 any = corpus__0; if linked_3531 == nil { tmp5 = ifn_3532.Invoke_O__O(arg_3533) } else { tmp5 = linked_3531.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3530, arg_3533) }; ref_file__12 = /*line :554:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var root_3534 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any = lang.IFn_Cast(A_arbace_go_check_A_const_330.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_3535 == nil { ref__13 = ifn_3536.Invoke_O__O(arg_3537) } else { ref__13 = linked_3535.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_3534, arg_3537) } } else { ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_3542 any = /*line :554:1*/A_arbace_go_check_A_const_207.Invoke_O__O(sm__10); if











	jrt.Long_InstanceOf(na_3542) { var n0_3543 int64 = jrt.NN(jrt.Long_Cast(na_3542)).LongValue__J(); and__1927000168__auto____14 = n0_3543 == 0 } else { if jrt.Double_InstanceOf(na_3542) { var n0_3543_2 float64 = jrt.NN(jrt.Double_Cast(na_3542)).DoubleValue__D(); and__1927000168__auto____14 = n0_3543_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_3542) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_3544 any = A_arbace_go_check_A_const_294.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_3544) { var n0_3545 int64 = jrt.NN(jrt.Long_Cast(na_3544)).LongValue__J(); and__1927000168__auto____15 = n0_3545 == 0 } else { if jrt.Double_InstanceOf(na_3544) { var n0_3545_2 float64 = jrt.NN(jrt.Double_Cast(na_3544)).DoubleValue__D(); and__1927000168__auto____15 = n0_3545_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_3544) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_3546 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3546, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3548 lang.IFn; if linked_3547 == nil { ifn_3548 = lang.IFn_Cast(root_3546) } else { ifn_3548 = nil }; var arg_3549 any; var root_3550 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3552 lang.IFn; if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = sm__10; var arg_3554 any = A_arbace_go_check_A_const_331; if linked_3551 == nil { arg_3549 = ifn_3552.Invoke_O_O__O(arg_3553, arg_3554) } else { arg_3549 = linked_3551.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3550, arg_3553, arg_3554) }; if linked_3547 == nil { and__1927000168__auto____16 = ifn_3548.Invoke_O__O(arg_3549) } else { and__1927000168__auto____16 = linked_3547.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3546, arg_3549) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_3555 any; var root_3556 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3556, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3558 lang.IFn
		if linked_3557 == nil { ifn_3558 = lang.IFn_Cast(root_3556) } else { ifn_3558 = nil }; var arg_3559 any = sm__10; var arg_3560 any = A_arbace_go_check_A_const_332; if linked_3557 == nil { na_3555 = ifn_3558.Invoke_O_O__O(arg_3559, arg_3560) } else { na_3555 = linked_3557.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3556, arg_3559, arg_3560) }; if jrt.Long_InstanceOf(na_3555) { var n0_3561 int64 = jrt.NN(jrt.Long_Cast(na_3555)).LongValue__J(); and__1927000168__auto____17 = n0_3561 == 0 } else { if jrt.Double_InstanceOf(na_3555) { var n0_3561_2 float64 = jrt.NN(jrt.Double_Cast(na_3555)).DoubleValue__D(); and__1927000168__auto____17 = n0_3561_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_3555) } }
//line :566:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_3562 any; var root_3563 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3563, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3565 lang.IFn; if linked_3564 == nil { ifn_3565 = lang.IFn_Cast(root_3563) } else { ifn_3565 = nil }; var arg_3566 any = sm__10; var arg_3567 any = A_arbace_go_check_A_const_333; if linked_3564 == nil { na_3562 = ifn_3565.Invoke_O_O__O(arg_3566, arg_3567) } else { na_3562 = linked_3564.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3563, arg_3566, arg_3567) }; if jrt.Long_InstanceOf(na_3562) { var n0_3568 int64 = jrt.NN(jrt.Long_Cast(na_3562)).LongValue__J(); tmp6 = n0_3568 == 0 } else { if jrt.Double_InstanceOf(na_3562) { var n0_3568_2 float64 = jrt.NN(jrt.Double_Cast(na_3562)).DoubleValue__D(); tmp6 = n0_3568_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_3562) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :566:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_3569 any = /*line :554:1*/A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_3570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3569, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3571 lang.IFn; if














	linked_3570 == nil { ifn_3571 = lang.IFn_Cast(root_3569) } else { ifn_3571 = nil }; var arg_3572 any = ref__13; var arg_3573 any = A_arbace_go_check_A_const_334; if linked_3570 == nil { tmp7 = ifn_3571.Invoke_O_O__O(arg_3572, arg_3573) } else { tmp7 = linked_3570.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3569, arg_3572, arg_3573) }; var tmp8 any = tmp7; var tmp9 any; var root_3574 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_3575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3574, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3576 lang.IFn; if linked_3575 == nil { ifn_3576 = lang.IFn_Cast(root_3574) } else { ifn_3576 = nil }; var arg_3577 any = sm__10; var arg_3578 any = A_arbace_go_check_A_const_296; if linked_3575 == nil { tmp9 = ifn_3576.Invoke_O_O__O(arg_3577, arg_3578) } else { tmp9 = linked_3575.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3574, arg_3577, arg_3578) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_3587 any =
	A_arbace_go_check_A_const_335.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, A_arbace_go_check_write_edn_A_fn_class); var ifn_3589 lang.IFn; if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_3591 any; var tmp10 any = A_arbace_go_check_A_const_336; var tmp11 any = A_arbace_go_check_A_const_337; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_207; var tmp14 any; var root_3592 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_3593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3592, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3594 lang.IFn; if

	linked_3593 == nil { ifn_3594 = lang.IFn_Cast(root_3592) } else { ifn_3594 = nil }; var arg_3595 any; var root_3596 any = A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3596, A_arbace_go_check_report_errors_A_fn_class); var ifn_3598 lang.IFn; if linked_3597 == nil { ifn_3598 = lang.IFn_Cast(root_3596) } else { ifn_3598 = nil }; var arg_3599 any = rs__9; if linked_3597 == nil { arg_3595 = ifn_3598.Invoke_O__O(arg_3599) } else { arg_3595 = linked_3597.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3596, arg_3599) }; if linked_3593 == nil { tmp14 = ifn_3594.Invoke_O__O(arg_3595) } else { tmp14 = linked_3593.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3592, arg_3595) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_153; var tmp17 any; var root_3600 any = /*line :570:1*/A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_3601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3600, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3602 lang.IFn; if


	linked_3601 == nil { ifn_3602 = lang.IFn_Cast(root_3600) } else { ifn_3602 = nil }; var arg_3603 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000422__1685000428_A_New(); var tmp19 *jrt.Class; var fncls__3689 *jrt.Class = A_arbace_go_check_annotations_iter__1685000422__1685000428_A_fn_class; if fncls__3689 == nil { var fncls__3689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_annotations_iter__1685000422__1685000428_A_fn_class = fncls__3689d; tmp19 = fncls__3689d } else { tmp19 = fncls__3689 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_3603 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_3601 == nil { tmp17 = ifn_3602.Invoke_O__O(arg_3603) } else { tmp17 = linked_3601.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3600, arg_3603) }; arg_3591 = /*line :570:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_3588 == nil { ifn_3589.Invoke_O_O__O(arg_3590, arg_3591) } else { linked_3588.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3587, arg_3590, arg_3591) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_204.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_290.Invoke_O__O(sm__10); var tmp23 any; var root_3708 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3708, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3710 lang.IFn; if
	linked_3709 == nil { ifn_3710 = lang.IFn_Cast(root_3708) } else { ifn_3710 = nil }; var arg_3711 any = sm__10; var arg_3712 any = A_arbace_go_check_A_const_340; if linked_3709 == nil { tmp23 = ifn_3710.Invoke_O_O__O(arg_3711, arg_3712) } else { tmp23 = linked_3709.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3708, arg_3711, arg_3712) }; var tmp24 any = tmp23; var tmp25 any; var root_3713 any = /*line :574:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3713, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3715 lang.IFn; if
	linked_3714 == nil { ifn_3715 = lang.IFn_Cast(root_3713) } else { ifn_3715 = nil }; var arg_3716 any = sm__10; var arg_3717 any = A_arbace_go_check_A_const_341; if linked_3714 == nil { tmp25 = ifn_3715.Invoke_O_O__O(arg_3716, arg_3717) } else { tmp25 = linked_3714.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3713, arg_3716, arg_3717) }; var tmp26 any = tmp25; var tmp27 any; var root_3718 any = /*line :574:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3718, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3720 lang.IFn; if

	linked_3719 == nil { ifn_3720 = lang.IFn_Cast(root_3718) } else { ifn_3720 = nil }; var arg_3721 any = sm__10; var arg_3722 any = A_arbace_go_check_A_const_342; if linked_3719 == nil { tmp27 = ifn_3720.Invoke_O_O__O(arg_3721, arg_3722) } else { tmp27 = linked_3719.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3718, arg_3721, arg_3722) }; var tmp28 any = tmp27; var tmp29 any = /*line :574:1*/A_arbace_go_check_A_const_207.Invoke_O__O(sm__10); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()); var tmp31 any; var root_3727 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3727, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3729 lang.IFn; if


	linked_3728 == nil { ifn_3729 = lang.IFn_Cast(root_3727) } else { ifn_3729 = nil }; var arg_3730 any = sm__10; var arg_3731 any = A_arbace_go_check_A_const_343; if linked_3728 == nil { tmp31 = ifn_3729.Invoke_O_O__O(arg_3730, arg_3731) } else { tmp31 = linked_3728.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3727, arg_3730, arg_3731) }; var tmp32 any = /*line :574:1*/tmp30.Invoke_O__O(tmp31); var tmp33 any; var root_3732 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3732, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3734 lang.IFn; if



	linked_3733 == nil { ifn_3734 = lang.IFn_Cast(root_3732) } else { ifn_3734 = nil }; var arg_3735 any = sm__10; var arg_3736 any = A_arbace_go_check_A_const_344; if linked_3733 == nil { tmp33 = ifn_3734.Invoke_O_O__O(arg_3735, arg_3736) } else { tmp33 = linked_3733.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3732, arg_3735, arg_3736) }; var tmp34 any = tmp33; var tmp35 any; var root_3737 any = /*line :574:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3737, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3739 lang.IFn; if



	linked_3738 == nil { ifn_3739 = lang.IFn_Cast(root_3737) } else { ifn_3739 = nil }; var arg_3740 any = sm__10; var arg_3741 any = A_arbace_go_check_A_const_345; if linked_3738 == nil { tmp35 = ifn_3739.Invoke_O_O__O(arg_3740, arg_3741) } else { tmp35 = linked_3738.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3737, arg_3740, arg_3741) }; /*line :574:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_14, corpus__0, tmp22, tmp24, tmp26, tmp28, tmp29, tmp32, tmp34, tmp35, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000438__16 any; var root_3742 any = /*line :554:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3744 lang.IFn; if
























	linked_3743 == nil { ifn_3744 = lang.IFn_Cast(root_3742) } else { ifn_3744 = nil }; var arg_3745 any; var root_3746 any = A_arbace_go_check_A_const_346.GetRawRoot__O(); var linked_3747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3746, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3748 lang.IFn; if linked_3747 == nil { ifn_3748 = lang.IFn_Cast(root_3746) } else { ifn_3748 = nil }; var arg_3749 any = A_arbace_go_check_A_const_347; var arg_3750 any; var root_3751 any = A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3751, A_arbace_go_check_report_errors_A_fn_class); var ifn_3753 lang.IFn; if linked_3752 == nil { ifn_3753 = lang.IFn_Cast(root_3751) } else { ifn_3753 = nil }; var arg_3754 any = rs__9; if linked_3752 == nil { arg_3750 = ifn_3753.Invoke_O__O(arg_3754) } else { arg_3750 = linked_3752.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3751, arg_3754) }; if linked_3747 == nil { arg_3745 = ifn_3748.Invoke_O_O__O(arg_3749, arg_3750) } else { arg_3745 = linked_3747.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3746, arg_3749, arg_3750) }; if linked_3743 == nil { seq_1685000438__16 = ifn_3744.Invoke_O__O(arg_3745) } else { seq_1685000438__16 = linked_3743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3742, arg_3745) }; var chunk_1685000439__17 any; var count_1685000440__18 int64 = 0; var i_1685000441__19 int64 = 0; L1:
//line :554:1
	for {
























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000441__19, count_1685000440__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000439__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000441__19)); lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__20); seq_1685000438__16, chunk_1685000439__17, count_1685000440__18, i_1685000441__19 = seq_1685000438__16, chunk_1685000439__17, count_1685000440__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000441__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_3755 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3755, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3757 lang.IFn; if linked_3756 == nil { ifn_3757 = lang.IFn_Cast(root_3755) } else { ifn_3757 = nil }; var arg_3758 any = seq_1685000438__16; if linked_3756 == nil { temp__1927000414__auto____20 = ifn_3757.Invoke_O__O(arg_3758) } else { temp__1927000414__auto____20 = linked_3756.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3755, arg_3758) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000438__21 any = temp__1927000414__auto____20; var tmp36 any; var root_3759 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3759, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3761 lang.IFn; if linked_3760 == nil { ifn_3761 = lang.IFn_Cast(root_3759) } else { ifn_3761 = nil }; var arg_3762 any = seq_1685000438__21; if linked_3760 == nil { tmp36 = ifn_3761.Invoke_O__O(arg_3762) } else { tmp36 = linked_3760.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3759, arg_3762) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____22 any; var root_3763 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3763, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3765 lang.IFn; if linked_3764 == nil { ifn_3765 = lang.IFn_Cast(root_3763) } else { ifn_3765 = nil }; var arg_3766 any = seq_1685000438__21; if linked_3764 == nil { c__1927000678__auto____22 = ifn_3765.Invoke_O__O(arg_3766) } else { c__1927000678__auto____22 = linked_3764.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3763, arg_3766) }; var tmp37 any; var root_3812 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3812, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3814 lang.IFn; if linked_3813 == nil { ifn_3814 = lang.IFn_Cast(root_3812) } else { ifn_3814 = nil }; var arg_3815 any = seq_1685000438__21; if linked_3813 == nil { tmp37 = ifn_3814.Invoke_O__O(arg_3815) } else { tmp37 = linked_3813.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3812, arg_3815) }; seq_1685000438__16, chunk_1685000439__17, count_1685000440__18, i_1685000441__19 = tmp37, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_3767 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3767, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3769 lang.IFn; if linked_3768 == nil { ifn_3769 = lang.IFn_Cast(root_3767) } else { ifn_3769 = nil }; var arg_3770 any = seq_1685000438__21; if linked_3768 == nil { l__22 = ifn_3769.Invoke_O__O(arg_3770) } else { l__22 = linked_3768.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3767, arg_3770) }; lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__22); var tmp38 any; var root_3821 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3823 lang.IFn; if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any = seq_1685000438__21; if linked_3822 == nil { tmp38 = ifn_3823.Invoke_O__O(arg_3824) } else { tmp38 = linked_3822.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3821, arg_3824) }; seq_1685000438__16, chunk_1685000439__17, count_1685000440__18, i_1685000441__19 = tmp38, nil, 0, 0; continue L1 } } }
//line :554:1
		break L1 }; var tmp39 any; var root_3771 any =

























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3773 lang.IFn; if linked_3772 == nil { ifn_3773 = lang.IFn_Cast(root_3771) } else { ifn_3773 = nil }; var arg_3774 any; var root_3775 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3775, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3777 lang.IFn; if linked_3776 == nil { ifn_3777 = lang.IFn_Cast(root_3775) } else { ifn_3777 = nil }; var arg_3778 any = sm__10; var arg_3779 any = A_arbace_go_check_A_const_348; if linked_3776 == nil { arg_3774 = ifn_3777.Invoke_O_O__O(arg_3778, arg_3779) } else { arg_3774 = linked_3776.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3775, arg_3778, arg_3779) }; if linked_3772 == nil { tmp39 = ifn_3773.Invoke_O__O(arg_3774) } else { tmp39 = linked_3772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3771, arg_3774) }; if jrt.J2g_Truth(tmp39) {
		var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()); var tmp42 any; var root_3789 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3789, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3791 lang.IFn; if linked_3790 == nil { ifn_3791 = lang.IFn_Cast(root_3789) } else { ifn_3791 = nil }; var arg_3792 any = sm__10; var arg_3793 any = A_arbace_go_check_A_const_349; if linked_3790 == nil { tmp42 = ifn_3791.Invoke_O_O__O(arg_3792, arg_3793) } else { tmp42 = linked_3790.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3789, arg_3792, arg_3793) }; tmp40.Invoke_O_O__O(Lit_16, tmp41.Invoke_O__O(tmp42)) }; var tmp43 any; var root_3794 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3794, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3796 lang.IFn; if linked_3795 == nil { ifn_3796 = lang.IFn_Cast(root_3794) } else { ifn_3796 = nil }; var arg_3797 any = A_arbace_go_check_A_const_132.Invoke_O__O(sm__10); if linked_3795 == nil { tmp43 = ifn_3796.Invoke_O__O(arg_3797) } else { tmp43 = linked_3795.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3794, arg_3797) }; if jrt.J2g_Truth(tmp43) {
		lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_132.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_3825 any = A_arbace_go_check_A_const_335.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, A_arbace_go_check_write_edn_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any; var root_3830 any = A_arbace_go_check_A_const_328.GetRawRoot__O(); var linked_3831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3830, A_arbace_go_check_reference_path_A_fn_class); var ifn_3832 lang.IFn; if linked_3831 == nil { ifn_3832 = lang.IFn_Cast(root_3830) } else { ifn_3832 = nil }; var arg_3833 any = corpus__0; if linked_3831 == nil { arg_3828 = ifn_3832.Invoke_O__O(arg_3833) } else { arg_3828 = linked_3831.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3830, arg_3833) }; var arg_3829 any; var root_3834 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3835 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3834, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3836 lang.IFn; if linked_3835 == nil { ifn_3836 = lang.IFn_Cast(root_3834) } else { ifn_3836 = nil }; var arg_3837 any; var root_3840 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_3841 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3840, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3842 lang.IFn; if linked_3841 == nil { ifn_3842 = lang.IFn_Cast(root_3840) } else { ifn_3842 = nil }; var arg_3843 any = sm__10; var arg_3844 any = A_arbace_go_check_A_const_296; if linked_3841 == nil { arg_3837 = ifn_3842.Invoke_O_O__O(arg_3843, arg_3844) } else { arg_3837 = linked_3841.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3840, arg_3843, arg_3844) }; var arg_3838 any = A_arbace_go_check_A_const_334; var arg_3839 any = Lit_18; if linked_3835 == nil { arg_3829 = ifn_3836.Invoke_O_O_O__O(arg_3837, arg_3838, arg_3839) } else { arg_3829 = linked_3835.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3834, arg_3837, arg_3838, arg_3839) }; if linked_3826 == nil { ifn_3827.Invoke_O_O__O(arg_3828, arg_3829) } else { linked_3826.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3825, arg_3828, arg_3829) }
		var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp45 any; var root_3850 any = A_arbace_go_check_A_const_328.GetRawRoot__O(); var linked_3851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3850, A_arbace_go_check_reference_path_A_fn_class); var ifn_3852 lang.IFn; if linked_3851 == nil { ifn_3852 = lang.IFn_Cast(root_3850) } else { ifn_3852 = nil }; var arg_3853 any = corpus__0; if linked_3851 == nil { tmp45 = ifn_3852.Invoke_O__O(arg_3853) } else { tmp45 = linked_3851.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3850, arg_3853) }; tmp44.Invoke_O_O__O(Lit_19, tmp45)
//line :584:1
		return clean__14 } else { var tmp46 any; var root_3579 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3581 lang.IFn



			if linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any = clean__14; if linked_3580 == nil { tmp46 = ifn_3581.Invoke_O__O(arg_3582) } else { tmp46 = linked_3580.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3579, arg_3582) }
//line :584:1
			if jrt.J2g_Truth(tmp46) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp48 any; var root_3860 any = A_arbace_go_check_A_const_328.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, A_arbace_go_check_reference_path_A_fn_class); var ifn_3862 lang.IFn; if linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = corpus__0; if linked_3861 == nil { tmp48 = ifn_3862.Invoke_O__O(arg_3863) } else { tmp48 = linked_3861.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3860, arg_3863) }; tmp47.Invoke_O_O_O__O(Lit_20, tmp48, Lit_21)
//line :584:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp49 any; var root_3583 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3583, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3585 lang.IFn





					if linked_3584 == nil { ifn_3585 = lang.IFn_Cast(root_3583) } else { ifn_3585 = nil }; var arg_3586 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_3584 == nil { tmp49 = ifn_3585.Invoke_O__O(arg_3586) } else { tmp49 = linked_3584.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3583, arg_3586) }
//line :584:1
					if jrt.J2g_Truth(tmp49) {





						var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp51 any; var root_3870 any = A_arbace_go_check_A_const_328.GetRawRoot__O(); var linked_3871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3870, A_arbace_go_check_reference_path_A_fn_class); var ifn_3872 lang.IFn; if linked_3871 == nil { ifn_3872 = lang.IFn_Cast(root_3870) } else { ifn_3872 = nil }; var arg_3873 any = corpus__0; if linked_3871 == nil { tmp51 = ifn_3872.Invoke_O__O(arg_3873) } else { tmp51 = linked_3871.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3870, arg_3873) }; tmp50.Invoke_O_O_O__O(Lit_22, tmp51, Lit_23)
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()); var tmp54 any; var root_3883 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_3884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3883, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3885 lang.IFn; if linked_3884 == nil { ifn_3885 = lang.IFn_Cast(root_3883) } else { ifn_3885 = nil }; var arg_3886 any = ref__13; var arg_3887 any = A_arbace_go_check_A_const_334; if linked_3884 == nil { tmp54 = ifn_3885.Invoke_O_O__O(arg_3886, arg_3887) } else { tmp54 = linked_3884.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3883, arg_3886, arg_3887) }; tmp52.Invoke_O_O__O(Lit_24, tmp53.Invoke_O__O(tmp54))
						var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()); var tmp57 any; var root_3897 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_3898 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3897, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3899 lang.IFn; if linked_3898 == nil { ifn_3899 = lang.IFn_Cast(root_3897) } else { ifn_3899 = nil }; var arg_3900 any = sm__10; var arg_3901 any = A_arbace_go_check_A_const_296; if linked_3898 == nil { tmp57 = ifn_3899.Invoke_O_O__O(arg_3900, arg_3901) } else { tmp57 = linked_3898.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3897, arg_3900, arg_3901) }; tmp55.Invoke_O_O__O(Lit_25, tmp56.Invoke_O__O(tmp57))
//line :584:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :573:1
func A_arbace_go_check_annotations_iter__1685000422__1685000428_A_New() *A_arbace_go_check_annotations_iter__1685000422__1685000428_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000422__1685000428_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_A) Invoke_O_O__O(self, s__1685000423__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A_New_O_O(s__1685000423__1, self); var tmp2 *jrt.Class; var fncls__3688 *jrt.Class = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A_fn_class; if fncls__3688 == nil { var fncls__3688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A_fn_class = fncls__3688d; tmp2 = fncls__3688d } else { tmp2 = fncls__3688 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :573:1
func A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A{}; t.Ctor_O_O(p0, p1); return t }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A) Ctor_O_O(c__s__1685000423, c__iter__1685000422 any) { t.F_s__1685000423 = c__s__1685000423; t.F_iter__1685000422 = c__iter__1685000422 }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A) Invoke_O__O(self any) any { { var s__1685000423__1 any; var t_ any = t.F_s__1685000423; t.F_s__1685000423 = nil; s__1685000423__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3604 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3606 lang.IFn; if linked_3605 == nil { ifn_3606 = lang.IFn_Cast(root_3604) } else { ifn_3606 = nil }; var arg_3607 any = s__1685000423__1; if linked_3605 == nil { temp__1927000414__auto____2 = ifn_3606.Invoke_O__O(arg_3607) } else { temp__1927000414__auto____2 = linked_3605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3604, arg_3607) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3608 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = xs__1927001018__auto____3; if linked_3609 == nil { r__4 = ifn_3610.Invoke_O__O(arg_3611) } else { r__4 = linked_3609.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3608, arg_3611) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3670 *jrt.Class = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A_fn_class; if fncls__3670 == nil { var fncls__3670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A_fn_class = fncls__3670d; tmp2 = fncls__3670d } else { tmp2 = fncls__3670 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3671 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3671, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3673 lang.IFn; if linked_3672 == nil { ifn_3673 = lang.IFn_Cast(root_3671) } else { ifn_3673 = nil }; var arg_3674 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_154.Invoke_O__O(r__4)); if linked_3672 == nil { fs__1927001036__auto____6 = ifn_3673.Invoke_O__O(arg_3674) } else { fs__1927001036__auto____6 = linked_3672.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3671, arg_3674) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3675 any = A_arbace_go_check_A_const_286.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3677 lang.IFn; if linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any = fs__1927001036__auto____6; var arg_3679 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000422); var tmp4 any; var root_3680 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3680, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3682 lang.IFn; if linked_3681 == nil { ifn_3682 = lang.IFn_Cast(root_3680) } else { ifn_3682 = nil }; var arg_3683 any = s__1685000423__1; if linked_3681 == nil { tmp4 = ifn_3682.Invoke_O__O(arg_3683) } else { tmp4 = linked_3681.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3680, arg_3683) }; arg_3679 = tmp3.Invoke_O__O(tmp4); if linked_3676 == nil { return ifn_3677.Invoke_O_O__O(arg_3678, arg_3679) } else { return linked_3676.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3675, arg_3678, arg_3679) } } else { var tmp5 any; var root_3684 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3684, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3686 lang.IFn; if linked_3685 == nil { ifn_3686 = lang.IFn_Cast(root_3684) } else { ifn_3686 = nil }; var arg_3687 any = s__1685000423__1; if linked_3685 == nil { tmp5 = ifn_3686.Invoke_O__O(arg_3687) } else { tmp5 = linked_3685.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3684, arg_3687) }; s__1685000423__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :573:1
func A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A{}; t.Ctor_O(p0); return t }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A) Invoke_O_O__O(self, s__1685000425__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A_New_O_O_O(self, t.F_r, s__1685000425__1); var tmp2 *jrt.Class; var fncls__3669 *jrt.Class = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A_fn_class; if fncls__3669 == nil { var fncls__3669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A_fn_class = fncls__3669d; tmp2 = fncls__3669d } else { tmp2 = fncls__3669 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :573:1
func A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A) Ctor_O_O_O(c__iter__1685000424, c__r, c__s__1685000425 any) { t.F_iter__1685000424 = c__iter__1685000424; t.F_r = c__r; t.F_s__1685000425 = c__s__1685000425 }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A) Invoke_O__O(self any) any { { var s__1685000425__1 any; var t_ any = t.F_s__1685000425; t.F_s__1685000425 = nil; s__1685000425__1 = t_; for { var temp__1927000414__auto____2 any; var root_3612 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3612, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3614 lang.IFn; if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = s__1685000425__1; if linked_3613 == nil { temp__1927000414__auto____2 = ifn_3614.Invoke_O__O(arg_3615) } else { temp__1927000414__auto____2 = linked_3613.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3612, arg_3615) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000425__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3616 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3616, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3618 lang.IFn; if linked_3617 == nil { ifn_3618 = lang.IFn_Cast(root_3616) } else { ifn_3618 = nil }; var arg_3619 any = s__1685000425__3; if linked_3617 == nil { tmp1 = ifn_3618.Invoke_O__O(arg_3619) } else { tmp1 = linked_3617.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3616, arg_3619) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3620 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3620, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3622 lang.IFn; if linked_3621 == nil { ifn_3622 = lang.IFn_Cast(root_3620) } else { ifn_3622 = nil }; var arg_3623 any = s__1685000425__3; if linked_3621 == nil { c__1927001037__auto____4 = ifn_3622.Invoke_O__O(arg_3623) } else { c__1927001037__auto____4 = linked_3621.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3620, arg_3623) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000427__6 any; var root_3624 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3624, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3626 lang.IFn; if linked_3625 == nil { ifn_3626 = lang.IFn_Cast(root_3624) } else { ifn_3626 = nil }; var arg_3627 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3625 == nil { b__1685000427__6 = ifn_3626.Invoke_O__O(arg_3627) } else { b__1685000427__6 = linked_3625.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3624, arg_3627) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A_New_O_O_I_O(b__1685000427__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3633 *jrt.Class = A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A_fn_class; if fncls__3633 == nil { var fncls__3633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A_fn_class = fncls__3633d; tmp3 = fncls__3633d } else { tmp3 = fncls__3633 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3634 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3634, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3636 lang.IFn; if linked_3635 == nil { ifn_3636 = lang.IFn_Cast(root_3634) } else { ifn_3636 = nil }; var arg_3637 any; var root_3639 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3641 lang.IFn; if linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; var arg_3642 any = b__1685000427__6; if linked_3640 == nil { arg_3637 = ifn_3641.Invoke_O__O(arg_3642) } else { arg_3637 = linked_3640.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3639, arg_3642) }; var arg_3638 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000424); var tmp5 any; var root_3643 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3645 lang.IFn; if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = s__1685000425__3; if linked_3644 == nil { tmp5 = ifn_3645.Invoke_O__O(arg_3646) } else { tmp5 = linked_3644.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3643, arg_3646) }; arg_3638 = tmp4.Invoke_O__O(tmp5); if linked_3635 == nil { return ifn_3636.Invoke_O_O__O(arg_3637, arg_3638) } else { return linked_3635.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3634, arg_3637, arg_3638) } } else { var root_3647 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3649 lang.IFn; if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any; var root_3652 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3652, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3654 lang.IFn; if linked_3653 == nil { ifn_3654 = lang.IFn_Cast(root_3652) } else { ifn_3654 = nil }; var arg_3655 any = b__1685000427__6; if linked_3653 == nil { arg_3650 = ifn_3654.Invoke_O__O(arg_3655) } else { arg_3650 = linked_3653.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3652, arg_3655) }; var arg_3651 any; if linked_3648 == nil { return ifn_3649.Invoke_O_O__O(arg_3650, arg_3651) } else { return linked_3648.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3647, arg_3650, arg_3651) } } } else { var u__4 any; var root_3656 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3656, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3658 lang.IFn; if linked_3657 == nil { ifn_3658 = lang.IFn_Cast(root_3656) } else { ifn_3658 = nil }; var arg_3659 any = s__1685000425__3; if linked_3657 == nil { u__4 = ifn_3658.Invoke_O__O(arg_3659) } else { u__4 = linked_3657.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3656, arg_3659) }; var root_3660 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3660, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3662 lang.IFn; if linked_3661 == nil { ifn_3662 = lang.IFn_Cast(root_3660) } else { ifn_3662 = nil }; var arg_3663 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), u__4); var arg_3664 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000424); var tmp7 any; var root_3665 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3665, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3667 lang.IFn; if linked_3666 == nil { ifn_3667 = lang.IFn_Cast(root_3665) } else { ifn_3667 = nil }; var arg_3668 any = s__1685000425__3; if linked_3666 == nil { tmp7 = ifn_3667.Invoke_O__O(arg_3668) } else { tmp7 = linked_3666.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3665, arg_3668) }; arg_3664 = tmp6.Invoke_O__O(tmp7); if linked_3661 == nil { return ifn_3662.Invoke_O_O__O(arg_3663, arg_3664) } else { return linked_3661.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3660, arg_3663, arg_3664) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :573:1
func A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A) Ctor_O_O_I_O(c__b__1685000427, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000427 = c__b__1685000427; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :573:1
func (t *A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A) Invoke_O__O(self any) any { { var i__1685000426__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000426__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000426__1)); var root_3628 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3628, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3630 lang.IFn; if linked_3629 == nil { ifn_3630 = lang.IFn_Cast(root_3628) } else { ifn_3630 = nil }; var arg_3631 any = t.F_b__1685000427; var arg_3632 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), u__2); if linked_3629 == nil { ifn_3630.Invoke_O_O__O(arg_3631, arg_3632) } else { linked_3629.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3628, arg_3631, arg_3632) }; i__1685000426__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000426__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :596:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000443__2 any = args__0; var seq__1685000444__3 any; var root_3902 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3904 lang.IFn; if


	linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = vec__1685000443__2; if linked_3903 == nil { seq__1685000444__3 = ifn_3904.Invoke_O__O(arg_3905) } else { seq__1685000444__3 = linked_3903.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3902, arg_3905) }; var first__1685000445__4 any; var root_3906 any = /*line :596:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3908 lang.IFn; if


	linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any = seq__1685000444__3; if linked_3907 == nil { first__1685000445__4 = ifn_3908.Invoke_O__O(arg_3909) } else { first__1685000445__4 = linked_3907.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3906, arg_3909) }; var seq__1685000444__5 any; var root_3910 any = /*line :596:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3910, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3912 lang.IFn; if


	linked_3911 == nil { ifn_3912 = lang.IFn_Cast(root_3910) } else { ifn_3912 = nil }; var arg_3913 any = seq__1685000444__3; if linked_3911 == nil { seq__1685000444__5 = ifn_3912.Invoke_O__O(arg_3913) } else { seq__1685000444__5 = linked_3911.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3910, arg_3913) }; var cmd__6 any = first__1685000445__4; var args__7 any = seq__1685000444__5; var G__1685000446__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000446__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000446__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000447_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__3977 /*line :600:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000447_A_fn_class

		if fncls__3977 == nil { var fncls__3977d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000447_A_fn_class = fncls__3977d; tmp2 = fncls__3977d } else { tmp2 = fncls__3977 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :600:1
		var cs__10 any; var tmp3 any; var root_3978 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3978, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3980 lang.IFn









		if linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; var arg_3981 any = A_arbace_go_check_A_const_351.Invoke_O__O(opts__9); if linked_3979 == nil { tmp3 = ifn_3980.Invoke_O__O(arg_3981) } else { tmp3 = linked_3979.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3978, arg_3981) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_351.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_354.GetRawRoot__O() }
//line :600:1
		var ok__11 any; var root_3982 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_3983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3982, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3984 lang.IFn










		if linked_3983 == nil { ifn_3984 = lang.IFn_Cast(root_3982) } else { ifn_3984 = nil }; var arg_3985 any; var iter__1927001039__auto____11 any; var tmp4 any = A_arbace_go_check__main_iter__1685000450__1685000454_A_New_O(opts__9); var tmp5 *jrt.Class; var fncls__4054 *jrt.Class = A_arbace_go_check__main_iter__1685000450__1685000454_A_fn_class; if fncls__4054 == nil { var fncls__4054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_iter__1685000450__1685000454_A_fn_class = fncls__4054d; tmp5 = fncls__4054d } else { tmp5 = fncls__4054 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_3985 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(cs__10); if linked_3983 == nil { ok__11 = ifn_3984.Invoke_O__O(arg_3985) } else { ok__11 = linked_3983.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3982, arg_3985) }
		var root_4060 any = A_arbace_go_check_A_const_358.GetRawRoot__O(); var linked_4061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4060, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4062 lang.IFn; if linked_4061 == nil { ifn_4062 = lang.IFn_Cast(root_4060) } else { ifn_4062 = nil }; if linked_4061 == nil { ifn_4062.Invoke__O() } else { linked_4061.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4060) }
		var tmp6 int64; var tmp7 any; var root_4055 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_4056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4055, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4057 lang.IFn; if linked_4056 == nil { ifn_4057 = lang.IFn_Cast(root_4055) } else { ifn_4057 = nil }; var arg_4058 any = A_arbace_go_check_A_const_357.GetRawRoot__O(); var arg_4059 any = ok__11; if linked_4056 == nil { tmp7 = ifn_4057.Invoke_O_O__O(arg_4058, arg_4059) } else { tmp7 = linked_4056.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4055, arg_4058, arg_4059) }; if jrt.J2g_Truth(tmp7) { tmp6 = 0 } else { tmp6 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp6)); return nil }
//line :600:1
	default:};













	lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :602:1
func A_arbace_go_check__main_fn__1685000447_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000447_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000447_A{}; t.Ctor_O(p0); return t }
//line :602:1
func (t *A_arbace_go_check__main_fn__1685000447_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :602:1
func (t *A_arbace_go_check__main_fn__1685000447_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_322; var tmp2 any = A_arbace_go_check_A_const_350; var tmp3 any = A_arbace_go_check_A_const_324; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_351, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_3915 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3915, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3917 lang.IFn; if linked_3916 == nil { ifn_3917 = lang.IFn_Cast(root_3915) } else { ifn_3917 = nil }; var arg_3918 any = as__1; if linked_3916 == nil { tmp4 = ifn_3917.Invoke_O__O(arg_3918) } else { tmp4 = linked_3916.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3915, arg_3918) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000448__3_ any; var root_3919 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3919, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3921 lang.IFn

		if linked_3920 == nil { ifn_3921 = lang.IFn_Cast(root_3919) } else { ifn_3921 = nil }; var arg_3922 any = as__1; if linked_3920 == nil { G__1685000448__3_ = ifn_3921.Invoke_O__O(arg_3922) } else { G__1685000448__3_ = linked_3920.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3919, arg_3922) }; switch lang.Util_Hash_O__I_NoInit(G__1685000448__3_) >> 10 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000448__3_, Lit_6) {

			var tmp5 any; var root_3924 any = A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_3925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3924, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3926 lang.IFn; if linked_3925 == nil { ifn_3926 = lang.IFn_Cast(root_3924) } else { ifn_3926 = nil }; var arg_3927 any = as__1; if linked_3925 == nil { tmp5 = ifn_3926.Invoke_O__O(arg_3927) } else { tmp5 = linked_3925.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3924, arg_3927) }; var tmp6 any = tmp5; var tmp7 any; var root_3928 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3929 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3928, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3930 lang.IFn; if linked_3929 == nil { ifn_3930 = lang.IFn_Cast(root_3928) } else { ifn_3930 = nil }; var arg_3931 any = o__2; var arg_3932 any = A_arbace_go_check_A_const_322; var arg_3933 any; var tmp8 any; var root_3934 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); var linked_3935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3934, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3936 lang.IFn; if linked_3935 == nil { ifn_3936 = lang.IFn_Cast(root_3934) } else { ifn_3936 = nil }; var arg_3937 any = as__1; if linked_3935 == nil { tmp8 = ifn_3936.Invoke_O__O(arg_3937) } else { tmp8 = linked_3935.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3934, arg_3937) }; arg_3933 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp8))).Ref(); if linked_3929 == nil { tmp7 = ifn_3930.Invoke_O_O_O__O(arg_3931, arg_3932, arg_3933) } else { tmp7 = linked_3929.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3928, arg_3931, arg_3932, arg_3933) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :605:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000448__3_, Lit_7) {
			var tmp9 any; var root_3938 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3938, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3940 lang.IFn; if linked_3939 == nil { ifn_3940 = lang.IFn_Cast(root_3938) } else { ifn_3940 = nil }; var arg_3941 any = as__1; if linked_3939 == nil { tmp9 = ifn_3940.Invoke_O__O(arg_3941) } else { tmp9 = linked_3939.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3938, arg_3941) }; var tmp10 any = tmp9; var tmp11 any; var root_3942 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3943 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3942, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3944 lang.IFn; if linked_3943 == nil { ifn_3944 = lang.IFn_Cast(root_3942) } else { ifn_3944 = nil }; var arg_3945 any = o__2; var arg_3946 any = A_arbace_go_check_A_const_323; var arg_3947 any = jrt.Boolean_TRUE.Ref(); if linked_3943 == nil { tmp11 = ifn_3944.Invoke_O_O_O__O(arg_3945, arg_3946, arg_3947) } else { tmp11 = linked_3943.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3942, arg_3945, arg_3946, arg_3947) }; as__1, o__2 = tmp10, tmp11; continue L1 }
//line :605:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000448__3_, Lit_8) {


			var tmp12 any; var root_3948 any = A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_3949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3948, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3950 lang.IFn; if linked_3949 == nil { ifn_3950 = lang.IFn_Cast(root_3948) } else { ifn_3950 = nil }; var arg_3951 any = as__1; if linked_3949 == nil { tmp12 = ifn_3950.Invoke_O__O(arg_3951) } else { tmp12 = linked_3949.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3948, arg_3951) }; var tmp13 any = tmp12; var tmp14 any; var root_3952 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3952, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3954 lang.IFn; if linked_3953 == nil { ifn_3954 = lang.IFn_Cast(root_3952) } else { ifn_3954 = nil }; var arg_3955 any = o__2; var arg_3956 any = A_arbace_go_check_A_const_324; var arg_3957 any; var root_3958 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); var linked_3959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3958, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3960 lang.IFn; if linked_3959 == nil { ifn_3960 = lang.IFn_Cast(root_3958) } else { ifn_3960 = nil }; var arg_3961 any = as__1; if linked_3959 == nil { arg_3957 = ifn_3960.Invoke_O__O(arg_3961) } else { arg_3957 = linked_3959.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3958, arg_3961) }; if linked_3953 == nil { tmp14 = ifn_3954.Invoke_O_O_O__O(arg_3955, arg_3956, arg_3957) } else { tmp14 = linked_3953.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3952, arg_3955, arg_3956, arg_3957) }; as__1, o__2 = tmp13, tmp14; continue L1 }
//line :605:1
		default:
		}


		var tmp15 any; var root_3962 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3962, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3964 lang.IFn; if linked_3963 == nil { ifn_3964 = lang.IFn_Cast(root_3962) } else { ifn_3964 = nil }; var arg_3965 any = as__1; if linked_3963 == nil { tmp15 = ifn_3964.Invoke_O__O(arg_3965) } else { tmp15 = linked_3963.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3962, arg_3965) }; var tmp16 any = tmp15; var tmp17 any; var root_3966 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_3967 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3966, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3968 lang.IFn; if linked_3967 == nil { ifn_3968 = lang.IFn_Cast(root_3966) } else { ifn_3968 = nil }; var arg_3969 any = o__2; var arg_3970 any = A_arbace_go_check_A_const_351; var arg_3971 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_3972 any; var root_3973 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3973, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3975 lang.IFn; if linked_3974 == nil { ifn_3975 = lang.IFn_Cast(root_3973) } else { ifn_3975 = nil }; var arg_3976 any = as__1; if linked_3974 == nil { arg_3972 = ifn_3975.Invoke_O__O(arg_3976) } else { arg_3972 = linked_3974.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3973, arg_3976) }; if linked_3967 == nil { tmp17 = ifn_3968.Invoke_O_O_O_O__O(arg_3969, arg_3970, arg_3971, arg_3972) } else { tmp17 = linked_3967.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3966, arg_3969, arg_3970, arg_3971, arg_3972) }; as__1, o__2 = tmp16, tmp17; continue L1 } } }; /*line :602:1*/panic("j2g: unreachable") }








func A_arbace_go_check__main_iter__1685000450__1685000454_A_New_O(p0 any) *A_arbace_go_check__main_iter__1685000450__1685000454_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000450__1685000454_A{}; t.Ctor_O(p0); return t }
//line :611:1
func (t *A_arbace_go_check__main_iter__1685000450__1685000454_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :611:1
func (t *A_arbace_go_check__main_iter__1685000450__1685000454_A) Invoke_O_O__O(self, s__1685000451__1 any) any { var tmp1 any = A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A_New_O_O_O(s__1685000451__1, t.F_opts, self); var tmp2 *jrt.Class; var fncls__4053 *jrt.Class = A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A_fn_class; if fncls__4053 == nil { var fncls__4053d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A_fn_class = fncls__4053d; tmp2 = fncls__4053d } else { tmp2 = fncls__4053 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :611:1
func A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :611:1
func (t *A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A) Ctor_O_O_O(c__s__1685000451, c__opts, c__iter__1685000450 any) { t.F_s__1685000451 = c__s__1685000451; t.F_opts = c__opts; t.F_iter__1685000450 = c__iter__1685000450 }
//line :611:1
func (t *A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A) Invoke_O__O(self any) any { { var s__1685000451__1 any; var t_ any = t.F_s__1685000451; t.F_s__1685000451 = nil; s__1685000451__1 = t_; for { var temp__1927000414__auto____2 any; var root_3986 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3986, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3988 lang.IFn; if linked_3987 == nil { ifn_3988 = lang.IFn_Cast(root_3986) } else { ifn_3988 = nil }; var arg_3989 any = s__1685000451__1; if linked_3987 == nil { temp__1927000414__auto____2 = ifn_3988.Invoke_O__O(arg_3989) } else { temp__1927000414__auto____2 = linked_3987.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3986, arg_3989) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000451__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3990 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3990, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3992 lang.IFn; if linked_3991 == nil { ifn_3992 = lang.IFn_Cast(root_3990) } else { ifn_3992 = nil }; var arg_3993 any = s__1685000451__3; if linked_3991 == nil { tmp1 = ifn_3992.Invoke_O__O(arg_3993) } else { tmp1 = linked_3991.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3990, arg_3993) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3994 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = s__1685000451__3; if linked_3995 == nil { c__1927001037__auto____4 = ifn_3996.Invoke_O__O(arg_3997) } else { c__1927001037__auto____4 = linked_3995.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3994, arg_3997) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000453__6 any; var root_3998 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3998, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4000 lang.IFn; if linked_3999 == nil { ifn_4000 = lang.IFn_Cast(root_3998) } else { ifn_4000 = nil }; var arg_4001 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3999 == nil { b__1685000453__6 = ifn_4000.Invoke_O__O(arg_4001) } else { b__1685000453__6 = linked_3999.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3998, arg_4001) }; var tmp2 any = A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A_New_O_O_I_O(b__1685000453__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4012 *jrt.Class = A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A_fn_class; if fncls__4012 == nil { var fncls__4012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A_fn_class = fncls__4012d; tmp3 = fncls__4012d } else { tmp3 = fncls__4012 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4013 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_4014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4013, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4015 lang.IFn; if linked_4014 == nil { ifn_4015 = lang.IFn_Cast(root_4013) } else { ifn_4015 = nil }; var arg_4016 any; var root_4018 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_4019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4018, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4020 lang.IFn; if linked_4019 == nil { ifn_4020 = lang.IFn_Cast(root_4018) } else { ifn_4020 = nil }; var arg_4021 any = b__1685000453__6; if linked_4019 == nil { arg_4016 = ifn_4020.Invoke_O__O(arg_4021) } else { arg_4016 = linked_4019.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4018, arg_4021) }; var arg_4017 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000450); var tmp5 any; var root_4022 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4022, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4024 lang.IFn; if linked_4023 == nil { ifn_4024 = lang.IFn_Cast(root_4022) } else { ifn_4024 = nil }; var arg_4025 any = s__1685000451__3; if linked_4023 == nil { tmp5 = ifn_4024.Invoke_O__O(arg_4025) } else { tmp5 = linked_4023.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4022, arg_4025) }; arg_4017 = tmp4.Invoke_O__O(tmp5); if linked_4014 == nil { return ifn_4015.Invoke_O_O__O(arg_4016, arg_4017) } else { return linked_4014.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4013, arg_4016, arg_4017) } } else { var root_4026 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_4027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4026, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4028 lang.IFn; if linked_4027 == nil { ifn_4028 = lang.IFn_Cast(root_4026) } else { ifn_4028 = nil }; var arg_4029 any; var root_4031 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_4032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4031, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4033 lang.IFn; if linked_4032 == nil { ifn_4033 = lang.IFn_Cast(root_4031) } else { ifn_4033 = nil }; var arg_4034 any = b__1685000453__6; if linked_4032 == nil { arg_4029 = ifn_4033.Invoke_O__O(arg_4034) } else { arg_4029 = linked_4032.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4031, arg_4034) }; var arg_4030 any; if linked_4027 == nil { return ifn_4028.Invoke_O_O__O(arg_4029, arg_4030) } else { return linked_4027.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4026, arg_4029, arg_4030) } } } else { var c__4 any; var root_4035 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4035, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4037 lang.IFn; if linked_4036 == nil { ifn_4037 = lang.IFn_Cast(root_4035) } else { ifn_4037 = nil }; var arg_4038 any = s__1685000451__3; if linked_4036 == nil { c__4 = ifn_4037.Invoke_O__O(arg_4038) } else { c__4 = linked_4036.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4035, arg_4038) }; var root_4039 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_4040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4039, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4041 lang.IFn; if linked_4040 == nil { ifn_4041 = lang.IFn_Cast(root_4039) } else { ifn_4041 = nil }; var arg_4042 any; var root_4044 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_4045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4044, A_arbace_go_check_annotations_A_fn_class); var ifn_4046 lang.IFn; if linked_4045 == nil { ifn_4046 = lang.IFn_Cast(root_4044) } else { ifn_4046 = nil }; var arg_4047 any = c__4; var arg_4048 any = t.F_opts; if linked_4045 == nil { arg_4042 = ifn_4046.Invoke_O_O__O(arg_4047, arg_4048) } else { arg_4042 = linked_4045.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4044, arg_4047, arg_4048) }; var arg_4043 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000450); var tmp7 any; var root_4049 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any = s__1685000451__3; if linked_4050 == nil { tmp7 = ifn_4051.Invoke_O__O(arg_4052) } else { tmp7 = linked_4050.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4049, arg_4052) }; arg_4043 = tmp6.Invoke_O__O(tmp7); if linked_4040 == nil { return ifn_4041.Invoke_O_O__O(arg_4042, arg_4043) } else { return linked_4040.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4039, arg_4042, arg_4043) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :611:1
func A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :611:1
func (t *A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A) Ctor_O_O_I_O(c__b__1685000453, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000453 = c__b__1685000453; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :611:1
func (t *A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A) Invoke_O__O(self any) any { { var i__1685000452__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000452__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000452__1)); var root_4002 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_4003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4002, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4004 lang.IFn; if linked_4003 == nil { ifn_4004 = lang.IFn_Cast(root_4002) } else { ifn_4004 = nil }; var arg_4005 any = t.F_b__1685000453; var arg_4006 any; var root_4007 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_4008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4007, A_arbace_go_check_annotations_A_fn_class); var ifn_4009 lang.IFn; if linked_4008 == nil { ifn_4009 = lang.IFn_Cast(root_4007) } else { ifn_4009 = nil }; var arg_4010 any = c__2; var arg_4011 any = t.F_opts; if linked_4008 == nil { arg_4006 = ifn_4009.Invoke_O_O__O(arg_4010, arg_4011) } else { arg_4006 = linked_4008.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4007, arg_4010, arg_4011) }; if linked_4003 == nil { ifn_4004.Invoke_O_O__O(arg_4005, arg_4006) } else { linked_4003.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4002, arg_4005, arg_4006) }; i__1685000452__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000452__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Keyword

var A_arbace_go_check_A_const_55 *lang.Var

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Keyword

var A_arbace_go_check_A_const_61 *lang.Var

var A_arbace_go_check_A_const_62 *lang.Keyword

var A_arbace_go_check_A_const_63 *lang.Var

var A_arbace_go_check_A_const_64 *lang.Keyword

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Var

var A_arbace_go_check_A_const_67 *lang.Keyword

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Var

var A_arbace_go_check_A_const_73 *lang.Keyword

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Var

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 any

var A_arbace_go_check_A_const_78 *lang.Keyword

var A_arbace_go_check_A_const_79 *lang.Var

var A_arbace_go_check_A_const_80 *lang.Keyword

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Var

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Keyword

var A_arbace_go_check_A_const_90 *lang.Var

var A_arbace_go_check_A_const_91 *lang.Keyword

var A_arbace_go_check_A_const_92 *lang.Var

var A_arbace_go_check_A_const_93 *lang.Keyword

var A_arbace_go_check_A_const_94 any

var A_arbace_go_check_A_const_95 *lang.Keyword

var A_arbace_go_check_A_const_96 *lang.Var

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 any

var A_arbace_go_check_A_const_99 *lang.Keyword

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Var

var A_arbace_go_check_A_const_102 *lang.Keyword

var A_arbace_go_check_A_const_103 *lang.Keyword

var A_arbace_go_check_A_const_104 *lang.Keyword

var A_arbace_go_check_A_const_105 *lang.Keyword

var A_arbace_go_check_A_const_106 *lang.Keyword

var A_arbace_go_check_A_const_107 *lang.Keyword

var A_arbace_go_check_A_const_108 *lang.Keyword

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Var

var A_arbace_go_check_A_const_113 *lang.Var

var A_arbace_go_check_A_const_114 *lang.Keyword

var A_arbace_go_check_A_const_115 *lang.Var

var A_arbace_go_check_A_const_116 *lang.Var

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Var

var A_arbace_go_check_A_const_119 any

var A_arbace_go_check_A_const_120 *lang.Var

var A_arbace_go_check_A_const_121 *lang.Var

var A_arbace_go_check_A_const_122 *lang.Var

var A_arbace_go_check_A_const_123 any

var A_arbace_go_check_A_const_124 any

var A_arbace_go_check_A_const_125 *lang.Var

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Keyword

var A_arbace_go_check_A_const_128 *lang.Keyword

var A_arbace_go_check_A_const_129 any

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Keyword

var A_arbace_go_check_A_const_133 *lang.Keyword

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 *lang.Keyword

var A_arbace_go_check_A_const_138 *lang.Var

var A_arbace_go_check_A_const_139 *lang.Var

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 *lang.Var

var A_arbace_go_check_A_const_142 *lang.Keyword

var A_arbace_go_check_A_const_143 *lang.Keyword

var A_arbace_go_check_A_const_144 *lang.Keyword

var A_arbace_go_check_A_const_145 *lang.Var

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Var

var A_arbace_go_check_A_const_151 *lang.Keyword

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Keyword

var A_arbace_go_check_A_const_154 *lang.Keyword

var A_arbace_go_check_A_const_155 *lang.Var

var A_arbace_go_check_A_const_156 *lang.Var

var A_arbace_go_check_A_const_157 *lang.Var

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Var

var A_arbace_go_check_A_const_164 *lang.Var

var A_arbace_go_check_A_const_165 *lang.Var

var A_arbace_go_check_A_const_166 *lang.Var

var A_arbace_go_check_A_const_167 *lang.Var

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Keyword

var A_arbace_go_check_A_const_185 *lang.Keyword

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Keyword

var A_arbace_go_check_A_const_188 *lang.Keyword

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Keyword

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Keyword

var A_arbace_go_check_A_const_197 *lang.Var

var A_arbace_go_check_A_const_198 *lang.Var

var A_arbace_go_check_A_const_199 *lang.Var

var A_arbace_go_check_A_const_200 *lang.Var

var A_arbace_go_check_A_const_201 *lang.Keyword

var A_arbace_go_check_A_const_202 *lang.Keyword

var A_arbace_go_check_A_const_203 *lang.Keyword

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Var

var A_arbace_go_check_A_const_206 *lang.Keyword

var A_arbace_go_check_A_const_207 *lang.Keyword

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Var

var A_arbace_go_check_A_const_210 *lang.Var

var A_arbace_go_check_A_const_211 *lang.Keyword

var A_arbace_go_check_A_const_212 *lang.Keyword

var A_arbace_go_check_A_const_213 *lang.Keyword

var A_arbace_go_check_A_const_214 *lang.Keyword

var A_arbace_go_check_A_const_215 *lang.Var

var A_arbace_go_check_A_const_216 any

var A_arbace_go_check_A_const_217 any

var A_arbace_go_check_A_const_218 *lang.Keyword

var A_arbace_go_check_A_const_219 *lang.Keyword

var A_arbace_go_check_A_const_220 *lang.Keyword

var A_arbace_go_check_A_const_221 *lang.Keyword

var A_arbace_go_check_A_const_222 *lang.Var

var A_arbace_go_check_A_const_223 *lang.Keyword

var A_arbace_go_check_A_const_224 *lang.Keyword

var A_arbace_go_check_A_const_225 *lang.Keyword

var A_arbace_go_check_A_const_226 *lang.Keyword

var A_arbace_go_check_A_const_227 *lang.Keyword

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Var

var A_arbace_go_check_A_const_230 *lang.Var

var A_arbace_go_check_A_const_231 *lang.Keyword

var A_arbace_go_check_A_const_232 *lang.Var

var A_arbace_go_check_A_const_233 *lang.Var

var A_arbace_go_check_A_const_234 *lang.Keyword

var A_arbace_go_check_A_const_235 *lang.Var

var A_arbace_go_check_A_const_236 *lang.Var

var A_arbace_go_check_A_const_237 *lang.Var

var A_arbace_go_check_A_const_238 any

var A_arbace_go_check_A_const_239 *lang.Keyword

var A_arbace_go_check_A_const_240 *lang.Var

var A_arbace_go_check_A_const_241 *lang.Var

var A_arbace_go_check_A_const_242 *lang.Var

var A_arbace_go_check_A_const_243 *lang.Var

var A_arbace_go_check_A_const_244 *lang.Var

var A_arbace_go_check_A_const_245 *lang.Var

var A_arbace_go_check_A_const_246 *lang.Keyword

var A_arbace_go_check_A_const_247 *lang.Keyword

var A_arbace_go_check_A_const_248 *lang.Var

var A_arbace_go_check_A_const_249 *lang.Keyword

var A_arbace_go_check_A_const_250 *lang.Keyword

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 *lang.Var

var A_arbace_go_check_A_const_253 *lang.Keyword

var A_arbace_go_check_A_const_254 any

var A_arbace_go_check_A_const_255 *lang.Keyword

var A_arbace_go_check_A_const_256 any

var A_arbace_go_check_A_const_257 any

var A_arbace_go_check_A_const_258 any

var A_arbace_go_check_A_const_259 *lang.Keyword

var A_arbace_go_check_A_const_260 *lang.Keyword

var A_arbace_go_check_A_const_261 any

var A_arbace_go_check_A_const_262 *lang.Var

var A_arbace_go_check_A_const_263 *lang.Var

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Var

var A_arbace_go_check_A_const_266 *lang.Var

var A_arbace_go_check_A_const_267 any

var A_arbace_go_check_A_const_268 *lang.Var

var A_arbace_go_check_A_const_269 *lang.Keyword

var A_arbace_go_check_A_const_270 *lang.Keyword

var A_arbace_go_check_A_const_271 *lang.Keyword

var A_arbace_go_check_A_const_272 *lang.Keyword

var A_arbace_go_check_A_const_273 *lang.Var

var A_arbace_go_check_A_const_274 *lang.Var

var A_arbace_go_check_A_const_275 *lang.Var

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Var

var A_arbace_go_check_A_const_278 *lang.Var

var A_arbace_go_check_A_const_279 *lang.Keyword

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Var

var A_arbace_go_check_A_const_283 *lang.Var

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 any

var A_arbace_go_check_A_const_286 *lang.Var

var A_arbace_go_check_A_const_287 any

var A_arbace_go_check_A_const_288 any

var A_arbace_go_check_A_const_289 *lang.Var

var A_arbace_go_check_A_const_290 *lang.Keyword

var A_arbace_go_check_A_const_291 *lang.Keyword

var A_arbace_go_check_A_const_292 *lang.Keyword

var A_arbace_go_check_A_const_293 *lang.Keyword

var A_arbace_go_check_A_const_294 *lang.Keyword

var A_arbace_go_check_A_const_295 *lang.Var

var A_arbace_go_check_A_const_296 *lang.Keyword

var A_arbace_go_check_A_const_297 *lang.Keyword

var A_arbace_go_check_A_const_298 *lang.Var

var A_arbace_go_check_A_const_299 *lang.Keyword

var A_arbace_go_check_A_const_300 any

var A_arbace_go_check_A_const_301 *lang.Keyword

var A_arbace_go_check_A_const_302 *lang.Keyword

var A_arbace_go_check_A_const_303 *lang.Var

var A_arbace_go_check_A_const_304 any

var A_arbace_go_check_A_const_305 any

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 any

var A_arbace_go_check_A_const_309 *lang.Var

var A_arbace_go_check_A_const_310 any

var A_arbace_go_check_A_const_311 *lang.Var

var A_arbace_go_check_A_const_312 *lang.Var

var A_arbace_go_check_A_const_313 *lang.Var

var A_arbace_go_check_A_const_314 *lang.Var

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 *lang.Var

var A_arbace_go_check_A_const_322 *lang.Keyword

var A_arbace_go_check_A_const_323 *lang.Keyword

var A_arbace_go_check_A_const_324 *lang.Keyword

var A_arbace_go_check_A_const_325 *lang.Var

var A_arbace_go_check_A_const_326 *lang.Var

var A_arbace_go_check_A_const_327 *jrt.Class

var A_arbace_go_check_A_const_328 *lang.Var

var A_arbace_go_check_A_const_329 *lang.Var

var A_arbace_go_check_A_const_330 *lang.Var

var A_arbace_go_check_A_const_331 any

var A_arbace_go_check_A_const_332 any

var A_arbace_go_check_A_const_333 any

var A_arbace_go_check_A_const_334 *lang.Keyword

var A_arbace_go_check_A_const_335 *lang.Var

var A_arbace_go_check_A_const_336 *lang.Keyword

var A_arbace_go_check_A_const_337 *lang.Keyword

var A_arbace_go_check_A_const_338 *lang.Var

var A_arbace_go_check_A_const_339 *lang.Var

var A_arbace_go_check_A_const_340 any

var A_arbace_go_check_A_const_341 any

var A_arbace_go_check_A_const_342 any

var A_arbace_go_check_A_const_343 any

var A_arbace_go_check_A_const_344 any

var A_arbace_go_check_A_const_345 any

var A_arbace_go_check_A_const_346 *lang.Var

var A_arbace_go_check_A_const_347 any

var A_arbace_go_check_A_const_348 any

var A_arbace_go_check_A_const_349 any

var A_arbace_go_check_A_const_350 any

var A_arbace_go_check_A_const_351 *lang.Keyword

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 *lang.Var

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 525); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[166]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[167]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[168]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[169]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[170]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[171]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[172]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[173]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[174]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[175]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[176]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[177]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[178]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[179]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[180]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[181]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[182]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[183]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[184]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[185]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[186]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[187]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[189]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[190]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[191]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[192]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[193]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[194]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[195]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[196]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[200]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[203] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[204]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[205]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[207]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[208]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[209]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[213]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[214]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[215]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[216]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[220]); A_arbace_go_check_A_const_55 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[221]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[223]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[224]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[226]); A_arbace_go_check_A_const_61 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[228]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[231]); A_arbace_go_check_A_const_66 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[232]); A_arbace_go_check_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[233]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_72 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[240]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_77 = A_arbace_go_check_A_const_pool.A[243]; A_arbace_go_check_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_79 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[245]); A_arbace_go_check_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_86 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[252]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_90 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[257]); A_arbace_go_check_A_const_92 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[259]); A_arbace_go_check_A_const_94 = A_arbace_go_check_A_const_pool.A[260]; A_arbace_go_check_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_96 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_98 = A_arbace_go_check_A_const_pool.A[264] }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_101 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_102 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[269]); A_arbace_go_check_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[276]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_112 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_113 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_115 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[281]); A_arbace_go_check_A_const_116 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[282]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[283]); A_arbace_go_check_A_const_118 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_119 = A_arbace_go_check_A_const_pool.A[285]; A_arbace_go_check_A_const_120 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_121 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_122 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[288]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = A_arbace_go_check_A_const_pool.A[289]; A_arbace_go_check_A_const_124 = A_arbace_go_check_A_const_pool.A[290]; A_arbace_go_check_A_const_125 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]); A_arbace_go_check_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_129 = A_arbace_go_check_A_const_pool.A[295]; A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_132 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_133 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[300]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_137 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_138 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_139 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[305]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_141 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_142 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_144 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_145 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[312]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_150 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[316]); A_arbace_go_check_A_const_151 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[317]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_153 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[319]); A_arbace_go_check_A_const_154 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[320]); A_arbace_go_check_A_const_155 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[321]); A_arbace_go_check_A_const_156 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_157 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[324]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_163 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[329]); A_arbace_go_check_A_const_164 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_165 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_166 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_167 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[336]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[348]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_184 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_185 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_187 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[353]); A_arbace_go_check_A_const_188 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_191 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_196 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_197 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_198 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_199 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]); A_arbace_go_check_A_const_200 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_201 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_202 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_203 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_205 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_206 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[372]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_209 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_210 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_211 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[377]); A_arbace_go_check_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_215 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_216 = A_arbace_go_check_A_const_pool.A[382]; A_arbace_go_check_A_const_217 = A_arbace_go_check_A_const_pool.A[383]; A_arbace_go_check_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[384]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_221 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_222 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_223 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[389]); A_arbace_go_check_A_const_224 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_229 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_230 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_232 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_233 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_235 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[401]); A_arbace_go_check_A_const_236 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_237 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_238 = A_arbace_go_check_A_const_pool.A[404]; A_arbace_go_check_A_const_239 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_240 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_241 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_242 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[408]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_244 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_245 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_246 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_247 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[413]); A_arbace_go_check_A_const_248 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_249 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_252 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_253 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_254 = A_arbace_go_check_A_const_pool.A[420] }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_255 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_256 = A_arbace_go_check_A_const_pool.A[422]; A_arbace_go_check_A_const_257 = A_arbace_go_check_A_const_pool.A[423]; A_arbace_go_check_A_const_258 = A_arbace_go_check_A_const_pool.A[424]; A_arbace_go_check_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[425]); A_arbace_go_check_A_const_260 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_261 = A_arbace_go_check_A_const_pool.A[427]; A_arbace_go_check_A_const_262 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[428]); A_arbace_go_check_A_const_263 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[429]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[430]); A_arbace_go_check_A_const_265 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_266 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_267 = A_arbace_go_check_A_const_pool.A[433] }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_269 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[435]); A_arbace_go_check_A_const_270 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[436]); A_arbace_go_check_A_const_271 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_272 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]); A_arbace_go_check_A_const_273 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_274 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_275 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_277 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_278 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_279 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[445]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_282 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_283 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]); A_arbace_go_check_A_const_285 = A_arbace_go_check_A_const_pool.A[451]; A_arbace_go_check_A_const_286 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[452]); A_arbace_go_check_A_const_287 = A_arbace_go_check_A_const_pool.A[453]; A_arbace_go_check_A_const_288 = A_arbace_go_check_A_const_pool.A[454]; A_arbace_go_check_A_const_289 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_290 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_291 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[457]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_293 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_294 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_295 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_296 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[462]); A_arbace_go_check_A_const_297 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_298 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_299 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_300 = A_arbace_go_check_A_const_pool.A[466]; A_arbace_go_check_A_const_301 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_302 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_303 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[469]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_304 = A_arbace_go_check_A_const_pool.A[470]; A_arbace_go_check_A_const_305 = A_arbace_go_check_A_const_pool.A[471]; A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[472]); A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[473]); A_arbace_go_check_A_const_308 = A_arbace_go_check_A_const_pool.A[474]; A_arbace_go_check_A_const_309 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[475]); A_arbace_go_check_A_const_310 = A_arbace_go_check_A_const_pool.A[476]; A_arbace_go_check_A_const_311 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[477]); A_arbace_go_check_A_const_312 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[478]); A_arbace_go_check_A_const_313 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[479]); A_arbace_go_check_A_const_314 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[480]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[481]); A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[482]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[483]); A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[484]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[486]); A_arbace_go_check_A_const_321 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[487]); A_arbace_go_check_A_const_322 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[488]); A_arbace_go_check_A_const_323 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_324 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_325 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_326 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_327 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_328 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[494]) }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_329 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[495]); A_arbace_go_check_A_const_330 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_331 = A_arbace_go_check_A_const_pool.A[497]; A_arbace_go_check_A_const_332 = A_arbace_go_check_A_const_pool.A[498]; A_arbace_go_check_A_const_333 = A_arbace_go_check_A_const_pool.A[499]; A_arbace_go_check_A_const_334 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[500]); A_arbace_go_check_A_const_335 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_336 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_337 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_338 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_339 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_340 = A_arbace_go_check_A_const_pool.A[506]; A_arbace_go_check_A_const_341 = A_arbace_go_check_A_const_pool.A[507] }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = A_arbace_go_check_A_const_pool.A[508]; A_arbace_go_check_A_const_343 = A_arbace_go_check_A_const_pool.A[509]; A_arbace_go_check_A_const_344 = A_arbace_go_check_A_const_pool.A[510]; A_arbace_go_check_A_const_345 = A_arbace_go_check_A_const_pool.A[511]; A_arbace_go_check_A_const_346 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[512]); A_arbace_go_check_A_const_347 = A_arbace_go_check_A_const_pool.A[513]; A_arbace_go_check_A_const_348 = A_arbace_go_check_A_const_pool.A[514]; A_arbace_go_check_A_const_349 = A_arbace_go_check_A_const_pool.A[515]; A_arbace_go_check_A_const_350 = A_arbace_go_check_A_const_pool.A[516]; A_arbace_go_check_A_const_351 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_353 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[521]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[522]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[523]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[524]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000447_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000447_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000450__1685000454_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_iter__1685000450__1685000454_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A struct{ j2g_header uint64; F_s__1685000451, F_opts, F_iter__1685000450 any }

var A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A struct{ j2g_header uint64; F_b__1685000453, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_iter__1685000450__1685000454_fn__1685000455_fn__1685000456_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000422__1685000428_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000422__1685000428_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A struct{ j2g_header uint64; F_s__1685000423, F_iter__1685000422 any }

var A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A struct{ j2g_header uint64; F_iter__1685000424, F_r, F_s__1685000425 any }

var A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A struct{ j2g_header uint64; F_b__1685000427, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_annotations_iter__1685000422__1685000428_fn__1685000429_iter__1685000424__1685000430_fn__1685000431_fn__1685000432_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000302_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000302_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000306_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000306_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000316_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000330_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000316_fn__1685000332_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A struct{ j2g_header uint64; F_s__1685000321, F_iter__1685000320 any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A struct{ j2g_header uint64; F_b__1685000323 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000320__1685000324_fn__1685000325_fn__1685000326_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts, F_s__1685000335, F_iter__1685000334 any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A struct{ j2g_header uint64; F_dir, F_b__1685000337, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000340_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000316_iter__1685000334__1685000338_fn__1685000339_fn__1685000350_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000292__1685000296_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A struct{ j2g_header uint64; F_s__1685000293, F_iter__1685000292 any }

var A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1685000295, F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_iter__1685000292__1685000296_fn__1685000297_fn__1685000298_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000100_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000100_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000102_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000102_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000138_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000138_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000145_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000145_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000152_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000152_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000162_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000162_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000164_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000164_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000182_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000182_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000184_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000184_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000190_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000193_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000197_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000199_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000201_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000203_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000205_fn__1685000206_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000225_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000227_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000229_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000193_fn__1685000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A struct{ j2g_header uint64; F_iter__1685000209, F_s__1685000210, F_verified any }

var A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A struct{ j2g_header uint64; F_b__1685000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1685000193_iter__1685000209__1685000213_fn__1685000214_fn__1685000215_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000238_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000238_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000174_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000174_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000174_one__1685000175_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000240__1685000244_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000240__1685000244_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A struct{ j2g_header uint64; F_s__1685000241, F_iter__1685000240 any }

var A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000243 any }

var A_arbace_go_check_check_package_iter__1685000240__1685000244_fn__1685000245_fn__1685000246_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000178_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000178_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000178_fn__1685000179_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000256_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000256_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000399_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000399_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000401__1685000405_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000401__1685000405_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A struct{ j2g_header uint64; F_s__1685000402, F_iter__1685000401 any }

var A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A struct{ j2g_header uint64; F_b__1685000404 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000401__1685000405_fn__1685000406_fn__1685000407_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000379__1685000385_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000379__1685000385_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A struct{ j2g_header uint64; F_s__1685000380, F_iter__1685000379 any }

var A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A struct{ j2g_header uint64; F_r, F_s__1685000382, F_iter__1685000381 any }

var A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_b__1685000384, F_c__1927001037__auto__ any }

var A_arbace_go_check_report_errors_iter__1685000379__1685000385_fn__1685000386_iter__1685000381__1685000387_fn__1685000388_fn__1685000389_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000253_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000253_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000270__1685000274_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A struct{ j2g_header uint64; F_f, F_out, F_q, F_s__1685000271, F_iter__1685000270, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_b__1685000273, F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000276_fn__1685000277_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000270__1685000274_fn__1685000275_fn__1685000280_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000265_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000265_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000265_fn__1685000266_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000366_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000368_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000368_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000370_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000372_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000372_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000374_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000374_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000376_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000376_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000364_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000364_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000362_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000362_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000415_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000415_A_fn_class *jrt.Class
