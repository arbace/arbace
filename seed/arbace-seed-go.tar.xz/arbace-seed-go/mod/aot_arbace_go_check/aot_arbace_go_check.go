//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_106)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__7, A_arbace_go_check_A_const_54.Invoke_O__O(n__6))).Ref() } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_262 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_go_check_A_const_24; var arg_266 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_268 == nil { tmp2 = ifn_269.Invoke_O__O(arg_270) } else { tmp2 = linked_268.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_267, arg_270) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_271 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_275 any = Lit_143; var arg_276 any; var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_280 == nil { arg_276 = ifn_281.Invoke_O__O(arg_282) } else { arg_276 = linked_280.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_279, arg_282) }; var arg_277 any; var root_283 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_285 lang.IFn
							if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = want__7; if linked_284 == nil { arg_277 = ifn_285.Invoke_O__O(arg_286) } else { arg_277 = linked_284.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_283, arg_286) }
//line :93:1
							var arg_278 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_289 lang.IFn
							if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_288 == nil { arg_278 = ifn_289.Invoke_O__O(arg_290) } else { arg_278 = linked_288.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_287, arg_290) }
//line :93:1
							if linked_272 == nil { ifn_273.Invoke_O_O_O_O_O__O(arg_274, arg_275, arg_276, arg_277, arg_278) } else { linked_272.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_271, arg_274, arg_275, arg_276, arg_277, arg_278) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_291 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_293 lang.IFn
									if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_292 == nil { and__1927000168__auto____11 = ifn_293.Invoke_O__O(arg_294) } else { and__1927000168__auto____11 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_295 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_67; var arg_299 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_300 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); var arg_304 any = Lit_143; var arg_305 any; var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); if linked_309 == nil { arg_305 = ifn_310.Invoke_O__O(arg_311) } else { arg_305 = linked_309.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_308, arg_311) }; var arg_306 any = Lit_144; var arg_307 any; var root_312 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_313 == nil { arg_307 = ifn_314.Invoke_O__O(arg_315) } else { arg_307 = linked_313.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_312, arg_315) }; if linked_301 == nil { ifn_302.Invoke_O_O_O_O_O__O(arg_303, arg_304, arg_305, arg_306, arg_307) } else { linked_301.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_300, arg_303, arg_304, arg_305, arg_306, arg_307) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1685000042__7; if linked_317 == nil { tmp8 = ifn_318.Invoke_O__O(arg_319) } else { tmp8 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_316, arg_319) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__9, A_arbace_go_check_A_const_54.Invoke_O__O(n__8))).Ref() } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_320 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_24; var arg_324 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_321 == nil { ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { linked_321.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_325 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_326 == nil { tmp10 = ifn_327.Invoke_O__O(arg_328) } else { tmp10 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_325, arg_328) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_329 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_333 any = Lit_143; var arg_334 any; var root_337 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_338 == nil { arg_334 = ifn_339.Invoke_O__O(arg_340) } else { arg_334 = linked_338.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_337, arg_340) }; var arg_335 any; var root_341 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_343 lang.IFn
								if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = want__9; if linked_342 == nil { arg_335 = ifn_343.Invoke_O__O(arg_344) } else { arg_335 = linked_342.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_341, arg_344) }
//line :93:1
								var arg_336 any; var root_345 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_347 lang.IFn
								if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_346 == nil { arg_336 = ifn_347.Invoke_O__O(arg_348) } else { arg_336 = linked_346.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_345, arg_348) }
//line :93:1
								if linked_330 == nil { ifn_331.Invoke_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336) } else { linked_330.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_349 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_351 lang.IFn
										if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_350 == nil { and__1927000168__auto____13 = ifn_351.Invoke_O__O(arg_352) } else { and__1927000168__auto____13 = linked_350.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_353 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_go_check_A_const_67; var arg_357 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_354 == nil { tmp11 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp11 = linked_354.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_358 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); var arg_362 any = Lit_143; var arg_363 any; var root_366 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); if linked_367 == nil { arg_363 = ifn_368.Invoke_O__O(arg_369) } else { arg_363 = linked_367.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_366, arg_369) }; var arg_364 any = Lit_144; var arg_365 any; var root_370 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_371 == nil { arg_365 = ifn_372.Invoke_O__O(arg_373) } else { arg_365 = linked_371.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_370, arg_373) }; if linked_359 == nil { ifn_360.Invoke_O_O_O_O_O__O(arg_361, arg_362, arg_363, arg_364, arg_365) } else { linked_359.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_358, arg_361, arg_362, arg_363, arg_364, arg_365) } } }
//line :86:1
				var tmp15 any; var root_374 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1685000042__7; if linked_375 == nil { tmp15 = ifn_376.Invoke_O__O(arg_377) } else { tmp15 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_70; var tmp2 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_71; var tmp4 any; var root_378 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_380 lang.IFn; if
													linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = pkg_scope__0; var arg_382 any = A_arbace_go_check_A_const_73; if linked_379 == nil { tmp4 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp4 = linked_379.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_74; var tmp7 any; var root_383 any = /*line :101:1*/A_arbace_go_check_A_const_75.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_385 lang.IFn; if


	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var or__1927000174__auto____4 any; var root_387 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = fi__1; var arg_391 any = A_arbace_go_check_A_const_77; if linked_388 == nil { or__1927000174__auto____4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { or__1927000174__auto____4 = linked_388.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_386 = or__1927000174__auto____4 } else { arg_386 = A_arbace_go_check_A_const_74.Invoke_O__O(config__2) }; if linked_384 == nil { tmp7 = ifn_385.Invoke_O__O(arg_386) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_384.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_383, arg_386)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_78; var tmp10 any; var root_392 any = /*line :101:1*/A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_394 lang.IFn; if



	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_go_check_A_const_73.Invoke_O__O(fi__1); if linked_393 == nil { tmp10 = ifn_394.Invoke_O__O(arg_395) } else { tmp10 = linked_393.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_392, arg_395) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_80; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_80; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_81.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_82; var tmp16 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_83; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_84; var tmp20 any; var root_396 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_398 lang.IFn; if





	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.PersistentVector_EMPTY.Ref(); if linked_397 == nil { tmp20 = ifn_398.Invoke_O__O(arg_399) } else { tmp20 = linked_397.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_396, arg_399) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_85; var tmp23 any; var root_400 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_402 lang.IFn; if





	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.PersistentVector_EMPTY.Ref(); if linked_401 == nil { tmp23 = ifn_402.Invoke_O__O(arg_403) } else { tmp23 = linked_401.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_400, arg_403) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__502d; tmp1 = fncls__502d } else { tmp1 = fncls__502 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_503 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_A_const_84.Invoke_O__O(fi__0); if linked_508 == nil { arg_506 = ifn_509.Invoke_O__O(arg_510) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_507, arg_510) }; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__561d; tmp3 = fncls__561d } else { tmp3 = fncls__561 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_404 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_406 lang.IFn
	if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = f__1; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_404, arg_407) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_408 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = f__1; if linked_409 == nil { temp__1927000414__auto____2 = ifn_410.Invoke_O__O(arg_411) } else { temp__1927000414__auto____2 = linked_409.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_470 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_472 lang.IFn
			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_go_check_A_const_71.Invoke_O__O(t.F_fi); var arg_474 any = q__3; if linked_471 == nil { temp__1927000414__auto____4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { temp__1927000414__auto____4 = linked_471.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_91; var tmp3 any; var root_475 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_477 lang.IFn
				if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__5; var arg_479 any = A_arbace_go_check_A_const_93; if linked_476 == nil { tmp3 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp3 = linked_476.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_480 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = x__5; var arg_484 any = A_arbace_go_check_A_const_89; var arg_485 any = jrt.Boolean_TRUE.Ref(); if linked_481 == nil { ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp5 any; var root_412 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_414 lang.IFn


			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; if linked_413 == nil { tmp5 = ifn_414.Invoke_O__O(arg_415) } else { tmp5 = linked_413.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_412, arg_415) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_416 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_418 lang.IFn; _ = ___6; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = imp__7; var arg_420 any = A_arbace_go_check_A_const_89; var arg_421 any = jrt.Boolean_TRUE.Ref(); if linked_417 == nil { ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { linked_417.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } } } else {
//line :113:1
				var tmp6 any; var root_422 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_424 lang.IFn




				if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp6 = ifn_424.Invoke_O__O(arg_425) } else { tmp6 = linked_423.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_422, arg_425) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_426 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn




					if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = f__1; if linked_427 == nil { seq_1685000052__2 = ifn_428.Invoke_O__O(arg_429) } else { seq_1685000052__2 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1685000052__2; if linked_431 == nil { temp__1927000414__auto____6 = ifn_432.Invoke_O__O(arg_433) } else { temp__1927000414__auto____6 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1685000052__7; if linked_435 == nil { tmp7 = ifn_436.Invoke_O__O(arg_437) } else { tmp7 = linked_435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_1685000052__7; if linked_439 == nil { c__1927000678__auto____8 = ifn_440.Invoke_O__O(arg_441) } else { c__1927000678__auto____8 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_438, arg_441) }; var tmp8 any; var root_486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1685000052__7; if linked_487 == nil { tmp8 = ifn_488.Invoke_O__O(arg_489) } else { tmp8 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1685000052__7; if linked_443 == nil { x__8 = ifn_444.Invoke_O__O(arg_445) } else { x__8 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_1685000052__7; if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_490, arg_493) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_446 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_448 lang.IFn





							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; if linked_447 == nil { tmp10 = ifn_448.Invoke_O__O(arg_449) } else { tmp10 = linked_447.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_446, arg_449) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_450 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn





								if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = f__1; if linked_451 == nil { seq_1685000056__2 = ifn_452.Invoke_O__O(arg_453) } else { seq_1685000056__2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1685000056__2; if linked_455 == nil { temp__1927000414__auto____6_2 = ifn_456.Invoke_O__O(arg_457) } else { temp__1927000414__auto____6_2 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_458 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1685000056__7; if linked_459 == nil { tmp11 = ifn_460.Invoke_O__O(arg_461) } else { tmp11 = linked_459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_462 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1685000056__7; if linked_463 == nil { c__1927000678__auto____8_2 = ifn_464.Invoke_O__O(arg_465) } else { c__1927000678__auto____8_2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_462, arg_465) }; var tmp12 any; var root_494 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1685000056__7; if linked_495 == nil { tmp12 = ifn_496.Invoke_O__O(arg_497) } else { tmp12 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_466 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1685000056__7; if linked_467 == nil { x__8_2 = ifn_468.Invoke_O__O(arg_469) } else { x__8_2 = linked_467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_466, arg_469) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1685000056__7; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_511 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_513 lang.IFn
		if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = f__1; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp3 any; var root_515 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn
			if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__1; if linked_516 == nil { tmp3 = ifn_517.Invoke_O__O(arg_518) } else { tmp3 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_521 lang.IFn; _ = ___4; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = imp__5; var arg_523 any = A_arbace_go_check_A_const_89; var arg_524 any = jrt.Boolean_TRUE.Ref(); if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_525 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_527 lang.IFn

				if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { or__1927000174__auto____2 = ifn_527.Invoke_O__O(arg_528) } else { or__1927000174__auto____2 = linked_526.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_529 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_529, arg_532) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__1; if linked_534 == nil { seq_1685000065__2 = ifn_535.Invoke_O__O(arg_536) } else { seq_1685000065__2 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1685000065__2; if linked_538 == nil { temp__1927000414__auto____6 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000414__auto____6 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1685000065__7; if linked_542 == nil { tmp5 = ifn_543.Invoke_O__O(arg_544) } else { tmp5 = linked_542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_541, arg_544) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = seq_1685000065__7; if linked_546 == nil { c__1927000678__auto____8 = ifn_547.Invoke_O__O(arg_548) } else { c__1927000678__auto____8 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_545, arg_548) }; var tmp6 any; var root_553 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = seq_1685000065__7; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1685000065__7; if linked_550 == nil { x__8 = ifn_551.Invoke_O__O(arg_552) } else { x__8 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_557 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1685000065__7; if linked_558 == nil { tmp7 = ifn_559.Invoke_O__O(arg_560) } else { tmp7 = linked_558.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_557, arg_560) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_98); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp6 any; var root_682 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = d__0; if linked_683 == nil { tmp6 = ifn_684.Invoke_O__O(arg_685) } else { tmp6 = linked_683.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_99; var tmp8 any; var root_674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { tmp8 = ifn_676.Invoke_O__O(arg_677) } else { tmp8 = linked_675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_674, arg_677) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp10 any; var root_678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = d__0; if linked_679 == nil { tmp10 = ifn_680.Invoke_O__O(arg_681) } else { tmp10 = linked_679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_678, arg_681) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_564 lang.IFn
		if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = f__1; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_566 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = f__1; if linked_567 == nil { tmp2 = ifn_568.Invoke_O__O(arg_569) } else { tmp2 = linked_567.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_566, arg_569) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_572 lang.IFn

			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = t.F_pkg_scope; var arg_574 any; var root_575 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = f__1; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_575, arg_578) }; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_94); var tmp4 any; var root_634 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_636 lang.IFn
				if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__3; var arg_638 any = A_arbace_go_check_A_const_93; if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp4 = linked_635.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_579 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_583 any = A_arbace_go_check_A_const_95; var arg_584 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_585 any = x__3; if linked_580 == nil { tmp6 = ifn_581.Invoke_O_O_O_O__O(arg_582, arg_583, arg_584, arg_585) } else { tmp6 = linked_580.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_579, arg_582, arg_583, arg_584, arg_585) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_586 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_588 lang.IFn




								if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = f__1; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_586, arg_589) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_639 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_641 lang.IFn




									if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = f__1; if linked_640 == nil { temp__1927000414__auto____2_2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2_2 = linked_640.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_643 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_645 lang.IFn
										if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = h__3; var arg_647 any = Lit_124; if linked_644 == nil { and__1927000168__auto____4 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { and__1927000168__auto____4 = linked_644.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_648 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = h__3; var arg_656 any = Lit_142; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { and__1927000168__auto____5 = ifn_650.Invoke_O__O(arg_651) } else { and__1927000168__auto____5 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn








									if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { seq_1685000072__2 = ifn_592.Invoke_O__O(arg_593) } else { seq_1685000072__2 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_1685000072__2; if linked_595 == nil { temp__1927000414__auto____6 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____6 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_1685000072__7; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_1685000072__7; if linked_603 == nil { c__1927000678__auto____8 = ifn_604.Invoke_O__O(arg_605) } else { c__1927000678__auto____8 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_602, arg_605) }; var tmp10 any; var root_657 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1685000072__7; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_657, arg_660) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1685000072__7; if linked_607 == nil { x__8 = ifn_608.Invoke_O__O(arg_609) } else { x__8 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_661 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1685000072__7; if linked_662 == nil { tmp11 = ifn_663.Invoke_O__O(arg_664) } else { tmp11 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_610 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_612 lang.IFn









											if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = f__1; if linked_611 == nil { tmp12 = ifn_612.Invoke_O__O(arg_613) } else { tmp12 = linked_611.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_610, arg_613) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_614 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn









												if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = f__1; if linked_615 == nil { seq_1685000076__2 = ifn_616.Invoke_O__O(arg_617) } else { seq_1685000076__2 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_1685000076__2; if linked_619 == nil { temp__1927000414__auto____6_2 = ifn_620.Invoke_O__O(arg_621) } else { temp__1927000414__auto____6_2 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_622 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_1685000076__7; if linked_623 == nil { tmp13 = ifn_624.Invoke_O__O(arg_625) } else { tmp13 = linked_623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_626 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = seq_1685000076__7; if linked_627 == nil { c__1927000678__auto____8_2 = ifn_628.Invoke_O__O(arg_629) } else { c__1927000678__auto____8_2 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any; var root_665 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1685000076__7; if linked_666 == nil { tmp14 = ifn_667.Invoke_O__O(arg_668) } else { tmp14 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_630 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1685000076__7; if linked_631 == nil { x__8_2 = ifn_632.Invoke_O__O(arg_633) } else { x__8_2 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_669 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = seq_1685000076__7; if linked_670 == nil { tmp15 = ifn_671.Invoke_O__O(arg_672) } else { tmp15 = linked_670.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_669, arg_672) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000097__2 any) any { var map__1685000098__4 any = p__1685000097__2; var map__1685000098__5 any; if lang.ISeq_InstanceOf(map__1685000098__4) { var tmp1 any; var root_686 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = map__1685000098__4; if linked_687 == nil { tmp1 = ifn_688.Invoke_O__O(arg_689) } else { tmp1 = linked_687.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_690 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = map__1685000098__4; if linked_691 == nil { tmp2 = ifn_692.Invoke_O__O(arg_693) } else { tmp2 = linked_691.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_690, arg_693) }; map__1685000098__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_694 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = map__1685000098__4; if linked_695 == nil { tmp3 = ifn_696.Invoke_O__O(arg_697) } else { tmp3 = linked_695.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp3) { var root_698 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = map__1685000098__4; if linked_699 == nil { map__1685000098__5 = ifn_700.Invoke_O__O(arg_701) } else { map__1685000098__5 = linked_699.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_698, arg_701) } } else { map__1685000098__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000098__5 = map__1685000098__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000098__5, A_arbace_go_check_A_const_102); var pkg_scope__7 any; var root_702 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_704 lang.IFn; if




	linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var arg_706 any = A_arbace_go_check_A_const_103; if linked_703 == nil { pkg_scope__7 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { pkg_scope__7 = linked_703.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; var pkg__8 any; var root_707 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_709 lang.IFn; if





	linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var tmp4 any = A_arbace_go_check_A_const_104; var tmp5 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_70; var tmp7 any = A_arbace_go_check_A_const_70.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_71; var tmp9 any = A_arbace_go_check_A_const_105; var arg_710 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, A_arbace_go_check_A_const_105.Invoke_O__O(src__0))); if linked_708 == nil { pkg__8 = ifn_709.Invoke_O__O(arg_710) } else { pkg__8 = linked_708.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_707, arg_710) }; var errors__9 any; var root_711 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_713 lang.IFn; if






	linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = lang.PersistentVector_EMPTY.Ref(); if linked_712 == nil { errors__9 = ifn_713.Invoke_O__O(arg_714) } else { errors__9 = linked_712.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_711, arg_714) }; var annotated__10 any; var root_715 any = /*line :151:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_717 lang.IFn; if







	linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = A_arbace_go_check_A_const_81.Invoke_O__O(src__0); var arg_719 any = A_arbace_go_check_A_const_106; if linked_716 == nil { annotated__10 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { annotated__10 = linked_716.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_715, arg_718, arg_719) }; var ctx__11 any; var tmp10 any = A_arbace_go_check_A_const_107; var tmp11 any; var root_720 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_722 lang.IFn; if








	linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = lang.PersistentVector_EMPTY.Ref(); if linked_721 == nil { tmp11 = ifn_722.Invoke_O__O(arg_723) } else { tmp11 = linked_721.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_720, arg_723) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_go_check_A_const_108; var tmp14 any; var root_724 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_726 lang.IFn; if








	linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_725 == nil { tmp14 = ifn_726.Invoke_O__O(arg_727) } else { tmp14 = linked_725.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_724, arg_727) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_109; var tmp17 any; var root_728 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_730 lang.IFn; if








	linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = lang.PersistentVector_EMPTY.Ref(); if linked_729 == nil { tmp17 = ifn_730.Invoke_O__O(arg_731) } else { tmp17 = linked_729.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_728, arg_731) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_110; var tmp20 any; var root_732 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_734 lang.IFn; if








	linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = lang.PersistentVector_EMPTY.Ref(); if linked_733 == nil { tmp20 = ifn_734.Invoke_O__O(arg_735) } else { tmp20 = linked_733.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_732, arg_735) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_111; ctx__11 = /*line :151:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)))); var fis__12 any; var root_736 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_738 lang.IFn; if










	linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var tmp23 any = A_arbace_go_check_check_package_fn__1685000100_A_New_O_O(src__0, pkg_scope__7); var tmp24 *jrt.Class; var fncls__747 *jrt.Class = A_arbace_go_check_check_package_fn__1685000100_A_fn_class; if fncls__747 == nil { var fncls__747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_package_fn__1685000100_A_fn_class = fncls__747d; tmp24 = fncls__747d } else { tmp24 = fncls__747 }; arg_739 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_740 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_737 == nil { fis__12 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { fis__12 = linked_737.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }; var root_1183 any =
	A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp26 any = A_arbace_go_check_A_const_158; var tmp27 any = A_arbace_go_check_A_const_159; var tmp28 any = A_arbace_go_check_A_const_160; var tmp29 any = jrt.IdentityHashMap_New(); var tmp30 any = A_arbace_go_check_A_const_161; var tmp31 any = A_arbace_go_check_A_const_61; var tmp32 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)); var tmp33 any = A_arbace_go_check_A_const_162; var tmp34 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var tmp35 any = A_arbace_go_check_A_const_164; var tmp36 any = A_arbace_go_check_A_const_165.GetRawRoot__O(); var tmp37 any = A_arbace_go_check_A_const_166; var tmp38 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp39 any = A_arbace_go_check_A_const_167; var tmp40 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var tmp41 any = A_arbace_go_check_A_const_169; var tmp42 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var tmp43 any = A_arbace_go_check_A_const_171; var tmp44 any = A_arbace_go_check_check_package_fn__1685000102_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp45 *jrt.Class; var fncls__1191 *jrt.Class = A_arbace_go_check_check_package_fn__1685000102_A_fn_class; if









	fncls__1191 == nil { var fncls__1191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_package_fn__1685000102_A_fn_class = fncls__1191d; tmp45 = fncls__1191d } else { tmp45 = fncls__1191 }; var tmp46 any = /*line :163:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp47 any = A_arbace_go_check_A_const_173; var tmp48 any = A_arbace_go_check_A_const_174.GetRawRoot__O(); var tmp49 any = A_arbace_go_check_A_const_175; var tmp50 any = A_arbace_go_check_A_const_176.GetRawRoot__O(); var tmp51 any = A_arbace_go_check_A_const_177; arg_1186 = tmp25.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp26, pkg__8, tmp27, errors__9, tmp28, tmp29, tmp30, ctx__11, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, A_arbace_go_check_A_const_178.GetRawRoot__O())))); if linked_1184 == nil { ifn_1185.Invoke_O__O(arg_1186) } else { linked_1184.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1183, arg_1186) }; var tmp52 any; tmp252 := /*line :151:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000104__15 any; var root_1192 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1194 lang.IFn


























		if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = fis__12; if linked_1193 == nil { seq_1685000104__15 = ifn_1194.Invoke_O__O(arg_1195) } else { seq_1685000104__15 = linked_1193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1192, arg_1195) }
//line :151:1
		var chunk_1685000105__16 any; var count_1685000106__17 int64 = 0; var i_1685000107__18 int64 = 0; L1: for {


























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000107__18, count_1685000106__17) { var fi__19 any = lang.Indexed_Cast(chunk_1685000105__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000107__18)); var root_1255 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = fi__19; var arg_1259 any = resolve__1; if linked_1256 == nil { ifn_1257.Invoke_O_O__O(arg_1258, arg_1259) } else { linked_1256.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1255, arg_1258, arg_1259) }; seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, i_1685000107__18 = seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000107__18); continue L1 } else { var temp__1927000414__auto____19 any; var root_1196 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq_1685000104__15; if linked_1197 == nil { temp__1927000414__auto____19 = ifn_1198.Invoke_O__O(arg_1199) } else { temp__1927000414__auto____19 = linked_1197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1196, arg_1199) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_1685000104__20 any = temp__1927000414__auto____19; var tmp53 any; var root_1200 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = seq_1685000104__20; if linked_1201 == nil { tmp53 = ifn_1202.Invoke_O__O(arg_1203) } else { tmp53 = linked_1201.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1200, arg_1203) }; if jrt.J2g_Truth(tmp53) { var c__1927000678__auto____21 any; var root_1204 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = seq_1685000104__20; if linked_1205 == nil { c__1927000678__auto____21 = ifn_1206.Invoke_O__O(arg_1207) } else { c__1927000678__auto____21 = linked_1205.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1204, arg_1207) }; var tmp54 any; var root_1260 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = seq_1685000104__20; if linked_1261 == nil { tmp54 = ifn_1262.Invoke_O__O(arg_1263) } else { tmp54 = linked_1261.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1260, arg_1263) }; seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, i_1685000107__18 = tmp54, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__21 any; var root_1208 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = seq_1685000104__20; if linked_1209 == nil { fi__21 = ifn_1210.Invoke_O__O(arg_1211) } else { fi__21 = linked_1209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1208, arg_1211) }; var root_1264 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = fi__21; var arg_1268 any = resolve__1; if linked_1265 == nil { ifn_1266.Invoke_O_O__O(arg_1267, arg_1268) } else { linked_1265.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1264, arg_1267, arg_1268) }; var tmp55 any; var root_1269 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = seq_1685000104__20; if linked_1270 == nil { tmp55 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp55 = linked_1270.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1269, arg_1272) }; seq_1685000104__15, chunk_1685000105__16, count_1685000106__17, i_1685000107__18 = tmp55, nil, 0, 0; continue L1 } } }
//line :151:1
			break L1 }; var seq_1685000108__15 any; var root_1212 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1214 lang.IFn



























		if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = fis__12; if linked_1213 == nil { seq_1685000108__15 = ifn_1214.Invoke_O__O(arg_1215) } else { seq_1685000108__15 = linked_1213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1212, arg_1215) }
//line :151:1
		var chunk_1685000109__16 any; var count_1685000110__17 int64 = 0; var i_1685000111__18 int64 = 0; L2: for {



























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000111__18, count_1685000110__17) { var fi__19_2 any = lang.Indexed_Cast(chunk_1685000109__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000111__18)); var root_1273 any = A_arbace_go_check_A_const_181.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = fi__19_2; if linked_1274 == nil { ifn_1275.Invoke_O__O(arg_1276) } else { linked_1274.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1273, arg_1276) }; seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, i_1685000111__18 = seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000111__18); continue L2 } else { var temp__1927000414__auto____19_2 any; var root_1216 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = seq_1685000108__15; if linked_1217 == nil { temp__1927000414__auto____19_2 = ifn_1218.Invoke_O__O(arg_1219) } else { temp__1927000414__auto____19_2 = linked_1217.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1216, arg_1219) }; if jrt.J2g_Truth(temp__1927000414__auto____19_2) { var seq_1685000108__20 any = temp__1927000414__auto____19_2; var tmp56 any; var root_1220 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = seq_1685000108__20; if linked_1221 == nil { tmp56 = ifn_1222.Invoke_O__O(arg_1223) } else { tmp56 = linked_1221.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1220, arg_1223) }; if jrt.J2g_Truth(tmp56) { var c__1927000678__auto____21_2 any; var root_1224 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = seq_1685000108__20; if linked_1225 == nil { c__1927000678__auto____21_2 = ifn_1226.Invoke_O__O(arg_1227) } else { c__1927000678__auto____21_2 = linked_1225.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1224, arg_1227) }; var tmp57 any; var root_1277 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = seq_1685000108__20; if linked_1278 == nil { tmp57 = ifn_1279.Invoke_O__O(arg_1280) } else { tmp57 = linked_1278.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1277, arg_1280) }; seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, i_1685000111__18 = tmp57, c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__21_2 any; var root_1228 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = seq_1685000108__20; if linked_1229 == nil { fi__21_2 = ifn_1230.Invoke_O__O(arg_1231) } else { fi__21_2 = linked_1229.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1228, arg_1231) }; var root_1281 any = A_arbace_go_check_A_const_181.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = fi__21_2; if linked_1282 == nil { ifn_1283.Invoke_O__O(arg_1284) } else { linked_1282.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1281, arg_1284) }; var tmp58 any; var root_1285 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = seq_1685000108__20; if linked_1286 == nil { tmp58 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp58 = linked_1286.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1285, arg_1288) }; seq_1685000108__15, chunk_1685000109__16, count_1685000110__17, i_1685000111__18 = tmp58, nil, 0, 0; continue L2 } } }
//line :151:1
			break L2 }; var seq_1685000112__15 any; var root_1232 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1234 lang.IFn




























		if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = fis__12; if linked_1233 == nil { seq_1685000112__15 = ifn_1234.Invoke_O__O(arg_1235) } else { seq_1685000112__15 = linked_1233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1232, arg_1235) }
//line :151:1
		var chunk_1685000113__16 any; var count_1685000114__17 int64 = 0; var i_1685000115__18 int64 = 0; L3: for {




























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000115__18, count_1685000114__17) { var fi__19_3 any = lang.Indexed_Cast(chunk_1685000113__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000115__18)); var root_1289 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = fi__19_3; if linked_1290 == nil { ifn_1291.Invoke_O__O(arg_1292) } else { linked_1290.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1289, arg_1292) }; seq_1685000112__15, chunk_1685000113__16, count_1685000114__17, i_1685000115__18 = seq_1685000112__15, chunk_1685000113__16, count_1685000114__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000115__18); continue L3 } else { var temp__1927000414__auto____19_3 any; var root_1236 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = seq_1685000112__15; if linked_1237 == nil { temp__1927000414__auto____19_3 = ifn_1238.Invoke_O__O(arg_1239) } else { temp__1927000414__auto____19_3 = linked_1237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1236, arg_1239) }; if jrt.J2g_Truth(temp__1927000414__auto____19_3) { var seq_1685000112__20 any = temp__1927000414__auto____19_3; var tmp59 any; var root_1240 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = seq_1685000112__20; if linked_1241 == nil { tmp59 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp59 = linked_1241.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1240, arg_1243) }; if jrt.J2g_Truth(tmp59) { var c__1927000678__auto____21_3 any; var root_1244 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = seq_1685000112__20; if linked_1245 == nil { c__1927000678__auto____21_3 = ifn_1246.Invoke_O__O(arg_1247) } else { c__1927000678__auto____21_3 = linked_1245.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1244, arg_1247) }; var tmp60 any; var root_1293 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = seq_1685000112__20; if linked_1294 == nil { tmp60 = ifn_1295.Invoke_O__O(arg_1296) } else { tmp60 = linked_1294.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1293, arg_1296) }; seq_1685000112__15, chunk_1685000113__16, count_1685000114__17, i_1685000115__18 = tmp60, c__1927000678__auto____21_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__21_3 any; var root_1248 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = seq_1685000112__20; if linked_1249 == nil { fi__21_3 = ifn_1250.Invoke_O__O(arg_1251) } else { fi__21_3 = linked_1249.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1248, arg_1251) }; var root_1297 any = A_arbace_go_check_A_const_182.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = fi__21_3; if linked_1298 == nil { ifn_1299.Invoke_O__O(arg_1300) } else { linked_1298.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1297, arg_1300) }; var tmp61 any; var root_1301 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = seq_1685000112__20; if linked_1302 == nil { tmp61 = ifn_1303.Invoke_O__O(arg_1304) } else { tmp61 = linked_1302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1301, arg_1304) }; seq_1685000112__15, chunk_1685000113__16, count_1685000114__17, i_1685000115__18 = tmp61, nil, 0, 0; continue L3 } } }
//line :151:1
			break L3
		}




























		var root_1252 any = A_arbace_go_check_A_const_179.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; if linked_1253 == nil { ifn_1254.Invoke__O() } else { linked_1253.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1252) }
//line :151:1
		var objs__15 any; var root_748 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_750 lang.IFn






























		if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = A_arbace_go_check_A_const_107.Invoke_O__O(ctx__11); if linked_749 == nil { objs__15 = ifn_750.Invoke_O__O(arg_751) } else { objs__15 = linked_749.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_748, arg_751) }
//line :151:1
		var seq_1685000116__16 any; var root_1305 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1307 lang.IFn































		if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any; var root_1309 any = A_arbace_go_check_A_const_183.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var arg_1313 any = objs__15; if linked_1310 == nil { arg_1308 = ifn_1311.Invoke_O_O__O(arg_1312, arg_1313) } else { arg_1308 = linked_1310.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1309, arg_1312, arg_1313) }; if linked_1306 == nil { seq_1685000116__16 = ifn_1307.Invoke_O__O(arg_1308) } else { seq_1685000116__16 = linked_1306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1305, arg_1308) }
//line :151:1
		var chunk_1685000117__17 any; var count_1685000118__18 int64 = 0; var i_1685000119__19 int64 = 0; L4: for {































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000119__19, count_1685000118__18) { var vec__1685000120__20 any = lang.Indexed_Cast(chunk_1685000117__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000119__19)); var i__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000120__20, lang.RT_IntCast_J__I_NoInit(0), nil); var x__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000120__20, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1482 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = x__22; var arg_1486 any = A_arbace_go_check_A_const_186; var arg_1487 any = i__21; if linked_1483 == nil { ifn_1484.Invoke_O_O_O__O(arg_1485, arg_1486, arg_1487) } else { linked_1483.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1482, arg_1485, arg_1486, arg_1487) }; seq_1685000116__16, chunk_1685000117__17, count_1685000118__18, i_1685000119__19 = seq_1685000116__16, chunk_1685000117__17, count_1685000118__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000119__19); continue L4 } else { var temp__1927000414__auto____20 any; var root_1314 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = seq_1685000116__16; if linked_1315 == nil { temp__1927000414__auto____20 = ifn_1316.Invoke_O__O(arg_1317) } else { temp__1927000414__auto____20 = linked_1315.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1314, arg_1317) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000116__21 any = temp__1927000414__auto____20; var tmp62 any; var root_1318 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = seq_1685000116__21; if linked_1319 == nil { tmp62 = ifn_1320.Invoke_O__O(arg_1321) } else { tmp62 = linked_1319.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1318, arg_1321) }; if jrt.J2g_Truth(tmp62) { var c__1927000678__auto____22 any; var root_1322 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = seq_1685000116__21; if linked_1323 == nil { c__1927000678__auto____22 = ifn_1324.Invoke_O__O(arg_1325) } else { c__1927000678__auto____22 = linked_1323.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1322, arg_1325) }; var tmp63 any; var root_1488 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = seq_1685000116__21; if linked_1489 == nil { tmp63 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp63 = linked_1489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1488, arg_1491) }; seq_1685000116__16, chunk_1685000117__17, count_1685000118__18, i_1685000119__19 = tmp63, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1685000123__22 any; var root_1326 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = seq_1685000116__21; if linked_1327 == nil { vec__1685000123__22 = ifn_1328.Invoke_O__O(arg_1329) } else { vec__1685000123__22 = linked_1327.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1326, arg_1329) }; var i__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000123__22, lang.RT_IntCast_J__I_NoInit(0), nil); var x__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000123__22, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1492 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = x__24; var arg_1496 any = A_arbace_go_check_A_const_186; var arg_1497 any = i__23; if linked_1493 == nil { ifn_1494.Invoke_O_O_O__O(arg_1495, arg_1496, arg_1497) } else { linked_1493.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1492, arg_1495, arg_1496, arg_1497) }; var tmp64 any; var root_1498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = seq_1685000116__21; if linked_1499 == nil { tmp64 = ifn_1500.Invoke_O__O(arg_1501) } else { tmp64 = linked_1499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1498, arg_1501) }; seq_1685000116__16, chunk_1685000117__17, count_1685000118__18, i_1685000119__19 = tmp64, nil, 0, 0; continue L4 } } }
//line :151:1
			break L4 }; var seq_1685000126__16 any; var root_1330 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1332 lang.IFn

































		if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = objs__15; if linked_1331 == nil { seq_1685000126__16 = ifn_1332.Invoke_O__O(arg_1333) } else { seq_1685000126__16 = linked_1331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1330, arg_1333) }
//line :151:1
		var chunk_1685000127__17 any; var count_1685000128__18 int64 = 0; var i_1685000129__19 int64 = 0; L5: for {

































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000129__19, count_1685000128__18) { var x__20 any = lang.Indexed_Cast(chunk_1685000127__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000129__19)); var tmp65 any; var and__1927000168__auto____21 bool; var tmp66 any = A_arbace_go_check_A_const_54; var tmp67 any; var root_1334 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = x__20; var arg_1338 any = A_arbace_go_check_A_const_93; if linked_1335 == nil { tmp67 = ifn_1336.Invoke_O_O__O(arg_1337, arg_1338) } else { tmp67 = linked_1335.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1334, arg_1337, arg_1338) }; and__1927000168__auto____21 = lang.Util_Equiv_O_O__Z_NoInit(tmp66, tmp67); if and__1927000168__auto____21 { var root_1339 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any; var root_1343 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = x__20; var arg_1347 any = A_arbace_go_check_A_const_185; if linked_1344 == nil { arg_1342 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { arg_1342 = linked_1344.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; if linked_1340 == nil { tmp65 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp65 = linked_1340.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1339, arg_1342) } } else { tmp65 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }; if jrt.J2g_Truth(tmp65) { var root_1502 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = x__20; if linked_1503 == nil { ifn_1504.Invoke_O__O(arg_1505) } else { linked_1503.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1502, arg_1505) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000129__19); continue L5 } else { seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000129__19); continue L5 } } else { var temp__1927000414__auto____20_2 any; var root_1348 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = seq_1685000126__16; if linked_1349 == nil { temp__1927000414__auto____20_2 = ifn_1350.Invoke_O__O(arg_1351) } else { temp__1927000414__auto____20_2 = linked_1349.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1348, arg_1351) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000126__21 any = temp__1927000414__auto____20_2; var tmp68 any; var root_1352 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = seq_1685000126__21; if linked_1353 == nil { tmp68 = ifn_1354.Invoke_O__O(arg_1355) } else { tmp68 = linked_1353.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1352, arg_1355) }; if jrt.J2g_Truth(tmp68) { var c__1927000678__auto____22_2 any; var root_1356 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = seq_1685000126__21; if linked_1357 == nil { c__1927000678__auto____22_2 = ifn_1358.Invoke_O__O(arg_1359) } else { c__1927000678__auto____22_2 = linked_1357.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1356, arg_1359) }; var tmp69 any; var root_1506 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = seq_1685000126__21; if linked_1507 == nil { tmp69 = ifn_1508.Invoke_O__O(arg_1509) } else { tmp69 = linked_1507.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1506, arg_1509) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = tmp69, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var x__22_2 any; var root_1360 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = seq_1685000126__21; if linked_1361 == nil { x__22_2 = ifn_1362.Invoke_O__O(arg_1363) } else { x__22_2 = linked_1361.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1360, arg_1363) }; var tmp70 any; var and__1927000168__auto____23 bool; var tmp71 any = A_arbace_go_check_A_const_54; var tmp72 any; var root_1364 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = x__22_2; var arg_1368 any = A_arbace_go_check_A_const_93; if linked_1365 == nil { tmp72 = ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { tmp72 = linked_1365.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) }; and__1927000168__auto____23 = lang.Util_Equiv_O_O__Z_NoInit(tmp71, tmp72); if and__1927000168__auto____23 { var root_1369 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any; var root_1373 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = x__22_2; var arg_1377 any = A_arbace_go_check_A_const_185; if linked_1374 == nil { arg_1372 = ifn_1375.Invoke_O_O__O(arg_1376, arg_1377) } else { arg_1372 = linked_1374.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1373, arg_1376, arg_1377) }; if linked_1370 == nil { tmp70 = ifn_1371.Invoke_O__O(arg_1372) } else { tmp70 = linked_1370.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1369, arg_1372) } } else { tmp70 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }; if jrt.J2g_Truth(tmp70) { var root_1510 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = x__22_2; if linked_1511 == nil { ifn_1512.Invoke_O__O(arg_1513) } else { linked_1511.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1510, arg_1513) }; var tmp73 any; var root_1514 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = seq_1685000126__21; if linked_1515 == nil { tmp73 = ifn_1516.Invoke_O__O(arg_1517) } else { tmp73 = linked_1515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1514, arg_1517) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = tmp73, nil, 0, 0; continue L5 } else { var tmp74 any; var root_1518 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = seq_1685000126__21; if linked_1519 == nil { tmp74 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp74 = linked_1519.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1518, arg_1521) }; seq_1685000126__16, chunk_1685000127__17, count_1685000128__18, i_1685000129__19 = tmp74, nil, 0, 0; continue L5 } } } }
//line :151:1
			break L5 }; var seq_1685000130__16 any; var root_1378 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1380 lang.IFn


































		if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = objs__15; if linked_1379 == nil { seq_1685000130__16 = ifn_1380.Invoke_O__O(arg_1381) } else { seq_1685000130__16 = linked_1379.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1378, arg_1381) }
//line :151:1
		var chunk_1685000131__17 any; var count_1685000132__18 int64 = 0; var i_1685000133__19 int64 = 0; L6: for {


































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000133__19, count_1685000132__18) { var x__20_2 any = lang.Indexed_Cast(chunk_1685000131__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000133__19)); var tmp75 any; var and__1927000168__auto____21_2 bool; var tmp76 any = A_arbace_go_check_A_const_54; var tmp77 any; var root_1382 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = x__20_2; var arg_1386 any = A_arbace_go_check_A_const_93; if linked_1383 == nil { tmp77 = ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { tmp77 = linked_1383.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) }; and__1927000168__auto____21_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp76, tmp77); if and__1927000168__auto____21_2 { var root_1387 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = x__20_2; var arg_1391 any = A_arbace_go_check_A_const_185; if linked_1388 == nil { tmp75 = ifn_1389.Invoke_O_O__O(arg_1390, arg_1391) } else { tmp75 = linked_1388.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1387, arg_1390, arg_1391) } } else { tmp75 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }; if jrt.J2g_Truth(tmp75) { var root_1522 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = x__20_2; if linked_1523 == nil { ifn_1524.Invoke_O__O(arg_1525) } else { linked_1523.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1522, arg_1525) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000133__19); continue L6 } else { seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000133__19); continue L6 } } else { var temp__1927000414__auto____20_3 any; var root_1392 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = seq_1685000130__16; if linked_1393 == nil { temp__1927000414__auto____20_3 = ifn_1394.Invoke_O__O(arg_1395) } else { temp__1927000414__auto____20_3 = linked_1393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1392, arg_1395) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000130__21 any = temp__1927000414__auto____20_3; var tmp78 any; var root_1396 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = seq_1685000130__21; if linked_1397 == nil { tmp78 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp78 = linked_1397.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(tmp78) { var c__1927000678__auto____22_3 any; var root_1400 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = seq_1685000130__21; if linked_1401 == nil { c__1927000678__auto____22_3 = ifn_1402.Invoke_O__O(arg_1403) } else { c__1927000678__auto____22_3 = linked_1401.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1400, arg_1403) }; var tmp79 any; var root_1526 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = seq_1685000130__21; if linked_1527 == nil { tmp79 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp79 = linked_1527.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1526, arg_1529) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = tmp79, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__22_3 any; var root_1404 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = seq_1685000130__21; if linked_1405 == nil { x__22_3 = ifn_1406.Invoke_O__O(arg_1407) } else { x__22_3 = linked_1405.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1404, arg_1407) }; var tmp80 any; var and__1927000168__auto____23_2 bool; var tmp81 any = A_arbace_go_check_A_const_54; var tmp82 any; var root_1408 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = x__22_3; var arg_1412 any = A_arbace_go_check_A_const_93; if linked_1409 == nil { tmp82 = ifn_1410.Invoke_O_O__O(arg_1411, arg_1412) } else { tmp82 = linked_1409.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1408, arg_1411, arg_1412) }; and__1927000168__auto____23_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp81, tmp82); if and__1927000168__auto____23_2 { var root_1413 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = x__22_3; var arg_1417 any = A_arbace_go_check_A_const_185; if linked_1414 == nil { tmp80 = ifn_1415.Invoke_O_O__O(arg_1416, arg_1417) } else { tmp80 = linked_1414.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1413, arg_1416, arg_1417) } } else { tmp80 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23_2).Ref() }; if jrt.J2g_Truth(tmp80) { var root_1530 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = x__22_3; if linked_1531 == nil { ifn_1532.Invoke_O__O(arg_1533) } else { linked_1531.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1530, arg_1533) }; var tmp83 any; var root_1534 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = seq_1685000130__21; if linked_1535 == nil { tmp83 = ifn_1536.Invoke_O__O(arg_1537) } else { tmp83 = linked_1535.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1534, arg_1537) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = tmp83, nil, 0, 0; continue L6 } else { var tmp84 any; var root_1538 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = seq_1685000130__21; if linked_1539 == nil { tmp84 = ifn_1540.Invoke_O__O(arg_1541) } else { tmp84 = linked_1539.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1538, arg_1541) }; seq_1685000130__16, chunk_1685000131__17, count_1685000132__18, i_1685000133__19 = tmp84, nil, 0, 0; continue L6 } } } }
//line :151:1
			break L6 }; var seq_1685000134__16 any; var root_1418 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1420 lang.IFn



































		if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = objs__15; if linked_1419 == nil { seq_1685000134__16 = ifn_1420.Invoke_O__O(arg_1421) } else { seq_1685000134__16 = linked_1419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1418, arg_1421) }
//line :151:1
		var chunk_1685000135__17 any; var count_1685000136__18 int64 = 0; var i_1685000137__19 int64 = 0; L7: for {



































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000137__19, count_1685000136__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1685000135__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000137__19)); var tmp85 any; var root_1422 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = A_arbace_go_check_A_const_54; var arg_1426 any; var root_1427 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = x__20_3; var arg_1431 any = A_arbace_go_check_A_const_93; if linked_1428 == nil { arg_1426 = ifn_1429.Invoke_O_O__O(arg_1430, arg_1431) } else { arg_1426 = linked_1428.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1427, arg_1430, arg_1431) }; if linked_1423 == nil { tmp85 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { tmp85 = linked_1423.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }; if jrt.J2g_Truth(tmp85) { var root_1542 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = x__20_3; if linked_1543 == nil { ifn_1544.Invoke_O__O(arg_1545) } else { linked_1543.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1542, arg_1545) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000137__19); continue L7 } else { seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000137__19); continue L7 } } else { var temp__1927000414__auto____20_4 any; var root_1432 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = seq_1685000134__16; if linked_1433 == nil { temp__1927000414__auto____20_4 = ifn_1434.Invoke_O__O(arg_1435) } else { temp__1927000414__auto____20_4 = linked_1433.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1432, arg_1435) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000134__21 any = temp__1927000414__auto____20_4; var tmp86 any; var root_1436 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = seq_1685000134__21; if linked_1437 == nil { tmp86 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp86 = linked_1437.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1436, arg_1439) }; if jrt.J2g_Truth(tmp86) { var c__1927000678__auto____22_4 any; var root_1440 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = seq_1685000134__21; if linked_1441 == nil { c__1927000678__auto____22_4 = ifn_1442.Invoke_O__O(arg_1443) } else { c__1927000678__auto____22_4 = linked_1441.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1440, arg_1443) }; var tmp87 any; var root_1546 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = seq_1685000134__21; if linked_1547 == nil { tmp87 = ifn_1548.Invoke_O__O(arg_1549) } else { tmp87 = linked_1547.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1546, arg_1549) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = tmp87, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22_4 any; var root_1444 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = seq_1685000134__21; if linked_1445 == nil { x__22_4 = ifn_1446.Invoke_O__O(arg_1447) } else { x__22_4 = linked_1445.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1444, arg_1447) }; var tmp88 any; var root_1448 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = A_arbace_go_check_A_const_54; var arg_1452 any; var root_1453 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = x__22_4; var arg_1457 any = A_arbace_go_check_A_const_93; if linked_1454 == nil { arg_1452 = ifn_1455.Invoke_O_O__O(arg_1456, arg_1457) } else { arg_1452 = linked_1454.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1453, arg_1456, arg_1457) }; if linked_1449 == nil { tmp88 = ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { tmp88 = linked_1449.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; if jrt.J2g_Truth(tmp88) { var root_1550 any = A_arbace_go_check_A_const_170.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = x__22_4; if linked_1551 == nil { ifn_1552.Invoke_O__O(arg_1553) } else { linked_1551.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1550, arg_1553) }; var tmp89 any; var root_1554 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = seq_1685000134__21; if linked_1555 == nil { tmp89 = ifn_1556.Invoke_O__O(arg_1557) } else { tmp89 = linked_1555.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1554, arg_1557) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = tmp89, nil, 0, 0; continue L7 } else { var tmp90 any; var root_1558 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = seq_1685000134__21; if linked_1559 == nil { tmp90 = ifn_1560.Invoke_O__O(arg_1561) } else { tmp90 = linked_1559.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1558, arg_1561) }; seq_1685000134__16, chunk_1685000135__17, count_1685000136__18, i_1685000137__19 = tmp90, nil, 0, 0; continue L7 } } } }
//line :151:1
			break L7 }; var seq_1685000138__16 any; var root_1458 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1460 lang.IFn





































		if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any; var root_1462 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = A_arbace_go_check_A_const_109.Invoke_O__O(ctx__11); if linked_1463 == nil { arg_1461 = ifn_1464.Invoke_O__O(arg_1465) } else { arg_1461 = linked_1463.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1462, arg_1465) }; if linked_1459 == nil { seq_1685000138__16 = ifn_1460.Invoke_O__O(arg_1461) } else { seq_1685000138__16 = linked_1459.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1458, arg_1461) }
//line :151:1
		var chunk_1685000139__17 any; var count_1685000140__18 int64 = 0; var i_1685000141__19 int64 = 0; L8: for {





































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000141__19, count_1685000140__18) { var x__20_4 any = lang.Indexed_Cast(chunk_1685000139__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000141__19)); var root_1562 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = x__20_4; if linked_1563 == nil { ifn_1564.Invoke_O__O(arg_1565) } else { linked_1563.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1562, arg_1565) }; seq_1685000138__16, chunk_1685000139__17, count_1685000140__18, i_1685000141__19 = seq_1685000138__16, chunk_1685000139__17, count_1685000140__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000141__19); continue L8 } else { var temp__1927000414__auto____20_5 any; var root_1466 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = seq_1685000138__16; if linked_1467 == nil { temp__1927000414__auto____20_5 = ifn_1468.Invoke_O__O(arg_1469) } else { temp__1927000414__auto____20_5 = linked_1467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1466, arg_1469) }; if jrt.J2g_Truth(temp__1927000414__auto____20_5) { var seq_1685000138__21 any = temp__1927000414__auto____20_5; var tmp91 any; var root_1470 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = seq_1685000138__21; if linked_1471 == nil { tmp91 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp91 = linked_1471.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1470, arg_1473) }; if jrt.J2g_Truth(tmp91) { var c__1927000678__auto____22_5 any; var root_1474 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = seq_1685000138__21; if linked_1475 == nil { c__1927000678__auto____22_5 = ifn_1476.Invoke_O__O(arg_1477) } else { c__1927000678__auto____22_5 = linked_1475.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1474, arg_1477) }; var tmp92 any; var root_1566 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = seq_1685000138__21; if linked_1567 == nil { tmp92 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp92 = linked_1567.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1566, arg_1569) }; seq_1685000138__16, chunk_1685000139__17, count_1685000140__18, i_1685000141__19 = tmp92, c__1927000678__auto____22_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__22_5 any; var root_1478 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = seq_1685000138__21; if linked_1479 == nil { x__22_5 = ifn_1480.Invoke_O__O(arg_1481) } else { x__22_5 = linked_1479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1478, arg_1481) }; var root_1570 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = x__22_5; if linked_1571 == nil { ifn_1572.Invoke_O__O(arg_1573) } else { linked_1571.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1570, arg_1573) }; var tmp93 any; var root_1574 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = seq_1685000138__21; if linked_1575 == nil { tmp93 = ifn_1576.Invoke_O__O(arg_1577) } else { tmp93 = linked_1575.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1574, arg_1577) }; seq_1685000138__16, chunk_1685000139__17, count_1685000140__18, i_1685000141__19 = tmp93, nil, 0, 0; continue L8 } } }
//line :151:1
			break L8 }; var decls__16 any; var root_752 any = A_arbace_go_check_A_const_115.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_754 lang.IFn






































		if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp94 any = A_arbace_go_check_check_package_fn__1685000142_A_New(); var tmp95 *jrt.Class; var fncls__766 *jrt.Class = A_arbace_go_check_check_package_fn__1685000142_A_fn_class; if fncls__766 == nil { var fncls__766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_check_package_fn__1685000142_A_fn_class = fncls__766d; tmp95 = fncls__766d } else { tmp95 = fncls__766 }; arg_759 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp94, tmp95, nil); var arg_760 any = objs__15; if linked_757 == nil { arg_755 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { arg_755 = linked_757.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if linked_753 == nil { decls__16 = ifn_754.Invoke_O__O(arg_755) } else { decls__16 = linked_753.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_752, arg_755) }
//line :151:1
		var seq_1685000144__17 any; var root_1578 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1580 lang.IFn







































		if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = decls__16; if linked_1579 == nil { seq_1685000144__17 = ifn_1580.Invoke_O__O(arg_1581) } else { seq_1685000144__17 = linked_1579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1578, arg_1581) }
//line :151:1
		var chunk_1685000145__18 any; var count_1685000146__19 int64 = 0; var i_1685000147__20 int64 = 0; L9: for {







































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000147__20, count_1685000146__19) { var d__21 any = lang.Indexed_Cast(chunk_1685000145__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000147__20)); L10: for { var ls__22 any; var tmp96 *lang.Keyword = A_arbace_go_check_A_const_189; var tmp97 any; var root_1674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1676 lang.IFn

				if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = d__21; if linked_1675 == nil { tmp97 = ifn_1676.Invoke_O__O(arg_1677) } else { tmp97 = linked_1675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1674, arg_1677) }; ls__22 = tmp96.Invoke_O__O(tmp97)
				var tmp98 any; var root_1678 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = ls__22; if linked_1679 == nil { tmp98 = ifn_1680.Invoke_O__O(arg_1681) } else { tmp98 = linked_1679.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1678, arg_1681) }; if jrt.J2g_Truth(tmp98) {
					var tmp99 *lang.Volatile = lang.Volatile_Cast(d__21); var tmp100 any; var root_1682 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = jrt.NN(lang.Volatile_Cast(d__21)).Deref__O(); var arg_1686 any = A_arbace_go_check_A_const_189; var arg_1687 any = lang.PersistentVector_EMPTY.Ref(); if linked_1683 == nil { tmp100 = ifn_1684.Invoke_O_O_O__O(arg_1685, arg_1686, arg_1687) } else { tmp100 = linked_1683.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1682, arg_1685, arg_1686, arg_1687) }; jrt.NN(tmp99).Reset_O__O(tmp100)
					var root_1734 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any; var tmp101 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp102 any = A_arbace_go_check_A_const_194; var tmp103 any = A_arbace_go_check_A_const_195; var tmp104 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp105 any; var root_1747 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = d__21; if linked_1748 == nil { tmp105 = ifn_1749.Invoke_O__O(arg_1750) } else { tmp105 = linked_1748.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1747, arg_1750) }; var tmp106 any = tmp104.Invoke_O__O(tmp105); var tmp107 any = A_arbace_go_check_A_const_196; var tmp108 any; var G__1685000148__23_ any; var tmp109 *lang.Keyword = A_arbace_go_check_A_const_197; var tmp110 any; var root_1751 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = d__21; if linked_1752 == nil { tmp110 = ifn_1753.Invoke_O__O(arg_1754) } else { tmp110 = linked_1752.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1751, arg_1754) }; G__1685000148__23_ = tmp109.Invoke_O__O(tmp110); if lang.Util_Identical_O_O__Z_NoInit(G__1685000148__23_, nil) { tmp108 = nil } else { var root_1755 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1757 lang.IFn; if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = G__1685000148__23_; var arg_1759 any = A_arbace_go_check_A_const_78; if linked_1756 == nil { tmp108 = ifn_1757.Invoke_O_O__O(arg_1758, arg_1759) } else { tmp108 = linked_1756.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1755, arg_1758, arg_1759) } }; arg_1737 = tmp101.Invoke_O_O_O_O_O_O__O(tmp102, d__21, tmp103, tmp106, tmp107, tmp108); if linked_1735 == nil { ifn_1736.Invoke_O__O(arg_1737) } else { linked_1735.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1734, arg_1737) }; var tmp111 any = A_arbace_go_check_check_package_fn__1685000149_A_New_O_O(d__21, ls__22); var tmp112 *jrt.Class; var fncls__1733 *jrt.Class = A_arbace_go_check_check_package_fn__1685000149_A_fn_class; if fncls__1733 == nil { var fncls__1733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000149_A_fn_class = fncls__1733d; tmp112 = fncls__1733d } else { tmp112 = fncls__1733 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp111, tmp112, nil).Invoke__O()


					continue L10 }
//line :191:1
				break L10 }; seq_1685000144__17, chunk_1685000145__18, count_1685000146__19, i_1685000147__20 = seq_1685000144__17, chunk_1685000145__18, count_1685000146__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000147__20); continue L9 } else { var temp__1927000414__auto____21 any; var root_1582 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = seq_1685000144__17; if linked_1583 == nil { temp__1927000414__auto____21 = ifn_1584.Invoke_O__O(arg_1585) } else { temp__1927000414__auto____21 = linked_1583.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1582, arg_1585) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000144__22 any = temp__1927000414__auto____21; var tmp113 any; var root_1586 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = seq_1685000144__22; if linked_1587 == nil { tmp113 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp113 = linked_1587.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1586, arg_1589) }; if jrt.J2g_Truth(tmp113) { var c__1927000678__auto____23 any; var root_1590 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = seq_1685000144__22; if linked_1591 == nil { c__1927000678__auto____23 = ifn_1592.Invoke_O__O(arg_1593) } else { c__1927000678__auto____23 = linked_1591.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1590, arg_1593) }; var tmp114 any; var root_1760 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = seq_1685000144__22; if linked_1761 == nil { tmp114 = ifn_1762.Invoke_O__O(arg_1763) } else { tmp114 = linked_1761.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1760, arg_1763) }; seq_1685000144__17, chunk_1685000145__18, count_1685000146__19, i_1685000147__20 = tmp114, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L9 } else { var d__23 any; var root_1594 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = seq_1685000144__22; if linked_1595 == nil { d__23 = ifn_1596.Invoke_O__O(arg_1597) } else { d__23 = linked_1595.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1594, arg_1597) }; L11: for { var ls__24 any; var tmp115 *lang.Keyword = A_arbace_go_check_A_const_189; var tmp116 any; var root_1764 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1766 lang.IFn

					if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = d__23; if linked_1765 == nil { tmp116 = ifn_1766.Invoke_O__O(arg_1767) } else { tmp116 = linked_1765.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1764, arg_1767) }; ls__24 = tmp115.Invoke_O__O(tmp116)
					var tmp117 any; var root_1768 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = ls__24; if linked_1769 == nil { tmp117 = ifn_1770.Invoke_O__O(arg_1771) } else { tmp117 = linked_1769.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1768, arg_1771) }; if jrt.J2g_Truth(tmp117) {
						var tmp118 *lang.Volatile = lang.Volatile_Cast(d__23); var tmp119 any; var root_1772 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1774 lang.IFn; if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = jrt.NN(lang.Volatile_Cast(d__23)).Deref__O(); var arg_1776 any = A_arbace_go_check_A_const_189; var arg_1777 any = lang.PersistentVector_EMPTY.Ref(); if linked_1773 == nil { tmp119 = ifn_1774.Invoke_O_O_O__O(arg_1775, arg_1776, arg_1777) } else { tmp119 = linked_1773.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1772, arg_1775, arg_1776, arg_1777) }; jrt.NN(tmp118).Reset_O__O(tmp119)
						var root_1824 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any; var tmp120 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp121 any = A_arbace_go_check_A_const_194; var tmp122 any = A_arbace_go_check_A_const_195; var tmp123 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp124 any; var root_1837 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = d__23; if linked_1838 == nil { tmp124 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp124 = linked_1838.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1837, arg_1840) }; var tmp125 any = tmp123.Invoke_O__O(tmp124); var tmp126 any = A_arbace_go_check_A_const_196; var tmp127 any; var G__1685000155__25_ any; var tmp128 *lang.Keyword = A_arbace_go_check_A_const_197; var tmp129 any; var root_1841 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = d__23; if linked_1842 == nil { tmp129 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp129 = linked_1842.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1841, arg_1844) }; G__1685000155__25_ = tmp128.Invoke_O__O(tmp129); if lang.Util_Identical_O_O__Z_NoInit(G__1685000155__25_, nil) { tmp127 = nil } else { var root_1845 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = G__1685000155__25_; var arg_1849 any = A_arbace_go_check_A_const_78; if linked_1846 == nil { tmp127 = ifn_1847.Invoke_O_O__O(arg_1848, arg_1849) } else { tmp127 = linked_1846.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1845, arg_1848, arg_1849) } }; arg_1827 = tmp120.Invoke_O_O_O_O_O_O__O(tmp121, d__23, tmp122, tmp125, tmp126, tmp127); if linked_1825 == nil { ifn_1826.Invoke_O__O(arg_1827) } else { linked_1825.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1824, arg_1827) }; var tmp130 any = A_arbace_go_check_check_package_fn__1685000156_A_New_O_O(d__23, ls__24); var tmp131 *jrt.Class; var fncls__1823 *jrt.Class = A_arbace_go_check_check_package_fn__1685000156_A_fn_class; if fncls__1823 == nil { var fncls__1823d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000156_A_fn_class = fncls__1823d; tmp131 = fncls__1823d } else { tmp131 = fncls__1823 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp130, tmp131, nil).Invoke__O()


						continue L11 }
//line :191:1
					break L11 }; var tmp132 any; var root_1850 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = seq_1685000144__22; if linked_1851 == nil { tmp132 = ifn_1852.Invoke_O__O(arg_1853) } else { tmp132 = linked_1851.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1850, arg_1853) }; seq_1685000144__17, chunk_1685000145__18, count_1685000146__19, i_1685000147__20 = tmp132, nil, 0, 0; continue L9 } } }
//line :151:1
			break L9 }; var seq_1685000162__17 any; var root_1598 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1600 lang.IFn

















































		if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = decls__16; if linked_1599 == nil { seq_1685000162__17 = ifn_1600.Invoke_O__O(arg_1601) } else { seq_1685000162__17 = linked_1599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1598, arg_1601) }
//line :151:1
		var chunk_1685000163__18 any; var count_1685000164__19 int64 = 0; var i_1685000165__20 int64 = 0; L12: for {

















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000165__20, count_1685000164__19) { var d__21_2 any = lang.Indexed_Cast(chunk_1685000163__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000165__20)); var tmp133 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp134 any; var root_1602 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = d__21_2; if linked_1603 == nil { tmp134 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp134 = linked_1603.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1602, arg_1605) }; if jrt.J2g_Truth(tmp133.Invoke_O__O(tmp134)) {
				var root_1866 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any; var tmp135 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp136 any = A_arbace_go_check_A_const_194; var tmp137 any = A_arbace_go_check_A_const_195; var tmp138 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp139 any; var root_1877 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = d__21_2; if linked_1878 == nil { tmp139 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp139 = linked_1878.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1877, arg_1880) }; arg_1869 = tmp135.Invoke_O_O_O_O__O(tmp136, d__21_2, tmp137, tmp138.Invoke_O__O(tmp139)); if linked_1867 == nil { ifn_1868.Invoke_O__O(arg_1869) } else { linked_1867.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1866, arg_1869) }; var tmp140 any = A_arbace_go_check_check_package_fn__1685000166_A_New_O(d__21_2); var tmp141 *jrt.Class; var fncls__1865 *jrt.Class = A_arbace_go_check_check_package_fn__1685000166_A_fn_class; if fncls__1865 == nil { var fncls__1865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_check_check_package_fn__1685000166_A_fn_class = fncls__1865d; tmp141 = fncls__1865d } else { tmp141 = fncls__1865 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp140, tmp141, nil).Invoke__O()
//line :201:1
				seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, i_1685000165__20 = seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000165__20); continue L12 } else { seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, i_1685000165__20 = seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000165__20); continue L12 } } else { var temp__1927000414__auto____21_2 any; var root_1606 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = seq_1685000162__17; if linked_1607 == nil { temp__1927000414__auto____21_2 = ifn_1608.Invoke_O__O(arg_1609) } else { temp__1927000414__auto____21_2 = linked_1607.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1606, arg_1609) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000162__22 any = temp__1927000414__auto____21_2; var tmp142 any; var root_1610 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = seq_1685000162__22; if linked_1611 == nil { tmp142 = ifn_1612.Invoke_O__O(arg_1613) } else { tmp142 = linked_1611.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1610, arg_1613) }; if jrt.J2g_Truth(tmp142) { var c__1927000678__auto____23_2 any; var root_1614 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = seq_1685000162__22; if linked_1615 == nil { c__1927000678__auto____23_2 = ifn_1616.Invoke_O__O(arg_1617) } else { c__1927000678__auto____23_2 = linked_1615.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1614, arg_1617) }; var tmp143 any; var root_1881 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = seq_1685000162__22; if linked_1882 == nil { tmp143 = ifn_1883.Invoke_O__O(arg_1884) } else { tmp143 = linked_1882.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1881, arg_1884) }; seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, i_1685000165__20 = tmp143, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__23_2 any; var root_1618 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = seq_1685000162__22; if linked_1619 == nil { d__23_2 = ifn_1620.Invoke_O__O(arg_1621) } else { d__23_2 = linked_1619.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1618, arg_1621) }; var tmp144 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp145 any; var root_1622 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = d__23_2; if linked_1623 == nil { tmp145 = ifn_1624.Invoke_O__O(arg_1625) } else { tmp145 = linked_1623.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1622, arg_1625) }; if jrt.J2g_Truth(tmp144.Invoke_O__O(tmp145)) {
					var root_1897 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any; var tmp146 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()); var tmp147 any = A_arbace_go_check_A_const_194; var tmp148 any = A_arbace_go_check_A_const_195; var tmp149 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp150 any; var root_1908 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1910 lang.IFn; if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any = d__23_2; if linked_1909 == nil { tmp150 = ifn_1910.Invoke_O__O(arg_1911) } else { tmp150 = linked_1909.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1908, arg_1911) }; arg_1900 = tmp146.Invoke_O_O_O_O__O(tmp147, d__23_2, tmp148, tmp149.Invoke_O__O(tmp150)); if linked_1898 == nil { ifn_1899.Invoke_O__O(arg_1900) } else { linked_1898.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1897, arg_1900) }; var tmp151 any = A_arbace_go_check_check_package_fn__1685000168_A_New_O(d__23_2); var tmp152 *jrt.Class; var fncls__1896 *jrt.Class = A_arbace_go_check_check_package_fn__1685000168_A_fn_class; if fncls__1896 == nil { var fncls__1896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_check_check_package_fn__1685000168_A_fn_class = fncls__1896d; tmp152 = fncls__1896d } else { tmp152 = fncls__1896 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp151, tmp152, nil).Invoke__O()
//line :201:1
					var tmp153 any; var root_1912 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1914 lang.IFn; if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = seq_1685000162__22; if linked_1913 == nil { tmp153 = ifn_1914.Invoke_O__O(arg_1915) } else { tmp153 = linked_1913.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1912, arg_1915) }; seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, i_1685000165__20 = tmp153, nil, 0, 0; continue L12 } else { var tmp154 any; var root_1916 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1918 lang.IFn; if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any = seq_1685000162__22; if linked_1917 == nil { tmp154 = ifn_1918.Invoke_O__O(arg_1919) } else { tmp154 = linked_1917.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1916, arg_1919) }; seq_1685000162__17, chunk_1685000163__18, count_1685000164__19, i_1685000165__20 = tmp154, nil, 0, 0; continue L12 } } } }
//line :151:1
			break L12 }; var seq_1685000170__17 any; var root_1626 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1628 lang.IFn





















































		if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = decls__16; if linked_1627 == nil { seq_1685000170__17 = ifn_1628.Invoke_O__O(arg_1629) } else { seq_1685000170__17 = linked_1627.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1626, arg_1629) }
//line :151:1
		var chunk_1685000171__18 any; var count_1685000172__19 int64 = 0; var i_1685000173__20 int64 = 0; L13: for {





















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000173__20, count_1685000172__19) { var d__21_3 any = lang.Indexed_Cast(chunk_1685000171__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000173__20)); var tmp155 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp156 any; var root_1630 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = d__21_3; if linked_1631 == nil { tmp156 = ifn_1632.Invoke_O__O(arg_1633) } else { tmp156 = linked_1631.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1630, arg_1633) }; if jrt.J2g_Truth(tmp155.Invoke_O__O(tmp156)) {
				var root_1920 any = A_arbace_go_check_A_const_199.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any; var tmp157 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp158 any; var root_1925 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = d__21_3; if linked_1926 == nil { tmp158 = ifn_1927.Invoke_O__O(arg_1928) } else { tmp158 = linked_1926.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1925, arg_1928) }; arg_1923 = tmp157.Invoke_O__O(tmp158); var arg_1924 any; var tmp159 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp160 any; var root_1929 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = d__21_3; if linked_1930 == nil { tmp160 = ifn_1931.Invoke_O__O(arg_1932) } else { tmp160 = linked_1930.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1929, arg_1932) }; arg_1924 = tmp159.Invoke_O__O(tmp160); if linked_1921 == nil { ifn_1922.Invoke_O_O__O(arg_1923, arg_1924) } else { linked_1921.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_1920, arg_1923, arg_1924) }
//line :205:1
				seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000173__20); continue L13 } else { seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000173__20); continue L13 } } else { var temp__1927000414__auto____21_3 any; var root_1634 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = seq_1685000170__17; if linked_1635 == nil { temp__1927000414__auto____21_3 = ifn_1636.Invoke_O__O(arg_1637) } else { temp__1927000414__auto____21_3 = linked_1635.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1634, arg_1637) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000170__22 any = temp__1927000414__auto____21_3; var tmp161 any; var root_1638 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = seq_1685000170__22; if linked_1639 == nil { tmp161 = ifn_1640.Invoke_O__O(arg_1641) } else { tmp161 = linked_1639.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1638, arg_1641) }; if jrt.J2g_Truth(tmp161) { var c__1927000678__auto____23_3 any; var root_1642 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = seq_1685000170__22; if linked_1643 == nil { c__1927000678__auto____23_3 = ifn_1644.Invoke_O__O(arg_1645) } else { c__1927000678__auto____23_3 = linked_1643.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1642, arg_1645) }; var tmp162 any; var root_1933 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = seq_1685000170__22; if linked_1934 == nil { tmp162 = ifn_1935.Invoke_O__O(arg_1936) } else { tmp162 = linked_1934.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1933, arg_1936) }; seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = tmp162, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L13 } else { var d__23_3 any; var root_1646 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = seq_1685000170__22; if linked_1647 == nil { d__23_3 = ifn_1648.Invoke_O__O(arg_1649) } else { d__23_3 = linked_1647.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1646, arg_1649) }; var tmp163 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp164 any; var root_1650 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = d__23_3; if linked_1651 == nil { tmp164 = ifn_1652.Invoke_O__O(arg_1653) } else { tmp164 = linked_1651.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1650, arg_1653) }; if jrt.J2g_Truth(tmp163.Invoke_O__O(tmp164)) {
					var root_1937 any = A_arbace_go_check_A_const_199.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any; var tmp165 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp166 any; var root_1942 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = d__23_3; if linked_1943 == nil { tmp166 = ifn_1944.Invoke_O__O(arg_1945) } else { tmp166 = linked_1943.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1942, arg_1945) }; arg_1940 = tmp165.Invoke_O__O(tmp166); var arg_1941 any; var tmp167 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp168 any; var root_1946 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = d__23_3; if linked_1947 == nil { tmp168 = ifn_1948.Invoke_O__O(arg_1949) } else { tmp168 = linked_1947.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1946, arg_1949) }; arg_1941 = tmp167.Invoke_O__O(tmp168); if linked_1938 == nil { ifn_1939.Invoke_O_O__O(arg_1940, arg_1941) } else { linked_1938.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_1937, arg_1940, arg_1941) }
//line :205:1
					var tmp169 any; var root_1950 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = seq_1685000170__22; if linked_1951 == nil { tmp169 = ifn_1952.Invoke_O__O(arg_1953) } else { tmp169 = linked_1951.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1950, arg_1953) }; seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = tmp169, nil, 0, 0; continue L13 } else { var tmp170 any; var root_1954 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = seq_1685000170__22; if linked_1955 == nil { tmp170 = ifn_1956.Invoke_O__O(arg_1957) } else { tmp170 = linked_1955.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1954, arg_1957) }; seq_1685000170__17, chunk_1685000171__18, count_1685000172__19, i_1685000173__20 = tmp170, nil, 0, 0; continue L13 } } } }
//line :151:1
			break L13 }; var seq_1685000174__17 any; var root_1654 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1656 lang.IFn























































		if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = fis__12; if linked_1655 == nil { seq_1685000174__17 = ifn_1656.Invoke_O__O(arg_1657) } else { seq_1685000174__17 = linked_1655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1654, arg_1657) }
//line :151:1
		var chunk_1685000175__18 any; var count_1685000176__19 int64 = 0; var i_1685000177__20 int64 = 0; L14: for {























































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000177__20, count_1685000176__19) { var fi__21_4 any = lang.Indexed_Cast(chunk_1685000175__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000177__20)); var root_1958 any = A_arbace_go_check_A_const_200.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = fi__21_4; if linked_1959 == nil { ifn_1960.Invoke_O__O(arg_1961) } else { linked_1959.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_1958, arg_1961) }; seq_1685000174__17, chunk_1685000175__18, count_1685000176__19, i_1685000177__20 = seq_1685000174__17, chunk_1685000175__18, count_1685000176__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000177__20); continue L14 } else { var temp__1927000414__auto____21_4 any; var root_1658 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = seq_1685000174__17; if linked_1659 == nil { temp__1927000414__auto____21_4 = ifn_1660.Invoke_O__O(arg_1661) } else { temp__1927000414__auto____21_4 = linked_1659.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1658, arg_1661) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000174__22 any = temp__1927000414__auto____21_4; var tmp171 any; var root_1662 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = seq_1685000174__22; if linked_1663 == nil { tmp171 = ifn_1664.Invoke_O__O(arg_1665) } else { tmp171 = linked_1663.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1662, arg_1665) }; if jrt.J2g_Truth(tmp171) { var c__1927000678__auto____23_4 any; var root_1666 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1668 lang.IFn; if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any = seq_1685000174__22; if linked_1667 == nil { c__1927000678__auto____23_4 = ifn_1668.Invoke_O__O(arg_1669) } else { c__1927000678__auto____23_4 = linked_1667.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1666, arg_1669) }; var tmp172 any; var root_1962 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = seq_1685000174__22; if linked_1963 == nil { tmp172 = ifn_1964.Invoke_O__O(arg_1965) } else { tmp172 = linked_1963.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1962, arg_1965) }; seq_1685000174__17, chunk_1685000175__18, count_1685000176__19, i_1685000177__20 = tmp172, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var fi__23 any; var root_1670 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = seq_1685000174__22; if linked_1671 == nil { fi__23 = ifn_1672.Invoke_O__O(arg_1673) } else { fi__23 = linked_1671.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1670, arg_1673) }; var root_1966 any = A_arbace_go_check_A_const_200.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = fi__23; if linked_1967 == nil { ifn_1968.Invoke_O__O(arg_1969) } else { linked_1967.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_1966, arg_1969) }; var tmp173 any; var root_1970 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = seq_1685000174__22; if linked_1971 == nil { tmp173 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp173 = linked_1971.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1970, arg_1973) }; seq_1685000174__17, chunk_1685000175__18, count_1685000176__19, i_1685000177__20 = tmp173, nil, 0, 0; continue L14 } } }
//line :151:1
			break L14 }; var order__17 any; var root_767 any = A_arbace_go_check_A_const_118.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_769 lang.IFn

























































		if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = objs__15; if linked_768 == nil { order__17 = ifn_769.Invoke_O__O(arg_770) } else { order__17 = linked_768.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_767, arg_770) }
//line :151:1
		var say__18 any; var root_771 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_773 lang.IFn


























































		if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = src__0; var arg_775 any = A_arbace_go_check_A_const_119; if linked_772 == nil { say__18 = ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { say__18 = linked_772.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }
//line :151:1
		var init_entry__19 any; var tmp174 any = A_arbace_go_check_check_package_init_entry__1685000178_A_New(); var tmp175 *jrt.Class
		var fncls__816 /*line :151:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000178_A_fn_class



























































		if fncls__816 == nil { var fncls__816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_check_package_init_entry__1685000178_A_fn_class = fncls__816d; tmp175 = fncls__816d } else { tmp175 = fncls__816 }; init_entry__19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp174, tmp175, nil)
//line :151:1
		var have__20 any; var root_817 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_819 lang.IFn






























































		if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = init_entry__19; var arg_821 any = order__17; if linked_818 == nil { have__20 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { have__20 = linked_818.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }
//line :151:1
		var norm__21 any; var tmp176 any = A_arbace_go_check_check_package_norm__1685000182_A_New(); var tmp177 *jrt.Class
		var fncls__850 /*line :151:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000182_A_fn_class
































































		if fncls__850 == nil { var fncls__850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_norm__1685000182_A_fn_class = fncls__850d; tmp177 = fncls__850d } else { tmp177 = fncls__850 }; norm__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp176, tmp177, nil)
//line :151:1
		var init_result__22 any; var tmp178 any; var root_851 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_853 lang.IFn





































































		if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = say__18; if linked_852 == nil { tmp178 = ifn_853.Invoke_O__O(arg_854) } else { tmp178 = linked_852.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_851, arg_854) }; if jrt.J2g_Truth(tmp178) {
			var tmp179 any; var root_855 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = norm__21; var arg_859 any = say__18; if linked_856 == nil { tmp179 = ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { tmp179 = linked_856.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp179, have__20) { var tmp180 any = A_arbace_go_check_A_const_127; var tmp181 any = jrt.Boolean_TRUE.Ref(); var tmp182 any = A_arbace_go_check_A_const_128; init_result__22 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp180, tmp181, tmp182, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__18)).Ref())) } else {

				var root_1974 any = A_arbace_go_check_A_const_201.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_202.Invoke_O__O(src__0)) { arg_1977 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_202.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp183 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp184 any; var root_1981 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_1982 == nil { tmp184 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp184 = linked_1982.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1981, arg_1984) }; arg_1977 = tmp183.Invoke_O__O(tmp184) }; var arg_1978 any; var or__1927000174__auto____22 any = A_arbace_go_check_A_const_203.Invoke_O__O(src__0)
				if jrt.J2g_Truth(or__1927000174__auto____22) { arg_1978 = or__1927000174__auto____22 } else { arg_1978 = A_arbace_go_check_A_const_22 }
//line :224:1
				var arg_1979 any = A_arbace_go_check_A_const_204; var arg_1980 any = lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_61, A_arbace_go_check_A_const_104.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()).Invoke_O__O(say__18), lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()).Invoke_O__O(have__20)); if linked_1975 == nil { ifn_1976.Invoke_O_O_O_O__O(arg_1977, arg_1978, arg_1979, arg_1980) } else { linked_1975.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1974, arg_1977, arg_1978, arg_1979, arg_1980) }
//line :222:1
				init_result__22 = A_arbace_go_check_A_const_129 } } else {
//line :221:1
					init_result__22 = nil }
//line :151:1
		var generic_ids__23 any; var root_860 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_862 lang.IFn














































































		if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var root_864 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var tmp185 any = A_arbace_go_check_check_package_fn__1685000186_A_New(); var tmp186 *jrt.Class; var fncls__877 *jrt.Class = A_arbace_go_check_check_package_fn__1685000186_A_fn_class; if fncls__877 == nil { var fncls__877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_fn__1685000186_A_fn_class = fncls__877d; tmp186 = fncls__877d } else { tmp186 = fncls__877 }; arg_867 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp185, tmp186, nil); var arg_868 any = decls__16; if linked_865 == nil { arg_863 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { arg_863 = linked_865.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }; if linked_861 == nil { generic_ids__23 = ifn_862.Invoke_O__O(arg_863) } else { generic_ids__23 = linked_861.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_860, arg_863) }
//line :151:1
		var errs__24 any; var root_878 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_880 lang.IFn

























































		if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = errors__9; if linked_879 == nil { errs__24 = ifn_880.Invoke_O__O(arg_881) } else { errs__24 = linked_879.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_878, arg_881) }
//line :151:1
		var counted__25 any; var root_882 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_884 lang.IFn
















































































		if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var tmp187 any = A_arbace_go_check_check_package_fn__1685000188_A_New_O(generic_ids__23); var tmp188 *jrt.Class; var fncls__892 *jrt.Class = A_arbace_go_check_check_package_fn__1685000188_A_fn_class; if fncls__892 == nil { var fncls__892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_fn__1685000188_A_fn_class = fncls__892d; tmp188 = fncls__892d } else { tmp188 = fncls__892 }; arg_885 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp187, tmp188, nil); var arg_886 any = errs__24; if linked_883 == nil { counted__25 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { counted__25 = linked_883.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }
//line :151:1
		var forms__26 any; var m__26 any = jrt.IdentityHashMap_New(); var order__27 any = jrt.ArrayList_New(); var seq_1685000190__28 any; var root_2000 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2002 lang.IFn




















































































		if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = decls__16; if linked_2001 == nil { seq_1685000190__28 = ifn_2002.Invoke_O__O(arg_2003) } else { seq_1685000190__28 = linked_2001.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2000, arg_2003) }
//line :151:1
		var chunk_1685000191__29 any; var count_1685000192__30 int64 = 0; var i_1685000193__31 int64 = 0; L15: for {




















































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000193__31, count_1685000192__30) { var d__32 any = lang.Indexed_Cast(chunk_1685000191__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000193__31)); var f__33 any; var tmp189 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp190 any; var root_2020 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2022 lang.IFn
				if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = d__32; if linked_2021 == nil { tmp190 = ifn_2022.Invoke_O__O(arg_2023) } else { tmp190 = linked_2021.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2020, arg_2023) }; f__33 = tmp189.Invoke_O__O(tmp190)
				if jrt.NN(jrt.IdentityHashMap_Cast(m__26)).ContainsKey_O__Z(f__33) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__27)).Add_O__Z(f__33)); jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Put_O_O__O(f__33, lang.PersistentVector_EMPTY.Ref()) }
				var tmp191 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__26); var tmp192 any; var root_2024 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Get_O__O(f__33); var arg_2028 any = d__32; if linked_2025 == nil { tmp192 = ifn_2026.Invoke_O_O__O(arg_2027, arg_2028) } else { tmp192 = linked_2025.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2024, arg_2027, arg_2028) }; jrt.NN(tmp191).Put_O_O__O(f__33, tmp192)
//line :236:1
				seq_1685000190__28, chunk_1685000191__29, count_1685000192__30, i_1685000193__31 = seq_1685000190__28, chunk_1685000191__29, count_1685000192__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000193__31); continue L15 } else { var temp__1927000414__auto____32 any; var root_2004 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = seq_1685000190__28; if linked_2005 == nil { temp__1927000414__auto____32 = ifn_2006.Invoke_O__O(arg_2007) } else { temp__1927000414__auto____32 = linked_2005.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2004, arg_2007) }; if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_1685000190__33 any = temp__1927000414__auto____32; var tmp193 any; var root_2008 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = seq_1685000190__33; if linked_2009 == nil { tmp193 = ifn_2010.Invoke_O__O(arg_2011) } else { tmp193 = linked_2009.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2008, arg_2011) }; if jrt.J2g_Truth(tmp193) { var c__1927000678__auto____34 any; var root_2012 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = seq_1685000190__33; if linked_2013 == nil { c__1927000678__auto____34 = ifn_2014.Invoke_O__O(arg_2015) } else { c__1927000678__auto____34 = linked_2013.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2012, arg_2015) }; var tmp194 any; var root_2029 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = seq_1685000190__33; if linked_2030 == nil { tmp194 = ifn_2031.Invoke_O__O(arg_2032) } else { tmp194 = linked_2030.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2029, arg_2032) }; seq_1685000190__28, chunk_1685000191__29, count_1685000192__30, i_1685000193__31 = tmp194, c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__34 any; var root_2016 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = seq_1685000190__33; if linked_2017 == nil { d__34 = ifn_2018.Invoke_O__O(arg_2019) } else { d__34 = linked_2017.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2016, arg_2019) }; var f__35 any; var tmp195 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp196 any; var root_2033 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2035 lang.IFn
					if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = d__34; if linked_2034 == nil { tmp196 = ifn_2035.Invoke_O__O(arg_2036) } else { tmp196 = linked_2034.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2033, arg_2036) }; f__35 = tmp195.Invoke_O__O(tmp196)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__26)).ContainsKey_O__Z(f__35) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__27)).Add_O__Z(f__35)); jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Put_O_O__O(f__35, lang.PersistentVector_EMPTY.Ref()) }
					var tmp197 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__26); var tmp198 any; var root_2037 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Get_O__O(f__35); var arg_2041 any = d__34; if linked_2038 == nil { tmp198 = ifn_2039.Invoke_O_O__O(arg_2040, arg_2041) } else { tmp198 = linked_2038.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2037, arg_2040, arg_2041) }; jrt.NN(tmp197).Put_O_O__O(f__35, tmp198)
//line :236:1
					var tmp199 any; var root_2042 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = seq_1685000190__33; if linked_2043 == nil { tmp199 = ifn_2044.Invoke_O__O(arg_2045) } else { tmp199 = linked_2043.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2042, arg_2045) }; seq_1685000190__28, chunk_1685000191__29, count_1685000192__30, i_1685000193__31 = tmp199, nil, 0, 0; continue L15 } } }
//line :151:1
			break L15
		}























































































		var root_893 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any; var tmp200 any = A_arbace_go_check_check_package_fn__1685000194_A_New_O(m__26); var tmp201 *jrt.Class; var fncls__898 *jrt.Class = A_arbace_go_check_check_package_fn__1685000194_A_fn_class; if fncls__898 == nil { var fncls__898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_check_check_package_fn__1685000194_A_fn_class = fncls__898d; tmp201 = fncls__898d } else { tmp201 = fncls__898 }; arg_896 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp200, tmp201, nil); var arg_897 any = order__27; if linked_894 == nil { forms__26 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { forms__26 = linked_894.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }
//line :151:1
		var stats__27 any; var root_899 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_901 lang.IFn

























































































		if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var tmp202 any = A_arbace_go_check_check_package_fn__1685000197_A_New(); var tmp203 *jrt.Class; var fncls__1179 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_A_fn_class
		if fncls__1179 == nil { var fncls__1179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_fn__1685000197_A_fn_class = fncls__1179d; tmp203 = fncls__1179d } else { tmp203 = fncls__1179 }; arg_902 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp202, tmp203, nil)
//line :241:1
		var arg_903 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_151, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_140, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_142, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_127, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_153, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_132, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_154, lang.PersistentVector_EMPTY.Ref())); var arg_904 any = forms__26; if linked_900 == nil { stats__27 = ifn_901.Invoke_O_O_O__O(arg_902, arg_903, arg_904) } else { stats__27 = linked_900.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_899, arg_902, arg_903, arg_904)
		}




























		if jrt.J2g_Truth(keep_trees__6) { } else { var seq_1685000238__28 any; var root_2046 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2048 lang.IFn
			if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = decls__16; if linked_2047 == nil { seq_1685000238__28 = ifn_2048.Invoke_O__O(arg_2049) } else { seq_1685000238__28 = linked_2047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2046, arg_2049) }
//line :271:1
			var chunk_1685000239__29 any; var count_1685000240__30 int64 = 0; var i_1685000241__31 int64 = 0; L16: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000241__31, count_1685000240__30) { var d__32_2 any = lang.Indexed_Cast(chunk_1685000239__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000241__31)); var tmp204 any; var and__1927000168__auto____33 bool; var tmp205 any = A_arbace_go_check_A_const_220; var tmp206 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp207 any; var root_2207 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2209 lang.IFn
					if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = d__32_2; if linked_2208 == nil { tmp207 = ifn_2209.Invoke_O__O(arg_2210) } else { tmp207 = linked_2208.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2207, arg_2210) }; and__1927000168__auto____33 = lang.Util_Equiv_O_O__Z_NoInit(tmp205, tmp206.Invoke_O__O(tmp207)); if and__1927000168__auto____33 { var or__1927000174__auto____34 any; var root_2211 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any; var root_2215 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any; var tmp208 *lang.Keyword = A_arbace_go_check_A_const_197; var tmp209 any; var root_2220 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = d__32_2; if linked_2221 == nil { tmp209 = ifn_2222.Invoke_O__O(arg_2223) } else { tmp209 = linked_2221.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2220, arg_2223) }; arg_2218 = tmp208.Invoke_O__O(tmp209); var arg_2219 any = A_arbace_go_check_A_const_221; if linked_2216 == nil { arg_2214 = ifn_2217.Invoke_O_O__O(arg_2218, arg_2219) } else { arg_2214 = linked_2216.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2215, arg_2218, arg_2219) }; if linked_2212 == nil { or__1927000174__auto____34 = ifn_2213.Invoke_O__O(arg_2214) } else { or__1927000174__auto____34 = linked_2212.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2211, arg_2214) }; if jrt.J2g_Truth(or__1927000174__auto____34) { tmp204 = or__1927000174__auto____34 } else { var root_2224 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any; var root_2228 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2230 lang.IFn; if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any; var tmp210 *lang.Keyword = A_arbace_go_check_A_const_197; var tmp211 any; var root_2233 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = d__32_2; if linked_2234 == nil { tmp211 = ifn_2235.Invoke_O__O(arg_2236) } else { tmp211 = linked_2234.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2233, arg_2236) }; arg_2231 = tmp210.Invoke_O__O(tmp211); var arg_2232 any = A_arbace_go_check_A_const_222; if linked_2229 == nil { arg_2227 = ifn_2230.Invoke_O_O__O(arg_2231, arg_2232) } else { arg_2227 = linked_2229.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2228, arg_2231, arg_2232) }; if linked_2225 == nil { tmp204 = ifn_2226.Invoke_O__O(arg_2227) } else { tmp204 = linked_2225.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2224, arg_2227) } } } else { tmp204 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____33).Ref() }; if jrt.J2g_Truth(tmp204) {
						jrt.NN(lang.Volatile_Cast(d__32_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__32_2)).Deref__O(), A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225, A_arbace_go_check_A_const_226)) } else {
							jrt.NN(lang.Volatile_Cast(d__32_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__32_2)).Deref__O(), A_arbace_go_check_A_const_188, A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225, A_arbace_go_check_A_const_226)) }
//line :272:1
					seq_1685000238__28, chunk_1685000239__29, count_1685000240__30, i_1685000241__31 = seq_1685000238__28, chunk_1685000239__29, count_1685000240__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000241__31); continue L16 } else { var temp__1927000414__auto____32_2 any; var root_2050 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = seq_1685000238__28; if linked_2051 == nil { temp__1927000414__auto____32_2 = ifn_2052.Invoke_O__O(arg_2053) } else { temp__1927000414__auto____32_2 = linked_2051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2050, arg_2053) }; if jrt.J2g_Truth(temp__1927000414__auto____32_2) { var seq_1685000238__33 any = temp__1927000414__auto____32_2; var tmp212 any; var root_2054 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = seq_1685000238__33; if linked_2055 == nil { tmp212 = ifn_2056.Invoke_O__O(arg_2057) } else { tmp212 = linked_2055.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2054, arg_2057) }; if jrt.J2g_Truth(tmp212) { var c__1927000678__auto____34_2 any; var root_2058 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = seq_1685000238__33; if linked_2059 == nil { c__1927000678__auto____34_2 = ifn_2060.Invoke_O__O(arg_2061) } else { c__1927000678__auto____34_2 = linked_2059.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2058, arg_2061) }; var tmp213 any; var root_2252 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = seq_1685000238__33; if linked_2253 == nil { tmp213 = ifn_2254.Invoke_O__O(arg_2255) } else { tmp213 = linked_2253.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2252, arg_2255) }; seq_1685000238__28, chunk_1685000239__29, count_1685000240__30, i_1685000241__31 = tmp213, c__1927000678__auto____34_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var d__34_2 any; var root_2062 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = seq_1685000238__33; if linked_2063 == nil { d__34_2 = ifn_2064.Invoke_O__O(arg_2065) } else { d__34_2 = linked_2063.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2062, arg_2065) }
						var tmp214 any; var and__1927000168__auto____35 bool; var tmp215 any = A_arbace_go_check_A_const_220; var tmp216 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp217 any; var root_2256 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = d__34_2; if linked_2257 == nil { tmp217 = ifn_2258.Invoke_O__O(arg_2259) } else { tmp217 = linked_2257.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2256, arg_2259) }; and__1927000168__auto____35 = lang.Util_Equiv_O_O__Z_NoInit(tmp215, tmp216.Invoke_O__O(tmp217)); if and__1927000168__auto____35 { var or__1927000174__auto____36 any; var root_2260 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any; var root_2264 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any; var tmp218 *lang.Keyword = A_arbace_go_check_A_const_197; var tmp219 any; var root_2269 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2271 lang.IFn; if linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = d__34_2; if linked_2270 == nil { tmp219 = ifn_2271.Invoke_O__O(arg_2272) } else { tmp219 = linked_2270.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2269, arg_2272) }; arg_2267 = tmp218.Invoke_O__O(tmp219); var arg_2268 any = A_arbace_go_check_A_const_221; if linked_2265 == nil { arg_2263 = ifn_2266.Invoke_O_O__O(arg_2267, arg_2268) } else { arg_2263 = linked_2265.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2264, arg_2267, arg_2268) }; if linked_2261 == nil { or__1927000174__auto____36 = ifn_2262.Invoke_O__O(arg_2263) } else { or__1927000174__auto____36 = linked_2261.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2260, arg_2263) }; if jrt.J2g_Truth(or__1927000174__auto____36) { tmp214 = or__1927000174__auto____36 } else { var root_2273 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any; var root_2277 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any; var tmp220 *lang.Keyword = A_arbace_go_check_A_const_197; var tmp221 any; var root_2282 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2284 lang.IFn; if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = d__34_2; if linked_2283 == nil { tmp221 = ifn_2284.Invoke_O__O(arg_2285) } else { tmp221 = linked_2283.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2282, arg_2285) }; arg_2280 = tmp220.Invoke_O__O(tmp221); var arg_2281 any = A_arbace_go_check_A_const_222; if linked_2278 == nil { arg_2276 = ifn_2279.Invoke_O_O__O(arg_2280, arg_2281) } else { arg_2276 = linked_2278.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2277, arg_2280, arg_2281) }; if linked_2274 == nil { tmp214 = ifn_2275.Invoke_O__O(arg_2276) } else { tmp214 = linked_2274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2273, arg_2276) } } } else { tmp214 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____35).Ref() }; if jrt.J2g_Truth(tmp214) {
							jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225, A_arbace_go_check_A_const_226)) } else {
								jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_223.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_188, A_arbace_go_check_A_const_224, A_arbace_go_check_A_const_225, A_arbace_go_check_A_const_226)) }
//line :272:1
						var tmp222 any; var root_2301 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = seq_1685000238__33; if linked_2302 == nil { tmp222 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp222 = linked_2302.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2301, arg_2304) }; seq_1685000238__28, chunk_1685000239__29, count_1685000240__30, i_1685000241__31 = tmp222, nil, 0, 0; continue L16 } } }
//line :271:1
				break L16
			}
		}


		var tmp223 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp224 any; var root_2066 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2070 any = A_arbace_go_check_A_const_207; var arg_2071 any; var tmp225 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_190.GetRawRoot__O()); var tmp226 any = A_arbace_go_check_A_const_104; var tmp227 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp228 any = A_arbace_go_check_A_const_208; var tmp229 any; var root_2094 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2096 lang.IFn


		if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any; var root_2098 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any; var root_2103 any = A_arbace_go_check_A_const_211.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = A_arbace_go_check_A_const_73; var arg_2107 any = A_arbace_go_check_A_const_78; if linked_2104 == nil { arg_2101 = ifn_2105.Invoke_O_O__O(arg_2106, arg_2107) } else { arg_2101 = linked_2104.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2103, arg_2106, arg_2107) }; var arg_2102 any = counted__25; if linked_2099 == nil { arg_2097 = ifn_2100.Invoke_O_O__O(arg_2101, arg_2102) } else { arg_2097 = linked_2099.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2098, arg_2101, arg_2102) }; if linked_2095 == nil { tmp229 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp229 = linked_2095.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2094, arg_2097) }
//line :277:1
		var tmp230 any = tmp229; var tmp231 any = A_arbace_go_check_A_const_212; var tmp232 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__24)), int64(lang.RT_Count_O__I_NoInit(counted__25)))).Ref(); var tmp233 any = A_arbace_go_check_A_const_213; var tmp234 any = A_arbace_go_check_A_const_214; var tmp235 any




		if jrt.J2g_Truth(keep_trees__6) { var root_2108 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any; var root_2112 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any; var tmp236 any = A_arbace_go_check_check_package_fn__1685000242_A_New(); var tmp237 *jrt.Class; var fncls__2121 *jrt.Class = A_arbace_go_check_check_package_fn__1685000242_A_fn_class; if fncls__2121 == nil { var fncls__2121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_check_package_fn__1685000242_A_fn_class = fncls__2121d; tmp237 = fncls__2121d } else { tmp237 = fncls__2121 }; arg_2115 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp236, tmp237, nil); var arg_2116 any = decls__16; if linked_2113 == nil { arg_2111 = ifn_2114.Invoke_O_O__O(arg_2115, arg_2116) } else { arg_2111 = linked_2113.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2112, arg_2115, arg_2116) }; if linked_2109 == nil { tmp235 = ifn_2110.Invoke_O__O(arg_2111) } else { tmp235 = linked_2109.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2108, arg_2111) } } else { tmp235 = nil }
//line :277:1
		var tmp238 any = tmp235; var tmp239 any = A_arbace_go_check_A_const_215; var tmp240 any







		if jrt.J2g_Truth(keep_trees__6) {
			var root_2122 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any; var iter__1927001039__auto____28 any; var tmp241 any = A_arbace_go_check_check_package_iter__1685000244__1685000248_A_New(); var tmp242 *jrt.Class; var fncls__2202 *jrt.Class = A_arbace_go_check_check_package_iter__1685000244__1685000248_A_fn_class; if fncls__2202 == nil { var fncls__2202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_iter__1685000244__1685000248_A_fn_class = fncls__2202d; tmp242 = fncls__2202d } else { tmp242 = fncls__2202 }; iter__1927001039__auto____28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp241, tmp242, nil); arg_2125 = lang.IFn_Cast(iter__1927001039__auto____28).Invoke_O__O(decls__16); if linked_2123 == nil { tmp240 = ifn_2124.Invoke_O__O(arg_2125) } else { tmp240 = linked_2123.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2122, arg_2125) } } else {
//line :285:1
				tmp240 = nil }
//line :277:1
		var tmp243 any = tmp240; var tmp244 any = A_arbace_go_check_A_const_219; var tmp245 any











		if jrt.J2g_Truth(keep_trees__6) { tmp245 = order__17 } else { tmp245 = nil }
//line :277:1
		var tmp246 any = tmp245; var tmp247 any = A_arbace_go_check_A_const_71; var tmp248 any












		if jrt.J2g_Truth(keep_trees__6) { tmp248 = pkg_scope__7 } else { tmp248 = nil }
//line :277:1
		var tmp249 any = tmp248; var tmp250 any = A_arbace_go_check_A_const_110; var tmp251 any













		if jrt.J2g_Truth(keep_trees__6) { var root_2203 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = A_arbace_go_check_A_const_110.Invoke_O__O(ctx__11); if linked_2204 == nil { tmp251 = ifn_2205.Invoke_O__O(arg_2206) } else { tmp251 = linked_2204.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2203, arg_2206) } } else { tmp251 = nil }
//line :277:1
		arg_2071 = tmp225.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(stats__27, tmp226, tmp227, tmp228, tmp230, tmp231, tmp232, tmp233, init_result__22, tmp234, tmp238, tmp239, tmp243, tmp244, tmp246, tmp247, tmp249, tmp250, tmp251)
//line :276:1
		if linked_2067 == nil { tmp224 = ifn_2068.Invoke_O_O_O__O(arg_2069, arg_2070, arg_2071) } else { tmp224 = linked_2067.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2066, arg_2069, arg_2070, arg_2071) }; jrt.NN(tmp223).Reset_O__O(tmp224)
//line :151:1
		tmp52 = pkg__8 }; return nil }(); var root_1180 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1182 lang.IFn; if











	linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; if linked_1181 == nil { ifn_1182.Invoke__O() } else { linked_1181.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1180) }; if /*line :151:1*/ tmp252 != nil { panic(tmp252) }; return tmp52 }










func A_arbace_go_check_check_package_fn__1685000100_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000100_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000100_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_go_check_check_package_fn__1685000100_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :162:1
func (t *A_arbace_go_check_check_package_fn__1685000100_A) Invoke_O_O__O(self, p1__1685000082_SHARP___1 any) any { var root_741 any = A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_go_check_file_info_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t.F_pkg_scope; var arg_745 any = p1__1685000082_SHARP___1; var arg_746 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_src); if linked_742 == nil { return ifn_743.Invoke_O_O_O__O(arg_744, arg_745, arg_746) } else { return linked_742.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_741, arg_744, arg_745, arg_746) } }










func A_arbace_go_check_check_package_fn__1685000102_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000102_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000102_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :173:1
func (t *A_arbace_go_check_check_package_fn__1685000102_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :173:1
func (t *A_arbace_go_check_check_package_fn__1685000102_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1187 any = A_arbace_go_check_A_const_172.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = A_arbace_go_check_A_const_104.Invoke_O__O(t.F_src); if linked_1188 == nil { tmp1 = ifn_1189.Invoke_O__O(arg_1190) } else { tmp1 = linked_1188.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1187, arg_1190) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :173:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }
















func A_arbace_go_check_check_package_fn__1685000142_A_New() *A_arbace_go_check_check_package_fn__1685000142_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000142_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000142_A) Ctor() {}
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000142_A) Invoke_O_O__O(self, p1__1685000083_SHARP___1 any) any { var root_761 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = p1__1685000083_SHARP___1; var arg_765 any = A_arbace_go_check_A_const_117; if linked_762 == nil { return ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { return linked_762.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) } }





func A_arbace_go_check_check_package_fn__1685000149_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000149_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000149_A{}; t.Ctor_O_O(p0, p1); return t }
//line :196:1
func (t *A_arbace_go_check_check_package_fn__1685000149_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :196:1
func (t *A_arbace_go_check_check_package_fn__1685000149_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000150__5 any; var root_1688 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1690 lang.IFn
											if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1691 = t_; if linked_1689 == nil { seq_1685000150__5 = ifn_1690.Invoke_O__O(arg_1691) } else { seq_1685000150__5 = linked_1689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1688, arg_1691) }
//line :196:1
	var chunk_1685000151__6 any; var count_1685000152__7 int64 = 0; var i_1685000153__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000153__8, count_1685000152__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000151__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000153__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, i_1685000153__8 = seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000153__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1692 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = seq_1685000150__5; if linked_1693 == nil { temp__1927000414__auto____9 = ifn_1694.Invoke_O__O(arg_1695) } else { temp__1927000414__auto____9 = linked_1693.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1692, arg_1695) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000150__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1696 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = seq_1685000150__10; if linked_1697 == nil { tmp2 = ifn_1698.Invoke_O__O(arg_1699) } else { tmp2 = linked_1697.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1696, arg_1699) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1700 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = seq_1685000150__10; if linked_1701 == nil { c__1927000678__auto____11 = ifn_1702.Invoke_O__O(arg_1703) } else { c__1927000678__auto____11 = linked_1701.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1700, arg_1703) }; var tmp3 any; var root_1711 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = seq_1685000150__10; if linked_1712 == nil { tmp3 = ifn_1713.Invoke_O__O(arg_1714) } else { tmp3 = linked_1712.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1711, arg_1714) }; seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, i_1685000153__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1704 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = seq_1685000150__10; if linked_1705 == nil { l__11 = ifn_1706.Invoke_O__O(arg_1707) } else { l__11 = linked_1705.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1704, arg_1707) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1715 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = seq_1685000150__10; if linked_1716 == nil { tmp4 = ifn_1717.Invoke_O__O(arg_1718) } else { tmp4 = linked_1716.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1715, arg_1718) }; seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, i_1685000153__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :196:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1719 any = A_arbace_go_check_A_const_191.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1721 lang.IFn

			if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = ex__5; if linked_1720 == nil { tmp6 = ifn_1721.Invoke_O__O(arg_1722) } else { tmp6 = linked_1720.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1719, arg_1722) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1723 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1726 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1727 any = A_arbace_go_check_A_const_132; var arg_1728 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_192; var tmp11 any; var root_1729 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = ex__5; if linked_1730 == nil { tmp11 = ifn_1731.Invoke_O__O(arg_1732) } else { tmp11 = linked_1730.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1729, arg_1732) }; arg_1728 = tmp10.Invoke_O__O(tmp11); if linked_1724 == nil { tmp8 = ifn_1725.Invoke_O_O_O__O(arg_1726, arg_1727, arg_1728) } else { tmp8 = linked_1724.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1723, arg_1726, arg_1727, arg_1728) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :196:1
				panic(tmp5) } } }; return nil }(); var root_1708 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; if linked_1709 == nil { ifn_1710.Invoke__O() } else { linked_1709.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1708) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :196:1
func A_arbace_go_check_check_package_fn__1685000156_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000156_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :196:1
func (t *A_arbace_go_check_check_package_fn__1685000156_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :196:1
func (t *A_arbace_go_check_check_package_fn__1685000156_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000157__5 any; var root_1778 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1780 lang.IFn
											if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1781 = t_; if linked_1779 == nil { seq_1685000157__5 = ifn_1780.Invoke_O__O(arg_1781) } else { seq_1685000157__5 = linked_1779.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1778, arg_1781) }
//line :196:1
	var chunk_1685000158__6 any; var count_1685000159__7 int64 = 0; var i_1685000160__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000160__8, count_1685000159__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000158__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000160__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000157__5, chunk_1685000158__6, count_1685000159__7, i_1685000160__8 = seq_1685000157__5, chunk_1685000158__6, count_1685000159__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000160__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1782 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = seq_1685000157__5; if linked_1783 == nil { temp__1927000414__auto____9 = ifn_1784.Invoke_O__O(arg_1785) } else { temp__1927000414__auto____9 = linked_1783.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1782, arg_1785) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000157__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1786 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = seq_1685000157__10; if linked_1787 == nil { tmp2 = ifn_1788.Invoke_O__O(arg_1789) } else { tmp2 = linked_1787.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1786, arg_1789) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1790 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = seq_1685000157__10; if linked_1791 == nil { c__1927000678__auto____11 = ifn_1792.Invoke_O__O(arg_1793) } else { c__1927000678__auto____11 = linked_1791.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1790, arg_1793) }; var tmp3 any; var root_1801 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = seq_1685000157__10; if linked_1802 == nil { tmp3 = ifn_1803.Invoke_O__O(arg_1804) } else { tmp3 = linked_1802.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1801, arg_1804) }; seq_1685000157__5, chunk_1685000158__6, count_1685000159__7, i_1685000160__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1794 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = seq_1685000157__10; if linked_1795 == nil { l__11 = ifn_1796.Invoke_O__O(arg_1797) } else { l__11 = linked_1795.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1794, arg_1797) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1805 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = seq_1685000157__10; if linked_1806 == nil { tmp4 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp4 = linked_1806.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1805, arg_1808) }; seq_1685000157__5, chunk_1685000158__6, count_1685000159__7, i_1685000160__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :196:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1809 any = A_arbace_go_check_A_const_191.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1811 lang.IFn

			if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = ex__5; if linked_1810 == nil { tmp6 = ifn_1811.Invoke_O__O(arg_1812) } else { tmp6 = linked_1810.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1809, arg_1812) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1813 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1816 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1817 any = A_arbace_go_check_A_const_132; var arg_1818 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_192; var tmp11 any; var root_1819 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = ex__5; if linked_1820 == nil { tmp11 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp11 = linked_1820.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1819, arg_1822) }; arg_1818 = tmp10.Invoke_O__O(tmp11); if linked_1814 == nil { tmp8 = ifn_1815.Invoke_O_O_O__O(arg_1816, arg_1817, arg_1818) } else { tmp8 = linked_1814.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1813, arg_1816, arg_1817, arg_1818) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :196:1
				panic(tmp5) } } }; return nil }(); var root_1798 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; if linked_1799 == nil { ifn_1800.Invoke__O() } else { linked_1799.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1798) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000166_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000166_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000166_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_go_check_check_package_fn__1685000166_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :202:1
func (t *A_arbace_go_check_check_package_fn__1685000166_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1854 any = A_arbace_go_check_A_const_198.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp3 any; var root_1858 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any; var t_ any = t.F_d; t.F_d = nil; arg_1861 = t_; if linked_1859 == nil { tmp3 = ifn_1860.Invoke_O__O(arg_1861) } else { tmp3 = linked_1859.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1858, arg_1861) }; arg_1857 = tmp2.Invoke_O__O(tmp3); if linked_1855 == nil { tmp1 = ifn_1856.Invoke_O__O(arg_1857) } else { tmp1 = linked_1855.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_1854, arg_1857) } }
//line :202:1
	return nil }(); var root_1862 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; if linked_1863 == nil { ifn_1864.Invoke__O() } else { linked_1863.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1862) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :202:1
func A_arbace_go_check_check_package_fn__1685000168_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000168_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000168_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_go_check_check_package_fn__1685000168_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :202:1
func (t *A_arbace_go_check_check_package_fn__1685000168_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1885 any = A_arbace_go_check_A_const_198.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp3 any; var root_1889 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any; var t_ any = t.F_d; t.F_d = nil; arg_1892 = t_; if linked_1890 == nil { tmp3 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp3 = linked_1890.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1889, arg_1892) }; arg_1888 = tmp2.Invoke_O__O(tmp3); if linked_1886 == nil { tmp1 = ifn_1887.Invoke_O__O(arg_1888) } else { tmp1 = linked_1886.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_1885, arg_1888) } }
//line :202:1
	return nil }(); var root_1893 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; if linked_1894 == nil { ifn_1895.Invoke__O() } else { linked_1894.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1893) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }








func A_arbace_go_check_check_package_init_entry__1685000178_A_New() *A_arbace_go_check_check_package_init_entry__1685000178_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000178_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_go_check_check_package_init_entry__1685000178_A) Ctor() {}
//line :211:1
func (t *A_arbace_go_check_check_package_init_entry__1685000178_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A_New(); var tmp2 *jrt.Class; var fncls__800 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A_fn_class; if
													fncls__800 == nil { var fncls__800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A_fn_class = fncls__800d; tmp2 = fncls__800d } else { tmp2 = fncls__800 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_812 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = lhs__1; if linked_813 == nil { tmp4 = ifn_814.Invoke_O__O(arg_815) } else { tmp4 = linked_813.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_812, arg_815) }; return tmp3.Invoke_O__O(tmp4) } else { var root_801 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var arg_805 any = A_arbace_go_check_A_const_123; var arg_806 any; var root_807 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = one__2; var arg_811 any = lhs__1; if linked_808 == nil { arg_806 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { arg_806 = linked_808.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; if linked_802 == nil { return ifn_803.Invoke_O_O_O__O(arg_804, arg_805, arg_806) } else { return linked_802.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_801, arg_804, arg_805, arg_806) } } }
//line :212:1
func A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A_New() *A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A) Ctor() {}
//line :212:1
func (t *A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_776 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = v__1; var arg_780 any = A_arbace_go_check_A_const_70; if linked_777 == nil { tmp1 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { tmp1 = linked_777.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_82, tmp1) { var tmp2 any; var root_790 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = v__1; var arg_794 any = A_arbace_go_check_A_const_73; if linked_791 == nil { tmp2 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { tmp2 = linked_791.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }; var tmp3 any = tmp2; var tmp4 any; var root_795 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = v__1; var arg_799 any = A_arbace_go_check_A_const_78; if linked_796 == nil { tmp4 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp4 = linked_796.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_781 any = A_arbace_go_check_A_const_120.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_785 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = v__1; var arg_789 any = A_arbace_go_check_A_const_70; if linked_786 == nil { arg_784 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { arg_784 = linked_786.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; if linked_782 == nil { return ifn_783.Invoke_O__O(arg_784) } else { return linked_782.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_781, arg_784) } } }



func A_arbace_go_check_check_package_norm__1685000182_A_New() *A_arbace_go_check_check_package_norm__1685000182_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000182_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_go_check_check_package_norm__1685000182_A) Ctor() {}
//line :216:1
func (t *A_arbace_go_check_check_package_norm__1685000182_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_822 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_824 lang.IFn; if
												linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = x__1; if linked_823 == nil { tmp1 = ifn_824.Invoke_O__O(arg_825) } else { tmp1 = linked_823.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_822, arg_825) }; if /*line :216:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_826 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_828 lang.IFn

		if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = x__1; if linked_827 == nil { tmp2 = ifn_828.Invoke_O__O(arg_829) } else { tmp2 = linked_827.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_826, arg_829) }
//line :216:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_85, tmp2) {


			var root_830 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var arg_834 any = A_arbace_go_check_A_const_124; var arg_835 any; var root_836 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A_New(); var tmp4 *jrt.Class; var fncls__845 *jrt.Class = A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A_fn_class; if fncls__845 == nil { var fncls__845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A_fn_class = fncls__845d; tmp4 = fncls__845d } else { tmp4 = fncls__845 }; arg_839 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_840 any; var root_846 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = x__1; if linked_847 == nil { arg_840 = ifn_848.Invoke_O__O(arg_849) } else { arg_840 = linked_847.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_846, arg_849) }; if linked_837 == nil { arg_835 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { arg_835 = linked_837.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; if linked_831 == nil { return ifn_832.Invoke_O_O_O__O(arg_833, arg_834, arg_835) } else { return linked_831.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_830, arg_833, arg_834, arg_835) } } else {
//line :216:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A_New() *A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A) Ctor() {}
//line :219:1
func (t *A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A) Invoke_O_O__O(self, p1__1685000084_SHARP___1 any) any { var tmp1 any; var root_841 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = p1__1685000084_SHARP___1; if linked_842 == nil { tmp1 = ifn_843.Invoke_O__O(arg_844) } else { tmp1 = linked_842.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000084_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000084_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000084_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000186_A_New() *A_arbace_go_check_check_package_fn__1685000186_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000186_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Ctor() {}
//line :230:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Invoke_O_O__O(self, p1__1685000085_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_869 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = p1__1685000085_SHARP___1; if linked_870 == nil { tmp2 = ifn_871.Invoke_O__O(arg_872) } else { tmp2 = linked_870.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp4 any; var root_873 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = p1__1685000085_SHARP___1; if linked_874 == nil { tmp4 = ifn_875.Invoke_O__O(arg_876) } else { tmp4 = linked_874.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_873, arg_876) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000188_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000188_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000188_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_go_check_check_package_fn__1685000188_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :232:1
func (t *A_arbace_go_check_check_package_fn__1685000188_A) Invoke_O_O__O(self, p1__1685000086_SHARP___1 any) any { var root_887 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = t.F_generic_ids; var arg_891 any = A_arbace_go_check_A_const_117.Invoke_O__O(p1__1685000086_SHARP___1); if linked_888 == nil { return ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { return linked_888.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_887, arg_890, arg_891) } }







func A_arbace_go_check_check_package_fn__1685000194_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000194_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000194_A{}; t.Ctor_O(p0); return t }
//line :240:1
func (t *A_arbace_go_check_check_package_fn__1685000194_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :240:1
func (t *A_arbace_go_check_check_package_fn__1685000194_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000197_A_New() *A_arbace_go_check_check_package_fn__1685000197_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_check_check_package_fn__1685000197_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_check_check_package_fn__1685000197_A) Invoke_O_O_O__O(self, acc__1, p__1685000196__2 any) any { var vec__1685000198__3 any = p__1685000196__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000198__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000198__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_905 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_907 lang.IFn; if
															linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A_New(); var tmp2 *jrt.Class; var fncls__914 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A_fn_class; if fncls__914 == nil { var fncls__914d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A_fn_class = fncls__914d; tmp2 = fncls__914d } else { tmp2 = fncls__914 }; arg_908 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_909 any = ds__5; if linked_906 == nil { gen__6 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { gen__6 = linked_906.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; var uses_generics__7 any; var root_915 any = /*line :242:1*/A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_917 lang.IFn; if

	linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A_New(); var tmp4 *jrt.Class; var fncls__924 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A_fn_class; if fncls__924 == nil { var fncls__924d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A_fn_class = fncls__924d; tmp4 = fncls__924d } else { tmp4 = fncls__924 }; arg_918 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_919 any = ds__5; if linked_916 == nil { uses_generics__7 = ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { uses_generics__7 = linked_916.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) }; var present__8 any; var root_925 any = /*line :242:1*/A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, A_arbace_go_check_annotations_present_A_fn_class); var ifn_927 lang.IFn; if


	linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = form__4; if linked_926 == nil { present__8 = ifn_927.Invoke_O__O(arg_928) } else { present__8 = linked_926.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_925, arg_928) }; var verified__9 any; var root_929 any = /*line :242:1*/A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_931 lang.IFn; if



	linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var arg_933 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_934 any; var root_935 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A_New(); var tmp6 *jrt.Class; var fncls__944 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A_fn_class; if fncls__944 == nil { var fncls__944d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A_fn_class = fncls__944d; tmp6 = fncls__944d } else { tmp6 = fncls__944 }; arg_938 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_939 any = ds__5; if linked_936 == nil { arg_934 = ifn_937.Invoke_O_O__O(arg_938, arg_939) } else { arg_934 = linked_936.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_935, arg_938, arg_939) }; if linked_930 == nil { verified__9 = ifn_931.Invoke_O_O_O__O(arg_932, arg_933, arg_934) } else { verified__9 = linked_930.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_929, arg_932, arg_933, arg_934) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_945 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any; var root_952 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = acc__1; var arg_956 any = A_arbace_go_check_A_const_140; var arg_957 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); if linked_953 == nil { arg_948 = ifn_954.Invoke_O_O_O__O(arg_955, arg_956, arg_957) } else { arg_948 = linked_953.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_952, arg_955, arg_956, arg_957) }; var arg_949 any = A_arbace_go_check_A_const_142; var arg_950 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_951 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_946 == nil { acc__10 = ifn_947.Invoke_O_O_O_O__O(arg_948, arg_949, arg_950, arg_951) } else { acc__10 = linked_946.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_945, arg_948, arg_949, arg_950, arg_951) } } else {
//line :247:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_958 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_964 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_966 lang.IFn
//line :253:1
		if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any; var root_970 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_972 lang.IFn
//line :252:1
		if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = acc__10; var arg_974 any = A_arbace_go_check_A_const_143; var arg_975 any; var root_976 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var arg_980 any = A_arbace_go_check_A_const_22; if linked_977 == nil { arg_975 = ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { arg_975 = linked_977.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_976, arg_979, arg_980) }; if linked_971 == nil { arg_967 = ifn_972.Invoke_O_O_O__O(arg_973, arg_974, arg_975) } else { arg_967 = linked_971.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_970, arg_973, arg_974, arg_975) }
		var arg_968 any = A_arbace_go_check_A_const_144; var arg_969 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A_New_O(present__8); var tmp8 *jrt.Class; var fncls__987 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A_fn_class; if fncls__987 == nil { var fncls__987d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A_fn_class = fncls__987d; tmp8 = fncls__987d } else { tmp8 = fncls__987 }; arg_969 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_965 == nil { arg_961 = ifn_966.Invoke_O_O_O__O(arg_967, arg_968, arg_969) } else { arg_961 = linked_965.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_964, arg_967, arg_968, arg_969) }
		var arg_962 any = A_arbace_go_check_A_const_132; var arg_963 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A_New_O(ds__5); var tmp10 *jrt.Class; var fncls__1010 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A_fn_class; if fncls__1010 == nil { var fncls__1010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A_fn_class = fncls__1010d; tmp10 = fncls__1010d } else { tmp10 = fncls__1010 }; arg_963 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_959 == nil { return ifn_960.Invoke_O_O_O__O(arg_961, arg_962, arg_963) } else { return linked_959.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_958, arg_961, arg_962, arg_963) } } else {
//line :250:1
			var unver__11 any; var root_1011 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1013 lang.IFn




			if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1015 any; var iter__1927001039__auto____11 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A_New_O(verified__9); var tmp12 *jrt.Class; var fncls__1098 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A_fn_class; if fncls__1098 == nil { var fncls__1098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A_fn_class = fncls__1098d; tmp12 = fncls__1098d } else { tmp12 = fncls__1098 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); arg_1015 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1012 == nil { unver__11 = ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { unver__11 = linked_1012.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015)
			}








			var root_1099 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var root_1105 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1107 lang.IFn
//line :264:1
			if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var root_1111 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1113 lang.IFn
//line :263:1
			if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var root_1117 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1119 lang.IFn
//line :262:1
			if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any; var root_1123 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1125 lang.IFn
//line :261:1
			if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any; var root_1130 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1132 lang.IFn
//line :260:1
			if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = acc__10; var arg_1134 any = A_arbace_go_check_A_const_151; var arg_1135 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); if linked_1131 == nil { arg_1126 = ifn_1132.Invoke_O_O_O__O(arg_1133, arg_1134, arg_1135) } else { arg_1126 = linked_1131.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1130, arg_1133, arg_1134, arg_1135) }
			var arg_1127 any = A_arbace_go_check_A_const_82; var arg_1128 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1129 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1124 == nil { arg_1120 = ifn_1125.Invoke_O_O_O_O__O(arg_1126, arg_1127, arg_1128, arg_1129) } else { arg_1120 = linked_1124.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1123, arg_1126, arg_1127, arg_1128, arg_1129) }
			var arg_1121 any = A_arbace_go_check_A_const_152; var arg_1122 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A_New_O(present__8); var tmp14 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A_fn_class = fncls__1142d; tmp14 = fncls__1142d } else { tmp14 = fncls__1142 }; arg_1122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1118 == nil { arg_1114 = ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { arg_1114 = linked_1118.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }
			var arg_1115 any = A_arbace_go_check_A_const_127; var arg_1116 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A_New_O(verified__9); var tmp16 *jrt.Class; var fncls__1149 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A_fn_class; if fncls__1149 == nil { var fncls__1149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A_fn_class = fncls__1149d; tmp16 = fncls__1149d } else { tmp16 = fncls__1149 }; arg_1116 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1112 == nil { arg_1108 = ifn_1113.Invoke_O_O_O__O(arg_1114, arg_1115, arg_1116) } else { arg_1108 = linked_1112.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1111, arg_1114, arg_1115, arg_1116) }
			var arg_1109 any = A_arbace_go_check_A_const_153; var arg_1110 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A_New_O(unver__11); var tmp18 *jrt.Class; var fncls__1156 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A_fn_class; if fncls__1156 == nil { var fncls__1156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A_fn_class = fncls__1156d; tmp18 = fncls__1156d } else { tmp18 = fncls__1156 }; arg_1110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1106 == nil { arg_1102 = ifn_1107.Invoke_O_O_O__O(arg_1108, arg_1109, arg_1110) } else { arg_1102 = linked_1106.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1105, arg_1108, arg_1109, arg_1110) }
			var arg_1103 any = A_arbace_go_check_A_const_154; var arg_1104 any; var tmp19 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A_New_O_O_O(form__4, ds__5, unver__11); var tmp20 *jrt.Class; var fncls__1178 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A_fn_class; if fncls__1178 == nil { var fncls__1178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A_fn_class = fncls__1178d; tmp20 = fncls__1178d } else { tmp20 = fncls__1178 }; arg_1104 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); if linked_1100 == nil { return ifn_1101.Invoke_O_O_O__O(arg_1102, arg_1103, arg_1104) } else { return linked_1100.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1099, arg_1102, arg_1103, arg_1104) } } }
//line :243:1
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A_New() *A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A) Invoke_O_O__O(self, p1__1685000087_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_910 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = p1__1685000087_SHARP___1; if linked_911 == nil { tmp2 = ifn_912.Invoke_O__O(arg_913) } else { tmp2 = linked_911.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_910, arg_913) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A_New() *A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A) Invoke_O_O__O(self, p1__1685000088_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_137; var tmp2 any; var root_920 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = p1__1685000088_SHARP___1; if linked_921 == nil { tmp2 = ifn_922.Invoke_O__O(arg_923) } else { tmp2 = linked_921.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_920, arg_923) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A_New() *A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A) Ctor() {}
//line :246:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A) Invoke_O_O__O(self, p1__1685000089_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_127; var tmp2 any; var root_940 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = p1__1685000089_SHARP___1; if linked_941 == nil { tmp2 = ifn_942.Invoke_O__O(arg_943) } else { tmp2 = linked_941.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_940, arg_943) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A{}; t.Ctor_O(p0); return t }
//line :253:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :253:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A) Invoke_O_O__O(self, p1__1685000090_SHARP___1 any) any { var root_981 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_985 any = p1__1685000090_SHARP___1; var arg_986 any = t.F_present; if linked_982 == nil { return ifn_983.Invoke_O_O_O__O(arg_984, arg_985, arg_986) } else { return linked_982.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_981, arg_984, arg_985, arg_986) } }
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A{}; t.Ctor_O(p0); return t }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A) Invoke_O_O__O(self, p1__1685000091_SHARP___1 any) any { var root_988 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A_New(); var tmp2 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A_fn_class = fncls__1009d; tmp2 = fncls__1009d } else { tmp2 = fncls__1009 }; arg_991 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_992 any = p1__1685000091_SHARP___1; var arg_993 any = t.F_ds; if linked_989 == nil { return ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { return linked_989.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993) } }
//line :254:1
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A_New() *A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A) Ctor() {}
//line :254:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_994 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = d__2; if linked_995 == nil { tmp2 = ifn_996.Invoke_O__O(arg_997) } else { tmp2 = linked_995.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_994, arg_997) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_998 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = m__1; var arg_1002 any = u__4; var arg_1003 any; var root_1004 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var arg_1008 any = A_arbace_go_check_A_const_22; if linked_1005 == nil { arg_1003 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { arg_1003 = linked_1005.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }; if linked_999 == nil { return ifn_1000.Invoke_O_O_O__O(arg_1001, arg_1002, arg_1003) } else { return linked_999.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_998, arg_1001, arg_1002, arg_1003) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A{}; t.Ctor_O(p0); return t }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A) Invoke_O_O__O(self, s__1685000214__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A_New_O_O_O(s__1685000214__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1097 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A_fn_class; if fncls__1097 == nil { var fncls__1097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A_fn_class = fncls__1097d; tmp2 = fncls__1097d } else { tmp2 = fncls__1097 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :255:1
func A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A) Ctor_O_O_O(c__s__1685000214, c__iter__1685000213, c__verified any) { t.F_s__1685000214 = c__s__1685000214; t.F_iter__1685000213 = c__iter__1685000213; t.F_verified = c__verified }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A) Invoke_O__O(self any) any { { var s__1685000214__1 any; var t_ any = t.F_s__1685000214; t.F_s__1685000214 = nil; s__1685000214__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1016 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__1685000214__1; if linked_1017 == nil { temp__1927000414__auto____2 = ifn_1018.Invoke_O__O(arg_1019) } else { temp__1927000414__auto____2 = linked_1017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1016, arg_1019) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000214__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1020 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = s__1685000214__3; if linked_1021 == nil { tmp1 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp1 = linked_1021.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1020, arg_1023) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1024 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = s__1685000214__3; if linked_1025 == nil { c__1927001037__auto____4 = ifn_1026.Invoke_O__O(arg_1027) } else { c__1927001037__auto____4 = linked_1025.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1024, arg_1027) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000216__6 any; var root_1028 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1029 == nil { b__1685000216__6 = ifn_1030.Invoke_O__O(arg_1031) } else { b__1685000216__6 = linked_1029.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1028, arg_1031) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A_New_O_I_O_O(b__1685000216__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1047 *jrt.Class = A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A_fn_class; if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A_fn_class = fncls__1047d; tmp3 = fncls__1047d } else { tmp3 = fncls__1047 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1048 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any; var root_1053 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = b__1685000216__6; if linked_1054 == nil { arg_1051 = ifn_1055.Invoke_O__O(arg_1056) } else { arg_1051 = linked_1054.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1053, arg_1056) }; var arg_1052 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000213); var tmp5 any; var root_1057 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = s__1685000214__3; if linked_1058 == nil { tmp5 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp5 = linked_1058.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1057, arg_1060) }; arg_1052 = tmp4.Invoke_O__O(tmp5); if linked_1049 == nil { return ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { return linked_1049.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) } } else { var root_1061 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1066 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = b__1685000216__6; if linked_1067 == nil { arg_1064 = ifn_1068.Invoke_O__O(arg_1069) } else { arg_1064 = linked_1067.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1066, arg_1069) }; var arg_1065 any; if linked_1062 == nil { return ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { return linked_1062.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) } } } else { var vec__1685000224__4 any; var root_1070 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = s__1685000214__3; if linked_1071 == nil { vec__1685000224__4 = ifn_1072.Invoke_O__O(arg_1073) } else { vec__1685000224__4 = linked_1071.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1070, arg_1073) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000224__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000224__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1074 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1076 lang.IFn

	if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = n__6; var arg_1078 any = v__7; if linked_1075 == nil { tmp6 = ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { tmp6 = linked_1075.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) }
//line :255:1
	if jrt.J2g_Truth(tmp6) { var root_1079 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var tmp7 jrt.Number_I; var na_1084 any = n__6; var na_1085 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1084); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1085) }; tmp8 = tmp9; if tmp8 { var n0_1086 int64 = jrt.NN(jrt.Long_Cast(na_1084)).LongValue__J(); var n1_1087 int64 = jrt.NN(jrt.Long_Cast(na_1085)).LongValue__J(); var nr_1088 int64 = n0_1086 - n1_1087; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1087 == -9223372036854775808); if tmp11 { tmp11 = (n0_1086^n1_1087)&(n0_1086^nr_1088) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1088)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1084, na_1085) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1084); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1085) }; tmp12 = tmp13; if tmp12 { var n0_1086_2 float64 = jrt.NN(jrt.Double_Cast(na_1084)).DoubleValue__D(); var n1_1087_2 float64 = jrt.NN(jrt.Double_Cast(na_1085)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1086_2 + -n1_1087_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1084, na_1085) } }
//line :255:1
		arg_1082 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1083 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000213); var tmp15 any; var root_1089 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__1685000214__3; if linked_1090 == nil { tmp15 = ifn_1091.Invoke_O__O(arg_1092) } else { tmp15 = linked_1090.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1089, arg_1092) }; arg_1083 = tmp14.Invoke_O__O(tmp15); if linked_1080 == nil { return ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { return linked_1080.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) } } else { var tmp16 any; var root_1093 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = s__1685000214__3; if linked_1094 == nil { tmp16 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp16 = linked_1094.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1093, arg_1096) }; s__1685000214__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :255:1
func A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A) Ctor_O_I_O_O(c__b__1685000216 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1685000216 = c__b__1685000216; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A) Invoke_O__O(self any) any { { var i__1685000215__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000215__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000220__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000215__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000220__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000220__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1032 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1034 lang.IFn

	if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = n__4; var arg_1036 any = v__5; if linked_1033 == nil { tmp2 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { tmp2 = linked_1033.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }
//line :255:1
	if jrt.J2g_Truth(tmp2) { var root_1037 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = t.F_b__1685000216; var arg_1041 any; var tmp3 jrt.Number_I; var na_1042 any = n__4; var na_1043 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1042); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1043) }; tmp4 = tmp5; if tmp4 { var n0_1044 int64 = jrt.NN(jrt.Long_Cast(na_1042)).LongValue__J(); var n1_1045 int64 = jrt.NN(jrt.Long_Cast(na_1043)).LongValue__J(); var nr_1046 int64 = n0_1044 - n1_1045; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1045 == -9223372036854775808); if tmp7 { tmp7 = (n0_1044^n1_1045)&(n0_1044^nr_1046) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1046)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1042, na_1043) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1042); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1043) }; tmp8 = tmp9; if tmp8 { var n0_1044_2 float64 = jrt.NN(jrt.Double_Cast(na_1042)).DoubleValue__D(); var n1_1045_2 float64 = jrt.NN(jrt.Double_Cast(na_1043)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1044_2 + -n1_1045_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1042, na_1043) } }
//line :255:1
		arg_1041 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1038 == nil { ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { linked_1038.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) }; i__1685000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000215__1); continue L1 } else { i__1685000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000215__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A{}; t.Ctor_O(p0); return t }
//line :262:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :262:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A) Invoke_O_O__O(self, p1__1685000092_SHARP___1 any) any { var root_1136 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1140 any = p1__1685000092_SHARP___1; var arg_1141 any = t.F_present; if linked_1137 == nil { return ifn_1138.Invoke_O_O_O__O(arg_1139, arg_1140, arg_1141) } else { return linked_1137.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1136, arg_1139, arg_1140, arg_1141) } }
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A{}; t.Ctor_O(p0); return t }
//line :263:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :263:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A) Invoke_O_O__O(self, p1__1685000093_SHARP___1 any) any { var root_1143 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1147 any = p1__1685000093_SHARP___1; var arg_1148 any = t.F_verified; if linked_1144 == nil { return ifn_1145.Invoke_O_O_O__O(arg_1146, arg_1147, arg_1148) } else { return linked_1144.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1143, arg_1146, arg_1147, arg_1148) } }
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :264:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A) Invoke_O_O__O(self, p1__1685000094_SHARP___1 any) any { var root_1150 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1154 any = p1__1685000094_SHARP___1; var arg_1155 any = t.F_unver; if linked_1151 == nil { return ifn_1152.Invoke_O_O_O__O(arg_1153, arg_1154, arg_1155) } else { return linked_1151.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1150, arg_1153, arg_1154, arg_1155) } }
func A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :265:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :265:1
func (t *A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A) Invoke_O_O__O(self, p1__1685000095_SHARP___1 any) any { var tmp1 any; var root_1157 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = t.F_unver; if linked_1158 == nil { tmp1 = ifn_1159.Invoke_O__O(arg_1160) } else { tmp1 = linked_1158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1157, arg_1160) }; if jrt.J2g_Truth(tmp1) { var root_1161 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = p1__1685000095_SHARP___1; var arg_1165 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp4 any; var root_1166 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any; var root_1170 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = t.F_ds; if linked_1171 == nil { arg_1169 = ifn_1172.Invoke_O__O(arg_1173) } else { arg_1169 = linked_1171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1170, arg_1173) }; if linked_1167 == nil { tmp4 = ifn_1168.Invoke_O__O(arg_1169) } else { tmp4 = linked_1167.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1166, arg_1169) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1174 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = t.F_form; if linked_1175 == nil { tmp6 = ifn_1176.Invoke_O__O(arg_1177) } else { tmp6 = linked_1175.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1174, arg_1177) }; arg_1165 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1162 == nil { return ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { return linked_1162.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) } } else { return p1__1685000095_SHARP___1 } }
















func A_arbace_go_check_check_package_fn__1685000242_A_New() *A_arbace_go_check_check_package_fn__1685000242_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000242_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000242_A) Ctor() {}
//line :282:1
func (t *A_arbace_go_check_check_package_fn__1685000242_A) Invoke_O_O__O(self, p1__1685000096_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_188; var tmp2 any; var root_2117 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = p1__1685000096_SHARP___1; if linked_2118 == nil { tmp2 = ifn_2119.Invoke_O__O(arg_2120) } else { tmp2 = linked_2118.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2117, arg_2120) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000244__1685000248_A_New() *A_arbace_go_check_check_package_iter__1685000244__1685000248_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000244__1685000248_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_iter__1685000244__1685000248_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_check_check_package_iter__1685000244__1685000248_A) Invoke_O_O__O(self, s__1685000245__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A_New_O_O(s__1685000245__1, self); var tmp2 *jrt.Class; var fncls__2201 *jrt.Class = A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A_fn_class; if fncls__2201 == nil { var fncls__2201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A_fn_class = fncls__2201d; tmp2 = fncls__2201d } else { tmp2 = fncls__2201 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :286:1
func A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A{}; t.Ctor_O_O(p0, p1); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A) Ctor_O_O(c__s__1685000245, c__iter__1685000244 any) { t.F_s__1685000245 = c__s__1685000245; t.F_iter__1685000244 = c__iter__1685000244 }
//line :286:1
func (t *A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A) Invoke_O__O(self any) any { { var s__1685000245__1 any; var t_ any = t.F_s__1685000245; t.F_s__1685000245 = nil; s__1685000245__1 = t_; for { var temp__1927000414__auto____2 any; var root_2126 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = s__1685000245__1; if linked_2127 == nil { temp__1927000414__auto____2 = ifn_2128.Invoke_O__O(arg_2129) } else { temp__1927000414__auto____2 = linked_2127.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2126, arg_2129) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000245__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2130 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = s__1685000245__3; if linked_2131 == nil { tmp1 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp1 = linked_2131.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2130, arg_2133) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2134 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = s__1685000245__3; if linked_2135 == nil { c__1927001037__auto____4 = ifn_2136.Invoke_O__O(arg_2137) } else { c__1927001037__auto____4 = linked_2135.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2134, arg_2137) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000247__6 any; var root_2138 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2139 == nil { b__1685000247__6 = ifn_2140.Invoke_O__O(arg_2141) } else { b__1685000247__6 = linked_2139.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2138, arg_2141) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A_New_O_I_O(b__1685000247__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2156 *jrt.Class = A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A_fn_class; if fncls__2156 == nil { var fncls__2156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A_fn_class = fncls__2156d; tmp3 = fncls__2156d } else { tmp3 = fncls__2156 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2157 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any; var root_2162 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = b__1685000247__6; if linked_2163 == nil { arg_2160 = ifn_2164.Invoke_O__O(arg_2165) } else { arg_2160 = linked_2163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2162, arg_2165) }; var arg_2161 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000244); var tmp5 any; var root_2166 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = s__1685000245__3; if linked_2167 == nil { tmp5 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp5 = linked_2167.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2166, arg_2169) }; arg_2161 = tmp4.Invoke_O__O(tmp5); if linked_2158 == nil { return ifn_2159.Invoke_O_O__O(arg_2160, arg_2161) } else { return linked_2158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2157, arg_2160, arg_2161) } } else { var root_2170 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any; var root_2175 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = b__1685000247__6; if linked_2176 == nil { arg_2173 = ifn_2177.Invoke_O__O(arg_2178) } else { arg_2173 = linked_2176.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2175, arg_2178) }; var arg_2174 any; if linked_2171 == nil { return ifn_2172.Invoke_O_O__O(arg_2173, arg_2174) } else { return linked_2171.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2170, arg_2173, arg_2174) } } } else { var d__4 any; var root_2179 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = s__1685000245__3; if linked_2180 == nil { d__4 = ifn_2181.Invoke_O__O(arg_2182) } else { d__4 = linked_2180.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2179, arg_2182) }; var root_2183 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any; var root_2188 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2190 lang.IFn
															if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any; var root_2193 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = d__4; if linked_2194 == nil { arg_2191 = ifn_2195.Invoke_O__O(arg_2196) } else { arg_2191 = linked_2194.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2193, arg_2196) }; var arg_2192 any = A_arbace_go_check_A_const_218; if linked_2189 == nil { arg_2186 = ifn_2190.Invoke_O_O__O(arg_2191, arg_2192) } else { arg_2186 = linked_2189.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2188, arg_2191, arg_2192) }
//line :286:1
	var arg_2187 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000244); var tmp7 any; var root_2197 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = s__1685000245__3; if linked_2198 == nil { tmp7 = ifn_2199.Invoke_O__O(arg_2200) } else { tmp7 = linked_2198.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2197, arg_2200) }; arg_2187 = tmp6.Invoke_O__O(tmp7); if linked_2184 == nil { return ifn_2185.Invoke_O_O__O(arg_2186, arg_2187) } else { return linked_2184.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2183, arg_2186, arg_2187) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :286:1
func A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A) Ctor_O_I_O(c__b__1685000247 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000247 = c__b__1685000247; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :286:1
func (t *A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A) Invoke_O__O(self any) any { { var i__1685000246__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000246__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000246__1)); var root_2142 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = t.F_b__1685000247; var arg_2146 any; var root_2147 any = A_arbace_go_check_A_const_216.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2149 lang.IFn
																	if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2152 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = d__2; if linked_2153 == nil { arg_2150 = ifn_2154.Invoke_O__O(arg_2155) } else { arg_2150 = linked_2153.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2152, arg_2155) }; var arg_2151 any = A_arbace_go_check_A_const_217; if linked_2148 == nil { arg_2146 = ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { arg_2146 = linked_2148.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) }
//line :286:1
	if linked_2143 == nil { ifn_2144.Invoke_O_O__O(arg_2145, arg_2146) } else { linked_2143.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2142, arg_2145, arg_2146) }; i__1685000246__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000246__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_227; var tmp2 any = A_arbace_go_check_A_const_228; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_229; var tmp5 any; var root_2305 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2305, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2307 lang.IFn; if



	linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2306 == nil { tmp5 = ifn_2307.Invoke_O__O(arg_2308) } else { tmp5 = linked_2306.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2305, arg_2308) }; return /*line :296:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :304:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2309 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2311 lang.IFn; if



	linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = A_arbace_go_check_A_const_229.Invoke_O__O(s__0); if linked_2310 == nil { tmp1 = ifn_2311.Invoke_O__O(arg_2312) } else { tmp1 = linked_2310.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2309, arg_2312) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_228.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2313 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = p__5; if linked_2314 == nil { tmp2 = ifn_2315.Invoke_O__O(arg_2316) } else { tmp2 = linked_2314.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2313, arg_2316) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2317 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = p__5; if linked_2318 == nil { or__1927000174__auto____3 = ifn_2319.Invoke_O__O(arg_2320) } else { or__1927000174__auto____3 = linked_2318.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2317, arg_2320) } } else { or__1927000174__auto____3 = nil } } else {
//line :308:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_232.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2321 any = A_arbace_go_check_A_const_233.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, A_arbace_go_check_ns_package_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = d__5; var arg_2325 any = ns_name__1; if linked_2322 == nil { return ifn_2323.Invoke_O_O__O(arg_2324, arg_2325) } else { return linked_2322.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2321, arg_2324, arg_2325) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :313:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000257_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2369 *jrt.Class = A_arbace_go_check_resolver_fn__1685000257_A_fn_class; _ = deps__4; if




	fncls__2369 == nil { var fncls__2369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_resolver_fn__1685000257_A_fn_class = fncls__2369d; tmp2 = fncls__2369d } else { tmp2 = fncls__2369 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :318:1
func A_arbace_go_check_resolver_fn__1685000257_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000257_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000257_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :318:1
func (t *A_arbace_go_check_resolver_fn__1685000257_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :318:1
func (t *A_arbace_go_check_resolver_fn__1685000257_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_123, path__1) { return A_arbace_go_check_A_const_234.GetRawRoot__O() } else { var lp__3 any; var root_2326 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2328 lang.IFn

		if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = t.F_src; var arg_2330 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_81, A_arbace_go_check_A_const_235, path__1); var arg_2331 any = path__1; if linked_2327 == nil { lp__3 = ifn_2328.Invoke_O_O_O__O(arg_2329, arg_2330, arg_2331) } else { lp__3 = linked_2327.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2326, arg_2329, arg_2330, arg_2331) }
//line :321:1
		var p__4 any; var or__1927000174__auto____4 any; var root_2332 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2334 lang.IFn



		if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = t.F_s; var arg_2336 any = lp__3; var arg_2337 any = t.F_src; var arg_2338 any = t.F_chain; if linked_2333 == nil { or__1927000174__auto____4 = ifn_2334.Invoke_O_O_O_O__O(arg_2335, arg_2336, arg_2337, arg_2338) } else { or__1927000174__auto____4 = linked_2333.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2332, arg_2335, arg_2336, arg_2337, arg_2338) }; if jrt.J2g_Truth(or__1927000174__auto____4) { p__4 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp1 any; var and__1927000168__auto____5 any; var root_2339 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2341 lang.IFn
			if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any; var root_2343 any = A_arbace_go_check_A_const_237.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any; var root_2348 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any; var root_2352 any = A_arbace_go_check_A_const_238.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = lp__3; var arg_2356 any = A_arbace_go_check_A_const_239; if linked_2353 == nil { arg_2351 = ifn_2354.Invoke_O_O__O(arg_2355, arg_2356) } else { arg_2351 = linked_2353.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2352, arg_2355, arg_2356) }; if linked_2349 == nil { arg_2346 = ifn_2350.Invoke_O__O(arg_2351) } else { arg_2346 = linked_2349.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2348, arg_2351) }; var arg_2347 any = Lit_124; if linked_2344 == nil { arg_2342 = ifn_2345.Invoke_O_O__O(arg_2346, arg_2347) } else { arg_2342 = linked_2344.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2343, arg_2346, arg_2347) }; if linked_2340 == nil { and__1927000168__auto____5 = ifn_2341.Invoke_O__O(arg_2342) } else { and__1927000168__auto____5 = linked_2340.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2339, arg_2342) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____5 = nil } else { or__1927000174__auto____5 = nil }
//line :325:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { p__4 = or__1927000174__auto____5 } else {

				var root_2357 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = t.F_s; var arg_2361 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_125, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2362 any = t.F_src; var arg_2363 any = t.F_chain; if linked_2358 == nil { p__4 = ifn_2359.Invoke_O_O_O_O__O(arg_2360, arg_2361, arg_2362, arg_2363) } else { p__4 = linked_2358.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2357, arg_2360, arg_2361, arg_2362, arg_2363) } } }
//line :321:1
		return p__4 } }
//line :318:1
func (t *A_arbace_go_check_resolver_fn__1685000257_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2364 any = A_arbace_go_check_A_const_233.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, A_arbace_go_check_ns_package_A_fn_class); var ifn_2366 lang.IFn; if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = t.F_s; var arg_2368 any = ns_name__1; if linked_2365 == nil { return ifn_2366.Invoke_O_O__O(arg_2367, arg_2368) } else { return linked_2365.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2364, arg_2367, arg_2368)
	}
}








func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :330:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2424 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2428 any = chain__3; if linked_2425 == nil { tmp1 = ifn_2426.Invoke_O_O__O(arg_2427, arg_2428) } else { tmp1 = linked_2425.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2424, arg_2427, arg_2428) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2429 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2431 lang.IFn
		if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil); var tmp4 any; var root_2434 any = A_arbace_go_check_A_const_246.GetRawRoot__O(); var linked_2435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2434, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2436 lang.IFn; if linked_2435 == nil { ifn_2436 = lang.IFn_Cast(root_2434) } else { ifn_2436 = nil }; var arg_2437 any = Lit_100; var arg_2438 any; var root_2439 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = chain__3; var arg_2443 any = path__1; if linked_2440 == nil { arg_2438 = ifn_2441.Invoke_O_O__O(arg_2442, arg_2443) } else { arg_2438 = linked_2440.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2439, arg_2442, arg_2443) }; if linked_2435 == nil { tmp4 = ifn_2436.Invoke_O_O__O(arg_2437, arg_2438) } else { tmp4 = linked_2435.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2434, arg_2437, arg_2438) }; arg_2432 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2433 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104, path__1)); if linked_2430 == nil { tmp2 = ifn_2431.Invoke_O_O__O(arg_2432, arg_2433) } else { tmp2 = linked_2430.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2429, arg_2432, arg_2433) }
//line :333:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :330:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_232.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2370 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = lang.IFn_Cast(A_arbace_go_check_A_const_240.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2371 == nil { and__1927000168__auto____6 = ifn_2372.Invoke_O__O(arg_2373) } else { and__1927000168__auto____6 = linked_2371.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2370, arg_2373) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_232.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2374 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2376 lang.IFn

		if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = d__6; var arg_2378 any = path__1; var arg_2379 any = importer__2; var arg_2380 any = chain__3; if linked_2375 == nil { return ifn_2376.Invoke_O_O_O_O__O(arg_2377, arg_2378, arg_2379, arg_2380) } else { return linked_2375.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2374, arg_2377, arg_2378, arg_2379, arg_2380) } } else {
//line :335:1
			var cache__6 any = A_arbace_go_check_A_const_228.Invoke_O__O(s__0); var p__7 any; var root_2381 any = A_arbace_go_check_A_const_241.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2383 lang.IFn



			if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; if linked_2382 == nil { p__7 = ifn_2383.Invoke__O() } else { p__7 = linked_2382.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2381) }
//line :335:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2384 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2386 lang.IFn; if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = prev__8; if linked_2385 == nil { return ifn_2386.Invoke_O__O(arg_2387) } else { return linked_2385.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2384, arg_2387) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_227.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2388 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__9); if linked_2389 == nil { tmp5 = ifn_2390.Invoke_O__O(arg_2391) } else { tmp5 = linked_2389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2388, arg_2391) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000260_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2423 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000260_A_fn_class; if fncls__2423 == nil { var fncls__2423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_go_check_ensure_package_fn__1685000260_A_fn_class = fncls__2423d; tmp7 = fncls__2423d } else { tmp7 = fncls__2423 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :344:1
						pkg__10 = nil
					}




				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2444 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2444, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2448 any = A_arbace_go_check_A_const_247; var arg_2449 any; var root_2450 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2452 lang.IFn; if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2454 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_248; var tmp11 any; var root_2455 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2455, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2457 lang.IFn; if linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = pkg__10; var arg_2459 any = A_arbace_go_check_A_const_71; if linked_2456 == nil { tmp11 = ifn_2457.Invoke_O_O__O(arg_2458, arg_2459) } else { tmp11 = linked_2456.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2455, arg_2458, arg_2459) }; arg_2454 = tmp10.Invoke_O__O(tmp11); if linked_2451 == nil { arg_2449 = ifn_2452.Invoke_O_O__O(arg_2453, arg_2454) } else { arg_2449 = linked_2451.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2450, arg_2453, arg_2454) }; if linked_2445 == nil { tmp9 = ifn_2446.Invoke_O_O_O__O(arg_2447, arg_2448, arg_2449) } else { tmp9 = linked_2445.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2444, arg_2447, arg_2448, arg_2449) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2460 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2462 lang.IFn; if linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = A_arbace_go_check_A_const_229.Invoke_O__O(s__0); var arg_2464 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var arg_2465 any; var root_2467 any = A_arbace_go_check_A_const_172.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = path__1; if linked_2468 == nil { arg_2465 = ifn_2469.Invoke_O__O(arg_2470) } else { arg_2465 = linked_2468.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2467, arg_2470) }; var arg_2466 any = path__1; if linked_2461 == nil { ifn_2462.Invoke_O_O_O_O__O(arg_2463, arg_2464, arg_2465, arg_2466) } else { linked_2461.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2460, arg_2463, arg_2464, arg_2465, arg_2466) }
				var root_2471 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = p__7; var arg_2475 any = pkg__10; if linked_2472 == nil { ifn_2473.Invoke_O_O__O(arg_2474, arg_2475) } else { linked_2472.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2471, arg_2474, arg_2475) }
//line :341:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000260_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000260_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000260_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :345:1
func (t *A_arbace_go_check_ensure_package_fn__1685000260_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :345:1
func (t *A_arbace_go_check_ensure_package_fn__1685000260_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_242.GetRawRoot__O()); var tmp3 any = t.F_src; var tmp4 any; var root_2397 any = A_arbace_go_check_A_const_243.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, A_arbace_go_check_resolver_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any; var t_ any = t.F_s; t.F_s = nil; arg_2400 = t_; var arg_2401 any; var t__2 any = t.F_src; t.F_src = nil; arg_2401 = t__2; var arg_2402 any; var root_2403 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any; var root_2408 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2411 = t__3; if linked_2409 == nil { arg_2406 = ifn_2410.Invoke_O__O(arg_2411) } else { arg_2406 = linked_2409.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2408, arg_2411) }; var arg_2407 any = t.F_path; if linked_2404 == nil { arg_2402 = ifn_2405.Invoke_O_O__O(arg_2406, arg_2407) } else { arg_2402 = linked_2404.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2403, arg_2406, arg_2407) }; if linked_2398 == nil { tmp4 = ifn_2399.Invoke_O_O_O__O(arg_2400, arg_2401, arg_2402) } else { tmp4 = linked_2398.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2397, arg_2400, arg_2401, arg_2402) }; tmp1 = tmp2.Invoke_O_O__O(tmp3, tmp4) }
//line :345:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_2418 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2418, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2420 lang.IFn


		if linked_2419 == nil { ifn_2420 = lang.IFn_Cast(root_2418) } else { ifn_2420 = nil }; var arg_2421 any; var t__4 any = t.F_p; t.F_p = nil; arg_2421 = t__4; var arg_2422 any; if linked_2419 == nil { ifn_2420.Invoke_O_O__O(arg_2421, arg_2422) } else { linked_2419.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2418, arg_2421, arg_2422) }
//line :345:1
		var tmp6 any; var root_2412 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2414 lang.IFn



		if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var tmp7 any = t.F_path; var arg_2415 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2416 any; var tmp8 any = A_arbace_go_check_A_const_104; var tmp9 any; var t__5 any = t.F_path; t.F_path = nil; tmp9 = t__5; arg_2416 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)); var arg_2417 any = ex__3; if linked_2413 == nil { tmp6 = ifn_2414.Invoke_O_O_O__O(arg_2415, arg_2416, arg_2417) } else { tmp6 = linked_2413.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2412, arg_2415, arg_2416, arg_2417) }
//line :345:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) } }; return tmp1 }













func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var G__1685000263__2_ any = corpus__0; switch
											lang.Util_Hash_O__I_NoInit(G__1685000263__2_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000263__2_, Lit_87) { var tmp1 any = A_arbace_go_check_A_const_250; var tmp2 any = A_arbace_go_check_A_const_252; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_251; var tmp5 any = A_arbace_go_check_A_const_252; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_89), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_254, Lit_90)), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_255)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000263__2_, Lit_91) { var tmp6 any = A_arbace_go_check_A_const_250; var tmp7 any = A_arbace_go_check_A_const_252; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_256; var tmp10 any = A_arbace_go_check_A_const_252; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_92), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_254, Lit_90)), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_257)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000263__2_, Lit_51) { var tmp11 any = A_arbace_go_check_A_const_250; var tmp12 any = A_arbace_go_check_A_const_252; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref(); var tmp14 any = A_arbace_go_check_A_const_261; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_258)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000263__2_, Lit_95) { var tmp15 any = A_arbace_go_check_A_const_250; var tmp16 any = A_arbace_go_check_A_const_252; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref(); var tmp18 any = A_arbace_go_check_A_const_261; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_96), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_259)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000263__2_, Lit_97) { var tmp19 any = A_arbace_go_check_A_const_250; var tmp20 any = A_arbace_go_check_A_const_252; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_262)) }; default:}; var tmp21 any; var root_2477 any = A_arbace_go_check_A_const_244.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2479 lang.IFn; if












	linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_98, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2481 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_260, corpus__0)); if linked_2478 == nil { tmp21 = ifn_2479.Invoke_O_O__O(arg_2480, arg_2481) } else { tmp21 = linked_2478.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2477, arg_2480, arg_2481) }; /*line :360:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp21))) }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :375:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000266__0 any) any { var map__1685000267__2 any = p__1685000266__0; var map__1685000267__3 any; if lang.ISeq_InstanceOf(map__1685000267__2) { var tmp1 any; var root_2482 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2484 lang.IFn; if linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any = map__1685000267__2; if linked_2483 == nil { tmp1 = ifn_2484.Invoke_O__O(arg_2485) } else { tmp1 = linked_2483.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2482, arg_2485) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2486 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2486, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2488 lang.IFn; if linked_2487 == nil { ifn_2488 = lang.IFn_Cast(root_2486) } else { ifn_2488 = nil }; var arg_2489 any = map__1685000267__2; if linked_2487 == nil { tmp2 = ifn_2488.Invoke_O__O(arg_2489) } else { tmp2 = linked_2487.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2486, arg_2489) }; map__1685000267__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2490 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = map__1685000267__2; if linked_2491 == nil { tmp3 = ifn_2492.Invoke_O__O(arg_2493) } else { tmp3 = linked_2491.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2490, arg_2493) }; if jrt.J2g_Truth(tmp3) { var root_2494 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = map__1685000267__2; if linked_2495 == nil { map__1685000267__3 = ifn_2496.Invoke_O__O(arg_2497) } else { map__1685000267__3 = linked_2495.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2494, arg_2497) } } else { map__1685000267__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000267__3 = map__1685000267__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000267__3, A_arbace_go_check_A_const_250); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000267__3, A_arbace_go_check_A_const_105); var root_2498 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, A_arbace_go_check_session_A_fn_class); var ifn_2500 lang.IFn; if
											linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000269_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__2514 *jrt.Class = A_arbace_go_check_std_session_fn__1685000269_A_fn_class; if fncls__2514 == nil { var fncls__2514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_std_session_fn__1685000269_A_fn_class = fncls__2514d; tmp5 = fncls__2514d } else { tmp5 = fncls__2514 }; arg_2501 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_2499 == nil { return ifn_2500.Invoke_O__O(arg_2501) } else { return linked_2499.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2498, arg_2501) } }
//line :376:1
func A_arbace_go_check_std_session_fn__1685000269_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000269_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000269_A{}; t.Ctor_O_O(p0, p1); return t }
//line :376:1
func (t *A_arbace_go_check_std_session_fn__1685000269_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :376:1
func (t *A_arbace_go_check_std_session_fn__1685000269_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_2502 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2504 lang.IFn; if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__2513 *jrt.Class = A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A_fn_class; if fncls__2513 == nil { var fncls__2513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A_fn_class = fncls__2513d; tmp2 = fncls__2513d } else { tmp2 = fncls__2513 }; arg_2505 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2506 any = t.F_roots; if linked_2503 == nil { return ifn_2504.Invoke_O_O__O(arg_2505, arg_2506) } else { return linked_2503.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2502, arg_2505, arg_2506) } }
//line :377:1
func A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A{}; t.Ctor_O_O(p0, p1); return t }
//line :377:1
func (t *A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :377:1
func (t *A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A) Invoke_O_O__O(self, p1__1685000265_SHARP___1 any) any { var root_2507 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = p1__1685000265_SHARP___1; var arg_2511 any = t.F_path; var arg_2512 any = t.F_config; if linked_2508 == nil { return ifn_2509.Invoke_O_O_O__O(arg_2510, arg_2511, arg_2512) } else { return linked_2508.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_2507, arg_2510, arg_2511, arg_2512) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :383:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_2515 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2515, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2517 lang.IFn; if


	linked_2516 == nil { ifn_2517 = lang.IFn_Cast(root_2515) } else { ifn_2517 = nil }; var arg_2518 any = xs__2; if linked_2516 == nil { xs__4 = ifn_2517.Invoke_O__O(arg_2518) } else { xs__4 = linked_2516.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2515, arg_2518) }; var q__5 any = /*line :383:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_2519 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2521 lang.IFn; if





	linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__2591 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A_fn_class; if fncls__2591 == nil { var fncls__2591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A_fn_class = fncls__2591d; tmp2 = fncls__2591d } else { tmp2 = fncls__2591 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_2592 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = n__0; if linked_2593 == nil { tmp4 = ifn_2594.Invoke_O__O(arg_2595) } else { tmp4 = linked_2593.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2592, arg_2595) }; arg_2522 = tmp3.Invoke_O__O(tmp4); if linked_2520 == nil { workers__7 = ifn_2521.Invoke_O__O(arg_2522) } else { workers__7 = linked_2520.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2519, arg_2522) }; var seq_1685000288__8 any; var root_2600 any = /*line :383:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2602 lang.IFn; if















	linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = workers__7; if linked_2601 == nil { seq_1685000288__8 = ifn_2602.Invoke_O__O(arg_2603) } else { seq_1685000288__8 = linked_2601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2600, arg_2603) }; var chunk_1685000289__9 any; var count_1685000290__10 int64 = 0; var i_1685000291__11 int64 = 0; L1:
//line :383:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000291__11, count_1685000290__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000289__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000291__11)); var root_2620 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = w__12; if linked_2621 == nil { ifn_2622.Invoke_O__O(arg_2623) } else { linked_2621.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2620, arg_2623) }; seq_1685000288__8, chunk_1685000289__9, count_1685000290__10, i_1685000291__11 = seq_1685000288__8, chunk_1685000289__9, count_1685000290__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000291__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_2604 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = seq_1685000288__8; if linked_2605 == nil { temp__1927000414__auto____12 = ifn_2606.Invoke_O__O(arg_2607) } else { temp__1927000414__auto____12 = linked_2605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2604, arg_2607) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000288__13 any = temp__1927000414__auto____12; var tmp5 any; var root_2608 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = seq_1685000288__13; if linked_2609 == nil { tmp5 = ifn_2610.Invoke_O__O(arg_2611) } else { tmp5 = linked_2609.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2608, arg_2611) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_2612 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = seq_1685000288__13; if linked_2613 == nil { c__1927000678__auto____14 = ifn_2614.Invoke_O__O(arg_2615) } else { c__1927000678__auto____14 = linked_2613.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2612, arg_2615) }; var tmp6 any; var root_2624 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = seq_1685000288__13; if linked_2625 == nil { tmp6 = ifn_2626.Invoke_O__O(arg_2627) } else { tmp6 = linked_2625.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2624, arg_2627) }; seq_1685000288__8, chunk_1685000289__9, count_1685000290__10, i_1685000291__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_2616 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = seq_1685000288__13; if linked_2617 == nil { w__14 = ifn_2618.Invoke_O__O(arg_2619) } else { w__14 = linked_2617.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2616, arg_2619) }; var root_2628 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = w__14; if linked_2629 == nil { ifn_2630.Invoke_O__O(arg_2631) } else { linked_2629.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2628, arg_2631) }; var tmp7 any; var root_2632 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = seq_1685000288__13; if linked_2633 == nil { tmp7 = ifn_2634.Invoke_O__O(arg_2635) } else { tmp7 = linked_2633.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2632, arg_2635) }; seq_1685000288__8, chunk_1685000289__9, count_1685000290__10, i_1685000291__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :383:1
		break L1 }; var root_2596 any =
















	A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = out__6; if linked_2597 == nil { return ifn_2598.Invoke_O__O(arg_2599) } else { return linked_2597.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2596, arg_2599) } }
//line :389:1
func A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A) Invoke_O_O__O(self, s__1685000275__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A_New_O_O_O_O_O_O(t.F_f, t.F_out, t.F_q, s__1685000275__1, t.F_xs, self); var tmp2 *jrt.Class; var fncls__2590 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A_fn_class; if fncls__2590 == nil { var fncls__2590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A_fn_class = fncls__2590d; tmp2 = fncls__2590d } else { tmp2 = fncls__2590 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :389:1
func A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A) Ctor_O_O_O_O_O_O(c__f, c__out, c__q, c__s__1685000275, c__xs, c__iter__1685000274 any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_s__1685000275 = c__s__1685000275; t.F_xs = c__xs; t.F_iter__1685000274 = c__iter__1685000274 }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A) Invoke_O__O(self any) any { { var s__1685000275__1 any; var t_ any = t.F_s__1685000275; t.F_s__1685000275 = nil; s__1685000275__1 = t_; for { var temp__1927000414__auto____2 any; var root_2523 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = s__1685000275__1; if linked_2524 == nil { temp__1927000414__auto____2 = ifn_2525.Invoke_O__O(arg_2526) } else { temp__1927000414__auto____2 = linked_2524.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2523, arg_2526) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000275__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2527 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = s__1685000275__3; if linked_2528 == nil { tmp1 = ifn_2529.Invoke_O__O(arg_2530) } else { tmp1 = linked_2528.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2527, arg_2530) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2531 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = s__1685000275__3; if linked_2532 == nil { c__1927001037__auto____4 = ifn_2533.Invoke_O__O(arg_2534) } else { c__1927001037__auto____4 = linked_2532.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2531, arg_2534) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000277__6 any; var root_2535 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2536 == nil { b__1685000277__6 = ifn_2537.Invoke_O__O(arg_2538) } else { b__1685000277__6 = linked_2536.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2535, arg_2538) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A_New_O_O_O_O_O_I_O(b__1685000277__6, t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2549 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A_fn_class; if fncls__2549 == nil { var fncls__2549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A_fn_class = fncls__2549d; tmp3 = fncls__2549d } else { tmp3 = fncls__2549 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2550 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any; var root_2555 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = b__1685000277__6; if linked_2556 == nil { arg_2553 = ifn_2557.Invoke_O__O(arg_2558) } else { arg_2553 = linked_2556.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2555, arg_2558) }; var arg_2554 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000274); var tmp5 any; var root_2559 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = s__1685000275__3; if linked_2560 == nil { tmp5 = ifn_2561.Invoke_O__O(arg_2562) } else { tmp5 = linked_2560.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2559, arg_2562) }; arg_2554 = tmp4.Invoke_O__O(tmp5); if linked_2551 == nil { return ifn_2552.Invoke_O_O__O(arg_2553, arg_2554) } else { return linked_2551.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2550, arg_2553, arg_2554) } } else { var root_2563 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any; var root_2568 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = b__1685000277__6; if linked_2569 == nil { arg_2566 = ifn_2570.Invoke_O__O(arg_2571) } else { arg_2566 = linked_2569.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2568, arg_2571) }; var arg_2567 any; if linked_2564 == nil { return ifn_2565.Invoke_O_O__O(arg_2566, arg_2567) } else { return linked_2564.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2563, arg_2566, arg_2567) } } } else { var ___4 any; var root_2572 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2574 lang.IFn; _ = ___4; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = s__1685000275__3; if linked_2573 == nil { ___4 = ifn_2574.Invoke_O__O(arg_2575) } else { ___4 = linked_2573.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2572, arg_2575) }; var root_2576 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any; var root_2581 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2583 lang.IFn
															if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__2585 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A_fn_class; if fncls__2585 == nil { var fncls__2585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A_fn_class = fncls__2585d; tmp7 = fncls__2585d } else { tmp7 = fncls__2585 }; arg_2584 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2582 == nil { arg_2579 = ifn_2583.Invoke_O__O(arg_2584) } else { arg_2579 = linked_2582.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2581, arg_2584) }
//line :389:1
	var arg_2580 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000274); var tmp9 any; var root_2586 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = s__1685000275__3; if linked_2587 == nil { tmp9 = ifn_2588.Invoke_O__O(arg_2589) } else { tmp9 = linked_2587.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2586, arg_2589) }; arg_2580 = tmp8.Invoke_O__O(tmp9); if linked_2577 == nil { return ifn_2578.Invoke_O_O__O(arg_2579, arg_2580) } else { return linked_2577.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2576, arg_2579, arg_2580) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :389:1
func A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A) Ctor_O_O_O_O_O_I_O(c__b__1685000277, c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000277 = c__b__1685000277; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :389:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A) Invoke_O__O(self any) any { { var i__1685000276__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000276__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000276__1)); var root_2539 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2541 lang.IFn; _ = ___2; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = t.F_b__1685000277; var arg_2543 any; var root_2544 any = A_arbace_go_check_A_const_266.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2546 lang.IFn
																if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__2548 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A_fn_class; if fncls__2548 == nil { var fncls__2548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A_fn_class = fncls__2548d; tmp3 = fncls__2548d } else { tmp3 = fncls__2548 }; arg_2547 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2545 == nil { arg_2543 = ifn_2546.Invoke_O__O(arg_2547) } else { arg_2543 = linked_2545.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2544, arg_2547) }
//line :389:1
	if linked_2540 == nil { ifn_2541.Invoke_O_O__O(arg_2542, arg_2543) } else { linked_2540.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2539, arg_2542, arg_2543) }; i__1685000276__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000276__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :390:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :390:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_267.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_267.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_268) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_267.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_267.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :393:1
			return nil } } }; /*line :390:1*/panic("j2g: unreachable") }
//line :390:1
func A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :390:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :390:1
func (t *A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_267.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_267.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_268) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_267.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_267.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :393:1
			return nil } } }; /*line :390:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :402:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_2636 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = pkg__0; var arg_2640 any = A_arbace_go_check_A_const_207; if linked_2637 == nil { return ifn_2638.Invoke_O_O__O(arg_2639, arg_2640) } else { return linked_2637.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2636, arg_2639, arg_2640) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :404:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_104; var tmp2 any = A_arbace_go_check_A_const_208; var tmp3 any = A_arbace_go_check_A_const_73; var tmp4 any = A_arbace_go_check_A_const_78; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_271; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_104, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :404:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_272, A_arbace_go_check_A_const_273))), A_arbace_go_check_A_const_151, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_140, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_142, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_152, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_127, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_153, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_144, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_132, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_270, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :411:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :411:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_2641 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, A_arbace_go_check_corpus_config_A_fn_class); var ifn_2643 lang.IFn; if


	linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = corpus__0; if linked_2642 == nil { cc__3 = ifn_2643.Invoke_O__O(arg_2644) } else { cc__3 = linked_2642.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_2641, arg_2644) }; var s__4 any; var root_2645 any = /*line :411:1*/A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, A_arbace_go_check_std_session_A_fn_class); var ifn_2647 lang.IFn; if



	linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any = cc__3; if linked_2646 == nil { s__4 = ifn_2647.Invoke_O__O(arg_2648) } else { s__4 = linked_2646.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_2645, arg_2648) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :411:1*/A_arbace_go_check_A_const_256.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_251.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_2649 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2651 lang.IFn
		if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any = A_arbace_go_check_A_const_250.Invoke_O__O(cc__3); if linked_2650 == nil { root__5 = ifn_2651.Invoke_O__O(arg_2652) } else { root__5 = linked_2650.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2649, arg_2652) }
		var root_2653 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A_New(); var tmp3 *jrt.Class; var fncls__2723 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A_fn_class; if fncls__2723 == nil { var fncls__2723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A_fn_class = fncls__2723d; tmp3 = fncls__2723d } else { tmp3 = fncls__2723 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_2724 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = root__5; var arg_2728 any = Lit_33; if linked_2725 == nil { tmp5 = ifn_2726.Invoke_O_O__O(arg_2727, arg_2728) } else { tmp5 = linked_2725.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2724, arg_2727, arg_2728) }; arg_2656 = tmp4.Invoke_O__O(tmp5); if linked_2654 == nil { std_pkgs__5 = ifn_2655.Invoke_O__O(arg_2656) } else { std_pkgs__5 = linked_2654.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2653, arg_2656) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_2729 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; var arg_2732 any = jobs__1; var arg_2733 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000306_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__2751 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000306_A_fn_class
		if fncls__2751 == nil { var fncls__2751d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_check_corpus_fn__1685000306_A_fn_class = fncls__2751d; tmp7 = fncls__2751d } else { tmp7 = fncls__2751 }; arg_2733 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :423:1
		var arg_2734 any = std_pkgs__5; if linked_2730 == nil { return ifn_2731.Invoke_O_O_O__O(arg_2732, arg_2733, arg_2734) } else { return linked_2730.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2729, arg_2732, arg_2733, arg_2734) } } else {
//line :421:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_256.Invoke_O__O(cc__3)) { var map__1685000308__6 any = A_arbace_go_check_A_const_256.Invoke_O__O(cc__3); var map__1685000308__7 any








				if lang.ISeq_InstanceOf(map__1685000308__6) { var tmp8 any; var root_2752 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = map__1685000308__6; if linked_2753 == nil { tmp8 = ifn_2754.Invoke_O__O(arg_2755) } else { tmp8 = linked_2753.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2752, arg_2755) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2756 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = map__1685000308__6; if linked_2757 == nil { tmp9 = ifn_2758.Invoke_O__O(arg_2759) } else { tmp9 = linked_2757.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2756, arg_2759) }; map__1685000308__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_2760 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any = map__1685000308__6; if linked_2761 == nil { tmp10 = ifn_2762.Invoke_O__O(arg_2763) } else { tmp10 = linked_2761.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2760, arg_2763) }; if jrt.J2g_Truth(tmp10) { var root_2764 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = map__1685000308__6; if linked_2765 == nil { map__1685000308__7 = ifn_2766.Invoke_O__O(arg_2767) } else { map__1685000308__7 = linked_2765.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2764, arg_2767) } } else { map__1685000308__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000308__7 = map__1685000308__6 }
//line :421:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000308__7, A_arbace_go_check_A_const_252); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000308__7, A_arbace_go_check_A_const_254); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252, dir__8)); var root_2768 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2768, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2770 lang.IFn










				if linked_2769 == nil { ifn_2770 = lang.IFn_Cast(root_2768) } else { ifn_2770 = nil }; var arg_2771 any = jobs__1; var arg_2772 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000310_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__2816 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class
				if fncls__2816 == nil { var fncls__2816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class = fncls__2816d; tmp12 = fncls__2816d } else { tmp12 = fncls__2816 }; arg_2772 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :432:1
				var arg_2773 any; var root_2817 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2817, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2819 lang.IFn








				if linked_2818 == nil { ifn_2819 = lang.IFn_Cast(root_2817) } else { ifn_2819 = nil }; var arg_2820 any = root__10; var arg_2821 any = sub__9; if linked_2818 == nil { arg_2773 = ifn_2819.Invoke_O_O__O(arg_2820, arg_2821) } else { arg_2773 = linked_2818.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2817, arg_2820, arg_2821) }
//line :432:1
				if linked_2769 == nil { return ifn_2770.Invoke_O_O_O__O(arg_2771, arg_2772, arg_2773) } else { return linked_2769.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2768, arg_2771, arg_2772, arg_2773) } } else {
//line :421:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_251.Invoke_O__O(cc__3)) { var map__1685000312__6 any = A_arbace_go_check_A_const_251.Invoke_O__O(cc__3); var map__1685000312__7 any





















						if lang.ISeq_InstanceOf(map__1685000312__6) { var tmp13 any; var root_2822 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2822, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2824 lang.IFn; if linked_2823 == nil { ifn_2824 = lang.IFn_Cast(root_2822) } else { ifn_2824 = nil }; var arg_2825 any = map__1685000312__6; if linked_2823 == nil { tmp13 = ifn_2824.Invoke_O__O(arg_2825) } else { tmp13 = linked_2823.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2822, arg_2825) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_2826 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2826, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2828 lang.IFn; if linked_2827 == nil { ifn_2828 = lang.IFn_Cast(root_2826) } else { ifn_2828 = nil }; var arg_2829 any = map__1685000312__6; if linked_2827 == nil { tmp14 = ifn_2828.Invoke_O__O(arg_2829) } else { tmp14 = linked_2827.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2826, arg_2829) }; map__1685000312__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp14, jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 any; var root_2830 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2832 lang.IFn; if linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any = map__1685000312__6; if linked_2831 == nil { tmp15 = ifn_2832.Invoke_O__O(arg_2833) } else { tmp15 = linked_2831.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2830, arg_2833) }; if jrt.J2g_Truth(tmp15) { var root_2834 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = map__1685000312__6; if linked_2835 == nil { map__1685000312__7 = ifn_2836.Invoke_O__O(arg_2837) } else { map__1685000312__7 = linked_2835.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2834, arg_2837) } } else { map__1685000312__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000312__7 = map__1685000312__6 }
//line :421:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000312__7, A_arbace_go_check_A_const_252); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000312__7, A_arbace_go_check_A_const_254); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_252, dir__8_2)); var pfs__11 any; var root_2838 any = A_arbace_go_check_A_const_277.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2840 lang.IFn























						if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any = root__10_2; var arg_2842 any = sub__9_2; if linked_2839 == nil { pfs__11 = ifn_2840.Invoke_O_O__O(arg_2841, arg_2842) } else { pfs__11 = linked_2839.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2838, arg_2841, arg_2842) }
//line :421:1
						var tests__12 any; var root_2843 any = A_arbace_go_check_A_const_284.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2845 lang.IFn

























						if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000314_A_New(); var tmp17 *jrt.Class; var fncls__2853 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000314_A_fn_class; if fncls__2853 == nil { var fncls__2853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_check_corpus_fn__1685000314_A_fn_class = fncls__2853d; tmp17 = fncls__2853d } else { tmp17 = fncls__2853 }; arg_2846 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_2847 any = pfs__11; if linked_2844 == nil { tests__12 = ifn_2845.Invoke_O_O__O(arg_2846, arg_2847) } else { tests__12 = linked_2844.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2843, arg_2846, arg_2847)
						}


						var root_2854 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2856 lang.IFn; if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any; var root_2858 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_2859 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2858, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2860 lang.IFn; if linked_2859 == nil { ifn_2860 = lang.IFn_Cast(root_2858) } else { ifn_2860 = nil }; var arg_2861 any = A_arbace_go_check_A_const_287.GetRawRoot__O(); var arg_2862 any; var root_2863 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2863, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2865 lang.IFn
						if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any = jobs__1; var arg_2867 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000320_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__3096 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_A_fn_class
						if fncls__3096 == nil { var fncls__3096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000320_A_fn_class = fncls__3096d; tmp19 = fncls__3096d } else { tmp19 = fncls__3096 }; arg_2867 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :452:1
						var arg_2868 any; var root_3097 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_3098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3097, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3099 lang.IFn














						if linked_3098 == nil { ifn_3099 = lang.IFn_Cast(root_3097) } else { ifn_3099 = nil }; var arg_3100 any = A_arbace_go_check_A_const_290.GetRawRoot__O(); var arg_3101 any = tests__12; if linked_3098 == nil { arg_2868 = ifn_3099.Invoke_O_O__O(arg_3100, arg_3101) } else { arg_2868 = linked_3098.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3097, arg_3100, arg_3101) }
//line :452:1
						if linked_2864 == nil { arg_2862 = ifn_2865.Invoke_O_O_O__O(arg_2866, arg_2867, arg_2868) } else { arg_2862 = linked_2864.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2863, arg_2866, arg_2867, arg_2868) }
//line :451:1
						if linked_2859 == nil { arg_2857 = ifn_2860.Invoke_O_O__O(arg_2861, arg_2862) } else { arg_2857 = linked_2859.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2858, arg_2861, arg_2862) }; if linked_2855 == nil { return ifn_2856.Invoke_O__O(arg_2857) } else { return linked_2855.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2854, arg_2857) } } else {
//line :421:1
							return nil } } } }
//line :419:1
func A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A_New() *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A) Ctor() {}
//line :419:1
func (t *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A) Invoke_O_O__O(self, s__1685000297__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A_New_O_O(s__1685000297__1, self); var tmp2 *jrt.Class; var fncls__2722 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A_fn_class; if fncls__2722 == nil { var fncls__2722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A_fn_class = fncls__2722d; tmp2 = fncls__2722d } else { tmp2 = fncls__2722 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :419:1
func A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A{}; t.Ctor_O_O(p0, p1); return t }
//line :419:1
func (t *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A) Ctor_O_O(c__s__1685000297, c__iter__1685000296 any) { t.F_s__1685000297 = c__s__1685000297; t.F_iter__1685000296 = c__iter__1685000296 }
//line :419:1
func (t *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A) Invoke_O__O(self any) any { { var s__1685000297__1 any; var t_ any = t.F_s__1685000297; t.F_s__1685000297 = nil; s__1685000297__1 = t_; for { var temp__1927000414__auto____2 any; var root_2657 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = s__1685000297__1; if linked_2658 == nil { temp__1927000414__auto____2 = ifn_2659.Invoke_O__O(arg_2660) } else { temp__1927000414__auto____2 = linked_2658.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2657, arg_2660) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2661 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any = s__1685000297__3; if linked_2662 == nil { tmp1 = ifn_2663.Invoke_O__O(arg_2664) } else { tmp1 = linked_2662.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2661, arg_2664) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2665 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = s__1685000297__3; if linked_2666 == nil { c__1927001037__auto____4 = ifn_2667.Invoke_O__O(arg_2668) } else { c__1927001037__auto____4 = linked_2666.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2665, arg_2668) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000299__6 any; var root_2669 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2671 lang.IFn; if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2670 == nil { b__1685000299__6 = ifn_2671.Invoke_O__O(arg_2672) } else { b__1685000299__6 = linked_2670.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2669, arg_2672) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A_New_O_I_O(b__1685000299__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2682 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A_fn_class; if fncls__2682 == nil { var fncls__2682d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A_fn_class = fncls__2682d; tmp3 = fncls__2682d } else { tmp3 = fncls__2682 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2683 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2685 lang.IFn; if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any; var root_2688 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2690 lang.IFn; if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = b__1685000299__6; if linked_2689 == nil { arg_2686 = ifn_2690.Invoke_O__O(arg_2691) } else { arg_2686 = linked_2689.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2688, arg_2691) }; var arg_2687 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000296); var tmp5 any; var root_2692 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2692, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2694 lang.IFn; if linked_2693 == nil { ifn_2694 = lang.IFn_Cast(root_2692) } else { ifn_2694 = nil }; var arg_2695 any = s__1685000297__3; if linked_2693 == nil { tmp5 = ifn_2694.Invoke_O__O(arg_2695) } else { tmp5 = linked_2693.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2692, arg_2695) }; arg_2687 = tmp4.Invoke_O__O(tmp5); if linked_2684 == nil { return ifn_2685.Invoke_O_O__O(arg_2686, arg_2687) } else { return linked_2684.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2683, arg_2686, arg_2687) } } else { var root_2696 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any; var root_2701 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2703 lang.IFn; if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = b__1685000299__6; if linked_2702 == nil { arg_2699 = ifn_2703.Invoke_O__O(arg_2704) } else { arg_2699 = linked_2702.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2701, arg_2704) }; var arg_2700 any; if linked_2697 == nil { return ifn_2698.Invoke_O_O__O(arg_2699, arg_2700) } else { return linked_2697.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2696, arg_2699, arg_2700) } } } else { var pf__4 any; var root_2705 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2705, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2707 lang.IFn; if linked_2706 == nil { ifn_2707 = lang.IFn_Cast(root_2705) } else { ifn_2707 = nil }; var arg_2708 any = s__1685000297__3; if linked_2706 == nil { pf__4 = ifn_2707.Invoke_O__O(arg_2708) } else { pf__4 = linked_2706.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2705, arg_2708) }; var root_2709 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2709, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2711 lang.IFn; if linked_2710 == nil { ifn_2711 = lang.IFn_Cast(root_2709) } else { ifn_2711 = nil }; var arg_2712 any; var root_2714 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2714, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2716 lang.IFn
															if linked_2715 == nil { ifn_2716 = lang.IFn_Cast(root_2714) } else { ifn_2716 = nil }; var arg_2717 any = pf__4; if linked_2715 == nil { arg_2712 = ifn_2716.Invoke_O__O(arg_2717) } else { arg_2712 = linked_2715.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2714, arg_2717) }
//line :419:1
	var arg_2713 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000296); var tmp7 any; var root_2718 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2718, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2720 lang.IFn; if linked_2719 == nil { ifn_2720 = lang.IFn_Cast(root_2718) } else { ifn_2720 = nil }; var arg_2721 any = s__1685000297__3; if linked_2719 == nil { tmp7 = ifn_2720.Invoke_O__O(arg_2721) } else { tmp7 = linked_2719.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2718, arg_2721) }; arg_2713 = tmp6.Invoke_O__O(tmp7); if linked_2710 == nil { return ifn_2711.Invoke_O_O__O(arg_2712, arg_2713) } else { return linked_2710.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2709, arg_2712, arg_2713) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :419:1
func A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :419:1
func (t *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A) Ctor_O_I_O(c__b__1685000299 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000299 = c__b__1685000299; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :419:1
func (t *A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A) Invoke_O__O(self any) any { { var i__1685000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000298__1)); var root_2673 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2675 lang.IFn; if linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any = t.F_b__1685000299; var arg_2677 any; var root_2678 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2680 lang.IFn
																if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = pf__2; if linked_2679 == nil { arg_2677 = ifn_2680.Invoke_O__O(arg_2681) } else { arg_2677 = linked_2679.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2678, arg_2681) }
//line :419:1
	if linked_2674 == nil { ifn_2675.Invoke_O_O__O(arg_2676, arg_2677) } else { linked_2674.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2673, arg_2676, arg_2677) }; i__1685000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000298__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000306_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000306_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000306_A{}; t.Ctor_O(p0); return t }
//line :424:1
func (t *A_arbace_go_check_check_corpus_fn__1685000306_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :424:1
func (t *A_arbace_go_check_check_corpus_fn__1685000306_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_2735 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2735, A_arbace_go_check_result_of_A_fn_class); var ifn_2737 lang.IFn
												if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any; var root_2739 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2741 lang.IFn; if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any = t.F_s; var arg_2743 any = path__1; var arg_2744 any; var arg_2745 any = lang.PersistentVector_EMPTY.Ref(); if linked_2740 == nil { arg_2738 = ifn_2741.Invoke_O_O_O_O__O(arg_2742, arg_2743, arg_2744, arg_2745) } else { arg_2738 = linked_2740.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2739, arg_2742, arg_2743, arg_2744, arg_2745) }; if linked_2736 == nil { or__1927000174__auto____4 = ifn_2737.Invoke_O__O(arg_2738) } else { or__1927000174__auto____4 = linked_2736.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2735, arg_2738) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104, path__1, A_arbace_go_check_A_const_280, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :424:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_2746 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2746, A_arbace_go_check_error_result_A_fn_class); var ifn_2748 lang.IFn


		if linked_2747 == nil { ifn_2748 = lang.IFn_Cast(root_2746) } else { ifn_2748 = nil }; var arg_2749 any = path__1; var arg_2750 any = ex__4; if linked_2747 == nil { tmp1 = ifn_2748.Invoke_O_O__O(arg_2749, arg_2750) } else { tmp1 = linked_2747.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2746, arg_2749, arg_2750) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000310_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000310_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :433:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :433:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_2774 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2774, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2776 lang.IFn

	if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any = t.F_root; var arg_2778 any; var arg_2779 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_cc); var arg_2780 any = pf__1; if linked_2775 == nil { src__4 = ifn_2776.Invoke_O_O_O_O__O(arg_2777, arg_2778, arg_2779, arg_2780) } else { src__4 = linked_2775.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2774, arg_2777, arg_2778, arg_2779, arg_2780) }
	var tmp2 any; var root_2781 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__4); if linked_2782 == nil { tmp2 = ifn_2783.Invoke_O__O(arg_2784) } else { tmp2 = linked_2782.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2781, arg_2784) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_104; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_280, jrt.Boolean_TRUE.Ref())) } else {

		var root_2785 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2785, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any; var root_2791 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, A_arbace_go_check_result_of_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_242.GetRawRoot__O()); var tmp5 any; var root_2800 any = A_arbace_go_check_A_const_243.GetRawRoot__O(); var linked_2801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2800, A_arbace_go_check_resolver_A_fn_class); var ifn_2802 lang.IFn; if linked_2801 == nil { ifn_2802 = lang.IFn_Cast(root_2800) } else { ifn_2802 = nil }; var arg_2803 any = t.F_s; var arg_2804 any = src__4; var arg_2805 any = lang.PersistentVector_EMPTY.Ref(); if linked_2801 == nil { tmp5 = ifn_2802.Invoke_O_O_O__O(arg_2803, arg_2804, arg_2805) } else { tmp5 = linked_2801.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2800, arg_2803, arg_2804, arg_2805) }; arg_2794 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_2792 == nil { arg_2788 = ifn_2793.Invoke_O__O(arg_2794) } else { arg_2788 = linked_2792.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2791, arg_2794) }; var arg_2789 any = A_arbace_go_check_A_const_104; var arg_2790 any; var root_2806 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2808 lang.IFn
		if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2810 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_2807 == nil { arg_2790 = ifn_2808.Invoke_O_O__O(arg_2809, arg_2810) } else { arg_2790 = linked_2807.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2806, arg_2809, arg_2810) }
//line :438:1
		if linked_2786 == nil { tmp1 = ifn_2787.Invoke_O_O_O__O(arg_2788, arg_2789, arg_2790) } else { tmp1 = linked_2786.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2785, arg_2788, arg_2789, arg_2790) } } }; return nil }(); if /*line :433:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_2811 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, A_arbace_go_check_error_result_A_fn_class); var ifn_2813 lang.IFn






			if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2815 any = ex__4; if linked_2812 == nil { tmp1 = ifn_2813.Invoke_O_O__O(arg_2814, arg_2815) } else { tmp1 = linked_2812.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2811, arg_2814, arg_2815) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000314_A_New() *A_arbace_go_check_check_corpus_fn__1685000314_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000314_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_go_check_check_corpus_fn__1685000314_A) Ctor() {}
//line :447:1
func (t *A_arbace_go_check_check_corpus_fn__1685000314_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_2848 any = A_arbace_go_check_A_const_285.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2850 lang.IFn; if

	linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var arg_2851 any = A_arbace_go_check_A_const_286; var arg_2852 any = p__2; if linked_2849 == nil { temp__1927000408__auto____3 = ifn_2850.Invoke_O_O__O(arg_2851, arg_2852) } else { temp__1927000408__auto____3 = linked_2849.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2848, arg_2851, arg_2852) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000315__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000315__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000315__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000320_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000320_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :453:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :453:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_A) Invoke_O_O__O(self, p__1685000319__1 any) any { var vec__1685000321__2 any = p__1685000319__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000321__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000321__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_2869 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2871 lang.IFn

	if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2873 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A_New(); var tmp3 *jrt.Class; var fncls__2940 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A_fn_class; if fncls__2940 == nil { var fncls__2940d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A_fn_class = fncls__2940d; tmp3 = fncls__2940d } else { tmp3 = fncls__2940 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_2873 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_2870 == nil { by_path__7 = ifn_2871.Invoke_O_O__O(arg_2872, arg_2873) } else { by_path__7 = linked_2870.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2869, arg_2872, arg_2873) }
//line :453:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_190.GetRawRoot__O()); var tmp5 any; var root_2949 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, A_arbace_go_check_session_A_fn_class); var ifn_2951 lang.IFn



	if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__2960 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A_fn_class; if fncls__2960 == nil { var fncls__2960d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A_fn_class = fncls__2960d; tmp7 = fncls__2960d } else { tmp7 = fncls__2960 }; arg_2952 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2950 == nil { tmp5 = ifn_2951.Invoke_O__O(arg_2952) } else { tmp5 = linked_2950.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2949, arg_2952) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_232; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_240; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__2966 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A_fn_class; if fncls__2966 == nil { var fncls__2966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A_fn_class = fncls__2966d; tmp13 = fncls__2966d } else { tmp13 = fncls__2966 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_2967 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__3085 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A_fn_class; if fncls__3085 == nil { var fncls__3085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A_fn_class = fncls__3085d; tmp15 = fncls__3085d } else { tmp15 = fncls__3085 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_3086 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any = A_arbace_go_check_A_const_290.GetRawRoot__O(); var arg_3090 any = by_path__7; if linked_3087 == nil { tmp17 = ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { tmp17 = linked_3087.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) }; arg_2970 = tmp16.Invoke_O__O(tmp17); if linked_2968 == nil { tmp1 = ifn_2969.Invoke_O__O(arg_2970) } else { tmp1 = linked_2968.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2967, arg_2970) } }; return nil }(); if /*line :453:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_3091 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3091, A_arbace_go_check_error_result_A_fn_class); var ifn_3093 lang.IFn












		if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = tdir__3; var arg_3095 any = ex__7; if linked_3092 == nil { tmp19 = ifn_3093.Invoke_O_O__O(arg_3094, arg_3095) } else { tmp19 = linked_3092.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3091, arg_3094, arg_3095) }
//line :453:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A_New() *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A{}; t.Ctor(); return t }
//line :455:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A) Ctor() {}
//line :455:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A) Invoke_O_O__O(self, s__1685000325__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A_New_O_O(s__1685000325__1, self); var tmp2 *jrt.Class; var fncls__2939 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A_fn_class; if fncls__2939 == nil { var fncls__2939d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A_fn_class = fncls__2939d; tmp2 = fncls__2939d } else { tmp2 = fncls__2939 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :455:1
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :455:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A) Ctor_O_O(c__s__1685000325, c__iter__1685000324 any) { t.F_s__1685000325 = c__s__1685000325; t.F_iter__1685000324 = c__iter__1685000324 }
//line :455:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A) Invoke_O__O(self any) any { { var s__1685000325__1 any; var t_ any = t.F_s__1685000325; t.F_s__1685000325 = nil; s__1685000325__1 = t_; for { var temp__1927000414__auto____2 any; var root_2874 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any = s__1685000325__1; if linked_2875 == nil { temp__1927000414__auto____2 = ifn_2876.Invoke_O__O(arg_2877) } else { temp__1927000414__auto____2 = linked_2875.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2874, arg_2877) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000325__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2878 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2880 lang.IFn; if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = s__1685000325__3; if linked_2879 == nil { tmp1 = ifn_2880.Invoke_O__O(arg_2881) } else { tmp1 = linked_2879.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2878, arg_2881) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2882 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2882, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2884 lang.IFn; if linked_2883 == nil { ifn_2884 = lang.IFn_Cast(root_2882) } else { ifn_2884 = nil }; var arg_2885 any = s__1685000325__3; if linked_2883 == nil { c__1927001037__auto____4 = ifn_2884.Invoke_O__O(arg_2885) } else { c__1927001037__auto____4 = linked_2883.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2882, arg_2885) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000327__6 any; var root_2886 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2887 == nil { b__1685000327__6 = ifn_2888.Invoke_O__O(arg_2889) } else { b__1685000327__6 = linked_2887.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2886, arg_2889) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A_New_O_I_O(b__1685000327__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2899 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A_fn_class; if fncls__2899 == nil { var fncls__2899d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A_fn_class = fncls__2899d; tmp3 = fncls__2899d } else { tmp3 = fncls__2899 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2900 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2902 lang.IFn; if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var arg_2903 any; var root_2905 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2907 lang.IFn; if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any = b__1685000327__6; if linked_2906 == nil { arg_2903 = ifn_2907.Invoke_O__O(arg_2908) } else { arg_2903 = linked_2906.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2905, arg_2908) }; var arg_2904 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000324); var tmp5 any; var root_2909 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2909, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2911 lang.IFn; if linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var arg_2912 any = s__1685000325__3; if linked_2910 == nil { tmp5 = ifn_2911.Invoke_O__O(arg_2912) } else { tmp5 = linked_2910.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2909, arg_2912) }; arg_2904 = tmp4.Invoke_O__O(tmp5); if linked_2901 == nil { return ifn_2902.Invoke_O_O__O(arg_2903, arg_2904) } else { return linked_2901.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2900, arg_2903, arg_2904) } } else { var root_2913 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2913, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2915 lang.IFn; if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any; var root_2918 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2918, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2920 lang.IFn; if linked_2919 == nil { ifn_2920 = lang.IFn_Cast(root_2918) } else { ifn_2920 = nil }; var arg_2921 any = b__1685000327__6; if linked_2919 == nil { arg_2916 = ifn_2920.Invoke_O__O(arg_2921) } else { arg_2916 = linked_2919.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2918, arg_2921) }; var arg_2917 any; if linked_2914 == nil { return ifn_2915.Invoke_O_O__O(arg_2916, arg_2917) } else { return linked_2914.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2913, arg_2916, arg_2917) } } } else { var pf__4 any; var root_2922 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2922, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2924 lang.IFn; if linked_2923 == nil { ifn_2924 = lang.IFn_Cast(root_2922) } else { ifn_2924 = nil }; var arg_2925 any = s__1685000325__3; if linked_2923 == nil { pf__4 = ifn_2924.Invoke_O__O(arg_2925) } else { pf__4 = linked_2923.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2922, arg_2925) }; var root_2926 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_2927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2926, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2928 lang.IFn; if linked_2927 == nil { ifn_2928 = lang.IFn_Cast(root_2926) } else { ifn_2928 = nil }; var arg_2929 any; var tmp6 any; var root_2931 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2931, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2933 lang.IFn; if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any = pf__4; if linked_2932 == nil { tmp6 = ifn_2933.Invoke_O__O(arg_2934) } else { tmp6 = linked_2932.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2931, arg_2934) }; arg_2929 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_2930 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000324); var tmp8 any; var root_2935 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2935, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2937 lang.IFn; if linked_2936 == nil { ifn_2937 = lang.IFn_Cast(root_2935) } else { ifn_2937 = nil }; var arg_2938 any = s__1685000325__3; if linked_2936 == nil { tmp8 = ifn_2937.Invoke_O__O(arg_2938) } else { tmp8 = linked_2936.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2935, arg_2938) }; arg_2930 = tmp7.Invoke_O__O(tmp8); if linked_2927 == nil { return ifn_2928.Invoke_O_O__O(arg_2929, arg_2930) } else { return linked_2927.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2926, arg_2929, arg_2930) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :455:1
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :455:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A) Ctor_O_I_O(c__b__1685000327 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000327 = c__b__1685000327; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :455:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A) Invoke_O__O(self any) any { { var i__1685000326__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000326__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000326__1)); var root_2890 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2890, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2892 lang.IFn; if linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var arg_2893 any = t.F_b__1685000327; var arg_2894 any; var tmp2 any; var root_2895 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = pf__2; if linked_2896 == nil { tmp2 = ifn_2897.Invoke_O__O(arg_2898) } else { tmp2 = linked_2896.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2895, arg_2898) }; arg_2894 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_2891 == nil { ifn_2892.Invoke_O_O__O(arg_2893, arg_2894) } else { linked_2891.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2890, arg_2893, arg_2894) }; i__1685000326__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000326__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :457:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :457:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_2953 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2955 lang.IFn
																	if linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = t.F_root; var arg_2957 any = path__1; var arg_2958 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_cc); var arg_2959 any = pf__4; if linked_2954 == nil { return ifn_2955.Invoke_O_O_O_O__O(arg_2956, arg_2957, arg_2958, arg_2959) } else { return linked_2954.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2953, arg_2956, arg_2957, arg_2958, arg_2959) } } else {
//line :458:1
			return nil } }
//line :457:1
func A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A{}; t.Ctor_O(p0); return t }
//line :457:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :457:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A) Invoke_O_O__O(self, p1__1685000295_SHARP___1 any) any {


	var root_2961 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_2962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2961, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2963 lang.IFn; if linked_2962 == nil { ifn_2963 = lang.IFn_Cast(root_2961) } else { ifn_2963 = nil }; var arg_2964 any = t.F_by_path; var arg_2965 any = p1__1685000295_SHARP___1; if linked_2962 == nil { return ifn_2963.Invoke_O_O__O(arg_2964, arg_2965) } else { return linked_2962.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2961, arg_2964, arg_2965) } }
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A) Invoke_O_O__O(self, s__1685000339__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O(self, t.F_dir, t.F_tdir, t.F_ts, s__1685000339__1); var tmp2 *jrt.Class; var fncls__3084 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A_fn_class; if fncls__3084 == nil { var fncls__3084d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A_fn_class = fncls__3084d; tmp2 = fncls__3084d } else { tmp2 = fncls__3084 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :461:1
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A) Ctor_O_O_O_O_O(c__iter__1685000338, c__dir, c__tdir, c__ts, c__s__1685000339 any) { t.F_iter__1685000338 = c__iter__1685000338; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1685000339 = c__s__1685000339 }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A) Invoke_O__O(self any) any { { var s__1685000339__1 any; var t_ any = t.F_s__1685000339; t.F_s__1685000339 = nil; s__1685000339__1 = t_; for { var temp__1927000414__auto____2 any; var root_2971 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any = s__1685000339__1; if linked_2972 == nil { temp__1927000414__auto____2 = ifn_2973.Invoke_O__O(arg_2974) } else { temp__1927000414__auto____2 = linked_2972.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2971, arg_2974) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000339__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2975 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2975, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2977 lang.IFn; if linked_2976 == nil { ifn_2977 = lang.IFn_Cast(root_2975) } else { ifn_2977 = nil }; var arg_2978 any = s__1685000339__3; if linked_2976 == nil { tmp1 = ifn_2977.Invoke_O__O(arg_2978) } else { tmp1 = linked_2976.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2975, arg_2978) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2979 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2979, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2981 lang.IFn; if linked_2980 == nil { ifn_2981 = lang.IFn_Cast(root_2979) } else { ifn_2981 = nil }; var arg_2982 any = s__1685000339__3; if linked_2980 == nil { c__1927001037__auto____4 = ifn_2981.Invoke_O__O(arg_2982) } else { c__1927001037__auto____4 = linked_2980.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2979, arg_2982) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000341__6 any; var root_2983 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2983, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2985 lang.IFn; if linked_2984 == nil { ifn_2985 = lang.IFn_Cast(root_2983) } else { ifn_2985 = nil }; var arg_2986 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2984 == nil { b__1685000341__6 = ifn_2985.Invoke_O__O(arg_2986) } else { b__1685000341__6 = linked_2984.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2983, arg_2986) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_I_O_O(t.F_dir, t.F_tdir, t.F_ts, size__1927001038__auto____5, b__1685000341__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3020 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class; if fncls__3020 == nil { var fncls__3020d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class = fncls__3020d; tmp3 = fncls__3020d } else { tmp3 = fncls__3020 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3021 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3023 lang.IFn; if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any; var root_3026 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3026, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3028 lang.IFn; if linked_3027 == nil { ifn_3028 = lang.IFn_Cast(root_3026) } else { ifn_3028 = nil }; var arg_3029 any = b__1685000341__6; if linked_3027 == nil { arg_3024 = ifn_3028.Invoke_O__O(arg_3029) } else { arg_3024 = linked_3027.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3026, arg_3029) }; var arg_3025 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp5 any; var root_3030 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3030, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3032 lang.IFn; if linked_3031 == nil { ifn_3032 = lang.IFn_Cast(root_3030) } else { ifn_3032 = nil }; var arg_3033 any = s__1685000339__3; if linked_3031 == nil { tmp5 = ifn_3032.Invoke_O__O(arg_3033) } else { tmp5 = linked_3031.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3030, arg_3033) }; arg_3025 = tmp4.Invoke_O__O(tmp5); if linked_3022 == nil { return ifn_3023.Invoke_O_O__O(arg_3024, arg_3025) } else { return linked_3022.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3021, arg_3024, arg_3025) } } else { var root_3034 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3036 lang.IFn; if linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any; var root_3039 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3041 lang.IFn; if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any = b__1685000341__6; if linked_3040 == nil { arg_3037 = ifn_3041.Invoke_O__O(arg_3042) } else { arg_3037 = linked_3040.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3039, arg_3042) }; var arg_3038 any; if linked_3035 == nil { return ifn_3036.Invoke_O_O__O(arg_3037, arg_3038) } else { return linked_3035.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3034, arg_3037, arg_3038) } } } else { var vec__1685000351__4 any; var root_3043 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3043, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3045 lang.IFn; if linked_3044 == nil { ifn_3045 = lang.IFn_Cast(root_3043) } else { ifn_3045 = nil }; var arg_3046 any = s__1685000339__3; if linked_3044 == nil { vec__1685000351__4 = ifn_3045.Invoke_O__O(arg_3046) } else { vec__1685000351__4 = linked_3044.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3043, arg_3046) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000351__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000351__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3047 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3047, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3049 lang.IFn; _ = pf__6; if linked_3048 == nil { ifn_3049 = lang.IFn_Cast(root_3047) } else { ifn_3049 = nil }; var arg_3050 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3079 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A_fn_class
																if fncls__3079 == nil { var fncls__3079d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A_fn_class = fncls__3079d; tmp7 = fncls__3079d } else { tmp7 = fncls__3079 }; arg_3050 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :461:1
	var arg_3051 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp9 any; var root_3080 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3080, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3082 lang.IFn; if linked_3081 == nil { ifn_3082 = lang.IFn_Cast(root_3080) } else { ifn_3082 = nil }; var arg_3083 any = s__1685000339__3; if linked_3081 == nil { tmp9 = ifn_3082.Invoke_O__O(arg_3083) } else { tmp9 = linked_3081.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3080, arg_3083) }; arg_3051 = tmp8.Invoke_O__O(tmp9); if linked_3048 == nil { return ifn_3049.Invoke_O_O__O(arg_3050, arg_3051) } else { return linked_3048.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3047, arg_3050, arg_3051) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :461:1
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Ctor_O_O_O_I_O_O(c__dir, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__b__1685000341, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000341 = c__b__1685000341; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :461:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Invoke_O__O(self any) any { { var i__1685000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000345__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000340__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000345__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000345__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2987 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2987, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2989 lang.IFn; _ = pf__4; if linked_2988 == nil { ifn_2989 = lang.IFn_Cast(root_2987) } else { ifn_2989 = nil }; var arg_2990 any = t.F_b__1685000341; var arg_2991 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3019 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A_fn_class
																		if fncls__3019 == nil { var fncls__3019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A_fn_class = fncls__3019d; tmp3 = fncls__3019d } else { tmp3 = fncls__3019 }; arg_2991 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :461:1
	if linked_2988 == nil { ifn_2989.Invoke_O_O__O(arg_2990, arg_2991) } else { linked_2988.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2987, arg_2990, arg_2991) }; i__1685000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :462:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :462:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_2992 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any; var or__1927000174__auto____3 any; var root_2998 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2998, A_arbace_go_check_result_of_A_fn_class); var ifn_3000 lang.IFn; if linked_2999 == nil { ifn_3000 = lang.IFn_Cast(root_2998) } else { ifn_3000 = nil }; var arg_3001 any; var root_3002 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_3003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3002, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3004 lang.IFn; if linked_3003 == nil { ifn_3004 = lang.IFn_Cast(root_3002) } else { ifn_3004 = nil }; var arg_3005 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3005 = t_; var arg_3006 any = t.F_path; var arg_3007 any; var arg_3008 any = lang.PersistentVector_EMPTY.Ref(); if linked_3003 == nil { arg_3001 = ifn_3004.Invoke_O_O_O_O__O(arg_3005, arg_3006, arg_3007, arg_3008) } else { arg_3001 = linked_3003.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3002, arg_3005, arg_3006, arg_3007, arg_3008) }; if linked_2999 == nil { or__1927000174__auto____3 = ifn_3000.Invoke_O__O(arg_3001) } else { or__1927000174__auto____3 = linked_2999.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2998, arg_3001) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_2995 = or__1927000174__auto____3 } else { arg_2995 = A_arbace_go_check_A_const_288 }; var arg_2996 any = A_arbace_go_check_A_const_104; var arg_2997 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp3 any; var root_3009 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_3010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3009, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3011 lang.IFn
																					if linked_3010 == nil { ifn_3011 = lang.IFn_Cast(root_3009) } else { ifn_3011 = nil }; var arg_3012 any = t.F_tdir; var arg_3013 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3013 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3010 == nil { tmp3 = ifn_3011.Invoke_O_O__O(arg_3012, arg_3013) } else { tmp3 = linked_3010.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3009, arg_3012, arg_3013) }; arg_2997 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :463:1
		if linked_2993 == nil { tmp1 = ifn_2994.Invoke_O_O_O__O(arg_2995, arg_2996, arg_2997) } else { tmp1 = linked_2993.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2992, arg_2995, arg_2996, arg_2997) } }
//line :462:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3014 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3014, A_arbace_go_check_error_result_A_fn_class); var ifn_3016 lang.IFn


		if linked_3015 == nil { ifn_3016 = lang.IFn_Cast(root_3014) } else { ifn_3016 = nil }; var arg_3017 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3017 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3018 any = ex__3; if linked_3015 == nil { tmp1 = ifn_3016.Invoke_O_O__O(arg_3017, arg_3018) } else { tmp1 = linked_3015.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3014, arg_3017, arg_3018) } } }; return tmp1 }
//line :462:1
func A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :462:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :462:1
func (t *A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3052 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3052, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3054 lang.IFn; if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any; var or__1927000174__auto____3 any; var root_3058 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, A_arbace_go_check_result_of_A_fn_class); var ifn_3060 lang.IFn; if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any; var root_3062 any = A_arbace_go_check_A_const_236.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3064 lang.IFn; if linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3065 = t_; var arg_3066 any = t.F_path; var arg_3067 any; var arg_3068 any = lang.PersistentVector_EMPTY.Ref(); if linked_3063 == nil { arg_3061 = ifn_3064.Invoke_O_O_O_O__O(arg_3065, arg_3066, arg_3067, arg_3068) } else { arg_3061 = linked_3063.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3062, arg_3065, arg_3066, arg_3067, arg_3068) }; if linked_3059 == nil { or__1927000174__auto____3 = ifn_3060.Invoke_O__O(arg_3061) } else { or__1927000174__auto____3 = linked_3059.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3058, arg_3061) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3055 = or__1927000174__auto____3 } else { arg_3055 = A_arbace_go_check_A_const_289 }; var arg_3056 any = A_arbace_go_check_A_const_104; var arg_3057 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp3 any; var root_3069 any = A_arbace_go_check_A_const_283.GetRawRoot__O(); var linked_3070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3069, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3071 lang.IFn
																			if linked_3070 == nil { ifn_3071 = lang.IFn_Cast(root_3069) } else { ifn_3071 = nil }; var arg_3072 any = t.F_tdir; var arg_3073 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3073 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3070 == nil { tmp3 = ifn_3071.Invoke_O_O__O(arg_3072, arg_3073) } else { tmp3 = linked_3070.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3069, arg_3072, arg_3073) }; arg_3057 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :463:1
		if linked_3053 == nil { tmp1 = ifn_3054.Invoke_O_O_O__O(arg_3055, arg_3056, arg_3057) } else { tmp1 = linked_3053.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3052, arg_3055, arg_3056, arg_3057) } }
//line :462:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3074 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3074, A_arbace_go_check_error_result_A_fn_class); var ifn_3076 lang.IFn


		if linked_3075 == nil { ifn_3076 = lang.IFn_Cast(root_3074) } else { ifn_3076 = nil }; var arg_3077 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3077 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3078 any = ex__3; if linked_3075 == nil { tmp1 = ifn_3076.Invoke_O_O__O(arg_3077, arg_3078) } else { tmp1 = linked_3075.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3074, arg_3077, arg_3078) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :469:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3102 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_3103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3102, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3104 lang.IFn; if


	linked_3103 == nil { ifn_3104 = lang.IFn_Cast(root_3102) } else { ifn_3104 = nil }; var arg_3105 any = A_arbace_go_check_A_const_280; var arg_3106 any = results__1; if linked_3103 == nil { rs__3 = ifn_3104.Invoke_O_O__O(arg_3105, arg_3106) } else { rs__3 = linked_3103.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3102, arg_3105, arg_3106) }; var sum__4 any; var tmp1 any = /*line :469:1*/A_arbace_go_check_summarize_sum__1685000366_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3118 *jrt.Class = A_arbace_go_check_summarize_sum__1685000366_A_fn_class; if



	fncls__3118 == nil { var fncls__3118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_summarize_sum__1685000366_A_fn_class = fncls__3118d; tmp2 = fncls__3118d } else { tmp2 = fncls__3118 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :469:1*/A_arbace_go_check_summarize_msum__1685000368_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__3131 *jrt.Class = A_arbace_go_check_summarize_msum__1685000368_A_fn_class; if




	fncls__3131 == nil { var fncls__3131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_summarize_msum__1685000368_A_fn_class = fncls__3131d; tmp4 = fncls__3131d } else { tmp4 = fncls__3131 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_260; var tmp6 any = A_arbace_go_check_A_const_291; var tmp7 any = /*line :469:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_292; var tmp9 any = A_arbace_go_check_A_const_293; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_82); var tmp11 any = A_arbace_go_check_A_const_151; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_151); var tmp13 any = A_arbace_go_check_A_const_137; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_142); var tmp15 any = A_arbace_go_check_A_const_140; var tmp16 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_140); var tmp17 any = A_arbace_go_check_A_const_132; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_143))); var tmp19 any = A_arbace_go_check_A_const_208; var tmp20 lang.IFn = lang.IFn_Cast(sum__4); var tmp21 any = A_arbace_go_check_summarize_fn__1685000370_A_New(); var tmp22 *jrt.Class; var fncls__3214 *jrt.Class = A_arbace_go_check_summarize_fn__1685000370_A_fn_class; if












	fncls__3214 == nil { var fncls__3214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_summarize_fn__1685000370_A_fn_class = fncls__3214d; tmp22 = fncls__3214d } else { tmp22 = fncls__3214 }; var tmp23 any = /*line :469:1*/tmp20.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil)); var tmp24 any = A_arbace_go_check_A_const_294; var tmp25 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_212); var tmp26 any = A_arbace_go_check_A_const_295; var tmp27 any; var root_3132 any = A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3134 lang.IFn; if














	linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any; var tmp28 any = A_arbace_go_check_summarize_fn__1685000372_A_New(); var tmp29 *jrt.Class; var fncls__3137 *jrt.Class = A_arbace_go_check_summarize_fn__1685000372_A_fn_class; if fncls__3137 == nil { var fncls__3137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_go_check_summarize_fn__1685000372_A_fn_class = fncls__3137d; tmp29 = fncls__3137d } else { tmp29 = fncls__3137 }; arg_3135 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_3136 any = rs__3; if linked_3133 == nil { tmp27 = ifn_3134.Invoke_O_O__O(arg_3135, arg_3136) } else { tmp27 = linked_3133.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3132, arg_3135, arg_3136) }; var tmp30 any = /*line :469:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref(); var tmp31 any = A_arbace_go_check_A_const_297; var tmp32 any; var root_3138 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_3139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3138, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3140 lang.IFn; if















	linked_3139 == nil { ifn_3140 = lang.IFn_Cast(root_3138) } else { ifn_3140 = nil }; var arg_3141 any; var root_3142 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_3143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3142, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3144 lang.IFn; if linked_3143 == nil { ifn_3144 = lang.IFn_Cast(root_3142) } else { ifn_3144 = nil }; var arg_3145 any; var tmp33 any = A_arbace_go_check_summarize_fn__1685000374_A_New(); var tmp34 *jrt.Class; var fncls__3147 *jrt.Class = A_arbace_go_check_summarize_fn__1685000374_A_fn_class; if fncls__3147 == nil { var fncls__3147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_go_check_summarize_fn__1685000374_A_fn_class = fncls__3147d; tmp34 = fncls__3147d } else { tmp34 = fncls__3147 }; arg_3145 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3146 any = rs__3; if linked_3143 == nil { arg_3141 = ifn_3144.Invoke_O_O__O(arg_3145, arg_3146) } else { arg_3141 = linked_3143.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3142, arg_3145, arg_3146) }; if linked_3139 == nil { tmp32 = ifn_3140.Invoke_O__O(arg_3141) } else { tmp32 = linked_3139.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3138, arg_3141) }; var tmp35 any = tmp32; var tmp36 any = A_arbace_go_check_A_const_298; var tmp37 any = A_arbace_go_check_A_const_127; var tmp38 any; var root_3148 any = /*line :469:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3150 lang.IFn; if
















	linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any = lang.IFn_Cast(A_arbace_go_check_A_const_299.GetRawRoot__O()).Invoke__O(); var arg_3152 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_127); if linked_3149 == nil { tmp38 = ifn_3150.Invoke_O_O__O(arg_3151, arg_3152) } else { tmp38 = linked_3149.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3148, arg_3151, arg_3152) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_go_check_A_const_152; var tmp41 any; var root_3156 any = /*line :469:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3158 lang.IFn; if

















	linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any = lang.IFn_Cast(A_arbace_go_check_A_const_299.GetRawRoot__O()).Invoke__O(); var arg_3160 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_152); if linked_3157 == nil { tmp41 = ifn_3158.Invoke_O_O__O(arg_3159, arg_3160) } else { tmp41 = linked_3157.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3156, arg_3159, arg_3160) }; var tmp42 any = tmp41; var tmp43 any = A_arbace_go_check_A_const_153; var tmp44 any; var root_3164 any = /*line :469:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3164, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3166 lang.IFn; if


















	linked_3165 == nil { ifn_3166 = lang.IFn_Cast(root_3164) } else { ifn_3166 = nil }; var arg_3167 any = lang.IFn_Cast(A_arbace_go_check_A_const_299.GetRawRoot__O()).Invoke__O(); var arg_3168 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_153); if linked_3165 == nil { tmp44 = ifn_3166.Invoke_O_O__O(arg_3167, arg_3168) } else { tmp44 = linked_3165.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3164, arg_3167, arg_3168) }; var tmp45 any = tmp44; var tmp46 any = A_arbace_go_check_A_const_300; var tmp47 any; var root_3172 any = /*line :469:1*/A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3172, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3174 lang.IFn; if



















	linked_3173 == nil { ifn_3174 = lang.IFn_Cast(root_3172) } else { ifn_3174 = nil }; var arg_3175 any = lang.IFn_Cast(A_arbace_go_check_A_const_299.GetRawRoot__O()).Invoke__O(); var arg_3176 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_144); if linked_3173 == nil { tmp47 = ifn_3174.Invoke_O_O__O(arg_3175, arg_3176) } else { tmp47 = linked_3173.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3172, arg_3175, arg_3176) }; var tmp48 any = tmp47; var tmp49 any = A_arbace_go_check_A_const_213; var tmp50 any = A_arbace_go_check_A_const_291; var tmp51 any; var root_3180 any = /*line :469:1*/A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_3181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3180, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3182 lang.IFn; if




















	linked_3181 == nil { ifn_3182 = lang.IFn_Cast(root_3180) } else { ifn_3182 = nil }; var arg_3183 any; var tmp52 any = A_arbace_go_check_summarize_fn__1685000376_A_New(); var tmp53 *jrt.Class; var fncls__3190 *jrt.Class = A_arbace_go_check_summarize_fn__1685000376_A_fn_class; if fncls__3190 == nil { var fncls__3190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_check_summarize_fn__1685000376_A_fn_class = fncls__3190d; tmp53 = fncls__3190d } else { tmp53 = fncls__3190 }; arg_3183 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); var arg_3184 any = rs__3; if linked_3181 == nil { tmp51 = ifn_3182.Invoke_O_O__O(arg_3183, arg_3184) } else { tmp51 = linked_3181.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3180, arg_3183, arg_3184) }; var tmp54 any = /*line :469:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp51)).Ref(); var tmp55 any = A_arbace_go_check_A_const_302; var tmp56 lang.IFn = lang.IFn_Cast(sum__4); var tmp57 any = A_arbace_go_check_summarize_fn__1685000378_A_New(); var tmp58 *jrt.Class; var fncls__3221 *jrt.Class = A_arbace_go_check_summarize_fn__1685000378_A_fn_class; if





















	fncls__3221 == nil { var fncls__3221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_summarize_fn__1685000378_A_fn_class = fncls__3221d; tmp58 = fncls__3221d } else { tmp58 = fncls__3221 }; var tmp59 any = /*line :469:1*/tmp56.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil)); var tmp60 any = A_arbace_go_check_A_const_303; var tmp61 any; var root_3191 any = A_arbace_go_check_A_const_296.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3193 lang.IFn; if






















	linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any; var tmp62 any = A_arbace_go_check_summarize_fn__1685000380_A_New(); var tmp63 *jrt.Class; var fncls__3205 *jrt.Class = A_arbace_go_check_summarize_fn__1685000380_A_fn_class; if fncls__3205 == nil { var fncls__3205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_summarize_fn__1685000380_A_fn_class = fncls__3205d; tmp63 = fncls__3205d } else { tmp63 = fncls__3205 }; arg_3194 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil); var arg_3195 any = rs__3; if linked_3192 == nil { tmp61 = ifn_3193.Invoke_O_O__O(arg_3194, arg_3195) } else { tmp61 = linked_3192.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3191, arg_3194, arg_3195) }; var tmp64 any = /*line :469:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, tmp40, tmp42, tmp43, tmp45, tmp46, tmp48, tmp49, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp54, tmp55, tmp59, tmp60, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp61)).Ref())))); var tmp65 any = A_arbace_go_check_A_const_132; var tmp66 any; var root_3206 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3206, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3208 lang.IFn; if























	linked_3207 == nil { ifn_3208 = lang.IFn_Cast(root_3206) } else { ifn_3208 = nil }; var arg_3209 any = lang.IFn_Cast(A_arbace_go_check_A_const_299.GetRawRoot__O()).Invoke__O(); var arg_3210 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_132); if linked_3207 == nil { tmp66 = ifn_3208.Invoke_O_O__O(arg_3209, arg_3210) } else { tmp66 = linked_3207.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3206, arg_3209, arg_3210) }; return /*line :469:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp18, tmp19, tmp23, tmp24, tmp25, tmp26, tmp30, tmp31, tmp35, tmp36, tmp64, tmp65, tmp66)) }



func A_arbace_go_check_summarize_sum__1685000366_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000366_A{}; t.Ctor_O(p0); return t }
//line :473:1
func (t *A_arbace_go_check_summarize_sum__1685000366_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :473:1
func (t *A_arbace_go_check_summarize_sum__1685000366_A) Invoke_O_O__O(self, k__1 any) any { var root_3107 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3107, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3109 lang.IFn; if linked_3108 == nil { ifn_3109 = lang.IFn_Cast(root_3107) } else { ifn_3109 = nil }; var arg_3110 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3111 any = A_arbace_go_check_A_const_22; var arg_3112 any; var root_3113 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_3114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3113, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3115 lang.IFn; if linked_3114 == nil { ifn_3115 = lang.IFn_Cast(root_3113) } else { ifn_3115 = nil }; var arg_3116 any = k__1; var arg_3117 any = t.F_rs; if linked_3114 == nil { arg_3112 = ifn_3115.Invoke_O_O__O(arg_3116, arg_3117) } else { arg_3112 = linked_3114.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3113, arg_3116, arg_3117) }; if linked_3108 == nil { return ifn_3109.Invoke_O_O_O__O(arg_3110, arg_3111, arg_3112) } else { return linked_3108.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3107, arg_3110, arg_3111, arg_3112) } }
func A_arbace_go_check_summarize_msum__1685000368_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000368_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000368_A{}; t.Ctor_O(p0); return t }
//line :474:1
func (t *A_arbace_go_check_summarize_msum__1685000368_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :474:1
func (t *A_arbace_go_check_summarize_msum__1685000368_A) Invoke_O_O__O(self, k__1 any) any { var root_3119 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var arg_3123 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3124 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3125 any; var root_3126 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_3127 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3126, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3128 lang.IFn; if linked_3127 == nil { ifn_3128 = lang.IFn_Cast(root_3126) } else { ifn_3128 = nil }; var arg_3129 any = k__1; var arg_3130 any = t.F_rs; if linked_3127 == nil { arg_3125 = ifn_3128.Invoke_O_O__O(arg_3129, arg_3130) } else { arg_3125 = linked_3127.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3126, arg_3129, arg_3130) }; if linked_3120 == nil { return ifn_3121.Invoke_O_O_O_O__O(arg_3122, arg_3123, arg_3124, arg_3125) } else { return linked_3120.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3119, arg_3122, arg_3123, arg_3124, arg_3125) } }







func A_arbace_go_check_summarize_fn__1685000370_A_New() *A_arbace_go_check_summarize_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000370_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_go_check_summarize_fn__1685000370_A) Ctor() {}
//line :482:1
func (t *A_arbace_go_check_summarize_fn__1685000370_A) Invoke_O_O__O(self, p1__1685000360_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_208.Invoke_O__O(p1__1685000360_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000372_A_New() *A_arbace_go_check_summarize_fn__1685000372_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000372_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_go_check_summarize_fn__1685000372_A) Ctor() {}
//line :484:1
func (t *A_arbace_go_check_summarize_fn__1685000372_A) Invoke_O_O__O(self, p1__1685000361_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_270.Invoke_O__O(p1__1685000361_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000361_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000374_A_New() *A_arbace_go_check_summarize_fn__1685000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000374_A{}; t.Ctor(); return t }
//line :485:1
func (t *A_arbace_go_check_summarize_fn__1685000374_A) Ctor() {}
//line :485:1
func (t *A_arbace_go_check_summarize_fn__1685000374_A) Invoke_O_O__O(self, p1__1685000362_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_270.Invoke_O__O(p1__1685000362_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000362_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_104.Invoke_O__O(p1__1685000362_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000376_A_New() *A_arbace_go_check_summarize_fn__1685000376_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000376_A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_go_check_summarize_fn__1685000376_A) Ctor() {}
//line :490:1
func (t *A_arbace_go_check_summarize_fn__1685000376_A) Invoke_O_O__O(self, p1__1685000363_SHARP___1 any) any { var root_3185 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3185, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3187 lang.IFn; if linked_3186 == nil { ifn_3187 = lang.IFn_Cast(root_3185) } else { ifn_3187 = nil }; var arg_3188 any = p1__1685000363_SHARP___1; var arg_3189 any = A_arbace_go_check_A_const_301; if linked_3186 == nil { return ifn_3187.Invoke_O_O__O(arg_3188, arg_3189) } else { return linked_3186.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3185, arg_3188, arg_3189) } }
func A_arbace_go_check_summarize_fn__1685000378_A_New() *A_arbace_go_check_summarize_fn__1685000378_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000378_A{}; t.Ctor(); return t }
//line :491:1
func (t *A_arbace_go_check_summarize_fn__1685000378_A) Ctor() {}
//line :491:1
func (t *A_arbace_go_check_summarize_fn__1685000378_A) Invoke_O_O__O(self, p1__1685000364_SHARP___1 any) any { var root_3215 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3215, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3217 lang.IFn; if linked_3216 == nil { ifn_3217 = lang.IFn_Cast(root_3215) } else { ifn_3217 = nil }; var arg_3218 any = p1__1685000364_SHARP___1; var arg_3219 any = A_arbace_go_check_A_const_306; var arg_3220 any = A_arbace_go_check_A_const_22; if linked_3216 == nil { return ifn_3217.Invoke_O_O_O__O(arg_3218, arg_3219, arg_3220) } else { return linked_3216.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3215, arg_3218, arg_3219, arg_3220) } }
func A_arbace_go_check_summarize_fn__1685000380_A_New() *A_arbace_go_check_summarize_fn__1685000380_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000380_A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_go_check_summarize_fn__1685000380_A) Ctor() {}
//line :492:1
func (t *A_arbace_go_check_summarize_fn__1685000380_A) Invoke_O_O__O(self, p1__1685000365_SHARP___1 any) any { var root_3196 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3198 lang.IFn; if linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; var arg_3199 any; var root_3200 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3202 lang.IFn; if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any = p1__1685000365_SHARP___1; var arg_3204 any = A_arbace_go_check_A_const_305; if linked_3201 == nil { arg_3199 = ifn_3202.Invoke_O_O__O(arg_3203, arg_3204) } else { arg_3199 = linked_3201.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3200, arg_3203, arg_3204) }; if linked_3197 == nil { return ifn_3198.Invoke_O__O(arg_3199) } else { return linked_3197.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3196, arg_3199) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :495:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000383__1685000389_A_New(); var tmp2 *jrt.Class; var fncls__3307 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000383__1685000389_A_fn_class; if


	fncls__3307 == nil { var fncls__3307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_go_check_report_errors_iter__1685000383__1685000389_A_fn_class = fncls__3307d; tmp2 = fncls__3307d } else { tmp2 = fncls__3307 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :498:1
func A_arbace_go_check_report_errors_iter__1685000383__1685000389_A_New() *A_arbace_go_check_report_errors_iter__1685000383__1685000389_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000383__1685000389_A{}; t.Ctor(); return t }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_A) Ctor() {}
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_A) Invoke_O_O__O(self, s__1685000384__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A_New_O_O(s__1685000384__1, self); var tmp2 *jrt.Class; var fncls__3306 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A_fn_class; if fncls__3306 == nil { var fncls__3306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A_fn_class = fncls__3306d; tmp2 = fncls__3306d } else { tmp2 = fncls__3306 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :498:1
func A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A{}; t.Ctor_O_O(p0, p1); return t }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A) Ctor_O_O(c__s__1685000384, c__iter__1685000383 any) { t.F_s__1685000384 = c__s__1685000384; t.F_iter__1685000383 = c__iter__1685000383 }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A) Invoke_O__O(self any) any { { var s__1685000384__1 any; var t_ any = t.F_s__1685000384; t.F_s__1685000384 = nil; s__1685000384__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3222 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3224 lang.IFn; if linked_3223 == nil { ifn_3224 = lang.IFn_Cast(root_3222) } else { ifn_3224 = nil }; var arg_3225 any = s__1685000384__1; if linked_3223 == nil { temp__1927000414__auto____2 = ifn_3224.Invoke_O__O(arg_3225) } else { temp__1927000414__auto____2 = linked_3223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3222, arg_3225) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3226 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3228 lang.IFn; if linked_3227 == nil { ifn_3228 = lang.IFn_Cast(root_3226) } else { ifn_3228 = nil }; var arg_3229 any = xs__1927001018__auto____3; if linked_3227 == nil { r__4 = ifn_3228.Invoke_O__O(arg_3229) } else { r__4 = linked_3227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3226, arg_3229) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3288 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A_fn_class; if fncls__3288 == nil { var fncls__3288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A_fn_class = fncls__3288d; tmp2 = fncls__3288d } else { tmp2 = fncls__3288 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3289 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3291 lang.IFn; if linked_3290 == nil { ifn_3291 = lang.IFn_Cast(root_3289) } else { ifn_3291 = nil }; var arg_3292 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_208.Invoke_O__O(r__4)); if linked_3290 == nil { fs__1927001036__auto____6 = ifn_3291.Invoke_O__O(arg_3292) } else { fs__1927001036__auto____6 = linked_3290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3289, arg_3292) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3293 any = A_arbace_go_check_A_const_287.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3293, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3295 lang.IFn; if linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = fs__1927001036__auto____6; var arg_3297 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000383); var tmp4 any; var root_3298 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3300 lang.IFn; if linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any = s__1685000384__1; if linked_3299 == nil { tmp4 = ifn_3300.Invoke_O__O(arg_3301) } else { tmp4 = linked_3299.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3298, arg_3301) }; arg_3297 = tmp3.Invoke_O__O(tmp4); if linked_3294 == nil { return ifn_3295.Invoke_O_O__O(arg_3296, arg_3297) } else { return linked_3294.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3293, arg_3296, arg_3297) } } else { var tmp5 any; var root_3302 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3304 lang.IFn; if linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any = s__1685000384__1; if linked_3303 == nil { tmp5 = ifn_3304.Invoke_O__O(arg_3305) } else { tmp5 = linked_3303.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3302, arg_3305) }; s__1685000384__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :498:1
func A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A{}; t.Ctor_O(p0); return t }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A) Invoke_O_O__O(self, s__1685000386__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A_New_O_O_O(t.F_r, s__1685000386__1, self); var tmp2 *jrt.Class; var fncls__3287 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A_fn_class; if fncls__3287 == nil { var fncls__3287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A_fn_class = fncls__3287d; tmp2 = fncls__3287d } else { tmp2 = fncls__3287 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :498:1
func A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A) Ctor_O_O_O(c__r, c__s__1685000386, c__iter__1685000385 any) { t.F_r = c__r; t.F_s__1685000386 = c__s__1685000386; t.F_iter__1685000385 = c__iter__1685000385 }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A) Invoke_O__O(self any) any { { var s__1685000386__1 any; var t_ any = t.F_s__1685000386; t.F_s__1685000386 = nil; s__1685000386__1 = t_; for { var temp__1927000414__auto____2 any; var root_3230 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3230, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3232 lang.IFn; if linked_3231 == nil { ifn_3232 = lang.IFn_Cast(root_3230) } else { ifn_3232 = nil }; var arg_3233 any = s__1685000386__1; if linked_3231 == nil { temp__1927000414__auto____2 = ifn_3232.Invoke_O__O(arg_3233) } else { temp__1927000414__auto____2 = linked_3231.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3230, arg_3233) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000386__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3234 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3236 lang.IFn; if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = s__1685000386__3; if linked_3235 == nil { tmp1 = ifn_3236.Invoke_O__O(arg_3237) } else { tmp1 = linked_3235.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3234, arg_3237) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3238 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3238, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3240 lang.IFn; if linked_3239 == nil { ifn_3240 = lang.IFn_Cast(root_3238) } else { ifn_3240 = nil }; var arg_3241 any = s__1685000386__3; if linked_3239 == nil { c__1927001037__auto____4 = ifn_3240.Invoke_O__O(arg_3241) } else { c__1927001037__auto____4 = linked_3239.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3238, arg_3241) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000388__6 any; var root_3242 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3242, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3244 lang.IFn; if linked_3243 == nil { ifn_3244 = lang.IFn_Cast(root_3242) } else { ifn_3244 = nil }; var arg_3245 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3243 == nil { b__1685000388__6 = ifn_3244.Invoke_O__O(arg_3245) } else { b__1685000388__6 = linked_3243.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3242, arg_3245) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A_New_O_O_I_O(b__1685000388__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3251 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A_fn_class; if fncls__3251 == nil { var fncls__3251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A_fn_class = fncls__3251d; tmp3 = fncls__3251d } else { tmp3 = fncls__3251 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3252 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3252, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3254 lang.IFn; if linked_3253 == nil { ifn_3254 = lang.IFn_Cast(root_3252) } else { ifn_3254 = nil }; var arg_3255 any; var root_3257 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3257, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3259 lang.IFn; if linked_3258 == nil { ifn_3259 = lang.IFn_Cast(root_3257) } else { ifn_3259 = nil }; var arg_3260 any = b__1685000388__6; if linked_3258 == nil { arg_3255 = ifn_3259.Invoke_O__O(arg_3260) } else { arg_3255 = linked_3258.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3257, arg_3260) }; var arg_3256 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000385); var tmp5 any; var root_3261 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3261, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3263 lang.IFn; if linked_3262 == nil { ifn_3263 = lang.IFn_Cast(root_3261) } else { ifn_3263 = nil }; var arg_3264 any = s__1685000386__3; if linked_3262 == nil { tmp5 = ifn_3263.Invoke_O__O(arg_3264) } else { tmp5 = linked_3262.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3261, arg_3264) }; arg_3256 = tmp4.Invoke_O__O(tmp5); if linked_3253 == nil { return ifn_3254.Invoke_O_O__O(arg_3255, arg_3256) } else { return linked_3253.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3252, arg_3255, arg_3256) } } else { var root_3265 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3265, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3267 lang.IFn; if linked_3266 == nil { ifn_3267 = lang.IFn_Cast(root_3265) } else { ifn_3267 = nil }; var arg_3268 any; var root_3270 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3270, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3272 lang.IFn; if linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any = b__1685000388__6; if linked_3271 == nil { arg_3268 = ifn_3272.Invoke_O__O(arg_3273) } else { arg_3268 = linked_3271.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3270, arg_3273) }; var arg_3269 any; if linked_3266 == nil { return ifn_3267.Invoke_O_O__O(arg_3268, arg_3269) } else { return linked_3266.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3265, arg_3268, arg_3269) } } } else { var e__4 any; var root_3274 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3274, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3276 lang.IFn; if linked_3275 == nil { ifn_3276 = lang.IFn_Cast(root_3274) } else { ifn_3276 = nil }; var arg_3277 any = s__1685000386__3; if linked_3275 == nil { e__4 = ifn_3276.Invoke_O__O(arg_3277) } else { e__4 = linked_3275.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3274, arg_3277) }; var root_3278 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3278, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3280 lang.IFn; if linked_3279 == nil { ifn_3280 = lang.IFn_Cast(root_3278) } else { ifn_3280 = nil }; var arg_3281 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_23, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_271.Invoke_O__O(e__4))).Ref(); var arg_3282 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000385); var tmp7 any; var root_3283 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3285 lang.IFn; if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any = s__1685000386__3; if linked_3284 == nil { tmp7 = ifn_3285.Invoke_O__O(arg_3286) } else { tmp7 = linked_3284.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3283, arg_3286) }; arg_3282 = tmp6.Invoke_O__O(tmp7); if linked_3279 == nil { return ifn_3280.Invoke_O_O__O(arg_3281, arg_3282) } else { return linked_3279.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3278, arg_3281, arg_3282) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :498:1
func A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A) Ctor_O_O_I_O(c__b__1685000388, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000388 = c__b__1685000388; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :498:1
func (t *A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A) Invoke_O__O(self any) any { { var i__1685000387__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000387__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000387__1)); var root_3246 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3246, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3248 lang.IFn; if linked_3247 == nil { ifn_3248 = lang.IFn_Cast(root_3246) } else { ifn_3248 = nil }; var arg_3249 any = t.F_b__1685000388; var arg_3250 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_23, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_271.Invoke_O__O(e__2))).Ref(); if linked_3247 == nil { ifn_3248.Invoke_O_O__O(arg_3249, arg_3250) } else { linked_3247.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3246, arg_3249, arg_3250) }; i__1685000387__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000387__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :503:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000401__3 any; var root_3308 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3308, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3310 lang.IFn; if



	linked_3309 == nil { ifn_3310 = lang.IFn_Cast(root_3308) } else { ifn_3310 = nil }; var arg_3311 any = forms__0; if linked_3309 == nil { map__1685000401__3 = ifn_3310.Invoke_O__O(arg_3311) } else { map__1685000401__3 = linked_3309.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3308, arg_3311) }; var map__1685000401__4 any; if lang.ISeq_InstanceOf(map__1685000401__3) { var tmp1 any; var root_3312 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3312, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3314 lang.IFn; if linked_3313 == nil { ifn_3314 = lang.IFn_Cast(root_3312) } else { ifn_3314 = nil }; var arg_3315 any = map__1685000401__3; if linked_3313 == nil { tmp1 = ifn_3314.Invoke_O__O(arg_3315) } else { tmp1 = linked_3313.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3312, arg_3315) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3316 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3318 lang.IFn; if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any = map__1685000401__3; if linked_3317 == nil { tmp2 = ifn_3318.Invoke_O__O(arg_3319) } else { tmp2 = linked_3317.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3316, arg_3319) }; map__1685000401__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3320 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3322 lang.IFn; if linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any = map__1685000401__3; if linked_3321 == nil { tmp3 = ifn_3322.Invoke_O__O(arg_3323) } else { tmp3 = linked_3321.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3320, arg_3323) }; if jrt.J2g_Truth(tmp3) { var root_3324 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3326 lang.IFn; if linked_3325 == nil { ifn_3326 = lang.IFn_Cast(root_3324) } else { ifn_3326 = nil }; var arg_3327 any = map__1685000401__3; if linked_3325 == nil { map__1685000401__4 = ifn_3326.Invoke_O__O(arg_3327) } else { map__1685000401__4 = linked_3325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3324, arg_3327) } } else { map__1685000401__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000401__4 = map__1685000401__3 }; var package__5 any = /*line :503:1*/lang.RT_Get_O_O__O_NoInit(map__1685000401__4, A_arbace_go_check_A_const_103); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000401__4, A_arbace_go_check_A_const_70); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000401__4, A_arbace_go_check_A_const_114); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_308.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_309; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_105.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_104; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_104.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_107 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_70; var tmp10 any; var root_3334 any = /*line :503:1*/A_arbace_go_check_A_const_310.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3336 lang.IFn; if





	linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = name__6; if linked_3335 == nil { tmp10 = ifn_3336.Invoke_O__O(arg_3337) } else { tmp10 = linked_3335.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3334, arg_3337) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_105; var tmp13 any = A_arbace_go_check_A_const_81; var tmp14 any = A_arbace_go_check_A_const_203; var tmp15 any; var root_3338 any = /*line :503:1*/A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3338, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3340 lang.IFn; if






	linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var arg_3341 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000403_A_New(); var tmp17 *jrt.Class; var fncls__3355 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000403_A_fn_class; if fncls__3355 == nil { var fncls__3355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_check_forms_source_fn__1685000403_A_fn_class = fncls__3355d; tmp17 = fncls__3355d } else { tmp17 = fncls__3355 }; arg_3341 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3342 any = forms__0; if linked_3339 == nil { tmp15 = ifn_3340.Invoke_O_O__O(arg_3341, arg_3342) } else { tmp15 = linked_3339.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3338, arg_3341, arg_3342) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_114; var tmp20 any; var root_3356 any = /*line :503:1*/A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_3357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3356, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3358 lang.IFn; if







	linked_3357 == nil { ifn_3358 = lang.IFn_Cast(root_3356) } else { ifn_3358 = nil }; var arg_3359 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000405__1685000409_A_New(); var tmp22 *jrt.Class; var fncls__3430 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000405__1685000409_A_fn_class; if fncls__3430 == nil { var fncls__3430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_go_check_forms_source_iter__1685000405__1685000409_A_fn_class = fncls__3430d; tmp22 = fncls__3430d } else { tmp22 = fncls__3430 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3359 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3357 == nil { tmp20 = ifn_3358.Invoke_O__O(arg_3359) } else { tmp20 = linked_3357.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3356, arg_3359) }; return /*line :503:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000403_A_New() *A_arbace_go_check_forms_source_fn__1685000403_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000403_A{}; t.Ctor(); return t }
//line :510:1
func (t *A_arbace_go_check_forms_source_fn__1685000403_A) Ctor() {}
//line :510:1
func (t *A_arbace_go_check_forms_source_fn__1685000403_A) Invoke_O_O__O(self, p1__1685000400_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3343 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3345 lang.IFn; if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any = p1__1685000400_SHARP___1; if linked_3344 == nil { and__1927000168__auto____2 = ifn_3345.Invoke_O__O(arg_3346) } else { and__1927000168__auto____2 = linked_3344.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3343, arg_3346) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_311; var tmp3 any; var root_3347 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3349 lang.IFn; if linked_3348 == nil { ifn_3349 = lang.IFn_Cast(root_3347) } else { ifn_3349 = nil }; var arg_3350 any = p1__1685000400_SHARP___1; if linked_3348 == nil { tmp3 = ifn_3349.Invoke_O__O(arg_3350) } else { tmp3 = linked_3348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3347, arg_3350) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3351 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_3352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3351, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3353 lang.IFn; if linked_3352 == nil { ifn_3353 = lang.IFn_Cast(root_3351) } else { ifn_3353 = nil }; var arg_3354 any = p1__1685000400_SHARP___1; if linked_3352 == nil { return ifn_3353.Invoke_O__O(arg_3354) } else { return linked_3352.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3351, arg_3354) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000405__1685000409_A_New() *A_arbace_go_check_forms_source_iter__1685000405__1685000409_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000405__1685000409_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_go_check_forms_source_iter__1685000405__1685000409_A) Ctor() {}
//line :511:1
func (t *A_arbace_go_check_forms_source_iter__1685000405__1685000409_A) Invoke_O_O__O(self, s__1685000406__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A_New_O_O(self, s__1685000406__1); var tmp2 *jrt.Class; var fncls__3429 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A_fn_class; if fncls__3429 == nil { var fncls__3429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A_fn_class = fncls__3429d; tmp2 = fncls__3429d } else { tmp2 = fncls__3429 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :511:1
func A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A{}; t.Ctor_O_O(p0, p1); return t }
//line :511:1
func (t *A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A) Ctor_O_O(c__iter__1685000405, c__s__1685000406 any) { t.F_iter__1685000405 = c__iter__1685000405; t.F_s__1685000406 = c__s__1685000406 }
//line :511:1
func (t *A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A) Invoke_O__O(self any) any { { var s__1685000406__1 any; var t_ any = t.F_s__1685000406; t.F_s__1685000406 = nil; s__1685000406__1 = t_; for { var temp__1927000414__auto____2 any; var root_3360 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3360, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3362 lang.IFn; if linked_3361 == nil { ifn_3362 = lang.IFn_Cast(root_3360) } else { ifn_3362 = nil }; var arg_3363 any = s__1685000406__1; if linked_3361 == nil { temp__1927000414__auto____2 = ifn_3362.Invoke_O__O(arg_3363) } else { temp__1927000414__auto____2 = linked_3361.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3360, arg_3363) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000406__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3364 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3364, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3366 lang.IFn; if linked_3365 == nil { ifn_3366 = lang.IFn_Cast(root_3364) } else { ifn_3366 = nil }; var arg_3367 any = s__1685000406__3; if linked_3365 == nil { tmp1 = ifn_3366.Invoke_O__O(arg_3367) } else { tmp1 = linked_3365.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3364, arg_3367) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3368 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3368, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3370 lang.IFn; if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any = s__1685000406__3; if linked_3369 == nil { c__1927001037__auto____4 = ifn_3370.Invoke_O__O(arg_3371) } else { c__1927001037__auto____4 = linked_3369.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3368, arg_3371) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000408__6 any; var root_3372 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3372, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3374 lang.IFn; if linked_3373 == nil { ifn_3374 = lang.IFn_Cast(root_3372) } else { ifn_3374 = nil }; var arg_3375 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3373 == nil { b__1685000408__6 = ifn_3374.Invoke_O__O(arg_3375) } else { b__1685000408__6 = linked_3373.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3372, arg_3375) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A_New_O_I_O(b__1685000408__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3387 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A_fn_class; if fncls__3387 == nil { var fncls__3387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A_fn_class = fncls__3387d; tmp3 = fncls__3387d } else { tmp3 = fncls__3387 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3388 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3388, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3390 lang.IFn; if linked_3389 == nil { ifn_3390 = lang.IFn_Cast(root_3388) } else { ifn_3390 = nil }; var arg_3391 any; var root_3393 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3393, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3395 lang.IFn; if linked_3394 == nil { ifn_3395 = lang.IFn_Cast(root_3393) } else { ifn_3395 = nil }; var arg_3396 any = b__1685000408__6; if linked_3394 == nil { arg_3391 = ifn_3395.Invoke_O__O(arg_3396) } else { arg_3391 = linked_3394.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3393, arg_3396) }; var arg_3392 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000405); var tmp5 any; var root_3397 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3397, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3399 lang.IFn; if linked_3398 == nil { ifn_3399 = lang.IFn_Cast(root_3397) } else { ifn_3399 = nil }; var arg_3400 any = s__1685000406__3; if linked_3398 == nil { tmp5 = ifn_3399.Invoke_O__O(arg_3400) } else { tmp5 = linked_3398.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3397, arg_3400) }; arg_3392 = tmp4.Invoke_O__O(tmp5); if linked_3389 == nil { return ifn_3390.Invoke_O_O__O(arg_3391, arg_3392) } else { return linked_3389.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3388, arg_3391, arg_3392) } } else { var root_3401 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3403 lang.IFn; if linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; var arg_3404 any; var root_3406 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3406, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3408 lang.IFn; if linked_3407 == nil { ifn_3408 = lang.IFn_Cast(root_3406) } else { ifn_3408 = nil }; var arg_3409 any = b__1685000408__6; if linked_3407 == nil { arg_3404 = ifn_3408.Invoke_O__O(arg_3409) } else { arg_3404 = linked_3407.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3406, arg_3409) }; var arg_3405 any; if linked_3402 == nil { return ifn_3403.Invoke_O_O__O(arg_3404, arg_3405) } else { return linked_3402.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3401, arg_3404, arg_3405) } } } else { var fi__4 any; var root_3410 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3410, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3412 lang.IFn; if linked_3411 == nil { ifn_3412 = lang.IFn_Cast(root_3410) } else { ifn_3412 = nil }; var arg_3413 any = s__1685000406__3; if linked_3411 == nil { fi__4 = ifn_3412.Invoke_O__O(arg_3413) } else { fi__4 = linked_3411.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3410, arg_3413) }; var root_3414 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3416 lang.IFn; if linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any; var root_3419 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3419, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3421 lang.IFn; if linked_3420 == nil { ifn_3421 = lang.IFn_Cast(root_3419) } else { ifn_3421 = nil }; var arg_3422 any = fi__4; var arg_3423 any = A_arbace_go_check_A_const_81; var arg_3424 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__4); if linked_3420 == nil { arg_3417 = ifn_3421.Invoke_O_O_O__O(arg_3422, arg_3423, arg_3424) } else { arg_3417 = linked_3420.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3419, arg_3422, arg_3423, arg_3424) }; var arg_3418 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000405); var tmp7 any; var root_3425 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3427 lang.IFn; if linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any = s__1685000406__3; if linked_3426 == nil { tmp7 = ifn_3427.Invoke_O__O(arg_3428) } else { tmp7 = linked_3426.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3425, arg_3428) }; arg_3418 = tmp6.Invoke_O__O(tmp7); if linked_3415 == nil { return ifn_3416.Invoke_O_O__O(arg_3417, arg_3418) } else { return linked_3415.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3414, arg_3417, arg_3418) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :511:1
func A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :511:1
func (t *A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A) Ctor_O_I_O(c__b__1685000408 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000408 = c__b__1685000408; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :511:1
func (t *A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A) Invoke_O__O(self any) any { { var i__1685000407__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000407__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000407__1)); var root_3376 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3376, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3378 lang.IFn; if linked_3377 == nil { ifn_3378 = lang.IFn_Cast(root_3376) } else { ifn_3378 = nil }; var arg_3379 any = t.F_b__1685000408; var arg_3380 any; var root_3381 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3382 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3381, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3383 lang.IFn; if linked_3382 == nil { ifn_3383 = lang.IFn_Cast(root_3381) } else { ifn_3383 = nil }; var arg_3384 any = fi__2; var arg_3385 any = A_arbace_go_check_A_const_81; var arg_3386 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__2); if linked_3382 == nil { arg_3380 = ifn_3383.Invoke_O_O_O__O(arg_3384, arg_3385, arg_3386) } else { arg_3380 = linked_3382.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3381, arg_3384, arg_3385, arg_3386) }; if linked_3377 == nil { ifn_3378.Invoke_O_O__O(arg_3379, arg_3380) } else { linked_3377.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3376, arg_3379, arg_3380) }; i__1685000407__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000407__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :513:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3440 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3442 lang.IFn; if




	linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_313, jrt.Boolean_FALSE.Ref()); if linked_3441 == nil { ifn_3442.Invoke_O__O(arg_3443) } else { linked_3441.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3440, arg_3443) }; var tmp1 any; tmp3 := /*line :513:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3431 any = A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3433 lang.IFn






		if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any = r__2; var arg_3435 any = jrt.Boolean_FALSE.Ref(); var arg_3436 any = eof__3; if linked_3432 == nil { f__7 = ifn_3433.Invoke_O_O_O__O(arg_3434, arg_3435, arg_3436) } else { f__7 = linked_3432.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3431, arg_3434, arg_3435, arg_3436) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3449 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3449, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3451 lang.IFn; if linked_3450 == nil { ifn_3451 = lang.IFn_Cast(root_3449) } else { ifn_3451 = nil }; var arg_3452 any = acc__6; var arg_3453 any = f__7; if linked_3450 == nil { tmp2 = ifn_3451.Invoke_O_O__O(arg_3452, arg_3453) } else { tmp2 = linked_3450.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3449, arg_3452, arg_3453) }; acc__6 = tmp2; continue L1 }
//line :513:1
		break L1 } }; return nil }(); var root_3437 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3437, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3439 lang.IFn; if




	linked_3438 == nil { ifn_3439 = lang.IFn_Cast(root_3437) } else { ifn_3439 = nil }; if linked_3438 == nil { ifn_3439.Invoke__O() } else { linked_3438.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3437) }; if /*line :513:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :525:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :525:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3454 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3454, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3456 lang.IFn; if


	linked_3455 == nil { ifn_3456 = lang.IFn_Cast(root_3454) } else { ifn_3456 = nil }; var arg_3457 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); if linked_3455 == nil { tmp1 = ifn_3456.Invoke_O__O(arg_3457) } else { tmp1 = linked_3455.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3454, arg_3457) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3458 any = A_arbace_go_check_A_const_275.GetRawRoot__O(); var linked_3459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3458, A_arbace_go_check_std_session_A_fn_class); var ifn_3460 lang.IFn
		if linked_3459 == nil { ifn_3460 = lang.IFn_Cast(root_3458) } else { ifn_3460 = nil }; var arg_3461 any; var root_3462 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_3463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3462, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3464 lang.IFn; if linked_3463 == nil { ifn_3464 = lang.IFn_Cast(root_3462) } else { ifn_3464 = nil }; var arg_3465 any = corpus__0; if linked_3463 == nil { arg_3461 = ifn_3464.Invoke_O__O(arg_3465) } else { arg_3461 = linked_3463.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3462, arg_3465) }; if linked_3459 == nil { s__3 = ifn_3460.Invoke_O__O(arg_3461) } else { s__3 = linked_3459.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3458, arg_3461) }
		var root_3466 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_3467 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3466, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3468 lang.IFn; if linked_3467 == nil { ifn_3468 = lang.IFn_Cast(root_3466) } else { ifn_3468 = nil }; var arg_3469 any = A_arbace_go_check_A_const_314.GetRawRoot__O(); var arg_3470 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var arg_3471 any = corpus__0; var arg_3472 any = s__3; if linked_3467 == nil { ifn_3468.Invoke_O_O_O_O__O(arg_3469, arg_3470, arg_3471, arg_3472) } else { linked_3467.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3466, arg_3469, arg_3470, arg_3471, arg_3472) }
//line :528:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :533:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :533:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3473 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3473, A_arbace_go_check_std_A_fn_class); var ifn_3475 lang.IFn; if




	linked_3474 == nil { ifn_3475 = lang.IFn_Cast(root_3473) } else { ifn_3475 = nil }; var arg_3476 any = corpus__1; if linked_3474 == nil { s__4 = ifn_3475.Invoke_O__O(arg_3476) } else { s__4 = linked_3474.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3473, arg_3476) }; var src__5 any; var root_3477 any = /*line :533:1*/A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3477, A_arbace_go_check_forms_source_A_fn_class); var ifn_3479 lang.IFn; if





	linked_3478 == nil { ifn_3479 = lang.IFn_Cast(root_3477) } else { ifn_3479 = nil }; var arg_3480 any = forms__0; var arg_3481 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_105; var tmp2 any; var root_3482 any = A_arbace_go_check_A_const_274.GetRawRoot__O(); var linked_3483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3482, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3484 lang.IFn; if linked_3483 == nil { ifn_3484 = lang.IFn_Cast(root_3482) } else { ifn_3484 = nil }; var arg_3485 any = corpus__1; if linked_3483 == nil { tmp2 = ifn_3484.Invoke_O__O(arg_3485) } else { tmp2 = linked_3483.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3482, arg_3485) }; arg_3481 = tmp1.Invoke_O__O(tmp2); if linked_3478 == nil { src__5 = ifn_3479.Invoke_O_O__O(arg_3480, arg_3481) } else { src__5 = linked_3478.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3477, arg_3480, arg_3481) }; var pkg__6 any; var tmp3 lang.IFn = /*line :533:1*/lang.IFn_Cast(A_arbace_go_check_A_const_242.GetRawRoot__O()); var tmp4 any; var root_3493 any = A_arbace_go_check_A_const_243.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, A_arbace_go_check_resolver_A_fn_class); var ifn_3495 lang.IFn; if






	linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any = s__4; var arg_3497 any = src__5; var arg_3498 any = lang.PersistentVector_EMPTY.Ref(); if linked_3494 == nil { tmp4 = ifn_3495.Invoke_O_O_O__O(arg_3496, arg_3497, arg_3498) } else { tmp4 = linked_3494.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3493, arg_3496, arg_3497, arg_3498) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_102; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_102.Invoke_O__O(opts__2)); var root_3499 any =
	A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3499, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3501 lang.IFn; if linked_3500 == nil { ifn_3501 = lang.IFn_Cast(root_3499) } else { ifn_3501 = nil }; var arg_3502 any = pkg__6; var arg_3503 any = A_arbace_go_check_A_const_207; if linked_3500 == nil { return ifn_3501.Invoke_O_O__O(arg_3502, arg_3503) } else { return linked_3500.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3499, arg_3502, arg_3503) } }
//line :533:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_3504 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3504, A_arbace_go_check_check_forms_A_fn_class); var ifn_3506 lang.IFn; if linked_3505 == nil { ifn_3506 = lang.IFn_Cast(root_3504) } else { ifn_3506 = nil }; var arg_3507 any = forms__0; var arg_3508 any = Lit_51; var arg_3509 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3505 == nil { return ifn_3506.Invoke_O_O_O__O(arg_3507, arg_3508, arg_3509) } else { return linked_3505.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_3504, arg_3507, arg_3508, arg_3509)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :549:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :549:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_322.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_318.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_3527 any = A_arbace_go_check_A_const_156.GetRawRoot__O(); var linked_3528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3527, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3529 lang.IFn; if linked_3528 == nil { ifn_3529 = lang.IFn_Cast(root_3527) } else { ifn_3529 = nil }; var arg_3530 any = lang.IFn_Cast(A_arbace_go_check_A_const_157.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_321, s__1927001093__auto____3); if linked_3528 == nil { ifn_3529.Invoke_O__O(arg_3530) } else { linked_3528.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3527, arg_3530) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000419_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__3526 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000419_A_fn_class; if fncls__3526 == nil { var fncls__3526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_check_write_edn_fn__1685000419_A_fn_class = fncls__3526d; tmp4 = fncls__3526d } else { tmp4 = fncls__3526 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :551:1
func A_arbace_go_check_write_edn_fn__1685000419_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000419_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000419_A{}; t.Ctor_O_O(p0, p1); return t }
//line :551:1
func (t *A_arbace_go_check_write_edn_fn__1685000419_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :551:1
func (t *A_arbace_go_check_write_edn_fn__1685000419_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3522 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3522, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_3524 lang.IFn; if linked_3523 == nil { ifn_3524 = lang.IFn_Cast(root_3522) } else { ifn_3524 = nil }; var arg_3525 any; var t_ any = t.F_x; t.F_x = nil; arg_3525 = t_; if linked_3523 == nil { ifn_3524.Invoke_O__O(arg_3525) } else { linked_3523.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_3522, arg_3525) }; var root_3515 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3516 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3515, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3517 lang.IFn; if linked_3516 == nil { ifn_3517 = lang.IFn_Cast(root_3515) } else { ifn_3517 = nil }; var arg_3518 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_3518 = t__2; if linked_3516 == nil { tmp1 = ifn_3517.Invoke_O__O(arg_3518) } else { tmp1 = linked_3516.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3515, arg_3518) } }; return nil }(); var root_3519 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3519, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3521 lang.IFn; if linked_3520 == nil { ifn_3521 = lang.IFn_Cast(root_3519) } else { ifn_3521 = nil }; if linked_3520 == nil { ifn_3521.Invoke__O() } else { linked_3520.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3519) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :553:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :553:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_115, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil, corpus__0, nil)).Ref() }

func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :555:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000423__1 any) any { var map__1685000424__3 any = p__1685000423__1; var map__1685000424__4 any; if lang.ISeq_InstanceOf(map__1685000424__3) { var tmp1 any; var root_3540 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3540, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3542 lang.IFn; if linked_3541 == nil { ifn_3542 = lang.IFn_Cast(root_3540) } else { ifn_3542 = nil }; var arg_3543 any = map__1685000424__3; if linked_3541 == nil { tmp1 = ifn_3542.Invoke_O__O(arg_3543) } else { tmp1 = linked_3541.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3540, arg_3543) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3544 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3544, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3546 lang.IFn; if linked_3545 == nil { ifn_3546 = lang.IFn_Cast(root_3544) } else { ifn_3546 = nil }; var arg_3547 any = map__1685000424__3; if linked_3545 == nil { tmp2 = ifn_3546.Invoke_O__O(arg_3547) } else { tmp2 = linked_3545.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3544, arg_3547) }; map__1685000424__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3548 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3550 lang.IFn; if linked_3549 == nil { ifn_3550 = lang.IFn_Cast(root_3548) } else { ifn_3550 = nil }; var arg_3551 any = map__1685000424__3; if linked_3549 == nil { tmp3 = ifn_3550.Invoke_O__O(arg_3551) } else { tmp3 = linked_3549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3548, arg_3551) }; if jrt.J2g_Truth(tmp3) { var root_3552 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3552, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3554 lang.IFn; if linked_3553 == nil { ifn_3554 = lang.IFn_Cast(root_3552) } else { ifn_3554 = nil }; var arg_3555 any = map__1685000424__3; if linked_3553 == nil { map__1685000424__4 = ifn_3554.Invoke_O__O(arg_3555) } else { map__1685000424__4 = linked_3553.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3552, arg_3555) } } else { map__1685000424__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000424__4 = map__1685000424__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000424__4, A_arbace_go_check_A_const_323); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000424__4, A_arbace_go_check_A_const_324); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000424__4, A_arbace_go_check_A_const_325); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_3556 any = A_arbace_go_check_A_const_326.GetRawRoot__O(); var linked_3557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3556, A_arbace_go_check_check_corpus_A_fn_class); var ifn_3558 lang.IFn; if






	linked_3557 == nil { ifn_3558 = lang.IFn_Cast(root_3556) } else { ifn_3558 = nil }; var arg_3559 any = corpus__0; var arg_3560 any = jobs__5; if linked_3557 == nil { rs__9 = ifn_3558.Invoke_O_O__O(arg_3559, arg_3560) } else { rs__9 = linked_3557.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_3556, arg_3559, arg_3560) }; var sm__10 any; var root_3561 any = /*line :555:1*/A_arbace_go_check_A_const_327.GetRawRoot__O(); var linked_3562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3561, A_arbace_go_check_summarize_A_fn_class); var ifn_3563 lang.IFn; if







	linked_3562 == nil { ifn_3563 = lang.IFn_Cast(root_3561) } else { ifn_3563 = nil }; var arg_3564 any = corpus__0; var arg_3565 any = rs__9; if linked_3562 == nil { sm__10 = ifn_3563.Invoke_O_O__O(arg_3564, arg_3565) } else { sm__10 = linked_3562.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_3561, arg_3564, arg_3565) }; var secs__11 float64 = /*line :555:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_328; var tmp5 any; var root_3566 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3566, A_arbace_go_check_reference_path_A_fn_class); var ifn_3568 lang.IFn; if









	linked_3567 == nil { ifn_3568 = lang.IFn_Cast(root_3566) } else { ifn_3568 = nil }; var arg_3569 any = corpus__0; if linked_3567 == nil { tmp5 = ifn_3568.Invoke_O__O(arg_3569) } else { tmp5 = linked_3567.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3566, arg_3569) }; ref_file__12 = /*line :555:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var root_3570 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); var linked_3571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3570, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_3572 lang.IFn; if linked_3571 == nil { ifn_3572 = lang.IFn_Cast(root_3570) } else { ifn_3572 = nil }; var arg_3573 any = lang.IFn_Cast(A_arbace_go_check_A_const_331.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_3571 == nil { ref__13 = ifn_3572.Invoke_O__O(arg_3573) } else { ref__13 = linked_3571.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_3570, arg_3573) } } else { ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_3578 any = /*line :555:1*/A_arbace_go_check_A_const_208.Invoke_O__O(sm__10); if











	jrt.Long_InstanceOf(na_3578) { var n0_3579 int64 = jrt.NN(jrt.Long_Cast(na_3578)).LongValue__J(); and__1927000168__auto____14 = n0_3579 == 0 } else { if jrt.Double_InstanceOf(na_3578) { var n0_3579_2 float64 = jrt.NN(jrt.Double_Cast(na_3578)).DoubleValue__D(); and__1927000168__auto____14 = n0_3579_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_3578) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_3580 any = A_arbace_go_check_A_const_295.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_3580) { var n0_3581 int64 = jrt.NN(jrt.Long_Cast(na_3580)).LongValue__J(); and__1927000168__auto____15 = n0_3581 == 0 } else { if jrt.Double_InstanceOf(na_3580) { var n0_3581_2 float64 = jrt.NN(jrt.Double_Cast(na_3580)).DoubleValue__D(); and__1927000168__auto____15 = n0_3581_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_3580) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_3582 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_3583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3582, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3584 lang.IFn; if linked_3583 == nil { ifn_3584 = lang.IFn_Cast(root_3582) } else { ifn_3584 = nil }; var arg_3585 any; var root_3586 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3586, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3588 lang.IFn; if linked_3587 == nil { ifn_3588 = lang.IFn_Cast(root_3586) } else { ifn_3588 = nil }; var arg_3589 any = sm__10; var arg_3590 any = A_arbace_go_check_A_const_332; if linked_3587 == nil { arg_3585 = ifn_3588.Invoke_O_O__O(arg_3589, arg_3590) } else { arg_3585 = linked_3587.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3586, arg_3589, arg_3590) }; if linked_3583 == nil { and__1927000168__auto____16 = ifn_3584.Invoke_O__O(arg_3585) } else { and__1927000168__auto____16 = linked_3583.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3582, arg_3585) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_3591 any; var root_3592 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3592, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3594 lang.IFn
		if linked_3593 == nil { ifn_3594 = lang.IFn_Cast(root_3592) } else { ifn_3594 = nil }; var arg_3595 any = sm__10; var arg_3596 any = A_arbace_go_check_A_const_333; if linked_3593 == nil { na_3591 = ifn_3594.Invoke_O_O__O(arg_3595, arg_3596) } else { na_3591 = linked_3593.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3592, arg_3595, arg_3596) }; if jrt.Long_InstanceOf(na_3591) { var n0_3597 int64 = jrt.NN(jrt.Long_Cast(na_3591)).LongValue__J(); and__1927000168__auto____17 = n0_3597 == 0 } else { if jrt.Double_InstanceOf(na_3591) { var n0_3597_2 float64 = jrt.NN(jrt.Double_Cast(na_3591)).DoubleValue__D(); and__1927000168__auto____17 = n0_3597_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_3591) } }
//line :567:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_3598 any; var root_3599 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3599, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3601 lang.IFn; if linked_3600 == nil { ifn_3601 = lang.IFn_Cast(root_3599) } else { ifn_3601 = nil }; var arg_3602 any = sm__10; var arg_3603 any = A_arbace_go_check_A_const_334; if linked_3600 == nil { na_3598 = ifn_3601.Invoke_O_O__O(arg_3602, arg_3603) } else { na_3598 = linked_3600.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3599, arg_3602, arg_3603) }; if jrt.Long_InstanceOf(na_3598) { var n0_3604 int64 = jrt.NN(jrt.Long_Cast(na_3598)).LongValue__J(); tmp6 = n0_3604 == 0 } else { if jrt.Double_InstanceOf(na_3598) { var n0_3604_2 float64 = jrt.NN(jrt.Double_Cast(na_3598)).DoubleValue__D(); tmp6 = n0_3604_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_3598) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :567:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_3605 any = /*line :555:1*/A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_3606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3605, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3607 lang.IFn; if














	linked_3606 == nil { ifn_3607 = lang.IFn_Cast(root_3605) } else { ifn_3607 = nil }; var arg_3608 any = ref__13; var arg_3609 any = A_arbace_go_check_A_const_335; if linked_3606 == nil { tmp7 = ifn_3607.Invoke_O_O__O(arg_3608, arg_3609) } else { tmp7 = linked_3606.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3605, arg_3608, arg_3609) }; var tmp8 any = tmp7; var tmp9 any; var root_3610 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_3611 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3610, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3612 lang.IFn; if linked_3611 == nil { ifn_3612 = lang.IFn_Cast(root_3610) } else { ifn_3612 = nil }; var arg_3613 any = sm__10; var arg_3614 any = A_arbace_go_check_A_const_297; if linked_3611 == nil { tmp9 = ifn_3612.Invoke_O_O__O(arg_3613, arg_3614) } else { tmp9 = linked_3611.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3610, arg_3613, arg_3614) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_3623 any =
	A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3623, A_arbace_go_check_write_edn_A_fn_class); var ifn_3625 lang.IFn; if linked_3624 == nil { ifn_3625 = lang.IFn_Cast(root_3623) } else { ifn_3625 = nil }; var arg_3626 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_3627 any; var tmp10 any = A_arbace_go_check_A_const_337; var tmp11 any = A_arbace_go_check_A_const_338; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_208; var tmp14 any; var root_3628 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_3629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3628, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3630 lang.IFn; if

	linked_3629 == nil { ifn_3630 = lang.IFn_Cast(root_3628) } else { ifn_3630 = nil }; var arg_3631 any; var root_3632 any = A_arbace_go_check_A_const_339.GetRawRoot__O(); var linked_3633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3632, A_arbace_go_check_report_errors_A_fn_class); var ifn_3634 lang.IFn; if linked_3633 == nil { ifn_3634 = lang.IFn_Cast(root_3632) } else { ifn_3634 = nil }; var arg_3635 any = rs__9; if linked_3633 == nil { arg_3631 = ifn_3634.Invoke_O__O(arg_3635) } else { arg_3631 = linked_3633.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3632, arg_3635) }; if linked_3629 == nil { tmp14 = ifn_3630.Invoke_O__O(arg_3631) } else { tmp14 = linked_3629.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3628, arg_3631) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_153; var tmp17 any; var root_3636 any = /*line :571:1*/A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_3637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3636, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3638 lang.IFn; if


	linked_3637 == nil { ifn_3638 = lang.IFn_Cast(root_3636) } else { ifn_3638 = nil }; var arg_3639 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000426__1685000432_A_New(); var tmp19 *jrt.Class; var fncls__3725 *jrt.Class = A_arbace_go_check_annotations_iter__1685000426__1685000432_A_fn_class; if fncls__3725 == nil { var fncls__3725d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_annotations_iter__1685000426__1685000432_A_fn_class = fncls__3725d; tmp19 = fncls__3725d } else { tmp19 = fncls__3725 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_3639 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_3637 == nil { tmp17 = ifn_3638.Invoke_O__O(arg_3639) } else { tmp17 = linked_3637.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3636, arg_3639) }; arg_3627 = /*line :571:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_3624 == nil { ifn_3625.Invoke_O_O__O(arg_3626, arg_3627) } else { linked_3624.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3623, arg_3626, arg_3627) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_205.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_291.Invoke_O__O(sm__10); var tmp23 any; var root_3744 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3744, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3746 lang.IFn; if
	linked_3745 == nil { ifn_3746 = lang.IFn_Cast(root_3744) } else { ifn_3746 = nil }; var arg_3747 any = sm__10; var arg_3748 any = A_arbace_go_check_A_const_341; if linked_3745 == nil { tmp23 = ifn_3746.Invoke_O_O__O(arg_3747, arg_3748) } else { tmp23 = linked_3745.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3744, arg_3747, arg_3748) }; var tmp24 any = tmp23; var tmp25 any; var root_3749 any = /*line :575:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3749, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3751 lang.IFn; if
	linked_3750 == nil { ifn_3751 = lang.IFn_Cast(root_3749) } else { ifn_3751 = nil }; var arg_3752 any = sm__10; var arg_3753 any = A_arbace_go_check_A_const_342; if linked_3750 == nil { tmp25 = ifn_3751.Invoke_O_O__O(arg_3752, arg_3753) } else { tmp25 = linked_3750.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3749, arg_3752, arg_3753) }; var tmp26 any = tmp25; var tmp27 any; var root_3754 any = /*line :575:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3754, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3756 lang.IFn; if

	linked_3755 == nil { ifn_3756 = lang.IFn_Cast(root_3754) } else { ifn_3756 = nil }; var arg_3757 any = sm__10; var arg_3758 any = A_arbace_go_check_A_const_343; if linked_3755 == nil { tmp27 = ifn_3756.Invoke_O_O__O(arg_3757, arg_3758) } else { tmp27 = linked_3755.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3754, arg_3757, arg_3758) }; var tmp28 any = tmp27; var tmp29 any = /*line :575:1*/A_arbace_go_check_A_const_208.Invoke_O__O(sm__10); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()); var tmp31 any; var root_3763 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3763, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3765 lang.IFn; if


	linked_3764 == nil { ifn_3765 = lang.IFn_Cast(root_3763) } else { ifn_3765 = nil }; var arg_3766 any = sm__10; var arg_3767 any = A_arbace_go_check_A_const_344; if linked_3764 == nil { tmp31 = ifn_3765.Invoke_O_O__O(arg_3766, arg_3767) } else { tmp31 = linked_3764.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3763, arg_3766, arg_3767) }; var tmp32 any = /*line :575:1*/tmp30.Invoke_O__O(tmp31); var tmp33 any; var root_3768 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3768, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3770 lang.IFn; if



	linked_3769 == nil { ifn_3770 = lang.IFn_Cast(root_3768) } else { ifn_3770 = nil }; var arg_3771 any = sm__10; var arg_3772 any = A_arbace_go_check_A_const_345; if linked_3769 == nil { tmp33 = ifn_3770.Invoke_O_O__O(arg_3771, arg_3772) } else { tmp33 = linked_3769.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3768, arg_3771, arg_3772) }; var tmp34 any = tmp33; var tmp35 any; var root_3773 any = /*line :575:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3775 lang.IFn; if



	linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = sm__10; var arg_3777 any = A_arbace_go_check_A_const_346; if linked_3774 == nil { tmp35 = ifn_3775.Invoke_O_O__O(arg_3776, arg_3777) } else { tmp35 = linked_3774.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3773, arg_3776, arg_3777) }; /*line :575:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_14, corpus__0, tmp22, tmp24, tmp26, tmp28, tmp29, tmp32, tmp34, tmp35, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000442__16 any; var root_3778 any = /*line :555:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3780 lang.IFn; if
























	linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any; var root_3782 any = A_arbace_go_check_A_const_347.GetRawRoot__O(); var linked_3783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3782, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3784 lang.IFn; if linked_3783 == nil { ifn_3784 = lang.IFn_Cast(root_3782) } else { ifn_3784 = nil }; var arg_3785 any = A_arbace_go_check_A_const_348; var arg_3786 any; var root_3787 any = A_arbace_go_check_A_const_339.GetRawRoot__O(); var linked_3788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3787, A_arbace_go_check_report_errors_A_fn_class); var ifn_3789 lang.IFn; if linked_3788 == nil { ifn_3789 = lang.IFn_Cast(root_3787) } else { ifn_3789 = nil }; var arg_3790 any = rs__9; if linked_3788 == nil { arg_3786 = ifn_3789.Invoke_O__O(arg_3790) } else { arg_3786 = linked_3788.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3787, arg_3790) }; if linked_3783 == nil { arg_3781 = ifn_3784.Invoke_O_O__O(arg_3785, arg_3786) } else { arg_3781 = linked_3783.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3782, arg_3785, arg_3786) }; if linked_3779 == nil { seq_1685000442__16 = ifn_3780.Invoke_O__O(arg_3781) } else { seq_1685000442__16 = linked_3779.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3778, arg_3781) }; var chunk_1685000443__17 any; var count_1685000444__18 int64 = 0; var i_1685000445__19 int64 = 0; L1:
//line :555:1
	for {
























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000445__19, count_1685000444__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000443__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000445__19)); lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__20); seq_1685000442__16, chunk_1685000443__17, count_1685000444__18, i_1685000445__19 = seq_1685000442__16, chunk_1685000443__17, count_1685000444__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000445__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_3791 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3793 lang.IFn; if linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; var arg_3794 any = seq_1685000442__16; if linked_3792 == nil { temp__1927000414__auto____20 = ifn_3793.Invoke_O__O(arg_3794) } else { temp__1927000414__auto____20 = linked_3792.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3791, arg_3794) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000442__21 any = temp__1927000414__auto____20; var tmp36 any; var root_3795 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3795, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3797 lang.IFn; if linked_3796 == nil { ifn_3797 = lang.IFn_Cast(root_3795) } else { ifn_3797 = nil }; var arg_3798 any = seq_1685000442__21; if linked_3796 == nil { tmp36 = ifn_3797.Invoke_O__O(arg_3798) } else { tmp36 = linked_3796.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3795, arg_3798) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____22 any; var root_3799 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3799, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3801 lang.IFn; if linked_3800 == nil { ifn_3801 = lang.IFn_Cast(root_3799) } else { ifn_3801 = nil }; var arg_3802 any = seq_1685000442__21; if linked_3800 == nil { c__1927000678__auto____22 = ifn_3801.Invoke_O__O(arg_3802) } else { c__1927000678__auto____22 = linked_3800.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3799, arg_3802) }; var tmp37 any; var root_3848 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3848, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3850 lang.IFn; if linked_3849 == nil { ifn_3850 = lang.IFn_Cast(root_3848) } else { ifn_3850 = nil }; var arg_3851 any = seq_1685000442__21; if linked_3849 == nil { tmp37 = ifn_3850.Invoke_O__O(arg_3851) } else { tmp37 = linked_3849.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3848, arg_3851) }; seq_1685000442__16, chunk_1685000443__17, count_1685000444__18, i_1685000445__19 = tmp37, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_3803 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3803, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3805 lang.IFn; if linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; var arg_3806 any = seq_1685000442__21; if linked_3804 == nil { l__22 = ifn_3805.Invoke_O__O(arg_3806) } else { l__22 = linked_3804.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3803, arg_3806) }; lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__22); var tmp38 any; var root_3857 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3857, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3859 lang.IFn; if linked_3858 == nil { ifn_3859 = lang.IFn_Cast(root_3857) } else { ifn_3859 = nil }; var arg_3860 any = seq_1685000442__21; if linked_3858 == nil { tmp38 = ifn_3859.Invoke_O__O(arg_3860) } else { tmp38 = linked_3858.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3857, arg_3860) }; seq_1685000442__16, chunk_1685000443__17, count_1685000444__18, i_1685000445__19 = tmp38, nil, 0, 0; continue L1 } } }
//line :555:1
		break L1 }; var tmp39 any; var root_3807 any =

























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any; var root_3811 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = sm__10; var arg_3815 any = A_arbace_go_check_A_const_349; if linked_3812 == nil { arg_3810 = ifn_3813.Invoke_O_O__O(arg_3814, arg_3815) } else { arg_3810 = linked_3812.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3811, arg_3814, arg_3815) }; if linked_3808 == nil { tmp39 = ifn_3809.Invoke_O__O(arg_3810) } else { tmp39 = linked_3808.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3807, arg_3810) }; if jrt.J2g_Truth(tmp39) {
		var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()); var tmp42 any; var root_3825 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = sm__10; var arg_3829 any = A_arbace_go_check_A_const_350; if linked_3826 == nil { tmp42 = ifn_3827.Invoke_O_O__O(arg_3828, arg_3829) } else { tmp42 = linked_3826.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3825, arg_3828, arg_3829) }; tmp40.Invoke_O_O__O(Lit_16, tmp41.Invoke_O__O(tmp42)) }; var tmp43 any; var root_3830 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3830, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3832 lang.IFn; if linked_3831 == nil { ifn_3832 = lang.IFn_Cast(root_3830) } else { ifn_3832 = nil }; var arg_3833 any = A_arbace_go_check_A_const_132.Invoke_O__O(sm__10); if linked_3831 == nil { tmp43 = ifn_3832.Invoke_O__O(arg_3833) } else { tmp43 = linked_3831.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3830, arg_3833) }; if jrt.J2g_Truth(tmp43) {
		lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()).Invoke_O_O__O(Lit_17, lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_132.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_3861 any = A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3861, A_arbace_go_check_write_edn_A_fn_class); var ifn_3863 lang.IFn; if linked_3862 == nil { ifn_3863 = lang.IFn_Cast(root_3861) } else { ifn_3863 = nil }; var arg_3864 any; var root_3866 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3866, A_arbace_go_check_reference_path_A_fn_class); var ifn_3868 lang.IFn; if linked_3867 == nil { ifn_3868 = lang.IFn_Cast(root_3866) } else { ifn_3868 = nil }; var arg_3869 any = corpus__0; if linked_3867 == nil { arg_3864 = ifn_3868.Invoke_O__O(arg_3869) } else { arg_3864 = linked_3867.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3866, arg_3869) }; var arg_3865 any; var root_3870 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3870, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3872 lang.IFn; if linked_3871 == nil { ifn_3872 = lang.IFn_Cast(root_3870) } else { ifn_3872 = nil }; var arg_3873 any; var root_3876 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = sm__10; var arg_3880 any = A_arbace_go_check_A_const_297; if linked_3877 == nil { arg_3873 = ifn_3878.Invoke_O_O__O(arg_3879, arg_3880) } else { arg_3873 = linked_3877.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3876, arg_3879, arg_3880) }; var arg_3874 any = A_arbace_go_check_A_const_335; var arg_3875 any = Lit_18; if linked_3871 == nil { arg_3865 = ifn_3872.Invoke_O_O_O__O(arg_3873, arg_3874, arg_3875) } else { arg_3865 = linked_3871.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3870, arg_3873, arg_3874, arg_3875) }; if linked_3862 == nil { ifn_3863.Invoke_O_O__O(arg_3864, arg_3865) } else { linked_3862.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3861, arg_3864, arg_3865) }
		var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp45 any; var root_3886 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3886, A_arbace_go_check_reference_path_A_fn_class); var ifn_3888 lang.IFn; if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any = corpus__0; if linked_3887 == nil { tmp45 = ifn_3888.Invoke_O__O(arg_3889) } else { tmp45 = linked_3887.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3886, arg_3889) }; tmp44.Invoke_O_O__O(Lit_19, tmp45)
//line :585:1
		return clean__14 } else { var tmp46 any; var root_3615 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3615, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3617 lang.IFn



			if linked_3616 == nil { ifn_3617 = lang.IFn_Cast(root_3615) } else { ifn_3617 = nil }; var arg_3618 any = clean__14; if linked_3616 == nil { tmp46 = ifn_3617.Invoke_O__O(arg_3618) } else { tmp46 = linked_3616.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3615, arg_3618) }
//line :585:1
			if jrt.J2g_Truth(tmp46) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp48 any; var root_3896 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3896, A_arbace_go_check_reference_path_A_fn_class); var ifn_3898 lang.IFn; if linked_3897 == nil { ifn_3898 = lang.IFn_Cast(root_3896) } else { ifn_3898 = nil }; var arg_3899 any = corpus__0; if linked_3897 == nil { tmp48 = ifn_3898.Invoke_O__O(arg_3899) } else { tmp48 = linked_3897.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3896, arg_3899) }; tmp47.Invoke_O_O_O__O(Lit_20, tmp48, Lit_21)
//line :585:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp49 any; var root_3619 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3619, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3621 lang.IFn





					if linked_3620 == nil { ifn_3621 = lang.IFn_Cast(root_3619) } else { ifn_3621 = nil }; var arg_3622 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_3620 == nil { tmp49 = ifn_3621.Invoke_O__O(arg_3622) } else { tmp49 = linked_3620.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3619, arg_3622) }
//line :585:1
					if jrt.J2g_Truth(tmp49) {





						var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp51 any; var root_3906 any = A_arbace_go_check_A_const_329.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, A_arbace_go_check_reference_path_A_fn_class); var ifn_3908 lang.IFn; if linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any = corpus__0; if linked_3907 == nil { tmp51 = ifn_3908.Invoke_O__O(arg_3909) } else { tmp51 = linked_3907.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3906, arg_3909) }; tmp50.Invoke_O_O_O__O(Lit_22, tmp51, Lit_23)
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()); var tmp54 any; var root_3919 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_3920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3919, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3921 lang.IFn; if linked_3920 == nil { ifn_3921 = lang.IFn_Cast(root_3919) } else { ifn_3921 = nil }; var arg_3922 any = ref__13; var arg_3923 any = A_arbace_go_check_A_const_335; if linked_3920 == nil { tmp54 = ifn_3921.Invoke_O_O__O(arg_3922, arg_3923) } else { tmp54 = linked_3920.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3919, arg_3922, arg_3923) }; tmp52.Invoke_O_O__O(Lit_24, tmp53.Invoke_O__O(tmp54))
						var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()); var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_206.GetRawRoot__O()); var tmp57 any; var root_3933 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_3934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3933, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3935 lang.IFn; if linked_3934 == nil { ifn_3935 = lang.IFn_Cast(root_3933) } else { ifn_3935 = nil }; var arg_3936 any = sm__10; var arg_3937 any = A_arbace_go_check_A_const_297; if linked_3934 == nil { tmp57 = ifn_3935.Invoke_O_O__O(arg_3936, arg_3937) } else { tmp57 = linked_3934.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3933, arg_3936, arg_3937) }; tmp55.Invoke_O_O__O(Lit_25, tmp56.Invoke_O__O(tmp57))
//line :585:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :574:1
func A_arbace_go_check_annotations_iter__1685000426__1685000432_A_New() *A_arbace_go_check_annotations_iter__1685000426__1685000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000426__1685000432_A{}; t.Ctor(); return t }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_A) Ctor() {}
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_A) Invoke_O_O__O(self, s__1685000427__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A_New_O_O(self, s__1685000427__1); var tmp2 *jrt.Class; var fncls__3724 *jrt.Class = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A_fn_class; if fncls__3724 == nil { var fncls__3724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A_fn_class = fncls__3724d; tmp2 = fncls__3724d } else { tmp2 = fncls__3724 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :574:1
func A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A{}; t.Ctor_O_O(p0, p1); return t }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A) Ctor_O_O(c__iter__1685000426, c__s__1685000427 any) { t.F_iter__1685000426 = c__iter__1685000426; t.F_s__1685000427 = c__s__1685000427 }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A) Invoke_O__O(self any) any { { var s__1685000427__1 any; var t_ any = t.F_s__1685000427; t.F_s__1685000427 = nil; s__1685000427__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3640 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3642 lang.IFn; if linked_3641 == nil { ifn_3642 = lang.IFn_Cast(root_3640) } else { ifn_3642 = nil }; var arg_3643 any = s__1685000427__1; if linked_3641 == nil { temp__1927000414__auto____2 = ifn_3642.Invoke_O__O(arg_3643) } else { temp__1927000414__auto____2 = linked_3641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3640, arg_3643) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3644 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3646 lang.IFn; if linked_3645 == nil { ifn_3646 = lang.IFn_Cast(root_3644) } else { ifn_3646 = nil }; var arg_3647 any = xs__1927001018__auto____3; if linked_3645 == nil { r__4 = ifn_3646.Invoke_O__O(arg_3647) } else { r__4 = linked_3645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3644, arg_3647) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3706 *jrt.Class = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A_fn_class; if fncls__3706 == nil { var fncls__3706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A_fn_class = fncls__3706d; tmp2 = fncls__3706d } else { tmp2 = fncls__3706 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3707 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3709 lang.IFn; if linked_3708 == nil { ifn_3709 = lang.IFn_Cast(root_3707) } else { ifn_3709 = nil }; var arg_3710 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_154.Invoke_O__O(r__4)); if linked_3708 == nil { fs__1927001036__auto____6 = ifn_3709.Invoke_O__O(arg_3710) } else { fs__1927001036__auto____6 = linked_3708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3707, arg_3710) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3711 any = A_arbace_go_check_A_const_287.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3711, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3713 lang.IFn; if linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any = fs__1927001036__auto____6; var arg_3715 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000426); var tmp4 any; var root_3716 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3718 lang.IFn; if linked_3717 == nil { ifn_3718 = lang.IFn_Cast(root_3716) } else { ifn_3718 = nil }; var arg_3719 any = s__1685000427__1; if linked_3717 == nil { tmp4 = ifn_3718.Invoke_O__O(arg_3719) } else { tmp4 = linked_3717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3716, arg_3719) }; arg_3715 = tmp3.Invoke_O__O(tmp4); if linked_3712 == nil { return ifn_3713.Invoke_O_O__O(arg_3714, arg_3715) } else { return linked_3712.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3711, arg_3714, arg_3715) } } else { var tmp5 any; var root_3720 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3720, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3722 lang.IFn; if linked_3721 == nil { ifn_3722 = lang.IFn_Cast(root_3720) } else { ifn_3722 = nil }; var arg_3723 any = s__1685000427__1; if linked_3721 == nil { tmp5 = ifn_3722.Invoke_O__O(arg_3723) } else { tmp5 = linked_3721.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3720, arg_3723) }; s__1685000427__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :574:1
func A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A{}; t.Ctor_O(p0); return t }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A) Invoke_O_O__O(self, s__1685000429__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A_New_O_O_O(self, t.F_r, s__1685000429__1); var tmp2 *jrt.Class; var fncls__3705 *jrt.Class = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A_fn_class; if fncls__3705 == nil { var fncls__3705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A_fn_class = fncls__3705d; tmp2 = fncls__3705d } else { tmp2 = fncls__3705 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :574:1
func A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A) Ctor_O_O_O(c__iter__1685000428, c__r, c__s__1685000429 any) { t.F_iter__1685000428 = c__iter__1685000428; t.F_r = c__r; t.F_s__1685000429 = c__s__1685000429 }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A) Invoke_O__O(self any) any { { var s__1685000429__1 any; var t_ any = t.F_s__1685000429; t.F_s__1685000429 = nil; s__1685000429__1 = t_; for { var temp__1927000414__auto____2 any; var root_3648 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3648, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3650 lang.IFn; if linked_3649 == nil { ifn_3650 = lang.IFn_Cast(root_3648) } else { ifn_3650 = nil }; var arg_3651 any = s__1685000429__1; if linked_3649 == nil { temp__1927000414__auto____2 = ifn_3650.Invoke_O__O(arg_3651) } else { temp__1927000414__auto____2 = linked_3649.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3648, arg_3651) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000429__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3652 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3652, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3654 lang.IFn; if linked_3653 == nil { ifn_3654 = lang.IFn_Cast(root_3652) } else { ifn_3654 = nil }; var arg_3655 any = s__1685000429__3; if linked_3653 == nil { tmp1 = ifn_3654.Invoke_O__O(arg_3655) } else { tmp1 = linked_3653.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3652, arg_3655) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3656 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3656, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3658 lang.IFn; if linked_3657 == nil { ifn_3658 = lang.IFn_Cast(root_3656) } else { ifn_3658 = nil }; var arg_3659 any = s__1685000429__3; if linked_3657 == nil { c__1927001037__auto____4 = ifn_3658.Invoke_O__O(arg_3659) } else { c__1927001037__auto____4 = linked_3657.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3656, arg_3659) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000431__6 any; var root_3660 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3660, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3662 lang.IFn; if linked_3661 == nil { ifn_3662 = lang.IFn_Cast(root_3660) } else { ifn_3662 = nil }; var arg_3663 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3661 == nil { b__1685000431__6 = ifn_3662.Invoke_O__O(arg_3663) } else { b__1685000431__6 = linked_3661.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3660, arg_3663) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A_New_O_O_I_O(b__1685000431__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3669 *jrt.Class = A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A_fn_class; if fncls__3669 == nil { var fncls__3669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A_fn_class = fncls__3669d; tmp3 = fncls__3669d } else { tmp3 = fncls__3669 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3670 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3670, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3672 lang.IFn; if linked_3671 == nil { ifn_3672 = lang.IFn_Cast(root_3670) } else { ifn_3672 = nil }; var arg_3673 any; var root_3675 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3677 lang.IFn; if linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any = b__1685000431__6; if linked_3676 == nil { arg_3673 = ifn_3677.Invoke_O__O(arg_3678) } else { arg_3673 = linked_3676.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3675, arg_3678) }; var arg_3674 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000428); var tmp5 any; var root_3679 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3679, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3681 lang.IFn; if linked_3680 == nil { ifn_3681 = lang.IFn_Cast(root_3679) } else { ifn_3681 = nil }; var arg_3682 any = s__1685000429__3; if linked_3680 == nil { tmp5 = ifn_3681.Invoke_O__O(arg_3682) } else { tmp5 = linked_3680.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3679, arg_3682) }; arg_3674 = tmp4.Invoke_O__O(tmp5); if linked_3671 == nil { return ifn_3672.Invoke_O_O__O(arg_3673, arg_3674) } else { return linked_3671.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3670, arg_3673, arg_3674) } } else { var root_3683 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3683, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3685 lang.IFn; if linked_3684 == nil { ifn_3685 = lang.IFn_Cast(root_3683) } else { ifn_3685 = nil }; var arg_3686 any; var root_3688 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3688, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3690 lang.IFn; if linked_3689 == nil { ifn_3690 = lang.IFn_Cast(root_3688) } else { ifn_3690 = nil }; var arg_3691 any = b__1685000431__6; if linked_3689 == nil { arg_3686 = ifn_3690.Invoke_O__O(arg_3691) } else { arg_3686 = linked_3689.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3688, arg_3691) }; var arg_3687 any; if linked_3684 == nil { return ifn_3685.Invoke_O_O__O(arg_3686, arg_3687) } else { return linked_3684.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3683, arg_3686, arg_3687) } } } else { var u__4 any; var root_3692 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3692, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3694 lang.IFn; if linked_3693 == nil { ifn_3694 = lang.IFn_Cast(root_3692) } else { ifn_3694 = nil }; var arg_3695 any = s__1685000429__3; if linked_3693 == nil { u__4 = ifn_3694.Invoke_O__O(arg_3695) } else { u__4 = linked_3693.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3692, arg_3695) }; var root_3696 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_3697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3696, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3698 lang.IFn; if linked_3697 == nil { ifn_3698 = lang.IFn_Cast(root_3696) } else { ifn_3698 = nil }; var arg_3699 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), u__4); var arg_3700 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000428); var tmp7 any; var root_3701 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3701, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3703 lang.IFn; if linked_3702 == nil { ifn_3703 = lang.IFn_Cast(root_3701) } else { ifn_3703 = nil }; var arg_3704 any = s__1685000429__3; if linked_3702 == nil { tmp7 = ifn_3703.Invoke_O__O(arg_3704) } else { tmp7 = linked_3702.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3701, arg_3704) }; arg_3700 = tmp6.Invoke_O__O(tmp7); if linked_3697 == nil { return ifn_3698.Invoke_O_O__O(arg_3699, arg_3700) } else { return linked_3697.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3696, arg_3699, arg_3700) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :574:1
func A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A) Ctor_O_O_I_O(c__b__1685000431, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000431 = c__b__1685000431; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :574:1
func (t *A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A) Invoke_O__O(self any) any { { var i__1685000430__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000430__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000430__1)); var root_3664 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3664, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3666 lang.IFn; if linked_3665 == nil { ifn_3666 = lang.IFn_Cast(root_3664) } else { ifn_3666 = nil }; var arg_3667 any = t.F_b__1685000431; var arg_3668 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), u__2); if linked_3665 == nil { ifn_3666.Invoke_O_O__O(arg_3667, arg_3668) } else { linked_3665.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3664, arg_3667, arg_3668) }; i__1685000430__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000430__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :597:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :597:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000447__2 any = args__0; var seq__1685000448__3 any; var root_3938 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3938, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3940 lang.IFn; if


	linked_3939 == nil { ifn_3940 = lang.IFn_Cast(root_3938) } else { ifn_3940 = nil }; var arg_3941 any = vec__1685000447__2; if linked_3939 == nil { seq__1685000448__3 = ifn_3940.Invoke_O__O(arg_3941) } else { seq__1685000448__3 = linked_3939.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3938, arg_3941) }; var first__1685000449__4 any; var root_3942 any = /*line :597:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3942, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3944 lang.IFn; if


	linked_3943 == nil { ifn_3944 = lang.IFn_Cast(root_3942) } else { ifn_3944 = nil }; var arg_3945 any = seq__1685000448__3; if linked_3943 == nil { first__1685000449__4 = ifn_3944.Invoke_O__O(arg_3945) } else { first__1685000449__4 = linked_3943.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3942, arg_3945) }; var seq__1685000448__5 any; var root_3946 any = /*line :597:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3946, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3948 lang.IFn; if


	linked_3947 == nil { ifn_3948 = lang.IFn_Cast(root_3946) } else { ifn_3948 = nil }; var arg_3949 any = seq__1685000448__3; if linked_3947 == nil { seq__1685000448__5 = ifn_3948.Invoke_O__O(arg_3949) } else { seq__1685000448__5 = linked_3947.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3946, arg_3949) }; var cmd__6 any = first__1685000449__4; var args__7 any = seq__1685000448__5; var G__1685000450__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000450__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000450__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000451_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4013 /*line :601:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000451_A_fn_class

		if fncls__4013 == nil { var fncls__4013d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000451_A_fn_class = fncls__4013d; tmp2 = fncls__4013d } else { tmp2 = fncls__4013 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :601:1
		var cs__10 any; var tmp3 any; var root_4014 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4016 lang.IFn









		if linked_4015 == nil { ifn_4016 = lang.IFn_Cast(root_4014) } else { ifn_4016 = nil }; var arg_4017 any = A_arbace_go_check_A_const_352.Invoke_O__O(opts__9); if linked_4015 == nil { tmp3 = ifn_4016.Invoke_O__O(arg_4017) } else { tmp3 = linked_4015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4014, arg_4017) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_352.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_355.GetRawRoot__O() }
//line :601:1
		var ok__11 any; var root_4018 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_4019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4018, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4020 lang.IFn










		if linked_4019 == nil { ifn_4020 = lang.IFn_Cast(root_4018) } else { ifn_4020 = nil }; var arg_4021 any; var iter__1927001039__auto____11 any; var tmp4 any = A_arbace_go_check__main_iter__1685000454__1685000458_A_New_O(opts__9); var tmp5 *jrt.Class; var fncls__4090 *jrt.Class = A_arbace_go_check__main_iter__1685000454__1685000458_A_fn_class; if fncls__4090 == nil { var fncls__4090d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_iter__1685000454__1685000458_A_fn_class = fncls__4090d; tmp5 = fncls__4090d } else { tmp5 = fncls__4090 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_4021 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(cs__10); if linked_4019 == nil { ok__11 = ifn_4020.Invoke_O__O(arg_4021) } else { ok__11 = linked_4019.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4018, arg_4021) }
		var root_4096 any = A_arbace_go_check_A_const_359.GetRawRoot__O(); var linked_4097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4096, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4098 lang.IFn; if linked_4097 == nil { ifn_4098 = lang.IFn_Cast(root_4096) } else { ifn_4098 = nil }; if linked_4097 == nil { ifn_4098.Invoke__O() } else { linked_4097.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4096) }
		var tmp6 int64; var tmp7 any; var root_4091 any = A_arbace_go_check_A_const_357.GetRawRoot__O(); var linked_4092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4091, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4093 lang.IFn; if linked_4092 == nil { ifn_4093 = lang.IFn_Cast(root_4091) } else { ifn_4093 = nil }; var arg_4094 any = A_arbace_go_check_A_const_358.GetRawRoot__O(); var arg_4095 any = ok__11; if linked_4092 == nil { tmp7 = ifn_4093.Invoke_O_O__O(arg_4094, arg_4095) } else { tmp7 = linked_4092.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4091, arg_4094, arg_4095) }; if jrt.J2g_Truth(tmp7) { tmp6 = 0 } else { tmp6 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp6)); return nil }
//line :601:1
	default:};













	lang.IFn_Cast(A_arbace_go_check_A_const_340.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :603:1
func A_arbace_go_check__main_fn__1685000451_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000451_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000451_A{}; t.Ctor_O(p0); return t }
//line :603:1
func (t *A_arbace_go_check__main_fn__1685000451_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :603:1
func (t *A_arbace_go_check__main_fn__1685000451_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_323; var tmp2 any = A_arbace_go_check_A_const_351; var tmp3 any = A_arbace_go_check_A_const_325; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_253.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_352, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_3951 any = A_arbace_go_check_A_const_282.GetRawRoot__O(); var linked_3952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3951, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3953 lang.IFn; if linked_3952 == nil { ifn_3953 = lang.IFn_Cast(root_3951) } else { ifn_3953 = nil }; var arg_3954 any = as__1; if linked_3952 == nil { tmp4 = ifn_3953.Invoke_O__O(arg_3954) } else { tmp4 = linked_3952.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3951, arg_3954) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000452__3_ any; var root_3955 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3955, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3957 lang.IFn

		if linked_3956 == nil { ifn_3957 = lang.IFn_Cast(root_3955) } else { ifn_3957 = nil }; var arg_3958 any = as__1; if linked_3956 == nil { G__1685000452__3_ = ifn_3957.Invoke_O__O(arg_3958) } else { G__1685000452__3_ = linked_3956.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3955, arg_3958) }; switch lang.Util_Hash_O__I_NoInit(G__1685000452__3_) >> 10 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000452__3_, Lit_6) {

			var tmp5 any; var root_3960 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); var linked_3961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3960, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3962 lang.IFn; if linked_3961 == nil { ifn_3962 = lang.IFn_Cast(root_3960) } else { ifn_3962 = nil }; var arg_3963 any = as__1; if linked_3961 == nil { tmp5 = ifn_3962.Invoke_O__O(arg_3963) } else { tmp5 = linked_3961.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3960, arg_3963) }; var tmp6 any = tmp5; var tmp7 any; var root_3964 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3964, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3966 lang.IFn; if linked_3965 == nil { ifn_3966 = lang.IFn_Cast(root_3964) } else { ifn_3966 = nil }; var arg_3967 any = o__2; var arg_3968 any = A_arbace_go_check_A_const_323; var arg_3969 any; var tmp8 any; var root_3970 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); var linked_3971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3970, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3972 lang.IFn; if linked_3971 == nil { ifn_3972 = lang.IFn_Cast(root_3970) } else { ifn_3972 = nil }; var arg_3973 any = as__1; if linked_3971 == nil { tmp8 = ifn_3972.Invoke_O__O(arg_3973) } else { tmp8 = linked_3971.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3970, arg_3973) }; arg_3969 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp8))).Ref(); if linked_3965 == nil { tmp7 = ifn_3966.Invoke_O_O_O__O(arg_3967, arg_3968, arg_3969) } else { tmp7 = linked_3965.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3964, arg_3967, arg_3968, arg_3969) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :606:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000452__3_, Lit_7) {
			var tmp9 any; var root_3974 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3974, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3976 lang.IFn; if linked_3975 == nil { ifn_3976 = lang.IFn_Cast(root_3974) } else { ifn_3976 = nil }; var arg_3977 any = as__1; if linked_3975 == nil { tmp9 = ifn_3976.Invoke_O__O(arg_3977) } else { tmp9 = linked_3975.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3974, arg_3977) }; var tmp10 any = tmp9; var tmp11 any; var root_3978 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3978, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3980 lang.IFn; if linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; var arg_3981 any = o__2; var arg_3982 any = A_arbace_go_check_A_const_324; var arg_3983 any = jrt.Boolean_TRUE.Ref(); if linked_3979 == nil { tmp11 = ifn_3980.Invoke_O_O_O__O(arg_3981, arg_3982, arg_3983) } else { tmp11 = linked_3979.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3978, arg_3981, arg_3982, arg_3983) }; as__1, o__2 = tmp10, tmp11; continue L1 }
//line :606:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000452__3_, Lit_8) {


			var tmp12 any; var root_3984 any = A_arbace_go_check_A_const_353.GetRawRoot__O(); var linked_3985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3984, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3986 lang.IFn; if linked_3985 == nil { ifn_3986 = lang.IFn_Cast(root_3984) } else { ifn_3986 = nil }; var arg_3987 any = as__1; if linked_3985 == nil { tmp12 = ifn_3986.Invoke_O__O(arg_3987) } else { tmp12 = linked_3985.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3984, arg_3987) }; var tmp13 any = tmp12; var tmp14 any; var root_3988 any = A_arbace_go_check_A_const_190.GetRawRoot__O(); var linked_3989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3988, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3990 lang.IFn; if linked_3989 == nil { ifn_3990 = lang.IFn_Cast(root_3988) } else { ifn_3990 = nil }; var arg_3991 any = o__2; var arg_3992 any = A_arbace_go_check_A_const_325; var arg_3993 any; var root_3994 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = as__1; if linked_3995 == nil { arg_3993 = ifn_3996.Invoke_O__O(arg_3997) } else { arg_3993 = linked_3995.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3994, arg_3997) }; if linked_3989 == nil { tmp14 = ifn_3990.Invoke_O_O_O__O(arg_3991, arg_3992, arg_3993) } else { tmp14 = linked_3989.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3988, arg_3991, arg_3992, arg_3993) }; as__1, o__2 = tmp13, tmp14; continue L1 }
//line :606:1
		default:
		}


		var tmp15 any; var root_3998 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3998, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4000 lang.IFn; if linked_3999 == nil { ifn_4000 = lang.IFn_Cast(root_3998) } else { ifn_4000 = nil }; var arg_4001 any = as__1; if linked_3999 == nil { tmp15 = ifn_4000.Invoke_O__O(arg_4001) } else { tmp15 = linked_3999.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3998, arg_4001) }; var tmp16 any = tmp15; var tmp17 any; var root_4002 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4002, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4004 lang.IFn; if linked_4003 == nil { ifn_4004 = lang.IFn_Cast(root_4002) } else { ifn_4004 = nil }; var arg_4005 any = o__2; var arg_4006 any = A_arbace_go_check_A_const_352; var arg_4007 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4008 any; var root_4009 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4009, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4011 lang.IFn; if linked_4010 == nil { ifn_4011 = lang.IFn_Cast(root_4009) } else { ifn_4011 = nil }; var arg_4012 any = as__1; if linked_4010 == nil { arg_4008 = ifn_4011.Invoke_O__O(arg_4012) } else { arg_4008 = linked_4010.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4009, arg_4012) }; if linked_4003 == nil { tmp17 = ifn_4004.Invoke_O_O_O_O__O(arg_4005, arg_4006, arg_4007, arg_4008) } else { tmp17 = linked_4003.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4002, arg_4005, arg_4006, arg_4007, arg_4008) }; as__1, o__2 = tmp16, tmp17; continue L1 } } }; /*line :603:1*/panic("j2g: unreachable") }








func A_arbace_go_check__main_iter__1685000454__1685000458_A_New_O(p0 any) *A_arbace_go_check__main_iter__1685000454__1685000458_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000454__1685000458_A{}; t.Ctor_O(p0); return t }
//line :612:1
func (t *A_arbace_go_check__main_iter__1685000454__1685000458_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :612:1
func (t *A_arbace_go_check__main_iter__1685000454__1685000458_A) Invoke_O_O__O(self, s__1685000455__1 any) any { var tmp1 any = A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A_New_O_O_O(t.F_opts, s__1685000455__1, self); var tmp2 *jrt.Class; var fncls__4089 *jrt.Class = A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A_fn_class; if fncls__4089 == nil { var fncls__4089d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A_fn_class = fncls__4089d; tmp2 = fncls__4089d } else { tmp2 = fncls__4089 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :612:1
func A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :612:1
func (t *A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A) Ctor_O_O_O(c__opts, c__s__1685000455, c__iter__1685000454 any) { t.F_opts = c__opts; t.F_s__1685000455 = c__s__1685000455; t.F_iter__1685000454 = c__iter__1685000454 }
//line :612:1
func (t *A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A) Invoke_O__O(self any) any { { var s__1685000455__1 any; var t_ any = t.F_s__1685000455; t.F_s__1685000455 = nil; s__1685000455__1 = t_; for { var temp__1927000414__auto____2 any; var root_4022 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4022, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4024 lang.IFn; if linked_4023 == nil { ifn_4024 = lang.IFn_Cast(root_4022) } else { ifn_4024 = nil }; var arg_4025 any = s__1685000455__1; if linked_4023 == nil { temp__1927000414__auto____2 = ifn_4024.Invoke_O__O(arg_4025) } else { temp__1927000414__auto____2 = linked_4023.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4022, arg_4025) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000455__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4026 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4026, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4028 lang.IFn; if linked_4027 == nil { ifn_4028 = lang.IFn_Cast(root_4026) } else { ifn_4028 = nil }; var arg_4029 any = s__1685000455__3; if linked_4027 == nil { tmp1 = ifn_4028.Invoke_O__O(arg_4029) } else { tmp1 = linked_4027.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4026, arg_4029) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4030 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4030, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4032 lang.IFn; if linked_4031 == nil { ifn_4032 = lang.IFn_Cast(root_4030) } else { ifn_4032 = nil }; var arg_4033 any = s__1685000455__3; if linked_4031 == nil { c__1927001037__auto____4 = ifn_4032.Invoke_O__O(arg_4033) } else { c__1927001037__auto____4 = linked_4031.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4030, arg_4033) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000457__6 any; var root_4034 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_4035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4034, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4036 lang.IFn; if linked_4035 == nil { ifn_4036 = lang.IFn_Cast(root_4034) } else { ifn_4036 = nil }; var arg_4037 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4035 == nil { b__1685000457__6 = ifn_4036.Invoke_O__O(arg_4037) } else { b__1685000457__6 = linked_4035.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4034, arg_4037) }; var tmp2 any = A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A_New_O_O_I_O(b__1685000457__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4048 *jrt.Class = A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A_fn_class; if fncls__4048 == nil { var fncls__4048d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A_fn_class = fncls__4048d; tmp3 = fncls__4048d } else { tmp3 = fncls__4048 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4049 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any; var root_4054 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_4055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4054, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4056 lang.IFn; if linked_4055 == nil { ifn_4056 = lang.IFn_Cast(root_4054) } else { ifn_4056 = nil }; var arg_4057 any = b__1685000457__6; if linked_4055 == nil { arg_4052 = ifn_4056.Invoke_O__O(arg_4057) } else { arg_4052 = linked_4055.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4054, arg_4057) }; var arg_4053 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000454); var tmp5 any; var root_4058 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4058, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4060 lang.IFn; if linked_4059 == nil { ifn_4060 = lang.IFn_Cast(root_4058) } else { ifn_4060 = nil }; var arg_4061 any = s__1685000455__3; if linked_4059 == nil { tmp5 = ifn_4060.Invoke_O__O(arg_4061) } else { tmp5 = linked_4059.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4058, arg_4061) }; arg_4053 = tmp4.Invoke_O__O(tmp5); if linked_4050 == nil { return ifn_4051.Invoke_O_O__O(arg_4052, arg_4053) } else { return linked_4050.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4049, arg_4052, arg_4053) } } else { var root_4062 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_4063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4062, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4064 lang.IFn; if linked_4063 == nil { ifn_4064 = lang.IFn_Cast(root_4062) } else { ifn_4064 = nil }; var arg_4065 any; var root_4067 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_4068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4067, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4069 lang.IFn; if linked_4068 == nil { ifn_4069 = lang.IFn_Cast(root_4067) } else { ifn_4069 = nil }; var arg_4070 any = b__1685000457__6; if linked_4068 == nil { arg_4065 = ifn_4069.Invoke_O__O(arg_4070) } else { arg_4065 = linked_4068.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4067, arg_4070) }; var arg_4066 any; if linked_4063 == nil { return ifn_4064.Invoke_O_O__O(arg_4065, arg_4066) } else { return linked_4063.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4062, arg_4065, arg_4066) } } } else { var c__4 any; var root_4071 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4071, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4073 lang.IFn; if linked_4072 == nil { ifn_4073 = lang.IFn_Cast(root_4071) } else { ifn_4073 = nil }; var arg_4074 any = s__1685000455__3; if linked_4072 == nil { c__4 = ifn_4073.Invoke_O__O(arg_4074) } else { c__4 = linked_4072.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4071, arg_4074) }; var root_4075 any = A_arbace_go_check_A_const_150.GetRawRoot__O(); var linked_4076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4075, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4077 lang.IFn; if linked_4076 == nil { ifn_4077 = lang.IFn_Cast(root_4075) } else { ifn_4077 = nil }; var arg_4078 any; var root_4080 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_4081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4080, A_arbace_go_check_annotations_A_fn_class); var ifn_4082 lang.IFn; if linked_4081 == nil { ifn_4082 = lang.IFn_Cast(root_4080) } else { ifn_4082 = nil }; var arg_4083 any = c__4; var arg_4084 any = t.F_opts; if linked_4081 == nil { arg_4078 = ifn_4082.Invoke_O_O__O(arg_4083, arg_4084) } else { arg_4078 = linked_4081.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4080, arg_4083, arg_4084) }; var arg_4079 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000454); var tmp7 any; var root_4085 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_4086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4085, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4087 lang.IFn; if linked_4086 == nil { ifn_4087 = lang.IFn_Cast(root_4085) } else { ifn_4087 = nil }; var arg_4088 any = s__1685000455__3; if linked_4086 == nil { tmp7 = ifn_4087.Invoke_O__O(arg_4088) } else { tmp7 = linked_4086.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4085, arg_4088) }; arg_4079 = tmp6.Invoke_O__O(tmp7); if linked_4076 == nil { return ifn_4077.Invoke_O_O__O(arg_4078, arg_4079) } else { return linked_4076.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4075, arg_4078, arg_4079) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :612:1
func A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :612:1
func (t *A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A) Ctor_O_O_I_O(c__b__1685000457, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000457 = c__b__1685000457; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :612:1
func (t *A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A) Invoke_O__O(self any) any { { var i__1685000456__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000456__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000456__1)); var root_4038 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_4039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4038, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4040 lang.IFn; if linked_4039 == nil { ifn_4040 = lang.IFn_Cast(root_4038) } else { ifn_4040 = nil }; var arg_4041 any = t.F_b__1685000457; var arg_4042 any; var root_4043 any = A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_4044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4043, A_arbace_go_check_annotations_A_fn_class); var ifn_4045 lang.IFn; if linked_4044 == nil { ifn_4045 = lang.IFn_Cast(root_4043) } else { ifn_4045 = nil }; var arg_4046 any = c__2; var arg_4047 any = t.F_opts; if linked_4044 == nil { arg_4042 = ifn_4045.Invoke_O_O__O(arg_4046, arg_4047) } else { arg_4042 = linked_4044.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4043, arg_4046, arg_4047) }; if linked_4039 == nil { ifn_4040.Invoke_O_O__O(arg_4041, arg_4042) } else { linked_4039.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4038, arg_4041, arg_4042) }; i__1685000456__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000456__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Keyword

var A_arbace_go_check_A_const_55 *lang.Var

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Keyword

var A_arbace_go_check_A_const_61 *lang.Var

var A_arbace_go_check_A_const_62 *lang.Keyword

var A_arbace_go_check_A_const_63 *lang.Var

var A_arbace_go_check_A_const_64 *lang.Keyword

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Var

var A_arbace_go_check_A_const_67 *lang.Keyword

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Var

var A_arbace_go_check_A_const_73 *lang.Keyword

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Var

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 any

var A_arbace_go_check_A_const_78 *lang.Keyword

var A_arbace_go_check_A_const_79 *lang.Var

var A_arbace_go_check_A_const_80 *lang.Keyword

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Var

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Keyword

var A_arbace_go_check_A_const_90 *lang.Var

var A_arbace_go_check_A_const_91 *lang.Keyword

var A_arbace_go_check_A_const_92 *lang.Var

var A_arbace_go_check_A_const_93 *lang.Keyword

var A_arbace_go_check_A_const_94 any

var A_arbace_go_check_A_const_95 *lang.Keyword

var A_arbace_go_check_A_const_96 *lang.Var

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 any

var A_arbace_go_check_A_const_99 *lang.Keyword

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Var

var A_arbace_go_check_A_const_102 *lang.Keyword

var A_arbace_go_check_A_const_103 *lang.Keyword

var A_arbace_go_check_A_const_104 *lang.Keyword

var A_arbace_go_check_A_const_105 *lang.Keyword

var A_arbace_go_check_A_const_106 *lang.Keyword

var A_arbace_go_check_A_const_107 *lang.Keyword

var A_arbace_go_check_A_const_108 *lang.Keyword

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Var

var A_arbace_go_check_A_const_113 *lang.Var

var A_arbace_go_check_A_const_114 *lang.Keyword

var A_arbace_go_check_A_const_115 *lang.Var

var A_arbace_go_check_A_const_116 *lang.Var

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Var

var A_arbace_go_check_A_const_119 any

var A_arbace_go_check_A_const_120 *lang.Var

var A_arbace_go_check_A_const_121 *lang.Var

var A_arbace_go_check_A_const_122 *lang.Var

var A_arbace_go_check_A_const_123 any

var A_arbace_go_check_A_const_124 any

var A_arbace_go_check_A_const_125 *lang.Var

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Keyword

var A_arbace_go_check_A_const_128 *lang.Keyword

var A_arbace_go_check_A_const_129 any

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Keyword

var A_arbace_go_check_A_const_133 *lang.Keyword

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 *lang.Keyword

var A_arbace_go_check_A_const_138 *lang.Var

var A_arbace_go_check_A_const_139 *lang.Var

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 *lang.Var

var A_arbace_go_check_A_const_142 *lang.Keyword

var A_arbace_go_check_A_const_143 *lang.Keyword

var A_arbace_go_check_A_const_144 *lang.Keyword

var A_arbace_go_check_A_const_145 *lang.Var

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Var

var A_arbace_go_check_A_const_151 *lang.Keyword

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Keyword

var A_arbace_go_check_A_const_154 *lang.Keyword

var A_arbace_go_check_A_const_155 *lang.Var

var A_arbace_go_check_A_const_156 *lang.Var

var A_arbace_go_check_A_const_157 *lang.Var

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Var

var A_arbace_go_check_A_const_164 *lang.Var

var A_arbace_go_check_A_const_165 *lang.Var

var A_arbace_go_check_A_const_166 *lang.Var

var A_arbace_go_check_A_const_167 *lang.Var

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Keyword

var A_arbace_go_check_A_const_186 *lang.Keyword

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Keyword

var A_arbace_go_check_A_const_189 *lang.Keyword

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Var

var A_arbace_go_check_A_const_192 *lang.Keyword

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Var

var A_arbace_go_check_A_const_197 *lang.Keyword

var A_arbace_go_check_A_const_198 *lang.Var

var A_arbace_go_check_A_const_199 *lang.Var

var A_arbace_go_check_A_const_200 *lang.Var

var A_arbace_go_check_A_const_201 *lang.Var

var A_arbace_go_check_A_const_202 *lang.Keyword

var A_arbace_go_check_A_const_203 *lang.Keyword

var A_arbace_go_check_A_const_204 *lang.Keyword

var A_arbace_go_check_A_const_205 *lang.Var

var A_arbace_go_check_A_const_206 *lang.Var

var A_arbace_go_check_A_const_207 *lang.Keyword

var A_arbace_go_check_A_const_208 *lang.Keyword

var A_arbace_go_check_A_const_209 *lang.Var

var A_arbace_go_check_A_const_210 *lang.Var

var A_arbace_go_check_A_const_211 *lang.Var

var A_arbace_go_check_A_const_212 *lang.Keyword

var A_arbace_go_check_A_const_213 *lang.Keyword

var A_arbace_go_check_A_const_214 *lang.Keyword

var A_arbace_go_check_A_const_215 *lang.Keyword

var A_arbace_go_check_A_const_216 *lang.Var

var A_arbace_go_check_A_const_217 any

var A_arbace_go_check_A_const_218 any

var A_arbace_go_check_A_const_219 *lang.Keyword

var A_arbace_go_check_A_const_220 *lang.Keyword

var A_arbace_go_check_A_const_221 *lang.Keyword

var A_arbace_go_check_A_const_222 *lang.Keyword

var A_arbace_go_check_A_const_223 *lang.Var

var A_arbace_go_check_A_const_224 *lang.Keyword

var A_arbace_go_check_A_const_225 *lang.Keyword

var A_arbace_go_check_A_const_226 *lang.Keyword

var A_arbace_go_check_A_const_227 *lang.Keyword

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Keyword

var A_arbace_go_check_A_const_230 *lang.Var

var A_arbace_go_check_A_const_231 *lang.Var

var A_arbace_go_check_A_const_232 *lang.Keyword

var A_arbace_go_check_A_const_233 *lang.Var

var A_arbace_go_check_A_const_234 *lang.Var

var A_arbace_go_check_A_const_235 *lang.Keyword

var A_arbace_go_check_A_const_236 *lang.Var

var A_arbace_go_check_A_const_237 *lang.Var

var A_arbace_go_check_A_const_238 *lang.Var

var A_arbace_go_check_A_const_239 any

var A_arbace_go_check_A_const_240 *lang.Keyword

var A_arbace_go_check_A_const_241 *lang.Var

var A_arbace_go_check_A_const_242 *lang.Var

var A_arbace_go_check_A_const_243 *lang.Var

var A_arbace_go_check_A_const_244 *lang.Var

var A_arbace_go_check_A_const_245 *lang.Var

var A_arbace_go_check_A_const_246 *lang.Var

var A_arbace_go_check_A_const_247 *lang.Keyword

var A_arbace_go_check_A_const_248 *lang.Keyword

var A_arbace_go_check_A_const_249 *lang.Var

var A_arbace_go_check_A_const_250 *lang.Keyword

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 *lang.Keyword

var A_arbace_go_check_A_const_253 *lang.Var

var A_arbace_go_check_A_const_254 *lang.Keyword

var A_arbace_go_check_A_const_255 any

var A_arbace_go_check_A_const_256 *lang.Keyword

var A_arbace_go_check_A_const_257 any

var A_arbace_go_check_A_const_258 any

var A_arbace_go_check_A_const_259 any

var A_arbace_go_check_A_const_260 *lang.Keyword

var A_arbace_go_check_A_const_261 *lang.Keyword

var A_arbace_go_check_A_const_262 any

var A_arbace_go_check_A_const_263 *lang.Var

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Var

var A_arbace_go_check_A_const_266 *lang.Var

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 any

var A_arbace_go_check_A_const_269 *lang.Var

var A_arbace_go_check_A_const_270 *lang.Keyword

var A_arbace_go_check_A_const_271 *lang.Keyword

var A_arbace_go_check_A_const_272 *lang.Keyword

var A_arbace_go_check_A_const_273 *lang.Keyword

var A_arbace_go_check_A_const_274 *lang.Var

var A_arbace_go_check_A_const_275 *lang.Var

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Var

var A_arbace_go_check_A_const_278 *lang.Var

var A_arbace_go_check_A_const_279 *lang.Var

var A_arbace_go_check_A_const_280 *lang.Keyword

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Var

var A_arbace_go_check_A_const_283 *lang.Var

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 *lang.Var

var A_arbace_go_check_A_const_286 any

var A_arbace_go_check_A_const_287 *lang.Var

var A_arbace_go_check_A_const_288 any

var A_arbace_go_check_A_const_289 any

var A_arbace_go_check_A_const_290 *lang.Var

var A_arbace_go_check_A_const_291 *lang.Keyword

var A_arbace_go_check_A_const_292 *lang.Keyword

var A_arbace_go_check_A_const_293 *lang.Keyword

var A_arbace_go_check_A_const_294 *lang.Keyword

var A_arbace_go_check_A_const_295 *lang.Keyword

var A_arbace_go_check_A_const_296 *lang.Var

var A_arbace_go_check_A_const_297 *lang.Keyword

var A_arbace_go_check_A_const_298 *lang.Keyword

var A_arbace_go_check_A_const_299 *lang.Var

var A_arbace_go_check_A_const_300 *lang.Keyword

var A_arbace_go_check_A_const_301 any

var A_arbace_go_check_A_const_302 *lang.Keyword

var A_arbace_go_check_A_const_303 *lang.Keyword

var A_arbace_go_check_A_const_304 *lang.Var

var A_arbace_go_check_A_const_305 any

var A_arbace_go_check_A_const_306 any

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 *lang.Var

var A_arbace_go_check_A_const_309 any

var A_arbace_go_check_A_const_310 *lang.Var

var A_arbace_go_check_A_const_311 any

var A_arbace_go_check_A_const_312 *lang.Var

var A_arbace_go_check_A_const_313 *lang.Var

var A_arbace_go_check_A_const_314 *lang.Var

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 *lang.Var

var A_arbace_go_check_A_const_322 *lang.Var

var A_arbace_go_check_A_const_323 *lang.Keyword

var A_arbace_go_check_A_const_324 *lang.Keyword

var A_arbace_go_check_A_const_325 *lang.Keyword

var A_arbace_go_check_A_const_326 *lang.Var

var A_arbace_go_check_A_const_327 *lang.Var

var A_arbace_go_check_A_const_328 *jrt.Class

var A_arbace_go_check_A_const_329 *lang.Var

var A_arbace_go_check_A_const_330 *lang.Var

var A_arbace_go_check_A_const_331 *lang.Var

var A_arbace_go_check_A_const_332 any

var A_arbace_go_check_A_const_333 any

var A_arbace_go_check_A_const_334 any

var A_arbace_go_check_A_const_335 *lang.Keyword

var A_arbace_go_check_A_const_336 *lang.Var

var A_arbace_go_check_A_const_337 *lang.Keyword

var A_arbace_go_check_A_const_338 *lang.Keyword

var A_arbace_go_check_A_const_339 *lang.Var

var A_arbace_go_check_A_const_340 *lang.Var

var A_arbace_go_check_A_const_341 any

var A_arbace_go_check_A_const_342 any

var A_arbace_go_check_A_const_343 any

var A_arbace_go_check_A_const_344 any

var A_arbace_go_check_A_const_345 any

var A_arbace_go_check_A_const_346 any

var A_arbace_go_check_A_const_347 *lang.Var

var A_arbace_go_check_A_const_348 any

var A_arbace_go_check_A_const_349 any

var A_arbace_go_check_A_const_350 any

var A_arbace_go_check_A_const_351 any

var A_arbace_go_check_A_const_352 *lang.Keyword

var A_arbace_go_check_A_const_353 *lang.Var

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_const_359 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 526); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[166]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[167]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[168]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[169]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[170]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[171]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[172]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[173]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[174]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[175]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[176]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[177]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[178]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[179]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[180]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[181]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[182]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[183]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[184]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[185]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[186]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[187]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[189]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[190]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[191]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[192]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[193]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[194]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[195]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[196]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[200]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[203] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[204]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[205]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[207]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[208]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[209]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[213]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[214]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[215]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[216]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[220]); A_arbace_go_check_A_const_55 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[221]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[223]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[224]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[226]); A_arbace_go_check_A_const_61 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[228]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[231]); A_arbace_go_check_A_const_66 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[232]); A_arbace_go_check_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[233]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_72 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[240]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_77 = A_arbace_go_check_A_const_pool.A[243]; A_arbace_go_check_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_79 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[245]); A_arbace_go_check_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_86 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[252]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_90 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[257]); A_arbace_go_check_A_const_92 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[259]); A_arbace_go_check_A_const_94 = A_arbace_go_check_A_const_pool.A[260]; A_arbace_go_check_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_96 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_98 = A_arbace_go_check_A_const_pool.A[264] }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_101 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_102 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[269]); A_arbace_go_check_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[276]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_112 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_113 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_115 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[281]); A_arbace_go_check_A_const_116 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[282]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[283]); A_arbace_go_check_A_const_118 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_119 = A_arbace_go_check_A_const_pool.A[285]; A_arbace_go_check_A_const_120 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_121 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_122 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[288]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = A_arbace_go_check_A_const_pool.A[289]; A_arbace_go_check_A_const_124 = A_arbace_go_check_A_const_pool.A[290]; A_arbace_go_check_A_const_125 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]); A_arbace_go_check_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_129 = A_arbace_go_check_A_const_pool.A[295]; A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_132 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_133 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[300]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_137 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_138 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_139 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[305]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_141 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_142 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_144 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_145 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[312]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_150 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[316]); A_arbace_go_check_A_const_151 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[317]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_153 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[319]); A_arbace_go_check_A_const_154 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[320]); A_arbace_go_check_A_const_155 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[321]); A_arbace_go_check_A_const_156 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_157 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[324]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_163 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[329]); A_arbace_go_check_A_const_164 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_165 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_166 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_167 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[336]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[348]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_185 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_186 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]); A_arbace_go_check_A_const_188 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_189 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_191 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_192 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_196 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_197 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_198 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_199 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]); A_arbace_go_check_A_const_200 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_201 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_202 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_203 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_204 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_205 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_206 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_208 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_209 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_210 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_211 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[377]); A_arbace_go_check_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_215 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_216 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_217 = A_arbace_go_check_A_const_pool.A[383]; A_arbace_go_check_A_const_218 = A_arbace_go_check_A_const_pool.A[384] }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_221 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_222 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_223 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]); A_arbace_go_check_A_const_224 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_230 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_233 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_234 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[401]); A_arbace_go_check_A_const_236 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_237 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_238 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_239 = A_arbace_go_check_A_const_pool.A[405]; A_arbace_go_check_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_241 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_242 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[408]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_244 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_245 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_246 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_247 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[413]); A_arbace_go_check_A_const_248 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_249 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_252 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_253 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_254 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_255 = A_arbace_go_check_A_const_pool.A[421]; A_arbace_go_check_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_257 = A_arbace_go_check_A_const_pool.A[423]; A_arbace_go_check_A_const_258 = A_arbace_go_check_A_const_pool.A[424]; A_arbace_go_check_A_const_259 = A_arbace_go_check_A_const_pool.A[425]; A_arbace_go_check_A_const_260 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_261 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_262 = A_arbace_go_check_A_const_pool.A[428]; A_arbace_go_check_A_const_263 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[429]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[430]); A_arbace_go_check_A_const_265 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_266 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[433]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = A_arbace_go_check_A_const_pool.A[434]; A_arbace_go_check_A_const_269 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[435]); A_arbace_go_check_A_const_270 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[436]); A_arbace_go_check_A_const_271 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_272 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]); A_arbace_go_check_A_const_273 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_274 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_275 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_277 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_278 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_279 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[445]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_282 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_283 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]); A_arbace_go_check_A_const_285 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[451]); A_arbace_go_check_A_const_286 = A_arbace_go_check_A_const_pool.A[452]; A_arbace_go_check_A_const_287 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_288 = A_arbace_go_check_A_const_pool.A[454]; A_arbace_go_check_A_const_289 = A_arbace_go_check_A_const_pool.A[455]; A_arbace_go_check_A_const_290 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_291 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[457]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_293 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_294 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_295 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_296 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]); A_arbace_go_check_A_const_297 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_298 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_299 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_300 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_301 = A_arbace_go_check_A_const_pool.A[467]; A_arbace_go_check_A_const_302 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_303 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[469]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_304 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_305 = A_arbace_go_check_A_const_pool.A[471]; A_arbace_go_check_A_const_306 = A_arbace_go_check_A_const_pool.A[472]; A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[473]); A_arbace_go_check_A_const_308 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[474]); A_arbace_go_check_A_const_309 = A_arbace_go_check_A_const_pool.A[475]; A_arbace_go_check_A_const_310 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[476]); A_arbace_go_check_A_const_311 = A_arbace_go_check_A_const_pool.A[477]; A_arbace_go_check_A_const_312 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[478]); A_arbace_go_check_A_const_313 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[479]); A_arbace_go_check_A_const_314 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[480]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[481]); A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[482]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[483]); A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[484]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[486]); A_arbace_go_check_A_const_321 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[487]); A_arbace_go_check_A_const_322 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[488]); A_arbace_go_check_A_const_323 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_324 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_325 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_326 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_327 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_328 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[494]) }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_329 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[495]); A_arbace_go_check_A_const_330 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_331 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_332 = A_arbace_go_check_A_const_pool.A[498]; A_arbace_go_check_A_const_333 = A_arbace_go_check_A_const_pool.A[499]; A_arbace_go_check_A_const_334 = A_arbace_go_check_A_const_pool.A[500]; A_arbace_go_check_A_const_335 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_336 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_337 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_338 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_339 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_340 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[506]); A_arbace_go_check_A_const_341 = A_arbace_go_check_A_const_pool.A[507] }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = A_arbace_go_check_A_const_pool.A[508]; A_arbace_go_check_A_const_343 = A_arbace_go_check_A_const_pool.A[509]; A_arbace_go_check_A_const_344 = A_arbace_go_check_A_const_pool.A[510]; A_arbace_go_check_A_const_345 = A_arbace_go_check_A_const_pool.A[511]; A_arbace_go_check_A_const_346 = A_arbace_go_check_A_const_pool.A[512]; A_arbace_go_check_A_const_347 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[513]); A_arbace_go_check_A_const_348 = A_arbace_go_check_A_const_pool.A[514]; A_arbace_go_check_A_const_349 = A_arbace_go_check_A_const_pool.A[515]; A_arbace_go_check_A_const_350 = A_arbace_go_check_A_const_pool.A[516]; A_arbace_go_check_A_const_351 = A_arbace_go_check_A_const_pool.A[517]; A_arbace_go_check_A_const_352 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_353 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[521]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[522]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[523]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[524]); A_arbace_go_check_A_const_359 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[525]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000451_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000451_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000454__1685000458_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_iter__1685000454__1685000458_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A struct{ j2g_header uint64; F_opts, F_s__1685000455, F_iter__1685000454 any }

var A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A struct{ j2g_header uint64; F_b__1685000457, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_iter__1685000454__1685000458_fn__1685000459_fn__1685000460_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000426__1685000432_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000426__1685000432_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A struct{ j2g_header uint64; F_iter__1685000426, F_s__1685000427 any }

var A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A struct{ j2g_header uint64; F_iter__1685000428, F_r, F_s__1685000429 any }

var A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A struct{ j2g_header uint64; F_b__1685000431, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_annotations_iter__1685000426__1685000432_fn__1685000433_iter__1685000428__1685000434_fn__1685000435_fn__1685000436_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000306_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000306_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000314_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000314_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000320_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000334_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000320_fn__1685000336_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A struct{ j2g_header uint64; F_s__1685000325, F_iter__1685000324 any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A struct{ j2g_header uint64; F_b__1685000327 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000324__1685000328_fn__1685000329_fn__1685000330_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A struct{ j2g_header uint64; F_iter__1685000338, F_dir, F_tdir, F_ts, F_s__1685000339 any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_b__1685000341, F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000348_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000320_iter__1685000338__1685000342_fn__1685000343_fn__1685000354_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000296__1685000300_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A struct{ j2g_header uint64; F_s__1685000297, F_iter__1685000296 any }

var A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A struct{ j2g_header uint64; F_b__1685000299 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_iter__1685000296__1685000300_fn__1685000301_fn__1685000302_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000100_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000100_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000102_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000102_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000142_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000142_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000149_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000149_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000156_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000156_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000166_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000166_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000168_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000168_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000186_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000186_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000188_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000188_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000194_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000194_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000197_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000201_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000203_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000205_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000207_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000209_fn__1685000210_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000229_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000233_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000197_fn__1685000235_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A struct{ j2g_header uint64; F_s__1685000214, F_iter__1685000213, F_verified any }

var A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A struct{ j2g_header uint64; F_b__1685000216 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1685000197_iter__1685000213__1685000217_fn__1685000218_fn__1685000219_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000242_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000242_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000178_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000178_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000178_one__1685000179_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000244__1685000248_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000244__1685000248_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A struct{ j2g_header uint64; F_s__1685000245, F_iter__1685000244 any }

var A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A struct{ j2g_header uint64; F_b__1685000247 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000244__1685000248_fn__1685000249_fn__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000182_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000182_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000182_fn__1685000183_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000260_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000260_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000403_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000403_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000405__1685000409_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000405__1685000409_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A struct{ j2g_header uint64; F_iter__1685000405, F_s__1685000406 any }

var A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A struct{ j2g_header uint64; F_b__1685000408 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000405__1685000409_fn__1685000410_fn__1685000411_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000383__1685000389_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000383__1685000389_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A struct{ j2g_header uint64; F_s__1685000384, F_iter__1685000383 any }

var A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A struct{ j2g_header uint64; F_r, F_s__1685000386, F_iter__1685000385 any }

var A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A struct{ j2g_header uint64; F_b__1685000388, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_report_errors_iter__1685000383__1685000389_fn__1685000390_iter__1685000385__1685000391_fn__1685000392_fn__1685000393_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000257_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000257_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000274__1685000278_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A struct{ j2g_header uint64; F_f, F_out, F_q, F_s__1685000275, F_xs, F_iter__1685000274 any }

var A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A struct{ j2g_header uint64; F_b__1685000277, F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000280_fn__1685000281_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000274__1685000278_fn__1685000279_fn__1685000284_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000269_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000269_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000269_fn__1685000270_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000370_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000372_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000372_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000374_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000374_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000376_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000376_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000378_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000378_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000380_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000380_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000368_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000368_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000366_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000419_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000419_A_fn_class *jrt.Class
