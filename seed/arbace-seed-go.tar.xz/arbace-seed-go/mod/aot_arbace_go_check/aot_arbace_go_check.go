//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_117)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var fnbody__45 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp1 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__45); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp1 = fncls__44d } else { tmp1 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp1, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var fnbody__162 any = any(body_walk__4); var tmp2 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__162); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__161d; tmp2 = fncls__161d } else { tmp2 = fncls__161 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp2, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_46 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = acc__2; if linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_46, arg_49) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_50 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_52 lang.IFn
	if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = f__1; if linked_51 == nil { tmp1 = ifn_52.Invoke_O__O(arg_53) } else { tmp1 = linked_51.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_50, arg_53) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_90 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = in_meta__2; if linked_91 == nil { and__1927000168__auto____5 = ifn_92.Invoke_O__O(arg_93) } else { and__1927000168__auto____5 = linked_91.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_94 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_go_check_A_const_37; var arg_98 any; var root_99 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = f__1; if linked_100 == nil { arg_98 = ifn_101.Invoke_O__O(arg_102) } else { arg_98 = linked_100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_99, arg_102) }; if linked_95 == nil { tmp2 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { tmp2 = linked_95.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_94, arg_97, arg_98) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_103 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = f__1; if linked_104 == nil { tmp5 = ifn_105.Invoke_O__O(arg_106) } else { tmp5 = linked_104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_103, arg_106) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_107 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = m__3; var arg_111 any = A_arbace_go_check_A_const_40; if linked_108 == nil { tmp3 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { tmp3 = linked_108.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_112 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = f__1; if linked_113 == nil { tmp8 = ifn_114.Invoke_O__O(arg_115) } else { tmp8 = linked_113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_112, arg_115) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_116 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = v__5; if linked_117 == nil { tmp12 = ifn_118.Invoke_O__O(arg_119) } else { tmp12 = linked_117.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_66 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = f__1; if linked_67 == nil { tmp14 = ifn_68.Invoke_O__O(arg_69) } else { tmp14 = linked_67.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_66, arg_69) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_70 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_72 lang.IFn







		if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = f__1; if linked_71 == nil { seq_1685000015__3 = ifn_72.Invoke_O__O(arg_73) } else { seq_1685000015__3 = linked_71.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_70, arg_73) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_74 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = seq_1685000015__3; if linked_75 == nil { temp__1927000414__auto____7 = ifn_76.Invoke_O__O(arg_77) } else { temp__1927000414__auto____7 = linked_75.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_74, arg_77) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_78 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = seq_1685000015__8; if linked_79 == nil { tmp15 = ifn_80.Invoke_O__O(arg_81) } else { tmp15 = linked_79.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_82 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq_1685000015__8; if linked_83 == nil { c__1927000678__auto____9 = ifn_84.Invoke_O__O(arg_85) } else { c__1927000678__auto____9 = linked_83.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_82, arg_85) }; var tmp16 any; var root_120 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = seq_1685000015__8; if linked_121 == nil { tmp16 = ifn_122.Invoke_O__O(arg_123) } else { tmp16 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_120, arg_123) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_86 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq_1685000015__8; if linked_87 == nil { x__9 = ifn_88.Invoke_O__O(arg_89) } else { x__9 = linked_87.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_86, arg_89) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_124 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = seq_1685000015__8; if linked_125 == nil { tmp17 = ifn_126.Invoke_O__O(arg_127) } else { tmp17 = linked_125.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_124, arg_127) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_54 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_56 lang.IFn









			if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = f__1; if linked_55 == nil { tmp19 = ifn_56.Invoke_O__O(arg_57) } else { tmp19 = linked_55.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_54, arg_57) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_128 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_130 lang.IFn











				if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = m__3_2; var arg_132 any = A_arbace_go_check_A_const_40; if linked_129 == nil { tmp20 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { tmp20 = linked_129.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_128, arg_131, arg_132) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_58 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_60 lang.IFn















					if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = f__1; if linked_59 == nil { tmp21 = ifn_60.Invoke_O__O(arg_61) } else { tmp21 = linked_59.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_58, arg_61) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_133 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_135 lang.IFn















						if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = f__1; if linked_134 == nil { seq_1685000019__3 = ifn_135.Invoke_O__O(arg_136) } else { seq_1685000019__3 = linked_134.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_133, arg_136) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_137 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = seq_1685000019__3; if linked_138 == nil { temp__1927000414__auto____7_2 = ifn_139.Invoke_O__O(arg_140) } else { temp__1927000414__auto____7_2 = linked_138.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_141 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = seq_1685000019__8; if linked_142 == nil { tmp22 = ifn_143.Invoke_O__O(arg_144) } else { tmp22 = linked_142.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_145 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = seq_1685000019__8; if linked_146 == nil { c__1927000678__auto____9_2 = ifn_147.Invoke_O__O(arg_148) } else { c__1927000678__auto____9_2 = linked_146.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_145, arg_148) }; var tmp23 any; var root_153 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = seq_1685000019__8; if linked_154 == nil { tmp23 = ifn_155.Invoke_O__O(arg_156) } else { tmp23 = linked_154.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_153, arg_156) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_149 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = seq_1685000019__8; if linked_150 == nil { x__9_2 = ifn_151.Invoke_O__O(arg_152) } else { x__9_2 = linked_150.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_149, arg_152) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_157 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = seq_1685000019__8; if linked_158 == nil { tmp24 = ifn_159.Invoke_O__O(arg_160) } else { tmp24 = linked_158.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_157, arg_160) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_62 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_64 lang.IFn

















							if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = f__1; if linked_63 == nil { tmp26 = ifn_64.Invoke_O__O(arg_65) } else { tmp26 = linked_63.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_62, arg_65) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var fnbody__240 any = any(body_walk__4); var tmp1 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__240); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__239d; tmp1 = fncls__239d } else { tmp1 = fncls__239 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__240, tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_163 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_165 lang.IFn
		if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = x__1; if linked_164 == nil { tmp1 = ifn_165.Invoke_O__O(arg_166) } else { tmp1 = linked_164.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_163, arg_166) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.IdentityHashMap_Cast(t.F_seen).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayList_Cast(t.F_acc).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_167 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_169 lang.IFn

				if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = x__1; if linked_168 == nil { seq_1685000026__2 = ifn_169.Invoke_O__O(arg_170) } else { seq_1685000026__2 = linked_168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_167, arg_170) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_171 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_172 == nil { tmp2 = ifn_173.Invoke_O__O(arg_174) } else { tmp2 = linked_172.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_171, arg_174) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_175 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = seq_1685000026__2; if linked_176 == nil { temp__1927000414__auto____6 = ifn_177.Invoke_O__O(arg_178) } else { temp__1927000414__auto____6 = linked_176.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_175, arg_178) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_179 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = seq_1685000026__7; if linked_180 == nil { tmp3 = ifn_181.Invoke_O__O(arg_182) } else { tmp3 = linked_180.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_179, arg_182) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_183 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = seq_1685000026__7; if linked_184 == nil { c__1927000678__auto____8 = ifn_185.Invoke_O__O(arg_186) } else { c__1927000678__auto____8 = linked_184.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_183, arg_186) }; var tmp4 any; var root_219 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = seq_1685000026__7; if linked_220 == nil { tmp4 = ifn_221.Invoke_O__O(arg_222) } else { tmp4 = linked_220.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_219, arg_222) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_187 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = seq_1685000026__7; if linked_188 == nil { vec__1685000033__8 = ifn_189.Invoke_O__O(arg_190) } else { vec__1685000033__8 = linked_188.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_187, arg_190) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_191 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_192 == nil { tmp5 = ifn_193.Invoke_O__O(arg_194) } else { tmp5 = linked_192.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_223 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = seq_1685000026__7; if linked_224 == nil { tmp6 = ifn_225.Invoke_O__O(arg_226) } else { tmp6 = linked_224.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_223, arg_226) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_227 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = seq_1685000026__7; if linked_228 == nil { tmp7 = ifn_229.Invoke_O__O(arg_230) } else { tmp7 = linked_228.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_227, arg_230) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_195 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_197 lang.IFn





									if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = x__1; if linked_196 == nil { tmp8 = ifn_197.Invoke_O__O(arg_198) } else { tmp8 = linked_196.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_195, arg_198) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_199 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_201 lang.IFn





										if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = x__1; if linked_200 == nil { seq_1685000036__2 = ifn_201.Invoke_O__O(arg_202) } else { seq_1685000036__2 = linked_200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_199, arg_202) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_203 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = seq_1685000036__2; if linked_204 == nil { temp__1927000414__auto____6_2 = ifn_205.Invoke_O__O(arg_206) } else { temp__1927000414__auto____6_2 = linked_204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_207 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = seq_1685000036__7; if linked_208 == nil { tmp9 = ifn_209.Invoke_O__O(arg_210) } else { tmp9 = linked_208.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_207, arg_210) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_211 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = seq_1685000036__7; if linked_212 == nil { c__1927000678__auto____8_2 = ifn_213.Invoke_O__O(arg_214) } else { c__1927000678__auto____8_2 = linked_212.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_211, arg_214) }; var tmp10 any; var root_231 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = seq_1685000036__7; if linked_232 == nil { tmp10 = ifn_233.Invoke_O__O(arg_234) } else { tmp10 = linked_232.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_231, arg_234) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_215 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = seq_1685000036__7; if linked_216 == nil { y__8 = ifn_217.Invoke_O__O(arg_218) } else { y__8 = linked_216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_215, arg_218) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_235 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = seq_1685000036__7; if linked_236 == nil { tmp11 = ifn_237.Invoke_O__O(arg_238) } else { tmp11 = linked_236.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_235, arg_238) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_241 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_243 lang.IFn




	if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any; var root_245 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = tree__0; if linked_246 == nil { arg_244 = ifn_247.Invoke_O__O(arg_248) } else { arg_244 = linked_246.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_245, arg_248) }; if linked_242 == nil { seq_1685000042__2 = ifn_243.Invoke_O__O(arg_244) } else { seq_1685000042__2 = linked_242.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_241, arg_244) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { var root_265 any = A_arbace_go_check_A_const_54.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = want__7; var arg_269 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_266 == nil { tmp1 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { tmp1 = linked_266.(*aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_265, arg_268, arg_269) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_270 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = A_arbace_go_check_A_const_24; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_271 == nil { ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { linked_271.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_275 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_276 == nil { tmp2 = ifn_277.Invoke_O__O(arg_278) } else { tmp2 = linked_276.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_275, arg_278) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_283 any = Lit_156; var arg_284 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_288 == nil { arg_284 = ifn_289.Invoke_O__O(arg_290) } else { arg_284 = linked_288.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_287, arg_290) }; var arg_285 any; var root_291 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_293 lang.IFn
							if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = want__7; if linked_292 == nil { arg_285 = ifn_293.Invoke_O__O(arg_294) } else { arg_285 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_291, arg_294) }
//line :93:1
							var arg_286 any; var root_295 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_297 lang.IFn
							if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_296 == nil { arg_286 = ifn_297.Invoke_O__O(arg_298) } else { arg_286 = linked_296.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_295, arg_298) }
//line :93:1
							if linked_280 == nil { ifn_281.Invoke_O_O_O_O_O__O(arg_282, arg_283, arg_284, arg_285, arg_286) } else { linked_280.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_279, arg_282, arg_283, arg_284, arg_285, arg_286) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_61; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_62.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_65; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_299 any = A_arbace_go_check_A_const_67.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_301 lang.IFn
									if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_300 == nil { and__1927000168__auto____11 = ifn_301.Invoke_O__O(arg_302) } else { and__1927000168__auto____11 = linked_300.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_299, arg_302) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_303 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = A_arbace_go_check_A_const_68; var arg_307 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_304 == nil { tmp3 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { tmp3 = linked_304.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__6); var arg_312 any = Lit_156; var arg_313 any; var root_316 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__6); if linked_317 == nil { arg_313 = ifn_318.Invoke_O__O(arg_319) } else { arg_313 = linked_317.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_316, arg_319) }; var arg_314 any = Lit_157; var arg_315 any; var root_320 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__6); if linked_321 == nil { arg_315 = ifn_322.Invoke_O__O(arg_323) } else { arg_315 = linked_321.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_320, arg_323) }; if linked_309 == nil { ifn_310.Invoke_O_O_O_O_O__O(arg_311, arg_312, arg_313, arg_314, arg_315) } else { linked_309.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_308, arg_311, arg_312, arg_313, arg_314, arg_315) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_249 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = seq_1685000042__2; if linked_250 == nil { temp__1927000414__auto____6 = ifn_251.Invoke_O__O(arg_252) } else { temp__1927000414__auto____6 = linked_250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_253 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = seq_1685000042__7; if linked_254 == nil { tmp7 = ifn_255.Invoke_O__O(arg_256) } else { tmp7 = linked_254.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_257 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = seq_1685000042__7; if linked_258 == nil { c__1927000678__auto____8 = ifn_259.Invoke_O__O(arg_260) } else { c__1927000678__auto____8 = linked_258.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_257, arg_260) }; var tmp8 any; var root_324 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = seq_1685000042__7; if linked_325 == nil { tmp8 = ifn_326.Invoke_O__O(arg_327) } else { tmp8 = linked_325.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_324, arg_327) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_261 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = seq_1685000042__7; if linked_262 == nil { n__8 = ifn_263.Invoke_O__O(arg_264) } else { n__8 = linked_262.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_261, arg_264) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { var root_328 any = A_arbace_go_check_A_const_54.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = want__9; var arg_332 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_329 == nil { tmp9 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp9 = linked_329.(*aot_arbace_go_check_types.A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_328, arg_331, arg_332) } } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_333 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = A_arbace_go_check_A_const_24; var arg_337 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_334 == nil { ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { linked_334.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_333, arg_336, arg_337) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_338 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_339 == nil { tmp10 = ifn_340.Invoke_O__O(arg_341) } else { tmp10 = linked_339.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_338, arg_341) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_342 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_346 any = Lit_156; var arg_347 any; var root_350 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_351 == nil { arg_347 = ifn_352.Invoke_O__O(arg_353) } else { arg_347 = linked_351.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_350, arg_353) }; var arg_348 any; var root_354 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_356 lang.IFn
								if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = want__9; if linked_355 == nil { arg_348 = ifn_356.Invoke_O__O(arg_357) } else { arg_348 = linked_355.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_354, arg_357) }
//line :93:1
								var arg_349 any; var root_358 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_360 lang.IFn
								if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_359 == nil { arg_349 = ifn_360.Invoke_O__O(arg_361) } else { arg_349 = linked_359.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_358, arg_361) }
//line :93:1
								if linked_343 == nil { ifn_344.Invoke_O_O_O_O_O__O(arg_345, arg_346, arg_347, arg_348, arg_349) } else { linked_343.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_342, arg_345, arg_346, arg_347, arg_348, arg_349) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_61; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_62.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_65; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_362 any = A_arbace_go_check_A_const_67.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_364 lang.IFn
										if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_363 == nil { and__1927000168__auto____13 = ifn_364.Invoke_O__O(arg_365) } else { and__1927000168__auto____13 = linked_363.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_362, arg_365) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_366 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68; var arg_370 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_367 == nil { tmp11 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { tmp11 = linked_367.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_371 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__8); var arg_375 any = Lit_156; var arg_376 any; var root_379 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__8); if linked_380 == nil { arg_376 = ifn_381.Invoke_O__O(arg_382) } else { arg_376 = linked_380.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_379, arg_382) }; var arg_377 any = Lit_157; var arg_378 any; var root_383 any = A_arbace_go_check_A_const_60.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = A_arbace_go_check_A_const_55.Invoke_O__O(n__8); if linked_384 == nil { arg_378 = ifn_385.Invoke_O__O(arg_386) } else { arg_378 = linked_384.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_383, arg_386) }; if linked_372 == nil { ifn_373.Invoke_O_O_O_O_O__O(arg_374, arg_375, arg_376, arg_377, arg_378) } else { linked_372.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_371, arg_374, arg_375, arg_376, arg_377, arg_378) } } }
//line :86:1
				var tmp15 any; var root_387 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = seq_1685000042__7; if linked_388 == nil { tmp15 = ifn_389.Invoke_O__O(arg_390) } else { tmp15 = linked_388.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_387, arg_390) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_71; var tmp2 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_72; var tmp4 any; var root_391 any = A_arbace_go_check_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_393 lang.IFn; if
													linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = pkg_scope__0; var arg_395 any = A_arbace_go_check_A_const_74; if linked_392 == nil { tmp4 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { tmp4 = linked_392.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_75; var tmp7 any; var root_396 any = /*line :101:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_396, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_398 lang.IFn; if


	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any; var or__1927000174__auto____4 any; var root_400 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = fi__1; var arg_404 any = A_arbace_go_check_A_const_78; if linked_401 == nil { or__1927000174__auto____4 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { or__1927000174__auto____4 = linked_401.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_399 = or__1927000174__auto____4 } else { arg_399 = A_arbace_go_check_A_const_75.Invoke_O__O(config__2) }; if linked_397 == nil { tmp7 = ifn_398.Invoke_O__O(arg_399) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_397.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_396, arg_399)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_79; var tmp10 any; var root_405 any = /*line :101:1*/A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_407 lang.IFn; if



	linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = A_arbace_go_check_A_const_74.Invoke_O__O(fi__1); if linked_406 == nil { tmp10 = ifn_407.Invoke_O__O(arg_408) } else { tmp10 = linked_406.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_405, arg_408) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_81; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_81; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_82.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_83; var tmp16 any = A_arbace_go_check_A_const_83.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_84; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_85; var tmp20 any; var root_409 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_411 lang.IFn; if





	linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = lang.PersistentVector_EMPTY.Ref(); if linked_410 == nil { tmp20 = ifn_411.Invoke_O__O(arg_412) } else { tmp20 = linked_410.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_409, arg_412) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_86; var tmp23 any; var root_413 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_415 lang.IFn; if





	linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = lang.PersistentVector_EMPTY.Ref(); if linked_414 == nil { tmp23 = ifn_415.Invoke_O__O(arg_416) } else { tmp23 = linked_414.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_413, arg_416) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var fnbody__516 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__516); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__515d; tmp1 = fncls__515d } else { tmp1 = fncls__515 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__516, tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_517 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_521 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = A_arbace_go_check_A_const_85.Invoke_O__O(fi__0); if linked_522 == nil { arg_520 = ifn_523.Invoke_O__O(arg_524) } else { arg_520 = linked_522.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_521, arg_524) }; if linked_518 == nil { tmp2 = ifn_519.Invoke_O__O(arg_520) } else { tmp2 = linked_518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_517, arg_520) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var fnbody__576 any = any(body_walk2__4); var tmp3 *jrt.Class; var fncls__575 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__575 == nil { var fncls__575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__576); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__575d; tmp3 = fncls__575d } else { tmp3 = fncls__575 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__576, tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_417 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_419 lang.IFn
	if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = f__1; if linked_418 == nil { tmp1 = ifn_419.Invoke_O__O(arg_420) } else { tmp1 = linked_418.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_417, arg_420) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_421 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_423 lang.IFn
		if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = f__1; if linked_422 == nil { temp__1927000414__auto____2 = ifn_423.Invoke_O__O(arg_424) } else { temp__1927000414__auto____2 = linked_422.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_483 any = A_arbace_go_check_A_const_91.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_485 lang.IFn
			if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = A_arbace_go_check_A_const_72.Invoke_O__O(t.F_fi); var arg_487 any = q__3; if linked_484 == nil { temp__1927000414__auto____4 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { temp__1927000414__auto____4 = linked_484.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_92; var tmp3 any; var root_488 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_490 lang.IFn
				if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = x__5; var arg_492 any = A_arbace_go_check_A_const_94; if linked_489 == nil { tmp3 = ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { tmp3 = linked_489.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_493 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = x__5; var arg_497 any = A_arbace_go_check_A_const_90; var arg_498 any = jrt.Boolean_TRUE.Ref(); if linked_494 == nil { ifn_495.Invoke_O_O_O__O(arg_496, arg_497, arg_498) } else { linked_494.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_493, arg_496, arg_497, arg_498) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_84.Invoke_O__O(t.F_fi)); var tmp5 any; var root_425 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_427 lang.IFn


			if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = f__1; if linked_426 == nil { tmp5 = ifn_427.Invoke_O__O(arg_428) } else { tmp5 = linked_426.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_425, arg_428) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_429 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_431 lang.IFn; _ = ___6; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = imp__7; var arg_433 any = A_arbace_go_check_A_const_90; var arg_434 any = jrt.Boolean_TRUE.Ref(); if linked_430 == nil { ifn_431.Invoke_O_O_O__O(arg_432, arg_433, arg_434) } else { linked_430.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_429, arg_432, arg_433, arg_434) } } } } else {
//line :113:1
				var tmp6 any; var root_435 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_437 lang.IFn




				if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = f__1; if linked_436 == nil { tmp6 = ifn_437.Invoke_O__O(arg_438) } else { tmp6 = linked_436.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_435, arg_438) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_439 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn




					if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = f__1; if linked_440 == nil { seq_1685000052__2 = ifn_441.Invoke_O__O(arg_442) } else { seq_1685000052__2 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_443 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1685000052__2; if linked_444 == nil { temp__1927000414__auto____6 = ifn_445.Invoke_O__O(arg_446) } else { temp__1927000414__auto____6 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_447 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_1685000052__7; if linked_448 == nil { tmp7 = ifn_449.Invoke_O__O(arg_450) } else { tmp7 = linked_448.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_451 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq_1685000052__7; if linked_452 == nil { c__1927000678__auto____8 = ifn_453.Invoke_O__O(arg_454) } else { c__1927000678__auto____8 = linked_452.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_451, arg_454) }; var tmp8 any; var root_499 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = seq_1685000052__7; if linked_500 == nil { tmp8 = ifn_501.Invoke_O__O(arg_502) } else { tmp8 = linked_500.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_499, arg_502) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_455 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = seq_1685000052__7; if linked_456 == nil { x__8 = ifn_457.Invoke_O__O(arg_458) } else { x__8 = linked_456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_455, arg_458) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_503 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1685000052__7; if linked_504 == nil { tmp9 = ifn_505.Invoke_O__O(arg_506) } else { tmp9 = linked_504.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_503, arg_506) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_459 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_461 lang.IFn





							if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = f__1; if linked_460 == nil { tmp10 = ifn_461.Invoke_O__O(arg_462) } else { tmp10 = linked_460.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_459, arg_462) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_463 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn





								if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = f__1; if linked_464 == nil { seq_1685000056__2 = ifn_465.Invoke_O__O(arg_466) } else { seq_1685000056__2 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_467 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_1685000056__2; if linked_468 == nil { temp__1927000414__auto____6_2 = ifn_469.Invoke_O__O(arg_470) } else { temp__1927000414__auto____6_2 = linked_468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_471 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_1685000056__7; if linked_472 == nil { tmp11 = ifn_473.Invoke_O__O(arg_474) } else { tmp11 = linked_472.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_471, arg_474) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_475 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = seq_1685000056__7; if linked_476 == nil { c__1927000678__auto____8_2 = ifn_477.Invoke_O__O(arg_478) } else { c__1927000678__auto____8_2 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_475, arg_478) }; var tmp12 any; var root_507 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1685000056__7; if linked_508 == nil { tmp12 = ifn_509.Invoke_O__O(arg_510) } else { tmp12 = linked_508.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_507, arg_510) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_479 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1685000056__7; if linked_480 == nil { x__8_2 = ifn_481.Invoke_O__O(arg_482) } else { x__8_2 = linked_480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_479, arg_482) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_511 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1685000056__7; if linked_512 == nil { tmp13 = ifn_513.Invoke_O__O(arg_514) } else { tmp13 = linked_512.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_511, arg_514) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_525 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_527 lang.IFn
		if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { tmp1 = ifn_527.Invoke_O__O(arg_528) } else { tmp1 = linked_526.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_525, arg_528) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_84.Invoke_O__O(t.F_fi)); var tmp3 any; var root_529 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_531 lang.IFn
			if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp3 = ifn_531.Invoke_O__O(arg_532) } else { tmp3 = linked_530.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_529, arg_532) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_533 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_535 lang.IFn; _ = ___4; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = imp__5; var arg_537 any = A_arbace_go_check_A_const_90; var arg_538 any = jrt.Boolean_TRUE.Ref(); if linked_534 == nil { return ifn_535.Invoke_O_O_O__O(arg_536, arg_537, arg_538) } else { return linked_534.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_533, arg_536, arg_537, arg_538) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_539 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_541 lang.IFn

				if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = f__1; if linked_540 == nil { or__1927000174__auto____2 = ifn_541.Invoke_O__O(arg_542) } else { or__1927000174__auto____2 = linked_540.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_543 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = f__1; if linked_544 == nil { tmp4 = ifn_545.Invoke_O__O(arg_546) } else { tmp4 = linked_544.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_543, arg_546) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_547 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn

					if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = f__1; if linked_548 == nil { seq_1685000065__2 = ifn_549.Invoke_O__O(arg_550) } else { seq_1685000065__2 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_551 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = seq_1685000065__2; if linked_552 == nil { temp__1927000414__auto____6 = ifn_553.Invoke_O__O(arg_554) } else { temp__1927000414__auto____6 = linked_552.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_551, arg_554) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_555 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = seq_1685000065__7; if linked_556 == nil { tmp5 = ifn_557.Invoke_O__O(arg_558) } else { tmp5 = linked_556.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_555, arg_558) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_559 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = seq_1685000065__7; if linked_560 == nil { c__1927000678__auto____8 = ifn_561.Invoke_O__O(arg_562) } else { c__1927000678__auto____8 = linked_560.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_559, arg_562) }; var tmp6 any; var root_567 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = seq_1685000065__7; if linked_568 == nil { tmp6 = ifn_569.Invoke_O__O(arg_570) } else { tmp6 = linked_568.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_567, arg_570) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_563 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = seq_1685000065__7; if linked_564 == nil { x__8 = ifn_565.Invoke_O__O(arg_566) } else { x__8 = linked_564.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_563, arg_566) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_571 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = seq_1685000065__7; if linked_572 == nil { tmp7 = ifn_573.Invoke_O__O(arg_574) } else { tmp7 = linked_572.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_571, arg_574) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var fnbody__689 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, fnbody__689); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__688d; tmp1 = fncls__688d } else { tmp1 = fncls__688 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__689, tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_99); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp6 any; var root_698 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = d__0; if linked_699 == nil { tmp6 = ifn_700.Invoke_O__O(arg_701) } else { tmp6 = linked_699.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_698, arg_701) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp8 any; var root_690 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = d__0; if linked_691 == nil { tmp8 = ifn_692.Invoke_O__O(arg_693) } else { tmp8 = linked_691.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_690, arg_693) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp10 any; var root_694 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = d__0; if linked_695 == nil { tmp10 = ifn_696.Invoke_O__O(arg_697) } else { tmp10 = linked_695.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_694, arg_697) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_577 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_579 lang.IFn
		if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = f__1; if linked_578 == nil { and__1927000168__auto____2 = ifn_579.Invoke_O__O(arg_580) } else { and__1927000168__auto____2 = linked_578.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_577, arg_580) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_581 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = f__1; if linked_582 == nil { tmp2 = ifn_583.Invoke_O__O(arg_584) } else { tmp2 = linked_582.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_581, arg_584) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_585 any = A_arbace_go_check_A_const_91.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_587 lang.IFn

			if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = t.F_pkg_scope; var arg_589 any; var root_590 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { arg_589 = ifn_592.Invoke_O__O(arg_593) } else { arg_589 = linked_591.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_590, arg_593) }; if linked_586 == nil { temp__1927000414__auto____2 = ifn_587.Invoke_O_O__O(arg_588, arg_589) } else { temp__1927000414__auto____2 = linked_586.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_585, arg_588, arg_589) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_95); var tmp4 any; var root_649 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_651 lang.IFn
				if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = x__3; var arg_653 any = A_arbace_go_check_A_const_94; if linked_650 == nil { tmp4 = ifn_651.Invoke_O_O__O(arg_652, arg_653) } else { tmp4 = linked_650.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_649, arg_652, arg_653) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_594 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_598 any = A_arbace_go_check_A_const_96; var arg_599 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_600 any = x__3; if linked_595 == nil { tmp6 = ifn_596.Invoke_O_O_O_O__O(arg_597, arg_598, arg_599, arg_600) } else { tmp6 = linked_595.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_594, arg_597, arg_598, arg_599, arg_600) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_601 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_603 lang.IFn




								if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = f__1; if linked_602 == nil { tmp7 = ifn_603.Invoke_O__O(arg_604) } else { tmp7 = linked_602.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_601, arg_604) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_654 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_656 lang.IFn




									if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = f__1; if linked_655 == nil { temp__1927000414__auto____2_2 = ifn_656.Invoke_O__O(arg_657) } else { temp__1927000414__auto____2_2 = linked_655.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_654, arg_657) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_658 any = A_arbace_go_check_A_const_98.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_660 lang.IFn
										if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = h__3; var arg_662 any = Lit_137; if linked_659 == nil { and__1927000168__auto____4 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { and__1927000168__auto____4 = linked_659.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_663 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var root_667 any = A_arbace_go_check_A_const_98.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = h__3; var arg_671 any = Lit_155; if linked_668 == nil { arg_666 = ifn_669.Invoke_O_O__O(arg_670, arg_671) } else { arg_666 = linked_668.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_667, arg_670, arg_671) }; if linked_664 == nil { and__1927000168__auto____5 = ifn_665.Invoke_O__O(arg_666) } else { and__1927000168__auto____5 = linked_664.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_605 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_607 lang.IFn








									if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = f__1; if linked_606 == nil { seq_1685000072__2 = ifn_607.Invoke_O__O(arg_608) } else { seq_1685000072__2 = linked_606.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_605, arg_608) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_609 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = seq_1685000072__2; if linked_610 == nil { temp__1927000414__auto____6 = ifn_611.Invoke_O__O(arg_612) } else { temp__1927000414__auto____6 = linked_610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_609, arg_612) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_613 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = seq_1685000072__7; if linked_614 == nil { tmp9 = ifn_615.Invoke_O__O(arg_616) } else { tmp9 = linked_614.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_613, arg_616) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_617 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = seq_1685000072__7; if linked_618 == nil { c__1927000678__auto____8 = ifn_619.Invoke_O__O(arg_620) } else { c__1927000678__auto____8 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_617, arg_620) }; var tmp10 any; var root_672 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq_1685000072__7; if linked_673 == nil { tmp10 = ifn_674.Invoke_O__O(arg_675) } else { tmp10 = linked_673.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_672, arg_675) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_621 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = seq_1685000072__7; if linked_622 == nil { x__8 = ifn_623.Invoke_O__O(arg_624) } else { x__8 = linked_622.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_621, arg_624) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_676 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = seq_1685000072__7; if linked_677 == nil { tmp11 = ifn_678.Invoke_O__O(arg_679) } else { tmp11 = linked_677.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_676, arg_679) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_625 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_627 lang.IFn









											if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = f__1; if linked_626 == nil { tmp12 = ifn_627.Invoke_O__O(arg_628) } else { tmp12 = linked_626.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_625, arg_628) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_629 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_631 lang.IFn









												if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = f__1; if linked_630 == nil { seq_1685000076__2 = ifn_631.Invoke_O__O(arg_632) } else { seq_1685000076__2 = linked_630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_629, arg_632) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_633 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seq_1685000076__2; if linked_634 == nil { temp__1927000414__auto____6_2 = ifn_635.Invoke_O__O(arg_636) } else { temp__1927000414__auto____6_2 = linked_634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_637 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seq_1685000076__7; if linked_638 == nil { tmp13 = ifn_639.Invoke_O__O(arg_640) } else { tmp13 = linked_638.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_637, arg_640) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_641 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = seq_1685000076__7; if linked_642 == nil { c__1927000678__auto____8_2 = ifn_643.Invoke_O__O(arg_644) } else { c__1927000678__auto____8_2 = linked_642.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_641, arg_644) }; var tmp14 any; var root_680 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq_1685000076__7; if linked_681 == nil { tmp14 = ifn_682.Invoke_O__O(arg_683) } else { tmp14 = linked_681.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_680, arg_683) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_645 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = seq_1685000076__7; if linked_646 == nil { x__8_2 = ifn_647.Invoke_O__O(arg_648) } else { x__8_2 = linked_646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_645, arg_648) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_684 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = seq_1685000076__7; if linked_685 == nil { tmp15 = ifn_686.Invoke_O__O(arg_687) } else { tmp15 = linked_685.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_684, arg_687) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_number_local_types_BANG__A_New() *A_arbace_go_check_number_local_types_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_number_local_types_BANG__A) Invoke_O_O__O(self, lts__0 any) any { { var sorted__2 any; var root_702 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_704 lang.IFn





	if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var fnbody__708 any = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New(); var tmp1 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class = fncls__707d; tmp1 = fncls__707d } else { tmp1 = fncls__707 }; arg_705 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__708, tmp1, nil); var arg_706 any; var root_709 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any; var fnbody__715 any = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New(); var tmp2 *jrt.Class; var fncls__714 *jrt.Class = A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class; if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class = fncls__714d; tmp2 = fncls__714d } else { tmp2 = fncls__714 }; arg_712 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__715, tmp2, nil); var arg_713 any = lts__0; if linked_710 == nil { arg_706 = ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { arg_706 = linked_710.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) }; if linked_703 == nil { sorted__2 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { sorted__2 = linked_703.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }
//line :151:1
	var seq_1685000094__3 any; var root_716 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn






	if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any; var root_720 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = A_arbace_go_check_A_const_104.GetRawRoot__O(); var arg_724 any = sorted__2; if linked_721 == nil { arg_719 = ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { arg_719 = linked_721.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) }; if linked_717 == nil { seq_1685000094__3 = ifn_718.Invoke_O__O(arg_719) } else { seq_1685000094__3 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }
//line :151:1
	var chunk_1685000095__4 any; var count_1685000096__5 int64 = 0; var i_1685000097__6 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000097__6, count_1685000096__5) { var vec__1685000098__7 any = lang.Indexed_Cast(chunk_1685000095__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000097__6)); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000101__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000098__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000101__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var tmp5 any = A_arbace_go_check_A_const_107; var tmp6 jrt.Number_I; var na_748 any = n__8; _ = ___10
			if jrt.Long_InstanceOf(na_748) { var n0_749 int64 = jrt.NN(jrt.Long_Cast(na_748)).LongValue__J(); if n0_749 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_748) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_749 + 1)) } } else { if jrt.Double_InstanceOf(na_748) { var n0_749_2 float64 = jrt.NN(jrt.Double_Cast(na_748)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_749_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_748) } }; tmp3.Invoke_O_O_O_O__O(nt__11, tmp4, tmp5, tmp6)
//line :158:1
			seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000097__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_725 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1685000094__3; if linked_726 == nil { temp__1927000414__auto____7 = ifn_727.Invoke_O__O(arg_728) } else { temp__1927000414__auto____7 = linked_726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_725, arg_728) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000094__8 any = temp__1927000414__auto____7; var tmp7 any; var root_729 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_1685000094__8; if linked_730 == nil { tmp7 = ifn_731.Invoke_O__O(arg_732) } else { tmp7 = linked_730.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_733 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = seq_1685000094__8; if linked_734 == nil { c__1927000678__auto____9 = ifn_735.Invoke_O__O(arg_736) } else { c__1927000678__auto____9 = linked_734.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_733, arg_736) }; var tmp8 any; var root_750 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = seq_1685000094__8; if linked_751 == nil { tmp8 = ifn_752.Invoke_O__O(arg_753) } else { tmp8 = linked_751.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_750, arg_753) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000104__9 any; var root_737 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = seq_1685000094__8; if linked_738 == nil { vec__1685000104__9 = ifn_739.Invoke_O__O(arg_740) } else { vec__1685000104__9 = linked_738.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_737, arg_740) }; var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1685000107__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000104__9, lang.RT_IntCast_J__I_NoInit(1), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000107__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_105.GetRawRoot__O()); var tmp10 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var tmp11 any = A_arbace_go_check_A_const_107; var tmp12 jrt.Number_I; var na_761 any = n__10; _ = ___12
				if jrt.Long_InstanceOf(na_761) { var n0_762 int64 = jrt.NN(jrt.Long_Cast(na_761)).LongValue__J(); if n0_762 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_761) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_762 + 1)) } } else { if jrt.Double_InstanceOf(na_761) { var n0_762_2 float64 = jrt.NN(jrt.Double_Cast(na_761)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_762_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_761) } }; tmp9.Invoke_O_O_O_O__O(nt__13, tmp10, tmp11, tmp12)
//line :158:1
				var tmp13 any; var root_763 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = seq_1685000094__8; if linked_764 == nil { tmp13 = ifn_765.Invoke_O__O(arg_766) } else { tmp13 = linked_764.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_763, arg_766) }; seq_1685000094__3, chunk_1685000095__4, count_1685000096__5, i_1685000097__6 = tmp13, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :151:1*/panic("j2g: unreachable") }





func A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000083_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000083_A) Invoke_O_O__O(self, p__1685000082__1 any) any { var vec__1685000084__2 any = p__1685000082__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000084__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___4; return lang.Tuple_Create_O_O__IPersistentVector(id__3, k__5) }
//line :157:1
func A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_New() *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_number_local_types_BANG__fn__1685000089_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_number_local_types_BANG__fn__1685000089_A) Invoke_O_O_O__O(self, k__1, p__1685000088__2 any) any { var vec__1685000090__3 any = p__1685000088__2; var id__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(0), nil); var nt__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000090__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O_O__IPersistentVector(id__4, nt__5, k__1) }



func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000126__2 any) any { var map__1685000127__4 any = p__1685000126__2; var map__1685000127__5 any; if lang.ISeq_InstanceOf(map__1685000127__4) { var tmp1 any; var root_767 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = map__1685000127__4; if linked_768 == nil { tmp1 = ifn_769.Invoke_O__O(arg_770) } else { tmp1 = linked_768.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_767, arg_770) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_771 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = map__1685000127__4; if linked_772 == nil { tmp2 = ifn_773.Invoke_O__O(arg_774) } else { tmp2 = linked_772.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_771, arg_774) }; map__1685000127__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_775 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = map__1685000127__4; if linked_776 == nil { tmp3 = ifn_777.Invoke_O__O(arg_778) } else { tmp3 = linked_776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_775, arg_778) }; if jrt.J2g_Truth(tmp3) { var root_779 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = map__1685000127__4; if linked_780 == nil { map__1685000127__5 = ifn_781.Invoke_O__O(arg_782) } else { map__1685000127__5 = linked_780.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_779, arg_782) } } else { map__1685000127__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000127__5 = map__1685000127__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000127__5, A_arbace_go_check_A_const_109); var pkg_scope__7 any; var root_783 any = A_arbace_go_check_A_const_73.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_785 lang.IFn; if




	linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any; var arg_787 any = A_arbace_go_check_A_const_110; if linked_784 == nil { pkg_scope__7 = ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { pkg_scope__7 = linked_784.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_783, arg_786, arg_787) }; var pkg__8 any; var root_788 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_790 lang.IFn; if





	linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any; var tmp4 any = A_arbace_go_check_A_const_111; var tmp5 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_71; var tmp7 any = A_arbace_go_check_A_const_71.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_72; var tmp9 any = A_arbace_go_check_A_const_112; var tmp10 any = A_arbace_go_check_A_const_112.Invoke_O__O(src__0); var tmp11 any = A_arbace_go_check_A_const_113; var tmp12 any; var root_792 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_794 lang.IFn; if
	linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = lang.PersistentVector_EMPTY.Ref(); if linked_793 == nil { tmp12 = ifn_794.Invoke_O__O(arg_795) } else { tmp12 = linked_793.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_792, arg_795) }; arg_791 = /*line :167:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, tmp10, tmp11, tmp12)); if linked_789 == nil { pkg__8 = ifn_790.Invoke_O__O(arg_791) } else { pkg__8 = linked_789.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_788, arg_791) }; var errors__9 any; var root_796 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_798 lang.IFn; if







	linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = lang.PersistentVector_EMPTY.Ref(); if linked_797 == nil { errors__9 = ifn_798.Invoke_O__O(arg_799) } else { errors__9 = linked_797.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_796, arg_799) }; var resolving__10 any; var root_800 any = /*line :161:1*/A_arbace_go_check_A_const_114.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_802 lang.IFn; if










	linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = A_arbace_go_check_A_const_115.Invoke_O__O(src__0); if linked_801 == nil { resolving__10 = ifn_802.Invoke_O__O(arg_803) } else { resolving__10 = linked_801.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_800, arg_803) }; var annotated__11 any; var and__1927000168__auto____11 any; var root_804 any = /*line :161:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_806 lang.IFn; if











	linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = A_arbace_go_check_A_const_82.Invoke_O__O(src__0); var arg_808 any = A_arbace_go_check_A_const_116; if linked_805 == nil { and__1927000168__auto____11 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { and__1927000168__auto____11 = linked_805.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_809 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = resolving__10; if linked_810 == nil { annotated__11 = ifn_811.Invoke_O__O(arg_812) } else { annotated__11 = linked_810.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_809, arg_812) } } else { annotated__11 = and__1927000168__auto____11 }; var ctx__12 any; var tmp13 any = A_arbace_go_check_A_const_117; var tmp14 any; var root_813 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_815 lang.IFn; if












	linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = lang.PersistentVector_EMPTY.Ref(); if linked_814 == nil { tmp14 = ifn_815.Invoke_O__O(arg_816) } else { tmp14 = linked_814.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_813, arg_816) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_118; var tmp17 any; var root_817 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_819 lang.IFn; if












	linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_818 == nil { tmp17 = ifn_819.Invoke_O__O(arg_820) } else { tmp17 = linked_818.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_817, arg_820) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_119; var tmp20 any; var root_821 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_823 lang.IFn; if












	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = lang.PersistentVector_EMPTY.Ref(); if linked_822 == nil { tmp20 = ifn_823.Invoke_O__O(arg_824) } else { tmp20 = linked_822.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_821, arg_824) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_120; var tmp23 any; var root_825 any = /*line :161:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_827 lang.IFn; if












	linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = lang.PersistentVector_EMPTY.Ref(); if linked_826 == nil { tmp23 = ifn_827.Invoke_O__O(arg_828) } else { tmp23 = linked_826.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_825, arg_828) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_go_check_A_const_121; ctx__12 = /*line :161:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, tmp24, tmp25, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_61, annotated__11, A_arbace_go_check_A_const_122, resolving__10)))); var fis__13 any; var root_829 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_831 lang.IFn; if














	linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var fnbody__841 any = A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(src__0, pkg_scope__7); var tmp26 *jrt.Class; var fncls__840 *jrt.Class = A_arbace_go_check_check_package_fn__1685000129_A_fn_class; if fncls__840 == nil { var fncls__840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__841); A_arbace_go_check_check_package_fn__1685000129_A_fn_class = fncls__840d; tmp26 = fncls__840d } else { tmp26 = fncls__840 }; arg_832 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__841, tmp26, nil); var arg_833 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__0); if linked_830 == nil { fis__13 = ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { fis__13 = linked_830.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) }; var root_1321 any =
	A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp28 any = A_arbace_go_check_A_const_171; var tmp29 any = A_arbace_go_check_A_const_172; var tmp30 any = A_arbace_go_check_A_const_173; var tmp31 any = jrt.IdentityHashMap_New(); var tmp32 any = A_arbace_go_check_A_const_174; var tmp33 any = A_arbace_go_check_A_const_175; var tmp34 any = A_arbace_go_check_A_const_115.Invoke_O__O(src__0); var tmp35 any = A_arbace_go_check_A_const_176; var tmp36 any = jrt.Boolean_TRUE.Ref(); var tmp37 any = A_arbace_go_check_A_const_62; var tmp38 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_61, annotated__11, A_arbace_go_check_A_const_122, resolving__10)); var tmp39 any = A_arbace_go_check_A_const_177; var tmp40 any = A_arbace_go_check_A_const_178.GetRawRoot__O(); var tmp41 any = A_arbace_go_check_A_const_179; var tmp42 any = A_arbace_go_check_A_const_180.GetRawRoot__O(); var tmp43 any = A_arbace_go_check_A_const_181; var tmp44 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp45 any = A_arbace_go_check_A_const_182; var tmp46 any = A_arbace_go_check_A_const_183.GetRawRoot__O(); var tmp47 any = A_arbace_go_check_A_const_184; var tmp48 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var tmp49 any = A_arbace_go_check_A_const_186; var tmp50 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var tmp51 any = A_arbace_go_check_A_const_188; var tmp52 *lang.Compiler_AOTFn; var fnbody__1330 any = A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(src__0, pkg__8, resolve__1); var tmp53 *jrt.Class; var fncls__1329 *jrt.Class = A_arbace_go_check_check_package_fn__1685000131_A_fn_class; if












	fncls__1329 == nil { var fncls__1329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__1330); A_arbace_go_check_check_package_fn__1685000131_A_fn_class = fncls__1329d; tmp53 = fncls__1329d } else { tmp53 = fncls__1329 }; tmp52 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1330, tmp53, nil); var tmp54 any = /*line :177:1*/tmp52.Ref(); var tmp55 any = A_arbace_go_check_A_const_190; var tmp56 any = A_arbace_go_check_A_const_191.GetRawRoot__O(); var tmp57 any = A_arbace_go_check_A_const_192; var tmp58 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var tmp59 any = A_arbace_go_check_A_const_194; var tmp60 any = A_arbace_go_check_A_const_195.GetRawRoot__O(); var tmp61 any = A_arbace_go_check_A_const_196; var tmp62 any; var root_1331 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1333 lang.IFn; if

















	linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = lang.PersistentVector_EMPTY.Ref(); if linked_1332 == nil { tmp62 = ifn_1333.Invoke_O__O(arg_1334) } else { tmp62 = linked_1332.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1331, arg_1334) }; var tmp63 any = tmp62; var tmp64 any = A_arbace_go_check_A_const_197; var tmp65 any; var root_1335 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1337 lang.IFn; if


















	linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_198, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_199, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_A_const_200, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_201, lang.PersistentArrayMap_EMPTY.Ref())); if linked_1336 == nil { tmp65 = ifn_1337.Invoke_O__O(arg_1338) } else { tmp65 = linked_1336.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1335, arg_1338) }; var tmp66 any = tmp65; var tmp67 any = A_arbace_go_check_A_const_202; var tmp68 any; var root_1339 any = /*line :177:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1341 lang.IFn; if



















	linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = lang.PersistentVector_EMPTY.Ref(); if linked_1340 == nil { tmp68 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp68 = linked_1340.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1339, arg_1342) }; arg_1324 = /*line :177:1*/tmp27.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp28, pkg__8, tmp29, errors__9, tmp30, tmp31, tmp32, ctx__12, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp63, tmp64, tmp66, tmp67, tmp68)))); if linked_1322 == nil { ifn_1323.Invoke_O__O(arg_1324) } else { linked_1322.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1321, arg_1324) }; var tmp69 any; tmp322 := /*line :161:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





































		if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, A_arbace_go_check_A_const_71.Invoke_O__O(src__0)) { var seq_1685000133__16 any; var root_1343 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1345 lang.IFn
			if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = fis__13; if linked_1344 == nil { seq_1685000133__16 = ifn_1345.Invoke_O__O(arg_1346) } else { seq_1685000133__16 = linked_1344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1343, arg_1346) }
//line :199:1
			var chunk_1685000134__17 any; var count_1685000135__18 int64 = 0; var i_1685000136__19 int64 = 0; L1: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000136__19, count_1685000135__18) { var fi__20 any = lang.Indexed_Cast(chunk_1685000134__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000136__19)); var root_1426 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__20); var arg_1430 any; var or__1927000174__auto____21 any = A_arbace_go_check_A_const_79.Invoke_O__O(fi__20); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_1430 = or__1927000174__auto____21 } else { arg_1430 = A_arbace_go_check_A_const_43 }; var arg_1431 any = A_arbace_go_check_A_const_205; var arg_1432 any = Lit_58; if linked_1427 == nil { ifn_1428.Invoke_O_O_O_O__O(arg_1429, arg_1430, arg_1431, arg_1432) } else { linked_1427.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1426, arg_1429, arg_1430, arg_1431, arg_1432) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000136__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_1347 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = seq_1685000133__16; if linked_1348 == nil { temp__1927000414__auto____20 = ifn_1349.Invoke_O__O(arg_1350) } else { temp__1927000414__auto____20 = linked_1348.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1347, arg_1350) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000133__21 any = temp__1927000414__auto____20; var tmp70 any; var root_1351 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = seq_1685000133__21; if linked_1352 == nil { tmp70 = ifn_1353.Invoke_O__O(arg_1354) } else { tmp70 = linked_1352.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1351, arg_1354) }; if jrt.J2g_Truth(tmp70) { var c__1927000678__auto____22 any; var root_1355 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = seq_1685000133__21; if linked_1356 == nil { c__1927000678__auto____22 = ifn_1357.Invoke_O__O(arg_1358) } else { c__1927000678__auto____22 = linked_1356.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1355, arg_1358) }; var tmp71 any; var root_1433 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = seq_1685000133__21; if linked_1434 == nil { tmp71 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp71 = linked_1434.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1433, arg_1436) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp71, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__22 any; var root_1359 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = seq_1685000133__21; if linked_1360 == nil { fi__22 = ifn_1361.Invoke_O__O(arg_1362) } else { fi__22 = linked_1360.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1359, arg_1362) }; var root_1437 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = A_arbace_go_check_A_const_71.Invoke_O__O(fi__22); var arg_1441 any; var or__1927000174__auto____23 any = A_arbace_go_check_A_const_79.Invoke_O__O(fi__22); if jrt.J2g_Truth(or__1927000174__auto____23) { arg_1441 = or__1927000174__auto____23 } else { arg_1441 = A_arbace_go_check_A_const_43 }; var arg_1442 any = A_arbace_go_check_A_const_205; var arg_1443 any = Lit_58; if linked_1438 == nil { ifn_1439.Invoke_O_O_O_O__O(arg_1440, arg_1441, arg_1442, arg_1443) } else { linked_1438.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1437, arg_1440, arg_1441, arg_1442, arg_1443) }; var tmp72 any; var root_1444 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = seq_1685000133__21; if linked_1445 == nil { tmp72 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp72 = linked_1445.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1444, arg_1447) }; seq_1685000133__16, chunk_1685000134__17, count_1685000135__18, i_1685000136__19 = tmp72, nil, 0, 0; continue L1 } } }
//line :199:1
				break L1 } }
//line :161:1
		{ var seq_1685000137__16 any; var root_1363 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1365 lang.IFn







































			if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = fis__13; if linked_1364 == nil { seq_1685000137__16 = ifn_1365.Invoke_O__O(arg_1366) } else { seq_1685000137__16 = linked_1364.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1363, arg_1366) }
//line :161:1
			var chunk_1685000138__17 any; var count_1685000139__18 int64 = 0; var i_1685000140__19 int64 = 0; L2: for {







































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000140__19, count_1685000139__18) { var fi__20_2 any = lang.Indexed_Cast(chunk_1685000138__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000140__19)); var root_1448 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = fi__20_2; var arg_1452 any = resolve__1; if linked_1449 == nil { ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { linked_1449.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000140__19); continue L2 } else { var temp__1927000414__auto____20_2 any; var root_1367 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = seq_1685000137__16; if linked_1368 == nil { temp__1927000414__auto____20_2 = ifn_1369.Invoke_O__O(arg_1370) } else { temp__1927000414__auto____20_2 = linked_1368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1367, arg_1370) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000137__21 any = temp__1927000414__auto____20_2; var tmp73 any; var root_1371 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = seq_1685000137__21; if linked_1372 == nil { tmp73 = ifn_1373.Invoke_O__O(arg_1374) } else { tmp73 = linked_1372.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1371, arg_1374) }; if jrt.J2g_Truth(tmp73) { var c__1927000678__auto____22_2 any; var root_1375 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = seq_1685000137__21; if linked_1376 == nil { c__1927000678__auto____22_2 = ifn_1377.Invoke_O__O(arg_1378) } else { c__1927000678__auto____22_2 = linked_1376.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1375, arg_1378) }; var tmp74 any; var root_1453 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = seq_1685000137__21; if linked_1454 == nil { tmp74 = ifn_1455.Invoke_O__O(arg_1456) } else { tmp74 = linked_1454.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1453, arg_1456) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp74, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__22_2 any; var root_1379 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = seq_1685000137__21; if linked_1380 == nil { fi__22_2 = ifn_1381.Invoke_O__O(arg_1382) } else { fi__22_2 = linked_1380.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1379, arg_1382) }; var root_1457 any = A_arbace_go_check_A_const_206.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = fi__22_2; var arg_1461 any = resolve__1; if linked_1458 == nil { ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { linked_1458.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) }; var tmp75 any; var root_1462 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = seq_1685000137__21; if linked_1463 == nil { tmp75 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp75 = linked_1463.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1462, arg_1465) }; seq_1685000137__16, chunk_1685000138__17, count_1685000139__18, i_1685000140__19 = tmp75, nil, 0, 0; continue L2 } } }
//line :161:1
				break L2 }; var seq_1685000141__16 any; var root_1383 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1385 lang.IFn








































			if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = fis__13; if linked_1384 == nil { seq_1685000141__16 = ifn_1385.Invoke_O__O(arg_1386) } else { seq_1685000141__16 = linked_1384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1383, arg_1386) }
//line :161:1
			var chunk_1685000142__17 any; var count_1685000143__18 int64 = 0; var i_1685000144__19 int64 = 0; L3: for {








































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000144__19, count_1685000143__18) { var fi__20_3 any = lang.Indexed_Cast(chunk_1685000142__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000144__19)); var root_1466 any = A_arbace_go_check_A_const_207.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = fi__20_3; if linked_1467 == nil { ifn_1468.Invoke_O__O(arg_1469) } else { linked_1467.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1466, arg_1469) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000144__19); continue L3 } else { var temp__1927000414__auto____20_3 any; var root_1387 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = seq_1685000141__16; if linked_1388 == nil { temp__1927000414__auto____20_3 = ifn_1389.Invoke_O__O(arg_1390) } else { temp__1927000414__auto____20_3 = linked_1388.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1387, arg_1390) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000141__21 any = temp__1927000414__auto____20_3; var tmp76 any; var root_1391 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = seq_1685000141__21; if linked_1392 == nil { tmp76 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp76 = linked_1392.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1391, arg_1394) }; if jrt.J2g_Truth(tmp76) { var c__1927000678__auto____22_3 any; var root_1395 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = seq_1685000141__21; if linked_1396 == nil { c__1927000678__auto____22_3 = ifn_1397.Invoke_O__O(arg_1398) } else { c__1927000678__auto____22_3 = linked_1396.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1395, arg_1398) }; var tmp77 any; var root_1470 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = seq_1685000141__21; if linked_1471 == nil { tmp77 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp77 = linked_1471.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1470, arg_1473) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp77, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var fi__22_3 any; var root_1399 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = seq_1685000141__21; if linked_1400 == nil { fi__22_3 = ifn_1401.Invoke_O__O(arg_1402) } else { fi__22_3 = linked_1400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1399, arg_1402) }; var root_1474 any = A_arbace_go_check_A_const_207.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = fi__22_3; if linked_1475 == nil { ifn_1476.Invoke_O__O(arg_1477) } else { linked_1475.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1474, arg_1477) }; var tmp78 any; var root_1478 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = seq_1685000141__21; if linked_1479 == nil { tmp78 = ifn_1480.Invoke_O__O(arg_1481) } else { tmp78 = linked_1479.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1478, arg_1481) }; seq_1685000141__16, chunk_1685000142__17, count_1685000143__18, i_1685000144__19 = tmp78, nil, 0, 0; continue L3 } } }
//line :161:1
				break L3 }; var seq_1685000145__16 any; var root_1403 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1405 lang.IFn









































			if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = fis__13; if linked_1404 == nil { seq_1685000145__16 = ifn_1405.Invoke_O__O(arg_1406) } else { seq_1685000145__16 = linked_1404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1403, arg_1406) }
//line :161:1
			var chunk_1685000146__17 any; var count_1685000147__18 int64 = 0; var i_1685000148__19 int64 = 0; L4: for {









































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000148__19, count_1685000147__18) { var fi__20_4 any = lang.Indexed_Cast(chunk_1685000146__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000148__19)); var root_1482 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = fi__20_4; if linked_1483 == nil { ifn_1484.Invoke_O__O(arg_1485) } else { linked_1483.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1482, arg_1485) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000148__19); continue L4 } else { var temp__1927000414__auto____20_4 any; var root_1407 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = seq_1685000145__16; if linked_1408 == nil { temp__1927000414__auto____20_4 = ifn_1409.Invoke_O__O(arg_1410) } else { temp__1927000414__auto____20_4 = linked_1408.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1407, arg_1410) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000145__21 any = temp__1927000414__auto____20_4; var tmp79 any; var root_1411 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = seq_1685000145__21; if linked_1412 == nil { tmp79 = ifn_1413.Invoke_O__O(arg_1414) } else { tmp79 = linked_1412.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1411, arg_1414) }; if jrt.J2g_Truth(tmp79) { var c__1927000678__auto____22_4 any; var root_1415 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = seq_1685000145__21; if linked_1416 == nil { c__1927000678__auto____22_4 = ifn_1417.Invoke_O__O(arg_1418) } else { c__1927000678__auto____22_4 = linked_1416.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1415, arg_1418) }; var tmp80 any; var root_1486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = seq_1685000145__21; if linked_1487 == nil { tmp80 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp80 = linked_1487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1486, arg_1489) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp80, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var fi__22_4 any; var root_1419 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = seq_1685000145__21; if linked_1420 == nil { fi__22_4 = ifn_1421.Invoke_O__O(arg_1422) } else { fi__22_4 = linked_1420.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1419, arg_1422) }; var root_1490 any = A_arbace_go_check_A_const_208.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = fi__22_4; if linked_1491 == nil { ifn_1492.Invoke_O__O(arg_1493) } else { linked_1491.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_file_scope_conflicts_BANG__A).Invoke_O_O__O(root_1490, arg_1493) }; var tmp81 any; var root_1494 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = seq_1685000145__21; if linked_1495 == nil { tmp81 = ifn_1496.Invoke_O__O(arg_1497) } else { tmp81 = linked_1495.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1494, arg_1497) }; seq_1685000145__16, chunk_1685000146__17, count_1685000147__18, i_1685000148__19 = tmp81, nil, 0, 0; continue L4 } } }
//line :161:1
				break L4
			}









































			var root_1423 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; if linked_1424 == nil { ifn_1425.Invoke__O() } else { linked_1424.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1423) }
//line :161:1
			var objs__16 any; var root_842 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_844 lang.IFn











































			if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = A_arbace_go_check_A_const_117.Invoke_O__O(ctx__12); if linked_843 == nil { objs__16 = ifn_844.Invoke_O__O(arg_845) } else { objs__16 = linked_843.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_842, arg_845) }
//line :161:1
			var seq_1685000149__17 any; var root_1498 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1500 lang.IFn












































			if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any; var root_1502 any = A_arbace_go_check_A_const_103.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = A_arbace_go_check_A_const_104.GetRawRoot__O(); var arg_1506 any = objs__16; if linked_1503 == nil { arg_1501 = ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { arg_1501 = linked_1503.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) }; if linked_1499 == nil { seq_1685000149__17 = ifn_1500.Invoke_O__O(arg_1501) } else { seq_1685000149__17 = linked_1499.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1498, arg_1501) }
//line :161:1
			var chunk_1685000150__18 any; var count_1685000151__19 int64 = 0; var i_1685000152__20 int64 = 0; L5: for {












































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000152__20, count_1685000151__19) { var vec__1685000153__21 any = lang.Indexed_Cast(chunk_1685000150__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000152__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000153__21, lang.RT_IntCast_J__I_NoInit(0), nil); var x__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000153__21, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1700 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = x__23; var arg_1704 any = A_arbace_go_check_A_const_212; var arg_1705 any = i__22; if linked_1701 == nil { ifn_1702.Invoke_O_O_O__O(arg_1703, arg_1704, arg_1705) } else { linked_1701.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1700, arg_1703, arg_1704, arg_1705) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000152__20); continue L5 } else { var temp__1927000414__auto____21 any; var root_1507 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = seq_1685000149__17; if linked_1508 == nil { temp__1927000414__auto____21 = ifn_1509.Invoke_O__O(arg_1510) } else { temp__1927000414__auto____21 = linked_1508.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1507, arg_1510) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000149__22 any = temp__1927000414__auto____21; var tmp82 any; var root_1511 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = seq_1685000149__22; if linked_1512 == nil { tmp82 = ifn_1513.Invoke_O__O(arg_1514) } else { tmp82 = linked_1512.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1511, arg_1514) }; if jrt.J2g_Truth(tmp82) { var c__1927000678__auto____23 any; var root_1515 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = seq_1685000149__22; if linked_1516 == nil { c__1927000678__auto____23 = ifn_1517.Invoke_O__O(arg_1518) } else { c__1927000678__auto____23 = linked_1516.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1515, arg_1518) }; var tmp83 any; var root_1706 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = seq_1685000149__22; if linked_1707 == nil { tmp83 = ifn_1708.Invoke_O__O(arg_1709) } else { tmp83 = linked_1707.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1706, arg_1709) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = tmp83, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var vec__1685000156__23 any; var root_1519 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = seq_1685000149__22; if linked_1520 == nil { vec__1685000156__23 = ifn_1521.Invoke_O__O(arg_1522) } else { vec__1685000156__23 = linked_1520.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1519, arg_1522) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000156__23, lang.RT_IntCast_J__I_NoInit(0), nil); var x__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000156__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1710 any = A_arbace_go_check_A_const_89.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = x__25; var arg_1714 any = A_arbace_go_check_A_const_212; var arg_1715 any = i__24; if linked_1711 == nil { ifn_1712.Invoke_O_O_O__O(arg_1713, arg_1714, arg_1715) } else { linked_1711.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1710, arg_1713, arg_1714, arg_1715) }; var tmp84 any; var root_1716 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = seq_1685000149__22; if linked_1717 == nil { tmp84 = ifn_1718.Invoke_O__O(arg_1719) } else { tmp84 = linked_1717.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1716, arg_1719) }; seq_1685000149__17, chunk_1685000150__18, count_1685000151__19, i_1685000152__20 = tmp84, nil, 0, 0; continue L5 } } }
//line :161:1
				break L5
			}













































			var root_1523 any = A_arbace_go_check_A_const_209.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = objs__16; if linked_1524 == nil { ifn_1525.Invoke_O__O(arg_1526) } else { linked_1524.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_direct_cycles_BANG__A).Invoke_O_O__O(root_1523, arg_1526) }
//line :161:1
			var seq_1685000159__17 any; var root_1527 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1529 lang.IFn
















































			if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = objs__16; if linked_1528 == nil { seq_1685000159__17 = ifn_1529.Invoke_O__O(arg_1530) } else { seq_1685000159__17 = linked_1528.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1527, arg_1530) }
//line :161:1
			var chunk_1685000160__18 any; var count_1685000161__19 int64 = 0; var i_1685000162__20 int64 = 0; L6: for {
















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000162__20, count_1685000161__19) { var x__21 any = lang.Indexed_Cast(chunk_1685000160__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000162__20)); var tmp85 any; var and__1927000168__auto____22 bool; var tmp86 any = A_arbace_go_check_A_const_55; var tmp87 any; var root_1531 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = x__21; var arg_1535 any = A_arbace_go_check_A_const_94; if linked_1532 == nil { tmp87 = ifn_1533.Invoke_O_O__O(arg_1534, arg_1535) } else { tmp87 = linked_1532.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1531, arg_1534, arg_1535) }; and__1927000168__auto____22 = lang.Util_Equiv_O_O__Z_NoInit(tmp86, tmp87); if and__1927000168__auto____22 { var root_1536 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any; var root_1540 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = x__21; var arg_1544 any = A_arbace_go_check_A_const_210; if linked_1541 == nil { arg_1539 = ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { arg_1539 = linked_1541.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }; if linked_1537 == nil { tmp85 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp85 = linked_1537.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1536, arg_1539) } } else { tmp85 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22).Ref() }; if jrt.J2g_Truth(tmp85) { var root_1720 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = x__21; if linked_1721 == nil { ifn_1722.Invoke_O__O(arg_1723) } else { linked_1721.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1720, arg_1723) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } else { seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000162__20); continue L6 } } else { var temp__1927000414__auto____21_2 any; var root_1545 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = seq_1685000159__17; if linked_1546 == nil { temp__1927000414__auto____21_2 = ifn_1547.Invoke_O__O(arg_1548) } else { temp__1927000414__auto____21_2 = linked_1546.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1545, arg_1548) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000159__22 any = temp__1927000414__auto____21_2; var tmp88 any; var root_1549 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = seq_1685000159__22; if linked_1550 == nil { tmp88 = ifn_1551.Invoke_O__O(arg_1552) } else { tmp88 = linked_1550.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1549, arg_1552) }; if jrt.J2g_Truth(tmp88) { var c__1927000678__auto____23_2 any; var root_1553 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = seq_1685000159__22; if linked_1554 == nil { c__1927000678__auto____23_2 = ifn_1555.Invoke_O__O(arg_1556) } else { c__1927000678__auto____23_2 = linked_1554.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1553, arg_1556) }; var tmp89 any; var root_1724 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = seq_1685000159__22; if linked_1725 == nil { tmp89 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp89 = linked_1725.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1724, arg_1727) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp89, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__23_2 any; var root_1557 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = seq_1685000159__22; if linked_1558 == nil { x__23_2 = ifn_1559.Invoke_O__O(arg_1560) } else { x__23_2 = linked_1558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1557, arg_1560) }; var tmp90 any; var and__1927000168__auto____24 bool; var tmp91 any = A_arbace_go_check_A_const_55; var tmp92 any; var root_1561 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = x__23_2; var arg_1565 any = A_arbace_go_check_A_const_94; if linked_1562 == nil { tmp92 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { tmp92 = linked_1562.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; and__1927000168__auto____24 = lang.Util_Equiv_O_O__Z_NoInit(tmp91, tmp92); if and__1927000168__auto____24 { var root_1566 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any; var root_1570 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = x__23_2; var arg_1574 any = A_arbace_go_check_A_const_210; if linked_1571 == nil { arg_1569 = ifn_1572.Invoke_O_O__O(arg_1573, arg_1574) } else { arg_1569 = linked_1571.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1570, arg_1573, arg_1574) }; if linked_1567 == nil { tmp90 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp90 = linked_1567.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1566, arg_1569) } } else { tmp90 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24).Ref() }; if jrt.J2g_Truth(tmp90) { var root_1728 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = x__23_2; if linked_1729 == nil { ifn_1730.Invoke_O__O(arg_1731) } else { linked_1729.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1728, arg_1731) }; var tmp93 any; var root_1732 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = seq_1685000159__22; if linked_1733 == nil { tmp93 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp93 = linked_1733.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1732, arg_1735) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp93, nil, 0, 0; continue L6 } else { var tmp94 any; var root_1736 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = seq_1685000159__22; if linked_1737 == nil { tmp94 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp94 = linked_1737.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1736, arg_1739) }; seq_1685000159__17, chunk_1685000160__18, count_1685000161__19, i_1685000162__20 = tmp94, nil, 0, 0; continue L6 } } } }
//line :161:1
				break L6 }; var seq_1685000163__17 any; var root_1575 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1577 lang.IFn

















































			if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = objs__16; if linked_1576 == nil { seq_1685000163__17 = ifn_1577.Invoke_O__O(arg_1578) } else { seq_1685000163__17 = linked_1576.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1575, arg_1578) }
//line :161:1
			var chunk_1685000164__18 any; var count_1685000165__19 int64 = 0; var i_1685000166__20 int64 = 0; L7: for {

















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000166__20, count_1685000165__19) { var x__21_2 any = lang.Indexed_Cast(chunk_1685000164__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000166__20)); var tmp95 any; var and__1927000168__auto____22_2 bool; var tmp96 any = A_arbace_go_check_A_const_55; var tmp97 any; var root_1579 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = x__21_2; var arg_1583 any = A_arbace_go_check_A_const_94; if linked_1580 == nil { tmp97 = ifn_1581.Invoke_O_O__O(arg_1582, arg_1583) } else { tmp97 = linked_1580.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1579, arg_1582, arg_1583) }; and__1927000168__auto____22_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp96, tmp97); if and__1927000168__auto____22_2 { var root_1584 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = x__21_2; var arg_1588 any = A_arbace_go_check_A_const_210; if linked_1585 == nil { tmp95 = ifn_1586.Invoke_O_O__O(arg_1587, arg_1588) } else { tmp95 = linked_1585.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1584, arg_1587, arg_1588) } } else { tmp95 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22_2).Ref() }; if jrt.J2g_Truth(tmp95) { var root_1740 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = x__21_2; if linked_1741 == nil { ifn_1742.Invoke_O__O(arg_1743) } else { linked_1741.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1740, arg_1743) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } else { seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L7 } } else { var temp__1927000414__auto____21_3 any; var root_1589 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = seq_1685000163__17; if linked_1590 == nil { temp__1927000414__auto____21_3 = ifn_1591.Invoke_O__O(arg_1592) } else { temp__1927000414__auto____21_3 = linked_1590.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1589, arg_1592) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000163__22 any = temp__1927000414__auto____21_3; var tmp98 any; var root_1593 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = seq_1685000163__22; if linked_1594 == nil { tmp98 = ifn_1595.Invoke_O__O(arg_1596) } else { tmp98 = linked_1594.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1593, arg_1596) }; if jrt.J2g_Truth(tmp98) { var c__1927000678__auto____23_3 any; var root_1597 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = seq_1685000163__22; if linked_1598 == nil { c__1927000678__auto____23_3 = ifn_1599.Invoke_O__O(arg_1600) } else { c__1927000678__auto____23_3 = linked_1598.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1597, arg_1600) }; var tmp99 any; var root_1744 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = seq_1685000163__22; if linked_1745 == nil { tmp99 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp99 = linked_1745.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1744, arg_1747) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp99, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__23_3 any; var root_1601 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = seq_1685000163__22; if linked_1602 == nil { x__23_3 = ifn_1603.Invoke_O__O(arg_1604) } else { x__23_3 = linked_1602.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1601, arg_1604) }; var tmp100 any; var and__1927000168__auto____24_2 bool; var tmp101 any = A_arbace_go_check_A_const_55; var tmp102 any; var root_1605 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = x__23_3; var arg_1609 any = A_arbace_go_check_A_const_94; if linked_1606 == nil { tmp102 = ifn_1607.Invoke_O_O__O(arg_1608, arg_1609) } else { tmp102 = linked_1606.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1605, arg_1608, arg_1609) }; and__1927000168__auto____24_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp101, tmp102); if and__1927000168__auto____24_2 { var root_1610 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = x__23_3; var arg_1614 any = A_arbace_go_check_A_const_210; if linked_1611 == nil { tmp100 = ifn_1612.Invoke_O_O__O(arg_1613, arg_1614) } else { tmp100 = linked_1611.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1610, arg_1613, arg_1614) } } else { tmp100 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____24_2).Ref() }; if jrt.J2g_Truth(tmp100) { var root_1748 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = x__23_3; if linked_1749 == nil { ifn_1750.Invoke_O__O(arg_1751) } else { linked_1749.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1748, arg_1751) }; var tmp103 any; var root_1752 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = seq_1685000163__22; if linked_1753 == nil { tmp103 = ifn_1754.Invoke_O__O(arg_1755) } else { tmp103 = linked_1753.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1752, arg_1755) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp103, nil, 0, 0; continue L7 } else { var tmp104 any; var root_1756 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any = seq_1685000163__22; if linked_1757 == nil { tmp104 = ifn_1758.Invoke_O__O(arg_1759) } else { tmp104 = linked_1757.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1756, arg_1759) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp104, nil, 0, 0; continue L7 } } } }
//line :161:1
				break L7 }; var seq_1685000167__17 any; var root_1615 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1617 lang.IFn


















































			if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any = objs__16; if linked_1616 == nil { seq_1685000167__17 = ifn_1617.Invoke_O__O(arg_1618) } else { seq_1685000167__17 = linked_1616.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1615, arg_1618) }
//line :161:1
			var chunk_1685000168__18 any; var count_1685000169__19 int64 = 0; var i_1685000170__20 int64 = 0; L8: for {


















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000170__20, count_1685000169__19) { var x__21_3 any = lang.Indexed_Cast(chunk_1685000168__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000170__20)); var tmp105 any; var root_1619 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = A_arbace_go_check_A_const_55; var arg_1623 any; var root_1624 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = x__21_3; var arg_1628 any = A_arbace_go_check_A_const_94; if linked_1625 == nil { arg_1623 = ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { arg_1623 = linked_1625.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; if linked_1620 == nil { tmp105 = ifn_1621.Invoke_O_O__O(arg_1622, arg_1623) } else { tmp105 = linked_1620.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1619, arg_1622, arg_1623) }; if jrt.J2g_Truth(tmp105) { var root_1760 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = x__21_3; if linked_1761 == nil { ifn_1762.Invoke_O__O(arg_1763) } else { linked_1761.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1760, arg_1763) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } else { seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L8 } } else { var temp__1927000414__auto____21_4 any; var root_1629 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = seq_1685000167__17; if linked_1630 == nil { temp__1927000414__auto____21_4 = ifn_1631.Invoke_O__O(arg_1632) } else { temp__1927000414__auto____21_4 = linked_1630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1629, arg_1632) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000167__22 any = temp__1927000414__auto____21_4; var tmp106 any; var root_1633 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = seq_1685000167__22; if linked_1634 == nil { tmp106 = ifn_1635.Invoke_O__O(arg_1636) } else { tmp106 = linked_1634.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1633, arg_1636) }; if jrt.J2g_Truth(tmp106) { var c__1927000678__auto____23_4 any; var root_1637 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = seq_1685000167__22; if linked_1638 == nil { c__1927000678__auto____23_4 = ifn_1639.Invoke_O__O(arg_1640) } else { c__1927000678__auto____23_4 = linked_1638.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1637, arg_1640) }; var tmp107 any; var root_1764 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = seq_1685000167__22; if linked_1765 == nil { tmp107 = ifn_1766.Invoke_O__O(arg_1767) } else { tmp107 = linked_1765.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1764, arg_1767) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp107, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var x__23_4 any; var root_1641 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = seq_1685000167__22; if linked_1642 == nil { x__23_4 = ifn_1643.Invoke_O__O(arg_1644) } else { x__23_4 = linked_1642.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1641, arg_1644) }; var tmp108 any; var root_1645 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = A_arbace_go_check_A_const_55; var arg_1649 any; var root_1650 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = x__23_4; var arg_1654 any = A_arbace_go_check_A_const_94; if linked_1651 == nil { arg_1649 = ifn_1652.Invoke_O_O__O(arg_1653, arg_1654) } else { arg_1649 = linked_1651.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1650, arg_1653, arg_1654) }; if linked_1646 == nil { tmp108 = ifn_1647.Invoke_O_O__O(arg_1648, arg_1649) } else { tmp108 = linked_1646.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1645, arg_1648, arg_1649) }; if jrt.J2g_Truth(tmp108) { var root_1768 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = x__23_4; if linked_1769 == nil { ifn_1770.Invoke_O__O(arg_1771) } else { linked_1769.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1768, arg_1771) }; var tmp109 any; var root_1772 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1774 lang.IFn; if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = seq_1685000167__22; if linked_1773 == nil { tmp109 = ifn_1774.Invoke_O__O(arg_1775) } else { tmp109 = linked_1773.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1772, arg_1775) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp109, nil, 0, 0; continue L8 } else { var tmp110 any; var root_1776 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = seq_1685000167__22; if linked_1777 == nil { tmp110 = ifn_1778.Invoke_O__O(arg_1779) } else { tmp110 = linked_1777.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1776, arg_1779) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp110, nil, 0, 0; continue L8 } } } }
//line :161:1
				break L8 }; var seq_1685000171__17 any; var root_1655 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1657 lang.IFn




















































			if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any; var root_1659 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1659, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1661 lang.IFn; if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any = A_arbace_go_check_A_const_119.Invoke_O__O(ctx__12); if linked_1660 == nil { arg_1658 = ifn_1661.Invoke_O__O(arg_1662) } else { arg_1658 = linked_1660.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1659, arg_1662) }; if linked_1656 == nil { seq_1685000171__17 = ifn_1657.Invoke_O__O(arg_1658) } else { seq_1685000171__17 = linked_1656.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1655, arg_1658) }
//line :161:1
			var chunk_1685000172__18 any; var count_1685000173__19 int64 = 0; var i_1685000174__20 int64 = 0; L9: for {




















































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000174__20, count_1685000173__19) { var x__21_4 any = lang.Indexed_Cast(chunk_1685000172__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000174__20)); var root_1780 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = x__21_4; if linked_1781 == nil { ifn_1782.Invoke_O__O(arg_1783) } else { linked_1781.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1780, arg_1783) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000174__20); continue L9 } else { var temp__1927000414__auto____21_5 any; var root_1663 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = seq_1685000171__17; if linked_1664 == nil { temp__1927000414__auto____21_5 = ifn_1665.Invoke_O__O(arg_1666) } else { temp__1927000414__auto____21_5 = linked_1664.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1663, arg_1666) }; if jrt.J2g_Truth(temp__1927000414__auto____21_5) { var seq_1685000171__22 any = temp__1927000414__auto____21_5; var tmp111 any; var root_1667 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = seq_1685000171__22; if linked_1668 == nil { tmp111 = ifn_1669.Invoke_O__O(arg_1670) } else { tmp111 = linked_1668.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1667, arg_1670) }; if jrt.J2g_Truth(tmp111) { var c__1927000678__auto____23_5 any; var root_1671 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = seq_1685000171__22; if linked_1672 == nil { c__1927000678__auto____23_5 = ifn_1673.Invoke_O__O(arg_1674) } else { c__1927000678__auto____23_5 = linked_1672.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1671, arg_1674) }; var tmp112 any; var root_1784 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = seq_1685000171__22; if linked_1785 == nil { tmp112 = ifn_1786.Invoke_O__O(arg_1787) } else { tmp112 = linked_1785.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1784, arg_1787) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp112, c__1927000678__auto____23_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L9 } else { var x__23_5 any; var root_1675 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = seq_1685000171__22; if linked_1676 == nil { x__23_5 = ifn_1677.Invoke_O__O(arg_1678) } else { x__23_5 = linked_1676.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1675, arg_1678) }; var root_1788 any = A_arbace_go_check_A_const_213.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = x__23_5; if linked_1789 == nil { ifn_1790.Invoke_O__O(arg_1791) } else { linked_1789.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1788, arg_1791) }; var tmp113 any; var root_1792 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = seq_1685000171__22; if linked_1793 == nil { tmp113 = ifn_1794.Invoke_O__O(arg_1795) } else { tmp113 = linked_1793.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1792, arg_1795) }; seq_1685000171__17, chunk_1685000172__18, count_1685000173__19, i_1685000174__20 = tmp113, nil, 0, 0; continue L9 } } }
//line :161:1
				break L9 }; L10: for { var vs__17 any; var root_1679 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1681 lang.IFn























































					if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = A_arbace_go_check_A_const_196.Get__O(); if linked_1680 == nil { vs__17 = ifn_1681.Invoke_O__O(arg_1682) } else { vs__17 = linked_1680.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1679, arg_1682) }
					var tmp114 any; var root_1683 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1685 lang.IFn; if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = vs__17; if linked_1684 == nil { tmp114 = ifn_1685.Invoke_O__O(arg_1686) } else { tmp114 = linked_1684.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1683, arg_1686) }; if jrt.J2g_Truth(tmp114) {
						var root_1796 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = A_arbace_go_check_A_const_196.Get__O(); var arg_1800 any = lang.PersistentVector_EMPTY.Ref(); if linked_1797 == nil { ifn_1798.Invoke_O_O__O(arg_1799, arg_1800) } else { linked_1797.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1796, arg_1799, arg_1800) }
//line :218:1
						var seq_1685000175__18 any; var root_1801 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1803 lang.IFn

						if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = vs__17; if linked_1802 == nil { seq_1685000175__18 = ifn_1803.Invoke_O__O(arg_1804) } else { seq_1685000175__18 = linked_1802.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1801, arg_1804) }
//line :218:1
						var chunk_1685000176__19 any; var count_1685000177__20 int64 = 0; var i_1685000178__21 int64 = 0; L11: for {

							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000178__21, count_1685000177__20) { var v__22 any = lang.Indexed_Cast(chunk_1685000176__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000178__21)); lang.IFn_Cast(v__22).Invoke__O(); seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000178__21); continue L11 } else { var temp__1927000414__auto____22 any; var root_1805 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = seq_1685000175__18; if linked_1806 == nil { temp__1927000414__auto____22 = ifn_1807.Invoke_O__O(arg_1808) } else { temp__1927000414__auto____22 = linked_1806.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1805, arg_1808) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1685000175__23 any = temp__1927000414__auto____22; var tmp115 any; var root_1809 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = seq_1685000175__23; if linked_1810 == nil { tmp115 = ifn_1811.Invoke_O__O(arg_1812) } else { tmp115 = linked_1810.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1809, arg_1812) }; if jrt.J2g_Truth(tmp115) { var c__1927000678__auto____24 any; var root_1813 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = seq_1685000175__23; if linked_1814 == nil { c__1927000678__auto____24 = ifn_1815.Invoke_O__O(arg_1816) } else { c__1927000678__auto____24 = linked_1814.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1813, arg_1816) }; var tmp116 any; var root_1821 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = seq_1685000175__23; if linked_1822 == nil { tmp116 = ifn_1823.Invoke_O__O(arg_1824) } else { tmp116 = linked_1822.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1821, arg_1824) }; seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = tmp116, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var v__24 any; var root_1817 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = seq_1685000175__23; if linked_1818 == nil { v__24 = ifn_1819.Invoke_O__O(arg_1820) } else { v__24 = linked_1818.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1817, arg_1820) }; lang.IFn_Cast(v__24).Invoke__O(); var tmp117 any; var root_1825 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = seq_1685000175__23; if linked_1826 == nil { tmp117 = ifn_1827.Invoke_O__O(arg_1828) } else { tmp117 = linked_1826.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1825, arg_1828) }; seq_1685000175__18, chunk_1685000176__19, count_1685000177__20, i_1685000178__21 = tmp117, nil, 0, 0; continue L11 } } }
//line :218:1
							break L11
						}

						continue L10 }
//line :161:1
					break L10
				}



























































			var root_1687 any = A_arbace_go_check_A_const_211.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, A_arbace_go_check_number_local_types_BANG__A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var root_1691 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any; var root_1695 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = pkg__8; var arg_1699 any = A_arbace_go_check_A_const_113; if linked_1696 == nil { arg_1694 = ifn_1697.Invoke_O_O__O(arg_1698, arg_1699) } else { arg_1694 = linked_1696.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1695, arg_1698, arg_1699) }; if linked_1692 == nil { arg_1690 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1690 = linked_1692.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1691, arg_1694) }; if linked_1688 == nil { ifn_1689.Invoke_O__O(arg_1690) } else { linked_1688.(*A_arbace_go_check_number_local_types_BANG__A).Invoke_O_O__O(root_1687, arg_1690) }
//line :161:1
			var decls__17 any; var root_846 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_848 lang.IFn





























































			if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var fnbody__861 any = A_arbace_go_check_check_package_fn__1685000179_A_New(); var tmp118 *jrt.Class; var fncls__860 *jrt.Class = A_arbace_go_check_check_package_fn__1685000179_A_fn_class; if fncls__860 == nil { var fncls__860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_go_check_check_package_fn__1685000179_A_fn_class = fncls__860d; tmp118 = fncls__860d } else { tmp118 = fncls__860 }; arg_853 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__861, tmp118, nil); var arg_854 any = objs__16; if linked_851 == nil { arg_849 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_847 == nil { decls__17 = ifn_848.Invoke_O__O(arg_849) } else { decls__17 = linked_847.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_846, arg_849) }
//line :161:1
			var seq_1685000181__18 any; var root_1829 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1831 lang.IFn






























































			if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = decls__17; if linked_1830 == nil { seq_1685000181__18 = ifn_1831.Invoke_O__O(arg_1832) } else { seq_1685000181__18 = linked_1830.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1829, arg_1832) }
//line :161:1
			var chunk_1685000182__19 any; var count_1685000183__20 int64 = 0; var i_1685000184__21 int64 = 0; L12: for {






























































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000184__21, count_1685000183__20) { var d__22 any = lang.Indexed_Cast(chunk_1685000182__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000184__21)); L13: for { var ls__23 any; var tmp119 *lang.Keyword = A_arbace_go_check_A_const_216; var tmp120 any; var root_1953 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1955 lang.IFn

					if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = d__22; if linked_1954 == nil { tmp120 = ifn_1955.Invoke_O__O(arg_1956) } else { tmp120 = linked_1954.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1953, arg_1956) }; ls__23 = tmp119.Invoke_O__O(tmp120)
					var tmp121 any; var root_1957 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = ls__23; if linked_1958 == nil { tmp121 = ifn_1959.Invoke_O__O(arg_1960) } else { tmp121 = linked_1958.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1957, arg_1960) }; if jrt.J2g_Truth(tmp121) {
						var tmp122 *lang.Volatile = lang.Volatile_Cast(d__22); var tmp123 any; var root_1961 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_1962 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1961, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1963 lang.IFn; if linked_1962 == nil { ifn_1963 = lang.IFn_Cast(root_1961) } else { ifn_1963 = nil }; var arg_1964 any = jrt.NN(lang.Volatile_Cast(d__22)).Deref__O(); var arg_1965 any = A_arbace_go_check_A_const_216; var arg_1966 any = lang.PersistentVector_EMPTY.Ref(); if linked_1962 == nil { tmp123 = ifn_1963.Invoke_O_O_O__O(arg_1964, arg_1965, arg_1966) } else { tmp123 = linked_1962.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1961, arg_1964, arg_1965, arg_1966) }; jrt.NN(tmp122).Reset_O__O(tmp123)
						var root_2014 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any; var tmp124 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp125 any = A_arbace_go_check_A_const_220; var tmp126 any = A_arbace_go_check_A_const_221; var tmp127 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp128 any; var root_2027 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = d__22; if linked_2028 == nil { tmp128 = ifn_2029.Invoke_O__O(arg_2030) } else { tmp128 = linked_2028.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2027, arg_2030) }; var tmp129 any = tmp127.Invoke_O__O(tmp128); var tmp130 any = A_arbace_go_check_A_const_222; var tmp131 any; var G__1685000185__24_ any; var tmp132 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp133 any; var root_2031 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = d__22; if linked_2032 == nil { tmp133 = ifn_2033.Invoke_O__O(arg_2034) } else { tmp133 = linked_2032.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2031, arg_2034) }; G__1685000185__24_ = tmp132.Invoke_O__O(tmp133); if lang.Util_Identical_O_O__Z_NoInit(G__1685000185__24_, nil) { tmp131 = nil } else { var root_2035 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = G__1685000185__24_; var arg_2039 any = A_arbace_go_check_A_const_79; if linked_2036 == nil { tmp131 = ifn_2037.Invoke_O_O__O(arg_2038, arg_2039) } else { tmp131 = linked_2036.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2035, arg_2038, arg_2039) } }; arg_2017 = tmp124.Invoke_O_O_O_O_O_O__O(tmp125, d__22, tmp126, tmp129, tmp130, tmp131); if linked_2015 == nil { ifn_2016.Invoke_O__O(arg_2017) } else { linked_2015.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2014, arg_2017) }; var tmp134 *lang.Compiler_AOTFn; var fnbody__2013 any = A_arbace_go_check_check_package_fn__1685000186_A_New_O_O(d__22, ls__23); var tmp135 *jrt.Class; var fncls__2012 *jrt.Class = A_arbace_go_check_check_package_fn__1685000186_A_fn_class; if fncls__2012 == nil { var fncls__2012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__2013); A_arbace_go_check_check_package_fn__1685000186_A_fn_class = fncls__2012d; tmp135 = fncls__2012d } else { tmp135 = fncls__2012 }; tmp134 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2013, tmp135, nil); Up_Compiler_AOTFn_IFn(tmp134).Invoke__O()


						continue L13 }
//line :224:1
					break L13 }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000184__21); continue L12 } else { var temp__1927000414__auto____22_2 any; var root_1833 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = seq_1685000181__18; if linked_1834 == nil { temp__1927000414__auto____22_2 = ifn_1835.Invoke_O__O(arg_1836) } else { temp__1927000414__auto____22_2 = linked_1834.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1833, arg_1836) }; if jrt.J2g_Truth(temp__1927000414__auto____22_2) { var seq_1685000181__23 any = temp__1927000414__auto____22_2; var tmp136 any; var root_1837 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = seq_1685000181__23; if linked_1838 == nil { tmp136 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp136 = linked_1838.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1837, arg_1840) }; if jrt.J2g_Truth(tmp136) { var c__1927000678__auto____24_2 any; var root_1841 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = seq_1685000181__23; if linked_1842 == nil { c__1927000678__auto____24_2 = ifn_1843.Invoke_O__O(arg_1844) } else { c__1927000678__auto____24_2 = linked_1842.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1841, arg_1844) }; var tmp137 any; var root_2040 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = seq_1685000181__23; if linked_2041 == nil { tmp137 = ifn_2042.Invoke_O__O(arg_2043) } else { tmp137 = linked_2041.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2040, arg_2043) }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = tmp137, c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__24 any; var root_1845 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = seq_1685000181__23; if linked_1846 == nil { d__24 = ifn_1847.Invoke_O__O(arg_1848) } else { d__24 = linked_1846.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1845, arg_1848) }; L14: for { var ls__25 any; var tmp138 *lang.Keyword = A_arbace_go_check_A_const_216; var tmp139 any; var root_2044 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2046 lang.IFn

						if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = d__24; if linked_2045 == nil { tmp139 = ifn_2046.Invoke_O__O(arg_2047) } else { tmp139 = linked_2045.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2044, arg_2047) }; ls__25 = tmp138.Invoke_O__O(tmp139)
						var tmp140 any; var root_2048 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = ls__25; if linked_2049 == nil { tmp140 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp140 = linked_2049.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2048, arg_2051) }; if jrt.J2g_Truth(tmp140) {
							var tmp141 *lang.Volatile = lang.Volatile_Cast(d__24); var tmp142 any; var root_2052 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = jrt.NN(lang.Volatile_Cast(d__24)).Deref__O(); var arg_2056 any = A_arbace_go_check_A_const_216; var arg_2057 any = lang.PersistentVector_EMPTY.Ref(); if linked_2053 == nil { tmp142 = ifn_2054.Invoke_O_O_O__O(arg_2055, arg_2056, arg_2057) } else { tmp142 = linked_2053.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2052, arg_2055, arg_2056, arg_2057) }; jrt.NN(tmp141).Reset_O__O(tmp142)
							var root_2105 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any; var tmp143 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp144 any = A_arbace_go_check_A_const_220; var tmp145 any = A_arbace_go_check_A_const_221; var tmp146 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp147 any; var root_2118 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = d__24; if linked_2119 == nil { tmp147 = ifn_2120.Invoke_O__O(arg_2121) } else { tmp147 = linked_2119.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2118, arg_2121) }; var tmp148 any = tmp146.Invoke_O__O(tmp147); var tmp149 any = A_arbace_go_check_A_const_222; var tmp150 any; var G__1685000192__26_ any; var tmp151 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp152 any; var root_2122 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = d__24; if linked_2123 == nil { tmp152 = ifn_2124.Invoke_O__O(arg_2125) } else { tmp152 = linked_2123.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2122, arg_2125) }; G__1685000192__26_ = tmp151.Invoke_O__O(tmp152); if lang.Util_Identical_O_O__Z_NoInit(G__1685000192__26_, nil) { tmp150 = nil } else { var root_2126 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = G__1685000192__26_; var arg_2130 any = A_arbace_go_check_A_const_79; if linked_2127 == nil { tmp150 = ifn_2128.Invoke_O_O__O(arg_2129, arg_2130) } else { tmp150 = linked_2127.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2126, arg_2129, arg_2130) } }; arg_2108 = tmp143.Invoke_O_O_O_O_O_O__O(tmp144, d__24, tmp145, tmp148, tmp149, tmp150); if linked_2106 == nil { ifn_2107.Invoke_O__O(arg_2108) } else { linked_2106.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2105, arg_2108) }; var tmp153 *lang.Compiler_AOTFn; var fnbody__2104 any = A_arbace_go_check_check_package_fn__1685000193_A_New_O_O(d__24, ls__25); var tmp154 *jrt.Class; var fncls__2103 *jrt.Class = A_arbace_go_check_check_package_fn__1685000193_A_fn_class; if fncls__2103 == nil { var fncls__2103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__2104); A_arbace_go_check_check_package_fn__1685000193_A_fn_class = fncls__2103d; tmp154 = fncls__2103d } else { tmp154 = fncls__2103 }; tmp153 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2104, tmp154, nil); Up_Compiler_AOTFn_IFn(tmp153).Invoke__O()


							continue L14 }
//line :224:1
						break L14 }; var tmp155 any; var root_2131 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any = seq_1685000181__23; if linked_2132 == nil { tmp155 = ifn_2133.Invoke_O__O(arg_2134) } else { tmp155 = linked_2132.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2131, arg_2134) }; seq_1685000181__18, chunk_1685000182__19, count_1685000183__20, i_1685000184__21 = tmp155, nil, 0, 0; continue L12 } } }
//line :161:1
				break L12 }; var seq_1685000199__18 any; var root_1849 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1851 lang.IFn








































































			if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = decls__17; if linked_1850 == nil { seq_1685000199__18 = ifn_1851.Invoke_O__O(arg_1852) } else { seq_1685000199__18 = linked_1850.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1849, arg_1852) }
//line :161:1
			var chunk_1685000200__19 any; var count_1685000201__20 int64 = 0; var i_1685000202__21 int64 = 0; L15: for {








































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000202__21, count_1685000201__20) { var d__22_2 any = lang.Indexed_Cast(chunk_1685000200__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000202__21)); var tmp156 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp157 any; var root_1853 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = d__22_2; if linked_1854 == nil { tmp157 = ifn_1855.Invoke_O__O(arg_1856) } else { tmp157 = linked_1854.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(tmp156.Invoke_O__O(tmp157)) {
					var root_2148 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any; var tmp158 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp159 any = A_arbace_go_check_A_const_220; var tmp160 any = A_arbace_go_check_A_const_221; var tmp161 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp162 any; var root_2159 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = d__22_2; if linked_2160 == nil { tmp162 = ifn_2161.Invoke_O__O(arg_2162) } else { tmp162 = linked_2160.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2159, arg_2162) }; arg_2151 = tmp158.Invoke_O_O_O_O__O(tmp159, d__22_2, tmp160, tmp161.Invoke_O__O(tmp162)); if linked_2149 == nil { ifn_2150.Invoke_O__O(arg_2151) } else { linked_2149.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2148, arg_2151) }; var tmp163 *lang.Compiler_AOTFn; var fnbody__2147 any = A_arbace_go_check_check_package_fn__1685000203_A_New_O(d__22_2); var tmp164 *jrt.Class; var fncls__2146 *jrt.Class = A_arbace_go_check_check_package_fn__1685000203_A_fn_class; if fncls__2146 == nil { var fncls__2146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__2147); A_arbace_go_check_check_package_fn__1685000203_A_fn_class = fncls__2146d; tmp164 = fncls__2146d } else { tmp164 = fncls__2146 }; tmp163 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2147, tmp164, nil); Up_Compiler_AOTFn_IFn(tmp163).Invoke__O()
//line :234:1
					seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000202__21); continue L15 } else { seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000202__21); continue L15 } } else { var temp__1927000414__auto____22_3 any; var root_1857 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = seq_1685000199__18; if linked_1858 == nil { temp__1927000414__auto____22_3 = ifn_1859.Invoke_O__O(arg_1860) } else { temp__1927000414__auto____22_3 = linked_1858.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1857, arg_1860) }; if jrt.J2g_Truth(temp__1927000414__auto____22_3) { var seq_1685000199__23 any = temp__1927000414__auto____22_3; var tmp165 any; var root_1861 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = seq_1685000199__23; if linked_1862 == nil { tmp165 = ifn_1863.Invoke_O__O(arg_1864) } else { tmp165 = linked_1862.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1861, arg_1864) }; if jrt.J2g_Truth(tmp165) { var c__1927000678__auto____24_3 any; var root_1865 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = seq_1685000199__23; if linked_1866 == nil { c__1927000678__auto____24_3 = ifn_1867.Invoke_O__O(arg_1868) } else { c__1927000678__auto____24_3 = linked_1866.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1865, arg_1868) }; var tmp166 any; var root_2163 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = seq_1685000199__23; if linked_2164 == nil { tmp166 = ifn_2165.Invoke_O__O(arg_2166) } else { tmp166 = linked_2164.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2163, arg_2166) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp166, c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__24_2 any; var root_1869 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = seq_1685000199__23; if linked_1870 == nil { d__24_2 = ifn_1871.Invoke_O__O(arg_1872) } else { d__24_2 = linked_1870.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1869, arg_1872) }; var tmp167 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp168 any; var root_1873 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = d__24_2; if linked_1874 == nil { tmp168 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp168 = linked_1874.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1873, arg_1876) }; if jrt.J2g_Truth(tmp167.Invoke_O__O(tmp168)) {
						var root_2180 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any; var tmp169 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp170 any = A_arbace_go_check_A_const_220; var tmp171 any = A_arbace_go_check_A_const_221; var tmp172 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp173 any; var root_2191 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = d__24_2; if linked_2192 == nil { tmp173 = ifn_2193.Invoke_O__O(arg_2194) } else { tmp173 = linked_2192.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2191, arg_2194) }; arg_2183 = tmp169.Invoke_O_O_O_O__O(tmp170, d__24_2, tmp171, tmp172.Invoke_O__O(tmp173)); if linked_2181 == nil { ifn_2182.Invoke_O__O(arg_2183) } else { linked_2181.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2180, arg_2183) }; var tmp174 *lang.Compiler_AOTFn; var fnbody__2179 any = A_arbace_go_check_check_package_fn__1685000205_A_New_O(d__24_2); var tmp175 *jrt.Class; var fncls__2178 *jrt.Class = A_arbace_go_check_check_package_fn__1685000205_A_fn_class; if fncls__2178 == nil { var fncls__2178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__2179); A_arbace_go_check_check_package_fn__1685000205_A_fn_class = fncls__2178d; tmp175 = fncls__2178d } else { tmp175 = fncls__2178 }; tmp174 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2179, tmp175, nil); Up_Compiler_AOTFn_IFn(tmp174).Invoke__O()
//line :234:1
						var tmp176 any; var root_2195 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = seq_1685000199__23; if linked_2196 == nil { tmp176 = ifn_2197.Invoke_O__O(arg_2198) } else { tmp176 = linked_2196.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2195, arg_2198) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp176, nil, 0, 0; continue L15 } else { var tmp177 any; var root_2199 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = seq_1685000199__23; if linked_2200 == nil { tmp177 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp177 = linked_2200.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2199, arg_2202) }; seq_1685000199__18, chunk_1685000200__19, count_1685000201__20, i_1685000202__21 = tmp177, nil, 0, 0; continue L15 } } } }
//line :161:1
				break L15
			}












































































			if jrt.J2g_Truth(resolving__10) { var seq_1685000207__18 any; var root_1877 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1879 lang.IFn
				if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = decls__17; if linked_1878 == nil { seq_1685000207__18 = ifn_1879.Invoke_O__O(arg_1880) } else { seq_1685000207__18 = linked_1878.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1877, arg_1880) }
//line :239:1
				var chunk_1685000208__19 any; var count_1685000209__20 int64 = 0; var i_1685000210__21 int64 = 0; L16: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000210__21, count_1685000209__20) { var d__22_3 any = lang.Indexed_Cast(chunk_1685000208__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000210__21)); var tmp178 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp179 any; var root_1881 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = d__22_3; if linked_1882 == nil { tmp179 = ifn_1883.Invoke_O__O(arg_1884) } else { tmp179 = linked_1882.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1881, arg_1884) }; if jrt.J2g_Truth(tmp178.Invoke_O__O(tmp179)) { var seq_1685000215__23 any; var root_2203 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any; var root_2207 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2209 lang.IFn
						if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any; var tmp180 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp181 any; var root_2211 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = d__22_3; if linked_2212 == nil { tmp181 = ifn_2213.Invoke_O__O(arg_2214) } else { tmp181 = linked_2212.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2211, arg_2214) }; arg_2210 = tmp180.Invoke_O__O(tmp181); if linked_2208 == nil { arg_2206 = ifn_2209.Invoke_O__O(arg_2210) } else { arg_2206 = linked_2208.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2207, arg_2210) }
//line :240:1
						if linked_2204 == nil { seq_1685000215__23 = ifn_2205.Invoke_O__O(arg_2206) } else { seq_1685000215__23 = linked_2204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2203, arg_2206) }; var chunk_1685000216__24 any; var count_1685000217__25 int64 = 0; var i_1685000218__26 int64 = 0; L17: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000218__26, count_1685000217__25) { var n__27 any = lang.Indexed_Cast(chunk_1685000216__24).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000218__26)); var tmp182 any; var tmp183 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____28 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp183, A_arbace_go_check_A_const_50.Invoke_O__O(n__27))

							if and__1927000168__auto____28 { tmp182 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__27)) } else { tmp182 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____28).Ref() }
//line :240:1
							if jrt.J2g_Truth(tmp182) {


								var root_2231 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__27); var arg_2235 any; var tmp184 any = A_arbace_go_check_A_const_226; var tmp185 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__27); var tmp186 any = A_arbace_go_check_A_const_55; var G__1685000219__28_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp184, tmp185, tmp186, A_arbace_go_check_A_const_55.Invoke_O__O(n__27), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp187 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp187.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__27))) {

									var root_2236 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = G__1685000219__28_; var arg_2240 any = A_arbace_go_check_A_const_229; var arg_2241 any = jrt.Boolean_TRUE.Ref(); if linked_2237 == nil { arg_2235 = ifn_2238.Invoke_O_O_O__O(arg_2239, arg_2240, arg_2241) } else { arg_2235 = linked_2237.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2236, arg_2239, arg_2240, arg_2241) } } else {
//line :243:1
										arg_2235 = G__1685000219__28_ }; if linked_2232 == nil { ifn_2233.Invoke_O_O__O(arg_2234, arg_2235) } else { linked_2232.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2231, arg_2234, arg_2235) }
//line :240:1
								seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000218__26); continue L17 } else { seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000218__26); continue L17 } } else { var temp__1927000414__auto____27 any; var root_2215 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = seq_1685000215__23; if linked_2216 == nil { temp__1927000414__auto____27 = ifn_2217.Invoke_O__O(arg_2218) } else { temp__1927000414__auto____27 = linked_2216.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2215, arg_2218) }; if jrt.J2g_Truth(temp__1927000414__auto____27) { var seq_1685000215__28 any = temp__1927000414__auto____27; var tmp188 any; var root_2219 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = seq_1685000215__28; if linked_2220 == nil { tmp188 = ifn_2221.Invoke_O__O(arg_2222) } else { tmp188 = linked_2220.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2219, arg_2222) }; if jrt.J2g_Truth(tmp188) { var c__1927000678__auto____29 any; var root_2223 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = seq_1685000215__28; if linked_2224 == nil { c__1927000678__auto____29 = ifn_2225.Invoke_O__O(arg_2226) } else { c__1927000678__auto____29 = linked_2224.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2223, arg_2226) }; var tmp189 any; var root_2242 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = seq_1685000215__28; if linked_2243 == nil { tmp189 = ifn_2244.Invoke_O__O(arg_2245) } else { tmp189 = linked_2243.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2242, arg_2245) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp189, c__1927000678__auto____29, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L17 } else { var n__29 any; var root_2227 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any = seq_1685000215__28; if linked_2228 == nil { n__29 = ifn_2229.Invoke_O__O(arg_2230) } else { n__29 = linked_2228.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2227, arg_2230) }; var tmp190 any; var tmp191 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____30 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp191, A_arbace_go_check_A_const_50.Invoke_O__O(n__29))

									if and__1927000168__auto____30 { tmp190 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__29)) } else { tmp190 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30).Ref() }
//line :240:1
									if jrt.J2g_Truth(tmp190) {


										var root_2246 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__29); var arg_2250 any; var tmp192 any = A_arbace_go_check_A_const_226; var tmp193 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__29); var tmp194 any = A_arbace_go_check_A_const_55; var G__1685000220__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp192, tmp193, tmp194, A_arbace_go_check_A_const_55.Invoke_O__O(n__29), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp195 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp195.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__29))) {

											var root_2251 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2251, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any = G__1685000220__30_; var arg_2255 any = A_arbace_go_check_A_const_229; var arg_2256 any = jrt.Boolean_TRUE.Ref(); if linked_2252 == nil { arg_2250 = ifn_2253.Invoke_O_O_O__O(arg_2254, arg_2255, arg_2256) } else { arg_2250 = linked_2252.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2251, arg_2254, arg_2255, arg_2256) } } else {
//line :243:1
												arg_2250 = G__1685000220__30_ }; if linked_2247 == nil { ifn_2248.Invoke_O_O__O(arg_2249, arg_2250) } else { linked_2247.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2246, arg_2249, arg_2250) }
//line :240:1
										var tmp196 any; var root_2257 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = seq_1685000215__28; if linked_2258 == nil { tmp196 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp196 = linked_2258.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2257, arg_2260) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp196, nil, 0, 0; continue L17 } else { var tmp197 any; var root_2261 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = seq_1685000215__28; if linked_2262 == nil { tmp197 = ifn_2263.Invoke_O__O(arg_2264) } else { tmp197 = linked_2262.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2261, arg_2264) }; seq_1685000215__23, chunk_1685000216__24, count_1685000217__25, i_1685000218__26 = tmp197, nil, 0, 0; continue L17 } } } }; break L17 }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__21); continue L16 } else { seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000210__21); continue L16 } } else { var temp__1927000414__auto____22_4 any; var root_1885 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = seq_1685000207__18; if linked_1886 == nil { temp__1927000414__auto____22_4 = ifn_1887.Invoke_O__O(arg_1888) } else { temp__1927000414__auto____22_4 = linked_1886.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1885, arg_1888) }; if jrt.J2g_Truth(temp__1927000414__auto____22_4) { var seq_1685000207__23 any = temp__1927000414__auto____22_4; var tmp198 any; var root_1889 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = seq_1685000207__23; if linked_1890 == nil { tmp198 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp198 = linked_1890.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1889, arg_1892) }; if jrt.J2g_Truth(tmp198) { var c__1927000678__auto____24_4 any; var root_1893 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = seq_1685000207__23; if linked_1894 == nil { c__1927000678__auto____24_4 = ifn_1895.Invoke_O__O(arg_1896) } else { c__1927000678__auto____24_4 = linked_1894.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1893, arg_1896) }; var tmp199 any; var root_2265 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any = seq_1685000207__23; if linked_2266 == nil { tmp199 = ifn_2267.Invoke_O__O(arg_2268) } else { tmp199 = linked_2266.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2265, arg_2268) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp199, c__1927000678__auto____24_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L16 } else { var d__24_3 any; var root_1897 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = seq_1685000207__23; if linked_1898 == nil { d__24_3 = ifn_1899.Invoke_O__O(arg_1900) } else { d__24_3 = linked_1898.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1897, arg_1900) }; var tmp200 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp201 any; var root_1901 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = d__24_3; if linked_1902 == nil { tmp201 = ifn_1903.Invoke_O__O(arg_1904) } else { tmp201 = linked_1902.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1901, arg_1904) }; if jrt.J2g_Truth(tmp200.Invoke_O__O(tmp201)) { var seq_1685000211__25 any; var root_2269 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2271 lang.IFn; if linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any; var root_2273 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_2275 lang.IFn
											if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any; var tmp202 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp203 any; var root_2277 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = d__24_3; if linked_2278 == nil { tmp203 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp203 = linked_2278.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2277, arg_2280) }; arg_2276 = tmp202.Invoke_O__O(tmp203); if linked_2274 == nil { arg_2272 = ifn_2275.Invoke_O__O(arg_2276) } else { arg_2272 = linked_2274.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_2273, arg_2276) }
//line :240:1
											if linked_2270 == nil { seq_1685000211__25 = ifn_2271.Invoke_O__O(arg_2272) } else { seq_1685000211__25 = linked_2270.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2269, arg_2272) }; var chunk_1685000212__26 any; var count_1685000213__27 int64 = 0; var i_1685000214__28 int64 = 0; L18: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000214__28, count_1685000213__27) { var n__29_2 any = lang.Indexed_Cast(chunk_1685000212__26).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000214__28)); var tmp204 any; var tmp205 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____30_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp205, A_arbace_go_check_A_const_50.Invoke_O__O(n__29_2))

												if and__1927000168__auto____30_2 { tmp204 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__29_2)) } else { tmp204 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____30_2).Ref() }
//line :240:1
												if jrt.J2g_Truth(tmp204) {


													var root_2297 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__29_2); var arg_2301 any; var tmp206 any = A_arbace_go_check_A_const_226; var tmp207 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__29_2); var tmp208 any = A_arbace_go_check_A_const_55; var G__1685000221__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp206, tmp207, tmp208, A_arbace_go_check_A_const_55.Invoke_O__O(n__29_2), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp209 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp209.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__29_2))) {

														var root_2302 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2302, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = G__1685000221__30_; var arg_2306 any = A_arbace_go_check_A_const_229; var arg_2307 any = jrt.Boolean_TRUE.Ref(); if linked_2303 == nil { arg_2301 = ifn_2304.Invoke_O_O_O__O(arg_2305, arg_2306, arg_2307) } else { arg_2301 = linked_2303.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2302, arg_2305, arg_2306, arg_2307) } } else {
//line :243:1
															arg_2301 = G__1685000221__30_ }; if linked_2298 == nil { ifn_2299.Invoke_O_O__O(arg_2300, arg_2301) } else { linked_2298.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2297, arg_2300, arg_2301) }
//line :240:1
													seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__28); continue L18 } else { seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000214__28); continue L18 } } else { var temp__1927000414__auto____29 any; var root_2281 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = seq_1685000211__25; if linked_2282 == nil { temp__1927000414__auto____29 = ifn_2283.Invoke_O__O(arg_2284) } else { temp__1927000414__auto____29 = linked_2282.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2281, arg_2284) }; if jrt.J2g_Truth(temp__1927000414__auto____29) { var seq_1685000211__30 any = temp__1927000414__auto____29; var tmp210 any; var root_2285 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = seq_1685000211__30; if linked_2286 == nil { tmp210 = ifn_2287.Invoke_O__O(arg_2288) } else { tmp210 = linked_2286.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2285, arg_2288) }; if jrt.J2g_Truth(tmp210) { var c__1927000678__auto____31 any; var root_2289 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = seq_1685000211__30; if linked_2290 == nil { c__1927000678__auto____31 = ifn_2291.Invoke_O__O(arg_2292) } else { c__1927000678__auto____31 = linked_2290.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2289, arg_2292) }; var tmp211 any; var root_2308 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = seq_1685000211__30; if linked_2309 == nil { tmp211 = ifn_2310.Invoke_O__O(arg_2311) } else { tmp211 = linked_2309.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2308, arg_2311) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp211, c__1927000678__auto____31, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L18 } else { var n__31 any; var root_2293 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = seq_1685000211__30; if linked_2294 == nil { n__31 = ifn_2295.Invoke_O__O(arg_2296) } else { n__31 = linked_2294.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2293, arg_2296) }; var tmp212 any; var tmp213 any = A_arbace_go_check_A_const_63; var and__1927000168__auto____32 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp213, A_arbace_go_check_A_const_50.Invoke_O__O(n__31))

														if and__1927000168__auto____32 { tmp212 = lang.IFn_Cast(A_arbace_go_check_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_70.Invoke_O__O(n__31)) } else { tmp212 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____32).Ref() }
//line :240:1
														if jrt.J2g_Truth(tmp212) {


															var root_2312 any = A_arbace_go_check_A_const_225.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = A_arbace_go_check_A_const_69.Invoke_O__O(n__31); var arg_2316 any; var tmp214 any = A_arbace_go_check_A_const_226; var tmp215 any = A_arbace_go_check_A_const_226.Invoke_O__O(n__31); var tmp216 any = A_arbace_go_check_A_const_55; var G__1685000222__32_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp214, tmp215, tmp216, A_arbace_go_check_A_const_55.Invoke_O__O(n__31), A_arbace_go_check_A_const_227, jrt.Boolean_TRUE.Ref())); var tmp217 *lang.Keyword = A_arbace_go_check_A_const_228; if jrt.J2g_Truth(tmp217.Invoke_O__O(A_arbace_go_check_A_const_66.Invoke_O__O(n__31))) {

																var root_2317 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = G__1685000222__32_; var arg_2321 any = A_arbace_go_check_A_const_229; var arg_2322 any = jrt.Boolean_TRUE.Ref(); if linked_2318 == nil { arg_2316 = ifn_2319.Invoke_O_O_O__O(arg_2320, arg_2321, arg_2322) } else { arg_2316 = linked_2318.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2317, arg_2320, arg_2321, arg_2322) } } else {
//line :243:1
																	arg_2316 = G__1685000222__32_ }; if linked_2313 == nil { ifn_2314.Invoke_O_O__O(arg_2315, arg_2316) } else { linked_2313.(*aot_arbace_go_check_env.A_arbace_go_check_env_answer_BANG__A).Invoke_O_O_O__O(root_2312, arg_2315, arg_2316) }
//line :240:1
															var tmp218 any; var root_2323 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2323, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2325 lang.IFn; if linked_2324 == nil { ifn_2325 = lang.IFn_Cast(root_2323) } else { ifn_2325 = nil }; var arg_2326 any = seq_1685000211__30; if linked_2324 == nil { tmp218 = ifn_2325.Invoke_O__O(arg_2326) } else { tmp218 = linked_2324.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2323, arg_2326) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp218, nil, 0, 0; continue L18 } else { var tmp219 any; var root_2327 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = seq_1685000211__30; if linked_2328 == nil { tmp219 = ifn_2329.Invoke_O__O(arg_2330) } else { tmp219 = linked_2328.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2327, arg_2330) }; seq_1685000211__25, chunk_1685000212__26, count_1685000213__27, i_1685000214__28 = tmp219, nil, 0, 0; continue L18 } } } }; break L18 }; var tmp220 any; var root_2331 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = seq_1685000207__23; if linked_2332 == nil { tmp220 = ifn_2333.Invoke_O__O(arg_2334) } else { tmp220 = linked_2332.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2331, arg_2334) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp220, nil, 0, 0; continue L16 } else { var tmp221 any; var root_2335 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = seq_1685000207__23; if linked_2336 == nil { tmp221 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp221 = linked_2336.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2335, arg_2338) }; seq_1685000207__18, chunk_1685000208__19, count_1685000209__20, i_1685000210__21 = tmp221, nil, 0, 0; continue L16 } } } }
//line :239:1
					break L16 } }
//line :161:1
			var seq_1685000223__18 any; var root_1905 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1907 lang.IFn





















































































			if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = decls__17; if linked_1906 == nil { seq_1685000223__18 = ifn_1907.Invoke_O__O(arg_1908) } else { seq_1685000223__18 = linked_1906.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1905, arg_1908) }
//line :161:1
			var chunk_1685000224__19 any; var count_1685000225__20 int64 = 0; var i_1685000226__21 int64 = 0; L19: for {





















































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000226__21, count_1685000225__20) { var d__22_4 any = lang.Indexed_Cast(chunk_1685000224__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000226__21)); var tmp222 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp223 any; var root_1909 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = d__22_4; if linked_1910 == nil { tmp223 = ifn_1911.Invoke_O__O(arg_1912) } else { tmp223 = linked_1910.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1909, arg_1912) }; if jrt.J2g_Truth(tmp222.Invoke_O__O(tmp223)) {
					var root_2339 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any; var tmp224 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp225 any; var root_2344 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = d__22_4; if linked_2345 == nil { tmp225 = ifn_2346.Invoke_O__O(arg_2347) } else { tmp225 = linked_2345.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2344, arg_2347) }; arg_2342 = tmp224.Invoke_O__O(tmp225); var arg_2343 any; var tmp226 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp227 any; var root_2348 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = d__22_4; if linked_2349 == nil { tmp227 = ifn_2350.Invoke_O__O(arg_2351) } else { tmp227 = linked_2349.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2348, arg_2351) }; arg_2343 = tmp226.Invoke_O__O(tmp227); if linked_2340 == nil { ifn_2341.Invoke_O_O__O(arg_2342, arg_2343) } else { linked_2340.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2339, arg_2342, arg_2343) }
//line :247:1
					seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } else { seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000226__21); continue L19 } } else { var temp__1927000414__auto____22_5 any; var root_1913 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = seq_1685000223__18; if linked_1914 == nil { temp__1927000414__auto____22_5 = ifn_1915.Invoke_O__O(arg_1916) } else { temp__1927000414__auto____22_5 = linked_1914.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1913, arg_1916) }; if jrt.J2g_Truth(temp__1927000414__auto____22_5) { var seq_1685000223__23 any = temp__1927000414__auto____22_5; var tmp228 any; var root_1917 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = seq_1685000223__23; if linked_1918 == nil { tmp228 = ifn_1919.Invoke_O__O(arg_1920) } else { tmp228 = linked_1918.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1917, arg_1920) }; if jrt.J2g_Truth(tmp228) { var c__1927000678__auto____24_5 any; var root_1921 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = seq_1685000223__23; if linked_1922 == nil { c__1927000678__auto____24_5 = ifn_1923.Invoke_O__O(arg_1924) } else { c__1927000678__auto____24_5 = linked_1922.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1921, arg_1924) }; var tmp229 any; var root_2352 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = seq_1685000223__23; if linked_2353 == nil { tmp229 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp229 = linked_2353.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2352, arg_2355) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp229, c__1927000678__auto____24_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L19 } else { var d__24_4 any; var root_1925 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = seq_1685000223__23; if linked_1926 == nil { d__24_4 = ifn_1927.Invoke_O__O(arg_1928) } else { d__24_4 = linked_1926.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1925, arg_1928) }; var tmp230 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp231 any; var root_1929 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = d__24_4; if linked_1930 == nil { tmp231 = ifn_1931.Invoke_O__O(arg_1932) } else { tmp231 = linked_1930.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1929, arg_1932) }; if jrt.J2g_Truth(tmp230.Invoke_O__O(tmp231)) {
						var root_2356 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any; var tmp232 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp233 any; var root_2361 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = d__24_4; if linked_2362 == nil { tmp233 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp233 = linked_2362.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2361, arg_2364) }; arg_2359 = tmp232.Invoke_O__O(tmp233); var arg_2360 any; var tmp234 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp235 any; var root_2365 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = d__24_4; if linked_2366 == nil { tmp235 = ifn_2367.Invoke_O__O(arg_2368) } else { tmp235 = linked_2366.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2365, arg_2368) }; arg_2360 = tmp234.Invoke_O__O(tmp235); if linked_2357 == nil { ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { linked_2357.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) }
//line :247:1
						var tmp236 any; var root_2369 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2369, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2371 lang.IFn; if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = seq_1685000223__23; if linked_2370 == nil { tmp236 = ifn_2371.Invoke_O__O(arg_2372) } else { tmp236 = linked_2370.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2369, arg_2372) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp236, nil, 0, 0; continue L19 } else { var tmp237 any; var root_2373 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = seq_1685000223__23; if linked_2374 == nil { tmp237 = ifn_2375.Invoke_O__O(arg_2376) } else { tmp237 = linked_2374.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2373, arg_2376) }; seq_1685000223__18, chunk_1685000224__19, count_1685000225__20, i_1685000226__21 = tmp237, nil, 0, 0; continue L19 } } } }
//line :161:1
				break L19 }; var seq_1685000227__18 any; var root_1933 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1935 lang.IFn























































































			if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = fis__13; if linked_1934 == nil { seq_1685000227__18 = ifn_1935.Invoke_O__O(arg_1936) } else { seq_1685000227__18 = linked_1934.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1933, arg_1936) }
//line :161:1
			var chunk_1685000228__19 any; var count_1685000229__20 int64 = 0; var i_1685000230__21 int64 = 0; L20: for {























































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000230__21, count_1685000229__20) { var fi__22_5 any = lang.Indexed_Cast(chunk_1685000228__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000230__21)); var root_2377 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2377, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2379 lang.IFn; if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any = fi__22_5; if linked_2378 == nil { ifn_2379.Invoke_O__O(arg_2380) } else { linked_2378.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2377, arg_2380) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000230__21); continue L20 } else { var temp__1927000414__auto____22_6 any; var root_1937 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = seq_1685000227__18; if linked_1938 == nil { temp__1927000414__auto____22_6 = ifn_1939.Invoke_O__O(arg_1940) } else { temp__1927000414__auto____22_6 = linked_1938.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1937, arg_1940) }; if jrt.J2g_Truth(temp__1927000414__auto____22_6) { var seq_1685000227__23 any = temp__1927000414__auto____22_6; var tmp238 any; var root_1941 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = seq_1685000227__23; if linked_1942 == nil { tmp238 = ifn_1943.Invoke_O__O(arg_1944) } else { tmp238 = linked_1942.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1941, arg_1944) }; if jrt.J2g_Truth(tmp238) { var c__1927000678__auto____24_6 any; var root_1945 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = seq_1685000227__23; if linked_1946 == nil { c__1927000678__auto____24_6 = ifn_1947.Invoke_O__O(arg_1948) } else { c__1927000678__auto____24_6 = linked_1946.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1945, arg_1948) }; var tmp239 any; var root_2381 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = seq_1685000227__23; if linked_2382 == nil { tmp239 = ifn_2383.Invoke_O__O(arg_2384) } else { tmp239 = linked_2382.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2381, arg_2384) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = tmp239, c__1927000678__auto____24_6, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24_6))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L20 } else { var fi__24 any; var root_1949 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1951 lang.IFn; if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = seq_1685000227__23; if linked_1950 == nil { fi__24 = ifn_1951.Invoke_O__O(arg_1952) } else { fi__24 = linked_1950.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1949, arg_1952) }; var root_2385 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any = fi__24; if linked_2386 == nil { ifn_2387.Invoke_O__O(arg_2388) } else { linked_2386.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_2385, arg_2388) }; var tmp240 any; var root_2389 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = seq_1685000227__23; if linked_2390 == nil { tmp240 = ifn_2391.Invoke_O__O(arg_2392) } else { tmp240 = linked_2390.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2389, arg_2392) }; seq_1685000227__18, chunk_1685000228__19, count_1685000229__20, i_1685000230__21 = tmp240, nil, 0, 0; continue L20 } } }
//line :161:1
				break L20 }; var order__18 any; var root_862 any = A_arbace_go_check_A_const_129.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_864 lang.IFn

























































































			if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = objs__16; if linked_863 == nil { order__18 = ifn_864.Invoke_O__O(arg_865) } else { order__18 = linked_863.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_862, arg_865) }
//line :161:1
			var ___19 any; var tmp241 any; var root_866 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_868 lang.IFn; _ = ___19



























































































			if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var root_870 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = errors__9; if linked_871 == nil { arg_869 = ifn_872.Invoke_O__O(arg_873) } else { arg_869 = linked_871.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_870, arg_873) }; if linked_867 == nil { tmp241 = ifn_868.Invoke_O__O(arg_869) } else { tmp241 = linked_867.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_866, arg_869) }; if jrt.J2g_Truth(tmp241) { var root_874 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; if linked_875 == nil { ___19 = ifn_876.Invoke__O() } else { ___19 = linked_875.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_monomorph_BANG__A).Invoke_O__O(root_874) } } else { ___19 = nil }
//line :161:1
			var ___20 any; var tmp242 any; var root_877 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_879 lang.IFn; _ = ___20





























































































			if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any; var root_881 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = errors__9; if linked_882 == nil { arg_880 = ifn_883.Invoke_O__O(arg_884) } else { arg_880 = linked_882.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_881, arg_884) }; if linked_878 == nil { tmp242 = ifn_879.Invoke_O__O(arg_880) } else { tmp242 = linked_878.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_877, arg_880) }; if jrt.J2g_Truth(tmp242) { var root_885 any = A_arbace_go_check_A_const_132.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; if linked_886 == nil { ___20 = ifn_887.Invoke__O() } else { ___20 = linked_886.(*aot_arbace_go_check_code.A_arbace_go_check_code_anon_iface_cycles_BANG__A).Invoke_O__O(root_885) } } else { ___20 = nil }
//line :161:1
			var say__21 any; var root_888 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_890 lang.IFn






























































































			if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = src__0; var arg_892 any = A_arbace_go_check_A_const_133; if linked_889 == nil { say__21 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { say__21 = linked_889.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) }
//line :161:1
			var init_entry__22 any; var fnbody__935 any = A_arbace_go_check_check_package_init_entry__1685000231_A_New(); var tmp243 *jrt.Class
			var fncls__934 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class































































































			if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class = fncls__934d; tmp243 = fncls__934d } else { tmp243 = fncls__934 }; init_entry__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__935, tmp243, nil)
//line :161:1
			var have__23 any; var root_936 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_938 lang.IFn


































































































			if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = init_entry__22; var arg_940 any = order__18; if linked_937 == nil { have__23 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { have__23 = linked_937.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }
//line :161:1
			var norm__24 any; var fnbody__971 any = A_arbace_go_check_check_package_norm__1685000235_A_New(); var tmp244 *jrt.Class
			var fncls__970 /*line :161:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000235_A_fn_class




































































































			if fncls__970 == nil { var fncls__970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_go_check_check_package_norm__1685000235_A_fn_class = fncls__970d; tmp244 = fncls__970d } else { tmp244 = fncls__970 }; norm__24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__971, tmp244, nil)
//line :161:1
			var init_result__25 any; var tmp245 any; var root_972 any = A_arbace_go_check_A_const_114.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_974 lang.IFn









































































































			if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = say__21; if linked_973 == nil { tmp245 = ifn_974.Invoke_O__O(arg_975) } else { tmp245 = linked_973.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_972, arg_975) }; if jrt.J2g_Truth(tmp245) {
				var tmp246 any; var root_976 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = norm__24; var arg_980 any = say__21; if linked_977 == nil { tmp246 = ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { tmp246 = linked_977.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_976, arg_979, arg_980) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp246, have__23) { var tmp247 any = A_arbace_go_check_A_const_140; var tmp248 any = jrt.Boolean_TRUE.Ref(); var tmp249 any = A_arbace_go_check_A_const_141; init_result__25 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp247, tmp248, tmp249, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__21)).Ref())) } else {

					var root_2393 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_232.Invoke_O__O(src__0)) { arg_2396 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_232.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp250 *lang.Keyword = A_arbace_go_check_A_const_71; var tmp251 any; var root_2400 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__0); if linked_2401 == nil { tmp251 = ifn_2402.Invoke_O__O(arg_2403) } else { tmp251 = linked_2401.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2400, arg_2403) }; arg_2396 = tmp250.Invoke_O__O(tmp251) }; var arg_2397 any; var or__1927000174__auto____25 any = A_arbace_go_check_A_const_233.Invoke_O__O(src__0)
					if jrt.J2g_Truth(or__1927000174__auto____25) { arg_2397 = or__1927000174__auto____25 } else { arg_2397 = A_arbace_go_check_A_const_22 }
//line :270:1
					var arg_2398 any = A_arbace_go_check_A_const_234; var arg_2399 any = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_66, A_arbace_go_check_A_const_111.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()).Invoke_O__O(say__21), lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()).Invoke_O__O(have__23)); if linked_2394 == nil { ifn_2395.Invoke_O_O_O_O__O(arg_2396, arg_2397, arg_2398, arg_2399) } else { linked_2394.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_2393, arg_2396, arg_2397, arg_2398, arg_2399) }
//line :268:1
					init_result__25 = A_arbace_go_check_A_const_142 } } else {
//line :267:1
						init_result__25 = nil }
//line :161:1
			var generic_ids__26 any; var root_981 any = A_arbace_go_check_A_const_143.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_983 lang.IFn


















































































































			if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any; var root_985 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any; var fnbody__999 any = A_arbace_go_check_check_package_fn__1685000239_A_New(); var tmp252 *jrt.Class; var fncls__998 *jrt.Class = A_arbace_go_check_check_package_fn__1685000239_A_fn_class; if fncls__998 == nil { var fncls__998d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_go_check_check_package_fn__1685000239_A_fn_class = fncls__998d; tmp252 = fncls__998d } else { tmp252 = fncls__998 }; arg_988 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__999, tmp252, nil); var arg_989 any = decls__17; if linked_986 == nil { arg_984 = ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { arg_984 = linked_986.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_985, arg_988, arg_989) }; if linked_982 == nil { generic_ids__26 = ifn_983.Invoke_O__O(arg_984) } else { generic_ids__26 = linked_982.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_981, arg_984) }
//line :161:1
			var errs__27 any; var root_1000 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1002 lang.IFn

























































































			if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = errors__9; if linked_1001 == nil { errs__27 = ifn_1002.Invoke_O__O(arg_1003) } else { errs__27 = linked_1001.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1000, arg_1003) }
//line :161:1
			var counted__28 any; var root_1004 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1006 lang.IFn




















































































































			if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any; var fnbody__1015 any = A_arbace_go_check_check_package_fn__1685000241_A_New_O(generic_ids__26); var tmp253 *jrt.Class; var fncls__1014 *jrt.Class = A_arbace_go_check_check_package_fn__1685000241_A_fn_class; if fncls__1014 == nil { var fncls__1014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1015); A_arbace_go_check_check_package_fn__1685000241_A_fn_class = fncls__1014d; tmp253 = fncls__1014d } else { tmp253 = fncls__1014 }; arg_1007 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1015, tmp253, nil); var arg_1008 any = errs__27; if linked_1005 == nil { counted__28 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { counted__28 = linked_1005.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }
//line :161:1
			var forms__29 any; var m__29 any = jrt.IdentityHashMap_New(); var order__30 any = jrt.ArrayList_New(); var seq_1685000243__31 any; var root_2419 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2421 lang.IFn
























































































































			if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = decls__17; if linked_2420 == nil { seq_1685000243__31 = ifn_2421.Invoke_O__O(arg_2422) } else { seq_1685000243__31 = linked_2420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2419, arg_2422) }
//line :161:1
			var chunk_1685000244__32 any; var count_1685000245__33 int64 = 0; var i_1685000246__34 int64 = 0; L21: for {
























































































































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000246__34, count_1685000245__33) { var d__35 any = lang.Indexed_Cast(chunk_1685000244__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000246__34)); var f__36 any; var tmp254 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp255 any; var root_2439 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2441 lang.IFn
					if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = d__35; if linked_2440 == nil { tmp255 = ifn_2441.Invoke_O__O(arg_2442) } else { tmp255 = linked_2440.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2439, arg_2442) }; f__36 = tmp254.Invoke_O__O(tmp255)
					if jrt.IdentityHashMap_Cast(m__29).ContainsKey_O__Z(f__36) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayList_Cast(order__30).Add_O__Z(f__36)); jrt.IdentityHashMap_Cast(m__29).Put_O_O__O(f__36, lang.PersistentVector_EMPTY.Ref()) }
					var tmp256 jrt.IdentityHashMap_I = jrt.IdentityHashMap_Cast(m__29); var tmp257 any; var root_2443 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2445 lang.IFn; if linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any = jrt.IdentityHashMap_Cast(m__29).Get_O__O(f__36); var arg_2447 any = d__35; if linked_2444 == nil { tmp257 = ifn_2445.Invoke_O_O__O(arg_2446, arg_2447) } else { tmp257 = linked_2444.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2443, arg_2446, arg_2447) }; tmp256.Put_O_O__O(f__36, tmp257)
//line :282:1
					seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000246__34); continue L21 } else { var temp__1927000414__auto____35 any; var root_2423 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = seq_1685000243__31; if linked_2424 == nil { temp__1927000414__auto____35 = ifn_2425.Invoke_O__O(arg_2426) } else { temp__1927000414__auto____35 = linked_2424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2423, arg_2426) }; if jrt.J2g_Truth(temp__1927000414__auto____35) { var seq_1685000243__36 any = temp__1927000414__auto____35; var tmp258 any; var root_2427 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2429 lang.IFn; if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = seq_1685000243__36; if linked_2428 == nil { tmp258 = ifn_2429.Invoke_O__O(arg_2430) } else { tmp258 = linked_2428.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2427, arg_2430) }; if jrt.J2g_Truth(tmp258) { var c__1927000678__auto____37 any; var root_2431 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2433 lang.IFn; if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = seq_1685000243__36; if linked_2432 == nil { c__1927000678__auto____37 = ifn_2433.Invoke_O__O(arg_2434) } else { c__1927000678__auto____37 = linked_2432.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2431, arg_2434) }; var tmp259 any; var root_2448 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2448, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2450 lang.IFn; if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any = seq_1685000243__36; if linked_2449 == nil { tmp259 = ifn_2450.Invoke_O__O(arg_2451) } else { tmp259 = linked_2449.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2448, arg_2451) }; seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = tmp259, c__1927000678__auto____37, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L21 } else { var d__37 any; var root_2435 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = seq_1685000243__36; if linked_2436 == nil { d__37 = ifn_2437.Invoke_O__O(arg_2438) } else { d__37 = linked_2436.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2435, arg_2438) }; var f__38 any; var tmp260 *lang.Keyword = A_arbace_go_check_A_const_101; var tmp261 any; var root_2452 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2454 lang.IFn
						if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any = d__37; if linked_2453 == nil { tmp261 = ifn_2454.Invoke_O__O(arg_2455) } else { tmp261 = linked_2453.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2452, arg_2455) }; f__38 = tmp260.Invoke_O__O(tmp261)
						if jrt.IdentityHashMap_Cast(m__29).ContainsKey_O__Z(f__38) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayList_Cast(order__30).Add_O__Z(f__38)); jrt.IdentityHashMap_Cast(m__29).Put_O_O__O(f__38, lang.PersistentVector_EMPTY.Ref()) }
						var tmp262 jrt.IdentityHashMap_I = jrt.IdentityHashMap_Cast(m__29); var tmp263 any; var root_2456 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2458 lang.IFn; if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = jrt.IdentityHashMap_Cast(m__29).Get_O__O(f__38); var arg_2460 any = d__37; if linked_2457 == nil { tmp263 = ifn_2458.Invoke_O_O__O(arg_2459, arg_2460) } else { tmp263 = linked_2457.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2456, arg_2459, arg_2460) }; tmp262.Put_O_O__O(f__38, tmp263)
//line :282:1
						var tmp264 any; var root_2461 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = seq_1685000243__36; if linked_2462 == nil { tmp264 = ifn_2463.Invoke_O__O(arg_2464) } else { tmp264 = linked_2462.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2461, arg_2464) }; seq_1685000243__31, chunk_1685000244__32, count_1685000245__33, i_1685000246__34 = tmp264, nil, 0, 0; continue L21 } } }
//line :161:1
				break L21
			}



























































































































			var root_1016 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any; var fnbody__1022 any = A_arbace_go_check_check_package_fn__1685000247_A_New_O(m__29); var tmp265 *jrt.Class; var fncls__1021 *jrt.Class = A_arbace_go_check_check_package_fn__1685000247_A_fn_class; if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1022); A_arbace_go_check_check_package_fn__1685000247_A_fn_class = fncls__1021d; tmp265 = fncls__1021d } else { tmp265 = fncls__1021 }; arg_1019 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1022, tmp265, nil); var arg_1020 any = order__30; if linked_1017 == nil { forms__29 = ifn_1018.Invoke_O_O__O(arg_1019, arg_1020) } else { forms__29 = linked_1017.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1016, arg_1019, arg_1020) }
//line :161:1
			var stats__30 any; var root_1023 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1025 lang.IFn





























































































































			if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any; var fnbody__1317 any = A_arbace_go_check_check_package_fn__1685000250_A_New_O(resolving__10); var tmp266 *jrt.Class; var fncls__1316 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_A_fn_class
			if fncls__1316 == nil { var fncls__1316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__1317); A_arbace_go_check_check_package_fn__1685000250_A_fn_class = fncls__1316d; tmp266 = fncls__1316d } else { tmp266 = fncls__1316 }; arg_1026 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1317, tmp266, nil)
//line :287:1
			var arg_1027 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_164, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_83, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_153, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_155, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_140, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_166, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_157, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_145, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_167, lang.PersistentVector_EMPTY.Ref())); var arg_1028 any = forms__29; if linked_1024 == nil { stats__30 = ifn_1025.Invoke_O_O_O__O(arg_1026, arg_1027, arg_1028) } else { stats__30 = linked_1024.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1023, arg_1026, arg_1027, arg_1028)
			}




























			var tmp267 any
			var and__1927000168__auto____31 any = resolving__10

			if jrt.J2g_Truth(and__1927000168__auto____31) { var root_2465 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2465, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2467 lang.IFn; if linked_2466 == nil { ifn_2467 = lang.IFn_Cast(root_2465) } else { ifn_2467 = nil }; var arg_2468 any = keep_trees__6; if linked_2466 == nil { tmp267 = ifn_2467.Invoke_O__O(arg_2468) } else { tmp267 = linked_2466.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2465, arg_2468) } } else { tmp267 = and__1927000168__auto____31 }
//line :317:1
			if jrt.J2g_Truth(tmp267) { var seq_1685000291__31 any; var root_2469 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2471 lang.IFn



				if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = decls__17; if linked_2470 == nil { seq_1685000291__31 = ifn_2471.Invoke_O__O(arg_2472) } else { seq_1685000291__31 = linked_2470.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2469, arg_2472) }
//line :317:1
				var chunk_1685000292__32 any; var count_1685000293__33 int64 = 0; var i_1685000294__34 int64 = 0; L22: for {



					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000294__34, count_1685000293__33) { var d__35_2 any = lang.Indexed_Cast(chunk_1685000292__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000294__34)); var root_2674 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = d__35_2; var arg_2678 any; var root_2679 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any; var root_2684 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = d__35_2; if linked_2685 == nil { arg_2682 = ifn_2686.Invoke_O__O(arg_2687) } else { arg_2682 = linked_2685.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2684, arg_2687) }; var arg_2683 any = A_arbace_go_check_A_const_252; if linked_2680 == nil { arg_2678 = ifn_2681.Invoke_O_O__O(arg_2682, arg_2683) } else { arg_2678 = linked_2680.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2679, arg_2682, arg_2683) }; if linked_2675 == nil { ifn_2676.Invoke_O_O__O(arg_2677, arg_2678) } else { linked_2675.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2674, arg_2677, arg_2678) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000294__34); continue L22 } else { var temp__1927000414__auto____35_2 any; var root_2473 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2475 lang.IFn; if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = seq_1685000291__31; if linked_2474 == nil { temp__1927000414__auto____35_2 = ifn_2475.Invoke_O__O(arg_2476) } else { temp__1927000414__auto____35_2 = linked_2474.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2473, arg_2476) }; if jrt.J2g_Truth(temp__1927000414__auto____35_2) { var seq_1685000291__36 any = temp__1927000414__auto____35_2; var tmp268 any; var root_2477 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = seq_1685000291__36; if linked_2478 == nil { tmp268 = ifn_2479.Invoke_O__O(arg_2480) } else { tmp268 = linked_2478.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2477, arg_2480) }; if jrt.J2g_Truth(tmp268) { var c__1927000678__auto____37_2 any; var root_2481 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = seq_1685000291__36; if linked_2482 == nil { c__1927000678__auto____37_2 = ifn_2483.Invoke_O__O(arg_2484) } else { c__1927000678__auto____37_2 = linked_2482.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2481, arg_2484) }; var tmp269 any; var root_2688 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2690 lang.IFn; if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = seq_1685000291__36; if linked_2689 == nil { tmp269 = ifn_2690.Invoke_O__O(arg_2691) } else { tmp269 = linked_2689.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2688, arg_2691) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp269, c__1927000678__auto____37_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L22 } else { var d__37_2 any; var root_2485 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = seq_1685000291__36; if linked_2486 == nil { d__37_2 = ifn_2487.Invoke_O__O(arg_2488) } else { d__37_2 = linked_2486.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2485, arg_2488) }; var root_2692 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_2693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2692, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_2694 lang.IFn; if linked_2693 == nil { ifn_2694 = lang.IFn_Cast(root_2692) } else { ifn_2694 = nil }; var arg_2695 any = d__37_2; var arg_2696 any; var root_2697 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2697, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2699 lang.IFn; if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2700 any; var root_2702 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = d__37_2; if linked_2703 == nil { arg_2700 = ifn_2704.Invoke_O__O(arg_2705) } else { arg_2700 = linked_2703.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2702, arg_2705) }; var arg_2701 any = A_arbace_go_check_A_const_253; if linked_2698 == nil { arg_2696 = ifn_2699.Invoke_O_O__O(arg_2700, arg_2701) } else { arg_2696 = linked_2698.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2697, arg_2700, arg_2701) }; if linked_2693 == nil { ifn_2694.Invoke_O_O__O(arg_2695, arg_2696) } else { linked_2693.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_2692, arg_2695, arg_2696) }; var tmp270 any; var root_2706 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2706, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2708 lang.IFn; if linked_2707 == nil { ifn_2708 = lang.IFn_Cast(root_2706) } else { ifn_2708 = nil }; var arg_2709 any = seq_1685000291__36; if linked_2707 == nil { tmp270 = ifn_2708.Invoke_O__O(arg_2709) } else { tmp270 = linked_2707.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2706, arg_2709) }; seq_1685000291__31, chunk_1685000292__32, count_1685000293__33, i_1685000294__34 = tmp270, nil, 0, 0; continue L22 } } }
//line :317:1
					break L22 } } else { var tmp271 any; var root_2489 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2491 lang.IFn




						if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = keep_trees__6; if linked_2490 == nil { tmp271 = ifn_2491.Invoke_O__O(arg_2492) } else { tmp271 = linked_2490.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2489, arg_2492) }
//line :317:1
						if jrt.J2g_Truth(tmp271) { var seq_1685000295__31 any; var root_2493 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2495 lang.IFn





							if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = decls__17; if linked_2494 == nil { seq_1685000295__31 = ifn_2495.Invoke_O__O(arg_2496) } else { seq_1685000295__31 = linked_2494.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2493, arg_2496) }
//line :317:1
							var chunk_1685000296__32 any; var count_1685000297__33 int64 = 0; var i_1685000298__34 int64 = 0; L23: for {





								if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000298__34, count_1685000297__33) { var d__35_3 any = lang.Indexed_Cast(chunk_1685000296__32).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000298__34)); var tmp272 any; var and__1927000168__auto____36 bool; var tmp273 any = A_arbace_go_check_A_const_254; var tmp274 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp275 any; var root_2710 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2710, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2712 lang.IFn
									if linked_2711 == nil { ifn_2712 = lang.IFn_Cast(root_2710) } else { ifn_2712 = nil }; var arg_2713 any = d__35_3; if linked_2711 == nil { tmp275 = ifn_2712.Invoke_O__O(arg_2713) } else { tmp275 = linked_2711.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2710, arg_2713) }; and__1927000168__auto____36 = lang.Util_Equiv_O_O__Z_NoInit(tmp273, tmp274.Invoke_O__O(tmp275)); if and__1927000168__auto____36 { var or__1927000174__auto____37 any; var root_2714 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2714, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2716 lang.IFn; if linked_2715 == nil { ifn_2716 = lang.IFn_Cast(root_2714) } else { ifn_2716 = nil }; var arg_2717 any; var root_2718 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2718, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2720 lang.IFn; if linked_2719 == nil { ifn_2720 = lang.IFn_Cast(root_2718) } else { ifn_2720 = nil }; var arg_2721 any; var tmp276 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp277 any; var root_2723 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = d__35_3; if linked_2724 == nil { tmp277 = ifn_2725.Invoke_O__O(arg_2726) } else { tmp277 = linked_2724.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2723, arg_2726) }; arg_2721 = tmp276.Invoke_O__O(tmp277); var arg_2722 any = A_arbace_go_check_A_const_255; if linked_2719 == nil { arg_2717 = ifn_2720.Invoke_O_O__O(arg_2721, arg_2722) } else { arg_2717 = linked_2719.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2718, arg_2721, arg_2722) }; if linked_2715 == nil { or__1927000174__auto____37 = ifn_2716.Invoke_O__O(arg_2717) } else { or__1927000174__auto____37 = linked_2715.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2714, arg_2717) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp272 = or__1927000174__auto____37 } else { var root_2727 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2727, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2729 lang.IFn; if linked_2728 == nil { ifn_2729 = lang.IFn_Cast(root_2727) } else { ifn_2729 = nil }; var arg_2730 any; var root_2731 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2731, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2733 lang.IFn; if linked_2732 == nil { ifn_2733 = lang.IFn_Cast(root_2731) } else { ifn_2733 = nil }; var arg_2734 any; var tmp278 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp279 any; var root_2736 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2736, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; var arg_2739 any = d__35_3; if linked_2737 == nil { tmp279 = ifn_2738.Invoke_O__O(arg_2739) } else { tmp279 = linked_2737.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2736, arg_2739) }; arg_2734 = tmp278.Invoke_O__O(tmp279); var arg_2735 any = A_arbace_go_check_A_const_256; if linked_2732 == nil { arg_2730 = ifn_2733.Invoke_O_O__O(arg_2734, arg_2735) } else { arg_2730 = linked_2732.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2731, arg_2734, arg_2735) }; if linked_2728 == nil { tmp272 = ifn_2729.Invoke_O__O(arg_2730) } else { tmp272 = linked_2728.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2727, arg_2730) } } } else { tmp272 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____36).Ref() }; if jrt.J2g_Truth(tmp272) {
										jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) } else {
											jrt.NN(lang.Volatile_Cast(d__35_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__35_3)).Deref__O(), A_arbace_go_check_A_const_215, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) }
//line :323:1
									seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000298__34); continue L23 } else { var temp__1927000414__auto____35_3 any; var root_2497 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2499 lang.IFn; if linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any = seq_1685000295__31; if linked_2498 == nil { temp__1927000414__auto____35_3 = ifn_2499.Invoke_O__O(arg_2500) } else { temp__1927000414__auto____35_3 = linked_2498.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2497, arg_2500) }; if jrt.J2g_Truth(temp__1927000414__auto____35_3) { var seq_1685000295__36 any = temp__1927000414__auto____35_3; var tmp280 any; var root_2501 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2503 lang.IFn; if linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any = seq_1685000295__36; if linked_2502 == nil { tmp280 = ifn_2503.Invoke_O__O(arg_2504) } else { tmp280 = linked_2502.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2501, arg_2504) }; if jrt.J2g_Truth(tmp280) { var c__1927000678__auto____37_3 any; var root_2505 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2505, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2507 lang.IFn; if linked_2506 == nil { ifn_2507 = lang.IFn_Cast(root_2505) } else { ifn_2507 = nil }; var arg_2508 any = seq_1685000295__36; if linked_2506 == nil { c__1927000678__auto____37_3 = ifn_2507.Invoke_O__O(arg_2508) } else { c__1927000678__auto____37_3 = linked_2506.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2505, arg_2508) }; var tmp281 any; var root_2755 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2755, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2757 lang.IFn; if linked_2756 == nil { ifn_2757 = lang.IFn_Cast(root_2755) } else { ifn_2757 = nil }; var arg_2758 any = seq_1685000295__36; if linked_2756 == nil { tmp281 = ifn_2757.Invoke_O__O(arg_2758) } else { tmp281 = linked_2756.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2755, arg_2758) }; seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = tmp281, c__1927000678__auto____37_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____37_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L23 } else { var d__37_3 any; var root_2509 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2511 lang.IFn; if linked_2510 == nil { ifn_2511 = lang.IFn_Cast(root_2509) } else { ifn_2511 = nil }; var arg_2512 any = seq_1685000295__36; if linked_2510 == nil { d__37_3 = ifn_2511.Invoke_O__O(arg_2512) } else { d__37_3 = linked_2510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2509, arg_2512) }
										var tmp282 any; var and__1927000168__auto____38 bool; var tmp283 any = A_arbace_go_check_A_const_254; var tmp284 *lang.Keyword = A_arbace_go_check_A_const_94; var tmp285 any; var root_2759 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2759, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2761 lang.IFn; if linked_2760 == nil { ifn_2761 = lang.IFn_Cast(root_2759) } else { ifn_2761 = nil }; var arg_2762 any = d__37_3; if linked_2760 == nil { tmp285 = ifn_2761.Invoke_O__O(arg_2762) } else { tmp285 = linked_2760.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2759, arg_2762) }; and__1927000168__auto____38 = lang.Util_Equiv_O_O__Z_NoInit(tmp283, tmp284.Invoke_O__O(tmp285)); if and__1927000168__auto____38 { var or__1927000174__auto____39 any; var root_2763 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2763, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2765 lang.IFn; if linked_2764 == nil { ifn_2765 = lang.IFn_Cast(root_2763) } else { ifn_2765 = nil }; var arg_2766 any; var root_2767 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2767, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2769 lang.IFn; if linked_2768 == nil { ifn_2769 = lang.IFn_Cast(root_2767) } else { ifn_2769 = nil }; var arg_2770 any; var tmp286 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp287 any; var root_2772 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2774 lang.IFn; if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = d__37_3; if linked_2773 == nil { tmp287 = ifn_2774.Invoke_O__O(arg_2775) } else { tmp287 = linked_2773.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2772, arg_2775) }; arg_2770 = tmp286.Invoke_O__O(tmp287); var arg_2771 any = A_arbace_go_check_A_const_255; if linked_2768 == nil { arg_2766 = ifn_2769.Invoke_O_O__O(arg_2770, arg_2771) } else { arg_2766 = linked_2768.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2767, arg_2770, arg_2771) }; if linked_2764 == nil { or__1927000174__auto____39 = ifn_2765.Invoke_O__O(arg_2766) } else { or__1927000174__auto____39 = linked_2764.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2763, arg_2766) }; if jrt.J2g_Truth(or__1927000174__auto____39) { tmp282 = or__1927000174__auto____39 } else { var root_2776 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any; var root_2780 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any; var tmp288 *lang.Keyword = A_arbace_go_check_A_const_223; var tmp289 any; var root_2785 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any = d__37_3; if linked_2786 == nil { tmp289 = ifn_2787.Invoke_O__O(arg_2788) } else { tmp289 = linked_2786.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2785, arg_2788) }; arg_2783 = tmp288.Invoke_O__O(tmp289); var arg_2784 any = A_arbace_go_check_A_const_256; if linked_2781 == nil { arg_2779 = ifn_2782.Invoke_O_O__O(arg_2783, arg_2784) } else { arg_2779 = linked_2781.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2780, arg_2783, arg_2784) }; if linked_2777 == nil { tmp282 = ifn_2778.Invoke_O__O(arg_2779) } else { tmp282 = linked_2777.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2776, arg_2779) } } } else { tmp282 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____38).Ref() }; if jrt.J2g_Truth(tmp282) {
											jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) } else {
												jrt.NN(lang.Volatile_Cast(d__37_3)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_257.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__37_3)).Deref__O(), A_arbace_go_check_A_const_215, A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259, A_arbace_go_check_A_const_260)) }
//line :323:1
										var tmp290 any; var root_2804 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2804, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2806 lang.IFn; if linked_2805 == nil { ifn_2806 = lang.IFn_Cast(root_2804) } else { ifn_2806 = nil }; var arg_2807 any = seq_1685000295__36; if linked_2805 == nil { tmp290 = ifn_2806.Invoke_O__O(arg_2807) } else { tmp290 = linked_2805.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2804, arg_2807) }; seq_1685000295__31, chunk_1685000296__32, count_1685000297__33, i_1685000298__34 = tmp290, nil, 0, 0; continue L23 } } }
//line :317:1
								break L23
							}
						}
					}






			var tmp291 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp292 any; var root_2513 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2514 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2513, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2515 lang.IFn; if linked_2514 == nil { ifn_2515 = lang.IFn_Cast(root_2513) } else { ifn_2515 = nil }; var arg_2516 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2517 any = A_arbace_go_check_A_const_237; var arg_2518 any; var tmp293 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_106.GetRawRoot__O()); var tmp294 any = A_arbace_go_check_A_const_111; var tmp295 any = A_arbace_go_check_A_const_111.Invoke_O__O(src__0); var tmp296 any = A_arbace_go_check_A_const_238; var tmp297 any; var root_2519 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2521 lang.IFn


			if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any; var root_2523 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any; var root_2528 any = A_arbace_go_check_A_const_240.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = A_arbace_go_check_A_const_74; var arg_2532 any = A_arbace_go_check_A_const_79; if linked_2529 == nil { arg_2526 = ifn_2530.Invoke_O_O__O(arg_2531, arg_2532) } else { arg_2526 = linked_2529.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2528, arg_2531, arg_2532) }; var arg_2527 any = counted__28; if linked_2524 == nil { arg_2522 = ifn_2525.Invoke_O_O__O(arg_2526, arg_2527) } else { arg_2522 = linked_2524.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2523, arg_2526, arg_2527) }; if linked_2520 == nil { tmp297 = ifn_2521.Invoke_O__O(arg_2522) } else { tmp297 = linked_2520.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2519, arg_2522) }
//line :328:1
			var tmp298 any = tmp297; var tmp299 any = A_arbace_go_check_A_const_241; var tmp300 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__27)), int64(lang.RT_Count_O__I_NoInit(counted__28)))).Ref(); var tmp301 any = A_arbace_go_check_A_const_242; var tmp302 any = A_arbace_go_check_A_const_243; var tmp303 any




			if jrt.J2g_Truth(keep_trees__6) { var root_2533 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2533, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2535 lang.IFn; if linked_2534 == nil { ifn_2535 = lang.IFn_Cast(root_2533) } else { ifn_2535 = nil }; var arg_2536 any; var root_2537 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_2538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2537, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2539 lang.IFn; if linked_2538 == nil { ifn_2539 = lang.IFn_Cast(root_2537) } else { ifn_2539 = nil }; var arg_2540 any; var fnbody__2547 any = A_arbace_go_check_check_package_fn__1685000299_A_New(); var tmp304 *jrt.Class; var fncls__2546 *jrt.Class = A_arbace_go_check_check_package_fn__1685000299_A_fn_class; if fncls__2546 == nil { var fncls__2546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_go_check_check_package_fn__1685000299_A_fn_class = fncls__2546d; tmp304 = fncls__2546d } else { tmp304 = fncls__2546 }; arg_2540 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2547, tmp304, nil); var arg_2541 any = decls__17; if linked_2538 == nil { arg_2536 = ifn_2539.Invoke_O_O__O(arg_2540, arg_2541) } else { arg_2536 = linked_2538.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2537, arg_2540, arg_2541) }; if linked_2534 == nil { tmp303 = ifn_2535.Invoke_O__O(arg_2536) } else { tmp303 = linked_2534.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2533, arg_2536) } } else { tmp303 = nil }
//line :328:1
			var tmp305 any = tmp303; var tmp306 any = A_arbace_go_check_A_const_244; var tmp307 any







			if jrt.J2g_Truth(keep_trees__6) {
				var root_2548 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any; var iter__1927001039__auto____31 any; var fnbody__2631 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_A_New(); var tmp308 *jrt.Class; var fncls__2630 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class; if fncls__2630 == nil { var fncls__2630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class = fncls__2630d; tmp308 = fncls__2630d } else { tmp308 = fncls__2630 }; iter__1927001039__auto____31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2631, tmp308, nil); arg_2551 = lang.IFn_Cast(iter__1927001039__auto____31).Invoke_O__O(decls__17); if linked_2549 == nil { tmp307 = ifn_2550.Invoke_O__O(arg_2551) } else { tmp307 = linked_2549.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2548, arg_2551) } } else {
//line :336:1
					tmp307 = nil }
//line :328:1
			var tmp309 any = tmp307; var tmp310 any = A_arbace_go_check_A_const_248; var tmp311 any











			if jrt.J2g_Truth(keep_trees__6) { tmp311 = order__18 } else { tmp311 = nil }
//line :328:1
			var tmp312 any = tmp311; var tmp313 any = A_arbace_go_check_A_const_249; var tmp314 any













			if jrt.J2g_Truth(resolving__10) {
				var root_2632 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any; var fnbody__2669 any = A_arbace_go_check_check_package_fn__1685000311_A_New(); var tmp315 *jrt.Class; var fncls__2668 *jrt.Class = A_arbace_go_check_check_package_fn__1685000311_A_fn_class; if fncls__2668 == nil { var fncls__2668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_go_check_check_package_fn__1685000311_A_fn_class = fncls__2668d; tmp315 = fncls__2668d } else { tmp315 = fncls__2668 }; arg_2635 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2669, tmp315, nil); var arg_2636 any = order__18; if linked_2633 == nil { tmp314 = ifn_2634.Invoke_O_O__O(arg_2635, arg_2636) } else { tmp314 = linked_2633.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2632, arg_2635, arg_2636) } } else {
//line :342:1
					tmp314 = nil }
//line :328:1
			var tmp316 any = tmp314; var tmp317 any = A_arbace_go_check_A_const_72; var tmp318 any
















			if jrt.J2g_Truth(keep_trees__6) { tmp318 = pkg_scope__7 } else { tmp318 = nil }
//line :328:1
			var tmp319 any = tmp318; var tmp320 any = A_arbace_go_check_A_const_120; var tmp321 any

















			if jrt.J2g_Truth(keep_trees__6) { var root_2670 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = A_arbace_go_check_A_const_120.Invoke_O__O(ctx__12); if linked_2671 == nil { tmp321 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp321 = linked_2671.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2670, arg_2673) } } else { tmp321 = nil }
//line :328:1
			arg_2518 = tmp293.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, stats__30, tmp294, tmp295, tmp296, tmp298, tmp299, tmp300, tmp301, init_result__25, tmp302, tmp305, tmp306, tmp309, tmp310, tmp312, tmp313, tmp316, tmp317, tmp319, tmp320, tmp321))))
//line :327:1
			if linked_2514 == nil { tmp292 = ifn_2515.Invoke_O_O_O__O(arg_2516, arg_2517, arg_2518) } else { tmp292 = linked_2514.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2513, arg_2516, arg_2517, arg_2518) }; jrt.NN(tmp291).Reset_O__O(tmp292)
//line :161:1
			tmp69 = pkg__8 }; return nil }(); var root_1318 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1320 lang.IFn; if















	linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; if linked_1319 == nil { ifn_1320.Invoke__O() } else { linked_1319.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1318) }; if /*line :161:1*/ tmp322 != nil { panic(tmp322) }; return tmp69 }














func A_arbace_go_check_check_package_fn__1685000129_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000129_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :176:1
func (t *A_arbace_go_check_check_package_fn__1685000129_A) Invoke_O_O__O(self, p1__1685000111_SHARP___1 any) any { var root_834 any = A_arbace_go_check_A_const_124.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, A_arbace_go_check_file_info_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = t.F_pkg_scope; var arg_838 any = p1__1685000111_SHARP___1; var arg_839 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_src); if linked_835 == nil { return ifn_836.Invoke_O_O_O__O(arg_837, arg_838, arg_839) } else { return linked_835.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_834, arg_837, arg_838, arg_839) } }













func A_arbace_go_check_check_package_fn__1685000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000131_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Ctor_O_O_O(c__src, c__pkg, c__resolve any) { t.F_src = c__src; t.F_pkg = c__pkg; t.F_resolve = c__resolve }
//line :190:1
func (t *A_arbace_go_check_check_package_fn__1685000131_A) Invoke_O_O__O(self, q__1 any) any { var tmp1 any; var root_1325 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src); if linked_1326 == nil { tmp1 = ifn_1327.Invoke_O__O(arg_1328) } else { tmp1 = linked_1326.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_1325, arg_1328) }; if lang.Util_Equiv_O_O__Z_NoInit(q__1, tmp1) { return t.F_pkg } else { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												tmp2 = lang.IFn_Cast(t.F_resolve).Invoke_O__O(q__1)
//line :190:1
	return nil }(); if tmp3 != nil { if lang.ArityException_InstanceOf(tmp3) { var ___4 *lang.ArityException = lang.ArityException_Cast(tmp3); _ = ___4; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } }
































func A_arbace_go_check_check_package_fn__1685000179_A_New() *A_arbace_go_check_check_package_fn__1685000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000179_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Invoke_O_O__O(self, p1__1685000112_SHARP___1 any) any { var root_855 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = p1__1685000112_SHARP___1; var arg_859 any = A_arbace_go_check_A_const_128; if linked_856 == nil { return ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { return linked_856.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) } }





func A_arbace_go_check_check_package_fn__1685000186_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000186_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000186_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000187__5 any; var root_1967 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1969 lang.IFn
											if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1970 = t_; if linked_1968 == nil { seq_1685000187__5 = ifn_1969.Invoke_O__O(arg_1970) } else { seq_1685000187__5 = linked_1968.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1967, arg_1970) }
//line :229:1
	var chunk_1685000188__6 any; var count_1685000189__7 int64 = 0; var i_1685000190__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000190__8, count_1685000189__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000188__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000190__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000190__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1971 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = seq_1685000187__5; if linked_1972 == nil { temp__1927000414__auto____9 = ifn_1973.Invoke_O__O(arg_1974) } else { temp__1927000414__auto____9 = linked_1972.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1971, arg_1974) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000187__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1975 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = seq_1685000187__10; if linked_1976 == nil { tmp2 = ifn_1977.Invoke_O__O(arg_1978) } else { tmp2 = linked_1976.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1975, arg_1978) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1979 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = seq_1685000187__10; if linked_1980 == nil { c__1927000678__auto____11 = ifn_1981.Invoke_O__O(arg_1982) } else { c__1927000678__auto____11 = linked_1980.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1979, arg_1982) }; var tmp3 any; var root_1990 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = seq_1685000187__10; if linked_1991 == nil { tmp3 = ifn_1992.Invoke_O__O(arg_1993) } else { tmp3 = linked_1991.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1990, arg_1993) }; seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1983 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = seq_1685000187__10; if linked_1984 == nil { l__11 = ifn_1985.Invoke_O__O(arg_1986) } else { l__11 = linked_1984.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1983, arg_1986) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1994 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = seq_1685000187__10; if linked_1995 == nil { tmp4 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp4 = linked_1995.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1994, arg_1997) }; seq_1685000187__5, chunk_1685000188__6, count_1685000189__7, i_1685000190__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1998 any = A_arbace_go_check_A_const_217.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2000 lang.IFn

			if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = ex__5; if linked_1999 == nil { tmp6 = ifn_2000.Invoke_O__O(arg_2001) } else { tmp6 = linked_1999.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1998, arg_2001) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2002 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2005 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2006 any = A_arbace_go_check_A_const_145; var arg_2007 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp11 any; var root_2008 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = ex__5; if linked_2009 == nil { tmp11 = ifn_2010.Invoke_O__O(arg_2011) } else { tmp11 = linked_2009.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2008, arg_2011) }; arg_2007 = tmp10.Invoke_O__O(tmp11); if linked_2003 == nil { tmp8 = ifn_2004.Invoke_O_O_O__O(arg_2005, arg_2006, arg_2007) } else { tmp8 = linked_2003.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2002, arg_2005, arg_2006, arg_2007) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_1987 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; if linked_1988 == nil { ifn_1989.Invoke__O() } else { linked_1988.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1987) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :229:1
func A_arbace_go_check_check_package_fn__1685000193_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000193_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000193_A{}; t.Ctor_O_O(p0, p1); return t }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :229:1
func (t *A_arbace_go_check_check_package_fn__1685000193_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000194__5 any; var root_2058 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2060 lang.IFn
											if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any; var t_ any = t.F_ls; t.F_ls = nil; arg_2061 = t_; if linked_2059 == nil { seq_1685000194__5 = ifn_2060.Invoke_O__O(arg_2061) } else { seq_1685000194__5 = linked_2059.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2058, arg_2061) }
//line :229:1
	var chunk_1685000195__6 any; var count_1685000196__7 int64 = 0; var i_1685000197__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000197__8, count_1685000196__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000195__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000197__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000197__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_2062 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = seq_1685000194__5; if linked_2063 == nil { temp__1927000414__auto____9 = ifn_2064.Invoke_O__O(arg_2065) } else { temp__1927000414__auto____9 = linked_2063.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2062, arg_2065) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000194__10 any = temp__1927000414__auto____9; var tmp2 any; var root_2066 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = seq_1685000194__10; if linked_2067 == nil { tmp2 = ifn_2068.Invoke_O__O(arg_2069) } else { tmp2 = linked_2067.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2066, arg_2069) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_2070 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = seq_1685000194__10; if linked_2071 == nil { c__1927000678__auto____11 = ifn_2072.Invoke_O__O(arg_2073) } else { c__1927000678__auto____11 = linked_2071.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2070, arg_2073) }; var tmp3 any; var root_2081 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = seq_1685000194__10; if linked_2082 == nil { tmp3 = ifn_2083.Invoke_O__O(arg_2084) } else { tmp3 = linked_2082.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2081, arg_2084) }; seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_2074 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = seq_1685000194__10; if linked_2075 == nil { l__11 = ifn_2076.Invoke_O__O(arg_2077) } else { l__11 = linked_2075.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2074, arg_2077) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_2085 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = seq_1685000194__10; if linked_2086 == nil { tmp4 = ifn_2087.Invoke_O__O(arg_2088) } else { tmp4 = linked_2086.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2085, arg_2088) }; seq_1685000194__5, chunk_1685000195__6, count_1685000196__7, i_1685000197__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :229:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_2089 any = A_arbace_go_check_A_const_217.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_2091 lang.IFn

			if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = ex__5; if linked_2090 == nil { tmp6 = ifn_2091.Invoke_O__O(arg_2092) } else { tmp6 = linked_2090.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_2089, arg_2092) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_2093 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2094 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2093, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2095 lang.IFn; if linked_2094 == nil { ifn_2095 = lang.IFn_Cast(root_2093) } else { ifn_2095 = nil }; var arg_2096 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_2096 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_2097 any = A_arbace_go_check_A_const_145; var arg_2098 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_218; var tmp11 any; var root_2099 any = A_arbace_go_check_A_const_219.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = ex__5; if linked_2100 == nil { tmp11 = ifn_2101.Invoke_O__O(arg_2102) } else { tmp11 = linked_2100.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2099, arg_2102) }; arg_2098 = tmp10.Invoke_O__O(tmp11); if linked_2094 == nil { tmp8 = ifn_2095.Invoke_O_O_O__O(arg_2096, arg_2097, arg_2098) } else { tmp8 = linked_2094.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2093, arg_2096, arg_2097, arg_2098) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :229:1
				panic(tmp5) } } }; return nil }(); var root_2078 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; if linked_2079 == nil { ifn_2080.Invoke__O() } else { linked_2079.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2078) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000203_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000203_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000203_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000203_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000203_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2135 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp3 any; var root_2139 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any; var t_ any = t.F_d; t.F_d = nil; arg_2142 = t_; if linked_2140 == nil { tmp3 = ifn_2141.Invoke_O__O(arg_2142) } else { tmp3 = linked_2140.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2139, arg_2142) }; arg_2138 = tmp2.Invoke_O__O(tmp3); if linked_2136 == nil { tmp1 = ifn_2137.Invoke_O__O(arg_2138) } else { tmp1 = linked_2136.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2135, arg_2138) } }
//line :235:1
	return nil }(); var root_2143 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; if linked_2144 == nil { ifn_2145.Invoke__O() } else { linked_2144.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2143) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :235:1
func A_arbace_go_check_check_package_fn__1685000205_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000205_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000205_A{}; t.Ctor_O(p0); return t }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000205_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :235:1
func (t *A_arbace_go_check_check_package_fn__1685000205_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_2167 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp3 any; var root_2171 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var t_ any = t.F_d; t.F_d = nil; arg_2174 = t_; if linked_2172 == nil { tmp3 = ifn_2173.Invoke_O__O(arg_2174) } else { tmp3 = linked_2172.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2171, arg_2174) }; arg_2170 = tmp2.Invoke_O__O(tmp3); if linked_2168 == nil { tmp1 = ifn_2169.Invoke_O__O(arg_2170) } else { tmp1 = linked_2168.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_2167, arg_2170) } }
//line :235:1
	return nil }(); var root_2175 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; if linked_2176 == nil { ifn_2177.Invoke__O() } else { linked_2176.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2175) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }





















func A_arbace_go_check_check_package_init_entry__1685000231_A_New() *A_arbace_go_check_check_package_init_entry__1685000231_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000231_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var fnbody__918 any = A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_New(); var tmp1 *jrt.Class; var fncls__917 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class; if
													fncls__917 == nil { var fncls__917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class = fncls__917d; tmp1 = fncls__917d } else { tmp1 = fncls__917 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__918, tmp1, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp2 lang.IFn = lang.IFn_Cast(one__2); var tmp3 any; var root_930 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = lhs__1; if linked_931 == nil { tmp3 = ifn_932.Invoke_O__O(arg_933) } else { tmp3 = linked_931.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_930, arg_933) }; return tmp2.Invoke_O__O(tmp3) } else { var root_919 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var arg_923 any = A_arbace_go_check_A_const_137; var arg_924 any; var root_925 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = one__2; var arg_929 any = lhs__1; if linked_926 == nil { arg_924 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { arg_924 = linked_926.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }; if linked_920 == nil { return ifn_921.Invoke_O_O_O__O(arg_922, arg_923, arg_924) } else { return linked_920.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_919, arg_922, arg_923, arg_924) } } }
//line :258:1
func A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_New() *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_893 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = v__1; var arg_897 any = A_arbace_go_check_A_const_71; if linked_894 == nil { tmp1 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { tmp1 = linked_894.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_57, tmp1) { var tmp2 any; var root_907 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = v__1; var arg_911 any = A_arbace_go_check_A_const_74; if linked_908 == nil { tmp2 = ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { tmp2 = linked_908.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_907, arg_910, arg_911) }; var tmp3 any = tmp2; var tmp4 any; var root_912 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = v__1; var arg_916 any = A_arbace_go_check_A_const_79; if linked_913 == nil { tmp4 = ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { tmp4 = linked_913.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_912, arg_915, arg_916) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_898 any = A_arbace_go_check_A_const_134.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any; var root_902 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = v__1; var arg_906 any = A_arbace_go_check_A_const_71; if linked_903 == nil { arg_901 = ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { arg_901 = linked_903.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }; if linked_899 == nil { return ifn_900.Invoke_O__O(arg_901) } else { return linked_899.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_898, arg_901) } } }



func A_arbace_go_check_check_package_norm__1685000235_A_New() *A_arbace_go_check_check_package_norm__1685000235_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000235_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1685000235_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_check_package_norm__1685000235_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_941 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_943 lang.IFn; if
												linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = x__1; if linked_942 == nil { tmp1 = ifn_943.Invoke_O__O(arg_944) } else { tmp1 = linked_942.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_941, arg_944) }; if /*line :262:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_945 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_947 lang.IFn

		if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = x__1; if linked_946 == nil { tmp2 = ifn_947.Invoke_O__O(arg_948) } else { tmp2 = linked_946.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_945, arg_948) }
//line :262:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_91, tmp2) {


			var root_949 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var arg_953 any = A_arbace_go_check_A_const_138; var arg_954 any; var root_955 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any; var fnbody__965 any = A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_New(); var tmp3 *jrt.Class; var fncls__964 *jrt.Class = A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class; if fncls__964 == nil { var fncls__964d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class = fncls__964d; tmp3 = fncls__964d } else { tmp3 = fncls__964 }; arg_958 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__965, tmp3, nil); var arg_959 any; var root_966 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = x__1; if linked_967 == nil { arg_959 = ifn_968.Invoke_O__O(arg_969) } else { arg_959 = linked_967.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_966, arg_969) }; if linked_956 == nil { arg_954 = ifn_957.Invoke_O_O__O(arg_958, arg_959) } else { arg_954 = linked_956.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_955, arg_958, arg_959) }; if linked_950 == nil { return ifn_951.Invoke_O_O_O__O(arg_952, arg_953, arg_954) } else { return linked_950.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_949, arg_952, arg_953, arg_954) } } else {
//line :262:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_New() *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A) Ctor() {}
//line :265:1
func (t *A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A) Invoke_O_O__O(self, p1__1685000113_SHARP___1 any) any { var tmp1 any; var root_960 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = p1__1685000113_SHARP___1; if linked_961 == nil { tmp1 = ifn_962.Invoke_O__O(arg_963) } else { tmp1 = linked_961.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_960, arg_963) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000113_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000113_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000239_A_New() *A_arbace_go_check_check_package_fn__1685000239_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000239_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_go_check_check_package_fn__1685000239_A) Ctor() {}
//line :276:1
func (t *A_arbace_go_check_check_package_fn__1685000239_A) Invoke_O_O__O(self, p1__1685000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp2 any; var root_990 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = p1__1685000114_SHARP___1; if linked_991 == nil { tmp2 = ifn_992.Invoke_O__O(arg_993) } else { tmp2 = linked_991.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_990, arg_993) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_146; var tmp4 any; var root_994 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = p1__1685000114_SHARP___1; if linked_995 == nil { tmp4 = ifn_996.Invoke_O__O(arg_997) } else { tmp4 = linked_995.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_994, arg_997) }; return tmp3.Invoke_O__O(tmp4) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000241_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000241_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000241_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_go_check_check_package_fn__1685000241_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :278:1
func (t *A_arbace_go_check_check_package_fn__1685000241_A) Invoke_O_O__O(self, p1__1685000115_SHARP___1 any) any { var root_1009 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = t.F_generic_ids; var arg_1013 any = A_arbace_go_check_A_const_128.Invoke_O__O(p1__1685000115_SHARP___1); if linked_1010 == nil { return ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { return linked_1010.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) } }







func A_arbace_go_check_check_package_fn__1685000247_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000247_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000247_A{}; t.Ctor_O(p0); return t }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000247_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :286:1
func (t *A_arbace_go_check_check_package_fn__1685000247_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.IdentityHashMap_Cast(t.F_m).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000250_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000250_A) Ctor_O(c__resolving any) { t.F_resolving = c__resolving }
//line :288:1
func (t *A_arbace_go_check_check_package_fn__1685000250_A) Invoke_O_O_O__O(self, acc__1, p__1685000249__2 any) any { var vec__1685000251__3 any = p__1685000249__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000251__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000251__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_1029 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1031 lang.IFn; if
															linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any; var fnbody__1039 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_New(); var tmp1 *jrt.Class; var fncls__1038 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class; if fncls__1038 == nil { var fncls__1038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class = fncls__1038d; tmp1 = fncls__1038d } else { tmp1 = fncls__1038 }; arg_1032 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1039, tmp1, nil); var arg_1033 any = ds__5; if linked_1030 == nil { gen__6 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { gen__6 = linked_1030.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) }; var uses_generics__7 any; var root_1040 any = /*line :288:1*/A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1042 lang.IFn; if

	linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any; var fnbody__1050 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_New(); var tmp2 *jrt.Class; var fncls__1049 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class; if fncls__1049 == nil { var fncls__1049d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class = fncls__1049d; tmp2 = fncls__1049d } else { tmp2 = fncls__1049 }; arg_1043 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1050, tmp2, nil); var arg_1044 any = ds__5; if linked_1041 == nil { uses_generics__7 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { uses_generics__7 = linked_1041.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) }; var present__8 any; if
	jrt.J2g_Truth(t.F_resolving) { present__8 = lang.PersistentArrayMap_EMPTY.Ref() } else { var root_1051 any = A_arbace_go_check_A_const_151.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, A_arbace_go_check_annotations_present_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = form__4; if linked_1052 == nil { present__8 = ifn_1053.Invoke_O__O(arg_1054) } else { present__8 = linked_1052.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_1051, arg_1054) } }; var verified__9 any; var root_1055 any = /*line :288:1*/A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1057 lang.IFn; if



	linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var arg_1059 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1060 any; var root_1061 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var fnbody__1071 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_New(); var tmp3 *jrt.Class; var fncls__1070 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class; if fncls__1070 == nil { var fncls__1070d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class = fncls__1070d; tmp3 = fncls__1070d } else { tmp3 = fncls__1070 }; arg_1064 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1071, tmp3, nil); var arg_1065 any = ds__5; if linked_1062 == nil { arg_1060 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { arg_1060 = linked_1062.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }; if linked_1056 == nil { verified__9 = ifn_1057.Invoke_O_O_O__O(arg_1058, arg_1059, arg_1060) } else { verified__9 = linked_1056.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1055, arg_1058, arg_1059, arg_1060) }; var acc__10 any; if
	jrt.J2g_Truth(uses_generics__7) {
		var root_1072 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any; var root_1079 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = acc__1; var arg_1083 any = A_arbace_go_check_A_const_153; var arg_1084 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); if linked_1080 == nil { arg_1075 = ifn_1081.Invoke_O_O_O__O(arg_1082, arg_1083, arg_1084) } else { arg_1075 = linked_1080.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1079, arg_1082, arg_1083, arg_1084) }; var arg_1076 any = A_arbace_go_check_A_const_155; var arg_1077 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1078 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1073 == nil { acc__10 = ifn_1074.Invoke_O_O_O_O__O(arg_1075, arg_1076, arg_1077, arg_1078) } else { acc__10 = linked_1073.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1072, arg_1075, arg_1076, arg_1077, arg_1078) } } else {
//line :293:1
			acc__10 = acc__1 }; if


	jrt.J2g_Truth(gen__6) {



		var root_1085 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var root_1091 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1093 lang.IFn
//line :299:1
		if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var root_1097 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1099 lang.IFn
//line :298:1
		if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = acc__10; var arg_1101 any = A_arbace_go_check_A_const_156; var arg_1102 any; var root_1103 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var arg_1107 any = A_arbace_go_check_A_const_22; if linked_1104 == nil { arg_1102 = ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { arg_1102 = linked_1104.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) }; if linked_1098 == nil { arg_1094 = ifn_1099.Invoke_O_O_O__O(arg_1100, arg_1101, arg_1102) } else { arg_1094 = linked_1098.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1097, arg_1100, arg_1101, arg_1102) }
		var arg_1095 any = A_arbace_go_check_A_const_157; var arg_1096 any; var fnbody__1115 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_New_O(present__8); var tmp4 *jrt.Class; var fncls__1114 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class; if fncls__1114 == nil { var fncls__1114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1115); A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class = fncls__1114d; tmp4 = fncls__1114d } else { tmp4 = fncls__1114 }; arg_1096 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1115, tmp4, nil); if linked_1092 == nil { arg_1088 = ifn_1093.Invoke_O_O_O__O(arg_1094, arg_1095, arg_1096) } else { arg_1088 = linked_1092.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1091, arg_1094, arg_1095, arg_1096) }
		var arg_1089 any = A_arbace_go_check_A_const_145; var arg_1090 any; var fnbody__1140 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_New_O(ds__5); var tmp5 *jrt.Class; var fncls__1139 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class; if fncls__1139 == nil { var fncls__1139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1140); A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class = fncls__1139d; tmp5 = fncls__1139d } else { tmp5 = fncls__1139 }; arg_1090 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1140, tmp5, nil); if linked_1086 == nil { return ifn_1087.Invoke_O_O_O__O(arg_1088, arg_1089, arg_1090) } else { return linked_1086.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1085, arg_1088, arg_1089, arg_1090) } } else {
//line :296:1
			var unver__11 any; var root_1141 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1143 lang.IFn




			if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1145 any; var iter__1927001039__auto____11 any; var fnbody__1231 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_New_O(verified__9); var tmp6 *jrt.Class; var fncls__1230 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class; if fncls__1230 == nil { var fncls__1230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1231); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class = fncls__1230d; tmp6 = fncls__1230d } else { tmp6 = fncls__1230 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1231, tmp6, nil); arg_1145 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(present__8); if linked_1142 == nil { unver__11 = ifn_1143.Invoke_O_O__O(arg_1144, arg_1145) } else { unver__11 = linked_1142.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1141, arg_1144, arg_1145)
			}








			var root_1232 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var root_1238 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1240 lang.IFn
//line :310:1
			if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any; var root_1244 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1246 lang.IFn
//line :309:1
			if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any; var root_1250 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1252 lang.IFn
//line :308:1
			if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any; var root_1256 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1258 lang.IFn
//line :307:1
			if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var root_1263 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1265 lang.IFn
//line :306:1
			if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = acc__10; var arg_1267 any = A_arbace_go_check_A_const_164; var arg_1268 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); if linked_1264 == nil { arg_1259 = ifn_1265.Invoke_O_O_O__O(arg_1266, arg_1267, arg_1268) } else { arg_1259 = linked_1264.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1263, arg_1266, arg_1267, arg_1268) }
			var arg_1260 any = A_arbace_go_check_A_const_83; var arg_1261 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1262 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1257 == nil { arg_1253 = ifn_1258.Invoke_O_O_O_O__O(arg_1259, arg_1260, arg_1261, arg_1262) } else { arg_1253 = linked_1257.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1256, arg_1259, arg_1260, arg_1261, arg_1262) }
			var arg_1254 any = A_arbace_go_check_A_const_165; var arg_1255 any; var fnbody__1276 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_New_O(present__8); var tmp7 *jrt.Class; var fncls__1275 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class; if fncls__1275 == nil { var fncls__1275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1276); A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class = fncls__1275d; tmp7 = fncls__1275d } else { tmp7 = fncls__1275 }; arg_1255 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1276, tmp7, nil); if linked_1251 == nil { arg_1247 = ifn_1252.Invoke_O_O_O__O(arg_1253, arg_1254, arg_1255) } else { arg_1247 = linked_1251.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1250, arg_1253, arg_1254, arg_1255) }
			var arg_1248 any = A_arbace_go_check_A_const_140; var arg_1249 any; var fnbody__1284 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_New_O(verified__9); var tmp8 *jrt.Class; var fncls__1283 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class; if fncls__1283 == nil { var fncls__1283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1284); A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class = fncls__1283d; tmp8 = fncls__1283d } else { tmp8 = fncls__1283 }; arg_1249 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1284, tmp8, nil); if linked_1245 == nil { arg_1241 = ifn_1246.Invoke_O_O_O__O(arg_1247, arg_1248, arg_1249) } else { arg_1241 = linked_1245.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1244, arg_1247, arg_1248, arg_1249) }
			var arg_1242 any = A_arbace_go_check_A_const_166; var arg_1243 any; var fnbody__1292 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_New_O(unver__11); var tmp9 *jrt.Class; var fncls__1291 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class; if fncls__1291 == nil { var fncls__1291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1292); A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class = fncls__1291d; tmp9 = fncls__1291d } else { tmp9 = fncls__1291 }; arg_1243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1292, tmp9, nil); if linked_1239 == nil { arg_1235 = ifn_1240.Invoke_O_O_O__O(arg_1241, arg_1242, arg_1243) } else { arg_1235 = linked_1239.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1238, arg_1241, arg_1242, arg_1243) }
			var arg_1236 any = A_arbace_go_check_A_const_167; var arg_1237 any; var fnbody__1315 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_New_O_O_O(form__4, ds__5, unver__11); var tmp10 *jrt.Class; var fncls__1314 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class; if fncls__1314 == nil { var fncls__1314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1315); A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class = fncls__1314d; tmp10 = fncls__1314d } else { tmp10 = fncls__1314 }; arg_1237 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1315, tmp10, nil); if linked_1233 == nil { return ifn_1234.Invoke_O_O_O__O(arg_1235, arg_1236, arg_1237) } else { return linked_1233.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1232, arg_1235, arg_1236, arg_1237) } } }
//line :289:1
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A) Ctor() {}
//line :289:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A) Invoke_O_O__O(self, p1__1685000116_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp2 any; var root_1034 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = p1__1685000116_SHARP___1; if linked_1035 == nil { tmp2 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp2 = linked_1035.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1034, arg_1037) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A) Ctor() {}
//line :290:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A) Invoke_O_O__O(self, p1__1685000117_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_150; var tmp2 any; var root_1045 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = p1__1685000117_SHARP___1; if linked_1046 == nil { tmp2 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp2 = linked_1046.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1045, arg_1048) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A) Ctor() {}
//line :292:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A) Invoke_O_O__O(self, p1__1685000118_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_140; var tmp2 any; var root_1066 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = p1__1685000118_SHARP___1; if linked_1067 == nil { tmp2 = ifn_1068.Invoke_O__O(arg_1069) } else { tmp2 = linked_1067.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1066, arg_1069) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :299:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A) Invoke_O_O__O(self, p1__1685000119_SHARP___1 any) any { var root_1108 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1112 any = p1__1685000119_SHARP___1; var arg_1113 any = t.F_present; if linked_1109 == nil { return ifn_1110.Invoke_O_O_O__O(arg_1111, arg_1112, arg_1113) } else { return linked_1109.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1108, arg_1111, arg_1112, arg_1113) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A) Invoke_O_O__O(self, p1__1685000120_SHARP___1 any) any { var root_1116 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any; var fnbody__1138 any = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_New(); var tmp1 *jrt.Class; var fncls__1137 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class; if fncls__1137 == nil { var fncls__1137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class = fncls__1137d; tmp1 = fncls__1137d } else { tmp1 = fncls__1137 }; arg_1119 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1138, tmp1, nil); var arg_1120 any = p1__1685000120_SHARP___1; var arg_1121 any = t.F_ds; if linked_1117 == nil { return ifn_1118.Invoke_O_O_O__O(arg_1119, arg_1120, arg_1121) } else { return linked_1117.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1116, arg_1119, arg_1120, arg_1121) } }
//line :300:1
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_New() *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A) Ctor() {}
//line :300:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_145; var tmp2 any; var root_1122 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = d__2; if linked_1123 == nil { tmp2 = ifn_1124.Invoke_O__O(arg_1125) } else { tmp2 = linked_1123.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1122, arg_1125) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_1126 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = m__1; var arg_1130 any = u__4; var arg_1131 any; var root_1132 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var arg_1136 any = A_arbace_go_check_A_const_22; if linked_1133 == nil { arg_1131 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { arg_1131 = linked_1133.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }; if linked_1127 == nil { return ifn_1128.Invoke_O_O_O__O(arg_1129, arg_1130, arg_1131) } else { return linked_1127.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1126, arg_1129, arg_1130, arg_1131) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A) Invoke_O_O__O(self, s__1685000267__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1229 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_New_O_O_O(s__1685000267__1, self, t.F_verified); var tmp2 *jrt.Class; var fncls__1228 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class; if fncls__1228 == nil { var fncls__1228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__1229); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class = fncls__1228d; tmp2 = fncls__1228d } else { tmp2 = fncls__1228 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1229, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :301:1
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A) Ctor_O_O_O(c__s__1685000267, c__iter__1685000266, c__verified any) { t.F_s__1685000267 = c__s__1685000267; t.F_iter__1685000266 = c__iter__1685000266; t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A) Invoke_O__O(self any) any { { var s__1685000267__1 any; var t_ any = t.F_s__1685000267; t.F_s__1685000267 = nil; s__1685000267__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1146 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = s__1685000267__1; if linked_1147 == nil { temp__1927000414__auto____2 = ifn_1148.Invoke_O__O(arg_1149) } else { temp__1927000414__auto____2 = linked_1147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1146, arg_1149) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000267__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1150 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = s__1685000267__3; if linked_1151 == nil { tmp1 = ifn_1152.Invoke_O__O(arg_1153) } else { tmp1 = linked_1151.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1150, arg_1153) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1154 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = s__1685000267__3; if linked_1155 == nil { c__1927001037__auto____4 = ifn_1156.Invoke_O__O(arg_1157) } else { c__1927001037__auto____4 = linked_1155.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1154, arg_1157) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000269__6 any; var root_1158 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1159 == nil { b__1685000269__6 = ifn_1160.Invoke_O__O(arg_1161) } else { b__1685000269__6 = linked_1159.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1158, arg_1161) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1178 any = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_New_O_I_O_O(b__1685000269__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_verified); var tmp3 *jrt.Class; var fncls__1177 *jrt.Class = A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class; if fncls__1177 == nil { var fncls__1177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1178); A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class = fncls__1177d; tmp3 = fncls__1177d } else { tmp3 = fncls__1177 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1178, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1179 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var root_1184 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = b__1685000269__6; if linked_1185 == nil { arg_1182 = ifn_1186.Invoke_O__O(arg_1187) } else { arg_1182 = linked_1185.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1184, arg_1187) }; var arg_1183 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000266); var tmp5 any; var root_1188 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = s__1685000267__3; if linked_1189 == nil { tmp5 = ifn_1190.Invoke_O__O(arg_1191) } else { tmp5 = linked_1189.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1188, arg_1191) }; arg_1183 = tmp4.Invoke_O__O(tmp5); if linked_1180 == nil { return ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { return linked_1180.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } } else { var root_1192 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var root_1197 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = b__1685000269__6; if linked_1198 == nil { arg_1195 = ifn_1199.Invoke_O__O(arg_1200) } else { arg_1195 = linked_1198.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1197, arg_1200) }; var arg_1196 any; if linked_1193 == nil { return ifn_1194.Invoke_O_O__O(arg_1195, arg_1196) } else { return linked_1193.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1192, arg_1195, arg_1196) } } } else { var vec__1685000277__4 any; var root_1201 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = s__1685000267__3; if linked_1202 == nil { vec__1685000277__4 = ifn_1203.Invoke_O__O(arg_1204) } else { vec__1685000277__4 = linked_1202.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1201, arg_1204) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000277__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000277__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var root_1205 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1207 lang.IFn

	if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = n__6; var arg_1209 any = v__7; if linked_1206 == nil { tmp6 = ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { tmp6 = linked_1206.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) }
//line :301:1
	if jrt.J2g_Truth(tmp6) { var root_1210 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var tmp7 jrt.Number_I; var na_1215 any = n__6; var na_1216 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1215); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1216) }; tmp8 = tmp9; if tmp8 { var n0_1217 int64 = jrt.NN(jrt.Long_Cast(na_1215)).LongValue__J(); var n1_1218 int64 = jrt.NN(jrt.Long_Cast(na_1216)).LongValue__J(); var nr_1219 int64 = n0_1217 - n1_1218; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1218 == -9223372036854775808); if tmp11 { tmp11 = (n0_1217^n1_1218)&(n0_1217^nr_1219) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1219)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1215, na_1216) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1215); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1216) }; tmp12 = tmp13; if tmp12 { var n0_1217_2 float64 = jrt.NN(jrt.Double_Cast(na_1215)).DoubleValue__D(); var n1_1218_2 float64 = jrt.NN(jrt.Double_Cast(na_1216)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1217_2 + -n1_1218_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1215, na_1216) } }
//line :301:1
		arg_1213 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1214 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000266); var tmp15 any; var root_1220 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = s__1685000267__3; if linked_1221 == nil { tmp15 = ifn_1222.Invoke_O__O(arg_1223) } else { tmp15 = linked_1221.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1220, arg_1223) }; arg_1214 = tmp14.Invoke_O__O(tmp15); if linked_1211 == nil { return ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { return linked_1211.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) } } else { var tmp16 any; var root_1224 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = s__1685000267__3; if linked_1225 == nil { tmp16 = ifn_1226.Invoke_O__O(arg_1227) } else { tmp16 = linked_1225.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1224, arg_1227) }; s__1685000267__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :301:1
func A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A) Ctor_O_I_O_O(c__b__1685000269 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__verified any) { t.F_b__1685000269 = c__b__1685000269; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_verified = c__verified }
//line :301:1
func (t *A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A) Invoke_O__O(self any) any { { var i__1685000268__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000268__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000273__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000268__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000273__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var root_1162 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1164 lang.IFn

	if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = n__4; var arg_1166 any = v__5; if linked_1163 == nil { tmp2 = ifn_1164.Invoke_O_O__O(arg_1165, arg_1166) } else { tmp2 = linked_1163.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1162, arg_1165, arg_1166) }
//line :301:1
	if jrt.J2g_Truth(tmp2) { var root_1167 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = t.F_b__1685000269; var arg_1171 any; var tmp3 jrt.Number_I; var na_1172 any = n__4; var na_1173 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1172); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1173) }; tmp4 = tmp5; if tmp4 { var n0_1174 int64 = jrt.NN(jrt.Long_Cast(na_1172)).LongValue__J(); var n1_1175 int64 = jrt.NN(jrt.Long_Cast(na_1173)).LongValue__J(); var nr_1176 int64 = n0_1174 - n1_1175; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1175 == -9223372036854775808); if tmp7 { tmp7 = (n0_1174^n1_1175)&(n0_1174^nr_1176) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1176)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1172, na_1173) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1172); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1173) }; tmp8 = tmp9; if tmp8 { var n0_1174_2 float64 = jrt.NN(jrt.Double_Cast(na_1172)).DoubleValue__D(); var n1_1175_2 float64 = jrt.NN(jrt.Double_Cast(na_1173)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1174_2 + -n1_1175_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1172, na_1173) } }
//line :301:1
		arg_1171 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1168 == nil { ifn_1169.Invoke_O_O__O(arg_1170, arg_1171) } else { linked_1168.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1167, arg_1170, arg_1171) }; i__1685000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000268__1); continue L1 } else { i__1685000268__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000268__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :308:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A) Invoke_O_O__O(self, p1__1685000121_SHARP___1 any) any { var root_1269 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1273 any = p1__1685000121_SHARP___1; var arg_1274 any = t.F_present; if linked_1270 == nil { return ifn_1271.Invoke_O_O_O__O(arg_1272, arg_1273, arg_1274) } else { return linked_1270.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1269, arg_1272, arg_1273, arg_1274) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :309:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A) Invoke_O_O__O(self, p1__1685000122_SHARP___1 any) any { var root_1277 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1281 any = p1__1685000122_SHARP___1; var arg_1282 any = t.F_verified; if linked_1278 == nil { return ifn_1279.Invoke_O_O_O__O(arg_1280, arg_1281, arg_1282) } else { return linked_1278.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1277, arg_1280, arg_1281, arg_1282) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :310:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A) Invoke_O_O__O(self, p1__1685000123_SHARP___1 any) any { var root_1285 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1289 any = p1__1685000123_SHARP___1; var arg_1290 any = t.F_unver; if linked_1286 == nil { return ifn_1287.Invoke_O_O_O__O(arg_1288, arg_1289, arg_1290) } else { return linked_1286.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1285, arg_1288, arg_1289, arg_1290) } }
func A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :311:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A) Ctor_O_O_O(c__form, c__ds, c__unver any) { t.F_form = c__form; t.F_ds = c__ds; t.F_unver = c__unver }
//line :311:1
func (t *A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A) Invoke_O_O__O(self, p1__1685000124_SHARP___1 any) any { var tmp1 any; var root_1293 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = t.F_unver; if linked_1294 == nil { tmp1 = ifn_1295.Invoke_O__O(arg_1296) } else { tmp1 = linked_1294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1293, arg_1296) }; if jrt.J2g_Truth(tmp1) { var root_1297 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = p1__1685000124_SHARP___1; var arg_1301 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_71; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_74; var tmp4 any; var root_1302 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1306 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = t.F_ds; if linked_1307 == nil { arg_1305 = ifn_1308.Invoke_O__O(arg_1309) } else { arg_1305 = linked_1307.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1306, arg_1309) }; if linked_1303 == nil { tmp4 = ifn_1304.Invoke_O__O(arg_1305) } else { tmp4 = linked_1303.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1302, arg_1305) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1310 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = t.F_form; if linked_1311 == nil { tmp6 = ifn_1312.Invoke_O__O(arg_1313) } else { tmp6 = linked_1311.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1310, arg_1313) }; arg_1301 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1298 == nil { return ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { return linked_1298.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) } } else { return p1__1685000124_SHARP___1 } }





















func A_arbace_go_check_check_package_fn__1685000299_A_New() *A_arbace_go_check_check_package_fn__1685000299_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000299_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_go_check_check_package_fn__1685000299_A) Ctor() {}
//line :333:1
func (t *A_arbace_go_check_check_package_fn__1685000299_A) Invoke_O_O__O(self, p1__1685000125_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_215; var tmp2 any; var root_2542 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2544 lang.IFn; if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any = p1__1685000125_SHARP___1; if linked_2543 == nil { tmp2 = ifn_2544.Invoke_O__O(arg_2545) } else { tmp2 = linked_2543.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2542, arg_2545) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000301__1685000305_A_New() *A_arbace_go_check_check_package_iter__1685000301__1685000305_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_A) Ctor() {}
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_A) Invoke_O_O__O(self, s__1685000302__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2629 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_New_O_O(s__1685000302__1, self); var tmp2 *jrt.Class; var fncls__2628 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class; if fncls__2628 == nil { var fncls__2628d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__2629); A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class = fncls__2628d; tmp2 = fncls__2628d } else { tmp2 = fncls__2628 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2629, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :337:1
func A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A) Ctor_O_O(c__s__1685000302, c__iter__1685000301 any) { t.F_s__1685000302 = c__s__1685000302; t.F_iter__1685000301 = c__iter__1685000301 }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A) Invoke_O__O(self any) any { { var s__1685000302__1 any; var t_ any = t.F_s__1685000302; t.F_s__1685000302 = nil; s__1685000302__1 = t_; for { var temp__1927000414__auto____2 any; var root_2552 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any = s__1685000302__1; if linked_2553 == nil { temp__1927000414__auto____2 = ifn_2554.Invoke_O__O(arg_2555) } else { temp__1927000414__auto____2 = linked_2553.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2552, arg_2555) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000302__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2556 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = s__1685000302__3; if linked_2557 == nil { tmp1 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp1 = linked_2557.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2556, arg_2559) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2560 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = s__1685000302__3; if linked_2561 == nil { c__1927001037__auto____4 = ifn_2562.Invoke_O__O(arg_2563) } else { c__1927001037__auto____4 = linked_2561.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2560, arg_2563) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000304__6 any; var root_2564 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2566 lang.IFn; if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2565 == nil { b__1685000304__6 = ifn_2566.Invoke_O__O(arg_2567) } else { b__1685000304__6 = linked_2565.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2564, arg_2567) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2583 any = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_New_O_I_O(b__1685000304__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2582 *jrt.Class = A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class; if fncls__2582 == nil { var fncls__2582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__2583); A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class = fncls__2582d; tmp3 = fncls__2582d } else { tmp3 = fncls__2582 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2583, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2584 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any; var root_2589 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = b__1685000304__6; if linked_2590 == nil { arg_2587 = ifn_2591.Invoke_O__O(arg_2592) } else { arg_2587 = linked_2590.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2589, arg_2592) }; var arg_2588 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000301); var tmp5 any; var root_2593 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2593, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2595 lang.IFn; if linked_2594 == nil { ifn_2595 = lang.IFn_Cast(root_2593) } else { ifn_2595 = nil }; var arg_2596 any = s__1685000302__3; if linked_2594 == nil { tmp5 = ifn_2595.Invoke_O__O(arg_2596) } else { tmp5 = linked_2594.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2593, arg_2596) }; arg_2588 = tmp4.Invoke_O__O(tmp5); if linked_2585 == nil { return ifn_2586.Invoke_O_O__O(arg_2587, arg_2588) } else { return linked_2585.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2584, arg_2587, arg_2588) } } else { var root_2597 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2597, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any; var root_2602 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2602, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = b__1685000304__6; if linked_2603 == nil { arg_2600 = ifn_2604.Invoke_O__O(arg_2605) } else { arg_2600 = linked_2603.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2602, arg_2605) }; var arg_2601 any; if linked_2598 == nil { return ifn_2599.Invoke_O_O__O(arg_2600, arg_2601) } else { return linked_2598.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2597, arg_2600, arg_2601) } } } else { var d__4 any; var root_2606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2608 lang.IFn; if linked_2607 == nil { ifn_2608 = lang.IFn_Cast(root_2606) } else { ifn_2608 = nil }; var arg_2609 any = s__1685000302__3; if linked_2607 == nil { d__4 = ifn_2608.Invoke_O__O(arg_2609) } else { d__4 = linked_2607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2606, arg_2609) }; var root_2610 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_2611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2610, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2612 lang.IFn; if linked_2611 == nil { ifn_2612 = lang.IFn_Cast(root_2610) } else { ifn_2612 = nil }; var arg_2613 any; var root_2615 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2617 lang.IFn
															if linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any; var root_2620 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = d__4; if linked_2621 == nil { arg_2618 = ifn_2622.Invoke_O__O(arg_2623) } else { arg_2618 = linked_2621.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2620, arg_2623) }; var arg_2619 any = A_arbace_go_check_A_const_247; if linked_2616 == nil { arg_2613 = ifn_2617.Invoke_O_O__O(arg_2618, arg_2619) } else { arg_2613 = linked_2616.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2615, arg_2618, arg_2619) }
//line :337:1
	var arg_2614 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000301); var tmp7 any; var root_2624 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = s__1685000302__3; if linked_2625 == nil { tmp7 = ifn_2626.Invoke_O__O(arg_2627) } else { tmp7 = linked_2625.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2624, arg_2627) }; arg_2614 = tmp6.Invoke_O__O(tmp7); if linked_2611 == nil { return ifn_2612.Invoke_O_O__O(arg_2613, arg_2614) } else { return linked_2611.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2610, arg_2613, arg_2614) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A) Ctor_O_I_O(c__b__1685000304 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000304 = c__b__1685000304; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A) Invoke_O__O(self any) any { { var i__1685000303__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000303__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000303__1)); var root_2568 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = t.F_b__1685000304; var arg_2572 any; var root_2573 any = A_arbace_go_check_A_const_245.GetRawRoot__O(); var linked_2574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2573, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2575 lang.IFn
																	if linked_2574 == nil { ifn_2575 = lang.IFn_Cast(root_2573) } else { ifn_2575 = nil }; var arg_2576 any; var root_2578 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2578, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2580 lang.IFn; if linked_2579 == nil { ifn_2580 = lang.IFn_Cast(root_2578) } else { ifn_2580 = nil }; var arg_2581 any = d__2; if linked_2579 == nil { arg_2576 = ifn_2580.Invoke_O__O(arg_2581) } else { arg_2576 = linked_2579.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2578, arg_2581) }; var arg_2577 any = A_arbace_go_check_A_const_246; if linked_2574 == nil { arg_2572 = ifn_2575.Invoke_O_O__O(arg_2576, arg_2577) } else { arg_2572 = linked_2574.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2573, arg_2576, arg_2577) }
//line :337:1
	if linked_2569 == nil { ifn_2570.Invoke_O_O__O(arg_2571, arg_2572) } else { linked_2569.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2568, arg_2571, arg_2572) }; i__1685000303__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000303__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_check_package_fn__1685000311_A_New() *A_arbace_go_check_check_package_fn__1685000311_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000311_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_A) Invoke_O_O__O(self, lhs__1 any) any { var root_2637 any = A_arbace_go_check_A_const_123.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any; var fnbody__2667 any = A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_New(); var tmp1 *jrt.Class; var fncls__2666 *jrt.Class = A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class; if fncls__2666 == nil { var fncls__2666d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class = fncls__2666d; tmp1 = fncls__2666d } else { tmp1 = fncls__2666 }; arg_2640 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2667, tmp1, nil); var arg_2641 any = lhs__1; if linked_2638 == nil { return ifn_2639.Invoke_O_O__O(arg_2640, arg_2641) } else { return linked_2638.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2637, arg_2640, arg_2641) } }
//line :343:1
func A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_New() *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_2642 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = v__1; var arg_2646 any = A_arbace_go_check_A_const_71; if linked_2643 == nil { tmp1 = ifn_2644.Invoke_O_O__O(arg_2645, arg_2646) } else { tmp1 = linked_2643.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2642, arg_2645, arg_2646) }; var tmp2 any = tmp1; var tmp3 any; var root_2647 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2647, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2649 lang.IFn; if linked_2648 == nil { ifn_2649 = lang.IFn_Cast(root_2647) } else { ifn_2649 = nil }; var arg_2650 any = v__1; var arg_2651 any = A_arbace_go_check_A_const_74; if linked_2648 == nil { tmp3 = ifn_2649.Invoke_O_O__O(arg_2650, arg_2651) } else { tmp3 = linked_2648.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2647, arg_2650, arg_2651) }; var tmp4 any = tmp3; var tmp5 any; var root_2652 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = v__1; var arg_2656 any = A_arbace_go_check_A_const_79; if linked_2653 == nil { tmp5 = ifn_2654.Invoke_O_O__O(arg_2655, arg_2656) } else { tmp5 = linked_2653.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2652, arg_2655, arg_2656) }; var tmp6 any = tmp5; var tmp7 any; var root_2657 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any; var root_2661 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any = v__1; var arg_2665 any = A_arbace_go_check_A_const_251; if linked_2662 == nil { arg_2660 = ifn_2663.Invoke_O_O__O(arg_2664, arg_2665) } else { arg_2660 = linked_2662.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2661, arg_2664, arg_2665) }; if linked_2658 == nil { tmp7 = ifn_2659.Invoke_O__O(arg_2660) } else { tmp7 = linked_2658.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2657, arg_2660) }; return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp2, tmp4, tmp6, tmp7) }







func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :351:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_261; var tmp2 any = A_arbace_go_check_A_const_262; var tmp3 any = jrt.ConcurrentHashMap_New(); var tmp4 any = A_arbace_go_check_A_const_263; var tmp5 any; var root_2808 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2809 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2808, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2810 lang.IFn; if



	linked_2809 == nil { ifn_2810 = lang.IFn_Cast(root_2808) } else { ifn_2810 = nil }; var arg_2811 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2809 == nil { tmp5 = ifn_2810.Invoke_O__O(arg_2811) } else { tmp5 = linked_2809.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2808, arg_2811) }; return /*line :351:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, tmp3, tmp4, tmp5)) }







func A_arbace_go_check_ns_package_A_New() *A_arbace_go_check_ns_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ns_package_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_ns_package_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_ns_package_A) Invoke_O_O_O__O(self, s__0, ns_name__1 any) any { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp1 any; var root_2812 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2812, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2814 lang.IFn; if



	linked_2813 == nil { ifn_2814 = lang.IFn_Cast(root_2812) } else { ifn_2814 = nil }; var arg_2815 any = A_arbace_go_check_A_const_263.Invoke_O__O(s__0); if linked_2813 == nil { tmp1 = ifn_2814.Invoke_O__O(arg_2815) } else { tmp1 = linked_2813.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2812, arg_2815) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, ns_name__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var path__4 any = temp__1927000414__auto____3; var p__5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_A_const_262.Invoke_O__O(s__0))).Get_O__O(path__4); var tmp2 any
		var and__1927000168__auto____6 any = p__5
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2816 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2816, aot_arbace_core.A_arbace_core_realized_QMARK__A_fn_class); var ifn_2818 lang.IFn; if linked_2817 == nil { ifn_2818 = lang.IFn_Cast(root_2816) } else { ifn_2818 = nil }; var arg_2819 any = p__5; if linked_2817 == nil { tmp2 = ifn_2818.Invoke_O__O(arg_2819) } else { tmp2 = linked_2817.(*aot_arbace_core.A_arbace_core_realized_QMARK__A).Invoke_O_O__O(root_2816, arg_2819) } } else { tmp2 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp2) { var root_2820 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2822 lang.IFn; if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any = p__5; if linked_2821 == nil { or__1927000174__auto____3 = ifn_2822.Invoke_O__O(arg_2823) } else { or__1927000174__auto____3 = linked_2821.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2820, arg_2823) } } else { or__1927000174__auto____3 = nil } } else {
//line :363:1
			or__1927000174__auto____3 = nil }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_266.Invoke_O__O(s__0)


				if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var root_2824 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, A_arbace_go_check_ns_package_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = d__5; var arg_2828 any = ns_name__1; if linked_2825 == nil { return ifn_2826.Invoke_O_O__O(arg_2827, arg_2828) } else { return linked_2825.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2824, arg_2827, arg_2828) } } else { return nil } } }

func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var fnbody__2873 any = A_arbace_go_check_resolver_fn__1685000318_A_New_O_O_O(src__1, s__0, chain__2); var tmp1 *jrt.Class; var fncls__2872 *jrt.Class = A_arbace_go_check_resolver_fn__1685000318_A_fn_class; _ = deps__4; if




	fncls__2872 == nil { var fncls__2872d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__2873); A_arbace_go_check_resolver_fn__1685000318_A_fn_class = fncls__2872d; tmp1 = fncls__2872d } else { tmp1 = fncls__2872 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2873, tmp1, nil) }
//line :373:1
func A_arbace_go_check_resolver_fn__1685000318_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000318_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000318_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_136, path__1) { return A_arbace_go_check_A_const_268.GetRawRoot__O() } else { var lp__3 any; var root_2829 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2831 lang.IFn

		if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = t.F_src; var arg_2833 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_269, path__1); var arg_2834 any = path__1; if linked_2830 == nil { lp__3 = ifn_2831.Invoke_O_O_O__O(arg_2832, arg_2833, arg_2834) } else { lp__3 = linked_2830.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2829, arg_2832, arg_2833, arg_2834) }
//line :376:1
		var why__4 any; var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_270.Invoke_O__O(t.F_s)



		if jrt.J2g_Truth(temp__1927000414__auto____4) { var rf__5 any = temp__1927000414__auto____4; why__4 = lang.IFn_Cast(rf__5).Invoke_O_O__O(lp__3, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_src)) } else { why__4 = nil }
//line :376:1
		var p__5 any
		var or__1927000174__auto____5 any = why__4




		if jrt.J2g_Truth(or__1927000174__auto____5) { p__5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_2835 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2837 lang.IFn
			if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = t.F_s; var arg_2839 any = lp__3; var arg_2840 any = t.F_src; var arg_2841 any = t.F_chain; if linked_2836 == nil { or__1927000174__auto____6 = ifn_2837.Invoke_O_O_O_O__O(arg_2838, arg_2839, arg_2840, arg_2841) } else { or__1927000174__auto____6 = linked_2836.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2835, arg_2838, arg_2839, arg_2840, arg_2841) }
//line :382:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { p__5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any; var tmp1 any; var and__1927000168__auto____7 any; var root_2842 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2842, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2844 lang.IFn

				if linked_2843 == nil { ifn_2844 = lang.IFn_Cast(root_2842) } else { ifn_2844 = nil }; var arg_2845 any; var root_2846 any = A_arbace_go_check_A_const_272.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2848 lang.IFn; if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; var arg_2849 any; var root_2851 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any; var root_2855 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any = lp__3; var arg_2859 any = A_arbace_go_check_A_const_274; if linked_2856 == nil { arg_2854 = ifn_2857.Invoke_O_O__O(arg_2858, arg_2859) } else { arg_2854 = linked_2856.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2855, arg_2858, arg_2859) }; if linked_2852 == nil { arg_2849 = ifn_2853.Invoke_O__O(arg_2854) } else { arg_2849 = linked_2852.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2851, arg_2854) }; var arg_2850 any = Lit_137; if linked_2847 == nil { arg_2845 = ifn_2848.Invoke_O_O__O(arg_2849, arg_2850) } else { arg_2845 = linked_2847.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2846, arg_2849, arg_2850) }; if linked_2843 == nil { and__1927000168__auto____7 = ifn_2844.Invoke_O__O(arg_2845) } else { and__1927000168__auto____7 = linked_2843.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2842, arg_2845) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____7 = nil } else { or__1927000174__auto____7 = nil }
//line :382:1
				if jrt.J2g_Truth(or__1927000174__auto____7) { p__5 = or__1927000174__auto____7 } else {


					var root_2860 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2860, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2862 lang.IFn; if linked_2861 == nil { ifn_2862 = lang.IFn_Cast(root_2860) } else { ifn_2862 = nil }; var arg_2863 any = t.F_s; var arg_2864 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_138, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2865 any = t.F_src; var arg_2866 any = t.F_chain; if linked_2861 == nil { p__5 = ifn_2862.Invoke_O_O_O_O__O(arg_2863, arg_2864, arg_2865, arg_2866) } else { p__5 = linked_2861.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2860, arg_2863, arg_2864, arg_2865, arg_2866) } } } }
//line :376:1
		return p__5 } }
//line :373:1
func (t *A_arbace_go_check_resolver_fn__1685000318_A) Invoke_O_O__O(self, ns_name__1 any) any {
	var root_2867 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, A_arbace_go_check_ns_package_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = t.F_s; var arg_2871 any = ns_name__1; if linked_2868 == nil { return ifn_2869.Invoke_O_O__O(arg_2870, arg_2871) } else { return linked_2868.(*A_arbace_go_check_ns_package_A).Invoke_O_O_O__O(root_2867, arg_2870, arg_2871)
	}
}











func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :388:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2956 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2956, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2958 lang.IFn; if linked_2957 == nil { ifn_2958 = lang.IFn_Cast(root_2956) } else { ifn_2958 = nil }; var arg_2959 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2960 any = chain__3; if linked_2957 == nil { tmp1 = ifn_2958.Invoke_O_O__O(arg_2959, arg_2960) } else { tmp1 = linked_2957.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2956, arg_2959, arg_2960) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2961 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2961, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2963 lang.IFn
		if linked_2962 == nil { ifn_2963 = lang.IFn_Cast(root_2961) } else { ifn_2963 = nil }; var arg_2964 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_110, nil); var tmp4 any; var root_2966 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2968 lang.IFn; if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any = Lit_111; var arg_2970 any; var root_2971 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any = chain__3; var arg_2975 any = path__1; if linked_2972 == nil { arg_2970 = ifn_2973.Invoke_O_O__O(arg_2974, arg_2975) } else { arg_2970 = linked_2972.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2971, arg_2974, arg_2975) }; if linked_2967 == nil { tmp4 = ifn_2968.Invoke_O_O__O(arg_2969, arg_2970) } else { tmp4 = linked_2967.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2966, arg_2969, arg_2970) }; arg_2964 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2965 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111, path__1)); if linked_2962 == nil { tmp2 = ifn_2963.Invoke_O_O__O(arg_2964, arg_2965) } else { tmp2 = linked_2962.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2961, arg_2964, arg_2965) }
//line :391:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :388:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_266.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2874 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any = lang.IFn_Cast(A_arbace_go_check_A_const_275.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2875 == nil { and__1927000168__auto____6 = ifn_2876.Invoke_O__O(arg_2877) } else { and__1927000168__auto____6 = linked_2875.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2874, arg_2877) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_266.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2878 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2880 lang.IFn

		if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = d__6; var arg_2882 any = path__1; var arg_2883 any = importer__2; var arg_2884 any = chain__3; if linked_2879 == nil { return ifn_2880.Invoke_O_O_O_O__O(arg_2881, arg_2882, arg_2883, arg_2884) } else { return linked_2879.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2878, arg_2881, arg_2882, arg_2883, arg_2884) } } else {
//line :393:1
			var cache__6 any = A_arbace_go_check_A_const_262.Invoke_O__O(s__0); var p__7 any; var root_2885 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2887 lang.IFn



			if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; if linked_2886 == nil { p__7 = ifn_2887.Invoke__O() } else { p__7 = linked_2886.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2885) }
//line :393:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2888 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2888, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2890 lang.IFn; if linked_2889 == nil { ifn_2890 = lang.IFn_Cast(root_2888) } else { ifn_2890 = nil }; var arg_2891 any = prev__8; if linked_2889 == nil { return ifn_2890.Invoke_O__O(arg_2891) } else { return linked_2889.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2888, arg_2891) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_261.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2892 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2892, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2894 lang.IFn; if linked_2893 == nil { ifn_2894 = lang.IFn_Cast(root_2892) } else { ifn_2894 = nil }; var arg_2895 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__9); if linked_2893 == nil { tmp5 = ifn_2894.Invoke_O__O(arg_2895) } else { tmp5 = linked_2893.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2892, arg_2895) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 *lang.Compiler_AOTFn; var fnbody__2955 any = A_arbace_go_check_ensure_package_fn__1685000321_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2954 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class; if fncls__2954 == nil { var fncls__2954d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2955); A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class = fncls__2954d; tmp7 = fncls__2954d } else { tmp7 = fncls__2954 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2955, tmp7, nil); pkg__10 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O() } else {
//line :402:1
						pkg__10 = nil
					}






				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2976 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_2977 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2976, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2978 lang.IFn; if linked_2977 == nil { ifn_2978 = lang.IFn_Cast(root_2976) } else { ifn_2978 = nil }; var arg_2979 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2980 any = A_arbace_go_check_A_const_282; var arg_2981 any; var root_2982 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2984 lang.IFn; if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2986 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_283; var tmp11 any; var root_2987 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_2988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2987, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2989 lang.IFn; if linked_2988 == nil { ifn_2989 = lang.IFn_Cast(root_2987) } else { ifn_2989 = nil }; var arg_2990 any = pkg__10; var arg_2991 any = A_arbace_go_check_A_const_72; if linked_2988 == nil { tmp11 = ifn_2989.Invoke_O_O__O(arg_2990, arg_2991) } else { tmp11 = linked_2988.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2987, arg_2990, arg_2991) }; arg_2986 = tmp10.Invoke_O__O(tmp11); if linked_2983 == nil { arg_2981 = ifn_2984.Invoke_O_O__O(arg_2985, arg_2986) } else { arg_2981 = linked_2983.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2982, arg_2985, arg_2986) }; if linked_2977 == nil { tmp9 = ifn_2978.Invoke_O_O_O__O(arg_2979, arg_2980, arg_2981) } else { tmp9 = linked_2977.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2976, arg_2979, arg_2980, arg_2981) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2992 any = A_arbace_go_check_A_const_284.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any = A_arbace_go_check_A_const_263.Invoke_O__O(s__0); var arg_2996 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var arg_2997 any; var root_2999 any = A_arbace_go_check_A_const_189.GetRawRoot__O(); var linked_3000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2999, aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_3001 lang.IFn; if linked_3000 == nil { ifn_3001 = lang.IFn_Cast(root_2999) } else { ifn_3001 = nil }; var arg_3002 any = path__1; if linked_3000 == nil { arg_2997 = ifn_3001.Invoke_O__O(arg_3002) } else { arg_2997 = linked_3000.(*aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_2999, arg_3002) }; var arg_2998 any = path__1; if linked_2993 == nil { ifn_2994.Invoke_O_O_O_O__O(arg_2995, arg_2996, arg_2997, arg_2998) } else { linked_2993.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2992, arg_2995, arg_2996, arg_2997, arg_2998) }
				var root_3003 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = p__7; var arg_3007 any = pkg__10; if linked_3004 == nil { ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { linked_3004.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) }
//line :399:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000321_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000321_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000321_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :403:1
func (t *A_arbace_go_check_ensure_package_fn__1685000321_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :403:1
func (t *A_arbace_go_check_ensure_package_fn__1685000321_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 any; var G__1685000322__3_ any = A_arbace_go_check_A_const_109.Invoke_O__O(t.F_s); if lang.Util_Identical_O_O__Z_NoInit(G__1685000322__3_, nil) { tmp2 = nil } else { var root_2896 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any = G__1685000322__3_; var arg_2900 any = lang.Tuple_Create_O__IPersistentVector(t.F_path); if linked_2897 == nil { tmp2 = ifn_2898.Invoke_O_O__O(arg_2899, arg_2900) } else { tmp2 = linked_2897.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2896, arg_2899, arg_2900) } }; if jrt.J2g_Truth(tmp2) {
												var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp4 any = t.F_src; var tmp5 any; var root_2908 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2908, A_arbace_go_check_resolver_A_fn_class); var ifn_2910 lang.IFn; if linked_2909 == nil { ifn_2910 = lang.IFn_Cast(root_2908) } else { ifn_2910 = nil }; var arg_2911 any; var t_ any = t.F_s; t.F_s = nil; arg_2911 = t_; var arg_2912 any; var t__2 any = t.F_src; t.F_src = nil; arg_2912 = t__2; var arg_2913 any; var root_2914 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2914, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2916 lang.IFn; if linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any; var root_2919 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2922 = t__3; if linked_2920 == nil { arg_2917 = ifn_2921.Invoke_O__O(arg_2922) } else { arg_2917 = linked_2920.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2919, arg_2922) }; var arg_2918 any = t.F_path; if linked_2915 == nil { arg_2913 = ifn_2916.Invoke_O_O__O(arg_2917, arg_2918) } else { arg_2913 = linked_2915.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2914, arg_2917, arg_2918) }; if linked_2909 == nil { tmp5 = ifn_2910.Invoke_O_O_O__O(arg_2911, arg_2912, arg_2913) } else { tmp5 = linked_2909.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2908, arg_2911, arg_2912, arg_2913) }; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, A_arbace_go_check_A_const_109, jrt.Boolean_TRUE.Ref()) } else {
													var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp7 any = t.F_src; var tmp8 any; var root_2928 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_2929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2928, A_arbace_go_check_resolver_A_fn_class); var ifn_2930 lang.IFn; if linked_2929 == nil { ifn_2930 = lang.IFn_Cast(root_2928) } else { ifn_2930 = nil }; var arg_2931 any; var t__4 any = t.F_s; t.F_s = nil; arg_2931 = t__4; var arg_2932 any; var t__5 any = t.F_src; t.F_src = nil; arg_2932 = t__5; var arg_2933 any; var root_2934 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2935 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2934, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2936 lang.IFn; if linked_2935 == nil { ifn_2936 = lang.IFn_Cast(root_2934) } else { ifn_2936 = nil }; var arg_2937 any; var root_2939 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any; var t__6 any = t.F_chain; t.F_chain = nil; arg_2942 = t__6; if linked_2940 == nil { arg_2937 = ifn_2941.Invoke_O__O(arg_2942) } else { arg_2937 = linked_2940.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2939, arg_2942) }; var arg_2938 any = t.F_path; if linked_2935 == nil { arg_2933 = ifn_2936.Invoke_O_O__O(arg_2937, arg_2938) } else { arg_2933 = linked_2935.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2934, arg_2937, arg_2938) }; if linked_2929 == nil { tmp8 = ifn_2930.Invoke_O_O_O__O(arg_2931, arg_2932, arg_2933) } else { tmp8 = linked_2929.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2928, arg_2931, arg_2932, arg_2933) }; tmp1 = tmp6.Invoke_O_O__O(tmp7, tmp8) } }
//line :403:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var root_2949 any = A_arbace_go_check_A_const_280.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2951 lang.IFn




		if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any; var t__7 any = t.F_p; t.F_p = nil; arg_2952 = t__7; var arg_2953 any; if linked_2950 == nil { ifn_2951.Invoke_O_O__O(arg_2952, arg_2953) } else { linked_2950.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2949, arg_2952, arg_2953) }
//line :403:1
		var tmp10 any; var root_2943 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2945 lang.IFn





		if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var tmp11 any = t.F_path; var arg_2946 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2947 any; var tmp12 any = A_arbace_go_check_A_const_111; var tmp13 any; var t__8 any = t.F_path; t.F_path = nil; tmp13 = t__8; arg_2947 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13)); var arg_2948 any = ex__3; if linked_2944 == nil { tmp10 = ifn_2945.Invoke_O_O_O__O(arg_2946, arg_2947, arg_2948) } else { tmp10 = linked_2944.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2943, arg_2946, arg_2947, arg_2948) }
//line :403:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp10))) } }; return tmp1 }











func A_arbace_go_check_check_src_A_New() *A_arbace_go_check_check_src_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_src_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_go_check_check_src_A) Ctor() {}
//line :415:1
func (t *A_arbace_go_check_check_src_A) Invoke_O_O_O__O(self, s__0, src__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp2 any; var root_3013 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_3014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3013, A_arbace_go_check_resolver_A_fn_class); var ifn_3015 lang.IFn; if linked_3014 == nil { ifn_3015 = lang.IFn_Cast(root_3013) } else { ifn_3015 = nil }; var arg_3016 any = s__0; var arg_3017 any = src__1; var arg_3018 any = lang.PersistentVector_EMPTY.Ref(); if linked_3014 == nil { tmp2 = ifn_3015.Invoke_O_O_O__O(arg_3016, arg_3017, arg_3018) } else { tmp2 = linked_3014.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3013, arg_3016, arg_3017, arg_3018) }; return tmp1.Invoke_O_O__O(src__1, tmp2)
}










func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :430:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var temp__1927000408__auto____2 any = A_arbace_go_check_A_const_285.Get__O(); if
											jrt.J2g_Truth(temp__1927000408__auto____2) { var f__3 any = temp__1927000408__auto____2; var G__1685000326__4_ any = corpus__0
												switch lang.Util_Hash_O__I_NoInit(G__1685000326__4_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_93) { var tmp1 any = A_arbace_go_check_A_const_286; var tmp2 any = A_arbace_go_check_A_const_288; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_287; var tmp5 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_290)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_97) { var tmp6 any = A_arbace_go_check_A_const_286; var tmp7 any = A_arbace_go_check_A_const_288; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_291; var tmp10 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_98), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_292)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_54) { var tmp11 any = A_arbace_go_check_A_const_286; var tmp12 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_99), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_293)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_100) { var tmp13 any = A_arbace_go_check_A_const_286; var tmp14 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_101), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_294)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000326__4_, Lit_102) { var tmp15 any = A_arbace_go_check_A_const_286; var tmp16 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, f__3, nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_301)) }; default:}; var tmp17 any; var root_3020 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3022 lang.IFn







		if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_3024 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295, corpus__0)); if linked_3021 == nil { tmp17 = ifn_3022.Invoke_O_O__O(arg_3023, arg_3024) } else { tmp17 = linked_3021.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3020, arg_3023, arg_3024) }
//line :432:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) } else {
//line :431:1
			var G__1685000327__3_ any = corpus__0









			switch lang.Util_Hash_O__I_NoInit(G__1685000327__3_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_93) { var tmp18 any = A_arbace_go_check_A_const_286; var tmp19 any = A_arbace_go_check_A_const_288; var tmp20 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))); var tmp21 any = A_arbace_go_check_A_const_287; var tmp22 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp20, tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_297)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_97) { var tmp23 any = A_arbace_go_check_A_const_286; var tmp24 any = A_arbace_go_check_A_const_288; var tmp25 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))); var tmp26 any = A_arbace_go_check_A_const_291; var tmp27 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp25, tmp26, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_106), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_289, Lit_96)), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_298)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_54) { var tmp28 any = A_arbace_go_check_A_const_286; var tmp29 any = A_arbace_go_check_A_const_288; var tmp30 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(); var tmp31 any = A_arbace_go_check_A_const_302; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp28, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_299)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_100) { var tmp32 any = A_arbace_go_check_A_const_286; var tmp33 any = A_arbace_go_check_A_const_288; var tmp34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(); var tmp35 any = A_arbace_go_check_A_const_302; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, tmp35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_109), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_300)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000327__3_, Lit_102) { var tmp36 any = A_arbace_go_check_A_const_286; var tmp37 any = A_arbace_go_check_A_const_288; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp36, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_112, A_arbace_go_check_A_const_303)) }; default:}; var tmp38 any; var root_3026 any = A_arbace_go_check_A_const_279.GetRawRoot__O(); var linked_3027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3026, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_3028 lang.IFn












			if linked_3027 == nil { ifn_3028 = lang.IFn_Cast(root_3026) } else { ifn_3028 = nil }; var arg_3029 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_3030 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_295, corpus__0)); if linked_3027 == nil { tmp38 = ifn_3028.Invoke_O_O__O(arg_3029, arg_3030) } else { tmp38 = linked_3027.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_3026, arg_3029, arg_3030) }
//line :441:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp38))) } }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :456:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :456:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000330__0 any) any { var map__1685000331__2 any = p__1685000330__0; var map__1685000331__3 any; if lang.ISeq_InstanceOf(map__1685000331__2) { var tmp1 any; var root_3031 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3031, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3033 lang.IFn; if linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any = map__1685000331__2; if linked_3032 == nil { tmp1 = ifn_3033.Invoke_O__O(arg_3034) } else { tmp1 = linked_3032.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3031, arg_3034) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3035 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3035, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3037 lang.IFn; if linked_3036 == nil { ifn_3037 = lang.IFn_Cast(root_3035) } else { ifn_3037 = nil }; var arg_3038 any = map__1685000331__2; if linked_3036 == nil { tmp2 = ifn_3037.Invoke_O__O(arg_3038) } else { tmp2 = linked_3036.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3035, arg_3038) }; map__1685000331__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_3039 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3041 lang.IFn; if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any = map__1685000331__2; if linked_3040 == nil { tmp3 = ifn_3041.Invoke_O__O(arg_3042) } else { tmp3 = linked_3040.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3039, arg_3042) }; if jrt.J2g_Truth(tmp3) { var root_3043 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3043, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3045 lang.IFn; if linked_3044 == nil { ifn_3045 = lang.IFn_Cast(root_3043) } else { ifn_3045 = nil }; var arg_3046 any = map__1685000331__2; if linked_3044 == nil { map__1685000331__3 = ifn_3045.Invoke_O__O(arg_3046) } else { map__1685000331__3 = linked_3044.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3043, arg_3046) } } else { map__1685000331__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000331__3 = map__1685000331__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000331__3, A_arbace_go_check_A_const_286); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000331__3, A_arbace_go_check_A_const_112); var root_3047 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3047, A_arbace_go_check_session_A_fn_class); var ifn_3049 lang.IFn; if
											linked_3048 == nil { ifn_3049 = lang.IFn_Cast(root_3047) } else { ifn_3049 = nil }; var arg_3050 any; var fnbody__3065 any = A_arbace_go_check_std_session_fn__1685000333_A_New_O_O(roots__4, config__5); var tmp4 *jrt.Class; var fncls__3064 *jrt.Class = A_arbace_go_check_std_session_fn__1685000333_A_fn_class; if fncls__3064 == nil { var fncls__3064d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__3065); A_arbace_go_check_std_session_fn__1685000333_A_fn_class = fncls__3064d; tmp4 = fncls__3064d } else { tmp4 = fncls__3064 }; arg_3050 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3065, tmp4, nil); if linked_3048 == nil { return ifn_3049.Invoke_O__O(arg_3050) } else { return linked_3048.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3047, arg_3050) } }
//line :457:1
func A_arbace_go_check_std_session_fn__1685000333_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000333_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000333_A{}; t.Ctor_O_O(p0, p1); return t }
//line :457:1
func (t *A_arbace_go_check_std_session_fn__1685000333_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :457:1
func (t *A_arbace_go_check_std_session_fn__1685000333_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_3051 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3051, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3053 lang.IFn; if linked_3052 == nil { ifn_3053 = lang.IFn_Cast(root_3051) } else { ifn_3053 = nil }; var arg_3054 any; var fnbody__3063 any = A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_New_O_O(path__1, t.F_config); var tmp1 *jrt.Class; var fncls__3062 *jrt.Class = A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class; if fncls__3062 == nil { var fncls__3062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, fnbody__3063); A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class = fncls__3062d; tmp1 = fncls__3062d } else { tmp1 = fncls__3062 }; arg_3054 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3063, tmp1, nil); var arg_3055 any = t.F_roots; if linked_3052 == nil { return ifn_3053.Invoke_O_O__O(arg_3054, arg_3055) } else { return linked_3052.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3051, arg_3054, arg_3055) } }
//line :458:1
func A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :458:1
func (t *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :458:1
func (t *A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A) Invoke_O_O__O(self, p1__1685000329_SHARP___1 any) any { var root_3056 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3056, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3058 lang.IFn; if linked_3057 == nil { ifn_3058 = lang.IFn_Cast(root_3056) } else { ifn_3058 = nil }; var arg_3059 any = p1__1685000329_SHARP___1; var arg_3060 any = t.F_path; var arg_3061 any = t.F_config; if linked_3057 == nil { return ifn_3058.Invoke_O_O_O__O(arg_3059, arg_3060, arg_3061) } else { return linked_3057.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_3056, arg_3059, arg_3060, arg_3061) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :464:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_3066 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3066, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3068 lang.IFn; if


	linked_3067 == nil { ifn_3068 = lang.IFn_Cast(root_3066) } else { ifn_3068 = nil }; var arg_3069 any = xs__2; if linked_3067 == nil { xs__4 = ifn_3068.Invoke_O__O(arg_3069) } else { xs__4 = linked_3067.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3066, arg_3069) }; var q__5 any = /*line :464:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_3070 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3070, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3072 lang.IFn; if





	linked_3071 == nil { ifn_3072 = lang.IFn_Cast(root_3070) } else { ifn_3072 = nil }; var arg_3073 any; var iter__1927001039__auto____7 any; var fnbody__3147 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp1 *jrt.Class; var fncls__3146 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class; if fncls__3146 == nil { var fncls__3146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, fnbody__3147); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class = fncls__3146d; tmp1 = fncls__3146d } else { tmp1 = fncls__3146 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3147, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp3 any; var root_3148 any = A_arbace_go_check_A_const_310.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3150 lang.IFn; if linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any = n__0; if linked_3149 == nil { tmp3 = ifn_3150.Invoke_O__O(arg_3151) } else { tmp3 = linked_3149.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3148, arg_3151) }; arg_3073 = tmp2.Invoke_O__O(tmp3); if linked_3071 == nil { workers__7 = ifn_3072.Invoke_O__O(arg_3073) } else { workers__7 = linked_3071.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3070, arg_3073) }; var seq_1685000352__8 any; var root_3156 any = /*line :464:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3158 lang.IFn; if















	linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any = workers__7; if linked_3157 == nil { seq_1685000352__8 = ifn_3158.Invoke_O__O(arg_3159) } else { seq_1685000352__8 = linked_3157.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3156, arg_3159) }; var chunk_1685000353__9 any; var count_1685000354__10 int64 = 0; var i_1685000355__11 int64 = 0; L1:
//line :464:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000355__11, count_1685000354__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000353__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000355__11)); var root_3176 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3176, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3178 lang.IFn; if linked_3177 == nil { ifn_3178 = lang.IFn_Cast(root_3176) } else { ifn_3178 = nil }; var arg_3179 any = w__12; if linked_3177 == nil { ifn_3178.Invoke_O__O(arg_3179) } else { linked_3177.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3176, arg_3179) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000355__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_3160 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3160, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3162 lang.IFn; if linked_3161 == nil { ifn_3162 = lang.IFn_Cast(root_3160) } else { ifn_3162 = nil }; var arg_3163 any = seq_1685000352__8; if linked_3161 == nil { temp__1927000414__auto____12 = ifn_3162.Invoke_O__O(arg_3163) } else { temp__1927000414__auto____12 = linked_3161.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3160, arg_3163) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000352__13 any = temp__1927000414__auto____12; var tmp4 any; var root_3164 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3164, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3166 lang.IFn; if linked_3165 == nil { ifn_3166 = lang.IFn_Cast(root_3164) } else { ifn_3166 = nil }; var arg_3167 any = seq_1685000352__13; if linked_3165 == nil { tmp4 = ifn_3166.Invoke_O__O(arg_3167) } else { tmp4 = linked_3165.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3164, arg_3167) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_3168 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3168, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3170 lang.IFn; if linked_3169 == nil { ifn_3170 = lang.IFn_Cast(root_3168) } else { ifn_3170 = nil }; var arg_3171 any = seq_1685000352__13; if linked_3169 == nil { c__1927000678__auto____14 = ifn_3170.Invoke_O__O(arg_3171) } else { c__1927000678__auto____14 = linked_3169.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3168, arg_3171) }; var tmp5 any; var root_3180 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3180, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3182 lang.IFn; if linked_3181 == nil { ifn_3182 = lang.IFn_Cast(root_3180) } else { ifn_3182 = nil }; var arg_3183 any = seq_1685000352__13; if linked_3181 == nil { tmp5 = ifn_3182.Invoke_O__O(arg_3183) } else { tmp5 = linked_3181.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3180, arg_3183) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_3172 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3172, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3174 lang.IFn; if linked_3173 == nil { ifn_3174 = lang.IFn_Cast(root_3172) } else { ifn_3174 = nil }; var arg_3175 any = seq_1685000352__13; if linked_3173 == nil { w__14 = ifn_3174.Invoke_O__O(arg_3175) } else { w__14 = linked_3173.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3172, arg_3175) }; var root_3184 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3184, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3186 lang.IFn; if linked_3185 == nil { ifn_3186 = lang.IFn_Cast(root_3184) } else { ifn_3186 = nil }; var arg_3187 any = w__14; if linked_3185 == nil { ifn_3186.Invoke_O__O(arg_3187) } else { linked_3185.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3184, arg_3187) }; var tmp6 any; var root_3188 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3188, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3190 lang.IFn; if linked_3189 == nil { ifn_3190 = lang.IFn_Cast(root_3188) } else { ifn_3190 = nil }; var arg_3191 any = seq_1685000352__13; if linked_3189 == nil { tmp6 = ifn_3190.Invoke_O__O(arg_3191) } else { tmp6 = linked_3189.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3188, arg_3191) }; seq_1685000352__8, chunk_1685000353__9, count_1685000354__10, i_1685000355__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :464:1
		break L1 }; var root_3152 any =
















	A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3152, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3154 lang.IFn; if linked_3153 == nil { ifn_3154 = lang.IFn_Cast(root_3152) } else { ifn_3154 = nil }; var arg_3155 any = out__6; if linked_3153 == nil { return ifn_3154.Invoke_O__O(arg_3155) } else { return linked_3153.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3152, arg_3155) } }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A) Invoke_O_O__O(self, s__1685000339__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3145 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O_O(self, t.F_f, t.F_out, t.F_q, t.F_xs, s__1685000339__1); var tmp2 *jrt.Class; var fncls__3144 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class; if fncls__3144 == nil { var fncls__3144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, fnbody__3145); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class = fncls__3144d; tmp2 = fncls__3144d } else { tmp2 = fncls__3144 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3145, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A) Ctor_O_O_O_O_O_O(c__iter__1685000338, c__f, c__out, c__q, c__xs, c__s__1685000339 any) { t.F_iter__1685000338 = c__iter__1685000338; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_s__1685000339 = c__s__1685000339 }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A) Invoke_O__O(self any) any { { var s__1685000339__1 any; var t_ any = t.F_s__1685000339; t.F_s__1685000339 = nil; s__1685000339__1 = t_; for { var temp__1927000414__auto____2 any; var root_3074 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3074, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3076 lang.IFn; if linked_3075 == nil { ifn_3076 = lang.IFn_Cast(root_3074) } else { ifn_3076 = nil }; var arg_3077 any = s__1685000339__1; if linked_3075 == nil { temp__1927000414__auto____2 = ifn_3076.Invoke_O__O(arg_3077) } else { temp__1927000414__auto____2 = linked_3075.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3074, arg_3077) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000339__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3078 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3078, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3080 lang.IFn; if linked_3079 == nil { ifn_3080 = lang.IFn_Cast(root_3078) } else { ifn_3080 = nil }; var arg_3081 any = s__1685000339__3; if linked_3079 == nil { tmp1 = ifn_3080.Invoke_O__O(arg_3081) } else { tmp1 = linked_3079.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3078, arg_3081) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3082 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3082, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3084 lang.IFn; if linked_3083 == nil { ifn_3084 = lang.IFn_Cast(root_3082) } else { ifn_3084 = nil }; var arg_3085 any = s__1685000339__3; if linked_3083 == nil { c__1927001037__auto____4 = ifn_3084.Invoke_O__O(arg_3085) } else { c__1927001037__auto____4 = linked_3083.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3082, arg_3085) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000341__6 any; var root_3086 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3087 == nil { b__1685000341__6 = ifn_3088.Invoke_O__O(arg_3089) } else { b__1685000341__6 = linked_3087.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3086, arg_3089) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3102 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_O_I_O_O(t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, b__1685000341__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3101 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class; if fncls__3101 == nil { var fncls__3101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, fnbody__3102); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class = fncls__3101d; tmp3 = fncls__3101d } else { tmp3 = fncls__3101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3102, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3103 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3105 lang.IFn; if linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; var arg_3106 any; var root_3108 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3110 lang.IFn; if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; var arg_3111 any = b__1685000341__6; if linked_3109 == nil { arg_3106 = ifn_3110.Invoke_O__O(arg_3111) } else { arg_3106 = linked_3109.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3108, arg_3111) }; var arg_3107 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp5 any; var root_3112 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3112, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3114 lang.IFn; if linked_3113 == nil { ifn_3114 = lang.IFn_Cast(root_3112) } else { ifn_3114 = nil }; var arg_3115 any = s__1685000339__3; if linked_3113 == nil { tmp5 = ifn_3114.Invoke_O__O(arg_3115) } else { tmp5 = linked_3113.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3112, arg_3115) }; arg_3107 = tmp4.Invoke_O__O(tmp5); if linked_3104 == nil { return ifn_3105.Invoke_O_O__O(arg_3106, arg_3107) } else { return linked_3104.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3103, arg_3106, arg_3107) } } else { var root_3116 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3116, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3118 lang.IFn; if linked_3117 == nil { ifn_3118 = lang.IFn_Cast(root_3116) } else { ifn_3118 = nil }; var arg_3119 any; var root_3121 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3121, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3123 lang.IFn; if linked_3122 == nil { ifn_3123 = lang.IFn_Cast(root_3121) } else { ifn_3123 = nil }; var arg_3124 any = b__1685000341__6; if linked_3122 == nil { arg_3119 = ifn_3123.Invoke_O__O(arg_3124) } else { arg_3119 = linked_3122.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3121, arg_3124) }; var arg_3120 any; if linked_3117 == nil { return ifn_3118.Invoke_O_O__O(arg_3119, arg_3120) } else { return linked_3117.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3116, arg_3119, arg_3120) } } } else { var ___4 any; var root_3125 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3125, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3127 lang.IFn; _ = ___4; if linked_3126 == nil { ifn_3127 = lang.IFn_Cast(root_3125) } else { ifn_3127 = nil }; var arg_3128 any = s__1685000339__3; if linked_3126 == nil { ___4 = ifn_3127.Invoke_O__O(arg_3128) } else { ___4 = linked_3126.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3125, arg_3128) }; var root_3129 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3129, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3131 lang.IFn; if linked_3130 == nil { ifn_3131 = lang.IFn_Cast(root_3129) } else { ifn_3131 = nil }; var arg_3132 any; var root_3134 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3134, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3136 lang.IFn
															if linked_3135 == nil { ifn_3136 = lang.IFn_Cast(root_3134) } else { ifn_3136 = nil }; var arg_3137 any; var fnbody__3139 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp6 *jrt.Class; var fncls__3138 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class; if fncls__3138 == nil { var fncls__3138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__3139); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class = fncls__3138d; tmp6 = fncls__3138d } else { tmp6 = fncls__3138 }; arg_3137 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3139, tmp6, nil); if linked_3135 == nil { arg_3132 = ifn_3136.Invoke_O__O(arg_3137) } else { arg_3132 = linked_3135.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3134, arg_3137) }
//line :470:1
	var arg_3133 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000338); var tmp8 any; var root_3140 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3140, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3142 lang.IFn; if linked_3141 == nil { ifn_3142 = lang.IFn_Cast(root_3140) } else { ifn_3142 = nil }; var arg_3143 any = s__1685000339__3; if linked_3141 == nil { tmp8 = ifn_3142.Invoke_O__O(arg_3143) } else { tmp8 = linked_3141.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3140, arg_3143) }; arg_3133 = tmp7.Invoke_O__O(tmp8); if linked_3130 == nil { return ifn_3131.Invoke_O_O__O(arg_3132, arg_3133) } else { return linked_3130.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3129, arg_3132, arg_3133) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :470:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Ctor_O_O_O_O_I_O_O(c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__b__1685000341, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000341 = c__b__1685000341; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :470:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A) Invoke_O__O(self any) any { { var i__1685000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000340__1)); var root_3090 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3090, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3092 lang.IFn; _ = ___2; if linked_3091 == nil { ifn_3092 = lang.IFn_Cast(root_3090) } else { ifn_3092 = nil }; var arg_3093 any = t.F_b__1685000341; var arg_3094 any; var root_3095 any = A_arbace_go_check_A_const_307.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3097 lang.IFn
																if linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any; var fnbody__3100 any = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp2 *jrt.Class; var fncls__3099 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class; if fncls__3099 == nil { var fncls__3099d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, fnbody__3100); A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class = fncls__3099d; tmp2 = fncls__3099d } else { tmp2 = fncls__3099 }; arg_3098 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3100, tmp2, nil); if linked_3096 == nil { arg_3094 = ifn_3097.Invoke_O__O(arg_3098) } else { arg_3094 = linked_3096.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3095, arg_3098) }
//line :470:1
	if linked_3091 == nil { ifn_3092.Invoke_O_O__O(arg_3093, arg_3094) } else { linked_3091.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3090, arg_3093, arg_3094) }; i__1685000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_309) }
		var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_out); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :471:1*/panic("j2g: unreachable") }
//line :471:1
func A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :471:1
func (t *A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_309) }
		var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_out); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_308.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_308.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :471:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :483:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_3192 any = A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_3193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3192, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3194 lang.IFn; if linked_3193 == nil { ifn_3194 = lang.IFn_Cast(root_3192) } else { ifn_3194 = nil }; var arg_3195 any = pkg__0; var arg_3196 any = A_arbace_go_check_A_const_237; if linked_3193 == nil { return ifn_3194.Invoke_O_O__O(arg_3195, arg_3196) } else { return linked_3193.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3192, arg_3195, arg_3196) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :485:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :485:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_111; var tmp2 any = A_arbace_go_check_A_const_238; var tmp3 any = A_arbace_go_check_A_const_74; var tmp4 any = A_arbace_go_check_A_const_79; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_312; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_115, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :485:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_313, A_arbace_go_check_A_const_314))), A_arbace_go_check_A_const_164, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_83, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_153, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_155, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_165, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_140, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_166, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_157, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_145, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_311, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :492:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :492:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_3197 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3197, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3199 lang.IFn; if


	linked_3198 == nil { ifn_3199 = lang.IFn_Cast(root_3197) } else { ifn_3199 = nil }; var arg_3200 any = corpus__0; if linked_3198 == nil { cc__3 = ifn_3199.Invoke_O__O(arg_3200) } else { cc__3 = linked_3198.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3197, arg_3200) }; var s__4 any; var root_3201 any = /*line :492:1*/A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3201, A_arbace_go_check_std_session_A_fn_class); var ifn_3203 lang.IFn; if



	linked_3202 == nil { ifn_3203 = lang.IFn_Cast(root_3201) } else { ifn_3203 = nil }; var arg_3204 any = cc__3; if linked_3202 == nil { s__4 = ifn_3203.Invoke_O__O(arg_3204) } else { s__4 = linked_3202.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3201, arg_3204) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :492:1*/A_arbace_go_check_A_const_291.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_287.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_3205 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3205, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3207 lang.IFn
		if linked_3206 == nil { ifn_3207 = lang.IFn_Cast(root_3205) } else { ifn_3207 = nil }; var arg_3208 any = A_arbace_go_check_A_const_286.Invoke_O__O(cc__3); if linked_3206 == nil { root__5 = ifn_3207.Invoke_O__O(arg_3208) } else { root__5 = linked_3206.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3205, arg_3208) }
		var root_3209 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3211 lang.IFn; if linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any; var iter__1927001039__auto____6 any; var fnbody__3282 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_New(); var tmp2 *jrt.Class; var fncls__3281 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class; if fncls__3281 == nil { var fncls__3281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class = fncls__3281d; tmp2 = fncls__3281d } else { tmp2 = fncls__3281 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3282, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp4 any; var root_3283 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3285 lang.IFn; if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any = root__5; var arg_3287 any = Lit_36; if linked_3284 == nil { tmp4 = ifn_3285.Invoke_O_O__O(arg_3286, arg_3287) } else { tmp4 = linked_3284.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3283, arg_3286, arg_3287) }; arg_3212 = tmp3.Invoke_O__O(tmp4); if linked_3210 == nil { std_pkgs__5 = ifn_3211.Invoke_O__O(arg_3212) } else { std_pkgs__5 = linked_3210.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3209, arg_3212) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_3288 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = jobs__1; var arg_3292 any; var fnbody__3311 any = A_arbace_go_check_check_corpus_fn__1685000370_A_New_O(s__4); var tmp5 *jrt.Class; var fncls__3310 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class
		if fncls__3310 == nil { var fncls__3310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__3311); A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class = fncls__3310d; tmp5 = fncls__3310d } else { tmp5 = fncls__3310 }; arg_3292 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3311, tmp5, nil)
//line :504:1
		var arg_3293 any = std_pkgs__5; if linked_3289 == nil { return ifn_3290.Invoke_O_O_O__O(arg_3291, arg_3292, arg_3293) } else { return linked_3289.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3288, arg_3291, arg_3292, arg_3293) } } else {
//line :502:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_291.Invoke_O__O(cc__3)) { var map__1685000372__6 any = A_arbace_go_check_A_const_291.Invoke_O__O(cc__3); var map__1685000372__7 any








				if lang.ISeq_InstanceOf(map__1685000372__6) { var tmp6 any; var root_3312 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3312, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3314 lang.IFn; if linked_3313 == nil { ifn_3314 = lang.IFn_Cast(root_3312) } else { ifn_3314 = nil }; var arg_3315 any = map__1685000372__6; if linked_3313 == nil { tmp6 = ifn_3314.Invoke_O__O(arg_3315) } else { tmp6 = linked_3313.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3312, arg_3315) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_3316 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3318 lang.IFn; if linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any = map__1685000372__6; if linked_3317 == nil { tmp7 = ifn_3318.Invoke_O__O(arg_3319) } else { tmp7 = linked_3317.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3316, arg_3319) }; map__1685000372__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_3320 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3322 lang.IFn; if linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any = map__1685000372__6; if linked_3321 == nil { tmp8 = ifn_3322.Invoke_O__O(arg_3323) } else { tmp8 = linked_3321.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3320, arg_3323) }; if jrt.J2g_Truth(tmp8) { var root_3324 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3324, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3326 lang.IFn; if linked_3325 == nil { ifn_3326 = lang.IFn_Cast(root_3324) } else { ifn_3326 = nil }; var arg_3327 any = map__1685000372__6; if linked_3325 == nil { map__1685000372__7 = ifn_3326.Invoke_O__O(arg_3327) } else { map__1685000372__7 = linked_3325.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3324, arg_3327) } } else { map__1685000372__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000372__7 = map__1685000372__6 }
//line :502:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_288); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000372__7, A_arbace_go_check_A_const_289); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_288, dir__8)); var root_3328 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3330 lang.IFn










				if linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any = jobs__1; var arg_3332 any; var fnbody__3377 any = A_arbace_go_check_check_corpus_fn__1685000374_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp9 *jrt.Class; var fncls__3376 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class
				if fncls__3376 == nil { var fncls__3376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__3377); A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class = fncls__3376d; tmp9 = fncls__3376d } else { tmp9 = fncls__3376 }; arg_3332 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3377, tmp9, nil)
//line :513:1
				var arg_3333 any; var root_3378 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3380 lang.IFn








				if linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any = root__10; var arg_3382 any = sub__9; if linked_3379 == nil { arg_3333 = ifn_3380.Invoke_O_O__O(arg_3381, arg_3382) } else { arg_3333 = linked_3379.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3378, arg_3381, arg_3382) }
//line :513:1
				if linked_3329 == nil { return ifn_3330.Invoke_O_O_O__O(arg_3331, arg_3332, arg_3333) } else { return linked_3329.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3328, arg_3331, arg_3332, arg_3333) } } else {
//line :502:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_287.Invoke_O__O(cc__3)) { var map__1685000376__6 any = A_arbace_go_check_A_const_287.Invoke_O__O(cc__3); var map__1685000376__7 any





















						if lang.ISeq_InstanceOf(map__1685000376__6) { var tmp10 any; var root_3383 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3383, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3385 lang.IFn; if linked_3384 == nil { ifn_3385 = lang.IFn_Cast(root_3383) } else { ifn_3385 = nil }; var arg_3386 any = map__1685000376__6; if linked_3384 == nil { tmp10 = ifn_3385.Invoke_O__O(arg_3386) } else { tmp10 = linked_3384.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3383, arg_3386) }; if jrt.J2g_Truth(tmp10) { var tmp11 any; var root_3387 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3387, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3389 lang.IFn; if linked_3388 == nil { ifn_3389 = lang.IFn_Cast(root_3387) } else { ifn_3389 = nil }; var arg_3390 any = map__1685000376__6; if linked_3388 == nil { tmp11 = ifn_3389.Invoke_O__O(arg_3390) } else { tmp11 = linked_3388.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3387, arg_3390) }; map__1685000376__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp11)).Ref() } else { var tmp12 any; var root_3391 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3391, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3393 lang.IFn; if linked_3392 == nil { ifn_3393 = lang.IFn_Cast(root_3391) } else { ifn_3393 = nil }; var arg_3394 any = map__1685000376__6; if linked_3392 == nil { tmp12 = ifn_3393.Invoke_O__O(arg_3394) } else { tmp12 = linked_3392.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3391, arg_3394) }; if jrt.J2g_Truth(tmp12) { var root_3395 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = map__1685000376__6; if linked_3396 == nil { map__1685000376__7 = ifn_3397.Invoke_O__O(arg_3398) } else { map__1685000376__7 = linked_3396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3395, arg_3398) } } else { map__1685000376__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000376__7 = map__1685000376__6 }
//line :502:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000376__7, A_arbace_go_check_A_const_288); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000376__7, A_arbace_go_check_A_const_289); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_288, dir__8_2)); var pfs__11 any; var root_3399 any = A_arbace_go_check_A_const_318.GetRawRoot__O(); var linked_3400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3399, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_3401 lang.IFn























						if linked_3400 == nil { ifn_3401 = lang.IFn_Cast(root_3399) } else { ifn_3401 = nil }; var arg_3402 any = root__10_2; var arg_3403 any = sub__9_2; if linked_3400 == nil { pfs__11 = ifn_3401.Invoke_O_O__O(arg_3402, arg_3403) } else { pfs__11 = linked_3400.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_3399, arg_3402, arg_3403) }
//line :502:1
						var tests__12 any; var root_3404 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_3406 lang.IFn

























						if linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var arg_3407 any; var fnbody__3415 any = A_arbace_go_check_check_corpus_fn__1685000378_A_New(); var tmp13 *jrt.Class; var fncls__3414 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class; if fncls__3414 == nil { var fncls__3414d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class = fncls__3414d; tmp13 = fncls__3414d } else { tmp13 = fncls__3414 }; arg_3407 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3415, tmp13, nil); var arg_3408 any = pfs__11; if linked_3405 == nil { tests__12 = ifn_3406.Invoke_O_O__O(arg_3407, arg_3408) } else { tests__12 = linked_3405.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_3404, arg_3407, arg_3408)
						}


						var root_3416 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3416, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3418 lang.IFn; if linked_3417 == nil { ifn_3418 = lang.IFn_Cast(root_3416) } else { ifn_3418 = nil }; var arg_3419 any; var root_3420 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3420, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3422 lang.IFn; if linked_3421 == nil { ifn_3422 = lang.IFn_Cast(root_3420) } else { ifn_3422 = nil }; var arg_3423 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var arg_3424 any; var root_3425 any = A_arbace_go_check_A_const_319.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, A_arbace_go_check_run_parallel_A_fn_class); var ifn_3427 lang.IFn
						if linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any = jobs__1; var arg_3429 any; var fnbody__3669 any = A_arbace_go_check_check_corpus_fn__1685000384_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp14 *jrt.Class; var fncls__3668 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class
						if fncls__3668 == nil { var fncls__3668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__3669); A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class = fncls__3668d; tmp14 = fncls__3668d } else { tmp14 = fncls__3668 }; arg_3429 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3669, tmp14, nil)
//line :533:1
						var arg_3430 any; var root_3670 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_3671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3670, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3672 lang.IFn














						if linked_3671 == nil { ifn_3672 = lang.IFn_Cast(root_3670) } else { ifn_3672 = nil }; var arg_3673 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); var arg_3674 any = tests__12; if linked_3671 == nil { arg_3430 = ifn_3672.Invoke_O_O__O(arg_3673, arg_3674) } else { arg_3430 = linked_3671.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3670, arg_3673, arg_3674) }
//line :533:1
						if linked_3426 == nil { arg_3424 = ifn_3427.Invoke_O_O_O__O(arg_3428, arg_3429, arg_3430) } else { arg_3424 = linked_3426.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_3425, arg_3428, arg_3429, arg_3430) }
//line :532:1
						if linked_3421 == nil { arg_3419 = ifn_3422.Invoke_O_O__O(arg_3423, arg_3424) } else { arg_3419 = linked_3421.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_3420, arg_3423, arg_3424) }; if linked_3417 == nil { return ifn_3418.Invoke_O__O(arg_3419) } else { return linked_3417.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3416, arg_3419) } } else {
//line :502:1
							return nil } } } }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_New() *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A) Ctor() {}
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A) Invoke_O_O__O(self, s__1685000361__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3280 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_New_O_O(s__1685000361__1, self); var tmp2 *jrt.Class; var fncls__3279 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class; if fncls__3279 == nil { var fncls__3279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__3280); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class = fncls__3279d; tmp2 = fncls__3279d } else { tmp2 = fncls__3279 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3280, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A{}; t.Ctor_O_O(p0, p1); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A) Ctor_O_O(c__s__1685000361, c__iter__1685000360 any) { t.F_s__1685000361 = c__s__1685000361; t.F_iter__1685000360 = c__iter__1685000360 }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A) Invoke_O__O(self any) any { { var s__1685000361__1 any; var t_ any = t.F_s__1685000361; t.F_s__1685000361 = nil; s__1685000361__1 = t_; for { var temp__1927000414__auto____2 any; var root_3213 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = s__1685000361__1; if linked_3214 == nil { temp__1927000414__auto____2 = ifn_3215.Invoke_O__O(arg_3216) } else { temp__1927000414__auto____2 = linked_3214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3213, arg_3216) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000361__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3217 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3219 lang.IFn; if linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any = s__1685000361__3; if linked_3218 == nil { tmp1 = ifn_3219.Invoke_O__O(arg_3220) } else { tmp1 = linked_3218.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3217, arg_3220) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3221 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3223 lang.IFn; if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = s__1685000361__3; if linked_3222 == nil { c__1927001037__auto____4 = ifn_3223.Invoke_O__O(arg_3224) } else { c__1927001037__auto____4 = linked_3222.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3221, arg_3224) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000363__6 any; var root_3225 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3225, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3227 lang.IFn; if linked_3226 == nil { ifn_3227 = lang.IFn_Cast(root_3225) } else { ifn_3227 = nil }; var arg_3228 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3226 == nil { b__1685000363__6 = ifn_3227.Invoke_O__O(arg_3228) } else { b__1685000363__6 = linked_3226.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3225, arg_3228) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3239 any = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1685000363__6); var tmp3 *jrt.Class; var fncls__3238 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class; if fncls__3238 == nil { var fncls__3238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__3239); A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class = fncls__3238d; tmp3 = fncls__3238d } else { tmp3 = fncls__3238 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3239, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3240 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3240, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3242 lang.IFn; if linked_3241 == nil { ifn_3242 = lang.IFn_Cast(root_3240) } else { ifn_3242 = nil }; var arg_3243 any; var root_3245 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3245, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3247 lang.IFn; if linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any = b__1685000363__6; if linked_3246 == nil { arg_3243 = ifn_3247.Invoke_O__O(arg_3248) } else { arg_3243 = linked_3246.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3245, arg_3248) }; var arg_3244 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000360); var tmp5 any; var root_3249 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3249, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3251 lang.IFn; if linked_3250 == nil { ifn_3251 = lang.IFn_Cast(root_3249) } else { ifn_3251 = nil }; var arg_3252 any = s__1685000361__3; if linked_3250 == nil { tmp5 = ifn_3251.Invoke_O__O(arg_3252) } else { tmp5 = linked_3250.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3249, arg_3252) }; arg_3244 = tmp4.Invoke_O__O(tmp5); if linked_3241 == nil { return ifn_3242.Invoke_O_O__O(arg_3243, arg_3244) } else { return linked_3241.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3240, arg_3243, arg_3244) } } else { var root_3253 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3253, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3255 lang.IFn; if linked_3254 == nil { ifn_3255 = lang.IFn_Cast(root_3253) } else { ifn_3255 = nil }; var arg_3256 any; var root_3258 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3258, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3260 lang.IFn; if linked_3259 == nil { ifn_3260 = lang.IFn_Cast(root_3258) } else { ifn_3260 = nil }; var arg_3261 any = b__1685000363__6; if linked_3259 == nil { arg_3256 = ifn_3260.Invoke_O__O(arg_3261) } else { arg_3256 = linked_3259.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3258, arg_3261) }; var arg_3257 any; if linked_3254 == nil { return ifn_3255.Invoke_O_O__O(arg_3256, arg_3257) } else { return linked_3254.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3253, arg_3256, arg_3257) } } } else { var pf__4 any; var root_3262 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = s__1685000361__3; if linked_3263 == nil { pf__4 = ifn_3264.Invoke_O__O(arg_3265) } else { pf__4 = linked_3263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3262, arg_3265) }; var root_3266 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3266, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3268 lang.IFn; if linked_3267 == nil { ifn_3268 = lang.IFn_Cast(root_3266) } else { ifn_3268 = nil }; var arg_3269 any; var root_3271 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3271, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3273 lang.IFn
															if linked_3272 == nil { ifn_3273 = lang.IFn_Cast(root_3271) } else { ifn_3273 = nil }; var arg_3274 any = pf__4; if linked_3272 == nil { arg_3269 = ifn_3273.Invoke_O__O(arg_3274) } else { arg_3269 = linked_3272.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3271, arg_3274) }
//line :500:1
	var arg_3270 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000360); var tmp7 any; var root_3275 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3275, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3277 lang.IFn; if linked_3276 == nil { ifn_3277 = lang.IFn_Cast(root_3275) } else { ifn_3277 = nil }; var arg_3278 any = s__1685000361__3; if linked_3276 == nil { tmp7 = ifn_3277.Invoke_O__O(arg_3278) } else { tmp7 = linked_3276.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3275, arg_3278) }; arg_3270 = tmp6.Invoke_O__O(tmp7); if linked_3267 == nil { return ifn_3268.Invoke_O_O__O(arg_3269, arg_3270) } else { return linked_3267.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3266, arg_3269, arg_3270) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000363 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000363 = c__b__1685000363 }
//line :500:1
func (t *A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A) Invoke_O__O(self any) any { { var i__1685000362__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000362__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000362__1)); var root_3229 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3229, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3231 lang.IFn; if linked_3230 == nil { ifn_3231 = lang.IFn_Cast(root_3229) } else { ifn_3231 = nil }; var arg_3232 any = t.F_b__1685000363; var arg_3233 any; var root_3234 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3236 lang.IFn
																if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = pf__2; if linked_3235 == nil { arg_3233 = ifn_3236.Invoke_O__O(arg_3237) } else { arg_3233 = linked_3235.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3234, arg_3237) }
//line :500:1
	if linked_3230 == nil { ifn_3231.Invoke_O_O__O(arg_3232, arg_3233) } else { linked_3230.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3229, arg_3232, arg_3233) }; i__1685000362__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000362__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000370_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000370_A{}; t.Ctor_O(p0); return t }
//line :505:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :505:1
func (t *A_arbace_go_check_check_corpus_fn__1685000370_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_3294 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3294, A_arbace_go_check_result_of_A_fn_class); var ifn_3296 lang.IFn
												if linked_3295 == nil { ifn_3296 = lang.IFn_Cast(root_3294) } else { ifn_3296 = nil }; var arg_3297 any; var root_3298 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3300 lang.IFn; if linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any = t.F_s; var arg_3302 any = path__1; var arg_3303 any; var arg_3304 any = lang.PersistentVector_EMPTY.Ref(); if linked_3299 == nil { arg_3297 = ifn_3300.Invoke_O_O_O_O__O(arg_3301, arg_3302, arg_3303, arg_3304) } else { arg_3297 = linked_3299.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3298, arg_3301, arg_3302, arg_3303, arg_3304) }; if linked_3295 == nil { or__1927000174__auto____4 = ifn_3296.Invoke_O__O(arg_3297) } else { or__1927000174__auto____4 = linked_3295.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3294, arg_3297) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111, path__1, A_arbace_go_check_A_const_321, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :505:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_3305 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, A_arbace_go_check_error_result_A_fn_class); var ifn_3307 lang.IFn


		if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = path__1; var arg_3309 any = ex__4; if linked_3306 == nil { tmp1 = ifn_3307.Invoke_O_O__O(arg_3308, arg_3309) } else { tmp1 = linked_3306.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3305, arg_3308, arg_3309) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000374_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000374_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000374_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :514:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :514:1
func (t *A_arbace_go_check_check_corpus_fn__1685000374_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_3334 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3336 lang.IFn

	if linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = t.F_root; var arg_3338 any; var arg_3339 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_cc); var arg_3340 any = pf__1; if linked_3335 == nil { src__4 = ifn_3336.Invoke_O_O_O_O__O(arg_3337, arg_3338, arg_3339, arg_3340) } else { src__4 = linked_3335.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3334, arg_3337, arg_3338, arg_3339, arg_3340) }
	var tmp2 any; var root_3341 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_3342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3341, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3343 lang.IFn; if linked_3342 == nil { ifn_3343 = lang.IFn_Cast(root_3341) } else { ifn_3343 = nil }; var arg_3344 any = A_arbace_go_check_A_const_125.Invoke_O__O(src__4); if linked_3342 == nil { tmp2 = ifn_3343.Invoke_O__O(arg_3344) } else { tmp2 = linked_3342.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3341, arg_3344) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_111; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.File_Cast(pf__1).GetPath__String().Ref(), A_arbace_go_check_A_const_321, jrt.Boolean_TRUE.Ref())) } else {

		var root_3345 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3346 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3345, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3347 lang.IFn; if linked_3346 == nil { ifn_3347 = lang.IFn_Cast(root_3345) } else { ifn_3347 = nil }; var arg_3348 any; var root_3351 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3351, A_arbace_go_check_result_of_A_fn_class); var ifn_3353 lang.IFn; if linked_3352 == nil { ifn_3353 = lang.IFn_Cast(root_3351) } else { ifn_3353 = nil }; var arg_3354 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp5 any; var root_3360 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_3361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3360, A_arbace_go_check_resolver_A_fn_class); var ifn_3362 lang.IFn; if linked_3361 == nil { ifn_3362 = lang.IFn_Cast(root_3360) } else { ifn_3362 = nil }; var arg_3363 any = t.F_s; var arg_3364 any = src__4; var arg_3365 any = lang.PersistentVector_EMPTY.Ref(); if linked_3361 == nil { tmp5 = ifn_3362.Invoke_O_O_O__O(arg_3363, arg_3364, arg_3365) } else { tmp5 = linked_3361.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3360, arg_3363, arg_3364, arg_3365) }; arg_3354 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_3352 == nil { arg_3348 = ifn_3353.Invoke_O__O(arg_3354) } else { arg_3348 = linked_3352.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3351, arg_3354) }; var arg_3349 any = A_arbace_go_check_A_const_111; var arg_3350 any; var root_3366 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3366, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3368 lang.IFn
		if linked_3367 == nil { ifn_3368 = lang.IFn_Cast(root_3366) } else { ifn_3368 = nil }; var arg_3369 any = jrt.File_Cast(pf__1).GetPath__String().Ref(); var arg_3370 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_3367 == nil { arg_3350 = ifn_3368.Invoke_O_O__O(arg_3369, arg_3370) } else { arg_3350 = linked_3367.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3366, arg_3369, arg_3370) }
//line :519:1
		if linked_3346 == nil { tmp1 = ifn_3347.Invoke_O_O_O__O(arg_3348, arg_3349, arg_3350) } else { tmp1 = linked_3346.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3345, arg_3348, arg_3349, arg_3350) } } }; return nil }(); if /*line :514:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_3371 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, A_arbace_go_check_error_result_A_fn_class); var ifn_3373 lang.IFn






			if linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = jrt.File_Cast(pf__1).GetPath__String().Ref(); var arg_3375 any = ex__4; if linked_3372 == nil { tmp1 = ifn_3373.Invoke_O_O__O(arg_3374, arg_3375) } else { tmp1 = linked_3372.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3371, arg_3374, arg_3375) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000378_A_New() *A_arbace_go_check_check_corpus_fn__1685000378_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000378_A{}; t.Ctor(); return t }
//line :528:1
func (t *A_arbace_go_check_check_corpus_fn__1685000378_A) Ctor() {}
//line :528:1
func (t *A_arbace_go_check_check_corpus_fn__1685000378_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.File_Cast(pf__1).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_3409 any = A_arbace_go_check_A_const_325.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3411 lang.IFn; if

	linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any = A_arbace_go_check_A_const_326; var arg_3413 any = p__2; if linked_3410 == nil { temp__1927000408__auto____3 = ifn_3411.Invoke_O_O__O(arg_3412, arg_3413) } else { temp__1927000408__auto____3 = linked_3410.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3409, arg_3412, arg_3413) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000379__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000379__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000384_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :534:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_A) Invoke_O_O__O(self, p__1685000383__1 any) any { var vec__1685000385__2 any = p__1685000383__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000385__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_3431 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3433 lang.IFn

	if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3435 any; var iter__1927001039__auto____7 any; var fnbody__3505 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_New(); var tmp2 *jrt.Class; var fncls__3504 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class; if fncls__3504 == nil { var fncls__3504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class = fncls__3504d; tmp2 = fncls__3504d } else { tmp2 = fncls__3504 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3505, tmp2, nil); arg_3435 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_3432 == nil { by_path__7 = ifn_3433.Invoke_O_O__O(arg_3434, arg_3435) } else { by_path__7 = linked_3432.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3431, arg_3434, arg_3435) }
//line :534:1
	var ts__8 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_106.GetRawRoot__O()); var tmp4 any; var root_3514 any = A_arbace_go_check_A_const_304.GetRawRoot__O(); var linked_3515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3514, A_arbace_go_check_session_A_fn_class); var ifn_3516 lang.IFn



	if linked_3515 == nil { ifn_3516 = lang.IFn_Cast(root_3514) } else { ifn_3516 = nil }; var arg_3517 any; var fnbody__3526 any = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp5 *jrt.Class; var fncls__3525 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class; if fncls__3525 == nil { var fncls__3525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__3526); A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class = fncls__3525d; tmp5 = fncls__3525d } else { tmp5 = fncls__3525 }; arg_3517 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3526, tmp5, nil); if linked_3515 == nil { tmp4 = ifn_3516.Invoke_O__O(arg_3517) } else { tmp4 = linked_3515.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_3514, arg_3517) }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_A_const_266; var tmp8 any = t.F_s; var tmp9 any = A_arbace_go_check_A_const_275; var tmp10 *lang.Compiler_AOTFn; var fnbody__3533 any = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_New_O(by_path__7); var tmp11 *jrt.Class; var fncls__3532 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class; if fncls__3532 == nil { var fncls__3532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__3533); A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class = fncls__3532d; tmp11 = fncls__3532d } else { tmp11 = fncls__3532 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3533, tmp11, nil); ts__8 = tmp3.Invoke_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9, tmp10.Ref())



	var root_3534 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any; var iter__1927001039__auto____9 any; var fnbody__3657 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp12 *jrt.Class; var fncls__3656 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class; if fncls__3656 == nil { var fncls__3656d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__3657); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class = fncls__3656d; tmp12 = fncls__3656d } else { tmp12 = fncls__3656 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3657, tmp12, nil); var tmp13 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp14 any; var root_3658 any = A_arbace_go_check_A_const_102.GetRawRoot__O(); var linked_3659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3658, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3660 lang.IFn; if linked_3659 == nil { ifn_3660 = lang.IFn_Cast(root_3658) } else { ifn_3660 = nil }; var arg_3661 any = A_arbace_go_check_A_const_330.GetRawRoot__O(); var arg_3662 any = by_path__7; if linked_3659 == nil { tmp14 = ifn_3660.Invoke_O_O__O(arg_3661, arg_3662) } else { tmp14 = linked_3659.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3658, arg_3661, arg_3662) }; arg_3537 = tmp13.Invoke_O__O(tmp14); if linked_3535 == nil { tmp1 = ifn_3536.Invoke_O__O(arg_3537) } else { tmp1 = linked_3535.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3534, arg_3537) } }; return nil }(); if /*line :534:1*/ tmp15 != nil { if true { var ex__7 jrt.Throwable_I = tmp15; var tmp16 any; var root_3663 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3663, A_arbace_go_check_error_result_A_fn_class); var ifn_3665 lang.IFn












		if linked_3664 == nil { ifn_3665 = lang.IFn_Cast(root_3663) } else { ifn_3665 = nil }; var arg_3666 any = tdir__3; var arg_3667 any = ex__7; if linked_3664 == nil { tmp16 = ifn_3665.Invoke_O_O__O(arg_3666, arg_3667) } else { tmp16 = linked_3664.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3663, arg_3666, arg_3667) }
//line :534:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp16) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_New() *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A) Ctor() {}
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A) Invoke_O_O__O(self, s__1685000389__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3503 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_New_O_O(s__1685000389__1, self); var tmp2 *jrt.Class; var fncls__3502 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class; if fncls__3502 == nil { var fncls__3502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__3503); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class = fncls__3502d; tmp2 = fncls__3502d } else { tmp2 = fncls__3502 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3503, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :536:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A) Ctor_O_O(c__s__1685000389, c__iter__1685000388 any) { t.F_s__1685000389 = c__s__1685000389; t.F_iter__1685000388 = c__iter__1685000388 }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A) Invoke_O__O(self any) any { { var s__1685000389__1 any; var t_ any = t.F_s__1685000389; t.F_s__1685000389 = nil; s__1685000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_3436 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3438 lang.IFn; if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = s__1685000389__1; if linked_3437 == nil { temp__1927000414__auto____2 = ifn_3438.Invoke_O__O(arg_3439) } else { temp__1927000414__auto____2 = linked_3437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3436, arg_3439) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3440 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3442 lang.IFn; if linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any = s__1685000389__3; if linked_3441 == nil { tmp1 = ifn_3442.Invoke_O__O(arg_3443) } else { tmp1 = linked_3441.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3440, arg_3443) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3444 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3444, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3446 lang.IFn; if linked_3445 == nil { ifn_3446 = lang.IFn_Cast(root_3444) } else { ifn_3446 = nil }; var arg_3447 any = s__1685000389__3; if linked_3445 == nil { c__1927001037__auto____4 = ifn_3446.Invoke_O__O(arg_3447) } else { c__1927001037__auto____4 = linked_3445.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3444, arg_3447) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000391__6 any; var root_3448 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3448, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3450 lang.IFn; if linked_3449 == nil { ifn_3450 = lang.IFn_Cast(root_3448) } else { ifn_3450 = nil }; var arg_3451 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3449 == nil { b__1685000391__6 = ifn_3450.Invoke_O__O(arg_3451) } else { b__1685000391__6 = linked_3449.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3448, arg_3451) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3462 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_New_O_I_O(b__1685000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3461 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class; if fncls__3461 == nil { var fncls__3461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__3462); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class = fncls__3461d; tmp3 = fncls__3461d } else { tmp3 = fncls__3461 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3462, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3463 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3463, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3465 lang.IFn; if linked_3464 == nil { ifn_3465 = lang.IFn_Cast(root_3463) } else { ifn_3465 = nil }; var arg_3466 any; var root_3468 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3470 lang.IFn; if linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any = b__1685000391__6; if linked_3469 == nil { arg_3466 = ifn_3470.Invoke_O__O(arg_3471) } else { arg_3466 = linked_3469.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3468, arg_3471) }; var arg_3467 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000388); var tmp5 any; var root_3472 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3472, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3474 lang.IFn; if linked_3473 == nil { ifn_3474 = lang.IFn_Cast(root_3472) } else { ifn_3474 = nil }; var arg_3475 any = s__1685000389__3; if linked_3473 == nil { tmp5 = ifn_3474.Invoke_O__O(arg_3475) } else { tmp5 = linked_3473.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3472, arg_3475) }; arg_3467 = tmp4.Invoke_O__O(tmp5); if linked_3464 == nil { return ifn_3465.Invoke_O_O__O(arg_3466, arg_3467) } else { return linked_3464.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3463, arg_3466, arg_3467) } } else { var root_3476 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3476, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3478 lang.IFn; if linked_3477 == nil { ifn_3478 = lang.IFn_Cast(root_3476) } else { ifn_3478 = nil }; var arg_3479 any; var root_3481 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3481, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3483 lang.IFn; if linked_3482 == nil { ifn_3483 = lang.IFn_Cast(root_3481) } else { ifn_3483 = nil }; var arg_3484 any = b__1685000391__6; if linked_3482 == nil { arg_3479 = ifn_3483.Invoke_O__O(arg_3484) } else { arg_3479 = linked_3482.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3481, arg_3484) }; var arg_3480 any; if linked_3477 == nil { return ifn_3478.Invoke_O_O__O(arg_3479, arg_3480) } else { return linked_3477.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3476, arg_3479, arg_3480) } } } else { var pf__4 any; var root_3485 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3485, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3487 lang.IFn; if linked_3486 == nil { ifn_3487 = lang.IFn_Cast(root_3485) } else { ifn_3487 = nil }; var arg_3488 any = s__1685000389__3; if linked_3486 == nil { pf__4 = ifn_3487.Invoke_O__O(arg_3488) } else { pf__4 = linked_3486.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3485, arg_3488) }; var root_3489 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3489, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3491 lang.IFn; if linked_3490 == nil { ifn_3491 = lang.IFn_Cast(root_3489) } else { ifn_3491 = nil }; var arg_3492 any; var tmp6 any; var root_3494 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3494, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3496 lang.IFn; if linked_3495 == nil { ifn_3496 = lang.IFn_Cast(root_3494) } else { ifn_3496 = nil }; var arg_3497 any = pf__4; if linked_3495 == nil { tmp6 = ifn_3496.Invoke_O__O(arg_3497) } else { tmp6 = linked_3495.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3494, arg_3497) }; arg_3492 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_3493 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000388); var tmp8 any; var root_3498 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3500 lang.IFn; if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = s__1685000389__3; if linked_3499 == nil { tmp8 = ifn_3500.Invoke_O__O(arg_3501) } else { tmp8 = linked_3499.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3498, arg_3501) }; arg_3493 = tmp7.Invoke_O__O(tmp8); if linked_3490 == nil { return ifn_3491.Invoke_O_O__O(arg_3492, arg_3493) } else { return linked_3490.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3489, arg_3492, arg_3493) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :536:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A) Ctor_O_I_O(c__b__1685000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000391 = c__b__1685000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :536:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A) Invoke_O__O(self any) any { { var i__1685000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000390__1)); var root_3452 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3452, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3454 lang.IFn; if linked_3453 == nil { ifn_3454 = lang.IFn_Cast(root_3452) } else { ifn_3454 = nil }; var arg_3455 any = t.F_b__1685000391; var arg_3456 any; var tmp2 any; var root_3457 any = A_arbace_go_check_A_const_317.GetRawRoot__O(); var linked_3458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3457, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_3459 lang.IFn; if linked_3458 == nil { ifn_3459 = lang.IFn_Cast(root_3457) } else { ifn_3459 = nil }; var arg_3460 any = pf__2; if linked_3458 == nil { tmp2 = ifn_3459.Invoke_O__O(arg_3460) } else { tmp2 = linked_3458.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_3457, arg_3460) }; arg_3456 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_3453 == nil { ifn_3454.Invoke_O_O__O(arg_3455, arg_3456) } else { linked_3453.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3452, arg_3455, arg_3456) }; i__1685000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_3518 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3520 lang.IFn
																	if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any = t.F_root; var arg_3522 any = path__1; var arg_3523 any = A_arbace_go_check_A_const_112.Invoke_O__O(t.F_cc); var arg_3524 any = pf__4; if linked_3519 == nil { return ifn_3520.Invoke_O_O_O_O__O(arg_3521, arg_3522, arg_3523, arg_3524) } else { return linked_3519.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3518, arg_3521, arg_3522, arg_3523, arg_3524) } } else {
//line :539:1
			return nil } }
//line :538:1
func A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A{}; t.Ctor_O(p0); return t }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :538:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A) Invoke_O_O__O(self, p1__1685000359_SHARP___1 any) any {


	var root_3527 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_3528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3527, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3529 lang.IFn; if linked_3528 == nil { ifn_3529 = lang.IFn_Cast(root_3527) } else { ifn_3529 = nil }; var arg_3530 any = t.F_by_path; var arg_3531 any = p1__1685000359_SHARP___1; if linked_3528 == nil { return ifn_3529.Invoke_O_O__O(arg_3530, arg_3531) } else { return linked_3528.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3527, arg_3530, arg_3531) } }
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A) Invoke_O_O__O(self, s__1685000403__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3655 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_New_O_O_O_O_O(self, t.F_dir, t.F_tdir, t.F_ts, s__1685000403__1); var tmp2 *jrt.Class; var fncls__3654 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class; if fncls__3654 == nil { var fncls__3654d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__3655); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class = fncls__3654d; tmp2 = fncls__3654d } else { tmp2 = fncls__3654 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3655, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A) Ctor_O_O_O_O_O(c__iter__1685000402, c__dir, c__tdir, c__ts, c__s__1685000403 any) { t.F_iter__1685000402 = c__iter__1685000402; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1685000403 = c__s__1685000403 }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A) Invoke_O__O(self any) any { { var s__1685000403__1 any; var t_ any = t.F_s__1685000403; t.F_s__1685000403 = nil; s__1685000403__1 = t_; for { var temp__1927000414__auto____2 any; var root_3538 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3538, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3540 lang.IFn; if linked_3539 == nil { ifn_3540 = lang.IFn_Cast(root_3538) } else { ifn_3540 = nil }; var arg_3541 any = s__1685000403__1; if linked_3539 == nil { temp__1927000414__auto____2 = ifn_3540.Invoke_O__O(arg_3541) } else { temp__1927000414__auto____2 = linked_3539.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3538, arg_3541) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000403__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3542 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3542, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3544 lang.IFn; if linked_3543 == nil { ifn_3544 = lang.IFn_Cast(root_3542) } else { ifn_3544 = nil }; var arg_3545 any = s__1685000403__3; if linked_3543 == nil { tmp1 = ifn_3544.Invoke_O__O(arg_3545) } else { tmp1 = linked_3543.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3542, arg_3545) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3546 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3546, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3548 lang.IFn; if linked_3547 == nil { ifn_3548 = lang.IFn_Cast(root_3546) } else { ifn_3548 = nil }; var arg_3549 any = s__1685000403__3; if linked_3547 == nil { c__1927001037__auto____4 = ifn_3548.Invoke_O__O(arg_3549) } else { c__1927001037__auto____4 = linked_3547.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3546, arg_3549) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000405__6 any; var root_3550 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3552 lang.IFn; if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3551 == nil { b__1685000405__6 = ifn_3552.Invoke_O__O(arg_3553) } else { b__1685000405__6 = linked_3551.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3550, arg_3553) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3589 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_New_O_O_O_O_I_O(t.F_dir, b__1685000405__6, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3588 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class; if fncls__3588 == nil { var fncls__3588d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__3589); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class = fncls__3588d; tmp3 = fncls__3588d } else { tmp3 = fncls__3588 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3589, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3590 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3590, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3592 lang.IFn; if linked_3591 == nil { ifn_3592 = lang.IFn_Cast(root_3590) } else { ifn_3592 = nil }; var arg_3593 any; var root_3595 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3595, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3597 lang.IFn; if linked_3596 == nil { ifn_3597 = lang.IFn_Cast(root_3595) } else { ifn_3597 = nil }; var arg_3598 any = b__1685000405__6; if linked_3596 == nil { arg_3593 = ifn_3597.Invoke_O__O(arg_3598) } else { arg_3593 = linked_3596.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3595, arg_3598) }; var arg_3594 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000402); var tmp5 any; var root_3599 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3599, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3601 lang.IFn; if linked_3600 == nil { ifn_3601 = lang.IFn_Cast(root_3599) } else { ifn_3601 = nil }; var arg_3602 any = s__1685000403__3; if linked_3600 == nil { tmp5 = ifn_3601.Invoke_O__O(arg_3602) } else { tmp5 = linked_3600.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3599, arg_3602) }; arg_3594 = tmp4.Invoke_O__O(tmp5); if linked_3591 == nil { return ifn_3592.Invoke_O_O__O(arg_3593, arg_3594) } else { return linked_3591.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3590, arg_3593, arg_3594) } } else { var root_3603 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3603, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3605 lang.IFn; if linked_3604 == nil { ifn_3605 = lang.IFn_Cast(root_3603) } else { ifn_3605 = nil }; var arg_3606 any; var root_3608 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = b__1685000405__6; if linked_3609 == nil { arg_3606 = ifn_3610.Invoke_O__O(arg_3611) } else { arg_3606 = linked_3609.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3608, arg_3611) }; var arg_3607 any; if linked_3604 == nil { return ifn_3605.Invoke_O_O__O(arg_3606, arg_3607) } else { return linked_3604.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3603, arg_3606, arg_3607) } } } else { var vec__1685000415__4 any; var root_3612 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3612, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3614 lang.IFn; if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = s__1685000403__3; if linked_3613 == nil { vec__1685000415__4 = ifn_3614.Invoke_O__O(arg_3615) } else { vec__1685000415__4 = linked_3613.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3612, arg_3615) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000415__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000415__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3616 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3616, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3618 lang.IFn; _ = pf__6; if linked_3617 == nil { ifn_3618 = lang.IFn_Cast(root_3616) } else { ifn_3618 = nil }; var arg_3619 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__3649 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__3648 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class
																if fncls__3648 == nil { var fncls__3648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__3649); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class = fncls__3648d; tmp7 = fncls__3648d } else { tmp7 = fncls__3648 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3649, tmp7, nil); arg_3619 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :542:1
	var arg_3620 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000402); var tmp9 any; var root_3650 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3650, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3652 lang.IFn; if linked_3651 == nil { ifn_3652 = lang.IFn_Cast(root_3650) } else { ifn_3652 = nil }; var arg_3653 any = s__1685000403__3; if linked_3651 == nil { tmp9 = ifn_3652.Invoke_O__O(arg_3653) } else { tmp9 = linked_3651.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3650, arg_3653) }; arg_3620 = tmp8.Invoke_O__O(tmp9); if linked_3617 == nil { return ifn_3618.Invoke_O_O__O(arg_3619, arg_3620) } else { return linked_3617.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3616, arg_3619, arg_3620) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :542:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A) Ctor_O_O_O_O_I_O(c__dir, c__b__1685000405, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__1685000405 = c__b__1685000405; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :542:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A) Invoke_O__O(self any) any { { var i__1685000404__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000404__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000409__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000404__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000409__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000409__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3554 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3554, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3556 lang.IFn; _ = pf__4; if linked_3555 == nil { ifn_3556 = lang.IFn_Cast(root_3554) } else { ifn_3556 = nil }; var arg_3557 any = t.F_b__1685000405; var arg_3558 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__3587 any = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__3586 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class
																		if fncls__3586 == nil { var fncls__3586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__3587); A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class = fncls__3586d; tmp3 = fncls__3586d } else { tmp3 = fncls__3586 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3587, tmp3, nil); arg_3558 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :542:1
	if linked_3555 == nil { ifn_3556.Invoke_O_O__O(arg_3557, arg_3558) } else { linked_3555.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3554, arg_3557, arg_3558) }; i__1685000404__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000404__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_3559 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3560 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3559, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3561 lang.IFn; if linked_3560 == nil { ifn_3561 = lang.IFn_Cast(root_3559) } else { ifn_3561 = nil }; var arg_3562 any; var or__1927000174__auto____3 any; var root_3565 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3565, A_arbace_go_check_result_of_A_fn_class); var ifn_3567 lang.IFn; if linked_3566 == nil { ifn_3567 = lang.IFn_Cast(root_3565) } else { ifn_3567 = nil }; var arg_3568 any; var root_3569 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_3570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3569, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3571 lang.IFn; if linked_3570 == nil { ifn_3571 = lang.IFn_Cast(root_3569) } else { ifn_3571 = nil }; var arg_3572 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3572 = t_; var arg_3573 any = t.F_path; var arg_3574 any; var arg_3575 any = lang.PersistentVector_EMPTY.Ref(); if linked_3570 == nil { arg_3568 = ifn_3571.Invoke_O_O_O_O__O(arg_3572, arg_3573, arg_3574, arg_3575) } else { arg_3568 = linked_3570.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3569, arg_3572, arg_3573, arg_3574, arg_3575) }; if linked_3566 == nil { or__1927000174__auto____3 = ifn_3567.Invoke_O__O(arg_3568) } else { or__1927000174__auto____3 = linked_3566.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3565, arg_3568) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3562 = or__1927000174__auto____3 } else { arg_3562 = A_arbace_go_check_A_const_328 }; var arg_3563 any = A_arbace_go_check_A_const_111; var arg_3564 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3576 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3576, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3578 lang.IFn
																					if linked_3577 == nil { ifn_3578 = lang.IFn_Cast(root_3576) } else { ifn_3578 = nil }; var arg_3579 any = t.F_tdir; var arg_3580 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3580 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3577 == nil { tmp3 = ifn_3578.Invoke_O_O__O(arg_3579, arg_3580) } else { tmp3 = linked_3577.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3576, arg_3579, arg_3580) }; arg_3564 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :544:1
		if linked_3560 == nil { tmp1 = ifn_3561.Invoke_O_O_O__O(arg_3562, arg_3563, arg_3564) } else { tmp1 = linked_3560.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3559, arg_3562, arg_3563, arg_3564) } }
//line :543:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3581 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3581, A_arbace_go_check_error_result_A_fn_class); var ifn_3583 lang.IFn


		if linked_3582 == nil { ifn_3583 = lang.IFn_Cast(root_3581) } else { ifn_3583 = nil }; var arg_3584 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3584 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3585 any = ex__3; if linked_3582 == nil { tmp1 = ifn_3583.Invoke_O_O__O(arg_3584, arg_3585) } else { tmp1 = linked_3582.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3581, arg_3584, arg_3585) } } }; return tmp1 }
//line :543:1
func A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :543:1
func (t *A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_3621 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3621, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3623 lang.IFn; if linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any; var or__1927000174__auto____3 any; var root_3627 any = A_arbace_go_check_A_const_320.GetRawRoot__O(); var linked_3628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3627, A_arbace_go_check_result_of_A_fn_class); var ifn_3629 lang.IFn; if linked_3628 == nil { ifn_3629 = lang.IFn_Cast(root_3627) } else { ifn_3629 = nil }; var arg_3630 any; var root_3631 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, A_arbace_go_check_ensure_package_A_fn_class); var ifn_3633 lang.IFn; if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any; var t_ any = t.F_ts; t.F_ts = nil; arg_3634 = t_; var arg_3635 any = t.F_path; var arg_3636 any; var arg_3637 any = lang.PersistentVector_EMPTY.Ref(); if linked_3632 == nil { arg_3630 = ifn_3633.Invoke_O_O_O_O__O(arg_3634, arg_3635, arg_3636, arg_3637) } else { arg_3630 = linked_3632.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_3631, arg_3634, arg_3635, arg_3636, arg_3637) }; if linked_3628 == nil { or__1927000174__auto____3 = ifn_3629.Invoke_O__O(arg_3630) } else { or__1927000174__auto____3 = linked_3628.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_3627, arg_3630) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_3624 = or__1927000174__auto____3 } else { arg_3624 = A_arbace_go_check_A_const_329 }; var arg_3625 any = A_arbace_go_check_A_const_111; var arg_3626 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp3 any; var root_3638 any = A_arbace_go_check_A_const_323.GetRawRoot__O(); var linked_3639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3638, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_3640 lang.IFn
																			if linked_3639 == nil { ifn_3640 = lang.IFn_Cast(root_3638) } else { ifn_3640 = nil }; var arg_3641 any = t.F_tdir; var arg_3642 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_3642 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_3639 == nil { tmp3 = ifn_3640.Invoke_O_O__O(arg_3641, arg_3642) } else { tmp3 = linked_3639.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_3638, arg_3641, arg_3642) }; arg_3626 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :544:1
		if linked_3622 == nil { tmp1 = ifn_3623.Invoke_O_O_O__O(arg_3624, arg_3625, arg_3626) } else { tmp1 = linked_3622.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3621, arg_3624, arg_3625, arg_3626) } }
//line :543:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_3643 any = A_arbace_go_check_A_const_322.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, A_arbace_go_check_error_result_A_fn_class); var ifn_3645 lang.IFn


		if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_3646 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_3647 any = ex__3; if linked_3644 == nil { tmp1 = ifn_3645.Invoke_O_O__O(arg_3646, arg_3647) } else { tmp1 = linked_3644.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_3643, arg_3646, arg_3647) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :550:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :550:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_3675 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3677 lang.IFn; if


	linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any = A_arbace_go_check_A_const_321; var arg_3679 any = results__1; if linked_3676 == nil { rs__3 = ifn_3677.Invoke_O_O__O(arg_3678, arg_3679) } else { rs__3 = linked_3676.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3675, arg_3678, arg_3679) }; var sum__4 any; var fnbody__3692 any = /*line :550:1*/A_arbace_go_check_summarize_sum__1685000430_A_New_O(rs__3); var tmp1 *jrt.Class; var fncls__3691 *jrt.Class = A_arbace_go_check_summarize_sum__1685000430_A_fn_class; if



	fncls__3691 == nil { var fncls__3691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__3692); A_arbace_go_check_summarize_sum__1685000430_A_fn_class = fncls__3691d; tmp1 = fncls__3691d } else { tmp1 = fncls__3691 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3692, tmp1, nil); var msum__5 any; var fnbody__3706 any = /*line :550:1*/A_arbace_go_check_summarize_msum__1685000432_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__3705 *jrt.Class = A_arbace_go_check_summarize_msum__1685000432_A_fn_class; if




	fncls__3705 == nil { var fncls__3705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__3706); A_arbace_go_check_summarize_msum__1685000432_A_fn_class = fncls__3705d; tmp2 = fncls__3705d } else { tmp2 = fncls__3705 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3706, tmp2, nil); var tmp3 any = A_arbace_go_check_A_const_295; var tmp4 any = A_arbace_go_check_A_const_331; var tmp5 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp6 any = A_arbace_go_check_A_const_332; var tmp7 any = A_arbace_go_check_A_const_333; var tmp8 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_83); var tmp9 any = A_arbace_go_check_A_const_164; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_164); var tmp11 any = A_arbace_go_check_A_const_150; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_155); var tmp13 any = A_arbace_go_check_A_const_153; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_153); var tmp15 any = A_arbace_go_check_A_const_145; var tmp16 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_156))); var tmp17 any = A_arbace_go_check_A_const_238; var tmp18 lang.IFn = lang.IFn_Cast(sum__4); var tmp19 *lang.Compiler_AOTFn; var fnbody__3794 any = A_arbace_go_check_summarize_fn__1685000434_A_New(); var tmp20 *jrt.Class; var fncls__3793 *jrt.Class = A_arbace_go_check_summarize_fn__1685000434_A_fn_class; if












	fncls__3793 == nil { var fncls__3793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_go_check_summarize_fn__1685000434_A_fn_class = fncls__3793d; tmp20 = fncls__3793d } else { tmp20 = fncls__3793 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3794, tmp20, nil); var tmp21 any = /*line :550:1*/tmp18.Invoke_O__O(tmp19.Ref()); var tmp22 any = A_arbace_go_check_A_const_334; var tmp23 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_241); var tmp24 any = A_arbace_go_check_A_const_335; var tmp25 any; var root_3707 any = A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3707, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3709 lang.IFn; if














	linked_3708 == nil { ifn_3709 = lang.IFn_Cast(root_3707) } else { ifn_3709 = nil }; var arg_3710 any; var fnbody__3713 any = A_arbace_go_check_summarize_fn__1685000436_A_New(); var tmp26 *jrt.Class; var fncls__3712 *jrt.Class = A_arbace_go_check_summarize_fn__1685000436_A_fn_class; if fncls__3712 == nil { var fncls__3712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, nil); A_arbace_go_check_summarize_fn__1685000436_A_fn_class = fncls__3712d; tmp26 = fncls__3712d } else { tmp26 = fncls__3712 }; arg_3710 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3713, tmp26, nil); var arg_3711 any = rs__3; if linked_3708 == nil { tmp25 = ifn_3709.Invoke_O_O__O(arg_3710, arg_3711) } else { tmp25 = linked_3708.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3707, arg_3710, arg_3711) }; var tmp27 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp25)).Ref(); var tmp28 any = A_arbace_go_check_A_const_337; var tmp29 any; var root_3714 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3714, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3716 lang.IFn; if















	linked_3715 == nil { ifn_3716 = lang.IFn_Cast(root_3714) } else { ifn_3716 = nil }; var arg_3717 any; var root_3718 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3718, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3720 lang.IFn; if linked_3719 == nil { ifn_3720 = lang.IFn_Cast(root_3718) } else { ifn_3720 = nil }; var arg_3721 any; var fnbody__3724 any = A_arbace_go_check_summarize_fn__1685000438_A_New(); var tmp30 *jrt.Class; var fncls__3723 *jrt.Class = A_arbace_go_check_summarize_fn__1685000438_A_fn_class; if fncls__3723 == nil { var fncls__3723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_go_check_summarize_fn__1685000438_A_fn_class = fncls__3723d; tmp30 = fncls__3723d } else { tmp30 = fncls__3723 }; arg_3721 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3724, tmp30, nil); var arg_3722 any = rs__3; if linked_3719 == nil { arg_3717 = ifn_3720.Invoke_O_O__O(arg_3721, arg_3722) } else { arg_3717 = linked_3719.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3718, arg_3721, arg_3722) }; if linked_3715 == nil { tmp29 = ifn_3716.Invoke_O__O(arg_3717) } else { tmp29 = linked_3715.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3714, arg_3717) }; var tmp31 any = tmp29; var tmp32 any = A_arbace_go_check_A_const_338; var tmp33 any = A_arbace_go_check_A_const_140; var tmp34 any; var root_3725 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3725, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3727 lang.IFn; if
















	linked_3726 == nil { ifn_3727 = lang.IFn_Cast(root_3725) } else { ifn_3727 = nil }; var arg_3728 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3729 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_140); if linked_3726 == nil { tmp34 = ifn_3727.Invoke_O_O__O(arg_3728, arg_3729) } else { tmp34 = linked_3726.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3725, arg_3728, arg_3729) }; var tmp35 any = tmp34; var tmp36 any = A_arbace_go_check_A_const_165; var tmp37 any; var root_3733 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3733, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3735 lang.IFn; if

















	linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3737 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_165); if linked_3734 == nil { tmp37 = ifn_3735.Invoke_O_O__O(arg_3736, arg_3737) } else { tmp37 = linked_3734.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3733, arg_3736, arg_3737) }; var tmp38 any = tmp37; var tmp39 any = A_arbace_go_check_A_const_166; var tmp40 any; var root_3741 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3741, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3743 lang.IFn; if


















	linked_3742 == nil { ifn_3743 = lang.IFn_Cast(root_3741) } else { ifn_3743 = nil }; var arg_3744 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3745 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_166); if linked_3742 == nil { tmp40 = ifn_3743.Invoke_O_O__O(arg_3744, arg_3745) } else { tmp40 = linked_3742.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3741, arg_3744, arg_3745) }; var tmp41 any = tmp40; var tmp42 any = A_arbace_go_check_A_const_340; var tmp43 any; var root_3749 any = /*line :550:1*/A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3749, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3751 lang.IFn; if



















	linked_3750 == nil { ifn_3751 = lang.IFn_Cast(root_3749) } else { ifn_3751 = nil }; var arg_3752 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3753 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_157); if linked_3750 == nil { tmp43 = ifn_3751.Invoke_O_O__O(arg_3752, arg_3753) } else { tmp43 = linked_3750.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3749, arg_3752, arg_3753) }; var tmp44 any = tmp43; var tmp45 any = A_arbace_go_check_A_const_242; var tmp46 any = A_arbace_go_check_A_const_331; var tmp47 any; var root_3757 any = /*line :550:1*/A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3757, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3759 lang.IFn; if




















	linked_3758 == nil { ifn_3759 = lang.IFn_Cast(root_3757) } else { ifn_3759 = nil }; var arg_3760 any; var fnbody__3768 any = A_arbace_go_check_summarize_fn__1685000440_A_New(); var tmp48 *jrt.Class; var fncls__3767 *jrt.Class = A_arbace_go_check_summarize_fn__1685000440_A_fn_class; if fncls__3767 == nil { var fncls__3767d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_go_check_summarize_fn__1685000440_A_fn_class = fncls__3767d; tmp48 = fncls__3767d } else { tmp48 = fncls__3767 }; arg_3760 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3768, tmp48, nil); var arg_3761 any = rs__3; if linked_3758 == nil { tmp47 = ifn_3759.Invoke_O_O__O(arg_3760, arg_3761) } else { tmp47 = linked_3758.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3757, arg_3760, arg_3761) }; var tmp49 any = /*line :550:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp47)).Ref(); var tmp50 any = A_arbace_go_check_A_const_342; var tmp51 lang.IFn = lang.IFn_Cast(sum__4); var tmp52 *lang.Compiler_AOTFn; var fnbody__3802 any = A_arbace_go_check_summarize_fn__1685000442_A_New(); var tmp53 *jrt.Class; var fncls__3801 *jrt.Class = A_arbace_go_check_summarize_fn__1685000442_A_fn_class; if





















	fncls__3801 == nil { var fncls__3801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_go_check_summarize_fn__1685000442_A_fn_class = fncls__3801d; tmp53 = fncls__3801d } else { tmp53 = fncls__3801 }; tmp52 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3802, tmp53, nil); var tmp54 any = /*line :550:1*/tmp51.Invoke_O__O(tmp52.Ref()); var tmp55 any = A_arbace_go_check_A_const_343; var tmp56 any; var root_3769 any = A_arbace_go_check_A_const_336.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3771 lang.IFn; if






















	linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any; var fnbody__3784 any = A_arbace_go_check_summarize_fn__1685000444_A_New(); var tmp57 *jrt.Class; var fncls__3783 *jrt.Class = A_arbace_go_check_summarize_fn__1685000444_A_fn_class; if fncls__3783 == nil { var fncls__3783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_go_check_summarize_fn__1685000444_A_fn_class = fncls__3783d; tmp57 = fncls__3783d } else { tmp57 = fncls__3783 }; arg_3772 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3784, tmp57, nil); var arg_3773 any = rs__3; if linked_3770 == nil { tmp56 = ifn_3771.Invoke_O_O__O(arg_3772, arg_3773) } else { tmp56 = linked_3770.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3769, arg_3772, arg_3773) }; var tmp58 any = /*line :550:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp35, tmp36, tmp38, tmp39, tmp41, tmp42, tmp44, tmp45, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp49, tmp50, tmp54, tmp55, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp56)).Ref())))); var tmp59 any = A_arbace_go_check_A_const_145; var tmp60 any; var root_3785 any = A_arbace_go_check_A_const_158.GetRawRoot__O(); var linked_3786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3785, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3787 lang.IFn; if























	linked_3786 == nil { ifn_3787 = lang.IFn_Cast(root_3785) } else { ifn_3787 = nil }; var arg_3788 any = lang.IFn_Cast(A_arbace_go_check_A_const_339.GetRawRoot__O()).Invoke__O(); var arg_3789 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_145); if linked_3786 == nil { tmp60 = ifn_3787.Invoke_O_O__O(arg_3788, arg_3789) } else { tmp60 = linked_3786.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3785, arg_3788, arg_3789) }; return /*line :550:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, corpus__0, tmp4, tmp5, tmp6, tmp16, tmp17, tmp21, tmp22, tmp23, tmp24, tmp27, tmp28, tmp31, tmp32, tmp58, tmp59, tmp60)) }



func A_arbace_go_check_summarize_sum__1685000430_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000430_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000430_A{}; t.Ctor_O(p0); return t }
//line :554:1
func (t *A_arbace_go_check_summarize_sum__1685000430_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :554:1
func (t *A_arbace_go_check_summarize_sum__1685000430_A) Invoke_O_O__O(self, k__1 any) any { var root_3680 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3680, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3682 lang.IFn; if linked_3681 == nil { ifn_3682 = lang.IFn_Cast(root_3680) } else { ifn_3682 = nil }; var arg_3683 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3684 any = A_arbace_go_check_A_const_22; var arg_3685 any; var root_3686 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3686, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3688 lang.IFn; if linked_3687 == nil { ifn_3688 = lang.IFn_Cast(root_3686) } else { ifn_3688 = nil }; var arg_3689 any = k__1; var arg_3690 any = t.F_rs; if linked_3687 == nil { arg_3685 = ifn_3688.Invoke_O_O__O(arg_3689, arg_3690) } else { arg_3685 = linked_3687.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3686, arg_3689, arg_3690) }; if linked_3681 == nil { return ifn_3682.Invoke_O_O_O__O(arg_3683, arg_3684, arg_3685) } else { return linked_3681.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_3680, arg_3683, arg_3684, arg_3685) } }
func A_arbace_go_check_summarize_msum__1685000432_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000432_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000432_A{}; t.Ctor_O(p0); return t }
//line :555:1
func (t *A_arbace_go_check_summarize_msum__1685000432_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :555:1
func (t *A_arbace_go_check_summarize_msum__1685000432_A) Invoke_O_O__O(self, k__1 any) any { var root_3693 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_3694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3693, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3695 lang.IFn; if linked_3694 == nil { ifn_3695 = lang.IFn_Cast(root_3693) } else { ifn_3695 = nil }; var arg_3696 any = A_arbace_go_check_A_const_152.GetRawRoot__O(); var arg_3697 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_3698 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_3699 any; var root_3700 any = A_arbace_go_check_A_const_127.GetRawRoot__O(); var linked_3701 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3700, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3702 lang.IFn; if linked_3701 == nil { ifn_3702 = lang.IFn_Cast(root_3700) } else { ifn_3702 = nil }; var arg_3703 any = k__1; var arg_3704 any = t.F_rs; if linked_3701 == nil { arg_3699 = ifn_3702.Invoke_O_O__O(arg_3703, arg_3704) } else { arg_3699 = linked_3701.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3700, arg_3703, arg_3704) }; if linked_3694 == nil { return ifn_3695.Invoke_O_O_O_O__O(arg_3696, arg_3697, arg_3698, arg_3699) } else { return linked_3694.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3693, arg_3696, arg_3697, arg_3698, arg_3699) } }







func A_arbace_go_check_summarize_fn__1685000434_A_New() *A_arbace_go_check_summarize_fn__1685000434_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000434_A{}; t.Ctor(); return t }
//line :563:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Ctor() {}
//line :563:1
func (t *A_arbace_go_check_summarize_fn__1685000434_A) Invoke_O_O__O(self, p1__1685000424_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_238.Invoke_O__O(p1__1685000424_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000436_A_New() *A_arbace_go_check_summarize_fn__1685000436_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000436_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Ctor() {}
//line :565:1
func (t *A_arbace_go_check_summarize_fn__1685000436_A) Invoke_O_O__O(self, p1__1685000425_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_311.Invoke_O__O(p1__1685000425_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_83.Invoke_O__O(p1__1685000425_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000438_A_New() *A_arbace_go_check_summarize_fn__1685000438_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000438_A{}; t.Ctor(); return t }
//line :566:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Ctor() {}
//line :566:1
func (t *A_arbace_go_check_summarize_fn__1685000438_A) Invoke_O_O__O(self, p1__1685000426_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_311.Invoke_O__O(p1__1685000426_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_83.Invoke_O__O(p1__1685000426_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_111.Invoke_O__O(p1__1685000426_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000440_A_New() *A_arbace_go_check_summarize_fn__1685000440_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000440_A{}; t.Ctor(); return t }
//line :571:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Ctor() {}
//line :571:1
func (t *A_arbace_go_check_summarize_fn__1685000440_A) Invoke_O_O__O(self, p1__1685000427_SHARP___1 any) any { var root_3762 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3762, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3764 lang.IFn; if linked_3763 == nil { ifn_3764 = lang.IFn_Cast(root_3762) } else { ifn_3764 = nil }; var arg_3765 any = p1__1685000427_SHARP___1; var arg_3766 any = A_arbace_go_check_A_const_341; if linked_3763 == nil { return ifn_3764.Invoke_O_O__O(arg_3765, arg_3766) } else { return linked_3763.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3762, arg_3765, arg_3766) } }
func A_arbace_go_check_summarize_fn__1685000442_A_New() *A_arbace_go_check_summarize_fn__1685000442_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000442_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_go_check_summarize_fn__1685000442_A) Ctor() {}
//line :572:1
func (t *A_arbace_go_check_summarize_fn__1685000442_A) Invoke_O_O__O(self, p1__1685000428_SHARP___1 any) any { var root_3795 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3795, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3797 lang.IFn; if linked_3796 == nil { ifn_3797 = lang.IFn_Cast(root_3795) } else { ifn_3797 = nil }; var arg_3798 any = p1__1685000428_SHARP___1; var arg_3799 any = A_arbace_go_check_A_const_346; var arg_3800 any = A_arbace_go_check_A_const_22; if linked_3796 == nil { return ifn_3797.Invoke_O_O_O__O(arg_3798, arg_3799, arg_3800) } else { return linked_3796.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3795, arg_3798, arg_3799, arg_3800) } }
func A_arbace_go_check_summarize_fn__1685000444_A_New() *A_arbace_go_check_summarize_fn__1685000444_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000444_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_summarize_fn__1685000444_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_summarize_fn__1685000444_A) Invoke_O_O__O(self, p1__1685000429_SHARP___1 any) any { var root_3774 any = A_arbace_go_check_A_const_344.GetRawRoot__O(); var linked_3775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3774, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3776 lang.IFn; if linked_3775 == nil { ifn_3776 = lang.IFn_Cast(root_3774) } else { ifn_3776 = nil }; var arg_3777 any; var root_3778 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3780 lang.IFn; if linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any = p1__1685000429_SHARP___1; var arg_3782 any = A_arbace_go_check_A_const_345; if linked_3779 == nil { arg_3777 = ifn_3780.Invoke_O_O__O(arg_3781, arg_3782) } else { arg_3777 = linked_3779.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3778, arg_3781, arg_3782) }; if linked_3775 == nil { return ifn_3776.Invoke_O__O(arg_3777) } else { return linked_3775.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3774, arg_3777) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :576:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var fnbody__3893 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_New(); var tmp1 *jrt.Class; var fncls__3892 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class; if


	fncls__3892 == nil { var fncls__3892d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class = fncls__3892d; tmp1 = fncls__3892d } else { tmp1 = fncls__3892 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3893, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_New() *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_A{}; t.Ctor(); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A) Ctor() {}
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_A) Invoke_O_O__O(self, s__1685000448__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3891 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_New_O_O(self, s__1685000448__1); var tmp2 *jrt.Class; var fncls__3890 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class; if fncls__3890 == nil { var fncls__3890d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, fnbody__3891); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class = fncls__3890d; tmp2 = fncls__3890d } else { tmp2 = fncls__3890 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3891, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A{}; t.Ctor_O_O(p0, p1); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A) Ctor_O_O(c__iter__1685000447, c__s__1685000448 any) { t.F_iter__1685000447 = c__iter__1685000447; t.F_s__1685000448 = c__s__1685000448 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A) Invoke_O__O(self any) any { { var s__1685000448__1 any; var t_ any = t.F_s__1685000448; t.F_s__1685000448 = nil; s__1685000448__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3803 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3803, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3805 lang.IFn; if linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; var arg_3806 any = s__1685000448__1; if linked_3804 == nil { temp__1927000414__auto____2 = ifn_3805.Invoke_O__O(arg_3806) } else { temp__1927000414__auto____2 = linked_3804.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3803, arg_3806) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3807 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = xs__1927001018__auto____3; if linked_3808 == nil { r__4 = ifn_3809.Invoke_O__O(arg_3810) } else { r__4 = linked_3808.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3807, arg_3810) }; var iterys__1927001035__auto____5 any; var fnbody__3872 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_New_O(r__4); var tmp1 *jrt.Class; var fncls__3871 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class; if fncls__3871 == nil { var fncls__3871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__3872); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class = fncls__3871d; tmp1 = fncls__3871d } else { tmp1 = fncls__3871 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3872, tmp1, nil); var fs__1927001036__auto____6 any; var root_3873 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3875 lang.IFn; if linked_3874 == nil { ifn_3875 = lang.IFn_Cast(root_3873) } else { ifn_3875 = nil }; var arg_3876 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_238.Invoke_O__O(r__4)); if linked_3874 == nil { fs__1927001036__auto____6 = ifn_3875.Invoke_O__O(arg_3876) } else { fs__1927001036__auto____6 = linked_3874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3873, arg_3876) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3877 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var linked_3878 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3877, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3879 lang.IFn; if linked_3878 == nil { ifn_3879 = lang.IFn_Cast(root_3877) } else { ifn_3879 = nil }; var arg_3880 any = fs__1927001036__auto____6; var arg_3881 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1685000447); var tmp3 any; var root_3882 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3882, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3884 lang.IFn; if linked_3883 == nil { ifn_3884 = lang.IFn_Cast(root_3882) } else { ifn_3884 = nil }; var arg_3885 any = s__1685000448__1; if linked_3883 == nil { tmp3 = ifn_3884.Invoke_O__O(arg_3885) } else { tmp3 = linked_3883.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3882, arg_3885) }; arg_3881 = tmp2.Invoke_O__O(tmp3); if linked_3878 == nil { return ifn_3879.Invoke_O_O__O(arg_3880, arg_3881) } else { return linked_3878.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3877, arg_3880, arg_3881) } } else { var tmp4 any; var root_3886 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3886, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3888 lang.IFn; if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any = s__1685000448__1; if linked_3887 == nil { tmp4 = ifn_3888.Invoke_O__O(arg_3889) } else { tmp4 = linked_3887.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3886, arg_3889) }; s__1685000448__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A{}; t.Ctor_O(p0); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A) Invoke_O_O__O(self, s__1685000450__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3870 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_New_O_O_O(self, t.F_r, s__1685000450__1); var tmp2 *jrt.Class; var fncls__3869 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class; if fncls__3869 == nil { var fncls__3869d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, fnbody__3870); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class = fncls__3869d; tmp2 = fncls__3869d } else { tmp2 = fncls__3869 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3870, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A) Ctor_O_O_O(c__iter__1685000449, c__r, c__s__1685000450 any) { t.F_iter__1685000449 = c__iter__1685000449; t.F_r = c__r; t.F_s__1685000450 = c__s__1685000450 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A) Invoke_O__O(self any) any { { var s__1685000450__1 any; var t_ any = t.F_s__1685000450; t.F_s__1685000450 = nil; s__1685000450__1 = t_; for { var temp__1927000414__auto____2 any; var root_3811 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = s__1685000450__1; if linked_3812 == nil { temp__1927000414__auto____2 = ifn_3813.Invoke_O__O(arg_3814) } else { temp__1927000414__auto____2 = linked_3812.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3811, arg_3814) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000450__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3815 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3815, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3817 lang.IFn; if linked_3816 == nil { ifn_3817 = lang.IFn_Cast(root_3815) } else { ifn_3817 = nil }; var arg_3818 any = s__1685000450__3; if linked_3816 == nil { tmp1 = ifn_3817.Invoke_O__O(arg_3818) } else { tmp1 = linked_3816.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3815, arg_3818) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3819 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3819, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3821 lang.IFn; if linked_3820 == nil { ifn_3821 = lang.IFn_Cast(root_3819) } else { ifn_3821 = nil }; var arg_3822 any = s__1685000450__3; if linked_3820 == nil { c__1927001037__auto____4 = ifn_3821.Invoke_O__O(arg_3822) } else { c__1927001037__auto____4 = linked_3820.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3819, arg_3822) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000452__6 any; var root_3823 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3823, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3825 lang.IFn; if linked_3824 == nil { ifn_3825 = lang.IFn_Cast(root_3823) } else { ifn_3825 = nil }; var arg_3826 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3824 == nil { b__1685000452__6 = ifn_3825.Invoke_O__O(arg_3826) } else { b__1685000452__6 = linked_3824.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3823, arg_3826) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3833 any = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000452__6); var tmp3 *jrt.Class; var fncls__3832 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class; if fncls__3832 == nil { var fncls__3832d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__3833); A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class = fncls__3832d; tmp3 = fncls__3832d } else { tmp3 = fncls__3832 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3833, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3834 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3834, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3836 lang.IFn; if linked_3835 == nil { ifn_3836 = lang.IFn_Cast(root_3834) } else { ifn_3836 = nil }; var arg_3837 any; var root_3839 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3839, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3841 lang.IFn; if linked_3840 == nil { ifn_3841 = lang.IFn_Cast(root_3839) } else { ifn_3841 = nil }; var arg_3842 any = b__1685000452__6; if linked_3840 == nil { arg_3837 = ifn_3841.Invoke_O__O(arg_3842) } else { arg_3837 = linked_3840.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3839, arg_3842) }; var arg_3838 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000449); var tmp5 any; var root_3843 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3843, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3845 lang.IFn; if linked_3844 == nil { ifn_3845 = lang.IFn_Cast(root_3843) } else { ifn_3845 = nil }; var arg_3846 any = s__1685000450__3; if linked_3844 == nil { tmp5 = ifn_3845.Invoke_O__O(arg_3846) } else { tmp5 = linked_3844.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3843, arg_3846) }; arg_3838 = tmp4.Invoke_O__O(tmp5); if linked_3835 == nil { return ifn_3836.Invoke_O_O__O(arg_3837, arg_3838) } else { return linked_3835.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3834, arg_3837, arg_3838) } } else { var root_3847 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3847, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3849 lang.IFn; if linked_3848 == nil { ifn_3849 = lang.IFn_Cast(root_3847) } else { ifn_3849 = nil }; var arg_3850 any; var root_3852 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3852, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3854 lang.IFn; if linked_3853 == nil { ifn_3854 = lang.IFn_Cast(root_3852) } else { ifn_3854 = nil }; var arg_3855 any = b__1685000452__6; if linked_3853 == nil { arg_3850 = ifn_3854.Invoke_O__O(arg_3855) } else { arg_3850 = linked_3853.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3852, arg_3855) }; var arg_3851 any; if linked_3848 == nil { return ifn_3849.Invoke_O_O__O(arg_3850, arg_3851) } else { return linked_3848.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3847, arg_3850, arg_3851) } } } else { var e__4 any; var root_3856 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3856, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3858 lang.IFn; if linked_3857 == nil { ifn_3858 = lang.IFn_Cast(root_3856) } else { ifn_3858 = nil }; var arg_3859 any = s__1685000450__3; if linked_3857 == nil { e__4 = ifn_3858.Invoke_O__O(arg_3859) } else { e__4 = linked_3857.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3856, arg_3859) }; var root_3860 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3862 lang.IFn; if linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_74.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_79.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_312.Invoke_O__O(e__4))).Ref(); var arg_3864 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000449); var tmp7 any; var root_3865 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_3866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3867 lang.IFn; if linked_3866 == nil { ifn_3867 = lang.IFn_Cast(root_3865) } else { ifn_3867 = nil }; var arg_3868 any = s__1685000450__3; if linked_3866 == nil { tmp7 = ifn_3867.Invoke_O__O(arg_3868) } else { tmp7 = linked_3866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3865, arg_3868) }; arg_3864 = tmp6.Invoke_O__O(tmp7); if linked_3861 == nil { return ifn_3862.Invoke_O_O__O(arg_3863, arg_3864) } else { return linked_3861.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3860, arg_3863, arg_3864) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :579:1
func A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000452 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000452 = c__b__1685000452 }
//line :579:1
func (t *A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A) Invoke_O__O(self any) any { { var i__1685000451__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000451__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000451__1)); var root_3827 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3827, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3829 lang.IFn; if linked_3828 == nil { ifn_3829 = lang.IFn_Cast(root_3827) } else { ifn_3829 = nil }; var arg_3830 any = t.F_b__1685000452; var arg_3831 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_114, nil, Lit_26, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_74.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_79.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_312.Invoke_O__O(e__2))).Ref(); if linked_3828 == nil { ifn_3829.Invoke_O_O__O(arg_3830, arg_3831) } else { linked_3828.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3827, arg_3830, arg_3831) }; i__1685000451__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000451__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :584:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000465__3 any; var root_3894 any = A_arbace_go_check_A_const_347.GetRawRoot__O(); var linked_3895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3894, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3896 lang.IFn; if



	linked_3895 == nil { ifn_3896 = lang.IFn_Cast(root_3894) } else { ifn_3896 = nil }; var arg_3897 any = forms__0; if linked_3895 == nil { map__1685000465__3 = ifn_3896.Invoke_O__O(arg_3897) } else { map__1685000465__3 = linked_3895.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3894, arg_3897) }; var map__1685000465__4 any; if lang.ISeq_InstanceOf(map__1685000465__3) { var tmp1 any; var root_3898 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3898, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3900 lang.IFn; if linked_3899 == nil { ifn_3900 = lang.IFn_Cast(root_3898) } else { ifn_3900 = nil }; var arg_3901 any = map__1685000465__3; if linked_3899 == nil { tmp1 = ifn_3900.Invoke_O__O(arg_3901) } else { tmp1 = linked_3899.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3898, arg_3901) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3902 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any = map__1685000465__3; if linked_3903 == nil { tmp2 = ifn_3904.Invoke_O__O(arg_3905) } else { tmp2 = linked_3903.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3902, arg_3905) }; map__1685000465__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_3906 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3908 lang.IFn; if linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any = map__1685000465__3; if linked_3907 == nil { tmp3 = ifn_3908.Invoke_O__O(arg_3909) } else { tmp3 = linked_3907.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3906, arg_3909) }; if jrt.J2g_Truth(tmp3) { var root_3910 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3910, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3912 lang.IFn; if linked_3911 == nil { ifn_3912 = lang.IFn_Cast(root_3910) } else { ifn_3912 = nil }; var arg_3913 any = map__1685000465__3; if linked_3911 == nil { map__1685000465__4 = ifn_3912.Invoke_O__O(arg_3913) } else { map__1685000465__4 = linked_3911.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3910, arg_3913) } } else { map__1685000465__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000465__4 = map__1685000465__3 }; var package__5 any = /*line :584:1*/lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_110); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_71); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000465__4, A_arbace_go_check_A_const_125); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_348.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_349; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_112.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_111; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_111.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_118 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_71; var tmp10 any; var root_3920 any = /*line :584:1*/A_arbace_go_check_A_const_350.GetRawRoot__O(); var linked_3921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3920, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3922 lang.IFn; if





	linked_3921 == nil { ifn_3922 = lang.IFn_Cast(root_3920) } else { ifn_3922 = nil }; var arg_3923 any = name__6; if linked_3921 == nil { tmp10 = ifn_3922.Invoke_O__O(arg_3923) } else { tmp10 = linked_3921.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3920, arg_3923) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_112; var tmp13 any = A_arbace_go_check_A_const_82; var tmp14 any = A_arbace_go_check_A_const_233; var tmp15 any; var root_3924 any = /*line :584:1*/A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3924, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3926 lang.IFn; if






	linked_3925 == nil { ifn_3926 = lang.IFn_Cast(root_3924) } else { ifn_3926 = nil }; var arg_3927 any; var fnbody__3942 any = A_arbace_go_check_forms_source_fn__1685000467_A_New(); var tmp16 *jrt.Class; var fncls__3941 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000467_A_fn_class; if fncls__3941 == nil { var fncls__3941d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, nil); A_arbace_go_check_forms_source_fn__1685000467_A_fn_class = fncls__3941d; tmp16 = fncls__3941d } else { tmp16 = fncls__3941 }; arg_3927 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3942, tmp16, nil); var arg_3928 any = forms__0; if linked_3925 == nil { tmp15 = ifn_3926.Invoke_O_O__O(arg_3927, arg_3928) } else { tmp15 = linked_3925.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3924, arg_3927, arg_3928) }; var tmp17 any = tmp15; var tmp18 any = A_arbace_go_check_A_const_125; var tmp19 any; var root_3943 any = /*line :584:1*/A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_3944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3943, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3945 lang.IFn; if







	linked_3944 == nil { ifn_3945 = lang.IFn_Cast(root_3943) } else { ifn_3945 = nil }; var arg_3946 any; var iter__1927001039__auto____9 any; var fnbody__4020 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_New(); var tmp20 *jrt.Class; var fncls__4019 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class; if fncls__4019 == nil { var fncls__4019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class = fncls__4019d; tmp20 = fncls__4019d } else { tmp20 = fncls__4019 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4020, tmp20, nil); arg_3946 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3944 == nil { tmp19 = ifn_3945.Invoke_O__O(arg_3946) } else { tmp19 = linked_3944.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3943, arg_3946) }; return /*line :584:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp17, tmp18, tmp19)) }






func A_arbace_go_check_forms_source_fn__1685000467_A_New() *A_arbace_go_check_forms_source_fn__1685000467_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000467_A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_go_check_forms_source_fn__1685000467_A) Ctor() {}
//line :591:1
func (t *A_arbace_go_check_forms_source_fn__1685000467_A) Invoke_O_O__O(self, p1__1685000464_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3929 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3929, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3931 lang.IFn; if linked_3930 == nil { ifn_3931 = lang.IFn_Cast(root_3929) } else { ifn_3931 = nil }; var arg_3932 any = p1__1685000464_SHARP___1; if linked_3930 == nil { and__1927000168__auto____2 = ifn_3931.Invoke_O__O(arg_3932) } else { and__1927000168__auto____2 = linked_3930.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3929, arg_3932) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_351; var tmp3 any; var root_3933 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3933, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3935 lang.IFn; if linked_3934 == nil { ifn_3935 = lang.IFn_Cast(root_3933) } else { ifn_3935 = nil }; var arg_3936 any = p1__1685000464_SHARP___1; if linked_3934 == nil { tmp3 = ifn_3935.Invoke_O__O(arg_3936) } else { tmp3 = linked_3934.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3933, arg_3936) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3937 any = A_arbace_go_check_A_const_80.GetRawRoot__O(); var linked_3938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3937, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3939 lang.IFn; if linked_3938 == nil { ifn_3939 = lang.IFn_Cast(root_3937) } else { ifn_3939 = nil }; var arg_3940 any = p1__1685000464_SHARP___1; if linked_3938 == nil { return ifn_3939.Invoke_O__O(arg_3940) } else { return linked_3938.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3937, arg_3940) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_New() *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_A{}; t.Ctor(); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A) Ctor() {}
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_A) Invoke_O_O__O(self, s__1685000470__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4018 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_New_O_O(self, s__1685000470__1); var tmp2 *jrt.Class; var fncls__4017 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class; if fncls__4017 == nil { var fncls__4017d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__4018); A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class = fncls__4017d; tmp2 = fncls__4017d } else { tmp2 = fncls__4017 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4018, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :592:1
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A{}; t.Ctor_O_O(p0, p1); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A) Ctor_O_O(c__iter__1685000469, c__s__1685000470 any) { t.F_iter__1685000469 = c__iter__1685000469; t.F_s__1685000470 = c__s__1685000470 }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A) Invoke_O__O(self any) any { { var s__1685000470__1 any; var t_ any = t.F_s__1685000470; t.F_s__1685000470 = nil; s__1685000470__1 = t_; for { var temp__1927000414__auto____2 any; var root_3947 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3947, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3949 lang.IFn; if linked_3948 == nil { ifn_3949 = lang.IFn_Cast(root_3947) } else { ifn_3949 = nil }; var arg_3950 any = s__1685000470__1; if linked_3948 == nil { temp__1927000414__auto____2 = ifn_3949.Invoke_O__O(arg_3950) } else { temp__1927000414__auto____2 = linked_3948.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3947, arg_3950) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000470__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3951 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3951, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3953 lang.IFn; if linked_3952 == nil { ifn_3953 = lang.IFn_Cast(root_3951) } else { ifn_3953 = nil }; var arg_3954 any = s__1685000470__3; if linked_3952 == nil { tmp1 = ifn_3953.Invoke_O__O(arg_3954) } else { tmp1 = linked_3952.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3951, arg_3954) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3955 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3955, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3957 lang.IFn; if linked_3956 == nil { ifn_3957 = lang.IFn_Cast(root_3955) } else { ifn_3957 = nil }; var arg_3958 any = s__1685000470__3; if linked_3956 == nil { c__1927001037__auto____4 = ifn_3957.Invoke_O__O(arg_3958) } else { c__1927001037__auto____4 = linked_3956.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3955, arg_3958) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000472__6 any; var root_3959 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_3960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3959, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3961 lang.IFn; if linked_3960 == nil { ifn_3961 = lang.IFn_Cast(root_3959) } else { ifn_3961 = nil }; var arg_3962 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3960 == nil { b__1685000472__6 = ifn_3961.Invoke_O__O(arg_3962) } else { b__1685000472__6 = linked_3960.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3959, arg_3962) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3975 any = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_New_I_O_O(size__1927001038__auto____5, b__1685000472__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3974 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class; if fncls__3974 == nil { var fncls__3974d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__3975); A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class = fncls__3974d; tmp3 = fncls__3974d } else { tmp3 = fncls__3974 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3975, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3976 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3976, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3978 lang.IFn; if linked_3977 == nil { ifn_3978 = lang.IFn_Cast(root_3976) } else { ifn_3978 = nil }; var arg_3979 any; var root_3981 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3981, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3983 lang.IFn; if linked_3982 == nil { ifn_3983 = lang.IFn_Cast(root_3981) } else { ifn_3983 = nil }; var arg_3984 any = b__1685000472__6; if linked_3982 == nil { arg_3979 = ifn_3983.Invoke_O__O(arg_3984) } else { arg_3979 = linked_3982.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3981, arg_3984) }; var arg_3980 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000469); var tmp5 any; var root_3985 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3985, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3987 lang.IFn; if linked_3986 == nil { ifn_3987 = lang.IFn_Cast(root_3985) } else { ifn_3987 = nil }; var arg_3988 any = s__1685000470__3; if linked_3986 == nil { tmp5 = ifn_3987.Invoke_O__O(arg_3988) } else { tmp5 = linked_3986.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3985, arg_3988) }; arg_3980 = tmp4.Invoke_O__O(tmp5); if linked_3977 == nil { return ifn_3978.Invoke_O_O__O(arg_3979, arg_3980) } else { return linked_3977.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3976, arg_3979, arg_3980) } } else { var root_3989 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_3990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3989, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3991 lang.IFn; if linked_3990 == nil { ifn_3991 = lang.IFn_Cast(root_3989) } else { ifn_3991 = nil }; var arg_3992 any; var root_3994 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = b__1685000472__6; if linked_3995 == nil { arg_3992 = ifn_3996.Invoke_O__O(arg_3997) } else { arg_3992 = linked_3995.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3994, arg_3997) }; var arg_3993 any; if linked_3990 == nil { return ifn_3991.Invoke_O_O__O(arg_3992, arg_3993) } else { return linked_3990.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3989, arg_3992, arg_3993) } } } else { var fi__4 any; var root_3998 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3998, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4000 lang.IFn; if linked_3999 == nil { ifn_4000 = lang.IFn_Cast(root_3998) } else { ifn_4000 = nil }; var arg_4001 any = s__1685000470__3; if linked_3999 == nil { fi__4 = ifn_4000.Invoke_O__O(arg_4001) } else { fi__4 = linked_3999.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3998, arg_4001) }; var root_4002 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4002, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4004 lang.IFn; if linked_4003 == nil { ifn_4004 = lang.IFn_Cast(root_4002) } else { ifn_4004 = nil }; var arg_4005 any; var root_4007 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4008 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4007, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4009 lang.IFn; if linked_4008 == nil { ifn_4009 = lang.IFn_Cast(root_4007) } else { ifn_4009 = nil }; var arg_4010 any = fi__4; var arg_4011 any = A_arbace_go_check_A_const_82; var arg_4012 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__4); if linked_4008 == nil { arg_4005 = ifn_4009.Invoke_O_O_O__O(arg_4010, arg_4011, arg_4012) } else { arg_4005 = linked_4008.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4007, arg_4010, arg_4011, arg_4012) }; var arg_4006 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000469); var tmp7 any; var root_4013 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4013, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4015 lang.IFn; if linked_4014 == nil { ifn_4015 = lang.IFn_Cast(root_4013) } else { ifn_4015 = nil }; var arg_4016 any = s__1685000470__3; if linked_4014 == nil { tmp7 = ifn_4015.Invoke_O__O(arg_4016) } else { tmp7 = linked_4014.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4013, arg_4016) }; arg_4006 = tmp6.Invoke_O__O(tmp7); if linked_4003 == nil { return ifn_4004.Invoke_O_O__O(arg_4005, arg_4006) } else { return linked_4003.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4002, arg_4005, arg_4006) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :592:1
func A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1685000472, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1685000472 = c__b__1685000472; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :592:1
func (t *A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A) Invoke_O__O(self any) any { { var i__1685000471__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000471__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000471__1)); var root_3963 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_3964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3963, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3965 lang.IFn; if linked_3964 == nil { ifn_3965 = lang.IFn_Cast(root_3963) } else { ifn_3965 = nil }; var arg_3966 any = t.F_b__1685000472; var arg_3967 any; var root_3968 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_3969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3968, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3970 lang.IFn; if linked_3969 == nil { ifn_3970 = lang.IFn_Cast(root_3968) } else { ifn_3970 = nil }; var arg_3971 any = fi__2; var arg_3972 any = A_arbace_go_check_A_const_82; var arg_3973 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__2); if linked_3969 == nil { arg_3967 = ifn_3970.Invoke_O_O_O__O(arg_3971, arg_3972, arg_3973) } else { arg_3967 = linked_3969.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3968, arg_3971, arg_3972, arg_3973) }; if linked_3964 == nil { ifn_3965.Invoke_O_O__O(arg_3966, arg_3967) } else { linked_3964.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3963, arg_3966, arg_3967) }; i__1685000471__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000471__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :594:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_4030 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_4031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4030, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4032 lang.IFn; if




	linked_4031 == nil { ifn_4032 = lang.IFn_Cast(root_4030) } else { ifn_4032 = nil }; var arg_4033 any = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_353, jrt.Boolean_FALSE.Ref()); if linked_4031 == nil { ifn_4032.Invoke_O__O(arg_4033) } else { linked_4031.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4030, arg_4033) }; var tmp1 any; tmp3 := /*line :594:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_4021 any = A_arbace_go_check_A_const_352.GetRawRoot__O(); var linked_4022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4021, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_4023 lang.IFn






		if linked_4022 == nil { ifn_4023 = lang.IFn_Cast(root_4021) } else { ifn_4023 = nil }; var arg_4024 any = r__2; var arg_4025 any = jrt.Boolean_FALSE.Ref(); var arg_4026 any = eof__3; if linked_4022 == nil { f__7 = ifn_4023.Invoke_O_O_O__O(arg_4024, arg_4025, arg_4026) } else { f__7 = linked_4022.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_4021, arg_4024, arg_4025, arg_4026) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_4039 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_4040 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4039, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_4041 lang.IFn; if linked_4040 == nil { ifn_4041 = lang.IFn_Cast(root_4039) } else { ifn_4041 = nil }; var arg_4042 any = acc__6; var arg_4043 any = f__7; if linked_4040 == nil { tmp2 = ifn_4041.Invoke_O_O__O(arg_4042, arg_4043) } else { tmp2 = linked_4040.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_4039, arg_4042, arg_4043) }; acc__6 = tmp2; continue L1 }
//line :594:1
		break L1 } }; return nil }(); var root_4027 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4027, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4029 lang.IFn; if




	linked_4028 == nil { ifn_4029 = lang.IFn_Cast(root_4027) } else { ifn_4029 = nil }; if linked_4028 == nil { ifn_4029.Invoke__O() } else { linked_4028.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4027) }; if /*line :594:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :606:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :606:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_4044 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_4045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4044, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_4046 lang.IFn; if


	linked_4045 == nil { ifn_4046 = lang.IFn_Cast(root_4044) } else { ifn_4046 = nil }; var arg_4047 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); if linked_4045 == nil { tmp1 = ifn_4046.Invoke_O__O(arg_4047) } else { tmp1 = linked_4045.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_4044, arg_4047) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_4048 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_4049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4048, A_arbace_go_check_std_session_A_fn_class); var ifn_4050 lang.IFn
		if linked_4049 == nil { ifn_4050 = lang.IFn_Cast(root_4048) } else { ifn_4050 = nil }; var arg_4051 any; var root_4052 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_4053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4052, A_arbace_go_check_corpus_config_A_fn_class); var ifn_4054 lang.IFn; if linked_4053 == nil { ifn_4054 = lang.IFn_Cast(root_4052) } else { ifn_4054 = nil }; var arg_4055 any = corpus__0; if linked_4053 == nil { arg_4051 = ifn_4054.Invoke_O__O(arg_4055) } else { arg_4051 = linked_4053.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_4052, arg_4055) }; if linked_4049 == nil { s__3 = ifn_4050.Invoke_O__O(arg_4051) } else { s__3 = linked_4049.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_4048, arg_4051) }
		var root_4056 any = A_arbace_go_check_A_const_284.GetRawRoot__O(); var linked_4057 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4056, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_4058 lang.IFn; if linked_4057 == nil { ifn_4058 = lang.IFn_Cast(root_4056) } else { ifn_4058 = nil }; var arg_4059 any = A_arbace_go_check_A_const_354.GetRawRoot__O(); var arg_4060 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var arg_4061 any = corpus__0; var arg_4062 any = s__3; if linked_4057 == nil { ifn_4058.Invoke_O_O_O_O__O(arg_4059, arg_4060, arg_4061, arg_4062) } else { linked_4057.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_4056, arg_4059, arg_4060, arg_4061, arg_4062) }
//line :609:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_4063 any = A_arbace_go_check_A_const_355.GetRawRoot__O(); var linked_4064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4063, A_arbace_go_check_std_A_fn_class); var ifn_4065 lang.IFn; if




	linked_4064 == nil { ifn_4065 = lang.IFn_Cast(root_4063) } else { ifn_4065 = nil }; var arg_4066 any = corpus__1; if linked_4064 == nil { s__4 = ifn_4065.Invoke_O__O(arg_4066) } else { s__4 = linked_4064.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_4063, arg_4066) }; var src__5 any; var root_4067 any = /*line :614:1*/A_arbace_go_check_A_const_356.GetRawRoot__O(); var linked_4068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4067, A_arbace_go_check_forms_source_A_fn_class); var ifn_4069 lang.IFn; if





	linked_4068 == nil { ifn_4069 = lang.IFn_Cast(root_4067) } else { ifn_4069 = nil }; var arg_4070 any = forms__0; var arg_4071 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_112; var tmp2 any; var root_4072 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_4073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4072, A_arbace_go_check_corpus_config_A_fn_class); var ifn_4074 lang.IFn; if linked_4073 == nil { ifn_4074 = lang.IFn_Cast(root_4072) } else { ifn_4074 = nil }; var arg_4075 any = corpus__1; if linked_4073 == nil { tmp2 = ifn_4074.Invoke_O__O(arg_4075) } else { tmp2 = linked_4073.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_4072, arg_4075) }; arg_4071 = tmp1.Invoke_O__O(tmp2); if linked_4068 == nil { src__5 = ifn_4069.Invoke_O_O__O(arg_4070, arg_4071) } else { src__5 = linked_4068.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_4067, arg_4070, arg_4071) }; var pkg__6 any; var tmp3 lang.IFn = /*line :614:1*/lang.IFn_Cast(A_arbace_go_check_A_const_277.GetRawRoot__O()); var tmp4 any; var root_4083 any = A_arbace_go_check_A_const_278.GetRawRoot__O(); var linked_4084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4083, A_arbace_go_check_resolver_A_fn_class); var ifn_4085 lang.IFn; if






	linked_4084 == nil { ifn_4085 = lang.IFn_Cast(root_4083) } else { ifn_4085 = nil }; var arg_4086 any = s__4; var arg_4087 any = src__5; var arg_4088 any = lang.PersistentVector_EMPTY.Ref(); if linked_4084 == nil { tmp4 = ifn_4085.Invoke_O_O_O__O(arg_4086, arg_4087, arg_4088) } else { tmp4 = linked_4084.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_4083, arg_4086, arg_4087, arg_4088) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_109; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_109.Invoke_O__O(opts__2)); var root_4089 any =
	A_arbace_go_check_A_const_93.GetRawRoot__O(); var linked_4090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4089, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_4091 lang.IFn; if linked_4090 == nil { ifn_4091 = lang.IFn_Cast(root_4089) } else { ifn_4091 = nil }; var arg_4092 any = pkg__6; var arg_4093 any = A_arbace_go_check_A_const_237; if linked_4090 == nil { return ifn_4091.Invoke_O_O__O(arg_4092, arg_4093) } else { return linked_4090.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_4089, arg_4092, arg_4093) } }
//line :614:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_4094 any = A_arbace_go_check_A_const_357.GetRawRoot__O(); var linked_4095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4094, A_arbace_go_check_check_forms_A_fn_class); var ifn_4096 lang.IFn; if linked_4095 == nil { ifn_4096 = lang.IFn_Cast(root_4094) } else { ifn_4096 = nil }; var arg_4097 any = forms__0; var arg_4098 any = Lit_54; var arg_4099 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4095 == nil { return ifn_4096.Invoke_O_O_O__O(arg_4097, arg_4098, arg_4099) } else { return linked_4095.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_4094, arg_4097, arg_4098, arg_4099)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :630:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_362.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_358.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_4118 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_4119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4118, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4120 lang.IFn; if linked_4119 == nil { ifn_4120 = lang.IFn_Cast(root_4118) } else { ifn_4120 = nil }; var arg_4121 any = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_361, s__1927001093__auto____3); if linked_4119 == nil { ifn_4120.Invoke_O__O(arg_4121) } else { linked_4119.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4118, arg_4121) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__4117 any = A_arbace_go_check_write_edn_fn__1685000483_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__4116 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000483_A_fn_class; if fncls__4116 == nil { var fncls__4116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__4117); A_arbace_go_check_write_edn_fn__1685000483_A_fn_class = fncls__4116d; tmp4 = fncls__4116d } else { tmp4 = fncls__4116 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4117, tmp4, nil); tmp2 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :632:1
func A_arbace_go_check_write_edn_fn__1685000483_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000483_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000483_A{}; t.Ctor_O_O(p0, p1); return t }
//line :632:1
func (t *A_arbace_go_check_write_edn_fn__1685000483_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :632:1
func (t *A_arbace_go_check_write_edn_fn__1685000483_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4112 any = A_arbace_go_check_A_const_360.GetRawRoot__O(); var linked_4113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4112, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_4114 lang.IFn; if linked_4113 == nil { ifn_4114 = lang.IFn_Cast(root_4112) } else { ifn_4114 = nil }; var arg_4115 any; var t_ any = t.F_x; t.F_x = nil; arg_4115 = t_; if linked_4113 == nil { ifn_4114.Invoke_O__O(arg_4115) } else { linked_4113.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_4112, arg_4115) }; var root_4105 any = A_arbace_go_check_A_const_359.GetRawRoot__O(); var linked_4106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4105, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4107 lang.IFn; if linked_4106 == nil { ifn_4107 = lang.IFn_Cast(root_4105) } else { ifn_4107 = nil }; var arg_4108 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_4108 = t__2; if linked_4106 == nil { tmp1 = ifn_4107.Invoke_O__O(arg_4108) } else { tmp1 = linked_4106.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4105, arg_4108) } }; return nil }(); var root_4109 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4109, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4111 lang.IFn; if linked_4110 == nil { ifn_4111 = lang.IFn_Cast(root_4109) } else { ifn_4111 = nil }; if linked_4110 == nil { ifn_4111.Invoke__O() } else { linked_4110.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4109) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }






func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :639:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :639:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any {
	if jrt.J2g_Truth(A_arbace_go_check_A_const_363.Get__O()) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_363.Get__O(), nil, corpus__0, nil)).Ref() } else {
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_128, nil, Lit_129), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil, corpus__0, nil)).Ref()
		} }
func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :644:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000487__1 any) any { var map__1685000488__3 any = p__1685000487__1; var map__1685000488__4 any; if lang.ISeq_InstanceOf(map__1685000488__3) { var tmp1 any; var root_4131 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4131, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4133 lang.IFn; if linked_4132 == nil { ifn_4133 = lang.IFn_Cast(root_4131) } else { ifn_4133 = nil }; var arg_4134 any = map__1685000488__3; if linked_4132 == nil { tmp1 = ifn_4133.Invoke_O__O(arg_4134) } else { tmp1 = linked_4132.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4131, arg_4134) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_4135 any = A_arbace_go_check_A_const_108.GetRawRoot__O(); var linked_4136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4135, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_4137 lang.IFn; if linked_4136 == nil { ifn_4137 = lang.IFn_Cast(root_4135) } else { ifn_4137 = nil }; var arg_4138 any = map__1685000488__3; if linked_4136 == nil { tmp2 = ifn_4137.Invoke_O__O(arg_4138) } else { tmp2 = linked_4136.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_4135, arg_4138) }; map__1685000488__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_4139 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4139, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4141 lang.IFn; if linked_4140 == nil { ifn_4141 = lang.IFn_Cast(root_4139) } else { ifn_4141 = nil }; var arg_4142 any = map__1685000488__3; if linked_4140 == nil { tmp3 = ifn_4141.Invoke_O__O(arg_4142) } else { tmp3 = linked_4140.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4139, arg_4142) }; if jrt.J2g_Truth(tmp3) { var root_4143 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4145 lang.IFn; if linked_4144 == nil { ifn_4145 = lang.IFn_Cast(root_4143) } else { ifn_4145 = nil }; var arg_4146 any = map__1685000488__3; if linked_4144 == nil { map__1685000488__4 = ifn_4145.Invoke_O__O(arg_4146) } else { map__1685000488__4 = linked_4144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4143, arg_4146) } } else { map__1685000488__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000488__4 = map__1685000488__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_364); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_365); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000488__4, A_arbace_go_check_A_const_366); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_4147 any = A_arbace_go_check_A_const_367.GetRawRoot__O(); var linked_4148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4147, A_arbace_go_check_check_corpus_A_fn_class); var ifn_4149 lang.IFn; if






	linked_4148 == nil { ifn_4149 = lang.IFn_Cast(root_4147) } else { ifn_4149 = nil }; var arg_4150 any = corpus__0; var arg_4151 any = jobs__5; if linked_4148 == nil { rs__9 = ifn_4149.Invoke_O_O__O(arg_4150, arg_4151) } else { rs__9 = linked_4148.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_4147, arg_4150, arg_4151) }; var sm__10 any; var root_4152 any = /*line :644:1*/A_arbace_go_check_A_const_368.GetRawRoot__O(); var linked_4153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4152, A_arbace_go_check_summarize_A_fn_class); var ifn_4154 lang.IFn; if







	linked_4153 == nil { ifn_4154 = lang.IFn_Cast(root_4152) } else { ifn_4154 = nil }; var arg_4155 any = corpus__0; var arg_4156 any = rs__9; if linked_4153 == nil { sm__10 = ifn_4154.Invoke_O_O__O(arg_4155, arg_4156) } else { sm__10 = linked_4153.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_4152, arg_4155, arg_4156) }; var secs__11 float64 = /*line :644:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_369; var tmp5 any; var root_4157 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4157, A_arbace_go_check_reference_path_A_fn_class); var ifn_4159 lang.IFn; if









	linked_4158 == nil { ifn_4159 = lang.IFn_Cast(root_4157) } else { ifn_4159 = nil }; var arg_4160 any = corpus__0; if linked_4158 == nil { tmp5 = ifn_4159.Invoke_O__O(arg_4160) } else { tmp5 = linked_4158.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4157, arg_4160) }; ref_file__12 = /*line :644:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.File_Cast(ref_file__12).IsFile__Z() { var r__13 any; var root_4161 any = A_arbace_go_check_A_const_371.GetRawRoot__O(); var linked_4162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4161, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_4163 lang.IFn
		if linked_4162 == nil { ifn_4163 = lang.IFn_Cast(root_4161) } else { ifn_4163 = nil }; var arg_4164 any = lang.IFn_Cast(A_arbace_go_check_A_const_372.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_4162 == nil { r__13 = ifn_4163.Invoke_O__O(arg_4164) } else { r__13 = linked_4162.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_4161, arg_4164) }; if jrt.J2g_Truth(A_arbace_go_check_A_const_363.Get__O()) { var root_4169 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4170 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4169, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4171 lang.IFn; if linked_4170 == nil { ifn_4171 = lang.IFn_Cast(root_4169) } else { ifn_4171 = nil }; var arg_4172 any = A_arbace_go_check_A_const_373.Invoke_O__O(r__13); var arg_4173 any = A_arbace_go_check_A_const_337; if linked_4170 == nil { ref__13 = ifn_4171.Invoke_O_O__O(arg_4172, arg_4173) } else { ref__13 = linked_4170.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4169, arg_4172, arg_4173) } } else { ref__13 = r__13 } } else {
//line :655:1
			ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_4174 any = /*line :644:1*/A_arbace_go_check_A_const_238.Invoke_O__O(sm__10); if












	jrt.Long_InstanceOf(na_4174) { var n0_4175 int64 = jrt.NN(jrt.Long_Cast(na_4174)).LongValue__J(); and__1927000168__auto____14 = n0_4175 == 0 } else { if jrt.Double_InstanceOf(na_4174) { var n0_4175_2 float64 = jrt.NN(jrt.Double_Cast(na_4174)).DoubleValue__D(); and__1927000168__auto____14 = n0_4175_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_4174) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_4176 any = A_arbace_go_check_A_const_335.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_4176) { var n0_4177 int64 = jrt.NN(jrt.Long_Cast(na_4176)).LongValue__J(); and__1927000168__auto____15 = n0_4177 == 0 } else { if jrt.Double_InstanceOf(na_4176) { var n0_4177_2 float64 = jrt.NN(jrt.Double_Cast(na_4176)).DoubleValue__D(); and__1927000168__auto____15 = n0_4177_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_4176) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_4178 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_4179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4178, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4180 lang.IFn; if linked_4179 == nil { ifn_4180 = lang.IFn_Cast(root_4178) } else { ifn_4180 = nil }; var arg_4181 any; var root_4182 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4182, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4184 lang.IFn; if linked_4183 == nil { ifn_4184 = lang.IFn_Cast(root_4182) } else { ifn_4184 = nil }; var arg_4185 any = sm__10; var arg_4186 any = A_arbace_go_check_A_const_374; if linked_4183 == nil { arg_4181 = ifn_4184.Invoke_O_O__O(arg_4185, arg_4186) } else { arg_4181 = linked_4183.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4182, arg_4185, arg_4186) }; if linked_4179 == nil { and__1927000168__auto____16 = ifn_4180.Invoke_O__O(arg_4181) } else { and__1927000168__auto____16 = linked_4179.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4178, arg_4181) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_4187 any; var root_4188 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4188, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4190 lang.IFn
		if linked_4189 == nil { ifn_4190 = lang.IFn_Cast(root_4188) } else { ifn_4190 = nil }; var arg_4191 any = sm__10; var arg_4192 any = A_arbace_go_check_A_const_375; if linked_4189 == nil { na_4187 = ifn_4190.Invoke_O_O__O(arg_4191, arg_4192) } else { na_4187 = linked_4189.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4188, arg_4191, arg_4192) }; if jrt.Long_InstanceOf(na_4187) { var n0_4193 int64 = jrt.NN(jrt.Long_Cast(na_4187)).LongValue__J(); and__1927000168__auto____17 = n0_4193 == 0 } else { if jrt.Double_InstanceOf(na_4187) { var n0_4193_2 float64 = jrt.NN(jrt.Double_Cast(na_4187)).DoubleValue__D(); and__1927000168__auto____17 = n0_4193_2 == 0.0 } else { and__1927000168__auto____17 = lang.Numbers_IsZero_O__Z_NoInit(na_4187) } }
//line :657:1
		if and__1927000168__auto____17 {

			var tmp6 bool; var na_4194 any; var root_4195 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4195, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4197 lang.IFn; if linked_4196 == nil { ifn_4197 = lang.IFn_Cast(root_4195) } else { ifn_4197 = nil }; var arg_4198 any = sm__10; var arg_4199 any = A_arbace_go_check_A_const_376; if linked_4196 == nil { na_4194 = ifn_4197.Invoke_O_O__O(arg_4198, arg_4199) } else { na_4194 = linked_4196.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4195, arg_4198, arg_4199) }; if jrt.Long_InstanceOf(na_4194) { var n0_4200 int64 = jrt.NN(jrt.Long_Cast(na_4194)).LongValue__J(); tmp6 = n0_4200 == 0 } else { if jrt.Double_InstanceOf(na_4194) { var n0_4200_2 float64 = jrt.NN(jrt.Double_Cast(na_4194)).DoubleValue__D(); tmp6 = n0_4200_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_4194) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :657:1
				clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_4201 any = /*line :644:1*/A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4201, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4203 lang.IFn; if















	linked_4202 == nil { ifn_4203 = lang.IFn_Cast(root_4201) } else { ifn_4203 = nil }; var arg_4204 any = ref__13; var arg_4205 any = A_arbace_go_check_A_const_377; if linked_4202 == nil { tmp7 = ifn_4203.Invoke_O_O__O(arg_4204, arg_4205) } else { tmp7 = linked_4202.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4201, arg_4204, arg_4205) }; var tmp8 any = tmp7; var tmp9 any; var root_4206 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4207 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4206, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4208 lang.IFn; if linked_4207 == nil { ifn_4208 = lang.IFn_Cast(root_4206) } else { ifn_4208 = nil }; var arg_4209 any = sm__10; var arg_4210 any = A_arbace_go_check_A_const_337; if linked_4207 == nil { tmp9 = ifn_4208.Invoke_O_O__O(arg_4209, arg_4210) } else { tmp9 = linked_4207.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4206, arg_4209, arg_4210) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_4219 any =
	A_arbace_go_check_A_const_378.GetRawRoot__O(); var linked_4220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4219, A_arbace_go_check_write_edn_A_fn_class); var ifn_4221 lang.IFn; if linked_4220 == nil { ifn_4221 = lang.IFn_Cast(root_4219) } else { ifn_4221 = nil }; var arg_4222 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_4223 any; var tmp10 any = A_arbace_go_check_A_const_373; var tmp11 any = A_arbace_go_check_A_const_379; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_238; var tmp14 any; var root_4224 any = A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4224, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4226 lang.IFn; if

	linked_4225 == nil { ifn_4226 = lang.IFn_Cast(root_4224) } else { ifn_4226 = nil }; var arg_4227 any; var root_4228 any = A_arbace_go_check_A_const_380.GetRawRoot__O(); var linked_4229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4228, A_arbace_go_check_report_errors_A_fn_class); var ifn_4230 lang.IFn; if linked_4229 == nil { ifn_4230 = lang.IFn_Cast(root_4228) } else { ifn_4230 = nil }; var arg_4231 any = rs__9; if linked_4229 == nil { arg_4227 = ifn_4230.Invoke_O__O(arg_4231) } else { arg_4227 = linked_4229.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4228, arg_4231) }; if linked_4225 == nil { tmp14 = ifn_4226.Invoke_O__O(arg_4227) } else { tmp14 = linked_4225.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4224, arg_4227) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_166; var tmp17 any; var root_4232 any = /*line :661:1*/A_arbace_go_check_A_const_239.GetRawRoot__O(); var linked_4233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4232, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4234 lang.IFn; if


	linked_4233 == nil { ifn_4234 = lang.IFn_Cast(root_4232) } else { ifn_4234 = nil }; var arg_4235 any; var iter__1927001039__auto____16 any; var fnbody__4326 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_A_New(); var tmp18 *jrt.Class; var fncls__4325 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class; if fncls__4325 == nil { var fncls__4325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class = fncls__4325d; tmp18 = fncls__4325d } else { tmp18 = fncls__4325 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4326, tmp18, nil); arg_4235 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_4233 == nil { tmp17 = ifn_4234.Invoke_O__O(arg_4235) } else { tmp17 = linked_4233.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4232, arg_4235) }; arg_4223 = /*line :661:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_4220 == nil { ifn_4221.Invoke_O_O__O(arg_4222, arg_4223) } else { linked_4220.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4219, arg_4222, arg_4223) }; var tmp19 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_235.GetRawRoot__O()); var tmp21 any = A_arbace_go_check_A_const_331.Invoke_O__O(sm__10); var tmp22 any; var root_4345 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4345, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4347 lang.IFn; if
	linked_4346 == nil { ifn_4347 = lang.IFn_Cast(root_4345) } else { ifn_4347 = nil }; var arg_4348 any = sm__10; var arg_4349 any = A_arbace_go_check_A_const_382; if linked_4346 == nil { tmp22 = ifn_4347.Invoke_O_O__O(arg_4348, arg_4349) } else { tmp22 = linked_4346.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4345, arg_4348, arg_4349) }; var tmp23 any = tmp22; var tmp24 any; var root_4350 any = /*line :665:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4350, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4352 lang.IFn; if
	linked_4351 == nil { ifn_4352 = lang.IFn_Cast(root_4350) } else { ifn_4352 = nil }; var arg_4353 any = sm__10; var arg_4354 any = A_arbace_go_check_A_const_383; if linked_4351 == nil { tmp24 = ifn_4352.Invoke_O_O__O(arg_4353, arg_4354) } else { tmp24 = linked_4351.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4350, arg_4353, arg_4354) }; var tmp25 any = tmp24; var tmp26 any; var root_4355 any = /*line :665:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4355, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4357 lang.IFn; if

	linked_4356 == nil { ifn_4357 = lang.IFn_Cast(root_4355) } else { ifn_4357 = nil }; var arg_4358 any = sm__10; var arg_4359 any = A_arbace_go_check_A_const_384; if linked_4356 == nil { tmp26 = ifn_4357.Invoke_O_O__O(arg_4358, arg_4359) } else { tmp26 = linked_4356.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4355, arg_4358, arg_4359) }; var tmp27 any = tmp26; var tmp28 any = /*line :665:1*/A_arbace_go_check_A_const_238.Invoke_O__O(sm__10); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp30 any; var root_4364 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4364, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4366 lang.IFn; if


	linked_4365 == nil { ifn_4366 = lang.IFn_Cast(root_4364) } else { ifn_4366 = nil }; var arg_4367 any = sm__10; var arg_4368 any = A_arbace_go_check_A_const_385; if linked_4365 == nil { tmp30 = ifn_4366.Invoke_O_O__O(arg_4367, arg_4368) } else { tmp30 = linked_4365.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4364, arg_4367, arg_4368) }; var tmp31 any = /*line :665:1*/tmp29.Invoke_O__O(tmp30); var tmp32 any; var root_4369 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4369, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4371 lang.IFn; if



	linked_4370 == nil { ifn_4371 = lang.IFn_Cast(root_4369) } else { ifn_4371 = nil }; var arg_4372 any = sm__10; var arg_4373 any = A_arbace_go_check_A_const_386; if linked_4370 == nil { tmp32 = ifn_4371.Invoke_O_O__O(arg_4372, arg_4373) } else { tmp32 = linked_4370.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4369, arg_4372, arg_4373) }; var tmp33 any = tmp32; var tmp34 any; var root_4374 any = /*line :665:1*/A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4374, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4376 lang.IFn; if



	linked_4375 == nil { ifn_4376 = lang.IFn_Cast(root_4374) } else { ifn_4376 = nil }; var arg_4377 any = sm__10; var arg_4378 any = A_arbace_go_check_A_const_387; if linked_4375 == nil { tmp34 = ifn_4376.Invoke_O_O__O(arg_4377, arg_4378) } else { tmp34 = linked_4375.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4374, arg_4377, arg_4378) }; /*line :665:1*/tmp19.Invoke_O__O(tmp20.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(Lit_17, corpus__0, tmp21, tmp23, tmp25, tmp27, tmp28, tmp31, tmp33, tmp34, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000506__16 any; var root_4379 any = /*line :644:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4379, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4381 lang.IFn; if

























	linked_4380 == nil { ifn_4381 = lang.IFn_Cast(root_4379) } else { ifn_4381 = nil }; var arg_4382 any; var root_4383 any = A_arbace_go_check_A_const_388.GetRawRoot__O(); var linked_4384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4383, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_4385 lang.IFn; if linked_4384 == nil { ifn_4385 = lang.IFn_Cast(root_4383) } else { ifn_4385 = nil }; var arg_4386 any = A_arbace_go_check_A_const_389; var arg_4387 any; var root_4388 any = A_arbace_go_check_A_const_380.GetRawRoot__O(); var linked_4389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4388, A_arbace_go_check_report_errors_A_fn_class); var ifn_4390 lang.IFn; if linked_4389 == nil { ifn_4390 = lang.IFn_Cast(root_4388) } else { ifn_4390 = nil }; var arg_4391 any = rs__9; if linked_4389 == nil { arg_4387 = ifn_4390.Invoke_O__O(arg_4391) } else { arg_4387 = linked_4389.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_4388, arg_4391) }; if linked_4384 == nil { arg_4382 = ifn_4385.Invoke_O_O__O(arg_4386, arg_4387) } else { arg_4382 = linked_4384.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_4383, arg_4386, arg_4387) }; if linked_4380 == nil { seq_1685000506__16 = ifn_4381.Invoke_O__O(arg_4382) } else { seq_1685000506__16 = linked_4380.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4379, arg_4382) }; var chunk_1685000507__17 any; var count_1685000508__18 int64 = 0; var i_1685000509__19 int64 = 0; L1:
//line :644:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000509__19, count_1685000508__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000507__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000509__19)); lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__20); seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000509__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_4392 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4394 lang.IFn; if linked_4393 == nil { ifn_4394 = lang.IFn_Cast(root_4392) } else { ifn_4394 = nil }; var arg_4395 any = seq_1685000506__16; if linked_4393 == nil { temp__1927000414__auto____20 = ifn_4394.Invoke_O__O(arg_4395) } else { temp__1927000414__auto____20 = linked_4393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4392, arg_4395) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000506__21 any = temp__1927000414__auto____20; var tmp35 any; var root_4396 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4396, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4398 lang.IFn; if linked_4397 == nil { ifn_4398 = lang.IFn_Cast(root_4396) } else { ifn_4398 = nil }; var arg_4399 any = seq_1685000506__21; if linked_4397 == nil { tmp35 = ifn_4398.Invoke_O__O(arg_4399) } else { tmp35 = linked_4397.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4396, arg_4399) }; if jrt.J2g_Truth(tmp35) { var c__1927000678__auto____22 any; var root_4400 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4400, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4402 lang.IFn; if linked_4401 == nil { ifn_4402 = lang.IFn_Cast(root_4400) } else { ifn_4402 = nil }; var arg_4403 any = seq_1685000506__21; if linked_4401 == nil { c__1927000678__auto____22 = ifn_4402.Invoke_O__O(arg_4403) } else { c__1927000678__auto____22 = linked_4401.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4400, arg_4403) }; var tmp36 any; var root_4449 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4449, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4451 lang.IFn; if linked_4450 == nil { ifn_4451 = lang.IFn_Cast(root_4449) } else { ifn_4451 = nil }; var arg_4452 any = seq_1685000506__21; if linked_4450 == nil { tmp36 = ifn_4451.Invoke_O__O(arg_4452) } else { tmp36 = linked_4450.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4449, arg_4452) }; seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = tmp36, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_4404 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4404, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4406 lang.IFn; if linked_4405 == nil { ifn_4406 = lang.IFn_Cast(root_4404) } else { ifn_4406 = nil }; var arg_4407 any = seq_1685000506__21; if linked_4405 == nil { l__22 = ifn_4406.Invoke_O__O(arg_4407) } else { l__22 = linked_4405.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4404, arg_4407) }; lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O_O__O(Lit_18, l__22); var tmp37 any; var root_4458 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4458, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4460 lang.IFn; if linked_4459 == nil { ifn_4460 = lang.IFn_Cast(root_4458) } else { ifn_4460 = nil }; var arg_4461 any = seq_1685000506__21; if linked_4459 == nil { tmp37 = ifn_4460.Invoke_O__O(arg_4461) } else { tmp37 = linked_4459.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4458, arg_4461) }; seq_1685000506__16, chunk_1685000507__17, count_1685000508__18, i_1685000509__19 = tmp37, nil, 0, 0; continue L1 } } }
//line :644:1
		break L1 }; var tmp38 any; var root_4408 any =


























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4410 lang.IFn; if linked_4409 == nil { ifn_4410 = lang.IFn_Cast(root_4408) } else { ifn_4410 = nil }; var arg_4411 any; var root_4412 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4412, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4414 lang.IFn; if linked_4413 == nil { ifn_4414 = lang.IFn_Cast(root_4412) } else { ifn_4414 = nil }; var arg_4415 any = sm__10; var arg_4416 any = A_arbace_go_check_A_const_390; if linked_4413 == nil { arg_4411 = ifn_4414.Invoke_O_O__O(arg_4415, arg_4416) } else { arg_4411 = linked_4413.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4412, arg_4415, arg_4416) }; if linked_4409 == nil { tmp38 = ifn_4410.Invoke_O__O(arg_4411) } else { tmp38 = linked_4409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4408, arg_4411) }; if jrt.J2g_Truth(tmp38) {
		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp41 any; var root_4426 any = A_arbace_go_check_A_const_77.GetRawRoot__O(); var linked_4427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4426, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_4428 lang.IFn; if linked_4427 == nil { ifn_4428 = lang.IFn_Cast(root_4426) } else { ifn_4428 = nil }; var arg_4429 any = sm__10; var arg_4430 any = A_arbace_go_check_A_const_391; if linked_4427 == nil { tmp41 = ifn_4428.Invoke_O_O__O(arg_4429, arg_4430) } else { tmp41 = linked_4427.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_4426, arg_4429, arg_4430) }; tmp39.Invoke_O_O__O(Lit_19, tmp40.Invoke_O__O(tmp41)) }; var tmp42 any; var root_4431 any =
	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4431, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4433 lang.IFn; if linked_4432 == nil { ifn_4433 = lang.IFn_Cast(root_4431) } else { ifn_4433 = nil }; var arg_4434 any = A_arbace_go_check_A_const_145.Invoke_O__O(sm__10); if linked_4432 == nil { tmp42 = ifn_4433.Invoke_O__O(arg_4434) } else { tmp42 = linked_4432.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4431, arg_4434) }; if jrt.J2g_Truth(tmp42) {
		lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O_O__O(Lit_20, lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_145.Invoke_O__O(sm__10))) }; if
	jrt.J2g_Truth(record__6) {
		var root_4462 any = A_arbace_go_check_A_const_378.GetRawRoot__O(); var linked_4463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4462, A_arbace_go_check_write_edn_A_fn_class); var ifn_4464 lang.IFn; if linked_4463 == nil { ifn_4464 = lang.IFn_Cast(root_4462) } else { ifn_4464 = nil }; var arg_4465 any; var root_4467 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4467, A_arbace_go_check_reference_path_A_fn_class); var ifn_4469 lang.IFn; if linked_4468 == nil { ifn_4469 = lang.IFn_Cast(root_4467) } else { ifn_4469 = nil }; var arg_4470 any = corpus__0; if linked_4468 == nil { arg_4465 = ifn_4469.Invoke_O__O(arg_4470) } else { arg_4465 = linked_4468.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4467, arg_4470) }; var arg_4466 any; var root_4471 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4472 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4471, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4473 lang.IFn; if linked_4472 == nil { ifn_4473 = lang.IFn_Cast(root_4471) } else { ifn_4473 = nil }; var arg_4474 any; var root_4477 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4477, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4479 lang.IFn; if linked_4478 == nil { ifn_4479 = lang.IFn_Cast(root_4477) } else { ifn_4479 = nil }; var arg_4480 any = sm__10; var arg_4481 any = A_arbace_go_check_A_const_337; if linked_4478 == nil { arg_4474 = ifn_4479.Invoke_O_O__O(arg_4480, arg_4481) } else { arg_4474 = linked_4478.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4477, arg_4480, arg_4481) }; var arg_4475 any = A_arbace_go_check_A_const_377; var arg_4476 any = Lit_21; if linked_4472 == nil { arg_4466 = ifn_4473.Invoke_O_O_O__O(arg_4474, arg_4475, arg_4476) } else { arg_4466 = linked_4472.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4471, arg_4474, arg_4475, arg_4476) }; if linked_4463 == nil { ifn_4464.Invoke_O_O__O(arg_4465, arg_4466) } else { linked_4463.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_4462, arg_4465, arg_4466) }
		var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp44 any; var root_4487 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4487, A_arbace_go_check_reference_path_A_fn_class); var ifn_4489 lang.IFn; if linked_4488 == nil { ifn_4489 = lang.IFn_Cast(root_4487) } else { ifn_4489 = nil }; var arg_4490 any = corpus__0; if linked_4488 == nil { tmp44 = ifn_4489.Invoke_O__O(arg_4490) } else { tmp44 = linked_4488.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4487, arg_4490) }; tmp43.Invoke_O_O__O(Lit_22, tmp44)
//line :675:1
		return clean__14 } else { var tmp45 any; var root_4211 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4211, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4213 lang.IFn



			if linked_4212 == nil { ifn_4213 = lang.IFn_Cast(root_4211) } else { ifn_4213 = nil }; var arg_4214 any = clean__14; if linked_4212 == nil { tmp45 = ifn_4213.Invoke_O__O(arg_4214) } else { tmp45 = linked_4212.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4211, arg_4214) }
//line :675:1
			if jrt.J2g_Truth(tmp45) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp47 any; var root_4497 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4497, A_arbace_go_check_reference_path_A_fn_class); var ifn_4499 lang.IFn; if linked_4498 == nil { ifn_4499 = lang.IFn_Cast(root_4497) } else { ifn_4499 = nil }; var arg_4500 any = corpus__0; if linked_4498 == nil { tmp47 = ifn_4499.Invoke_O__O(arg_4500) } else { tmp47 = linked_4498.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4497, arg_4500) }; tmp46.Invoke_O_O_O__O(Lit_23, tmp47, Lit_24)
//line :675:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp48 any; var root_4215 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_4216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4215, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_4217 lang.IFn





					if linked_4216 == nil { ifn_4217 = lang.IFn_Cast(root_4215) } else { ifn_4217 = nil }; var arg_4218 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_4216 == nil { tmp48 = ifn_4217.Invoke_O__O(arg_4218) } else { tmp48 = linked_4216.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_4215, arg_4218) }
//line :675:1
					if jrt.J2g_Truth(tmp48) {





						var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp50 any; var root_4507 any = A_arbace_go_check_A_const_370.GetRawRoot__O(); var linked_4508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4507, A_arbace_go_check_reference_path_A_fn_class); var ifn_4509 lang.IFn; if linked_4508 == nil { ifn_4509 = lang.IFn_Cast(root_4507) } else { ifn_4509 = nil }; var arg_4510 any = corpus__0; if linked_4508 == nil { tmp50 = ifn_4509.Invoke_O__O(arg_4510) } else { tmp50 = linked_4508.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_4507, arg_4510) }; tmp49.Invoke_O_O_O__O(Lit_25, tmp50, Lit_26)
						var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp53 any; var root_4520 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4521 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4520, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4522 lang.IFn; if linked_4521 == nil { ifn_4522 = lang.IFn_Cast(root_4520) } else { ifn_4522 = nil }; var arg_4523 any = ref__13; var arg_4524 any = A_arbace_go_check_A_const_377; if linked_4521 == nil { tmp53 = ifn_4522.Invoke_O_O__O(arg_4523, arg_4524) } else { tmp53 = linked_4521.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4520, arg_4523, arg_4524) }; tmp51.Invoke_O_O__O(Lit_27, tmp52.Invoke_O__O(tmp53))
						var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()); var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_236.GetRawRoot__O()); var tmp56 any; var root_4534 any = A_arbace_go_check_A_const_257.GetRawRoot__O(); var linked_4535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4534, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_4536 lang.IFn; if linked_4535 == nil { ifn_4536 = lang.IFn_Cast(root_4534) } else { ifn_4536 = nil }; var arg_4537 any = sm__10; var arg_4538 any = A_arbace_go_check_A_const_337; if linked_4535 == nil { tmp56 = ifn_4536.Invoke_O_O__O(arg_4537, arg_4538) } else { tmp56 = linked_4535.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_4534, arg_4537, arg_4538) }; tmp54.Invoke_O_O__O(Lit_28, tmp55.Invoke_O__O(tmp56))
//line :675:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_A_New() *A_arbace_go_check_annotations_iter__1685000490__1685000496_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_A) Ctor() {}
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_A) Invoke_O_O__O(self, s__1685000491__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4324 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_New_O_O(s__1685000491__1, self); var tmp2 *jrt.Class; var fncls__4323 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class; if fncls__4323 == nil { var fncls__4323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__4324); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class = fncls__4323d; tmp2 = fncls__4323d } else { tmp2 = fncls__4323 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4324, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A{}; t.Ctor_O_O(p0, p1); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A) Ctor_O_O(c__s__1685000491, c__iter__1685000490 any) { t.F_s__1685000491 = c__s__1685000491; t.F_iter__1685000490 = c__iter__1685000490 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A) Invoke_O__O(self any) any { { var s__1685000491__1 any; var t_ any = t.F_s__1685000491; t.F_s__1685000491 = nil; s__1685000491__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_4236 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4238 lang.IFn; if linked_4237 == nil { ifn_4238 = lang.IFn_Cast(root_4236) } else { ifn_4238 = nil }; var arg_4239 any = s__1685000491__1; if linked_4237 == nil { temp__1927000414__auto____2 = ifn_4238.Invoke_O__O(arg_4239) } else { temp__1927000414__auto____2 = linked_4237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4236, arg_4239) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_4240 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4240, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4242 lang.IFn; if linked_4241 == nil { ifn_4242 = lang.IFn_Cast(root_4240) } else { ifn_4242 = nil }; var arg_4243 any = xs__1927001018__auto____3; if linked_4241 == nil { r__4 = ifn_4242.Invoke_O__O(arg_4243) } else { r__4 = linked_4241.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4240, arg_4243) }; var iterys__1927001035__auto____5 any; var fnbody__4305 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_New_O(r__4); var tmp1 *jrt.Class; var fncls__4304 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class; if fncls__4304 == nil { var fncls__4304d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__4305); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class = fncls__4304d; tmp1 = fncls__4304d } else { tmp1 = fncls__4304 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4305, tmp1, nil); var fs__1927001036__auto____6 any; var root_4306 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4306, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4308 lang.IFn; if linked_4307 == nil { ifn_4308 = lang.IFn_Cast(root_4306) } else { ifn_4308 = nil }; var arg_4309 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_167.Invoke_O__O(r__4)); if linked_4307 == nil { fs__1927001036__auto____6 = ifn_4308.Invoke_O__O(arg_4309) } else { fs__1927001036__auto____6 = linked_4307.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4306, arg_4309) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_4310 any = A_arbace_go_check_A_const_327.GetRawRoot__O(); var linked_4311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4310, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_4312 lang.IFn; if linked_4311 == nil { ifn_4312 = lang.IFn_Cast(root_4310) } else { ifn_4312 = nil }; var arg_4313 any = fs__1927001036__auto____6; var arg_4314 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1685000490); var tmp3 any; var root_4315 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4315, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4317 lang.IFn; if linked_4316 == nil { ifn_4317 = lang.IFn_Cast(root_4315) } else { ifn_4317 = nil }; var arg_4318 any = s__1685000491__1; if linked_4316 == nil { tmp3 = ifn_4317.Invoke_O__O(arg_4318) } else { tmp3 = linked_4316.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4315, arg_4318) }; arg_4314 = tmp2.Invoke_O__O(tmp3); if linked_4311 == nil { return ifn_4312.Invoke_O_O__O(arg_4313, arg_4314) } else { return linked_4311.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_4310, arg_4313, arg_4314) } } else { var tmp4 any; var root_4319 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4319, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4321 lang.IFn; if linked_4320 == nil { ifn_4321 = lang.IFn_Cast(root_4319) } else { ifn_4321 = nil }; var arg_4322 any = s__1685000491__1; if linked_4320 == nil { tmp4 = ifn_4321.Invoke_O__O(arg_4322) } else { tmp4 = linked_4320.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4319, arg_4322) }; s__1685000491__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A{}; t.Ctor_O(p0); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A) Invoke_O_O__O(self, s__1685000493__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4303 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_New_O_O_O(t.F_r, s__1685000493__1, self); var tmp2 *jrt.Class; var fncls__4302 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class; if fncls__4302 == nil { var fncls__4302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__4303); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class = fncls__4302d; tmp2 = fncls__4302d } else { tmp2 = fncls__4302 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4303, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A) Ctor_O_O_O(c__r, c__s__1685000493, c__iter__1685000492 any) { t.F_r = c__r; t.F_s__1685000493 = c__s__1685000493; t.F_iter__1685000492 = c__iter__1685000492 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A) Invoke_O__O(self any) any { { var s__1685000493__1 any; var t_ any = t.F_s__1685000493; t.F_s__1685000493 = nil; s__1685000493__1 = t_; for { var temp__1927000414__auto____2 any; var root_4244 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4246 lang.IFn; if linked_4245 == nil { ifn_4246 = lang.IFn_Cast(root_4244) } else { ifn_4246 = nil }; var arg_4247 any = s__1685000493__1; if linked_4245 == nil { temp__1927000414__auto____2 = ifn_4246.Invoke_O__O(arg_4247) } else { temp__1927000414__auto____2 = linked_4245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4244, arg_4247) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000493__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4248 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4248, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4250 lang.IFn; if linked_4249 == nil { ifn_4250 = lang.IFn_Cast(root_4248) } else { ifn_4250 = nil }; var arg_4251 any = s__1685000493__3; if linked_4249 == nil { tmp1 = ifn_4250.Invoke_O__O(arg_4251) } else { tmp1 = linked_4249.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4248, arg_4251) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4252 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4252, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4254 lang.IFn; if linked_4253 == nil { ifn_4254 = lang.IFn_Cast(root_4252) } else { ifn_4254 = nil }; var arg_4255 any = s__1685000493__3; if linked_4253 == nil { c__1927001037__auto____4 = ifn_4254.Invoke_O__O(arg_4255) } else { c__1927001037__auto____4 = linked_4253.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4252, arg_4255) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000495__6 any; var root_4256 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4256, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4258 lang.IFn; if linked_4257 == nil { ifn_4258 = lang.IFn_Cast(root_4256) } else { ifn_4258 = nil }; var arg_4259 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4257 == nil { b__1685000495__6 = ifn_4258.Invoke_O__O(arg_4259) } else { b__1685000495__6 = linked_4257.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4256, arg_4259) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4266 any = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_New_O_I_O_O(t.F_r, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000495__6); var tmp3 *jrt.Class; var fncls__4265 *jrt.Class = A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class; if fncls__4265 == nil { var fncls__4265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__4266); A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class = fncls__4265d; tmp3 = fncls__4265d } else { tmp3 = fncls__4265 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4266, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4267 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4267, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4269 lang.IFn; if linked_4268 == nil { ifn_4269 = lang.IFn_Cast(root_4267) } else { ifn_4269 = nil }; var arg_4270 any; var root_4272 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4272, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4274 lang.IFn; if linked_4273 == nil { ifn_4274 = lang.IFn_Cast(root_4272) } else { ifn_4274 = nil }; var arg_4275 any = b__1685000495__6; if linked_4273 == nil { arg_4270 = ifn_4274.Invoke_O__O(arg_4275) } else { arg_4270 = linked_4273.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4272, arg_4275) }; var arg_4271 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000492); var tmp5 any; var root_4276 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4276, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4278 lang.IFn; if linked_4277 == nil { ifn_4278 = lang.IFn_Cast(root_4276) } else { ifn_4278 = nil }; var arg_4279 any = s__1685000493__3; if linked_4277 == nil { tmp5 = ifn_4278.Invoke_O__O(arg_4279) } else { tmp5 = linked_4277.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4276, arg_4279) }; arg_4271 = tmp4.Invoke_O__O(tmp5); if linked_4268 == nil { return ifn_4269.Invoke_O_O__O(arg_4270, arg_4271) } else { return linked_4268.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4267, arg_4270, arg_4271) } } else { var root_4280 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4280, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4282 lang.IFn; if linked_4281 == nil { ifn_4282 = lang.IFn_Cast(root_4280) } else { ifn_4282 = nil }; var arg_4283 any; var root_4285 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4285, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4287 lang.IFn; if linked_4286 == nil { ifn_4287 = lang.IFn_Cast(root_4285) } else { ifn_4287 = nil }; var arg_4288 any = b__1685000495__6; if linked_4286 == nil { arg_4283 = ifn_4287.Invoke_O__O(arg_4288) } else { arg_4283 = linked_4286.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4285, arg_4288) }; var arg_4284 any; if linked_4281 == nil { return ifn_4282.Invoke_O_O__O(arg_4283, arg_4284) } else { return linked_4281.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4280, arg_4283, arg_4284) } } } else { var u__4 any; var root_4289 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4291 lang.IFn; if linked_4290 == nil { ifn_4291 = lang.IFn_Cast(root_4289) } else { ifn_4291 = nil }; var arg_4292 any = s__1685000493__3; if linked_4290 == nil { u__4 = ifn_4291.Invoke_O__O(arg_4292) } else { u__4 = linked_4290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4289, arg_4292) }; var root_4293 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4293, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4295 lang.IFn; if linked_4294 == nil { ifn_4295 = lang.IFn_Cast(root_4293) } else { ifn_4295 = nil }; var arg_4296 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), u__4); var arg_4297 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000492); var tmp7 any; var root_4298 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4298, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4300 lang.IFn; if linked_4299 == nil { ifn_4300 = lang.IFn_Cast(root_4298) } else { ifn_4300 = nil }; var arg_4301 any = s__1685000493__3; if linked_4299 == nil { tmp7 = ifn_4300.Invoke_O__O(arg_4301) } else { tmp7 = linked_4299.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4298, arg_4301) }; arg_4297 = tmp6.Invoke_O__O(tmp7); if linked_4294 == nil { return ifn_4295.Invoke_O_O__O(arg_4296, arg_4297) } else { return linked_4294.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4293, arg_4296, arg_4297) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A) Ctor_O_I_O_O(c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000495 any) { t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000495 = c__b__1685000495 }
//line :664:1
func (t *A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A) Invoke_O__O(self any) any { { var i__1685000494__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000494__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000494__1)); var root_4260 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4260, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4262 lang.IFn; if linked_4261 == nil { ifn_4262 = lang.IFn_Cast(root_4260) } else { ifn_4262 = nil }; var arg_4263 any = t.F_b__1685000495; var arg_4264 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_111.Invoke_O__O(t.F_r), u__2); if linked_4261 == nil { ifn_4262.Invoke_O_O__O(arg_4263, arg_4264) } else { linked_4261.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4260, arg_4263, arg_4264) }; i__1685000494__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000494__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :687:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :687:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000511__2 any = args__0; var seq__1685000512__3 any; var root_4539 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4541 lang.IFn; if


	linked_4540 == nil { ifn_4541 = lang.IFn_Cast(root_4539) } else { ifn_4541 = nil }; var arg_4542 any = vec__1685000511__2; if linked_4540 == nil { seq__1685000512__3 = ifn_4541.Invoke_O__O(arg_4542) } else { seq__1685000512__3 = linked_4540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4539, arg_4542) }; var first__1685000513__4 any; var root_4543 any = /*line :687:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4543, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4545 lang.IFn; if


	linked_4544 == nil { ifn_4545 = lang.IFn_Cast(root_4543) } else { ifn_4545 = nil }; var arg_4546 any = seq__1685000512__3; if linked_4544 == nil { first__1685000513__4 = ifn_4545.Invoke_O__O(arg_4546) } else { first__1685000513__4 = linked_4544.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4543, arg_4546) }; var seq__1685000512__5 any; var root_4547 any = /*line :687:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_4548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4547, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4549 lang.IFn; if


	linked_4548 == nil { ifn_4549 = lang.IFn_Cast(root_4547) } else { ifn_4549 = nil }; var arg_4550 any = seq__1685000512__3; if linked_4548 == nil { seq__1685000512__5 = ifn_4549.Invoke_O__O(arg_4550) } else { seq__1685000512__5 = linked_4548.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4547, arg_4550) }; var cmd__6 any = first__1685000513__4; var args__7 any = seq__1685000512__5; var G__1685000514__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000514__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000514__8_, Lit_1) { var opts__9 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__4643 any = A_arbace_go_check__main_fn__1685000515_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__4642 /*line :691:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000515_A_fn_class

		if fncls__4642 == nil { var fncls__4642d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__4643); A_arbace_go_check__main_fn__1685000515_A_fn_class = fncls__4642d; tmp2 = fncls__4642d } else { tmp2 = fncls__4642 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4643, tmp2, nil); opts__9 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :691:1
		var cs__10 any; var tmp3 any; var root_4644 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4644, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4646 lang.IFn











		if linked_4645 == nil { ifn_4646 = lang.IFn_Cast(root_4644) } else { ifn_4646 = nil }; var arg_4647 any = A_arbace_go_check_A_const_393.Invoke_O__O(opts__9); if linked_4645 == nil { tmp3 = ifn_4646.Invoke_O__O(arg_4647) } else { tmp3 = linked_4645.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4644, arg_4647) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_393.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_396.GetRawRoot__O() }
//line :691:1
		var ok__11 any; var root_4734 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_4735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4734, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4736 lang.IFn












		if linked_4735 == nil { ifn_4736 = lang.IFn_Cast(root_4734) } else { ifn_4736 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_170.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_285; var tmp6 any = A_arbace_go_check_A_const_164.Invoke_O__O(opts__9); var tmp7 any = A_arbace_go_check_A_const_363; var arg_4737 any = tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7, A_arbace_go_check_A_const_395.Invoke_O__O(opts__9)); if linked_4735 == nil { ifn_4736.Invoke_O__O(arg_4737) } else { linked_4735.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4734, arg_4737) }; var tmp8 *lang.Compiler_AOTFn; var fnbody__4728 any = A_arbace_go_check__main_fn__1685000518_A_New_O_O(cs__10, opts__9); var tmp9 *jrt.Class; var fncls__4727 *jrt.Class = A_arbace_go_check__main_fn__1685000518_A_fn_class; if fncls__4727 == nil { var fncls__4727d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__4728); A_arbace_go_check__main_fn__1685000518_A_fn_class = fncls__4727d; tmp9 = fncls__4727d } else { tmp9 = fncls__4727 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4728, tmp9, nil); ok__11 = Up_Compiler_AOTFn_IFn(tmp8).Invoke__O()


		var root_4745 any = A_arbace_go_check_A_const_400.GetRawRoot__O(); var linked_4746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4745, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4747 lang.IFn; if linked_4746 == nil { ifn_4747 = lang.IFn_Cast(root_4745) } else { ifn_4747 = nil }; if linked_4746 == nil { ifn_4747.Invoke__O() } else { linked_4746.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4745) }
		var tmp10 int64; var tmp11 any; var root_4729 any = A_arbace_go_check_A_const_398.GetRawRoot__O(); var linked_4730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4729, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_4731 lang.IFn; if linked_4730 == nil { ifn_4731 = lang.IFn_Cast(root_4729) } else { ifn_4731 = nil }; var arg_4732 any = A_arbace_go_check_A_const_399.GetRawRoot__O(); var arg_4733 any = ok__11; if linked_4730 == nil { tmp11 = ifn_4731.Invoke_O_O__O(arg_4732, arg_4733) } else { tmp11 = linked_4730.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_4729, arg_4732, arg_4733) }; if jrt.J2g_Truth(tmp11) { tmp10 = 0 } else { tmp10 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp10)); return nil }
//line :691:1
	default:};

















	lang.IFn_Cast(A_arbace_go_check_A_const_381.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :693:1
func A_arbace_go_check__main_fn__1685000515_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000515_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000515_A{}; t.Ctor_O(p0); return t }
//line :693:1
func (t *A_arbace_go_check__main_fn__1685000515_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :693:1
func (t *A_arbace_go_check__main_fn__1685000515_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_364; var tmp2 any = A_arbace_go_check_A_const_392; var tmp3 any = A_arbace_go_check_A_const_366; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_296.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_393, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_4552 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_4553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4552, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_4554 lang.IFn; if linked_4553 == nil { ifn_4554 = lang.IFn_Cast(root_4552) } else { ifn_4554 = nil }; var arg_4555 any = as__1; if linked_4553 == nil { tmp4 = ifn_4554.Invoke_O__O(arg_4555) } else { tmp4 = linked_4553.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_4552, arg_4555) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000516__3_ any; var root_4556 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4558 lang.IFn

		if linked_4557 == nil { ifn_4558 = lang.IFn_Cast(root_4556) } else { ifn_4558 = nil }; var arg_4559 any = as__1; if linked_4557 == nil { G__1685000516__3_ = ifn_4558.Invoke_O__O(arg_4559) } else { G__1685000516__3_ = linked_4557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4556, arg_4559) }; switch lang.Util_Hash_O__I_NoInit(G__1685000516__3_) >> 10 & 7 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_6) {



			var tmp5 any; var root_4561 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4561, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4563 lang.IFn; if linked_4562 == nil { ifn_4563 = lang.IFn_Cast(root_4561) } else { ifn_4563 = nil }; var arg_4564 any = as__1; if linked_4562 == nil { tmp5 = ifn_4563.Invoke_O__O(arg_4564) } else { tmp5 = linked_4562.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4561, arg_4564) }; var tmp6 any = tmp5; var tmp7 any; var root_4565 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4565, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4567 lang.IFn; if linked_4566 == nil { ifn_4567 = lang.IFn_Cast(root_4565) } else { ifn_4567 = nil }; var arg_4568 any = o__2; var arg_4569 any = A_arbace_go_check_A_const_164; var arg_4570 any; var root_4571 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4571, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4573 lang.IFn; if linked_4572 == nil { ifn_4573 = lang.IFn_Cast(root_4571) } else { ifn_4573 = nil }; var arg_4574 any = as__1; if linked_4572 == nil { arg_4570 = ifn_4573.Invoke_O__O(arg_4574) } else { arg_4570 = linked_4572.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4571, arg_4574) }; if linked_4566 == nil { tmp7 = ifn_4567.Invoke_O_O_O__O(arg_4568, arg_4569, arg_4570) } else { tmp7 = linked_4566.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4565, arg_4568, arg_4569, arg_4570) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :696:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_7) {




			var tmp8 any; var root_4575 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4575, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4577 lang.IFn; if linked_4576 == nil { ifn_4577 = lang.IFn_Cast(root_4575) } else { ifn_4577 = nil }; var arg_4578 any = as__1; if linked_4576 == nil { tmp8 = ifn_4577.Invoke_O__O(arg_4578) } else { tmp8 = linked_4576.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4575, arg_4578) }; var tmp9 any = tmp8; var tmp10 any; var root_4579 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4579, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4581 lang.IFn; if linked_4580 == nil { ifn_4581 = lang.IFn_Cast(root_4579) } else { ifn_4581 = nil }; var arg_4582 any = o__2; var arg_4583 any = A_arbace_go_check_A_const_395; var arg_4584 any; var root_4585 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4585, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4587 lang.IFn; if linked_4586 == nil { ifn_4587 = lang.IFn_Cast(root_4585) } else { ifn_4587 = nil }; var arg_4588 any = as__1; if linked_4586 == nil { arg_4584 = ifn_4587.Invoke_O__O(arg_4588) } else { arg_4584 = linked_4586.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4585, arg_4588) }; if linked_4580 == nil { tmp10 = ifn_4581.Invoke_O_O_O__O(arg_4582, arg_4583, arg_4584) } else { tmp10 = linked_4580.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4579, arg_4582, arg_4583, arg_4584) }; as__1, o__2 = tmp9, tmp10; continue L1 }
//line :696:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_8) {

			var tmp11 any; var root_4589 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4589, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4591 lang.IFn; if linked_4590 == nil { ifn_4591 = lang.IFn_Cast(root_4589) } else { ifn_4591 = nil }; var arg_4592 any = as__1; if linked_4590 == nil { tmp11 = ifn_4591.Invoke_O__O(arg_4592) } else { tmp11 = linked_4590.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4589, arg_4592) }; var tmp12 any = tmp11; var tmp13 any; var root_4593 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4594 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4593, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4595 lang.IFn; if linked_4594 == nil { ifn_4595 = lang.IFn_Cast(root_4593) } else { ifn_4595 = nil }; var arg_4596 any = o__2; var arg_4597 any = A_arbace_go_check_A_const_364; var arg_4598 any; var tmp14 any; var root_4599 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4599, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4601 lang.IFn; if linked_4600 == nil { ifn_4601 = lang.IFn_Cast(root_4599) } else { ifn_4601 = nil }; var arg_4602 any = as__1; if linked_4600 == nil { tmp14 = ifn_4601.Invoke_O__O(arg_4602) } else { tmp14 = linked_4600.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4599, arg_4602) }; arg_4598 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp14))).Ref(); if linked_4594 == nil { tmp13 = ifn_4595.Invoke_O_O_O__O(arg_4596, arg_4597, arg_4598) } else { tmp13 = linked_4594.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4593, arg_4596, arg_4597, arg_4598) }; as__1, o__2 = tmp12, tmp13; continue L1 }
//line :696:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_9) {
			var tmp15 any; var root_4603 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4603, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4605 lang.IFn; if linked_4604 == nil { ifn_4605 = lang.IFn_Cast(root_4603) } else { ifn_4605 = nil }; var arg_4606 any = as__1; if linked_4604 == nil { tmp15 = ifn_4605.Invoke_O__O(arg_4606) } else { tmp15 = linked_4604.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4603, arg_4606) }; var tmp16 any = tmp15; var tmp17 any; var root_4607 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4607, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4609 lang.IFn; if linked_4608 == nil { ifn_4609 = lang.IFn_Cast(root_4607) } else { ifn_4609 = nil }; var arg_4610 any = o__2; var arg_4611 any = A_arbace_go_check_A_const_365; var arg_4612 any = jrt.Boolean_TRUE.Ref(); if linked_4608 == nil { tmp17 = ifn_4609.Invoke_O_O_O__O(arg_4610, arg_4611, arg_4612) } else { tmp17 = linked_4608.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4607, arg_4610, arg_4611, arg_4612) }; as__1, o__2 = tmp16, tmp17; continue L1 }
//line :696:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000516__3_, Lit_10) {


			var tmp18 any; var root_4613 any = A_arbace_go_check_A_const_394.GetRawRoot__O(); var linked_4614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4613, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_4615 lang.IFn; if linked_4614 == nil { ifn_4615 = lang.IFn_Cast(root_4613) } else { ifn_4615 = nil }; var arg_4616 any = as__1; if linked_4614 == nil { tmp18 = ifn_4615.Invoke_O__O(arg_4616) } else { tmp18 = linked_4614.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_4613, arg_4616) }; var tmp19 any = tmp18; var tmp20 any; var root_4617 any = A_arbace_go_check_A_const_106.GetRawRoot__O(); var linked_4618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4617, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_4619 lang.IFn; if linked_4618 == nil { ifn_4619 = lang.IFn_Cast(root_4617) } else { ifn_4619 = nil }; var arg_4620 any = o__2; var arg_4621 any = A_arbace_go_check_A_const_366; var arg_4622 any; var root_4623 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_4624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4623, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_4625 lang.IFn; if linked_4624 == nil { ifn_4625 = lang.IFn_Cast(root_4623) } else { ifn_4625 = nil }; var arg_4626 any = as__1; if linked_4624 == nil { arg_4622 = ifn_4625.Invoke_O__O(arg_4626) } else { arg_4622 = linked_4624.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_4623, arg_4626) }; if linked_4618 == nil { tmp20 = ifn_4619.Invoke_O_O_O__O(arg_4620, arg_4621, arg_4622) } else { tmp20 = linked_4618.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_4617, arg_4620, arg_4621, arg_4622) }; as__1, o__2 = tmp19, tmp20; continue L1 }
//line :696:1
		default:
		}




		var tmp21 any; var root_4627 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4627, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4629 lang.IFn; if linked_4628 == nil { ifn_4629 = lang.IFn_Cast(root_4627) } else { ifn_4629 = nil }; var arg_4630 any = as__1; if linked_4628 == nil { tmp21 = ifn_4629.Invoke_O__O(arg_4630) } else { tmp21 = linked_4628.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4627, arg_4630) }; var tmp22 any = tmp21; var tmp23 any; var root_4631 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_4632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4631, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_4633 lang.IFn; if linked_4632 == nil { ifn_4633 = lang.IFn_Cast(root_4631) } else { ifn_4633 = nil }; var arg_4634 any = o__2; var arg_4635 any = A_arbace_go_check_A_const_393; var arg_4636 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_4637 any; var root_4638 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4638, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4640 lang.IFn; if linked_4639 == nil { ifn_4640 = lang.IFn_Cast(root_4638) } else { ifn_4640 = nil }; var arg_4641 any = as__1; if linked_4639 == nil { arg_4637 = ifn_4640.Invoke_O__O(arg_4641) } else { arg_4637 = linked_4639.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4638, arg_4641) }; if linked_4632 == nil { tmp23 = ifn_4633.Invoke_O_O_O_O__O(arg_4634, arg_4635, arg_4636, arg_4637) } else { tmp23 = linked_4632.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_4631, arg_4634, arg_4635, arg_4636, arg_4637) }; as__1, o__2 = tmp22, tmp23; continue L1 } } }; /*line :693:1*/panic("j2g: unreachable") }










func A_arbace_go_check__main_fn__1685000518_A_New_O_O(p0, p1 any) *A_arbace_go_check__main_fn__1685000518_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_A{}; t.Ctor_O_O(p0, p1); return t }
//line :704:1
func (t *A_arbace_go_check__main_fn__1685000518_A) Ctor_O_O(c__cs, c__opts any) { t.F_cs = c__cs; t.F_opts = c__opts }
//line :704:1
func (t *A_arbace_go_check__main_fn__1685000518_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var root_4648 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_4649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4648, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_4650 lang.IFn; if linked_4649 == nil { ifn_4650 = lang.IFn_Cast(root_4648) } else { ifn_4650 = nil }; var arg_4651 any; var iter__1927001039__auto____3 any; var fnbody__4723 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_New_O(t.F_opts); var tmp2 *jrt.Class; var fncls__4722 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class; if fncls__4722 == nil { var fncls__4722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__4723); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class = fncls__4722d; tmp2 = fncls__4722d } else { tmp2 = fncls__4722 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4723, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var t_ any = t.F_cs; t.F_cs = nil; tmp4 = t_; arg_4651 = tmp3.Invoke_O__O(tmp4); if linked_4649 == nil { tmp1 = ifn_4650.Invoke_O__O(arg_4651) } else { tmp1 = linked_4649.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_4648, arg_4651) } }
//line :704:1
	return nil }(); var root_4724 any = A_arbace_go_check_A_const_168.GetRawRoot__O(); var linked_4725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4724, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4726 lang.IFn; if linked_4725 == nil { ifn_4726 = lang.IFn_Cast(root_4724) } else { ifn_4726 = nil }; if linked_4725 == nil { ifn_4726.Invoke__O() } else { linked_4725.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4724) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A{}; t.Ctor_O(p0); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A) Invoke_O_O__O(self, s__1685000520__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4721 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_New_O_O_O(self, t.F_opts, s__1685000520__1); var tmp2 *jrt.Class; var fncls__4720 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class; if fncls__4720 == nil { var fncls__4720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__4721); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class = fncls__4720d; tmp2 = fncls__4720d } else { tmp2 = fncls__4720 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4721, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :706:1
func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A) Ctor_O_O_O(c__iter__1685000519, c__opts, c__s__1685000520 any) { t.F_iter__1685000519 = c__iter__1685000519; t.F_opts = c__opts; t.F_s__1685000520 = c__s__1685000520 }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A) Invoke_O__O(self any) any { { var s__1685000520__1 any; var t_ any = t.F_s__1685000520; t.F_s__1685000520 = nil; s__1685000520__1 = t_; for { var temp__1927000414__auto____2 any; var root_4652 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_4653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4654 lang.IFn; if linked_4653 == nil { ifn_4654 = lang.IFn_Cast(root_4652) } else { ifn_4654 = nil }; var arg_4655 any = s__1685000520__1; if linked_4653 == nil { temp__1927000414__auto____2 = ifn_4654.Invoke_O__O(arg_4655) } else { temp__1927000414__auto____2 = linked_4653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4652, arg_4655) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000520__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4656 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_4657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4656, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4658 lang.IFn; if linked_4657 == nil { ifn_4658 = lang.IFn_Cast(root_4656) } else { ifn_4658 = nil }; var arg_4659 any = s__1685000520__3; if linked_4657 == nil { tmp1 = ifn_4658.Invoke_O__O(arg_4659) } else { tmp1 = linked_4657.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4656, arg_4659) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4660 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_4661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4660, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4662 lang.IFn; if linked_4661 == nil { ifn_4662 = lang.IFn_Cast(root_4660) } else { ifn_4662 = nil }; var arg_4663 any = s__1685000520__3; if linked_4661 == nil { c__1927001037__auto____4 = ifn_4662.Invoke_O__O(arg_4663) } else { c__1927001037__auto____4 = linked_4661.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4660, arg_4663) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000522__6 any; var root_4664 any = A_arbace_go_check_A_const_159.GetRawRoot__O(); var linked_4665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4664, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4666 lang.IFn; if linked_4665 == nil { ifn_4666 = lang.IFn_Cast(root_4664) } else { ifn_4666 = nil }; var arg_4667 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4665 == nil { b__1685000522__6 = ifn_4666.Invoke_O__O(arg_4667) } else { b__1685000522__6 = linked_4665.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4664, arg_4667) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4679 any = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_New_O_O_I_O(b__1685000522__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4678 *jrt.Class = A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class; if fncls__4678 == nil { var fncls__4678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__4679); A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class = fncls__4678d; tmp3 = fncls__4678d } else { tmp3 = fncls__4678 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4679, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4680 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4680, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4682 lang.IFn; if linked_4681 == nil { ifn_4682 = lang.IFn_Cast(root_4680) } else { ifn_4682 = nil }; var arg_4683 any; var root_4685 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4685, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4687 lang.IFn; if linked_4686 == nil { ifn_4687 = lang.IFn_Cast(root_4685) } else { ifn_4687 = nil }; var arg_4688 any = b__1685000522__6; if linked_4686 == nil { arg_4683 = ifn_4687.Invoke_O__O(arg_4688) } else { arg_4683 = linked_4686.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4685, arg_4688) }; var arg_4684 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000519); var tmp5 any; var root_4689 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_4690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4689, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4691 lang.IFn; if linked_4690 == nil { ifn_4691 = lang.IFn_Cast(root_4689) } else { ifn_4691 = nil }; var arg_4692 any = s__1685000520__3; if linked_4690 == nil { tmp5 = ifn_4691.Invoke_O__O(arg_4692) } else { tmp5 = linked_4690.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4689, arg_4692) }; arg_4684 = tmp4.Invoke_O__O(tmp5); if linked_4681 == nil { return ifn_4682.Invoke_O_O__O(arg_4683, arg_4684) } else { return linked_4681.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4680, arg_4683, arg_4684) } } else { var root_4693 any = A_arbace_go_check_A_const_161.GetRawRoot__O(); var linked_4694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4693, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4695 lang.IFn; if linked_4694 == nil { ifn_4695 = lang.IFn_Cast(root_4693) } else { ifn_4695 = nil }; var arg_4696 any; var root_4698 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var linked_4699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4698, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4700 lang.IFn; if linked_4699 == nil { ifn_4700 = lang.IFn_Cast(root_4698) } else { ifn_4700 = nil }; var arg_4701 any = b__1685000522__6; if linked_4699 == nil { arg_4696 = ifn_4700.Invoke_O__O(arg_4701) } else { arg_4696 = linked_4699.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4698, arg_4701) }; var arg_4697 any; if linked_4694 == nil { return ifn_4695.Invoke_O_O__O(arg_4696, arg_4697) } else { return linked_4694.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4693, arg_4696, arg_4697) } } } else { var c__4 any; var root_4702 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_4703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4702, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4704 lang.IFn; if linked_4703 == nil { ifn_4704 = lang.IFn_Cast(root_4702) } else { ifn_4704 = nil }; var arg_4705 any = s__1685000520__3; if linked_4703 == nil { c__4 = ifn_4704.Invoke_O__O(arg_4705) } else { c__4 = linked_4703.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4702, arg_4705) }; var root_4706 any = A_arbace_go_check_A_const_163.GetRawRoot__O(); var linked_4707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4706, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4708 lang.IFn; if linked_4707 == nil { ifn_4708 = lang.IFn_Cast(root_4706) } else { ifn_4708 = nil }; var arg_4709 any; var root_4711 any = A_arbace_go_check_A_const_397.GetRawRoot__O(); var linked_4712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4711, A_arbace_go_check_annotations_A_fn_class); var ifn_4713 lang.IFn; if linked_4712 == nil { ifn_4713 = lang.IFn_Cast(root_4711) } else { ifn_4713 = nil }; var arg_4714 any = c__4; var arg_4715 any = t.F_opts; if linked_4712 == nil { arg_4709 = ifn_4713.Invoke_O_O__O(arg_4714, arg_4715) } else { arg_4709 = linked_4712.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4711, arg_4714, arg_4715) }; var arg_4710 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000519); var tmp7 any; var root_4716 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_4717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4718 lang.IFn; if linked_4717 == nil { ifn_4718 = lang.IFn_Cast(root_4716) } else { ifn_4718 = nil }; var arg_4719 any = s__1685000520__3; if linked_4717 == nil { tmp7 = ifn_4718.Invoke_O__O(arg_4719) } else { tmp7 = linked_4717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4716, arg_4719) }; arg_4710 = tmp6.Invoke_O__O(tmp7); if linked_4707 == nil { return ifn_4708.Invoke_O_O__O(arg_4709, arg_4710) } else { return linked_4707.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4706, arg_4709, arg_4710) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :706:1
func A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A) Ctor_O_O_I_O(c__b__1685000522, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000522 = c__b__1685000522; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :706:1
func (t *A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A) Invoke_O__O(self any) any { { var i__1685000521__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000521__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000521__1)); var root_4668 any = A_arbace_go_check_A_const_160.GetRawRoot__O(); var linked_4669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4668, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4670 lang.IFn; if linked_4669 == nil { ifn_4670 = lang.IFn_Cast(root_4668) } else { ifn_4670 = nil }; var arg_4671 any = t.F_b__1685000522; var arg_4672 any; var root_4673 any = A_arbace_go_check_A_const_397.GetRawRoot__O(); var linked_4674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4673, A_arbace_go_check_annotations_A_fn_class); var ifn_4675 lang.IFn; if linked_4674 == nil { ifn_4675 = lang.IFn_Cast(root_4673) } else { ifn_4675 = nil }; var arg_4676 any = c__2; var arg_4677 any = t.F_opts; if linked_4674 == nil { arg_4672 = ifn_4675.Invoke_O_O__O(arg_4676, arg_4677) } else { arg_4672 = linked_4674.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_4673, arg_4676, arg_4677) }; if linked_4669 == nil { ifn_4670.Invoke_O_O__O(arg_4671, arg_4672) } else { linked_4669.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4668, arg_4671, arg_4672) }; i__1685000521__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000521__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Var

var A_arbace_go_check_A_const_55 *lang.Keyword

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Var

var A_arbace_go_check_A_const_61 *lang.Keyword

var A_arbace_go_check_A_const_62 *lang.Var

var A_arbace_go_check_A_const_63 *lang.Keyword

var A_arbace_go_check_A_const_64 *lang.Var

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Keyword

var A_arbace_go_check_A_const_67 *lang.Var

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Keyword

var A_arbace_go_check_A_const_73 *lang.Var

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Keyword

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 *lang.Var

var A_arbace_go_check_A_const_78 any

var A_arbace_go_check_A_const_79 *lang.Keyword

var A_arbace_go_check_A_const_80 *lang.Var

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Keyword

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Var

var A_arbace_go_check_A_const_90 *lang.Keyword

var A_arbace_go_check_A_const_91 *lang.Var

var A_arbace_go_check_A_const_92 *lang.Keyword

var A_arbace_go_check_A_const_93 *lang.Var

var A_arbace_go_check_A_const_94 *lang.Keyword

var A_arbace_go_check_A_const_95 any

var A_arbace_go_check_A_const_96 *lang.Keyword

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 *lang.Var

var A_arbace_go_check_A_const_99 any

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Keyword

var A_arbace_go_check_A_const_102 *lang.Var

var A_arbace_go_check_A_const_103 *lang.Var

var A_arbace_go_check_A_const_104 *lang.Var

var A_arbace_go_check_A_const_105 *lang.Var

var A_arbace_go_check_A_const_106 *lang.Var

var A_arbace_go_check_A_const_107 *lang.Keyword

var A_arbace_go_check_A_const_108 *lang.Var

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Keyword

var A_arbace_go_check_A_const_113 *lang.Keyword

var A_arbace_go_check_A_const_114 *lang.Var

var A_arbace_go_check_A_const_115 *lang.Keyword

var A_arbace_go_check_A_const_116 *lang.Keyword

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Keyword

var A_arbace_go_check_A_const_119 *lang.Keyword

var A_arbace_go_check_A_const_120 *lang.Keyword

var A_arbace_go_check_A_const_121 *lang.Keyword

var A_arbace_go_check_A_const_122 *lang.Keyword

var A_arbace_go_check_A_const_123 *lang.Var

var A_arbace_go_check_A_const_124 *lang.Var

var A_arbace_go_check_A_const_125 *lang.Keyword

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Var

var A_arbace_go_check_A_const_128 *lang.Keyword

var A_arbace_go_check_A_const_129 *lang.Var

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Var

var A_arbace_go_check_A_const_133 any

var A_arbace_go_check_A_const_134 *lang.Var

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 any

var A_arbace_go_check_A_const_138 any

var A_arbace_go_check_A_const_139 *lang.Var

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 *lang.Keyword

var A_arbace_go_check_A_const_142 any

var A_arbace_go_check_A_const_143 *lang.Var

var A_arbace_go_check_A_const_144 *lang.Var

var A_arbace_go_check_A_const_145 *lang.Keyword

var A_arbace_go_check_A_const_146 *lang.Keyword

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Keyword

var A_arbace_go_check_A_const_151 *lang.Var

var A_arbace_go_check_A_const_152 *lang.Var

var A_arbace_go_check_A_const_153 *lang.Keyword

var A_arbace_go_check_A_const_154 *lang.Var

var A_arbace_go_check_A_const_155 *lang.Keyword

var A_arbace_go_check_A_const_156 *lang.Keyword

var A_arbace_go_check_A_const_157 *lang.Keyword

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Var

var A_arbace_go_check_A_const_164 *lang.Keyword

var A_arbace_go_check_A_const_165 *lang.Keyword

var A_arbace_go_check_A_const_166 *lang.Keyword

var A_arbace_go_check_A_const_167 *lang.Keyword

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Var

var A_arbace_go_check_A_const_180 *lang.Var

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Var

var A_arbace_go_check_A_const_183 *lang.Var

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Var

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Var

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Var

var A_arbace_go_check_A_const_197 *lang.Var

var A_arbace_go_check_A_const_198 *lang.Keyword

var A_arbace_go_check_A_const_199 *lang.Keyword

var A_arbace_go_check_A_const_200 *lang.Keyword

var A_arbace_go_check_A_const_201 *lang.Keyword

var A_arbace_go_check_A_const_202 *lang.Var

var A_arbace_go_check_A_const_203 *lang.Var

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Keyword

var A_arbace_go_check_A_const_206 *lang.Var

var A_arbace_go_check_A_const_207 *lang.Var

var A_arbace_go_check_A_const_208 *lang.Var

var A_arbace_go_check_A_const_209 *lang.Var

var A_arbace_go_check_A_const_210 *lang.Keyword

var A_arbace_go_check_A_const_211 *lang.Var

var A_arbace_go_check_A_const_212 *lang.Keyword

var A_arbace_go_check_A_const_213 *lang.Var

var A_arbace_go_check_A_const_214 *lang.Var

var A_arbace_go_check_A_const_215 *lang.Keyword

var A_arbace_go_check_A_const_216 *lang.Keyword

var A_arbace_go_check_A_const_217 *lang.Var

var A_arbace_go_check_A_const_218 *lang.Keyword

var A_arbace_go_check_A_const_219 *lang.Var

var A_arbace_go_check_A_const_220 *lang.Var

var A_arbace_go_check_A_const_221 *lang.Var

var A_arbace_go_check_A_const_222 *lang.Var

var A_arbace_go_check_A_const_223 *lang.Keyword

var A_arbace_go_check_A_const_224 *lang.Var

var A_arbace_go_check_A_const_225 *lang.Var

var A_arbace_go_check_A_const_226 *lang.Keyword

var A_arbace_go_check_A_const_227 *lang.Keyword

var A_arbace_go_check_A_const_228 *lang.Keyword

var A_arbace_go_check_A_const_229 *lang.Keyword

var A_arbace_go_check_A_const_230 *lang.Var

var A_arbace_go_check_A_const_231 *lang.Var

var A_arbace_go_check_A_const_232 *lang.Keyword

var A_arbace_go_check_A_const_233 *lang.Keyword

var A_arbace_go_check_A_const_234 *lang.Keyword

var A_arbace_go_check_A_const_235 *lang.Var

var A_arbace_go_check_A_const_236 *lang.Var

var A_arbace_go_check_A_const_237 *lang.Keyword

var A_arbace_go_check_A_const_238 *lang.Keyword

var A_arbace_go_check_A_const_239 *lang.Var

var A_arbace_go_check_A_const_240 *lang.Var

var A_arbace_go_check_A_const_241 *lang.Keyword

var A_arbace_go_check_A_const_242 *lang.Keyword

var A_arbace_go_check_A_const_243 *lang.Keyword

var A_arbace_go_check_A_const_244 *lang.Keyword

var A_arbace_go_check_A_const_245 *lang.Var

var A_arbace_go_check_A_const_246 any

var A_arbace_go_check_A_const_247 any

var A_arbace_go_check_A_const_248 *lang.Keyword

var A_arbace_go_check_A_const_249 *lang.Keyword

var A_arbace_go_check_A_const_250 *lang.Var

var A_arbace_go_check_A_const_251 *lang.Keyword

var A_arbace_go_check_A_const_252 any

var A_arbace_go_check_A_const_253 any

var A_arbace_go_check_A_const_254 *lang.Keyword

var A_arbace_go_check_A_const_255 *lang.Keyword

var A_arbace_go_check_A_const_256 *lang.Keyword

var A_arbace_go_check_A_const_257 *lang.Var

var A_arbace_go_check_A_const_258 *lang.Keyword

var A_arbace_go_check_A_const_259 *lang.Keyword

var A_arbace_go_check_A_const_260 *lang.Keyword

var A_arbace_go_check_A_const_261 *lang.Keyword

var A_arbace_go_check_A_const_262 *lang.Keyword

var A_arbace_go_check_A_const_263 *lang.Keyword

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Var

var A_arbace_go_check_A_const_266 *lang.Keyword

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 *lang.Var

var A_arbace_go_check_A_const_269 *lang.Keyword

var A_arbace_go_check_A_const_270 *lang.Keyword

var A_arbace_go_check_A_const_271 *lang.Var

var A_arbace_go_check_A_const_272 *lang.Var

var A_arbace_go_check_A_const_273 *lang.Var

var A_arbace_go_check_A_const_274 any

var A_arbace_go_check_A_const_275 *lang.Keyword

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Var

var A_arbace_go_check_A_const_278 *lang.Var

var A_arbace_go_check_A_const_279 *lang.Var

var A_arbace_go_check_A_const_280 *lang.Var

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Keyword

var A_arbace_go_check_A_const_283 *lang.Keyword

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 *lang.Var

var A_arbace_go_check_A_const_286 *lang.Keyword

var A_arbace_go_check_A_const_287 *lang.Keyword

var A_arbace_go_check_A_const_288 *lang.Keyword

var A_arbace_go_check_A_const_289 *lang.Keyword

var A_arbace_go_check_A_const_290 any

var A_arbace_go_check_A_const_291 *lang.Keyword

var A_arbace_go_check_A_const_292 any

var A_arbace_go_check_A_const_293 any

var A_arbace_go_check_A_const_294 any

var A_arbace_go_check_A_const_295 *lang.Keyword

var A_arbace_go_check_A_const_296 *lang.Var

var A_arbace_go_check_A_const_297 any

var A_arbace_go_check_A_const_298 any

var A_arbace_go_check_A_const_299 any

var A_arbace_go_check_A_const_300 any

var A_arbace_go_check_A_const_301 any

var A_arbace_go_check_A_const_302 *lang.Keyword

var A_arbace_go_check_A_const_303 any

var A_arbace_go_check_A_const_304 *lang.Var

var A_arbace_go_check_A_const_305 *lang.Var

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 *lang.Var

var A_arbace_go_check_A_const_309 any

var A_arbace_go_check_A_const_310 *lang.Var

var A_arbace_go_check_A_const_311 *lang.Keyword

var A_arbace_go_check_A_const_312 *lang.Keyword

var A_arbace_go_check_A_const_313 *lang.Keyword

var A_arbace_go_check_A_const_314 *lang.Keyword

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 *lang.Var

var A_arbace_go_check_A_const_319 *lang.Var

var A_arbace_go_check_A_const_320 *lang.Var

var A_arbace_go_check_A_const_321 *lang.Keyword

var A_arbace_go_check_A_const_322 *lang.Var

var A_arbace_go_check_A_const_323 *lang.Var

var A_arbace_go_check_A_const_324 *lang.Var

var A_arbace_go_check_A_const_325 *lang.Var

var A_arbace_go_check_A_const_326 any

var A_arbace_go_check_A_const_327 *lang.Var

var A_arbace_go_check_A_const_328 any

var A_arbace_go_check_A_const_329 any

var A_arbace_go_check_A_const_330 *lang.Var

var A_arbace_go_check_A_const_331 *lang.Keyword

var A_arbace_go_check_A_const_332 *lang.Keyword

var A_arbace_go_check_A_const_333 *lang.Keyword

var A_arbace_go_check_A_const_334 *lang.Keyword

var A_arbace_go_check_A_const_335 *lang.Keyword

var A_arbace_go_check_A_const_336 *lang.Var

var A_arbace_go_check_A_const_337 *lang.Keyword

var A_arbace_go_check_A_const_338 *lang.Keyword

var A_arbace_go_check_A_const_339 *lang.Var

var A_arbace_go_check_A_const_340 *lang.Keyword

var A_arbace_go_check_A_const_341 any

var A_arbace_go_check_A_const_342 *lang.Keyword

var A_arbace_go_check_A_const_343 *lang.Keyword

var A_arbace_go_check_A_const_344 *lang.Var

var A_arbace_go_check_A_const_345 any

var A_arbace_go_check_A_const_346 any

var A_arbace_go_check_A_const_347 *lang.Var

var A_arbace_go_check_A_const_348 *lang.Var

var A_arbace_go_check_A_const_349 any

var A_arbace_go_check_A_const_350 *lang.Var

var A_arbace_go_check_A_const_351 any

var A_arbace_go_check_A_const_352 *lang.Var

var A_arbace_go_check_A_const_353 *lang.Var

var A_arbace_go_check_A_const_354 *lang.Var

var A_arbace_go_check_A_const_355 *lang.Var

var A_arbace_go_check_A_const_356 *lang.Var

var A_arbace_go_check_A_const_357 *lang.Var

var A_arbace_go_check_A_const_358 *lang.Var

var A_arbace_go_check_A_const_359 *lang.Var

var A_arbace_go_check_A_const_360 *lang.Var

var A_arbace_go_check_A_const_361 *lang.Var

var A_arbace_go_check_A_const_362 *lang.Var

var A_arbace_go_check_A_const_363 *lang.Var

var A_arbace_go_check_A_const_364 *lang.Keyword

var A_arbace_go_check_A_const_365 *lang.Keyword

var A_arbace_go_check_A_const_366 *lang.Keyword

var A_arbace_go_check_A_const_367 *lang.Var

var A_arbace_go_check_A_const_368 *lang.Var

var A_arbace_go_check_A_const_369 *jrt.Class

var A_arbace_go_check_A_const_370 *lang.Var

var A_arbace_go_check_A_const_371 *lang.Var

var A_arbace_go_check_A_const_372 *lang.Var

var A_arbace_go_check_A_const_373 *lang.Keyword

var A_arbace_go_check_A_const_374 any

var A_arbace_go_check_A_const_375 any

var A_arbace_go_check_A_const_376 any

var A_arbace_go_check_A_const_377 *lang.Keyword

var A_arbace_go_check_A_const_378 *lang.Var

var A_arbace_go_check_A_const_379 *lang.Keyword

var A_arbace_go_check_A_const_380 *lang.Var

var A_arbace_go_check_A_const_381 *lang.Var

var A_arbace_go_check_A_const_382 any

var A_arbace_go_check_A_const_383 any

var A_arbace_go_check_A_const_384 any

var A_arbace_go_check_A_const_385 any

var A_arbace_go_check_A_const_386 any

var A_arbace_go_check_A_const_387 any

var A_arbace_go_check_A_const_388 *lang.Var

var A_arbace_go_check_A_const_389 any

var A_arbace_go_check_A_const_390 any

var A_arbace_go_check_A_const_391 any

var A_arbace_go_check_A_const_392 any

var A_arbace_go_check_A_const_393 *lang.Keyword

var A_arbace_go_check_A_const_394 *lang.Var

var A_arbace_go_check_A_const_395 *lang.Keyword

var A_arbace_go_check_A_const_396 *lang.Var

var A_arbace_go_check_A_const_397 *lang.Var

var A_arbace_go_check_A_const_398 *lang.Var

var A_arbace_go_check_A_const_399 *lang.Var

var A_arbace_go_check_A_const_400 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28(); A_arbace_go_check_A_clinit_p29(); A_arbace_go_check_A_clinit_p30(); A_arbace_go_check_A_clinit_p31(); A_arbace_go_check_A_clinit_p32() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 584); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[183]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[184]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[185]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[186]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[187]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[188]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[189]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[190]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[191]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[192]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[193]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[194]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[195]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[196]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[198]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[199]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[200]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[202]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[203]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[204]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[205]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[207]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[208]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[209]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[210]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[211]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[213]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[214]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[216]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[220] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[221]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[223]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[224]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[226]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[231]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[232]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[233]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_54 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[238]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_60 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_61 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_62 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[245]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_64 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[247]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_66 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_67 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_72 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[255]); A_arbace_go_check_A_const_73 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[257]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[259]); A_arbace_go_check_A_const_77 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[260]); A_arbace_go_check_A_const_78 = A_arbace_go_check_A_const_pool.A[261]; A_arbace_go_check_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_80 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[269]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[271]); A_arbace_go_check_A_const_89 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_91 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_92 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_93 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[276]); A_arbace_go_check_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_95 = A_arbace_go_check_A_const_pool.A[278]; A_arbace_go_check_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[280]); A_arbace_go_check_A_const_98 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[281]) }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = A_arbace_go_check_A_const_pool.A[282]; A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[283]); A_arbace_go_check_A_const_101 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[284]); A_arbace_go_check_A_const_102 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[285]); A_arbace_go_check_A_const_103 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_104 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_105 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_106 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[290]); A_arbace_go_check_A_const_108 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[295]); A_arbace_go_check_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_114 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_119 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_122 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[305]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_124 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]); A_arbace_go_check_A_const_125 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_127 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_129 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[312]); A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_132 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_133 = A_arbace_go_check_A_const_pool.A[316]; A_arbace_go_check_A_const_134 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[317]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[319]); A_arbace_go_check_A_const_137 = A_arbace_go_check_A_const_pool.A[320]; A_arbace_go_check_A_const_138 = A_arbace_go_check_A_const_pool.A[321]; A_arbace_go_check_A_const_139 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_141 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[324]); A_arbace_go_check_A_const_142 = A_arbace_go_check_A_const_pool.A[325]; A_arbace_go_check_A_const_143 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_144 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_145 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_146 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[329]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_150 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_151 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_152 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_153 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_154 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_155 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_156 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_157 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[341]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[343]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_163 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_164 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_165 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_166 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_167 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_179 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_180 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_182 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[367]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_186 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[372]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[373]); A_arbace_go_check_A_const_191 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[377]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_196 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[379]); A_arbace_go_check_A_const_197 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_198 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_199 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_200 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_201 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_202 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_203 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[386]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_205 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_206 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_208 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[391]); A_arbace_go_check_A_const_209 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_210 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_211 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_213 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_214 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_215 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_216 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_217 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[401]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[402]); A_arbace_go_check_A_const_220 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[403]); A_arbace_go_check_A_const_221 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[404]); A_arbace_go_check_A_const_222 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[405]); A_arbace_go_check_A_const_223 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[406]); A_arbace_go_check_A_const_224 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_225 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[409]); A_arbace_go_check_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_230 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[413]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[415]); A_arbace_go_check_A_const_233 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[416]); A_arbace_go_check_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_235 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_236 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_239 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_240 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_241 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[424]); A_arbace_go_check_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[425]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_244 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_245 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[428]); A_arbace_go_check_A_const_246 = A_arbace_go_check_A_const_pool.A[429]; A_arbace_go_check_A_const_247 = A_arbace_go_check_A_const_pool.A[430]; A_arbace_go_check_A_const_248 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_249 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_250 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[433]); A_arbace_go_check_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_252 = A_arbace_go_check_A_const_pool.A[435]; A_arbace_go_check_A_const_253 = A_arbace_go_check_A_const_pool.A[436]; A_arbace_go_check_A_const_254 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_255 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_257 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[440]); A_arbace_go_check_A_const_258 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_260 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_261 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_262 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[445]); A_arbace_go_check_A_const_263 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[447]); A_arbace_go_check_A_const_265 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_266 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[451]); A_arbace_go_check_A_const_269 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[452]); A_arbace_go_check_A_const_270 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_271 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_272 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[455]); A_arbace_go_check_A_const_273 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_274 = A_arbace_go_check_A_const_pool.A[457]; A_arbace_go_check_A_const_275 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_277 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_278 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_279 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[464]); A_arbace_go_check_A_const_282 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_283 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_285 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_286 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_287 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_288 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[471]); A_arbace_go_check_A_const_289 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[472]); A_arbace_go_check_A_const_290 = A_arbace_go_check_A_const_pool.A[473]; A_arbace_go_check_A_const_291 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[474]) }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = A_arbace_go_check_A_const_pool.A[475]; A_arbace_go_check_A_const_293 = A_arbace_go_check_A_const_pool.A[476]; A_arbace_go_check_A_const_294 = A_arbace_go_check_A_const_pool.A[477]; A_arbace_go_check_A_const_295 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[478]); A_arbace_go_check_A_const_296 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[479]); A_arbace_go_check_A_const_297 = A_arbace_go_check_A_const_pool.A[480]; A_arbace_go_check_A_const_298 = A_arbace_go_check_A_const_pool.A[481]; A_arbace_go_check_A_const_299 = A_arbace_go_check_A_const_pool.A[482]; A_arbace_go_check_A_const_300 = A_arbace_go_check_A_const_pool.A[483]; A_arbace_go_check_A_const_301 = A_arbace_go_check_A_const_pool.A[484]; A_arbace_go_check_A_const_302 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_303 = A_arbace_go_check_A_const_pool.A[486]; A_arbace_go_check_A_const_304 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[487]); A_arbace_go_check_A_const_305 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[488]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[489]); A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[490]); A_arbace_go_check_A_const_308 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[491]); A_arbace_go_check_A_const_309 = A_arbace_go_check_A_const_pool.A[492]; A_arbace_go_check_A_const_310 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[493]); A_arbace_go_check_A_const_311 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[494]); A_arbace_go_check_A_const_312 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[495]); A_arbace_go_check_A_const_313 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[496]); A_arbace_go_check_A_const_314 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[498]); A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[500]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_318 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_319 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]); A_arbace_go_check_A_const_320 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_321 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[504]); A_arbace_go_check_A_const_322 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[505]); A_arbace_go_check_A_const_323 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[506]); A_arbace_go_check_A_const_324 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[507]); A_arbace_go_check_A_const_325 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[508]); A_arbace_go_check_A_const_326 = A_arbace_go_check_A_const_pool.A[509]; A_arbace_go_check_A_const_327 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[510]); A_arbace_go_check_A_const_328 = A_arbace_go_check_A_const_pool.A[511]; A_arbace_go_check_A_const_329 = A_arbace_go_check_A_const_pool.A[512] }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_330 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[513]); A_arbace_go_check_A_const_331 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[514]); A_arbace_go_check_A_const_332 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[515]); A_arbace_go_check_A_const_333 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[516]); A_arbace_go_check_A_const_334 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[517]); A_arbace_go_check_A_const_335 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[518]); A_arbace_go_check_A_const_336 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[519]); A_arbace_go_check_A_const_337 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[520]); A_arbace_go_check_A_const_338 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[521]); A_arbace_go_check_A_const_339 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[522]); A_arbace_go_check_A_const_340 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[523]); A_arbace_go_check_A_const_341 = A_arbace_go_check_A_const_pool.A[524] }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[525]); A_arbace_go_check_A_const_343 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[526]); A_arbace_go_check_A_const_344 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[527]); A_arbace_go_check_A_const_345 = A_arbace_go_check_A_const_pool.A[528]; A_arbace_go_check_A_const_346 = A_arbace_go_check_A_const_pool.A[529]; A_arbace_go_check_A_const_347 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[530]); A_arbace_go_check_A_const_348 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[531]); A_arbace_go_check_A_const_349 = A_arbace_go_check_A_const_pool.A[532]; A_arbace_go_check_A_const_350 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[533]); A_arbace_go_check_A_const_351 = A_arbace_go_check_A_const_pool.A[534]; A_arbace_go_check_A_const_352 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[535]); A_arbace_go_check_A_const_353 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[536]); A_arbace_go_check_A_const_354 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[537]) }

func A_arbace_go_check_A_clinit_p29() { A_arbace_go_check_A_const_355 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[538]); A_arbace_go_check_A_const_356 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[539]); A_arbace_go_check_A_const_357 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[540]); A_arbace_go_check_A_const_358 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[541]); A_arbace_go_check_A_const_359 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[542]); A_arbace_go_check_A_const_360 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[543]); A_arbace_go_check_A_const_361 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[544]); A_arbace_go_check_A_const_362 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[545]); A_arbace_go_check_A_const_363 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[546]); A_arbace_go_check_A_const_364 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[547]); A_arbace_go_check_A_const_365 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[548]); A_arbace_go_check_A_const_366 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[549]) }

func A_arbace_go_check_A_clinit_p30() { A_arbace_go_check_A_const_367 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[550]); A_arbace_go_check_A_const_368 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[551]); A_arbace_go_check_A_const_369 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[552]); A_arbace_go_check_A_const_370 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[553]); A_arbace_go_check_A_const_371 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[554]); A_arbace_go_check_A_const_372 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[555]); A_arbace_go_check_A_const_373 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[556]); A_arbace_go_check_A_const_374 = A_arbace_go_check_A_const_pool.A[557]; A_arbace_go_check_A_const_375 = A_arbace_go_check_A_const_pool.A[558]; A_arbace_go_check_A_const_376 = A_arbace_go_check_A_const_pool.A[559]; A_arbace_go_check_A_const_377 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[560]); A_arbace_go_check_A_const_378 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[561]) }

func A_arbace_go_check_A_clinit_p31() { A_arbace_go_check_A_const_379 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[562]); A_arbace_go_check_A_const_380 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[563]); A_arbace_go_check_A_const_381 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[564]); A_arbace_go_check_A_const_382 = A_arbace_go_check_A_const_pool.A[565]; A_arbace_go_check_A_const_383 = A_arbace_go_check_A_const_pool.A[566]; A_arbace_go_check_A_const_384 = A_arbace_go_check_A_const_pool.A[567]; A_arbace_go_check_A_const_385 = A_arbace_go_check_A_const_pool.A[568]; A_arbace_go_check_A_const_386 = A_arbace_go_check_A_const_pool.A[569]; A_arbace_go_check_A_const_387 = A_arbace_go_check_A_const_pool.A[570]; A_arbace_go_check_A_const_388 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[571]); A_arbace_go_check_A_const_389 = A_arbace_go_check_A_const_pool.A[572]; A_arbace_go_check_A_const_390 = A_arbace_go_check_A_const_pool.A[573]; A_arbace_go_check_A_const_391 = A_arbace_go_check_A_const_pool.A[574]; A_arbace_go_check_A_const_392 = A_arbace_go_check_A_const_pool.A[575] }

func A_arbace_go_check_A_clinit_p32() { A_arbace_go_check_A_const_393 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[576]); A_arbace_go_check_A_const_394 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[577]); A_arbace_go_check_A_const_395 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[578]); A_arbace_go_check_A_const_396 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[579]); A_arbace_go_check_A_const_397 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[580]); A_arbace_go_check_A_const_398 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[581]); A_arbace_go_check_A_const_399 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[582]); A_arbace_go_check_A_const_400 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[583]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000515_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000515_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_A struct{ j2g_header uint64; F_cs, F_opts any }

var A_arbace_go_check__main_fn__1685000518_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A struct{ j2g_header uint64; F_iter__1685000519, F_opts, F_s__1685000520 any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A struct{ j2g_header uint64; F_b__1685000522, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_fn__1685000518_iter__1685000519__1685000523_fn__1685000524_fn__1685000525_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A struct{ j2g_header uint64; F_s__1685000491, F_iter__1685000490 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A struct{ j2g_header uint64; F_r, F_s__1685000493, F_iter__1685000492 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000495 any }

var A_arbace_go_check_annotations_iter__1685000490__1685000496_fn__1685000497_iter__1685000492__1685000498_fn__1685000499_fn__1685000500_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000370_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000374_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000374_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000378_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000378_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000384_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000398_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000384_fn__1685000400_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A struct{ j2g_header uint64; F_s__1685000389, F_iter__1685000388 any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A struct{ j2g_header uint64; F_b__1685000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000388__1685000392_fn__1685000393_fn__1685000394_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A struct{ j2g_header uint64; F_iter__1685000402, F_dir, F_tdir, F_ts, F_s__1685000403 any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A struct{ j2g_header uint64; F_dir, F_b__1685000405, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000408_fn__1685000412_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000384_iter__1685000402__1685000406_fn__1685000407_fn__1685000418_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A struct{ j2g_header uint64; F_s__1685000361, F_iter__1685000360 any }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000363 any }

var A_arbace_go_check_check_corpus_iter__1685000360__1685000364_fn__1685000365_fn__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000129_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000129_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000131_A struct{ j2g_header uint64; F_src, F_pkg, F_resolve any }

var A_arbace_go_check_check_package_fn__1685000131_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000179_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000186_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000186_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000193_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000193_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000203_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000203_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000205_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000205_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000239_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000239_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000241_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000241_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000247_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000247_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_A struct{ j2g_header uint64; F_resolving any }

var A_arbace_go_check_check_package_fn__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000254_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000256_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000258_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000260_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000262_fn__1685000263_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000282_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000284_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000286_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A struct{ j2g_header uint64; F_form, F_ds, F_unver any }

var A_arbace_go_check_check_package_fn__1685000250_fn__1685000288_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A struct{ j2g_header uint64; F_s__1685000267, F_iter__1685000266, F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A struct{ j2g_header uint64; F_b__1685000269 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_verified any }

var A_arbace_go_check_check_package_fn__1685000250_iter__1685000266__1685000270_fn__1685000271_fn__1685000272_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000299_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000299_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000311_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000311_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000311_fn__1685000312_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000231_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000231_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000231_one__1685000232_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A struct{ j2g_header uint64; F_s__1685000302, F_iter__1685000301 any }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A struct{ j2g_header uint64; F_b__1685000304 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000301__1685000305_fn__1685000306_fn__1685000307_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000235_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000235_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000235_fn__1685000236_A_fn_class *jrt.Class



type A_arbace_go_check_check_src_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_src_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000321_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000321_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000467_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000467_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A struct{ j2g_header uint64; F_iter__1685000469, F_s__1685000470 any }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1685000472, F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000469__1685000473_fn__1685000474_fn__1685000475_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_ns_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ns_package_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000083_A_fn_class *jrt.Class



type A_arbace_go_check_number_local_types_BANG__fn__1685000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_number_local_types_BANG__fn__1685000089_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A struct{ j2g_header uint64; F_iter__1685000447, F_s__1685000448 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A struct{ j2g_header uint64; F_iter__1685000449, F_r, F_s__1685000450 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A struct{ j2g_header uint64; F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000452 any }

var A_arbace_go_check_report_errors_iter__1685000447__1685000453_fn__1685000454_iter__1685000449__1685000455_fn__1685000456_fn__1685000457_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000318_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000318_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A struct{ j2g_header uint64; F_iter__1685000338, F_f, F_out, F_q, F_xs, F_s__1685000339 any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_b__1685000341, F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000344_fn__1685000345_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000338__1685000342_fn__1685000343_fn__1685000348_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000333_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000333_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000333_fn__1685000334_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000434_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000434_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000436_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000436_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000438_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000438_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000440_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000440_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000442_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000442_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000444_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000444_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000432_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000432_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000430_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000430_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000483_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000483_A_fn_class *jrt.Class
