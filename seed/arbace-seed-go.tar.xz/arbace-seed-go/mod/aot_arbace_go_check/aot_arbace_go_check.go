//line aot_arbace_go_check.ae:1
package aot_arbace_go_check

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_repr_go_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_New() *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_1); lang.IFn_Cast(A_arbace_go_check_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_go_check_A_const_3, A_arbace_go_check_A_const_4, A_arbace_go_check_A_const_5, A_arbace_go_check_A_const_6, A_arbace_go_check_A_const_7, A_arbace_go_check_A_const_8, A_arbace_go_check_A_const_9, A_arbace_go_check_A_const_10, A_arbace_go_check_A_const_11, A_arbace_go_check_A_const_12); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_103)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_eval1685000008_fn__1685000009_A_New() *A_arbace_go_check_eval1685000008_fn__1685000009_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_eval1685000008_fn__1685000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_eval1685000008_fn__1685000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_13.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_go_check_A_const_15; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_A_const_16.GetRawRoot__O(), A_arbace_go_check_A_const_17) }





























func A_arbace_go_check_annotations_present_A_New() *A_arbace_go_check_annotations_present_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_check_annotations_present_A) Invoke_O_O__O(self, form__0 any) any { var acc__2 any; var root_28 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_30 lang.IFn; if




	linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_29 == nil { acc__2 = ifn_30.Invoke_O__O(arg_31) } else { acc__2 = linked_29.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_28, arg_31) }; var add_BANG___3 any; var tmp1 any = /*line :31:1*/A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(acc__2); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class; if





	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; add_BANG___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var body_walk__4 /*line :31:1*/*A_arbace_go_check_annotations_present_walk__1685000014_A = A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(add_BANG___3); var walk__4 any; var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp3, nil);



























	lang.IFn_Cast(walk__4).Invoke_O_O__O(form__0, jrt.Boolean_FALSE.Ref()); var root_45 any = /*line :36:1*/A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = acc__2; if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_annotations_present_add_BANG___1685000012_A_New_O(p0 any) *A_arbace_go_check_annotations_present_add_BANG___1685000012_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_add_BANG___1685000012_A{}; t.Ctor_O(p0); return t }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :37:1
func (t *A_arbace_go_check_annotations_present_add_BANG___1685000012_A) Invoke_O_O_O__O(self, k__1, n__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(t.F_acc); var tmp2 any; var root_32 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = jrt.NN(lang.Volatile_Cast(t.F_acc)).Deref__O(); var arg_36 any = k__1; var arg_37 any; var root_39 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_43 any = A_arbace_go_check_A_const_22; if linked_40 == nil { arg_37 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_37 = linked_40.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; var arg_38 any = n__2; if linked_33 == nil { tmp2 = ifn_34.Invoke_O_O_O_O__O(arg_35, arg_36, arg_37, arg_38) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_32, arg_35, arg_36, arg_37, arg_38) }; return jrt.NN(tmp1).Reset_O__O(tmp2) }
func A_arbace_go_check_annotations_present_walk__1685000014_A_New_O(p0 any) *A_arbace_go_check_annotations_present_walk__1685000014_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_present_walk__1685000014_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Ctor_O(c__add_BANG_ any) { t.F_add_BANG_ = c__add_BANG_ }
//line :38:1
func (t *A_arbace_go_check_annotations_present_walk__1685000014_A) Invoke_O_O_O__O(self, f__1, in_meta__2 any) any {
	var tmp1 any; var root_49 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_51 lang.IFn
	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = f__1; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_49, arg_52) }
//line :39:1
	if jrt.J2g_Truth(tmp1) { var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp2 any; var and__1927000168__auto____4 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3)


		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_89 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = in_meta__2; if linked_90 == nil { and__1927000168__auto____5 = ifn_91.Invoke_O__O(arg_92) } else { and__1927000168__auto____5 = linked_90.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_93 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_go_check_A_const_37; var arg_97 any; var root_98 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = f__1; if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_24, A_arbace_go_check_A_const_43) }
		var tmp3 any; var and__1927000168__auto____4_2 bool; var tmp4 any = A_arbace_go_check_A_const_38; var tmp5 any; var root_102 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp5 = ifn_104.Invoke_O__O(arg_105) } else { tmp5 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; and__1927000168__auto____4_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____4_2 { var root_106 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = m__3; var arg_110 any = A_arbace_go_check_A_const_40; if linked_107 == nil { tmp3 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp3 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if jrt.J2g_Truth(tmp3) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
		var tmp6 any; var and__1927000168__auto____4_3 bool; var tmp7 any = A_arbace_go_check_A_const_41; var tmp8 any; var root_111 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp8 = ifn_113.Invoke_O__O(arg_114) } else { tmp8 = linked_112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_111, arg_114) }; and__1927000168__auto____4_3 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____4_3 { tmp6 = A_arbace_go_check_A_const_42.Invoke_O__O(m__3) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_3).Ref() }; if jrt.J2g_Truth(tmp6) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
//line :39:1
		var temp__1927000414__auto____4 any = A_arbace_go_check_A_const_29.Invoke_O__O(m__3)





		if jrt.J2g_Truth(temp__1927000414__auto____4) { var v__5 any = temp__1927000414__auto____4; var tmp9 lang.IFn = lang.IFn_Cast(t.F_add_BANG_); var tmp10 any = A_arbace_go_check_A_const_29; var tmp11 any; var tmp12 any; var root_115 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = v__5; if linked_116 == nil { tmp12 = ifn_117.Invoke_O__O(arg_118) } else { tmp12 = linked_116.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp12) { tmp11 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__5)).Ref() } else { tmp11 = A_arbace_go_check_A_const_43 }; tmp9.Invoke_O_O__O(tmp10, tmp11) }
		var tmp13 any = A_arbace_go_check_A_const_30; var tmp14 any; var root_65 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = f__1; if linked_66 == nil { tmp14 = ifn_67.Invoke_O__O(arg_68) } else { tmp14 = linked_66.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_65, arg_68) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, tmp14) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_44, A_arbace_go_check_A_const_43) }
//line :39:1
		var seq_1685000015__3 any; var root_69 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn







		if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = f__1; if linked_70 == nil { seq_1685000015__3 = ifn_71.Invoke_O__O(arg_72) } else { seq_1685000015__3 = linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) }
//line :39:1
		var chunk_1685000016__4 any; var count_1685000017__5 int64 = 0; var i_1685000018__6 int64 = 0; L1: for {







			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000018__6, count_1685000017__5) { var x__7 any = lang.Indexed_Cast(chunk_1685000016__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000018__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7, in_meta__2); seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000018__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_73 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = seq_1685000015__3; if linked_74 == nil { temp__1927000414__auto____7 = ifn_75.Invoke_O__O(arg_76) } else { temp__1927000414__auto____7 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1685000015__8 any = temp__1927000414__auto____7; var tmp15 any; var root_77 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = seq_1685000015__8; if linked_78 == nil { tmp15 = ifn_79.Invoke_O__O(arg_80) } else { tmp15 = linked_78.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____9 any; var root_81 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = seq_1685000015__8; if linked_82 == nil { c__1927000678__auto____9 = ifn_83.Invoke_O__O(arg_84) } else { c__1927000678__auto____9 = linked_82.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_81, arg_84) }; var tmp16 any; var root_119 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = seq_1685000015__8; if linked_120 == nil { tmp16 = ifn_121.Invoke_O__O(arg_122) } else { tmp16 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp16, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any; var root_85 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1685000015__8; if linked_86 == nil { x__9 = ifn_87.Invoke_O__O(arg_88) } else { x__9 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9, in_meta__2); var tmp17 any; var root_123 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq_1685000015__8; if linked_124 == nil { tmp17 = ifn_125.Invoke_O__O(arg_126) } else { tmp17 = linked_124.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_123, arg_126) }; seq_1685000015__3, chunk_1685000016__4, count_1685000017__5, i_1685000018__6 = tmp17, nil, 0, 0; continue L1 } } }
//line :39:1
			break L1 }; var tmp18 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3 any = tmp18.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))








		if jrt.J2g_Truth(temp__1927000414__auto____3) { var tg__4 any = temp__1927000414__auto____3; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
			var tmp19 any; var root_53 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_55 lang.IFn









			if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__1; if linked_54 == nil { tmp19 = ifn_55.Invoke_O__O(arg_56) } else { tmp19 = linked_54.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_53, arg_56) }
//line :39:1
			if jrt.J2g_Truth(tmp19) { var m__3_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); var tmp20 any; var root_127 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_129 lang.IFn











				if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = m__3_2; var arg_131 any = A_arbace_go_check_A_const_40; if linked_128 == nil { tmp20 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp20 = linked_128.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if jrt.J2g_Truth(tmp20) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_40, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_42.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_42, A_arbace_go_check_A_const_43) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_47.Invoke_O__O(m__3_2)) { lang.IFn_Cast(t.F_add_BANG_).Invoke_O_O__O(A_arbace_go_check_A_const_47, A_arbace_go_check_A_const_43) }
//line :39:1
				var temp__1927000414__auto____4_2 any = A_arbace_go_check_A_const_24.Invoke_O__O(m__3_2)














				if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var tg__5 any = temp__1927000414__auto____4_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__5, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
					var tmp21 any; var root_57 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_59 lang.IFn















					if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = f__1; if linked_58 == nil { tmp21 = ifn_59.Invoke_O__O(arg_60) } else { tmp21 = linked_58.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_57, arg_60) }
//line :39:1
					if jrt.J2g_Truth(tmp21) { var seq_1685000019__3 any; var root_132 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn















						if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__1; if linked_133 == nil { seq_1685000019__3 = ifn_134.Invoke_O__O(arg_135) } else { seq_1685000019__3 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }
//line :39:1
						var chunk_1685000020__4 any; var count_1685000021__5 int64 = 0; var i_1685000022__6 int64 = 0; L2: for {















							if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000022__6, count_1685000021__5) { var x__7_2 any = lang.Indexed_Cast(chunk_1685000020__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000022__6)); lang.IFn_Cast(self).Invoke_O_O__O(x__7_2, in_meta__2); seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000022__6); continue L2 } else { var temp__1927000414__auto____7_2 any; var root_136 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = seq_1685000019__3; if linked_137 == nil { temp__1927000414__auto____7_2 = ifn_138.Invoke_O__O(arg_139) } else { temp__1927000414__auto____7_2 = linked_137.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_136, arg_139) }; if jrt.J2g_Truth(temp__1927000414__auto____7_2) { var seq_1685000019__8 any = temp__1927000414__auto____7_2; var tmp22 any; var root_140 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = seq_1685000019__8; if linked_141 == nil { tmp22 = ifn_142.Invoke_O__O(arg_143) } else { tmp22 = linked_141.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____9_2 any; var root_144 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = seq_1685000019__8; if linked_145 == nil { c__1927000678__auto____9_2 = ifn_146.Invoke_O__O(arg_147) } else { c__1927000678__auto____9_2 = linked_145.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_144, arg_147) }; var tmp23 any; var root_152 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = seq_1685000019__8; if linked_153 == nil { tmp23 = ifn_154.Invoke_O__O(arg_155) } else { tmp23 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_152, arg_155) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp23, c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__9_2 any; var root_148 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = seq_1685000019__8; if linked_149 == nil { x__9_2 = ifn_150.Invoke_O__O(arg_151) } else { x__9_2 = linked_149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_148, arg_151) }; lang.IFn_Cast(self).Invoke_O_O__O(x__9_2, in_meta__2); var tmp24 any; var root_156 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = seq_1685000019__8; if linked_157 == nil { tmp24 = ifn_158.Invoke_O__O(arg_159) } else { tmp24 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; seq_1685000019__3, chunk_1685000020__4, count_1685000021__5, i_1685000022__6 = tmp24, nil, 0, 0; continue L2 } } }
//line :39:1
							break L2 }; var tmp25 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____3_2 any = tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
















						if jrt.J2g_Truth(temp__1927000414__auto____3_2) { var tg__4_2 any = temp__1927000414__auto____3_2; return lang.IFn_Cast(self).Invoke_O_O__O(tg__4_2, jrt.Boolean_TRUE.Ref()) } else { return nil } } else {
//line :39:1
							var tmp26 any; var root_61 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_63 lang.IFn

















							if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = f__1; if linked_62 == nil { tmp26 = ifn_63.Invoke_O__O(arg_64) } else { tmp26 = linked_62.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_61, arg_64) }
//line :39:1
							if jrt.J2g_Truth(tmp26) { return nil } else { if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil
							}
							}
						}
				}
		}
}


















func A_arbace_go_check_nodes_seq_A_New() *A_arbace_go_check_nodes_seq_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_nodes_seq_A) Invoke_O_O__O(self, tree__0 any) any { var acc__2 any = jrt.ArrayList_New(); var seen__3 any = jrt.IdentityHashMap_New(); var body_walk__4 *A_arbace_go_check_nodes_seq_walk__1685000025_A = A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(seen__3, acc__2); var walk__4 any; var tmp1 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class = fncls__237d; tmp1 = fncls__237d } else { tmp1 = fncls__237 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__4), tmp1, nil);













	lang.IFn_Cast(walk__4).Invoke_O__O(tree__0); return acc__2 }
//line :69:1
func A_arbace_go_check_nodes_seq_walk__1685000025_A_New_O_O(p0, p1 any) *A_arbace_go_check_nodes_seq_walk__1685000025_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_nodes_seq_walk__1685000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Ctor_O_O(c__seen, c__acc any) { t.F_seen = c__seen; t.F_acc = c__acc }
//line :69:1
func (t *A_arbace_go_check_nodes_seq_walk__1685000025_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_161 any = A_arbace_go_check_A_const_27.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_163 lang.IFn
		if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = x__1; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_161, arg_164) }
//line :70:1
		if jrt.J2g_Truth(tmp1) {
			if lang.Util_Identical_O_O__Z_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).Put_O_O__O(x__1, jrt.Boolean_TRUE.Ref()), nil) {
				if jrt.J2g_Truth(A_arbace_go_check_A_const_50.Invoke_O__O(x__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(x__1)) }
//line :71:1
				var seq_1685000026__2 any; var root_165 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_167 lang.IFn

				if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__1; if linked_166 == nil { seq_1685000026__2 = ifn_167.Invoke_O__O(arg_168) } else { seq_1685000026__2 = linked_166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_165, arg_168) }
//line :71:1
				var chunk_1685000027__3 any; var count_1685000028__4 int64 = 0; var i_1685000029__5 int64 = 0; L1: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000029__5, count_1685000028__4) { var vec__1685000030__6 any = lang.Indexed_Cast(chunk_1685000027__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000029__5)); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_169 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.IFn_Cast(A_arbace_go_check_A_const_48).Invoke_O__O(k__7); if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__8)
//line :73:1
						seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } else { seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000029__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = seq_1685000026__2; if linked_174 == nil { temp__1927000414__auto____6 = ifn_175.Invoke_O__O(arg_176) } else { temp__1927000414__auto____6 = linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000026__7 any = temp__1927000414__auto____6; var tmp3 any; var root_177 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = seq_1685000026__7; if linked_178 == nil { tmp3 = ifn_179.Invoke_O__O(arg_180) } else { tmp3 = linked_178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_181 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = seq_1685000026__7; if linked_182 == nil { c__1927000678__auto____8 = ifn_183.Invoke_O__O(arg_184) } else { c__1927000678__auto____8 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_181, arg_184) }; var tmp4 any; var root_217 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1685000026__7; if linked_218 == nil { tmp4 = ifn_219.Invoke_O__O(arg_220) } else { tmp4 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1685000033__8 any; var root_185 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1685000026__7; if linked_186 == nil { vec__1685000033__8 = ifn_187.Invoke_O__O(arg_188) } else { vec__1685000033__8 = linked_186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_185, arg_188) }; var k__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000033__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var root_189 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = lang.IFn_Cast(A_arbace_go_check_A_const_49).Invoke_O__O(k__9); if linked_190 == nil { tmp5 = ifn_191.Invoke_O__O(arg_192) } else { tmp5 = linked_190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(tmp5) {

							lang.IFn_Cast(self).Invoke_O__O(v__10)
//line :73:1
							var tmp6 any; var root_221 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = seq_1685000026__7; if linked_222 == nil { tmp6 = ifn_223.Invoke_O__O(arg_224) } else { tmp6 = linked_222.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_221, arg_224) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_225 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = seq_1685000026__7; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_225, arg_228) }; seq_1685000026__2, chunk_1685000027__3, count_1685000028__4, i_1685000029__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :71:1
								return nil } } else {
//line :70:1
									var tmp8 any; var root_193 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn





									if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = x__1; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }
//line :70:1
									if jrt.J2g_Truth(tmp8) { var seq_1685000036__2 any; var root_197 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn





										if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = x__1; if linked_198 == nil { seq_1685000036__2 = ifn_199.Invoke_O__O(arg_200) } else { seq_1685000036__2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }
//line :70:1
										var chunk_1685000037__3 any; var count_1685000038__4 int64 = 0; var i_1685000039__5 int64 = 0; L2: for {





											if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000039__5, count_1685000038__4) { var y__6 any = lang.Indexed_Cast(chunk_1685000037__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000039__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000039__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_201 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = seq_1685000036__2; if linked_202 == nil { temp__1927000414__auto____6_2 = ifn_203.Invoke_O__O(arg_204) } else { temp__1927000414__auto____6_2 = linked_202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000036__7 any = temp__1927000414__auto____6_2; var tmp9 any; var root_205 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = seq_1685000036__7; if linked_206 == nil { tmp9 = ifn_207.Invoke_O__O(arg_208) } else { tmp9 = linked_206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_205, arg_208) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8_2 any; var root_209 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = seq_1685000036__7; if linked_210 == nil { c__1927000678__auto____8_2 = ifn_211.Invoke_O__O(arg_212) } else { c__1927000678__auto____8_2 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_209, arg_212) }; var tmp10 any; var root_229 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = seq_1685000036__7; if linked_230 == nil { tmp10 = ifn_231.Invoke_O__O(arg_232) } else { tmp10 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_229, arg_232) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp10, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_213 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = seq_1685000036__7; if linked_214 == nil { y__8 = ifn_215.Invoke_O__O(arg_216) } else { y__8 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp11 any; var root_233 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = seq_1685000036__7; if linked_234 == nil { tmp11 = ifn_235.Invoke_O__O(arg_236) } else { tmp11 = linked_234.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_233, arg_236) }; seq_1685000036__2, chunk_1685000037__3, count_1685000038__4, i_1685000039__5 = tmp11, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :70:1
												if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :69:1
	panic("j2g: unreachable")
}










func A_arbace_go_check_verify_tags_BANG__A_New() *A_arbace_go_check_verify_tags_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_verify_tags_BANG__A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_verify_tags_BANG__A) Invoke_O_O__O(self, tree__0 any) any { { var seq_1685000042__2 any; var root_238 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn




	if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_go_check_A_const_51.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_nodes_seq_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = tree__0; if linked_243 == nil { arg_241 = ifn_244.Invoke_O__O(arg_245) } else { arg_241 = linked_243.(*A_arbace_go_check_nodes_seq_A).Invoke_O_O__O(root_242, arg_245) }; if linked_239 == nil { seq_1685000042__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1685000042__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :81:1
	var chunk_1685000043__3 any; var count_1685000044__4 int64 = 0; var i_1685000045__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000045__5, count_1685000044__4) { var n__6 any = lang.Indexed_Cast(chunk_1685000043__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000045__5))
			if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__6)) { var want__7 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__6); var tmp1 any
				var and__1927000168__auto____8 any = want__7

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__7, A_arbace_go_check_A_const_54.Invoke_O__O(n__6))).Ref() } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {
					var root_262 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_go_check_A_const_24; var arg_266 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } else {
						var tmp2 any; var and__1927000168__auto____8_2 any = want__7; if jrt.J2g_Truth(and__1927000168__auto____8_2) { var root_267 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_268 == nil { tmp2 = ifn_269.Invoke_O__O(arg_270) } else { tmp2 = linked_268.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_267, arg_270) } } else { tmp2 = and__1927000168__auto____8_2 }; if jrt.J2g_Truth(tmp2) {
							var root_271 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); var arg_275 any = Lit_140; var arg_276 any; var root_279 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__6); if linked_280 == nil { arg_276 = ifn_281.Invoke_O__O(arg_282) } else { arg_276 = linked_280.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_279, arg_282) }; var arg_277 any; var root_283 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_285 lang.IFn
							if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = want__7; if linked_284 == nil { arg_277 = ifn_285.Invoke_O__O(arg_286) } else { arg_277 = linked_284.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_283, arg_286) }
//line :93:1
							var arg_278 any; var root_287 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_289 lang.IFn
							if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_288 == nil { arg_278 = ifn_289.Invoke_O__O(arg_290) } else { arg_278 = linked_288.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_287, arg_290) }
//line :93:1
							if linked_272 == nil { ifn_273.Invoke_O_O_O_O_O__O(arg_274, arg_275, arg_276, arg_277, arg_278) } else { linked_272.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_271, arg_274, arg_275, arg_276, arg_277, arg_278) } } } } else {
//line :87:1
								var tmp3 any; var tmp4 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____7 any = tmp4.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







								if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp5 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____8_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_A_const_50.Invoke_O__O(n__6)); if and__1927000168__auto____8_3 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____10 any = tmp6.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__6)); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_291 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_293 lang.IFn
									if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_292 == nil { and__1927000168__auto____11 = ifn_293.Invoke_O__O(arg_294) } else { and__1927000168__auto____11 = linked_292.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :95:1
									if jrt.J2g_Truth(and__1927000168__auto____11) {
										var root_295 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_A_const_67; var arg_299 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_295, arg_298, arg_299) } } else {
//line :95:1
											tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = and__1927000168__auto____9 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8_3).Ref() } } else { tmp3 = and__1927000168__auto____7 }
//line :87:1
								if jrt.J2g_Truth(tmp3) {









									var root_300 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); var arg_304 any = Lit_140; var arg_305 any; var root_308 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__6); if linked_309 == nil { arg_305 = ifn_310.Invoke_O__O(arg_311) } else { arg_305 = linked_309.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_308, arg_311) }; var arg_306 any = Lit_141; var arg_307 any; var root_312 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__6); if linked_313 == nil { arg_307 = ifn_314.Invoke_O__O(arg_315) } else { arg_307 = linked_313.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_312, arg_315) }; if linked_301 == nil { ifn_302.Invoke_O_O_O_O_O__O(arg_303, arg_304, arg_305, arg_306, arg_307) } else { linked_301.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_300, arg_303, arg_304, arg_305, arg_306, arg_307) } } }
//line :86:1
			seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000045__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_246 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1685000042__2; if linked_247 == nil { temp__1927000414__auto____6 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____6 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000042__7 any = temp__1927000414__auto____6; var tmp7 any; var root_250 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1685000042__7; if linked_251 == nil { tmp7 = ifn_252.Invoke_O__O(arg_253) } else { tmp7 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_254 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1685000042__7; if linked_255 == nil { c__1927000678__auto____8 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____8 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp8 any; var root_316 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1685000042__7; if linked_317 == nil { tmp8 = ifn_318.Invoke_O__O(arg_319) } else { tmp8 = linked_317.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_316, arg_319) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_258 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1685000042__7; if linked_259 == nil { n__8 = ifn_260.Invoke_O__O(arg_261) } else { n__8 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				if jrt.J2g_Truth(A_arbace_go_check_A_const_52.Invoke_O__O(n__8)) { var want__9 any = A_arbace_go_check_A_const_53.Invoke_O__O(n__8); var tmp9 any
					var and__1927000168__auto____10_2 any = want__9

					if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(want__9, A_arbace_go_check_A_const_54.Invoke_O__O(n__8))).Ref() } else { tmp9 = and__1927000168__auto____10_2 }; if jrt.J2g_Truth(tmp9) {
						var root_320 any = A_arbace_go_check_A_const_55.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_check_A_const_24; var arg_324 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_321 == nil { ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { linked_321.(*aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else {
							var tmp10 any; var and__1927000168__auto____10_3 any = want__9; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_325 any = A_arbace_go_check_A_const_56.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_326 == nil { tmp10 = ifn_327.Invoke_O__O(arg_328) } else { tmp10 = linked_326.(*aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A).Invoke_O_O__O(root_325, arg_328) } } else { tmp10 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp10) {
								var root_329 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); var arg_333 any = Lit_140; var arg_334 any; var root_337 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_go_check_A_const_52.Invoke_O__O(n__8); if linked_338 == nil { arg_334 = ifn_339.Invoke_O__O(arg_340) } else { arg_334 = linked_338.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_337, arg_340) }; var arg_335 any; var root_341 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_343 lang.IFn
								if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = want__9; if linked_342 == nil { arg_335 = ifn_343.Invoke_O__O(arg_344) } else { arg_335 = linked_342.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_341, arg_344) }
//line :93:1
								var arg_336 any; var root_345 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_347 lang.IFn
								if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_346 == nil { arg_336 = ifn_347.Invoke_O__O(arg_348) } else { arg_336 = linked_346.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_345, arg_348) }
//line :93:1
								if linked_330 == nil { ifn_331.Invoke_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336) } else { linked_330.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336) } } } } else {
//line :87:1
									var tmp11 any; var tmp12 *lang.Keyword = A_arbace_go_check_A_const_60; var and__1927000168__auto____9_2 any = tmp12.Invoke_O__O(A_arbace_go_check_A_const_61.Get__O())







									if jrt.J2g_Truth(and__1927000168__auto____9_2) { var tmp13 any = A_arbace_go_check_A_const_62; var and__1927000168__auto____10_4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_A_const_50.Invoke_O__O(n__8)); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any = lang.IFn_Cast(A_arbace_go_check_A_const_63.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_A_const_69.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_64; var and__1927000168__auto____12 any = tmp14.Invoke_O__O(A_arbace_go_check_A_const_65.Invoke_O__O(n__8)); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_349 any = A_arbace_go_check_A_const_66.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A_fn_class); var ifn_351 lang.IFn
										if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_350 == nil { and__1927000168__auto____13 = ifn_351.Invoke_O__O(arg_352) } else { and__1927000168__auto____13 = linked_350.(*aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A).Invoke_O_O__O(root_349, arg_352) }
//line :95:1
										if jrt.J2g_Truth(and__1927000168__auto____13) {
											var root_353 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = A_arbace_go_check_A_const_67; var arg_357 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_354 == nil { tmp11 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp11 = linked_354.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } else {
//line :95:1
												tmp11 = and__1927000168__auto____13 } } else { tmp11 = and__1927000168__auto____12 } } else { tmp11 = and__1927000168__auto____11_2 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() } } else { tmp11 = and__1927000168__auto____9_2 }
//line :87:1
									if jrt.J2g_Truth(tmp11) {









										var root_358 any = A_arbace_go_check_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); var arg_362 any = Lit_140; var arg_363 any; var root_366 any = A_arbace_go_check_A_const_58.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_check_A_const_68.Invoke_O__O(n__8); if linked_367 == nil { arg_363 = ifn_368.Invoke_O__O(arg_369) } else { arg_363 = linked_367.(*aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A).Invoke_O_O__O(root_366, arg_369) }; var arg_364 any = Lit_141; var arg_365 any; var root_370 any = A_arbace_go_check_A_const_59.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = A_arbace_go_check_A_const_54.Invoke_O__O(n__8); if linked_371 == nil { arg_365 = ifn_372.Invoke_O__O(arg_373) } else { arg_365 = linked_371.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_370, arg_373) }; if linked_359 == nil { ifn_360.Invoke_O_O_O_O_O__O(arg_361, arg_362, arg_363, arg_364, arg_365) } else { linked_359.(*aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A).Invoke_O_O_O_O_O_O__O(root_358, arg_361, arg_362, arg_363, arg_364, arg_365) } } }
//line :86:1
				var tmp15 any; var root_374 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1685000042__7; if linked_375 == nil { tmp15 = ifn_376.Invoke_O__O(arg_377) } else { tmp15 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1685000042__2, chunk_1685000043__3, count_1685000044__4, i_1685000045__5 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :81:1*/panic("j2g: unreachable") }



















func A_arbace_go_check_file_info_A_New() *A_arbace_go_check_file_info_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_file_info_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_file_info_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_file_info_A) Invoke_O_O_O_O__O(self, pkg_scope__0, fi__1, config__2 any) any { var tmp1 any = A_arbace_go_check_A_const_70; var tmp2 any = A_arbace_go_check_A_const_70.Invoke_O__O(fi__1); var tmp3 any = A_arbace_go_check_A_const_71; var tmp4 any; var root_378 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_380 lang.IFn; if
													linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = pkg_scope__0; var arg_382 any = A_arbace_go_check_A_const_73; if linked_379 == nil { tmp4 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp4 = linked_379.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_74; var tmp7 any; var root_383 any = /*line :101:1*/A_arbace_go_check_A_const_75.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A_fn_class); var ifn_385 lang.IFn; if


	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var or__1927000174__auto____4 any; var root_387 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = fi__1; var arg_391 any = A_arbace_go_check_A_const_77; if linked_388 == nil { or__1927000174__auto____4 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { or__1927000174__auto____4 = linked_388.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_386 = or__1927000174__auto____4 } else { arg_386 = A_arbace_go_check_A_const_74.Invoke_O__O(config__2) }; if linked_384 == nil { tmp7 = ifn_385.Invoke_O__O(arg_386) } else { tmp7 = jrt.Long_ValueOf_J__Long_NoInit(linked_384.(*aot_arbace_go_check_code.A_arbace_go_check_code_lang_minor_A).InvokePrim_O_O__J(root_383, arg_386)).Ref() }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_78; var tmp10 any; var root_392 any = /*line :101:1*/A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_394 lang.IFn; if



	linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = A_arbace_go_check_A_const_73.Invoke_O__O(fi__1); if linked_393 == nil { tmp10 = ifn_394.Invoke_O__O(arg_395) } else { tmp10 = linked_393.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_392, arg_395) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_80; var tmp13 /*line :101:1*/*lang.Keyword = A_arbace_go_check_A_const_80; var tmp14 any = tmp13.Invoke_O__O(A_arbace_go_check_A_const_81.Invoke_O__O(fi__1)); var tmp15 any = A_arbace_go_check_A_const_82; var tmp16 any = A_arbace_go_check_A_const_82.Invoke_O__O(fi__1); var tmp17 any = A_arbace_go_check_A_const_83; var tmp18 any = jrt.HashMap_New(); var tmp19 any = A_arbace_go_check_A_const_84; var tmp20 any; var root_396 any = A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_398 lang.IFn; if





	linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.PersistentVector_EMPTY.Ref(); if linked_397 == nil { tmp20 = ifn_398.Invoke_O__O(arg_399) } else { tmp20 = linked_397.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_396, arg_399) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_85; var tmp23 any; var root_400 any = /*line :101:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_402 lang.IFn; if





	linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.PersistentVector_EMPTY.Ref(); if linked_401 == nil { tmp23 = ifn_402.Invoke_O__O(arg_403) } else { tmp23 = linked_401.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_400, arg_403) }; return /*line :101:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }







func A_arbace_go_check_mark_qualifiers_used_BANG__A_New() *A_arbace_go_check_mark_qualifiers_used_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__A) Invoke_O_O_O__O(self, fi__0, form__1 any) any { var body_walk__3 *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(fi__0); var walk__3 any; var tmp1 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class = fncls__502d; tmp1 = fncls__502d } else { tmp1 = fncls__502 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil);













	lang.IFn_Cast(walk__3).Invoke_O__O(form__1); var tmp2 any; var root_503 any =

	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_507 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_A_const_84.Invoke_O__O(fi__0); if linked_508 == nil { arg_506 = ifn_509.Invoke_O__O(arg_510) } else { arg_506 = linked_508.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_507, arg_510) }; if linked_504 == nil { tmp2 = ifn_505.Invoke_O__O(arg_506) } else { tmp2 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; if jrt.J2g_Truth(tmp2) { var body_walk2__4 *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(fi__0); var walk2__4 any; var tmp3 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class = fncls__561d; tmp3 = fncls__561d } else { tmp3 = fncls__561 }; walk2__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk2__4), tmp3, nil)





		return lang.IFn_Cast(walk2__4).Invoke_O__O(form__1) } else {
//line :125:1
			return nil } }
//line :112:1
func A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :112:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_404 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_406 lang.IFn
	if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = f__1; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_404, arg_407) }
//line :113:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_408 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = f__1; if linked_409 == nil { temp__1927000414__auto____2 = ifn_410.Invoke_O__O(arg_411) } else { temp__1927000414__auto____2 = linked_409.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_408, arg_411) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var q__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_470 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_472 lang.IFn
			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_go_check_A_const_71.Invoke_O__O(t.F_fi); var arg_474 any = q__3; if linked_471 == nil { temp__1927000414__auto____4 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { temp__1927000414__auto____4 = linked_471.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var x__5 any = temp__1927000414__auto____4; var tmp2 any = A_arbace_go_check_A_const_91; var tmp3 any; var root_475 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_477 lang.IFn
				if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__5; var arg_479 any = A_arbace_go_check_A_const_93; if linked_476 == nil { tmp3 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp3 = linked_476.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_480 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = x__5; var arg_484 any = A_arbace_go_check_A_const_89; var arg_485 any = jrt.Boolean_TRUE.Ref(); if linked_481 == nil { ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { linked_481.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } } }
//line :114:1
			var temp__1927000414__auto____4_2 any; var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp5 any; var root_412 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_414 lang.IFn


			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; if linked_413 == nil { tmp5 = ifn_414.Invoke_O__O(arg_415) } else { tmp5 = linked_413.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_412, arg_415) }; temp__1927000414__auto____4_2 = tmp4.Get_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var vec__1685000049__5 any = temp__1927000414__auto____4_2; var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000049__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_416 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_418 lang.IFn; _ = ___6; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = imp__7; var arg_420 any = A_arbace_go_check_A_const_89; var arg_421 any = jrt.Boolean_TRUE.Ref(); if linked_417 == nil { ifn_418.Invoke_O_O_O__O(arg_419, arg_420, arg_421) } else { linked_417.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_416, arg_419, arg_420, arg_421) } } } } else {
//line :113:1
				var tmp6 any; var root_422 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_424 lang.IFn




				if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = f__1; if linked_423 == nil { tmp6 = ifn_424.Invoke_O__O(arg_425) } else { tmp6 = linked_423.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_422, arg_425) }
//line :113:1
				if jrt.J2g_Truth(tmp6) { var seq_1685000052__2 any; var root_426 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn




					if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = f__1; if linked_427 == nil { seq_1685000052__2 = ifn_428.Invoke_O__O(arg_429) } else { seq_1685000052__2 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }
//line :113:1
					var chunk_1685000053__3 any; var count_1685000054__4 int64 = 0; var i_1685000055__5 int64 = 0; L1: for {




						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000055__5, count_1685000054__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000053__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000055__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000055__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_430 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1685000052__2; if linked_431 == nil { temp__1927000414__auto____6 = ifn_432.Invoke_O__O(arg_433) } else { temp__1927000414__auto____6 = linked_431.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000052__7 any = temp__1927000414__auto____6; var tmp7 any; var root_434 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1685000052__7; if linked_435 == nil { tmp7 = ifn_436.Invoke_O__O(arg_437) } else { tmp7 = linked_435.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____8 any; var root_438 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = seq_1685000052__7; if linked_439 == nil { c__1927000678__auto____8 = ifn_440.Invoke_O__O(arg_441) } else { c__1927000678__auto____8 = linked_439.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_438, arg_441) }; var tmp8 any; var root_486 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1685000052__7; if linked_487 == nil { tmp8 = ifn_488.Invoke_O__O(arg_489) } else { tmp8 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp8, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_442 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1685000052__7; if linked_443 == nil { x__8 = ifn_444.Invoke_O__O(arg_445) } else { x__8 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp9 any; var root_490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = seq_1685000052__7; if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_490, arg_493) }; seq_1685000052__2, chunk_1685000053__3, count_1685000054__4, i_1685000055__5 = tmp9, nil, 0, 0; continue L1 } } }
//line :113:1
						break L1 } } else { var tmp10 any; var root_446 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_448 lang.IFn





							if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; if linked_447 == nil { tmp10 = ifn_448.Invoke_O__O(arg_449) } else { tmp10 = linked_447.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_446, arg_449) }
//line :113:1
							if jrt.J2g_Truth(tmp10) { var seq_1685000056__2 any; var root_450 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn





								if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = f__1; if linked_451 == nil { seq_1685000056__2 = ifn_452.Invoke_O__O(arg_453) } else { seq_1685000056__2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }
//line :113:1
								var chunk_1685000057__3 any; var count_1685000058__4 int64 = 0; var i_1685000059__5 int64 = 0; L2: for {





									if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000059__5, count_1685000058__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000057__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000059__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000059__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_454 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1685000056__2; if linked_455 == nil { temp__1927000414__auto____6_2 = ifn_456.Invoke_O__O(arg_457) } else { temp__1927000414__auto____6_2 = linked_455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000056__7 any = temp__1927000414__auto____6_2; var tmp11 any; var root_458 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1685000056__7; if linked_459 == nil { tmp11 = ifn_460.Invoke_O__O(arg_461) } else { tmp11 = linked_459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____8_2 any; var root_462 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1685000056__7; if linked_463 == nil { c__1927000678__auto____8_2 = ifn_464.Invoke_O__O(arg_465) } else { c__1927000678__auto____8_2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_462, arg_465) }; var tmp12 any; var root_494 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1685000056__7; if linked_495 == nil { tmp12 = ifn_496.Invoke_O__O(arg_497) } else { tmp12 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp12, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_466 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1685000056__7; if linked_467 == nil { x__8_2 = ifn_468.Invoke_O__O(arg_469) } else { x__8_2 = linked_467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_466, arg_469) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp13 any; var root_498 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1685000056__7; if linked_499 == nil { tmp13 = ifn_500.Invoke_O__O(arg_501) } else { tmp13 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1685000056__2, chunk_1685000057__3, count_1685000058__4, i_1685000059__5 = tmp13, nil, 0, 0; continue L2 } } }
//line :113:1
									break L2 } } else { if A_arbace_go_check_A_const_28 != nil {
									}
									}
						}
			}



	if lang.IMeta_InstanceOf(f__1) { var tmp14 *lang.Keyword = A_arbace_go_check_A_const_24; var temp__1927000414__auto____2_2 any = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__1))
		if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var tg__3 any = temp__1927000414__auto____2_2; return lang.IFn_Cast(self).Invoke_O__O(tg__3) } else { return nil } } else {
//line :121:1
			return nil
		}
}


func A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_New_O(p0 any) *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :126:1
func (t *A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var root_511 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_513 lang.IFn
		if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = f__1; if linked_512 == nil { tmp1 = ifn_513.Invoke_O__O(arg_514) } else { tmp1 = linked_512.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_511, arg_514) }
//line :127:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(A_arbace_go_check_A_const_83.Invoke_O__O(t.F_fi)); var tmp3 any; var root_515 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_517 lang.IFn
			if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = f__1; if linked_516 == nil { tmp3 = ifn_517.Invoke_O__O(arg_518) } else { tmp3 = linked_516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_515, arg_518) }; temp__1927000414__auto____2 = tmp2.Get_O__O(tmp3); if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1685000062__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var imp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_521 lang.IFn; _ = ___4; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = imp__5; var arg_523 any = A_arbace_go_check_A_const_89; var arg_524 any = jrt.Boolean_TRUE.Ref(); if linked_520 == nil { return ifn_521.Invoke_O_O_O__O(arg_522, arg_523, arg_524) } else { return linked_520.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_519, arg_522, arg_523, arg_524) } } else { return nil } } else {
//line :127:1
				var tmp4 any; var or__1927000174__auto____2 any; var root_525 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_527 lang.IFn

				if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = f__1; if linked_526 == nil { or__1927000174__auto____2 = ifn_527.Invoke_O__O(arg_528) } else { or__1927000174__auto____2 = linked_526.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var root_529 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = f__1; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_529, arg_532) } }
//line :127:1
				if jrt.J2g_Truth(tmp4) { var seq_1685000065__2 any; var root_533 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__1; if linked_534 == nil { seq_1685000065__2 = ifn_535.Invoke_O__O(arg_536) } else { seq_1685000065__2 = linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) }
//line :127:1
					var chunk_1685000066__3 any; var count_1685000067__4 int64 = 0; var i_1685000068__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000068__5, count_1685000067__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000066__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000068__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000068__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_537 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1685000065__2; if linked_538 == nil { temp__1927000414__auto____6 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000414__auto____6 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000065__7 any = temp__1927000414__auto____6; var tmp5 any; var root_541 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1685000065__7; if linked_542 == nil { tmp5 = ifn_543.Invoke_O__O(arg_544) } else { tmp5 = linked_542.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_541, arg_544) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____8 any; var root_545 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = seq_1685000065__7; if linked_546 == nil { c__1927000678__auto____8 = ifn_547.Invoke_O__O(arg_548) } else { c__1927000678__auto____8 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_545, arg_548) }; var tmp6 any; var root_553 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = seq_1685000065__7; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp6, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_549 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = seq_1685000065__7; if linked_550 == nil { x__8 = ifn_551.Invoke_O__O(arg_552) } else { x__8 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp7 any; var root_557 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1685000065__7; if linked_558 == nil { tmp7 = ifn_559.Invoke_O__O(arg_560) } else { tmp7 = linked_558.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_557, arg_560) }; seq_1685000065__2, chunk_1685000066__3, count_1685000067__4, i_1685000068__5 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable")
}





func A_arbace_go_check_syntactic_deps_BANG__A_New() *A_arbace_go_check_syntactic_deps_BANG__A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_syntactic_deps_BANG__A) Invoke_O_O_O__O(self, d__0, pkg_scope__1 any) any { var body_walk__3 *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(d__0, pkg_scope__1); var walk__3 any; var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var tmp2 lang.IFn =















	lang.IFn_Cast(walk__3); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_98); var tmp5 *lang.Keyword = A_arbace_go_check_A_const_93; var tmp6 any; var root_682 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = d__0; if linked_683 == nil { tmp6 = ifn_684.Invoke_O__O(arg_685) } else { tmp6 = linked_683.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) { var tmp7 *lang.Keyword = A_arbace_go_check_A_const_99; var tmp8 any; var root_674 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { tmp8 = ifn_676.Invoke_O__O(arg_677) } else { tmp8 = linked_675.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_674, arg_677) }; tmp3 = tmp7.Invoke_O__O(tmp8) } else { var tmp9 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp10 any; var root_678 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = d__0; if linked_679 == nil { tmp10 = ifn_680.Invoke_O__O(arg_681) } else { tmp10 = linked_679.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_678, arg_681) }; tmp3 = tmp9.Invoke_O__O(tmp10) }; return tmp2.Invoke_O__O(tmp3) }
//line :136:1
func A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_New_O_O(p0, p1 any) *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Ctor_O_O(c__d, c__pkg_scope any) { t.F_d = c__d; t.F_pkg_scope = c__pkg_scope }
//line :136:1
func (t *A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A) Invoke_O_O__O(self, f__1 any) any {
	{ var tmp1 any; var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_564 lang.IFn
		if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = f__1; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_566 any = A_arbace_go_check_A_const_86.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = f__1; if linked_567 == nil { tmp2 = ifn_568.Invoke_O__O(arg_569) } else { tmp2 = linked_567.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_566, arg_569) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2, nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :137:1
		if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_check_A_const_90.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A_fn_class); var ifn_572 lang.IFn

			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = t.F_pkg_scope; var arg_574 any; var root_575 any = A_arbace_go_check_A_const_87.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = f__1; if linked_576 == nil { arg_574 = ifn_577.Invoke_O__O(arg_578) } else { arg_574 = linked_576.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_575, arg_578) }; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var x__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_94); var tmp4 any; var root_634 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_636 lang.IFn
				if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__3; var arg_638 any = A_arbace_go_check_A_const_93; if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { tmp4 = linked_635.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) {
					var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp6 any; var root_579 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(lang.Volatile_Cast(t.F_d)).Deref__O(); var arg_583 any = A_arbace_go_check_A_const_95; var arg_584 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_585 any = x__3; if linked_580 == nil { tmp6 = ifn_581.Invoke_O_O_O_O__O(arg_582, arg_583, arg_584, arg_585) } else { tmp6 = linked_580.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_579, arg_582, arg_583, arg_584, arg_585) }; return jrt.NN(tmp5).Reset_O__O(tmp6) } else {
//line :140:1
						return nil } } else {
//line :139:1
							return nil } } else {
//line :137:1
								var tmp7 any; var root_586 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_588 lang.IFn




								if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = f__1; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_586, arg_589) }
//line :137:1
								if jrt.J2g_Truth(tmp7) { var temp__1927000414__auto____2_2 any; var root_639 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_641 lang.IFn




									if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = f__1; if linked_640 == nil { temp__1927000414__auto____2_2 = ifn_641.Invoke_O__O(arg_642) } else { temp__1927000414__auto____2_2 = linked_640.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_639, arg_642) }; if jrt.J2g_Truth(temp__1927000414__auto____2_2) { var h__3 any = temp__1927000414__auto____2_2; var tmp8 any; var and__1927000168__auto____4 any; var root_643 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_645 lang.IFn
										if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = h__3; var arg_647 any = Lit_121; if linked_644 == nil { and__1927000168__auto____4 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { and__1927000168__auto____4 = linked_644.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_648 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_go_check_A_const_97.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = h__3; var arg_656 any = Lit_139; if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { and__1927000168__auto____5 = ifn_650.Invoke_O__O(arg_651) } else { and__1927000168__auto____5 = linked_649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(h__3)), 1)).Ref() } else { tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp8) { } }
//line :137:1
									var seq_1685000072__2 any; var root_590 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_592 lang.IFn








									if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = f__1; if linked_591 == nil { seq_1685000072__2 = ifn_592.Invoke_O__O(arg_593) } else { seq_1685000072__2 = linked_591.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_590, arg_593) }
//line :137:1
									var chunk_1685000073__3 any; var count_1685000074__4 int64 = 0; var i_1685000075__5 int64 = 0; L1: for {








										if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000075__5, count_1685000074__4) { var x__6 any = lang.Indexed_Cast(chunk_1685000073__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000075__5)); lang.IFn_Cast(self).Invoke_O__O(x__6); seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000075__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = seq_1685000072__2; if linked_595 == nil { temp__1927000414__auto____6 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____6 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1685000072__7 any = temp__1927000414__auto____6; var tmp9 any; var root_598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_1685000072__7; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____8 any; var root_602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_1685000072__7; if linked_603 == nil { c__1927000678__auto____8 = ifn_604.Invoke_O__O(arg_605) } else { c__1927000678__auto____8 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_602, arg_605) }; var tmp10 any; var root_657 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq_1685000072__7; if linked_658 == nil { tmp10 = ifn_659.Invoke_O__O(arg_660) } else { tmp10 = linked_658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_657, arg_660) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp10, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__8 any; var root_606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1685000072__7; if linked_607 == nil { x__8 = ifn_608.Invoke_O__O(arg_609) } else { x__8 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; lang.IFn_Cast(self).Invoke_O__O(x__8); var tmp11 any; var root_661 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq_1685000072__7; if linked_662 == nil { tmp11 = ifn_663.Invoke_O__O(arg_664) } else { tmp11 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; seq_1685000072__2, chunk_1685000073__3, count_1685000074__4, i_1685000075__5 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :137:1
											var tmp12 any; var root_610 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_612 lang.IFn









											if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = f__1; if linked_611 == nil { tmp12 = ifn_612.Invoke_O__O(arg_613) } else { tmp12 = linked_611.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_610, arg_613) }
//line :137:1
											if jrt.J2g_Truth(tmp12) { var seq_1685000076__2 any; var root_614 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn









												if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = f__1; if linked_615 == nil { seq_1685000076__2 = ifn_616.Invoke_O__O(arg_617) } else { seq_1685000076__2 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }
//line :137:1
												var chunk_1685000077__3 any; var count_1685000078__4 int64 = 0; var i_1685000079__5 int64 = 0; L2: for {









													if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000079__5, count_1685000078__4) { var x__6_2 any = lang.Indexed_Cast(chunk_1685000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000079__5)); lang.IFn_Cast(self).Invoke_O__O(x__6_2); seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000079__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var root_618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_1685000076__2; if linked_619 == nil { temp__1927000414__auto____6_2 = ifn_620.Invoke_O__O(arg_621) } else { temp__1927000414__auto____6_2 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1685000076__7 any = temp__1927000414__auto____6_2; var tmp13 any; var root_622 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = seq_1685000076__7; if linked_623 == nil { tmp13 = ifn_624.Invoke_O__O(arg_625) } else { tmp13 = linked_623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____8_2 any; var root_626 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = seq_1685000076__7; if linked_627 == nil { c__1927000678__auto____8_2 = ifn_628.Invoke_O__O(arg_629) } else { c__1927000678__auto____8_2 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any; var root_665 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1685000076__7; if linked_666 == nil { tmp14 = ifn_667.Invoke_O__O(arg_668) } else { tmp14 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp14, c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var x__8_2 any; var root_630 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1685000076__7; if linked_631 == nil { x__8_2 = ifn_632.Invoke_O__O(arg_633) } else { x__8_2 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; lang.IFn_Cast(self).Invoke_O__O(x__8_2); var tmp15 any; var root_669 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = seq_1685000076__7; if linked_670 == nil { tmp15 = ifn_671.Invoke_O__O(arg_672) } else { tmp15 = linked_670.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_669, arg_672) }; seq_1685000076__2, chunk_1685000077__3, count_1685000078__4, i_1685000079__5 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :137:1
														if A_arbace_go_check_A_const_28 != nil { return nil } else { return nil } } } } }
//line :136:1
	panic("j2g: unreachable")
}













func A_arbace_go_check_check_package_A_New() *A_arbace_go_check_check_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_check_package_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_check_package_A) DoInvoke_O_O_O_O__O(self, src__0, resolve__1, p__1685000096__2 any) any { var map__1685000097__4 any = p__1685000096__2; var map__1685000097__5 any; if lang.ISeq_InstanceOf(map__1685000097__4) { var tmp1 any; var root_686 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = map__1685000097__4; if linked_687 == nil { tmp1 = ifn_688.Invoke_O__O(arg_689) } else { tmp1 = linked_687.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_690 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = map__1685000097__4; if linked_691 == nil { tmp2 = ifn_692.Invoke_O__O(arg_693) } else { tmp2 = linked_691.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_690, arg_693) }; map__1685000097__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_694 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = map__1685000097__4; if linked_695 == nil { tmp3 = ifn_696.Invoke_O__O(arg_697) } else { tmp3 = linked_695.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp3) { var root_698 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = map__1685000097__4; if linked_699 == nil { map__1685000097__5 = ifn_700.Invoke_O__O(arg_701) } else { map__1685000097__5 = linked_699.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_698, arg_701) } } else { map__1685000097__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000097__5 = map__1685000097__4 }; var keep_trees__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000097__5, A_arbace_go_check_A_const_102); var pkg_scope__7 any; var root_702 any = A_arbace_go_check_A_const_72.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_go_check_env.A_arbace_go_check_env_scope_A_fn_class); var ifn_704 lang.IFn; if




	linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var arg_706 any = A_arbace_go_check_A_const_103; if linked_703 == nil { pkg_scope__7 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { pkg_scope__7 = linked_703.(*aot_arbace_go_check_env.A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; var pkg__8 any; var root_707 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_709 lang.IFn; if





	linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var tmp4 any = A_arbace_go_check_A_const_104; var tmp5 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp6 any = A_arbace_go_check_A_const_70; var tmp7 any = A_arbace_go_check_A_const_70.Invoke_O__O(src__0); var tmp8 any = A_arbace_go_check_A_const_71; var tmp9 any = A_arbace_go_check_A_const_105; var arg_710 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, pkg_scope__7, tmp9, A_arbace_go_check_A_const_105.Invoke_O__O(src__0))); if linked_708 == nil { pkg__8 = ifn_709.Invoke_O__O(arg_710) } else { pkg__8 = linked_708.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_707, arg_710) }; var errors__9 any; var root_711 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_713 lang.IFn; if






	linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = lang.PersistentVector_EMPTY.Ref(); if linked_712 == nil { errors__9 = ifn_713.Invoke_O__O(arg_714) } else { errors__9 = linked_712.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_711, arg_714) }; var annotated__10 any; var root_715 any = /*line :151:1*/A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_717 lang.IFn; if







	linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = A_arbace_go_check_A_const_81.Invoke_O__O(src__0); var arg_719 any = A_arbace_go_check_A_const_106; if linked_716 == nil { annotated__10 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { annotated__10 = linked_716.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_715, arg_718, arg_719) }; var ctx__11 any; var tmp10 any = A_arbace_go_check_A_const_107; var tmp11 any; var root_720 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_722 lang.IFn; if








	linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = lang.PersistentVector_EMPTY.Ref(); if linked_721 == nil { tmp11 = ifn_722.Invoke_O__O(arg_723) } else { tmp11 = linked_721.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_720, arg_723) }; var tmp12 any = tmp11; var tmp13 any = A_arbace_go_check_A_const_108; var tmp14 any; var root_724 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_726 lang.IFn; if








	linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_725 == nil { tmp14 = ifn_726.Invoke_O__O(arg_727) } else { tmp14 = linked_725.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_724, arg_727) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_109; var tmp17 any; var root_728 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_730 lang.IFn; if








	linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = lang.PersistentVector_EMPTY.Ref(); if linked_729 == nil { tmp17 = ifn_730.Invoke_O__O(arg_731) } else { tmp17 = linked_729.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_728, arg_731) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_go_check_A_const_110; var tmp20 any; var root_732 any = /*line :151:1*/A_arbace_go_check_A_const_18.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_734 lang.IFn; if








	linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = lang.PersistentVector_EMPTY.Ref(); if linked_733 == nil { tmp20 = ifn_734.Invoke_O__O(arg_735) } else { tmp20 = linked_733.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_732, arg_735) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_go_check_A_const_111; ctx__11 = /*line :151:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, tmp16, tmp18, tmp19, tmp21, tmp22, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)))); var fis__12 any; var root_736 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_738 lang.IFn; if










	linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var tmp23 any = A_arbace_go_check_check_package_fn__1685000099_A_New_O_O(src__0, pkg_scope__7); var tmp24 *jrt.Class; var fncls__747 *jrt.Class = A_arbace_go_check_check_package_fn__1685000099_A_fn_class; if fncls__747 == nil { var fncls__747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_check_package_fn__1685000099_A_fn_class = fncls__747d; tmp24 = fncls__747d } else { tmp24 = fncls__747 }; arg_739 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_740 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_737 == nil { fis__12 = ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { fis__12 = linked_737.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) }; var root_1180 any =
	A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var tmp25 any = A_arbace_go_check_A_const_157; var tmp26 any = A_arbace_go_check_A_const_158; var tmp27 any = A_arbace_go_check_A_const_159; var tmp28 any = jrt.IdentityHashMap_New(); var tmp29 any = A_arbace_go_check_A_const_160; var tmp30 any = A_arbace_go_check_A_const_61; var tmp31 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_60, annotated__10)); var tmp32 any = A_arbace_go_check_A_const_161; var tmp33 any = A_arbace_go_check_A_const_162.GetRawRoot__O(); var tmp34 any = A_arbace_go_check_A_const_163; var tmp35 any = A_arbace_go_check_A_const_164.GetRawRoot__O(); var tmp36 any = A_arbace_go_check_A_const_165; var tmp37 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp38 any = A_arbace_go_check_A_const_166; var tmp39 any = A_arbace_go_check_A_const_167.GetRawRoot__O(); var tmp40 any = A_arbace_go_check_A_const_168; var tmp41 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var tmp42 any = A_arbace_go_check_A_const_170; var tmp43 any = A_arbace_go_check_A_const_171.GetRawRoot__O(); var tmp44 any = A_arbace_go_check_A_const_172; var arg_1183 any = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp25, pkg__8, tmp26, errors__9, tmp27, tmp28, tmp29, ctx__11, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, A_arbace_go_check_A_const_173.GetRawRoot__O())))); if linked_1181 == nil { ifn_1182.Invoke_O__O(arg_1183) } else { linked_1181.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1180, arg_1183) }; var tmp45 any; tmp232 := /*line :151:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000101__15 any; var root_1184 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1186 lang.IFn























		if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = fis__12; if linked_1185 == nil { seq_1685000101__15 = ifn_1186.Invoke_O__O(arg_1187) } else { seq_1685000101__15 = linked_1185.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1184, arg_1187) }
//line :151:1
		var chunk_1685000102__16 any; var count_1685000103__17 int64 = 0; var i_1685000104__18 int64 = 0; L1: for {























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000104__18, count_1685000103__17) { var fi__19 any = lang.Indexed_Cast(chunk_1685000102__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000104__18)); var root_1227 any = A_arbace_go_check_A_const_175.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = fi__19; var arg_1231 any = resolve__1; if linked_1228 == nil { ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { linked_1228.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }; seq_1685000101__15, chunk_1685000102__16, count_1685000103__17, i_1685000104__18 = seq_1685000101__15, chunk_1685000102__16, count_1685000103__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000104__18); continue L1 } else { var temp__1927000414__auto____19 any; var root_1188 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = seq_1685000101__15; if linked_1189 == nil { temp__1927000414__auto____19 = ifn_1190.Invoke_O__O(arg_1191) } else { temp__1927000414__auto____19 = linked_1189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1188, arg_1191) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_1685000101__20 any = temp__1927000414__auto____19; var tmp46 any; var root_1192 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = seq_1685000101__20; if linked_1193 == nil { tmp46 = ifn_1194.Invoke_O__O(arg_1195) } else { tmp46 = linked_1193.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1192, arg_1195) }; if jrt.J2g_Truth(tmp46) { var c__1927000678__auto____21 any; var root_1196 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq_1685000101__20; if linked_1197 == nil { c__1927000678__auto____21 = ifn_1198.Invoke_O__O(arg_1199) } else { c__1927000678__auto____21 = linked_1197.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1196, arg_1199) }; var tmp47 any; var root_1232 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = seq_1685000101__20; if linked_1233 == nil { tmp47 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp47 = linked_1233.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1232, arg_1235) }; seq_1685000101__15, chunk_1685000102__16, count_1685000103__17, i_1685000104__18 = tmp47, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__21 any; var root_1200 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = seq_1685000101__20; if linked_1201 == nil { fi__21 = ifn_1202.Invoke_O__O(arg_1203) } else { fi__21 = linked_1201.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1200, arg_1203) }; var root_1236 any = A_arbace_go_check_A_const_175.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = fi__21; var arg_1240 any = resolve__1; if linked_1237 == nil { ifn_1238.Invoke_O_O__O(arg_1239, arg_1240) } else { linked_1237.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_declare_imports_BANG__A).Invoke_O_O_O__O(root_1236, arg_1239, arg_1240) }; var tmp48 any; var root_1241 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = seq_1685000101__20; if linked_1242 == nil { tmp48 = ifn_1243.Invoke_O__O(arg_1244) } else { tmp48 = linked_1242.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1241, arg_1244) }; seq_1685000101__15, chunk_1685000102__16, count_1685000103__17, i_1685000104__18 = tmp48, nil, 0, 0; continue L1 } } }
//line :151:1
			break L1 }; var seq_1685000105__15 any; var root_1204 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1206 lang.IFn
























		if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = fis__12; if linked_1205 == nil { seq_1685000105__15 = ifn_1206.Invoke_O__O(arg_1207) } else { seq_1685000105__15 = linked_1205.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1204, arg_1207) }
//line :151:1
		var chunk_1685000106__16 any; var count_1685000107__17 int64 = 0; var i_1685000108__18 int64 = 0; L2: for {
























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000108__18, count_1685000107__17) { var fi__19_2 any = lang.Indexed_Cast(chunk_1685000106__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000108__18)); var root_1245 any = A_arbace_go_check_A_const_176.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = fi__19_2; if linked_1246 == nil { ifn_1247.Invoke_O__O(arg_1248) } else { linked_1246.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1245, arg_1248) }; seq_1685000105__15, chunk_1685000106__16, count_1685000107__17, i_1685000108__18 = seq_1685000105__15, chunk_1685000106__16, count_1685000107__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000108__18); continue L2 } else { var temp__1927000414__auto____19_2 any; var root_1208 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = seq_1685000105__15; if linked_1209 == nil { temp__1927000414__auto____19_2 = ifn_1210.Invoke_O__O(arg_1211) } else { temp__1927000414__auto____19_2 = linked_1209.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1208, arg_1211) }; if jrt.J2g_Truth(temp__1927000414__auto____19_2) { var seq_1685000105__20 any = temp__1927000414__auto____19_2; var tmp49 any; var root_1212 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = seq_1685000105__20; if linked_1213 == nil { tmp49 = ifn_1214.Invoke_O__O(arg_1215) } else { tmp49 = linked_1213.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1212, arg_1215) }; if jrt.J2g_Truth(tmp49) { var c__1927000678__auto____21_2 any; var root_1216 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = seq_1685000105__20; if linked_1217 == nil { c__1927000678__auto____21_2 = ifn_1218.Invoke_O__O(arg_1219) } else { c__1927000678__auto____21_2 = linked_1217.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1216, arg_1219) }; var tmp50 any; var root_1249 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = seq_1685000105__20; if linked_1250 == nil { tmp50 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp50 = linked_1250.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1249, arg_1252) }; seq_1685000105__15, chunk_1685000106__16, count_1685000107__17, i_1685000108__18 = tmp50, c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var fi__21_2 any; var root_1220 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = seq_1685000105__20; if linked_1221 == nil { fi__21_2 = ifn_1222.Invoke_O__O(arg_1223) } else { fi__21_2 = linked_1221.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1220, arg_1223) }; var root_1253 any = A_arbace_go_check_A_const_176.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = fi__21_2; if linked_1254 == nil { ifn_1255.Invoke_O__O(arg_1256) } else { linked_1254.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_collect_file_BANG__A).Invoke_O_O__O(root_1253, arg_1256) }; var tmp51 any; var root_1257 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = seq_1685000105__20; if linked_1258 == nil { tmp51 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp51 = linked_1258.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1257, arg_1260) }; seq_1685000105__15, chunk_1685000106__16, count_1685000107__17, i_1685000108__18 = tmp51, nil, 0, 0; continue L2 } } }
//line :151:1
			break L2
		}
























		var root_1224 any = A_arbace_go_check_A_const_174.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; if linked_1225 == nil { ifn_1226.Invoke__O() } else { linked_1225.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_resolve_method_bases_BANG__A).Invoke_O__O(root_1224) }
//line :151:1
		var objs__15 any; var root_748 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_750 lang.IFn


























		if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = A_arbace_go_check_A_const_107.Invoke_O__O(ctx__11); if linked_749 == nil { objs__15 = ifn_750.Invoke_O__O(arg_751) } else { objs__15 = linked_749.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_748, arg_751) }
//line :151:1
		var seq_1685000109__16 any; var root_1261 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1263 lang.IFn



























		if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var root_1265 any = A_arbace_go_check_A_const_177.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = A_arbace_go_check_A_const_178.GetRawRoot__O(); var arg_1269 any = objs__15; if linked_1266 == nil { arg_1264 = ifn_1267.Invoke_O_O__O(arg_1268, arg_1269) } else { arg_1264 = linked_1266.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1265, arg_1268, arg_1269) }; if linked_1262 == nil { seq_1685000109__16 = ifn_1263.Invoke_O__O(arg_1264) } else { seq_1685000109__16 = linked_1262.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1261, arg_1264) }
//line :151:1
		var chunk_1685000110__17 any; var count_1685000111__18 int64 = 0; var i_1685000112__19 int64 = 0; L3: for {



























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000112__19, count_1685000111__18) { var vec__1685000113__20 any = lang.Indexed_Cast(chunk_1685000110__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000112__19)); var i__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000113__20, lang.RT_IntCast_J__I_NoInit(0), nil); var x__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000113__20, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1438 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = x__22; var arg_1442 any = A_arbace_go_check_A_const_180; var arg_1443 any = i__21; if linked_1439 == nil { ifn_1440.Invoke_O_O_O__O(arg_1441, arg_1442, arg_1443) } else { linked_1439.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1438, arg_1441, arg_1442, arg_1443) }; seq_1685000109__16, chunk_1685000110__17, count_1685000111__18, i_1685000112__19 = seq_1685000109__16, chunk_1685000110__17, count_1685000111__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000112__19); continue L3 } else { var temp__1927000414__auto____20 any; var root_1270 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = seq_1685000109__16; if linked_1271 == nil { temp__1927000414__auto____20 = ifn_1272.Invoke_O__O(arg_1273) } else { temp__1927000414__auto____20 = linked_1271.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1270, arg_1273) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000109__21 any = temp__1927000414__auto____20; var tmp52 any; var root_1274 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = seq_1685000109__21; if linked_1275 == nil { tmp52 = ifn_1276.Invoke_O__O(arg_1277) } else { tmp52 = linked_1275.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1274, arg_1277) }; if jrt.J2g_Truth(tmp52) { var c__1927000678__auto____22 any; var root_1278 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = seq_1685000109__21; if linked_1279 == nil { c__1927000678__auto____22 = ifn_1280.Invoke_O__O(arg_1281) } else { c__1927000678__auto____22 = linked_1279.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1278, arg_1281) }; var tmp53 any; var root_1444 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = seq_1685000109__21; if linked_1445 == nil { tmp53 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp53 = linked_1445.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1444, arg_1447) }; seq_1685000109__16, chunk_1685000110__17, count_1685000111__18, i_1685000112__19 = tmp53, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1685000116__22 any; var root_1282 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = seq_1685000109__21; if linked_1283 == nil { vec__1685000116__22 = ifn_1284.Invoke_O__O(arg_1285) } else { vec__1685000116__22 = linked_1283.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1282, arg_1285) }; var i__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000116__22, lang.RT_IntCast_J__I_NoInit(0), nil); var x__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000116__22, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1448 any = A_arbace_go_check_A_const_88.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = x__24; var arg_1452 any = A_arbace_go_check_A_const_180; var arg_1453 any = i__23; if linked_1449 == nil { ifn_1450.Invoke_O_O_O__O(arg_1451, arg_1452, arg_1453) } else { linked_1449.(*aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A).Invoke_O_O_O_O__O(root_1448, arg_1451, arg_1452, arg_1453) }; var tmp54 any; var root_1454 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = seq_1685000109__21; if linked_1455 == nil { tmp54 = ifn_1456.Invoke_O__O(arg_1457) } else { tmp54 = linked_1455.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1454, arg_1457) }; seq_1685000109__16, chunk_1685000110__17, count_1685000111__18, i_1685000112__19 = tmp54, nil, 0, 0; continue L3 } } }
//line :151:1
			break L3 }; var seq_1685000119__16 any; var root_1286 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1288 lang.IFn





























		if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = objs__15; if linked_1287 == nil { seq_1685000119__16 = ifn_1288.Invoke_O__O(arg_1289) } else { seq_1685000119__16 = linked_1287.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1286, arg_1289) }
//line :151:1
		var chunk_1685000120__17 any; var count_1685000121__18 int64 = 0; var i_1685000122__19 int64 = 0; L4: for {





























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000122__19, count_1685000121__18) { var x__20 any = lang.Indexed_Cast(chunk_1685000120__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000122__19)); var tmp55 any; var and__1927000168__auto____21 bool; var tmp56 any = A_arbace_go_check_A_const_54; var tmp57 any; var root_1290 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = x__20; var arg_1294 any = A_arbace_go_check_A_const_93; if linked_1291 == nil { tmp57 = ifn_1292.Invoke_O_O__O(arg_1293, arg_1294) } else { tmp57 = linked_1291.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1290, arg_1293, arg_1294) }; and__1927000168__auto____21 = lang.Util_Equiv_O_O__Z_NoInit(tmp56, tmp57); if and__1927000168__auto____21 { var root_1295 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var root_1299 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = x__20; var arg_1303 any = A_arbace_go_check_A_const_179; if linked_1300 == nil { arg_1298 = ifn_1301.Invoke_O_O__O(arg_1302, arg_1303) } else { arg_1298 = linked_1300.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1299, arg_1302, arg_1303) }; if linked_1296 == nil { tmp55 = ifn_1297.Invoke_O__O(arg_1298) } else { tmp55 = linked_1296.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1295, arg_1298) } } else { tmp55 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }; if jrt.J2g_Truth(tmp55) { var root_1458 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = x__20; if linked_1459 == nil { ifn_1460.Invoke_O__O(arg_1461) } else { linked_1459.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1458, arg_1461) }; seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, i_1685000122__19 = seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000122__19); continue L4 } else { seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, i_1685000122__19 = seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000122__19); continue L4 } } else { var temp__1927000414__auto____20_2 any; var root_1304 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = seq_1685000119__16; if linked_1305 == nil { temp__1927000414__auto____20_2 = ifn_1306.Invoke_O__O(arg_1307) } else { temp__1927000414__auto____20_2 = linked_1305.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1304, arg_1307) }; if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var seq_1685000119__21 any = temp__1927000414__auto____20_2; var tmp58 any; var root_1308 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = seq_1685000119__21; if linked_1309 == nil { tmp58 = ifn_1310.Invoke_O__O(arg_1311) } else { tmp58 = linked_1309.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1308, arg_1311) }; if jrt.J2g_Truth(tmp58) { var c__1927000678__auto____22_2 any; var root_1312 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = seq_1685000119__21; if linked_1313 == nil { c__1927000678__auto____22_2 = ifn_1314.Invoke_O__O(arg_1315) } else { c__1927000678__auto____22_2 = linked_1313.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1312, arg_1315) }; var tmp59 any; var root_1462 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = seq_1685000119__21; if linked_1463 == nil { tmp59 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp59 = linked_1463.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1462, arg_1465) }; seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, i_1685000122__19 = tmp59, c__1927000678__auto____22_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__22_2 any; var root_1316 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = seq_1685000119__21; if linked_1317 == nil { x__22_2 = ifn_1318.Invoke_O__O(arg_1319) } else { x__22_2 = linked_1317.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1316, arg_1319) }; var tmp60 any; var and__1927000168__auto____23 bool; var tmp61 any = A_arbace_go_check_A_const_54; var tmp62 any; var root_1320 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = x__22_2; var arg_1324 any = A_arbace_go_check_A_const_93; if linked_1321 == nil { tmp62 = ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { tmp62 = linked_1321.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) }; and__1927000168__auto____23 = lang.Util_Equiv_O_O__Z_NoInit(tmp61, tmp62); if and__1927000168__auto____23 { var root_1325 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any; var root_1329 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = x__22_2; var arg_1333 any = A_arbace_go_check_A_const_179; if linked_1330 == nil { arg_1328 = ifn_1331.Invoke_O_O__O(arg_1332, arg_1333) } else { arg_1328 = linked_1330.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1329, arg_1332, arg_1333) }; if linked_1326 == nil { tmp60 = ifn_1327.Invoke_O__O(arg_1328) } else { tmp60 = linked_1326.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1325, arg_1328) } } else { tmp60 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }; if jrt.J2g_Truth(tmp60) { var root_1466 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = x__22_2; if linked_1467 == nil { ifn_1468.Invoke_O__O(arg_1469) } else { linked_1467.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1466, arg_1469) }; var tmp63 any; var root_1470 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = seq_1685000119__21; if linked_1471 == nil { tmp63 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp63 = linked_1471.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1470, arg_1473) }; seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, i_1685000122__19 = tmp63, nil, 0, 0; continue L4 } else { var tmp64 any; var root_1474 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = seq_1685000119__21; if linked_1475 == nil { tmp64 = ifn_1476.Invoke_O__O(arg_1477) } else { tmp64 = linked_1475.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1474, arg_1477) }; seq_1685000119__16, chunk_1685000120__17, count_1685000121__18, i_1685000122__19 = tmp64, nil, 0, 0; continue L4 } } } }
//line :151:1
			break L4 }; var seq_1685000123__16 any; var root_1334 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1336 lang.IFn






























		if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = objs__15; if linked_1335 == nil { seq_1685000123__16 = ifn_1336.Invoke_O__O(arg_1337) } else { seq_1685000123__16 = linked_1335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1334, arg_1337) }
//line :151:1
		var chunk_1685000124__17 any; var count_1685000125__18 int64 = 0; var i_1685000126__19 int64 = 0; L5: for {






























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000126__19, count_1685000125__18) { var x__20_2 any = lang.Indexed_Cast(chunk_1685000124__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000126__19)); var tmp65 any; var and__1927000168__auto____21_2 bool; var tmp66 any = A_arbace_go_check_A_const_54; var tmp67 any; var root_1338 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = x__20_2; var arg_1342 any = A_arbace_go_check_A_const_93; if linked_1339 == nil { tmp67 = ifn_1340.Invoke_O_O__O(arg_1341, arg_1342) } else { tmp67 = linked_1339.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1338, arg_1341, arg_1342) }; and__1927000168__auto____21_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp66, tmp67); if and__1927000168__auto____21_2 { var root_1343 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = x__20_2; var arg_1347 any = A_arbace_go_check_A_const_179; if linked_1344 == nil { tmp65 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { tmp65 = linked_1344.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) } } else { tmp65 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }; if jrt.J2g_Truth(tmp65) { var root_1478 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = x__20_2; if linked_1479 == nil { ifn_1480.Invoke_O__O(arg_1481) } else { linked_1479.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1478, arg_1481) }; seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, i_1685000126__19 = seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000126__19); continue L5 } else { seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, i_1685000126__19 = seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000126__19); continue L5 } } else { var temp__1927000414__auto____20_3 any; var root_1348 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = seq_1685000123__16; if linked_1349 == nil { temp__1927000414__auto____20_3 = ifn_1350.Invoke_O__O(arg_1351) } else { temp__1927000414__auto____20_3 = linked_1349.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1348, arg_1351) }; if jrt.J2g_Truth(temp__1927000414__auto____20_3) { var seq_1685000123__21 any = temp__1927000414__auto____20_3; var tmp68 any; var root_1352 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = seq_1685000123__21; if linked_1353 == nil { tmp68 = ifn_1354.Invoke_O__O(arg_1355) } else { tmp68 = linked_1353.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1352, arg_1355) }; if jrt.J2g_Truth(tmp68) { var c__1927000678__auto____22_3 any; var root_1356 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = seq_1685000123__21; if linked_1357 == nil { c__1927000678__auto____22_3 = ifn_1358.Invoke_O__O(arg_1359) } else { c__1927000678__auto____22_3 = linked_1357.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1356, arg_1359) }; var tmp69 any; var root_1482 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = seq_1685000123__21; if linked_1483 == nil { tmp69 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp69 = linked_1483.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1482, arg_1485) }; seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, i_1685000126__19 = tmp69, c__1927000678__auto____22_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var x__22_3 any; var root_1360 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = seq_1685000123__21; if linked_1361 == nil { x__22_3 = ifn_1362.Invoke_O__O(arg_1363) } else { x__22_3 = linked_1361.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1360, arg_1363) }; var tmp70 any; var and__1927000168__auto____23_2 bool; var tmp71 any = A_arbace_go_check_A_const_54; var tmp72 any; var root_1364 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = x__22_3; var arg_1368 any = A_arbace_go_check_A_const_93; if linked_1365 == nil { tmp72 = ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { tmp72 = linked_1365.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) }; and__1927000168__auto____23_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp71, tmp72); if and__1927000168__auto____23_2 { var root_1369 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = x__22_3; var arg_1373 any = A_arbace_go_check_A_const_179; if linked_1370 == nil { tmp70 = ifn_1371.Invoke_O_O__O(arg_1372, arg_1373) } else { tmp70 = linked_1370.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1369, arg_1372, arg_1373) } } else { tmp70 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23_2).Ref() }; if jrt.J2g_Truth(tmp70) { var root_1486 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = x__22_3; if linked_1487 == nil { ifn_1488.Invoke_O__O(arg_1489) } else { linked_1487.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1486, arg_1489) }; var tmp73 any; var root_1490 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = seq_1685000123__21; if linked_1491 == nil { tmp73 = ifn_1492.Invoke_O__O(arg_1493) } else { tmp73 = linked_1491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1490, arg_1493) }; seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, i_1685000126__19 = tmp73, nil, 0, 0; continue L5 } else { var tmp74 any; var root_1494 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = seq_1685000123__21; if linked_1495 == nil { tmp74 = ifn_1496.Invoke_O__O(arg_1497) } else { tmp74 = linked_1495.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1494, arg_1497) }; seq_1685000123__16, chunk_1685000124__17, count_1685000125__18, i_1685000126__19 = tmp74, nil, 0, 0; continue L5 } } } }
//line :151:1
			break L5 }; var seq_1685000127__16 any; var root_1374 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1376 lang.IFn































		if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = objs__15; if linked_1375 == nil { seq_1685000127__16 = ifn_1376.Invoke_O__O(arg_1377) } else { seq_1685000127__16 = linked_1375.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1374, arg_1377) }
//line :151:1
		var chunk_1685000128__17 any; var count_1685000129__18 int64 = 0; var i_1685000130__19 int64 = 0; L6: for {































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000130__19, count_1685000129__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1685000128__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000130__19)); var tmp75 any; var root_1378 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = A_arbace_go_check_A_const_54; var arg_1382 any; var root_1383 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = x__20_3; var arg_1387 any = A_arbace_go_check_A_const_93; if linked_1384 == nil { arg_1382 = ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { arg_1382 = linked_1384.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }; if linked_1379 == nil { tmp75 = ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { tmp75 = linked_1379.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) }; if jrt.J2g_Truth(tmp75) { var root_1498 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = x__20_3; if linked_1499 == nil { ifn_1500.Invoke_O__O(arg_1501) } else { linked_1499.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1498, arg_1501) }; seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, i_1685000130__19 = seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000130__19); continue L6 } else { seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, i_1685000130__19 = seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000130__19); continue L6 } } else { var temp__1927000414__auto____20_4 any; var root_1388 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = seq_1685000127__16; if linked_1389 == nil { temp__1927000414__auto____20_4 = ifn_1390.Invoke_O__O(arg_1391) } else { temp__1927000414__auto____20_4 = linked_1389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1388, arg_1391) }; if jrt.J2g_Truth(temp__1927000414__auto____20_4) { var seq_1685000127__21 any = temp__1927000414__auto____20_4; var tmp76 any; var root_1392 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = seq_1685000127__21; if linked_1393 == nil { tmp76 = ifn_1394.Invoke_O__O(arg_1395) } else { tmp76 = linked_1393.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1392, arg_1395) }; if jrt.J2g_Truth(tmp76) { var c__1927000678__auto____22_4 any; var root_1396 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = seq_1685000127__21; if linked_1397 == nil { c__1927000678__auto____22_4 = ifn_1398.Invoke_O__O(arg_1399) } else { c__1927000678__auto____22_4 = linked_1397.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1396, arg_1399) }; var tmp77 any; var root_1502 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = seq_1685000127__21; if linked_1503 == nil { tmp77 = ifn_1504.Invoke_O__O(arg_1505) } else { tmp77 = linked_1503.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1502, arg_1505) }; seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, i_1685000130__19 = tmp77, c__1927000678__auto____22_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__22_4 any; var root_1400 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = seq_1685000127__21; if linked_1401 == nil { x__22_4 = ifn_1402.Invoke_O__O(arg_1403) } else { x__22_4 = linked_1401.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1400, arg_1403) }; var tmp78 any; var root_1404 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = A_arbace_go_check_A_const_54; var arg_1408 any; var root_1409 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = x__22_4; var arg_1413 any = A_arbace_go_check_A_const_93; if linked_1410 == nil { arg_1408 = ifn_1411.Invoke_O_O__O(arg_1412, arg_1413) } else { arg_1408 = linked_1410.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1409, arg_1412, arg_1413) }; if linked_1405 == nil { tmp78 = ifn_1406.Invoke_O_O__O(arg_1407, arg_1408) } else { tmp78 = linked_1405.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1404, arg_1407, arg_1408) }; if jrt.J2g_Truth(tmp78) { var root_1506 any = A_arbace_go_check_A_const_169.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = x__22_4; if linked_1507 == nil { ifn_1508.Invoke_O__O(arg_1509) } else { linked_1507.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_obj_decl_BANG__A).Invoke_O_O__O(root_1506, arg_1509) }; var tmp79 any; var root_1510 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = seq_1685000127__21; if linked_1511 == nil { tmp79 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp79 = linked_1511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1510, arg_1513) }; seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, i_1685000130__19 = tmp79, nil, 0, 0; continue L6 } else { var tmp80 any; var root_1514 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = seq_1685000127__21; if linked_1515 == nil { tmp80 = ifn_1516.Invoke_O__O(arg_1517) } else { tmp80 = linked_1515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1514, arg_1517) }; seq_1685000127__16, chunk_1685000128__17, count_1685000129__18, i_1685000130__19 = tmp80, nil, 0, 0; continue L6 } } } }
//line :151:1
			break L6 }; var seq_1685000131__16 any; var root_1414 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1416 lang.IFn

































		if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any; var root_1418 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = A_arbace_go_check_A_const_109.Invoke_O__O(ctx__11); if linked_1419 == nil { arg_1417 = ifn_1420.Invoke_O__O(arg_1421) } else { arg_1417 = linked_1419.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1418, arg_1421) }; if linked_1415 == nil { seq_1685000131__16 = ifn_1416.Invoke_O__O(arg_1417) } else { seq_1685000131__16 = linked_1415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1414, arg_1417) }
//line :151:1
		var chunk_1685000132__17 any; var count_1685000133__18 int64 = 0; var i_1685000134__19 int64 = 0; L7: for {

































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000134__19, count_1685000133__18) { var x__20_4 any = lang.Indexed_Cast(chunk_1685000132__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000134__19)); var root_1518 any = A_arbace_go_check_A_const_181.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = x__20_4; if linked_1519 == nil { ifn_1520.Invoke_O__O(arg_1521) } else { linked_1519.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1518, arg_1521) }; seq_1685000131__16, chunk_1685000132__17, count_1685000133__18, i_1685000134__19 = seq_1685000131__16, chunk_1685000132__17, count_1685000133__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000134__19); continue L7 } else { var temp__1927000414__auto____20_5 any; var root_1422 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = seq_1685000131__16; if linked_1423 == nil { temp__1927000414__auto____20_5 = ifn_1424.Invoke_O__O(arg_1425) } else { temp__1927000414__auto____20_5 = linked_1423.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1422, arg_1425) }; if jrt.J2g_Truth(temp__1927000414__auto____20_5) { var seq_1685000131__21 any = temp__1927000414__auto____20_5; var tmp81 any; var root_1426 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = seq_1685000131__21; if linked_1427 == nil { tmp81 = ifn_1428.Invoke_O__O(arg_1429) } else { tmp81 = linked_1427.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1426, arg_1429) }; if jrt.J2g_Truth(tmp81) { var c__1927000678__auto____22_5 any; var root_1430 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = seq_1685000131__21; if linked_1431 == nil { c__1927000678__auto____22_5 = ifn_1432.Invoke_O__O(arg_1433) } else { c__1927000678__auto____22_5 = linked_1431.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1430, arg_1433) }; var tmp82 any; var root_1522 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = seq_1685000131__21; if linked_1523 == nil { tmp82 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp82 = linked_1523.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1522, arg_1525) }; seq_1685000131__16, chunk_1685000132__17, count_1685000133__18, i_1685000134__19 = tmp82, c__1927000678__auto____22_5, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22_5))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22_5 any; var root_1434 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = seq_1685000131__21; if linked_1435 == nil { x__22_5 = ifn_1436.Invoke_O__O(arg_1437) } else { x__22_5 = linked_1435.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1434, arg_1437) }; var root_1526 any = A_arbace_go_check_A_const_181.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = x__22_5; if linked_1527 == nil { ifn_1528.Invoke_O__O(arg_1529) } else { linked_1527.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_check_body_BANG__A).Invoke_O_O__O(root_1526, arg_1529) }; var tmp83 any; var root_1530 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = seq_1685000131__21; if linked_1531 == nil { tmp83 = ifn_1532.Invoke_O__O(arg_1533) } else { tmp83 = linked_1531.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1530, arg_1533) }; seq_1685000131__16, chunk_1685000132__17, count_1685000133__18, i_1685000134__19 = tmp83, nil, 0, 0; continue L7 } } }
//line :151:1
			break L7 }; var decls__16 any; var root_752 any = A_arbace_go_check_A_const_115.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_754 lang.IFn


































		if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp84 any = A_arbace_go_check_check_package_fn__1685000135_A_New(); var tmp85 *jrt.Class; var fncls__766 *jrt.Class = A_arbace_go_check_check_package_fn__1685000135_A_fn_class; if fncls__766 == nil { var fncls__766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_check_package_fn__1685000135_A_fn_class = fncls__766d; tmp85 = fncls__766d } else { tmp85 = fncls__766 }; arg_759 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil); var arg_760 any = objs__15; if linked_757 == nil { arg_755 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { arg_755 = linked_757.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if linked_753 == nil { decls__16 = ifn_754.Invoke_O__O(arg_755) } else { decls__16 = linked_753.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_752, arg_755) }
//line :151:1
		var seq_1685000137__17 any; var root_1534 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1536 lang.IFn



































		if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = decls__16; if linked_1535 == nil { seq_1685000137__17 = ifn_1536.Invoke_O__O(arg_1537) } else { seq_1685000137__17 = linked_1535.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1534, arg_1537) }
//line :151:1
		var chunk_1685000138__18 any; var count_1685000139__19 int64 = 0; var i_1685000140__20 int64 = 0; L8: for {



































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000140__20, count_1685000139__19) { var d__21 any = lang.Indexed_Cast(chunk_1685000138__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000140__20)); L9: for { var ls__22 any; var tmp86 *lang.Keyword = A_arbace_go_check_A_const_183; var tmp87 any; var root_1638 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1640 lang.IFn

				if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = d__21; if linked_1639 == nil { tmp87 = ifn_1640.Invoke_O__O(arg_1641) } else { tmp87 = linked_1639.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1638, arg_1641) }; ls__22 = tmp86.Invoke_O__O(tmp87)
				var tmp88 any; var root_1642 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = ls__22; if linked_1643 == nil { tmp88 = ifn_1644.Invoke_O__O(arg_1645) } else { tmp88 = linked_1643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1642, arg_1645) }; if jrt.J2g_Truth(tmp88) {
					var tmp89 *lang.Volatile = lang.Volatile_Cast(d__21); var tmp90 any; var root_1646 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = jrt.NN(lang.Volatile_Cast(d__21)).Deref__O(); var arg_1650 any = A_arbace_go_check_A_const_183; var arg_1651 any = lang.PersistentVector_EMPTY.Ref(); if linked_1647 == nil { tmp90 = ifn_1648.Invoke_O_O_O__O(arg_1649, arg_1650, arg_1651) } else { tmp90 = linked_1647.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1646, arg_1649, arg_1650, arg_1651) }; jrt.NN(tmp89).Reset_O__O(tmp90)
					var root_1698 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1700 lang.IFn; if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any; var tmp91 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()); var tmp92 any = A_arbace_go_check_A_const_188; var tmp93 any = A_arbace_go_check_A_const_189; var tmp94 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp95 any; var root_1711 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = d__21; if linked_1712 == nil { tmp95 = ifn_1713.Invoke_O__O(arg_1714) } else { tmp95 = linked_1712.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1711, arg_1714) }; var tmp96 any = tmp94.Invoke_O__O(tmp95); var tmp97 any = A_arbace_go_check_A_const_190; var tmp98 any; var G__1685000141__23_ any; var tmp99 *lang.Keyword = A_arbace_go_check_A_const_191; var tmp100 any; var root_1715 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = d__21; if linked_1716 == nil { tmp100 = ifn_1717.Invoke_O__O(arg_1718) } else { tmp100 = linked_1716.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1715, arg_1718) }; G__1685000141__23_ = tmp99.Invoke_O__O(tmp100); if lang.Util_Identical_O_O__Z_NoInit(G__1685000141__23_, nil) { tmp98 = nil } else { var root_1719 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = G__1685000141__23_; var arg_1723 any = A_arbace_go_check_A_const_78; if linked_1720 == nil { tmp98 = ifn_1721.Invoke_O_O__O(arg_1722, arg_1723) } else { tmp98 = linked_1720.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1719, arg_1722, arg_1723) } }; arg_1701 = tmp91.Invoke_O_O_O_O_O_O__O(tmp92, d__21, tmp93, tmp96, tmp97, tmp98); if linked_1699 == nil { ifn_1700.Invoke_O__O(arg_1701) } else { linked_1699.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1698, arg_1701) }; var tmp101 any = A_arbace_go_check_check_package_fn__1685000142_A_New_O_O(d__21, ls__22); var tmp102 *jrt.Class; var fncls__1697 *jrt.Class = A_arbace_go_check_check_package_fn__1685000142_A_fn_class; if fncls__1697 == nil { var fncls__1697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_check_package_fn__1685000142_A_fn_class = fncls__1697d; tmp102 = fncls__1697d } else { tmp102 = fncls__1697 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp101, tmp102, nil).Invoke__O()


					continue L9 }
//line :187:1
				break L9 }; seq_1685000137__17, chunk_1685000138__18, count_1685000139__19, i_1685000140__20 = seq_1685000137__17, chunk_1685000138__18, count_1685000139__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000140__20); continue L8 } else { var temp__1927000414__auto____21 any; var root_1538 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = seq_1685000137__17; if linked_1539 == nil { temp__1927000414__auto____21 = ifn_1540.Invoke_O__O(arg_1541) } else { temp__1927000414__auto____21 = linked_1539.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1538, arg_1541) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_1685000137__22 any = temp__1927000414__auto____21; var tmp103 any; var root_1542 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = seq_1685000137__22; if linked_1543 == nil { tmp103 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp103 = linked_1543.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1542, arg_1545) }; if jrt.J2g_Truth(tmp103) { var c__1927000678__auto____23 any; var root_1546 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = seq_1685000137__22; if linked_1547 == nil { c__1927000678__auto____23 = ifn_1548.Invoke_O__O(arg_1549) } else { c__1927000678__auto____23 = linked_1547.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1546, arg_1549) }; var tmp104 any; var root_1724 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = seq_1685000137__22; if linked_1725 == nil { tmp104 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp104 = linked_1725.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1724, arg_1727) }; seq_1685000137__17, chunk_1685000138__18, count_1685000139__19, i_1685000140__20 = tmp104, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L8 } else { var d__23 any; var root_1550 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = seq_1685000137__22; if linked_1551 == nil { d__23 = ifn_1552.Invoke_O__O(arg_1553) } else { d__23 = linked_1551.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1550, arg_1553) }; L10: for { var ls__24 any; var tmp105 *lang.Keyword = A_arbace_go_check_A_const_183; var tmp106 any; var root_1728 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1730 lang.IFn

					if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = d__23; if linked_1729 == nil { tmp106 = ifn_1730.Invoke_O__O(arg_1731) } else { tmp106 = linked_1729.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1728, arg_1731) }; ls__24 = tmp105.Invoke_O__O(tmp106)
					var tmp107 any; var root_1732 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = ls__24; if linked_1733 == nil { tmp107 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp107 = linked_1733.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1732, arg_1735) }; if jrt.J2g_Truth(tmp107) {
						var tmp108 *lang.Volatile = lang.Volatile_Cast(d__23); var tmp109 any; var root_1736 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = jrt.NN(lang.Volatile_Cast(d__23)).Deref__O(); var arg_1740 any = A_arbace_go_check_A_const_183; var arg_1741 any = lang.PersistentVector_EMPTY.Ref(); if linked_1737 == nil { tmp109 = ifn_1738.Invoke_O_O_O__O(arg_1739, arg_1740, arg_1741) } else { tmp109 = linked_1737.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1736, arg_1739, arg_1740, arg_1741) }; jrt.NN(tmp108).Reset_O__O(tmp109)
						var root_1788 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any; var tmp110 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()); var tmp111 any = A_arbace_go_check_A_const_188; var tmp112 any = A_arbace_go_check_A_const_189; var tmp113 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp114 any; var root_1801 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = d__23; if linked_1802 == nil { tmp114 = ifn_1803.Invoke_O__O(arg_1804) } else { tmp114 = linked_1802.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1801, arg_1804) }; var tmp115 any = tmp113.Invoke_O__O(tmp114); var tmp116 any = A_arbace_go_check_A_const_190; var tmp117 any; var G__1685000148__25_ any; var tmp118 *lang.Keyword = A_arbace_go_check_A_const_191; var tmp119 any; var root_1805 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = d__23; if linked_1806 == nil { tmp119 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp119 = linked_1806.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1805, arg_1808) }; G__1685000148__25_ = tmp118.Invoke_O__O(tmp119); if lang.Util_Identical_O_O__Z_NoInit(G__1685000148__25_, nil) { tmp117 = nil } else { var root_1809 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = G__1685000148__25_; var arg_1813 any = A_arbace_go_check_A_const_78; if linked_1810 == nil { tmp117 = ifn_1811.Invoke_O_O__O(arg_1812, arg_1813) } else { tmp117 = linked_1810.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1809, arg_1812, arg_1813) } }; arg_1791 = tmp110.Invoke_O_O_O_O_O_O__O(tmp111, d__23, tmp112, tmp115, tmp116, tmp117); if linked_1789 == nil { ifn_1790.Invoke_O__O(arg_1791) } else { linked_1789.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1788, arg_1791) }; var tmp120 any = A_arbace_go_check_check_package_fn__1685000149_A_New_O_O(d__23, ls__24); var tmp121 *jrt.Class; var fncls__1787 *jrt.Class = A_arbace_go_check_check_package_fn__1685000149_A_fn_class; if fncls__1787 == nil { var fncls__1787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_check_package_fn__1685000149_A_fn_class = fncls__1787d; tmp121 = fncls__1787d } else { tmp121 = fncls__1787 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp120, tmp121, nil).Invoke__O()


						continue L10 }
//line :187:1
					break L10 }; var tmp122 any; var root_1814 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = seq_1685000137__22; if linked_1815 == nil { tmp122 = ifn_1816.Invoke_O__O(arg_1817) } else { tmp122 = linked_1815.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1814, arg_1817) }; seq_1685000137__17, chunk_1685000138__18, count_1685000139__19, i_1685000140__20 = tmp122, nil, 0, 0; continue L8 } } }
//line :151:1
			break L8 }; var seq_1685000155__17 any; var root_1554 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1556 lang.IFn













































		if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = decls__16; if linked_1555 == nil { seq_1685000155__17 = ifn_1556.Invoke_O__O(arg_1557) } else { seq_1685000155__17 = linked_1555.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1554, arg_1557) }
//line :151:1
		var chunk_1685000156__18 any; var count_1685000157__19 int64 = 0; var i_1685000158__20 int64 = 0; L11: for {













































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000158__20, count_1685000157__19) { var d__21_2 any = lang.Indexed_Cast(chunk_1685000156__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000158__20)); var tmp123 *lang.Keyword = A_arbace_go_check_A_const_182; var tmp124 any; var root_1558 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = d__21_2; if linked_1559 == nil { tmp124 = ifn_1560.Invoke_O__O(arg_1561) } else { tmp124 = linked_1559.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1558, arg_1561) }; if jrt.J2g_Truth(tmp123.Invoke_O__O(tmp124)) {
				var root_1830 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any; var tmp125 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()); var tmp126 any = A_arbace_go_check_A_const_188; var tmp127 any = A_arbace_go_check_A_const_189; var tmp128 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp129 any; var root_1841 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = d__21_2; if linked_1842 == nil { tmp129 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp129 = linked_1842.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1841, arg_1844) }; arg_1833 = tmp125.Invoke_O_O_O_O__O(tmp126, d__21_2, tmp127, tmp128.Invoke_O__O(tmp129)); if linked_1831 == nil { ifn_1832.Invoke_O__O(arg_1833) } else { linked_1831.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1830, arg_1833) }; var tmp130 any = A_arbace_go_check_check_package_fn__1685000159_A_New_O(d__21_2); var tmp131 *jrt.Class; var fncls__1829 *jrt.Class = A_arbace_go_check_check_package_fn__1685000159_A_fn_class; if fncls__1829 == nil { var fncls__1829d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_check_package_fn__1685000159_A_fn_class = fncls__1829d; tmp131 = fncls__1829d } else { tmp131 = fncls__1829 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp130, tmp131, nil).Invoke__O()
//line :197:1
				seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000158__20); continue L11 } else { seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000158__20); continue L11 } } else { var temp__1927000414__auto____21_2 any; var root_1562 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = seq_1685000155__17; if linked_1563 == nil { temp__1927000414__auto____21_2 = ifn_1564.Invoke_O__O(arg_1565) } else { temp__1927000414__auto____21_2 = linked_1563.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1562, arg_1565) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_1685000155__22 any = temp__1927000414__auto____21_2; var tmp132 any; var root_1566 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = seq_1685000155__22; if linked_1567 == nil { tmp132 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp132 = linked_1567.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1566, arg_1569) }; if jrt.J2g_Truth(tmp132) { var c__1927000678__auto____23_2 any; var root_1570 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = seq_1685000155__22; if linked_1571 == nil { c__1927000678__auto____23_2 = ifn_1572.Invoke_O__O(arg_1573) } else { c__1927000678__auto____23_2 = linked_1571.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1570, arg_1573) }; var tmp133 any; var root_1845 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = seq_1685000155__22; if linked_1846 == nil { tmp133 = ifn_1847.Invoke_O__O(arg_1848) } else { tmp133 = linked_1846.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1845, arg_1848) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = tmp133, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L11 } else { var d__23_2 any; var root_1574 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = seq_1685000155__22; if linked_1575 == nil { d__23_2 = ifn_1576.Invoke_O__O(arg_1577) } else { d__23_2 = linked_1575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1574, arg_1577) }; var tmp134 *lang.Keyword = A_arbace_go_check_A_const_182; var tmp135 any; var root_1578 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = d__23_2; if linked_1579 == nil { tmp135 = ifn_1580.Invoke_O__O(arg_1581) } else { tmp135 = linked_1579.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1578, arg_1581) }; if jrt.J2g_Truth(tmp134.Invoke_O__O(tmp135)) {
					var root_1861 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any; var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()); var tmp137 any = A_arbace_go_check_A_const_188; var tmp138 any = A_arbace_go_check_A_const_189; var tmp139 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp140 any; var root_1872 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = d__23_2; if linked_1873 == nil { tmp140 = ifn_1874.Invoke_O__O(arg_1875) } else { tmp140 = linked_1873.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1872, arg_1875) }; arg_1864 = tmp136.Invoke_O_O_O_O__O(tmp137, d__23_2, tmp138, tmp139.Invoke_O__O(tmp140)); if linked_1862 == nil { ifn_1863.Invoke_O__O(arg_1864) } else { linked_1862.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1861, arg_1864) }; var tmp141 any = A_arbace_go_check_check_package_fn__1685000161_A_New_O(d__23_2); var tmp142 *jrt.Class; var fncls__1860 *jrt.Class = A_arbace_go_check_check_package_fn__1685000161_A_fn_class; if fncls__1860 == nil { var fncls__1860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_check_package_fn__1685000161_A_fn_class = fncls__1860d; tmp142 = fncls__1860d } else { tmp142 = fncls__1860 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp141, tmp142, nil).Invoke__O()
//line :197:1
					var tmp143 any; var root_1876 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = seq_1685000155__22; if linked_1877 == nil { tmp143 = ifn_1878.Invoke_O__O(arg_1879) } else { tmp143 = linked_1877.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1876, arg_1879) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = tmp143, nil, 0, 0; continue L11 } else { var tmp144 any; var root_1880 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = seq_1685000155__22; if linked_1881 == nil { tmp144 = ifn_1882.Invoke_O__O(arg_1883) } else { tmp144 = linked_1881.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1880, arg_1883) }; seq_1685000155__17, chunk_1685000156__18, count_1685000157__19, i_1685000158__20 = tmp144, nil, 0, 0; continue L11 } } } }
//line :151:1
			break L11 }; var seq_1685000163__17 any; var root_1582 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1584 lang.IFn

















































		if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = decls__16; if linked_1583 == nil { seq_1685000163__17 = ifn_1584.Invoke_O__O(arg_1585) } else { seq_1685000163__17 = linked_1583.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1582, arg_1585) }
//line :151:1
		var chunk_1685000164__18 any; var count_1685000165__19 int64 = 0; var i_1685000166__20 int64 = 0; L12: for {

















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000166__20, count_1685000165__19) { var d__21_3 any = lang.Indexed_Cast(chunk_1685000164__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000166__20)); var tmp145 any; var or__1927000174__auto____22 any; var tmp146 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp147 any; var root_1586 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = d__21_3; if linked_1587 == nil { tmp147 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp147 = linked_1587.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1586, arg_1589) }; or__1927000174__auto____22 = tmp146.Invoke_O__O(tmp147); if jrt.J2g_Truth(or__1927000174__auto____22) { tmp145 = or__1927000174__auto____22 } else { var tmp148 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp149 any; var root_1590 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = d__21_3; if linked_1591 == nil { tmp149 = ifn_1592.Invoke_O__O(arg_1593) } else { tmp149 = linked_1591.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1590, arg_1593) }; tmp145 = tmp148.Invoke_O__O(tmp149) }; if jrt.J2g_Truth(tmp145) {
				var root_1884 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any; var tmp150 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp151 any; var root_1889 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = d__21_3; if linked_1890 == nil { tmp151 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp151 = linked_1890.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1889, arg_1892) }; arg_1887 = tmp150.Invoke_O__O(tmp151); var arg_1888 any; var tmp152 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp153 any; var root_1893 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = d__21_3; if linked_1894 == nil { tmp153 = ifn_1895.Invoke_O__O(arg_1896) } else { tmp153 = linked_1894.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1893, arg_1896) }; arg_1888 = tmp152.Invoke_O__O(tmp153); if linked_1885 == nil { ifn_1886.Invoke_O_O__O(arg_1887, arg_1888) } else { linked_1885.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_1884, arg_1887, arg_1888) }
//line :201:1
				seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L12 } else { seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000166__20); continue L12 } } else { var temp__1927000414__auto____21_3 any; var root_1594 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = seq_1685000163__17; if linked_1595 == nil { temp__1927000414__auto____21_3 = ifn_1596.Invoke_O__O(arg_1597) } else { temp__1927000414__auto____21_3 = linked_1595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1594, arg_1597) }; if jrt.J2g_Truth(temp__1927000414__auto____21_3) { var seq_1685000163__22 any = temp__1927000414__auto____21_3; var tmp154 any; var root_1598 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = seq_1685000163__22; if linked_1599 == nil { tmp154 = ifn_1600.Invoke_O__O(arg_1601) } else { tmp154 = linked_1599.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1598, arg_1601) }; if jrt.J2g_Truth(tmp154) { var c__1927000678__auto____23_3 any; var root_1602 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = seq_1685000163__22; if linked_1603 == nil { c__1927000678__auto____23_3 = ifn_1604.Invoke_O__O(arg_1605) } else { c__1927000678__auto____23_3 = linked_1603.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1602, arg_1605) }; var tmp155 any; var root_1897 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = seq_1685000163__22; if linked_1898 == nil { tmp155 = ifn_1899.Invoke_O__O(arg_1900) } else { tmp155 = linked_1898.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1897, arg_1900) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp155, c__1927000678__auto____23_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L12 } else { var d__23_3 any; var root_1606 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = seq_1685000163__22; if linked_1607 == nil { d__23_3 = ifn_1608.Invoke_O__O(arg_1609) } else { d__23_3 = linked_1607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1606, arg_1609) }; var tmp156 any; var or__1927000174__auto____24 any; var tmp157 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp158 any; var root_1610 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = d__23_3; if linked_1611 == nil { tmp158 = ifn_1612.Invoke_O__O(arg_1613) } else { tmp158 = linked_1611.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1610, arg_1613) }; or__1927000174__auto____24 = tmp157.Invoke_O__O(tmp158); if jrt.J2g_Truth(or__1927000174__auto____24) { tmp156 = or__1927000174__auto____24 } else { var tmp159 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp160 any; var root_1614 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = d__23_3; if linked_1615 == nil { tmp160 = ifn_1616.Invoke_O__O(arg_1617) } else { tmp160 = linked_1615.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1614, arg_1617) }; tmp156 = tmp159.Invoke_O__O(tmp160) }; if jrt.J2g_Truth(tmp156) {
					var root_1901 any = A_arbace_go_check_A_const_193.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any; var tmp161 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp162 any; var root_1906 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = d__23_3; if linked_1907 == nil { tmp162 = ifn_1908.Invoke_O__O(arg_1909) } else { tmp162 = linked_1907.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1906, arg_1909) }; arg_1904 = tmp161.Invoke_O__O(tmp162); var arg_1905 any; var tmp163 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp164 any; var root_1910 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = d__23_3; if linked_1911 == nil { tmp164 = ifn_1912.Invoke_O__O(arg_1913) } else { tmp164 = linked_1911.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1910, arg_1913) }; arg_1905 = tmp163.Invoke_O__O(tmp164); if linked_1902 == nil { ifn_1903.Invoke_O_O__O(arg_1904, arg_1905) } else { linked_1902.(*A_arbace_go_check_mark_qualifiers_used_BANG__A).Invoke_O_O_O__O(root_1901, arg_1904, arg_1905) }
//line :201:1
					var tmp165 any; var root_1914 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = seq_1685000163__22; if linked_1915 == nil { tmp165 = ifn_1916.Invoke_O__O(arg_1917) } else { tmp165 = linked_1915.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1914, arg_1917) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp165, nil, 0, 0; continue L12 } else { var tmp166 any; var root_1918 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = seq_1685000163__22; if linked_1919 == nil { tmp166 = ifn_1920.Invoke_O__O(arg_1921) } else { tmp166 = linked_1919.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1918, arg_1921) }; seq_1685000163__17, chunk_1685000164__18, count_1685000165__19, i_1685000166__20 = tmp166, nil, 0, 0; continue L12 } } } }
//line :151:1
			break L12 }; var seq_1685000167__17 any; var root_1618 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1620 lang.IFn



















































		if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = fis__12; if linked_1619 == nil { seq_1685000167__17 = ifn_1620.Invoke_O__O(arg_1621) } else { seq_1685000167__17 = linked_1619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1618, arg_1621) }
//line :151:1
		var chunk_1685000168__18 any; var count_1685000169__19 int64 = 0; var i_1685000170__20 int64 = 0; L13: for {



















































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000170__20, count_1685000169__19) { var fi__21_3 any = lang.Indexed_Cast(chunk_1685000168__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000170__20)); var root_1922 any = A_arbace_go_check_A_const_194.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = fi__21_3; if linked_1923 == nil { ifn_1924.Invoke_O__O(arg_1925) } else { linked_1923.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_1922, arg_1925) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000170__20); continue L13 } else { var temp__1927000414__auto____21_4 any; var root_1622 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = seq_1685000167__17; if linked_1623 == nil { temp__1927000414__auto____21_4 = ifn_1624.Invoke_O__O(arg_1625) } else { temp__1927000414__auto____21_4 = linked_1623.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1622, arg_1625) }; if jrt.J2g_Truth(temp__1927000414__auto____21_4) { var seq_1685000167__22 any = temp__1927000414__auto____21_4; var tmp167 any; var root_1626 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = seq_1685000167__22; if linked_1627 == nil { tmp167 = ifn_1628.Invoke_O__O(arg_1629) } else { tmp167 = linked_1627.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1626, arg_1629) }; if jrt.J2g_Truth(tmp167) { var c__1927000678__auto____23_4 any; var root_1630 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = seq_1685000167__22; if linked_1631 == nil { c__1927000678__auto____23_4 = ifn_1632.Invoke_O__O(arg_1633) } else { c__1927000678__auto____23_4 = linked_1631.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1630, arg_1633) }; var tmp168 any; var root_1926 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = seq_1685000167__22; if linked_1927 == nil { tmp168 = ifn_1928.Invoke_O__O(arg_1929) } else { tmp168 = linked_1927.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1926, arg_1929) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp168, c__1927000678__auto____23_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L13 } else { var fi__23 any; var root_1634 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = seq_1685000167__22; if linked_1635 == nil { fi__23 = ifn_1636.Invoke_O__O(arg_1637) } else { fi__23 = linked_1635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1634, arg_1637) }; var root_1930 any = A_arbace_go_check_A_const_194.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = fi__23; if linked_1931 == nil { ifn_1932.Invoke_O__O(arg_1933) } else { linked_1931.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_unused_imports_BANG__A).Invoke_O_O__O(root_1930, arg_1933) }; var tmp169 any; var root_1934 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = seq_1685000167__22; if linked_1935 == nil { tmp169 = ifn_1936.Invoke_O__O(arg_1937) } else { tmp169 = linked_1935.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1934, arg_1937) }; seq_1685000167__17, chunk_1685000168__18, count_1685000169__19, i_1685000170__20 = tmp169, nil, 0, 0; continue L13 } } }
//line :151:1
			break L13 }; var order__17 any; var root_767 any = A_arbace_go_check_A_const_118.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A_fn_class); var ifn_769 lang.IFn





















































		if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = objs__15; if linked_768 == nil { order__17 = ifn_769.Invoke_O__O(arg_770) } else { order__17 = linked_768.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_init_order_A).Invoke_O_O__O(root_767, arg_770) }
//line :151:1
		var say__18 any; var root_771 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_773 lang.IFn






















































		if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = src__0; var arg_775 any = A_arbace_go_check_A_const_119; if linked_772 == nil { say__18 = ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { say__18 = linked_772.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }
//line :151:1
		var init_entry__19 any; var tmp170 any = A_arbace_go_check_check_package_init_entry__1685000171_A_New(); var tmp171 *jrt.Class
		var fncls__816 /*line :151:1*/*jrt.Class = A_arbace_go_check_check_package_init_entry__1685000171_A_fn_class























































		if fncls__816 == nil { var fncls__816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_check_check_package_init_entry__1685000171_A_fn_class = fncls__816d; tmp171 = fncls__816d } else { tmp171 = fncls__816 }; init_entry__19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp170, tmp171, nil)
//line :151:1
		var have__20 any; var root_817 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_819 lang.IFn


























































		if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = init_entry__19; var arg_821 any = order__17; if linked_818 == nil { have__20 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { have__20 = linked_818.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }
//line :151:1
		var norm__21 any; var tmp172 any = A_arbace_go_check_check_package_norm__1685000175_A_New(); var tmp173 *jrt.Class
		var fncls__850 /*line :151:1*/*jrt.Class = A_arbace_go_check_check_package_norm__1685000175_A_fn_class




























































		if fncls__850 == nil { var fncls__850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_check_check_package_norm__1685000175_A_fn_class = fncls__850d; tmp173 = fncls__850d } else { tmp173 = fncls__850 }; norm__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp172, tmp173, nil)
//line :151:1
		var init_result__22 any; var tmp174 any; var root_851 any = A_arbace_go_check_A_const_126.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_853 lang.IFn

































































		if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = say__18; if linked_852 == nil { tmp174 = ifn_853.Invoke_O__O(arg_854) } else { tmp174 = linked_852.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_851, arg_854) }; if jrt.J2g_Truth(tmp174) {
			var tmp175 any; var root_855 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = norm__21; var arg_859 any = say__18; if linked_856 == nil { tmp175 = ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { tmp175 = linked_856.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp175, have__20) { var tmp176 any = A_arbace_go_check_A_const_127; var tmp177 any = jrt.Boolean_TRUE.Ref(); var tmp178 any = A_arbace_go_check_A_const_128; init_result__22 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp176, tmp177, tmp178, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(say__18)).Ref())) } else {

				var root_1938 any = A_arbace_go_check_A_const_195.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any; if jrt.J2g_Truth(A_arbace_go_check_A_const_196.Invoke_O__O(src__0)) { arg_1941 = jrt.File_New_String(jrt.String_Cast(A_arbace_go_check_A_const_196.Invoke_O__O(src__0))).GetName__String().Ref() } else { var tmp179 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp180 any; var root_1945 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__0); if linked_1946 == nil { tmp180 = ifn_1947.Invoke_O__O(arg_1948) } else { tmp180 = linked_1946.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1945, arg_1948) }; arg_1941 = tmp179.Invoke_O__O(tmp180) }; var arg_1942 any; var or__1927000174__auto____22_2 any = A_arbace_go_check_A_const_197.Invoke_O__O(src__0)
				if jrt.J2g_Truth(or__1927000174__auto____22_2) { arg_1942 = or__1927000174__auto____22_2 } else { arg_1942 = A_arbace_go_check_A_const_22 }
//line :220:1
				var arg_1943 any = A_arbace_go_check_A_const_198; var arg_1944 any = lang.IFn_Cast(A_arbace_go_check_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_59, A_arbace_go_check_A_const_104.Invoke_O__O(src__0), lang.IFn_Cast(A_arbace_go_check_A_const_200.GetRawRoot__O()).Invoke_O__O(say__18), lang.IFn_Cast(A_arbace_go_check_A_const_200.GetRawRoot__O()).Invoke_O__O(have__20)); if linked_1939 == nil { ifn_1940.Invoke_O_O_O_O__O(arg_1941, arg_1942, arg_1943, arg_1944) } else { linked_1939.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_1938, arg_1941, arg_1942, arg_1943, arg_1944) }
//line :218:1
				init_result__22 = A_arbace_go_check_A_const_129 } } else {
//line :217:1
					init_result__22 = nil }
//line :151:1
		var generic_ids__23 any; var root_860 any = A_arbace_go_check_A_const_130.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_862 lang.IFn










































































		if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var root_864 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var tmp181 any = A_arbace_go_check_check_package_fn__1685000179_A_New(); var tmp182 *jrt.Class; var fncls__881 *jrt.Class = A_arbace_go_check_check_package_fn__1685000179_A_fn_class; if fncls__881 == nil { var fncls__881d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_check_package_fn__1685000179_A_fn_class = fncls__881d; tmp182 = fncls__881d } else { tmp182 = fncls__881 }; arg_867 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp181, tmp182, nil); var arg_868 any = decls__16; if linked_865 == nil { arg_863 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { arg_863 = linked_865.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }; if linked_861 == nil { generic_ids__23 = ifn_862.Invoke_O__O(arg_863) } else { generic_ids__23 = linked_861.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_860, arg_863) }
//line :151:1
		var errs__24 any; var root_882 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_884 lang.IFn





















































		if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = errors__9; if linked_883 == nil { errs__24 = ifn_884.Invoke_O__O(arg_885) } else { errs__24 = linked_883.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_882, arg_885) }
//line :151:1
		var counted__25 any; var root_886 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_888 lang.IFn












































































		if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var tmp183 any = A_arbace_go_check_check_package_fn__1685000181_A_New_O(generic_ids__23); var tmp184 *jrt.Class; var fncls__896 *jrt.Class = A_arbace_go_check_check_package_fn__1685000181_A_fn_class; if fncls__896 == nil { var fncls__896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_check_check_package_fn__1685000181_A_fn_class = fncls__896d; tmp184 = fncls__896d } else { tmp184 = fncls__896 }; arg_889 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp183, tmp184, nil); var arg_890 any = errs__24; if linked_887 == nil { counted__25 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { counted__25 = linked_887.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }
//line :151:1
		var forms__26 any; var m__26 any = jrt.IdentityHashMap_New(); var order__27 any = jrt.ArrayList_New(); var seq_1685000183__28 any; var root_1964 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1966 lang.IFn
















































































		if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = decls__16; if linked_1965 == nil { seq_1685000183__28 = ifn_1966.Invoke_O__O(arg_1967) } else { seq_1685000183__28 = linked_1965.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1964, arg_1967) }
//line :151:1
		var chunk_1685000184__29 any; var count_1685000185__30 int64 = 0; var i_1685000186__31 int64 = 0; L14: for {
















































































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000186__31, count_1685000185__30) { var d__32 any = lang.Indexed_Cast(chunk_1685000184__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000186__31)); var f__33 any; var tmp185 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp186 any; var root_1984 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1986 lang.IFn
				if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = d__32; if linked_1985 == nil { tmp186 = ifn_1986.Invoke_O__O(arg_1987) } else { tmp186 = linked_1985.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1984, arg_1987) }; f__33 = tmp185.Invoke_O__O(tmp186)
				if jrt.NN(jrt.IdentityHashMap_Cast(m__26)).ContainsKey_O__Z(f__33) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__27)).Add_O__Z(f__33)); jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Put_O_O__O(f__33, lang.PersistentVector_EMPTY.Ref()) }
				var tmp187 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__26); var tmp188 any; var root_1988 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1988, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1990 lang.IFn; if linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Get_O__O(f__33); var arg_1992 any = d__32; if linked_1989 == nil { tmp188 = ifn_1990.Invoke_O_O__O(arg_1991, arg_1992) } else { tmp188 = linked_1989.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1988, arg_1991, arg_1992) }; jrt.NN(tmp187).Put_O_O__O(f__33, tmp188)
//line :232:1
				seq_1685000183__28, chunk_1685000184__29, count_1685000185__30, i_1685000186__31 = seq_1685000183__28, chunk_1685000184__29, count_1685000185__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000186__31); continue L14 } else { var temp__1927000414__auto____32 any; var root_1968 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = seq_1685000183__28; if linked_1969 == nil { temp__1927000414__auto____32 = ifn_1970.Invoke_O__O(arg_1971) } else { temp__1927000414__auto____32 = linked_1969.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1968, arg_1971) }; if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_1685000183__33 any = temp__1927000414__auto____32; var tmp189 any; var root_1972 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = seq_1685000183__33; if linked_1973 == nil { tmp189 = ifn_1974.Invoke_O__O(arg_1975) } else { tmp189 = linked_1973.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1972, arg_1975) }; if jrt.J2g_Truth(tmp189) { var c__1927000678__auto____34 any; var root_1976 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = seq_1685000183__33; if linked_1977 == nil { c__1927000678__auto____34 = ifn_1978.Invoke_O__O(arg_1979) } else { c__1927000678__auto____34 = linked_1977.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1976, arg_1979) }; var tmp190 any; var root_1993 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = seq_1685000183__33; if linked_1994 == nil { tmp190 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp190 = linked_1994.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1993, arg_1996) }; seq_1685000183__28, chunk_1685000184__29, count_1685000185__30, i_1685000186__31 = tmp190, c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L14 } else { var d__34 any; var root_1980 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = seq_1685000183__33; if linked_1981 == nil { d__34 = ifn_1982.Invoke_O__O(arg_1983) } else { d__34 = linked_1981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1980, arg_1983) }; var f__35 any; var tmp191 *lang.Keyword = A_arbace_go_check_A_const_100; var tmp192 any; var root_1997 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1999 lang.IFn
					if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = d__34; if linked_1998 == nil { tmp192 = ifn_1999.Invoke_O__O(arg_2000) } else { tmp192 = linked_1998.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1997, arg_2000) }; f__35 = tmp191.Invoke_O__O(tmp192)
					if jrt.NN(jrt.IdentityHashMap_Cast(m__26)).ContainsKey_O__Z(f__35) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayList_Cast(order__27)).Add_O__Z(f__35)); jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Put_O_O__O(f__35, lang.PersistentVector_EMPTY.Ref()) }
					var tmp193 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(m__26); var tmp194 any; var root_2001 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = jrt.NN(jrt.IdentityHashMap_Cast(m__26)).Get_O__O(f__35); var arg_2005 any = d__34; if linked_2002 == nil { tmp194 = ifn_2003.Invoke_O_O__O(arg_2004, arg_2005) } else { tmp194 = linked_2002.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2001, arg_2004, arg_2005) }; jrt.NN(tmp193).Put_O_O__O(f__35, tmp194)
//line :232:1
					var tmp195 any; var root_2006 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = seq_1685000183__33; if linked_2007 == nil { tmp195 = ifn_2008.Invoke_O__O(arg_2009) } else { tmp195 = linked_2007.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2006, arg_2009) }; seq_1685000183__28, chunk_1685000184__29, count_1685000185__30, i_1685000186__31 = tmp195, nil, 0, 0; continue L14 } } }
//line :151:1
			break L14
		}



















































































		var root_897 any = A_arbace_go_check_A_const_112.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any; var tmp196 any = A_arbace_go_check_check_package_fn__1685000187_A_New_O(m__26); var tmp197 *jrt.Class; var fncls__902 *jrt.Class = A_arbace_go_check_check_package_fn__1685000187_A_fn_class; if fncls__902 == nil { var fncls__902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_check_check_package_fn__1685000187_A_fn_class = fncls__902d; tmp197 = fncls__902d } else { tmp197 = fncls__902 }; arg_900 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp196, tmp197, nil); var arg_901 any = order__27; if linked_898 == nil { forms__26 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { forms__26 = linked_898.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_897, arg_900, arg_901) }
//line :151:1
		var stats__27 any; var root_903 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_905 lang.IFn





















































































		if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any; var tmp198 any = A_arbace_go_check_check_package_fn__1685000190_A_New(); var tmp199 *jrt.Class; var fncls__1176 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_A_fn_class
		if fncls__1176 == nil { var fncls__1176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_go_check_check_package_fn__1685000190_A_fn_class = fncls__1176d; tmp199 = fncls__1176d } else { tmp199 = fncls__1176 }; arg_906 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp198, tmp199, nil)
//line :237:1
		var arg_907 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_150, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_140, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_142, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_151, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_127, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_152, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_143, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_133, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_153, lang.PersistentVector_EMPTY.Ref())); var arg_908 any = forms__26; if linked_904 == nil { stats__27 = ifn_905.Invoke_O_O_O__O(arg_906, arg_907, arg_908) } else { stats__27 = linked_904.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_903, arg_906, arg_907, arg_908)
		}























		if jrt.J2g_Truth(keep_trees__6) { } else { var seq_1685000229__28 any; var root_2010 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2010, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2012 lang.IFn
			if linked_2011 == nil { ifn_2012 = lang.IFn_Cast(root_2010) } else { ifn_2012 = nil }; var arg_2013 any = decls__16; if linked_2011 == nil { seq_1685000229__28 = ifn_2012.Invoke_O__O(arg_2013) } else { seq_1685000229__28 = linked_2011.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2010, arg_2013) }
//line :262:1
			var chunk_1685000230__29 any; var count_1685000231__30 int64 = 0; var i_1685000232__31 int64 = 0; L15: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000232__31, count_1685000231__30) { var d__32_2 any = lang.Indexed_Cast(chunk_1685000230__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000232__31)); jrt.NN(lang.Volatile_Cast(d__32_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_214.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__32_2)).Deref__O(), A_arbace_go_check_A_const_182, A_arbace_go_check_A_const_215, A_arbace_go_check_A_const_216, A_arbace_go_check_A_const_217)); seq_1685000229__28, chunk_1685000230__29, count_1685000231__30, i_1685000232__31 = seq_1685000229__28, chunk_1685000230__29, count_1685000231__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000232__31); continue L15 } else { var temp__1927000414__auto____32_2 any; var root_2014 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = seq_1685000229__28; if linked_2015 == nil { temp__1927000414__auto____32_2 = ifn_2016.Invoke_O__O(arg_2017) } else { temp__1927000414__auto____32_2 = linked_2015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2014, arg_2017) }; if jrt.J2g_Truth(temp__1927000414__auto____32_2) { var seq_1685000229__33 any = temp__1927000414__auto____32_2; var tmp200 any; var root_2018 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any = seq_1685000229__33; if linked_2019 == nil { tmp200 = ifn_2020.Invoke_O__O(arg_2021) } else { tmp200 = linked_2019.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2018, arg_2021) }; if jrt.J2g_Truth(tmp200) { var c__1927000678__auto____34_2 any; var root_2022 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = seq_1685000229__33; if linked_2023 == nil { c__1927000678__auto____34_2 = ifn_2024.Invoke_O__O(arg_2025) } else { c__1927000678__auto____34_2 = linked_2023.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2022, arg_2025) }; var tmp201 any; var root_2179 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = seq_1685000229__33; if linked_2180 == nil { tmp201 = ifn_2181.Invoke_O__O(arg_2182) } else { tmp201 = linked_2180.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2179, arg_2182) }; seq_1685000229__28, chunk_1685000230__29, count_1685000231__30, i_1685000232__31 = tmp201, c__1927000678__auto____34_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L15 } else { var d__34_2 any; var root_2026 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = seq_1685000229__33; if linked_2027 == nil { d__34_2 = ifn_2028.Invoke_O__O(arg_2029) } else { d__34_2 = linked_2027.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2026, arg_2029) }; jrt.NN(lang.Volatile_Cast(d__34_2)).Reset_O__O(lang.IFn_Cast(A_arbace_go_check_A_const_214.GetRawRoot__O()).Invoke_O_O_O_O_O__O(jrt.NN(lang.Volatile_Cast(d__34_2)).Deref__O(), A_arbace_go_check_A_const_182, A_arbace_go_check_A_const_215, A_arbace_go_check_A_const_216, A_arbace_go_check_A_const_217)); var tmp202 any; var root_2191 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = seq_1685000229__33; if linked_2192 == nil { tmp202 = ifn_2193.Invoke_O__O(arg_2194) } else { tmp202 = linked_2192.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2191, arg_2194) }; seq_1685000229__28, chunk_1685000230__29, count_1685000231__30, i_1685000232__31 = tmp202, nil, 0, 0; continue L15 } } }
//line :262:1
				break L15
			} }
		var tmp203 *lang.Volatile = lang.Volatile_Cast(pkg__8); var tmp204 any; var root_2030 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2030, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2032 lang.IFn; if linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = jrt.NN(lang.Volatile_Cast(pkg__8)).Deref__O(); var arg_2034 any = A_arbace_go_check_A_const_201; var arg_2035 any; var tmp205 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_184.GetRawRoot__O()); var tmp206 any = A_arbace_go_check_A_const_104; var tmp207 any = A_arbace_go_check_A_const_104.Invoke_O__O(src__0); var tmp208 any = A_arbace_go_check_A_const_202; var tmp209 any; var root_2058 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2060 lang.IFn


		if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any; var root_2062 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any; var root_2067 any = A_arbace_go_check_A_const_205.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = A_arbace_go_check_A_const_73; var arg_2071 any = A_arbace_go_check_A_const_78; if linked_2068 == nil { arg_2065 = ifn_2069.Invoke_O_O__O(arg_2070, arg_2071) } else { arg_2065 = linked_2068.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2067, arg_2070, arg_2071) }; var arg_2066 any = counted__25; if linked_2063 == nil { arg_2061 = ifn_2064.Invoke_O_O__O(arg_2065, arg_2066) } else { arg_2061 = linked_2063.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2062, arg_2065, arg_2066) }; if linked_2059 == nil { tmp209 = ifn_2060.Invoke_O__O(arg_2061) } else { tmp209 = linked_2059.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2058, arg_2061) }
//line :265:1
		var tmp210 any = tmp209; var tmp211 any = A_arbace_go_check_A_const_206; var tmp212 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(errs__24)), int64(lang.RT_Count_O__I_NoInit(counted__25)))).Ref(); var tmp213 any = A_arbace_go_check_A_const_207; var tmp214 any = A_arbace_go_check_A_const_208; var tmp215 any




		if jrt.J2g_Truth(keep_trees__6) { var root_2072 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any; var root_2076 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any; var tmp216 any = A_arbace_go_check_check_package_fn__1685000233_A_New(); var tmp217 *jrt.Class; var fncls__2085 *jrt.Class = A_arbace_go_check_check_package_fn__1685000233_A_fn_class; if fncls__2085 == nil { var fncls__2085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_check_check_package_fn__1685000233_A_fn_class = fncls__2085d; tmp217 = fncls__2085d } else { tmp217 = fncls__2085 }; arg_2079 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp216, tmp217, nil); var arg_2080 any = decls__16; if linked_2077 == nil { arg_2075 = ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { arg_2075 = linked_2077.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) }; if linked_2073 == nil { tmp215 = ifn_2074.Invoke_O__O(arg_2075) } else { tmp215 = linked_2073.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2072, arg_2075) } } else { tmp215 = nil }
//line :265:1
		var tmp218 any = tmp215; var tmp219 any = A_arbace_go_check_A_const_209; var tmp220 any







		if jrt.J2g_Truth(keep_trees__6) {
			var root_2086 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var iter__1927001039__auto____28 any; var tmp221 any = A_arbace_go_check_check_package_iter__1685000235__1685000239_A_New(); var tmp222 *jrt.Class; var fncls__2166 *jrt.Class = A_arbace_go_check_check_package_iter__1685000235__1685000239_A_fn_class; if fncls__2166 == nil { var fncls__2166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_check_package_iter__1685000235__1685000239_A_fn_class = fncls__2166d; tmp222 = fncls__2166d } else { tmp222 = fncls__2166 }; iter__1927001039__auto____28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp221, tmp222, nil); arg_2089 = lang.IFn_Cast(iter__1927001039__auto____28).Invoke_O__O(decls__16); if linked_2087 == nil { tmp220 = ifn_2088.Invoke_O__O(arg_2089) } else { tmp220 = linked_2087.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2086, arg_2089) } } else {
//line :273:1
				tmp220 = nil }
//line :265:1
		var tmp223 any = tmp220; var tmp224 any = A_arbace_go_check_A_const_213; var tmp225 any











		if jrt.J2g_Truth(keep_trees__6) { tmp225 = order__17 } else { tmp225 = nil }
//line :265:1
		var tmp226 any = tmp225; var tmp227 any = A_arbace_go_check_A_const_71; var tmp228 any












		if jrt.J2g_Truth(keep_trees__6) { tmp228 = pkg_scope__7 } else { tmp228 = nil }
//line :265:1
		var tmp229 any = tmp228; var tmp230 any = A_arbace_go_check_A_const_110; var tmp231 any













		if jrt.J2g_Truth(keep_trees__6) { var root_2167 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = A_arbace_go_check_A_const_110.Invoke_O__O(ctx__11); if linked_2168 == nil { tmp231 = ifn_2169.Invoke_O__O(arg_2170) } else { tmp231 = linked_2168.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2167, arg_2170) } } else { tmp231 = nil }
//line :265:1
		arg_2035 = tmp205.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(stats__27, tmp206, tmp207, tmp208, tmp210, tmp211, tmp212, tmp213, init_result__22, tmp214, tmp218, tmp219, tmp223, tmp224, tmp226, tmp227, tmp229, tmp230, tmp231)
//line :264:1
		if linked_2031 == nil { tmp204 = ifn_2032.Invoke_O_O_O__O(arg_2033, arg_2034, arg_2035) } else { tmp204 = linked_2031.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2030, arg_2033, arg_2034, arg_2035) }; jrt.NN(tmp203).Reset_O__O(tmp204)
//line :151:1
		tmp45 = pkg__8 }; return nil }(); var root_1177 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1179 lang.IFn; if











	linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; if linked_1178 == nil { ifn_1179.Invoke__O() } else { linked_1178.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1177) }; if /*line :151:1*/ tmp232 != nil { panic(tmp232) }; return tmp45 }










func A_arbace_go_check_check_package_fn__1685000099_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000099_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000099_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_go_check_check_package_fn__1685000099_A) Ctor_O_O(c__src, c__pkg_scope any) { t.F_src = c__src; t.F_pkg_scope = c__pkg_scope }
//line :162:1
func (t *A_arbace_go_check_check_package_fn__1685000099_A) Invoke_O_O__O(self, p1__1685000082_SHARP___1 any) any { var root_741 any = A_arbace_go_check_A_const_113.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_go_check_file_info_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t.F_pkg_scope; var arg_745 any = p1__1685000082_SHARP___1; var arg_746 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_src); if linked_742 == nil { return ifn_743.Invoke_O_O_O__O(arg_744, arg_745, arg_746) } else { return linked_742.(*A_arbace_go_check_file_info_A).Invoke_O_O_O_O__O(root_741, arg_744, arg_745, arg_746) } }























func A_arbace_go_check_check_package_fn__1685000135_A_New() *A_arbace_go_check_check_package_fn__1685000135_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000135_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_check_check_package_fn__1685000135_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_check_check_package_fn__1685000135_A) Invoke_O_O__O(self, p1__1685000083_SHARP___1 any) any { var root_761 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = p1__1685000083_SHARP___1; var arg_765 any = A_arbace_go_check_A_const_117; if linked_762 == nil { return ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { return linked_762.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) } }





func A_arbace_go_check_check_package_fn__1685000142_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000142_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :192:1
func (t *A_arbace_go_check_check_package_fn__1685000142_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :192:1
func (t *A_arbace_go_check_check_package_fn__1685000142_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000143__5 any; var root_1652 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn
											if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1655 = t_; if linked_1653 == nil { seq_1685000143__5 = ifn_1654.Invoke_O__O(arg_1655) } else { seq_1685000143__5 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }
//line :192:1
	var chunk_1685000144__6 any; var count_1685000145__7 int64 = 0; var i_1685000146__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000146__8, count_1685000145__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000144__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000146__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000143__5, chunk_1685000144__6, count_1685000145__7, i_1685000146__8 = seq_1685000143__5, chunk_1685000144__6, count_1685000145__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000146__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1656 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = seq_1685000143__5; if linked_1657 == nil { temp__1927000414__auto____9 = ifn_1658.Invoke_O__O(arg_1659) } else { temp__1927000414__auto____9 = linked_1657.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1656, arg_1659) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000143__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1660 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = seq_1685000143__10; if linked_1661 == nil { tmp2 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp2 = linked_1661.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1660, arg_1663) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1664 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = seq_1685000143__10; if linked_1665 == nil { c__1927000678__auto____11 = ifn_1666.Invoke_O__O(arg_1667) } else { c__1927000678__auto____11 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1664, arg_1667) }; var tmp3 any; var root_1675 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = seq_1685000143__10; if linked_1676 == nil { tmp3 = ifn_1677.Invoke_O__O(arg_1678) } else { tmp3 = linked_1676.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1675, arg_1678) }; seq_1685000143__5, chunk_1685000144__6, count_1685000145__7, i_1685000146__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1668 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = seq_1685000143__10; if linked_1669 == nil { l__11 = ifn_1670.Invoke_O__O(arg_1671) } else { l__11 = linked_1669.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1668, arg_1671) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1679 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = seq_1685000143__10; if linked_1680 == nil { tmp4 = ifn_1681.Invoke_O__O(arg_1682) } else { tmp4 = linked_1680.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1679, arg_1682) }; seq_1685000143__5, chunk_1685000144__6, count_1685000145__7, i_1685000146__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :192:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1683 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1685 lang.IFn

			if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = ex__5; if linked_1684 == nil { tmp6 = ifn_1685.Invoke_O__O(arg_1686) } else { tmp6 = linked_1684.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1683, arg_1686) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1687 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1690 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1691 any = A_arbace_go_check_A_const_133; var arg_1692 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_186; var tmp11 any; var root_1693 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = ex__5; if linked_1694 == nil { tmp11 = ifn_1695.Invoke_O__O(arg_1696) } else { tmp11 = linked_1694.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1693, arg_1696) }; arg_1692 = tmp10.Invoke_O__O(tmp11); if linked_1688 == nil { tmp8 = ifn_1689.Invoke_O_O_O__O(arg_1690, arg_1691, arg_1692) } else { tmp8 = linked_1688.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1687, arg_1690, arg_1691, arg_1692) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :192:1
				panic(tmp5) } } }; return nil }(); var root_1672 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; if linked_1673 == nil { ifn_1674.Invoke__O() } else { linked_1673.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1672) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :192:1
func A_arbace_go_check_check_package_fn__1685000149_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_fn__1685000149_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000149_A{}; t.Ctor_O_O(p0, p1); return t }
//line :192:1
func (t *A_arbace_go_check_check_package_fn__1685000149_A) Ctor_O_O(c__d, c__ls any) { t.F_d = c__d; t.F_ls = c__ls }
//line :192:1
func (t *A_arbace_go_check_check_package_fn__1685000149_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1685000150__5 any; var root_1742 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1744 lang.IFn
											if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any; var t_ any = t.F_ls; t.F_ls = nil; arg_1745 = t_; if linked_1743 == nil { seq_1685000150__5 = ifn_1744.Invoke_O__O(arg_1745) } else { seq_1685000150__5 = linked_1743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1742, arg_1745) }
//line :192:1
	var chunk_1685000151__6 any; var count_1685000152__7 int64 = 0; var i_1685000153__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000153__8, count_1685000152__7) { var l__9 any = lang.Indexed_Cast(chunk_1685000151__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000153__8)); lang.IFn_Cast(l__9).Invoke__O(); seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, i_1685000153__8 = seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000153__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1746 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = seq_1685000150__5; if linked_1747 == nil { temp__1927000414__auto____9 = ifn_1748.Invoke_O__O(arg_1749) } else { temp__1927000414__auto____9 = linked_1747.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1746, arg_1749) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1685000150__10 any = temp__1927000414__auto____9; var tmp2 any; var root_1750 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = seq_1685000150__10; if linked_1751 == nil { tmp2 = ifn_1752.Invoke_O__O(arg_1753) } else { tmp2 = linked_1751.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1750, arg_1753) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_1754 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = seq_1685000150__10; if linked_1755 == nil { c__1927000678__auto____11 = ifn_1756.Invoke_O__O(arg_1757) } else { c__1927000678__auto____11 = linked_1755.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1754, arg_1757) }; var tmp3 any; var root_1765 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = seq_1685000150__10; if linked_1766 == nil { tmp3 = ifn_1767.Invoke_O__O(arg_1768) } else { tmp3 = linked_1766.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1765, arg_1768) }; seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, i_1685000153__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__11 any; var root_1758 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = seq_1685000150__10; if linked_1759 == nil { l__11 = ifn_1760.Invoke_O__O(arg_1761) } else { l__11 = linked_1759.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1758, arg_1761) }; lang.IFn_Cast(l__11).Invoke__O(); var tmp4 any; var root_1769 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = seq_1685000150__10; if linked_1770 == nil { tmp4 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp4 = linked_1770.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1769, arg_1772) }; seq_1685000150__5, chunk_1685000151__6, count_1685000152__7, i_1685000153__8 = tmp4, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :192:1
		break L1 } }; return nil }(); if tmp5 != nil { if jrt.Exception_InstanceOf(tmp5) { var ex__5 jrt.Exception_I = jrt.Exception_Cast(tmp5); var tmp6 any; var root_1773 any = A_arbace_go_check_A_const_185.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A_fn_class); var ifn_1775 lang.IFn

			if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = ex__5; if linked_1774 == nil { tmp6 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp6 = linked_1774.(*aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A).Invoke_O_O__O(root_1773, arg_1776) }; if jrt.J2g_Truth(tmp6) { var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_d); var tmp8 any; var root_1777 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any; var tmp9 any; var t__2 any = t.F_d; t.F_d = nil; tmp9 = t__2; arg_1780 = jrt.NN(lang.Volatile_Cast(tmp9)).Deref__O(); var arg_1781 any = A_arbace_go_check_A_const_133; var arg_1782 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_186; var tmp11 any; var root_1783 any = A_arbace_go_check_A_const_187.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = ex__5; if linked_1784 == nil { tmp11 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp11 = linked_1784.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1783, arg_1786) }; arg_1782 = tmp10.Invoke_O__O(tmp11); if linked_1778 == nil { tmp8 = ifn_1779.Invoke_O_O_O__O(arg_1780, arg_1781, arg_1782) } else { tmp8 = linked_1778.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1777, arg_1780, arg_1781, arg_1782) }; tmp1 = jrt.NN(tmp7).Reset_O__O(tmp8) } else { panic(jrt.Thrown(ex__5)) } } else {
//line :192:1
				panic(tmp5) } } }; return nil }(); var root_1762 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; if linked_1763 == nil { ifn_1764.Invoke__O() } else { linked_1763.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1762) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }





func A_arbace_go_check_check_package_fn__1685000159_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000159_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000159_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_go_check_check_package_fn__1685000159_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :198:1
func (t *A_arbace_go_check_check_package_fn__1685000159_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1818 any = A_arbace_go_check_A_const_192.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_182; var tmp3 any; var root_1822 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any; var t_ any = t.F_d; t.F_d = nil; arg_1825 = t_; if linked_1823 == nil { tmp3 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp3 = linked_1823.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1822, arg_1825) }; arg_1821 = tmp2.Invoke_O__O(tmp3); if linked_1819 == nil { tmp1 = ifn_1820.Invoke_O__O(arg_1821) } else { tmp1 = linked_1819.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_1818, arg_1821) } }
//line :198:1
	return nil }(); var root_1826 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; if linked_1827 == nil { ifn_1828.Invoke__O() } else { linked_1827.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1826) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :198:1
func A_arbace_go_check_check_package_fn__1685000161_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000161_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000161_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_go_check_check_package_fn__1685000161_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :198:1
func (t *A_arbace_go_check_check_package_fn__1685000161_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var root_1849 any = A_arbace_go_check_A_const_192.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, A_arbace_go_check_verify_tags_BANG__A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_182; var tmp3 any; var root_1853 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any; var t_ any = t.F_d; t.F_d = nil; arg_1856 = t_; if linked_1854 == nil { tmp3 = ifn_1855.Invoke_O__O(arg_1856) } else { tmp3 = linked_1854.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1853, arg_1856) }; arg_1852 = tmp2.Invoke_O__O(tmp3); if linked_1850 == nil { tmp1 = ifn_1851.Invoke_O__O(arg_1852) } else { tmp1 = linked_1850.(*A_arbace_go_check_verify_tags_BANG__A).Invoke_O_O__O(root_1849, arg_1852) } }
//line :198:1
	return nil }(); var root_1857 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; if linked_1858 == nil { ifn_1859.Invoke__O() } else { linked_1858.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1857) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }








func A_arbace_go_check_check_package_init_entry__1685000171_A_New() *A_arbace_go_check_check_package_init_entry__1685000171_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000171_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_go_check_check_package_init_entry__1685000171_A) Ctor() {}
//line :207:1
func (t *A_arbace_go_check_check_package_init_entry__1685000171_A) Invoke_O_O__O(self, lhs__1 any) any { var one__2 any; var tmp1 any = A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A_New(); var tmp2 *jrt.Class; var fncls__800 *jrt.Class = A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A_fn_class; if
													fncls__800 == nil { var fncls__800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A_fn_class = fncls__800d; tmp2 = fncls__800d } else { tmp2 = fncls__800 }; one__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if
													lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(lhs__1))) { var tmp3 lang.IFn = lang.IFn_Cast(one__2); var tmp4 any; var root_812 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = lhs__1; if linked_813 == nil { tmp4 = ifn_814.Invoke_O__O(arg_815) } else { tmp4 = linked_813.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_812, arg_815) }; return tmp3.Invoke_O__O(tmp4) } else { var root_801 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var arg_805 any = A_arbace_go_check_A_const_123; var arg_806 any; var root_807 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = one__2; var arg_811 any = lhs__1; if linked_808 == nil { arg_806 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { arg_806 = linked_808.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; if linked_802 == nil { return ifn_803.Invoke_O_O_O__O(arg_804, arg_805, arg_806) } else { return linked_802.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_801, arg_804, arg_805, arg_806) } } }
//line :208:1
func A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A_New() *A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; var root_776 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = v__1; var arg_780 any = A_arbace_go_check_A_const_70; if linked_777 == nil { tmp1 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { tmp1 = linked_777.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_79, tmp1) { var tmp2 any; var root_790 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = v__1; var arg_794 any = A_arbace_go_check_A_const_73; if linked_791 == nil { tmp2 = ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { tmp2 = linked_791.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) }; var tmp3 any = tmp2; var tmp4 any; var root_795 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = v__1; var arg_799 any = A_arbace_go_check_A_const_78; if linked_796 == nil { tmp4 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp4 = linked_796.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var root_781 any = A_arbace_go_check_A_const_120.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_785 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = v__1; var arg_789 any = A_arbace_go_check_A_const_70; if linked_786 == nil { arg_784 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { arg_784 = linked_786.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; if linked_782 == nil { return ifn_783.Invoke_O__O(arg_784) } else { return linked_782.(*aot_arbace_repr_go_types.A_arbace_repr_go_types_name_form_A).Invoke_O_O__O(root_781, arg_784) } } }



func A_arbace_go_check_check_package_norm__1685000175_A_New() *A_arbace_go_check_check_package_norm__1685000175_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000175_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_go_check_check_package_norm__1685000175_A) Ctor() {}
//line :212:1
func (t *A_arbace_go_check_check_package_norm__1685000175_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_822 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_824 lang.IFn; if
												linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = x__1; if linked_823 == nil { tmp1 = ifn_824.Invoke_O__O(arg_825) } else { tmp1 = linked_823.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_822, arg_825) }; if /*line :212:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(x__1, lang.RT_IntCast_J__I_NoInit(1))) } else { var tmp2 any; var root_826 any = A_arbace_go_check_A_const_96.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A_fn_class); var ifn_828 lang.IFn

		if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = x__1; if linked_827 == nil { tmp2 = ifn_828.Invoke_O__O(arg_829) } else { tmp2 = linked_827.(*aot_arbace_go_check_code.A_arbace_go_check_code_head_name_A).Invoke_O_O__O(root_826, arg_829) }
//line :212:1
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_82, tmp2) {


			var root_830 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = A_arbace_go_check_A_const_122.GetRawRoot__O(); var arg_834 any = A_arbace_go_check_A_const_124; var arg_835 any; var root_836 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any; var tmp3 any = A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A_New(); var tmp4 *jrt.Class; var fncls__845 *jrt.Class = A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A_fn_class; if fncls__845 == nil { var fncls__845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A_fn_class = fncls__845d; tmp4 = fncls__845d } else { tmp4 = fncls__845 }; arg_839 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_840 any; var root_846 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = x__1; if linked_847 == nil { arg_840 = ifn_848.Invoke_O__O(arg_849) } else { arg_840 = linked_847.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_846, arg_849) }; if linked_837 == nil { arg_835 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { arg_835 = linked_837.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; if linked_831 == nil { return ifn_832.Invoke_O_O_O__O(arg_833, arg_834, arg_835) } else { return linked_831.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_830, arg_833, arg_834, arg_835) } } else {
//line :212:1
				if A_arbace_go_check_A_const_28 != nil { return x__1 } else { return nil } } } }


func A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A_New() *A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A) Ctor() {}
//line :215:1
func (t *A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A) Invoke_O_O__O(self, p1__1685000084_SHARP___1 any) any { var tmp1 any; var root_841 any = A_arbace_go_check_A_const_26.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = p1__1685000084_SHARP___1; if linked_842 == nil { tmp1 = ifn_843.Invoke_O__O(arg_844) } else { tmp1 = linked_842.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(p1__1685000084_SHARP___1, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(p1__1685000084_SHARP___1, lang.RT_IntCast_J__I_NoInit(1))) } else { return p1__1685000084_SHARP___1 } }










func A_arbace_go_check_check_package_fn__1685000179_A_New() *A_arbace_go_check_check_package_fn__1685000179_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000179_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Ctor() {}
//line :226:1
func (t *A_arbace_go_check_check_package_fn__1685000179_A) Invoke_O_O__O(self, p1__1685000085_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp3 any; var root_869 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = p1__1685000085_SHARP___1; if linked_870 == nil { tmp3 = ifn_871.Invoke_O__O(arg_872) } else { tmp3 = linked_870.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_869, arg_872) }; or__1927000174__auto____2 = tmp2.Invoke_O__O(tmp3); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var tmp4 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp5 any; var root_873 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = p1__1685000085_SHARP___1; if linked_874 == nil { tmp5 = ifn_875.Invoke_O__O(arg_876) } else { tmp5 = linked_874.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_873, arg_876) }; tmp1 = tmp4.Invoke_O__O(tmp5) }; if jrt.J2g_Truth(tmp1) { var tmp6 *lang.Keyword = A_arbace_go_check_A_const_134; var tmp7 any; var root_877 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = p1__1685000085_SHARP___1; if linked_878 == nil { tmp7 = ifn_879.Invoke_O__O(arg_880) } else { tmp7 = linked_878.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_877, arg_880) }; return tmp6.Invoke_O__O(tmp7) } else { return nil } }

func A_arbace_go_check_check_package_fn__1685000181_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000181_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000181_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_go_check_check_package_fn__1685000181_A) Ctor_O(c__generic_ids any) { t.F_generic_ids = c__generic_ids }
//line :228:1
func (t *A_arbace_go_check_check_package_fn__1685000181_A) Invoke_O_O__O(self, p1__1685000086_SHARP___1 any) any { var root_891 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = t.F_generic_ids; var arg_895 any = A_arbace_go_check_A_const_117.Invoke_O__O(p1__1685000086_SHARP___1); if linked_892 == nil { return ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { return linked_892.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_891, arg_894, arg_895) } }







func A_arbace_go_check_check_package_fn__1685000187_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000187_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000187_A{}; t.Ctor_O(p0); return t }
//line :236:1
func (t *A_arbace_go_check_check_package_fn__1685000187_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :236:1
func (t *A_arbace_go_check_check_package_fn__1685000187_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.NN(jrt.IdentityHashMap_Cast(t.F_m)).Get_O__O(f__1)) }

func A_arbace_go_check_check_package_fn__1685000190_A_New() *A_arbace_go_check_check_package_fn__1685000190_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_go_check_check_package_fn__1685000190_A) Ctor() {}
//line :238:1
func (t *A_arbace_go_check_check_package_fn__1685000190_A) Invoke_O_O_O__O(self, acc__1, p__1685000189__2 any) any { var vec__1685000191__3 any = p__1685000189__2; var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000191__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000191__3, lang.RT_IntCast_J__I_NoInit(1), nil); var gen__6 any; var root_909 any = A_arbace_go_check_A_const_137.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_911 lang.IFn; if
															linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A_New(); var tmp2 *jrt.Class; var fncls__922 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A_fn_class; if fncls__922 == nil { var fncls__922d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A_fn_class = fncls__922d; tmp2 = fncls__922d } else { tmp2 = fncls__922 }; arg_912 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_913 any = ds__5; if linked_910 == nil { gen__6 = ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { gen__6 = linked_910.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) }; var present__7 any; var root_923 any = /*line :238:1*/A_arbace_go_check_A_const_138.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, A_arbace_go_check_annotations_present_A_fn_class); var ifn_925 lang.IFn; if

	linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = form__4; if linked_924 == nil { present__7 = ifn_925.Invoke_O__O(arg_926) } else { present__7 = linked_924.(*A_arbace_go_check_annotations_present_A).Invoke_O_O__O(root_923, arg_926) }; var verified__8 any; var root_927 any = /*line :238:1*/A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_929 lang.IFn; if


	linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var arg_931 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_932 any; var root_933 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any; var tmp3 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A_New(); var tmp4 *jrt.Class; var fncls__942 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A_fn_class; if fncls__942 == nil { var fncls__942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A_fn_class = fncls__942d; tmp4 = fncls__942d } else { tmp4 = fncls__942 }; arg_936 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_937 any = ds__5; if linked_934 == nil { arg_932 = ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { arg_932 = linked_934.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) }; if linked_928 == nil { verified__8 = ifn_929.Invoke_O_O_O__O(arg_930, arg_931, arg_932) } else { verified__8 = linked_928.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_927, arg_930, arg_931, arg_932) }; if
	jrt.J2g_Truth(gen__6) {




		var root_943 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any; var root_949 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_951 lang.IFn
//line :246:1
		if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any; var root_955 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_957 lang.IFn
//line :245:1
		if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any; var root_962 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_964 lang.IFn
//line :244:1
		if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = acc__1; var arg_966 any = A_arbace_go_check_A_const_140; var arg_967 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); if linked_963 == nil { arg_958 = ifn_964.Invoke_O_O_O__O(arg_965, arg_966, arg_967) } else { arg_958 = linked_963.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_962, arg_965, arg_966, arg_967) }
		var arg_959 any = A_arbace_go_check_A_const_142; var arg_960 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_961 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_956 == nil { arg_952 = ifn_957.Invoke_O_O_O_O__O(arg_958, arg_959, arg_960, arg_961) } else { arg_952 = linked_956.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_955, arg_958, arg_959, arg_960, arg_961) }
		var arg_953 any = A_arbace_go_check_A_const_143; var arg_954 any; var tmp5 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A_New_O(present__7); var tmp6 *jrt.Class; var fncls__974 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A_fn_class; if fncls__974 == nil { var fncls__974d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A_fn_class = fncls__974d; tmp6 = fncls__974d } else { tmp6 = fncls__974 }; arg_954 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_950 == nil { arg_946 = ifn_951.Invoke_O_O_O__O(arg_952, arg_953, arg_954) } else { arg_946 = linked_950.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_949, arg_952, arg_953, arg_954) }
		var arg_947 any = A_arbace_go_check_A_const_133; var arg_948 any; var tmp7 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A_New_O(ds__5); var tmp8 *jrt.Class; var fncls__997 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A_fn_class; if fncls__997 == nil { var fncls__997d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A_fn_class = fncls__997d; tmp8 = fncls__997d } else { tmp8 = fncls__997 }; arg_948 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); if linked_944 == nil { return ifn_945.Invoke_O_O_O__O(arg_946, arg_947, arg_948) } else { return linked_944.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_943, arg_946, arg_947, arg_948) } } else {
//line :242:1
			var unver__9 any; var root_998 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1000 lang.IFn





			if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1002 any; var iter__1927001039__auto____9 any; var tmp9 any = A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A_New_O(verified__8); var tmp10 *jrt.Class; var fncls__1095 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A_fn_class; if fncls__1095 == nil { var fncls__1095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A_fn_class = fncls__1095d; tmp10 = fncls__1095d } else { tmp10 = fncls__1095 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1002 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(present__7); if linked_999 == nil { unver__9 = ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { unver__9 = linked_999.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002)
			}








			var root_1096 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1102 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1104 lang.IFn
//line :257:1
			if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any; var root_1108 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1110 lang.IFn
//line :256:1
			if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var root_1114 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1116 lang.IFn
//line :255:1
			if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any; var root_1120 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1122 lang.IFn
//line :254:1
			if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any; var root_1127 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1129 lang.IFn
//line :253:1
			if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = acc__1; var arg_1131 any = A_arbace_go_check_A_const_150; var arg_1132 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); if linked_1128 == nil { arg_1123 = ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { arg_1123 = linked_1128.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) }
			var arg_1124 any = A_arbace_go_check_A_const_82; var arg_1125 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1126 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ds__5)).Ref(); if linked_1121 == nil { arg_1117 = ifn_1122.Invoke_O_O_O_O__O(arg_1123, arg_1124, arg_1125, arg_1126) } else { arg_1117 = linked_1121.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1120, arg_1123, arg_1124, arg_1125, arg_1126) }
			var arg_1118 any = A_arbace_go_check_A_const_151; var arg_1119 any; var tmp11 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A_New_O(present__7); var tmp12 *jrt.Class; var fncls__1139 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A_fn_class; if fncls__1139 == nil { var fncls__1139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A_fn_class = fncls__1139d; tmp12 = fncls__1139d } else { tmp12 = fncls__1139 }; arg_1119 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); if linked_1115 == nil { arg_1111 = ifn_1116.Invoke_O_O_O__O(arg_1117, arg_1118, arg_1119) } else { arg_1111 = linked_1115.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1114, arg_1117, arg_1118, arg_1119) }
			var arg_1112 any = A_arbace_go_check_A_const_127; var arg_1113 any; var tmp13 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A_New_O(verified__8); var tmp14 *jrt.Class; var fncls__1146 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A_fn_class; if fncls__1146 == nil { var fncls__1146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A_fn_class = fncls__1146d; tmp14 = fncls__1146d } else { tmp14 = fncls__1146 }; arg_1113 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_1109 == nil { arg_1105 = ifn_1110.Invoke_O_O_O__O(arg_1111, arg_1112, arg_1113) } else { arg_1105 = linked_1109.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1108, arg_1111, arg_1112, arg_1113) }
			var arg_1106 any = A_arbace_go_check_A_const_152; var arg_1107 any; var tmp15 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A_New_O(unver__9); var tmp16 *jrt.Class; var fncls__1153 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A_fn_class; if fncls__1153 == nil { var fncls__1153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A_fn_class = fncls__1153d; tmp16 = fncls__1153d } else { tmp16 = fncls__1153 }; arg_1107 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); if linked_1103 == nil { arg_1099 = ifn_1104.Invoke_O_O_O__O(arg_1105, arg_1106, arg_1107) } else { arg_1099 = linked_1103.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1102, arg_1105, arg_1106, arg_1107) }
			var arg_1100 any = A_arbace_go_check_A_const_153; var arg_1101 any; var tmp17 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A_New_O_O_O(form__4, unver__9, ds__5); var tmp18 *jrt.Class; var fncls__1175 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A_fn_class; if fncls__1175 == nil { var fncls__1175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A_fn_class = fncls__1175d; tmp18 = fncls__1175d } else { tmp18 = fncls__1175 }; arg_1101 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); if linked_1097 == nil { return ifn_1098.Invoke_O_O_O__O(arg_1099, arg_1100, arg_1101) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1096, arg_1099, arg_1100, arg_1101) } } }
//line :239:1
func A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A_New() *A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A) Ctor() {}
//line :239:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A) Invoke_O_O__O(self, p1__1685000087_SHARP___1 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_132; var tmp2 any; var root_914 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = p1__1685000087_SHARP___1; if linked_915 == nil { tmp2 = ifn_916.Invoke_O__O(arg_917) } else { tmp2 = linked_915.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_914, arg_917) }; or__1927000174__auto____2 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp3 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp4 any; var root_918 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = p1__1685000087_SHARP___1; if linked_919 == nil { tmp4 = ifn_920.Invoke_O__O(arg_921) } else { tmp4 = linked_919.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_918, arg_921) }; return tmp3.Invoke_O__O(tmp4) } }

func A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A_New() *A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A) Invoke_O_O__O(self, p1__1685000088_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_127; var tmp2 any; var root_938 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = p1__1685000088_SHARP___1; if linked_939 == nil { tmp2 = ifn_940.Invoke_O__O(arg_941) } else { tmp2 = linked_939.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_938, arg_941) }; return tmp1.Invoke_O__O(tmp2) }




func A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :246:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A) Invoke_O_O__O(self, p1__1685000089_SHARP___1 any) any { var root_968 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_972 any = p1__1685000089_SHARP___1; var arg_973 any = t.F_present; if linked_969 == nil { return ifn_970.Invoke_O_O_O__O(arg_971, arg_972, arg_973) } else { return linked_969.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_968, arg_971, arg_972, arg_973) } }
func A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A{}; t.Ctor_O(p0); return t }
//line :247:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :247:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A) Invoke_O_O__O(self, p1__1685000090_SHARP___1 any) any { var root_975 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any; var tmp1 any = A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A_New(); var tmp2 *jrt.Class; var fncls__996 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A_fn_class; if fncls__996 == nil { var fncls__996d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A_fn_class = fncls__996d; tmp2 = fncls__996d } else { tmp2 = fncls__996 }; arg_978 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_979 any = p1__1685000090_SHARP___1; var arg_980 any = t.F_ds; if linked_976 == nil { return ifn_977.Invoke_O_O_O__O(arg_978, arg_979, arg_980) } else { return linked_976.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_975, arg_978, arg_979, arg_980) } }
//line :247:1
func A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A_New() *A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A) Ctor() {}
//line :247:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A) Invoke_O_O_O__O(self, m__1, d__2 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_133; var tmp2 any; var root_981 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = d__2; if linked_982 == nil { tmp2 = ifn_983.Invoke_O__O(arg_984) } else { tmp2 = linked_982.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_981, arg_984) }; temp__1927000408__auto____3 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(temp__1927000408__auto____3) { var u__4 any = temp__1927000408__auto____3; var root_985 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = m__1; var arg_989 any = u__4; var arg_990 any; var root_991 any = A_arbace_go_check_A_const_20.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = A_arbace_go_check_A_const_141.GetRawRoot__O(); var arg_995 any = A_arbace_go_check_A_const_22; if linked_992 == nil { arg_990 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { arg_990 = linked_992.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }; if linked_986 == nil { return ifn_987.Invoke_O_O_O__O(arg_988, arg_989, arg_990) } else { return linked_986.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_985, arg_988, arg_989, arg_990) } } else { return m__1 } }
func A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :248:1
func (t *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A) Invoke_O_O__O(self, s__1685000205__1 any) any { var tmp1 any = A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A_New_O_O_O(self, t.F_verified, s__1685000205__1); var tmp2 *jrt.Class; var fncls__1094 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A_fn_class; if fncls__1094 == nil { var fncls__1094d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A_fn_class = fncls__1094d; tmp2 = fncls__1094d } else { tmp2 = fncls__1094 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :248:1
func A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :248:1
func (t *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A) Ctor_O_O_O(c__iter__1685000204, c__verified, c__s__1685000205 any) { t.F_iter__1685000204 = c__iter__1685000204; t.F_verified = c__verified; t.F_s__1685000205 = c__s__1685000205 }
//line :248:1
func (t *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A) Invoke_O__O(self any) any { { var s__1685000205__1 any; var t_ any = t.F_s__1685000205; t.F_s__1685000205 = nil; s__1685000205__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1003 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = s__1685000205__1; if linked_1004 == nil { temp__1927000414__auto____2 = ifn_1005.Invoke_O__O(arg_1006) } else { temp__1927000414__auto____2 = linked_1004.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1003, arg_1006) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1007 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = s__1685000205__3; if linked_1008 == nil { tmp1 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp1 = linked_1008.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1007, arg_1010) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1011 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = s__1685000205__3; if linked_1012 == nil { c__1927001037__auto____4 = ifn_1013.Invoke_O__O(arg_1014) } else { c__1927001037__auto____4 = linked_1012.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1011, arg_1014) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000207__6 any; var root_1015 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1016 == nil { b__1685000207__6 = ifn_1017.Invoke_O__O(arg_1018) } else { b__1685000207__6 = linked_1016.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1015, arg_1018) }; var tmp2 any = A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A_New_O_O_I_O(t.F_verified, b__1685000207__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1039 *jrt.Class = A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A_fn_class; if fncls__1039 == nil { var fncls__1039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A_fn_class = fncls__1039d; tmp3 = fncls__1039d } else { tmp3 = fncls__1039 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1040 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any; var root_1045 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = b__1685000207__6; if linked_1046 == nil { arg_1043 = ifn_1047.Invoke_O__O(arg_1048) } else { arg_1043 = linked_1046.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1045, arg_1048) }; var arg_1044 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000204); var tmp5 any; var root_1049 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = s__1685000205__3; if linked_1050 == nil { tmp5 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp5 = linked_1050.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1049, arg_1052) }; arg_1044 = tmp4.Invoke_O__O(tmp5); if linked_1041 == nil { return ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { return linked_1041.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) } } else { var root_1053 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any; var root_1058 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = b__1685000207__6; if linked_1059 == nil { arg_1056 = ifn_1060.Invoke_O__O(arg_1061) } else { arg_1056 = linked_1059.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1058, arg_1061) }; var arg_1057 any; if linked_1054 == nil { return ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { return linked_1054.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) } } } else { var vec__1685000215__4 any; var root_1062 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = s__1685000205__3; if linked_1063 == nil { vec__1685000215__4 = ifn_1064.Invoke_O__O(arg_1065) } else { vec__1685000215__4 = linked_1063.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1062, arg_1065) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000215__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000215__4, lang.RT_IntCast_J__I_NoInit(1), nil); var v__7 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__5, A_arbace_go_check_A_const_22); var tmp6 any; var and__1927000168__auto____8 any; var root_1066 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1068 lang.IFn

	if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = k__5; var arg_1070 any = A_arbace_go_check_A_const_47; if linked_1067 == nil { and__1927000168__auto____8 = ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { and__1927000168__auto____8 = linked_1067.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1071 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = n__6; var arg_1075 any = v__7; if linked_1072 == nil { tmp6 = ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { tmp6 = linked_1072.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) } } else { tmp6 = and__1927000168__auto____8 }
//line :248:1
	if jrt.J2g_Truth(tmp6) { var root_1076 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any; var tmp7 jrt.Number_I; var na_1081 any = n__6; var na_1082 any = v__7; var tmp8 bool; var tmp9 bool


		tmp9 = jrt.Long_InstanceOf(na_1081); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_1082) }; tmp8 = tmp9; if tmp8 { var n0_1083 int64 = jrt.NN(jrt.Long_Cast(na_1081)).LongValue__J(); var n1_1084 int64 = jrt.NN(jrt.Long_Cast(na_1082)).LongValue__J(); var nr_1085 int64 = n0_1083 - n1_1084; var tmp10 bool; var tmp11 bool; tmp11 = !(n1_1084 == -9223372036854775808); if tmp11 { tmp11 = (n0_1083^n1_1084)&(n0_1083^nr_1085) >= 0 }; tmp10 = tmp11; if tmp10 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1085)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1081, na_1082) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1081); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1082) }; tmp12 = tmp13; if tmp12 { var n0_1083_2 float64 = jrt.NN(jrt.Double_Cast(na_1081)).DoubleValue__D(); var n1_1084_2 float64 = jrt.NN(jrt.Double_Cast(na_1082)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1083_2 + -n1_1084_2)) } else { tmp7 = lang.Numbers_Minus_O_O__Number_NoInit(na_1081, na_1082) } }
//line :248:1
		arg_1079 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp7); var arg_1080 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1685000204); var tmp15 any; var root_1086 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = s__1685000205__3; if linked_1087 == nil { tmp15 = ifn_1088.Invoke_O__O(arg_1089) } else { tmp15 = linked_1087.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1086, arg_1089) }; arg_1080 = tmp14.Invoke_O__O(tmp15); if linked_1077 == nil { return ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { return linked_1077.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) } } else { var tmp16 any; var root_1090 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = s__1685000205__3; if linked_1091 == nil { tmp16 = ifn_1092.Invoke_O__O(arg_1093) } else { tmp16 = linked_1091.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1090, arg_1093) }; s__1685000205__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :248:1
func A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :248:1
func (t *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A) Ctor_O_O_I_O(c__verified, c__b__1685000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_verified = c__verified; t.F_b__1685000207 = c__b__1685000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :248:1
func (t *A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A) Invoke_O__O(self any) any { { var i__1685000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000211__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000206__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000211__2, lang.RT_IntCast_J__I_NoInit(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000211__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.RT_Get_O_O_O__O_NoInit(t.F_verified, k__3, A_arbace_go_check_A_const_22); var tmp2 any; var and__1927000168__auto____6 any; var root_1019 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1021 lang.IFn

	if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = k__3; var arg_1023 any = A_arbace_go_check_A_const_47; if linked_1020 == nil { and__1927000168__auto____6 = ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { and__1927000168__auto____6 = linked_1020.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1024 any = A_arbace_go_check_A_const_36.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = n__4; var arg_1028 any = v__5; if linked_1025 == nil { tmp2 = ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { tmp2 = linked_1025.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) } } else { tmp2 = and__1927000168__auto____6 }
//line :248:1
	if jrt.J2g_Truth(tmp2) { var root_1029 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = t.F_b__1685000207; var arg_1033 any; var tmp3 jrt.Number_I; var na_1034 any = n__4; var na_1035 any = v__5; var tmp4 bool; var tmp5 bool


		tmp5 = jrt.Long_InstanceOf(na_1034); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_1035) }; tmp4 = tmp5; if tmp4 { var n0_1036 int64 = jrt.NN(jrt.Long_Cast(na_1034)).LongValue__J(); var n1_1037 int64 = jrt.NN(jrt.Long_Cast(na_1035)).LongValue__J(); var nr_1038 int64 = n0_1036 - n1_1037; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_1037 == -9223372036854775808); if tmp7 { tmp7 = (n0_1036^n1_1037)&(n0_1036^nr_1038) >= 0 }; tmp6 = tmp7; if tmp6 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1038)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1034, na_1035) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_1034); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_1035) }; tmp8 = tmp9; if tmp8 { var n0_1036_2 float64 = jrt.NN(jrt.Double_Cast(na_1034)).DoubleValue__D(); var n1_1037_2 float64 = jrt.NN(jrt.Double_Cast(na_1035)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1036_2 + -n1_1037_2)) } else { tmp3 = lang.Numbers_Minus_O_O__Number_NoInit(na_1034, na_1035) } }
//line :248:1
		arg_1033 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp3); if linked_1030 == nil { ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { linked_1030.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) }; i__1685000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000206__1); continue L1 } else { i__1685000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000206__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A{}; t.Ctor_O(p0); return t }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A) Ctor_O(c__present any) { t.F_present = c__present }
//line :255:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A) Invoke_O_O__O(self, p1__1685000091_SHARP___1 any) any { var root_1133 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1137 any = p1__1685000091_SHARP___1; var arg_1138 any = t.F_present; if linked_1134 == nil { return ifn_1135.Invoke_O_O_O__O(arg_1136, arg_1137, arg_1138) } else { return linked_1134.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1133, arg_1136, arg_1137, arg_1138) } }
func A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A{}; t.Ctor_O(p0); return t }
//line :256:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A) Ctor_O(c__verified any) { t.F_verified = c__verified }
//line :256:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A) Invoke_O_O__O(self, p1__1685000092_SHARP___1 any) any { var root_1140 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1144 any = p1__1685000092_SHARP___1; var arg_1145 any = t.F_verified; if linked_1141 == nil { return ifn_1142.Invoke_O_O_O__O(arg_1143, arg_1144, arg_1145) } else { return linked_1141.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1140, arg_1143, arg_1144, arg_1145) } }
func A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A_New_O(p0 any) *A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A) Ctor_O(c__unver any) { t.F_unver = c__unver }
//line :257:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A) Invoke_O_O__O(self, p1__1685000093_SHARP___1 any) any { var root_1147 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_merge_with_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_1151 any = p1__1685000093_SHARP___1; var arg_1152 any = t.F_unver; if linked_1148 == nil { return ifn_1149.Invoke_O_O_O__O(arg_1150, arg_1151, arg_1152) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_merge_with_A).Invoke_O_O_O_O__O(root_1147, arg_1150, arg_1151, arg_1152) } }
func A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :258:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A) Ctor_O_O_O(c__form, c__unver, c__ds any) { t.F_form = c__form; t.F_unver = c__unver; t.F_ds = c__ds }
//line :258:1
func (t *A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A) Invoke_O_O__O(self, p1__1685000094_SHARP___1 any) any { var tmp1 any; var root_1154 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = t.F_unver; if linked_1155 == nil { tmp1 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp1 = linked_1155.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1154, arg_1157) }; if jrt.J2g_Truth(tmp1) { var root_1158 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = p1__1685000094_SHARP___1; var arg_1162 any; var tmp2 *lang.Keyword = A_arbace_go_check_A_const_70; var tmp3 *lang.Keyword = A_arbace_go_check_A_const_73; var tmp4 any; var root_1163 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1167 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = t.F_ds; if linked_1168 == nil { arg_1166 = ifn_1169.Invoke_O__O(arg_1170) } else { arg_1166 = linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) }; if linked_1164 == nil { tmp4 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp4 = linked_1164.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1163, arg_1166) }; var tmp5 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); var tmp6 any; var root_1171 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = t.F_form; if linked_1172 == nil { tmp6 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp6 = linked_1172.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_1171, arg_1174) }; arg_1162 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, t.F_unver); if linked_1159 == nil { return ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { return linked_1159.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } } else { return p1__1685000094_SHARP___1 } }











func A_arbace_go_check_check_package_fn__1685000233_A_New() *A_arbace_go_check_check_package_fn__1685000233_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_fn__1685000233_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_go_check_check_package_fn__1685000233_A) Ctor() {}
//line :270:1
func (t *A_arbace_go_check_check_package_fn__1685000233_A) Invoke_O_O__O(self, p1__1685000095_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_A_const_182; var tmp2 any; var root_2081 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = p1__1685000095_SHARP___1; if linked_2082 == nil { tmp2 = ifn_2083.Invoke_O__O(arg_2084) } else { tmp2 = linked_2082.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2081, arg_2084) }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_go_check_check_package_iter__1685000235__1685000239_A_New() *A_arbace_go_check_check_package_iter__1685000235__1685000239_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000235__1685000239_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_check_check_package_iter__1685000235__1685000239_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_check_check_package_iter__1685000235__1685000239_A) Invoke_O_O__O(self, s__1685000236__1 any) any { var tmp1 any = A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A_New_O_O(s__1685000236__1, self); var tmp2 *jrt.Class; var fncls__2165 *jrt.Class = A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A_fn_class; if fncls__2165 == nil { var fncls__2165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A_fn_class = fncls__2165d; tmp2 = fncls__2165d } else { tmp2 = fncls__2165 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :274:1
func A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A{}; t.Ctor_O_O(p0, p1); return t }
//line :274:1
func (t *A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A) Ctor_O_O(c__s__1685000236, c__iter__1685000235 any) { t.F_s__1685000236 = c__s__1685000236; t.F_iter__1685000235 = c__iter__1685000235 }
//line :274:1
func (t *A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A) Invoke_O__O(self any) any { { var s__1685000236__1 any; var t_ any = t.F_s__1685000236; t.F_s__1685000236 = nil; s__1685000236__1 = t_; for { var temp__1927000414__auto____2 any; var root_2090 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = s__1685000236__1; if linked_2091 == nil { temp__1927000414__auto____2 = ifn_2092.Invoke_O__O(arg_2093) } else { temp__1927000414__auto____2 = linked_2091.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2090, arg_2093) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000236__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2094 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = s__1685000236__3; if linked_2095 == nil { tmp1 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp1 = linked_2095.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2098 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = s__1685000236__3; if linked_2099 == nil { c__1927001037__auto____4 = ifn_2100.Invoke_O__O(arg_2101) } else { c__1927001037__auto____4 = linked_2099.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2098, arg_2101) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000238__6 any; var root_2102 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2103 == nil { b__1685000238__6 = ifn_2104.Invoke_O__O(arg_2105) } else { b__1685000238__6 = linked_2103.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2102, arg_2105) }; var tmp2 any = A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A_New_O_I_O(b__1685000238__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2120 *jrt.Class = A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A_fn_class; if fncls__2120 == nil { var fncls__2120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A_fn_class = fncls__2120d; tmp3 = fncls__2120d } else { tmp3 = fncls__2120 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2121 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any; var root_2126 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = b__1685000238__6; if linked_2127 == nil { arg_2124 = ifn_2128.Invoke_O__O(arg_2129) } else { arg_2124 = linked_2127.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2126, arg_2129) }; var arg_2125 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000235); var tmp5 any; var root_2130 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = s__1685000236__3; if linked_2131 == nil { tmp5 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp5 = linked_2131.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2130, arg_2133) }; arg_2125 = tmp4.Invoke_O__O(tmp5); if linked_2122 == nil { return ifn_2123.Invoke_O_O__O(arg_2124, arg_2125) } else { return linked_2122.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2121, arg_2124, arg_2125) } } else { var root_2134 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var root_2139 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = b__1685000238__6; if linked_2140 == nil { arg_2137 = ifn_2141.Invoke_O__O(arg_2142) } else { arg_2137 = linked_2140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2139, arg_2142) }; var arg_2138 any; if linked_2135 == nil { return ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { return linked_2135.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) } } } else { var d__4 any; var root_2143 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__1685000236__3; if linked_2144 == nil { d__4 = ifn_2145.Invoke_O__O(arg_2146) } else { d__4 = linked_2144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2143, arg_2146) }; var root_2147 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2152 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2154 lang.IFn
															if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any; var root_2157 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = d__4; if linked_2158 == nil { arg_2155 = ifn_2159.Invoke_O__O(arg_2160) } else { arg_2155 = linked_2158.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2157, arg_2160) }; var arg_2156 any = A_arbace_go_check_A_const_212; if linked_2153 == nil { arg_2150 = ifn_2154.Invoke_O_O__O(arg_2155, arg_2156) } else { arg_2150 = linked_2153.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2152, arg_2155, arg_2156) }
//line :274:1
	var arg_2151 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000235); var tmp7 any; var root_2161 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = s__1685000236__3; if linked_2162 == nil { tmp7 = ifn_2163.Invoke_O__O(arg_2164) } else { tmp7 = linked_2162.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2161, arg_2164) }; arg_2151 = tmp6.Invoke_O__O(tmp7); if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :274:1
func A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :274:1
func (t *A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A) Ctor_O_I_O(c__b__1685000238 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000238 = c__b__1685000238; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :274:1
func (t *A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A) Invoke_O__O(self any) any { { var i__1685000237__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000237__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000237__1)); var root_2106 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = t.F_b__1685000238; var arg_2110 any; var root_2111 any = A_arbace_go_check_A_const_210.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2113 lang.IFn
																	if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any; var root_2116 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = d__2; if linked_2117 == nil { arg_2114 = ifn_2118.Invoke_O__O(arg_2119) } else { arg_2114 = linked_2117.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2116, arg_2119) }; var arg_2115 any = A_arbace_go_check_A_const_211; if linked_2112 == nil { arg_2110 = ifn_2113.Invoke_O_O__O(arg_2114, arg_2115) } else { arg_2110 = linked_2112.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2111, arg_2114, arg_2115) }
//line :274:1
	if linked_2107 == nil { ifn_2108.Invoke_O_O__O(arg_2109, arg_2110) } else { linked_2107.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2106, arg_2109, arg_2110) }; i__1685000237__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000237__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_go_check_session_A_New() *A_arbace_go_check_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_session_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_check_session_A) Ctor() {}
//line :284:1
func (t *A_arbace_go_check_session_A) Invoke_O_O__O(self, resolve_src__0 any) any { var tmp1 any = A_arbace_go_check_A_const_218; var tmp2 any = A_arbace_go_check_A_const_219; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, resolve_src__0, tmp2, jrt.ConcurrentHashMap_New())) }







func A_arbace_go_check_resolver_A_New() *A_arbace_go_check_resolver_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_go_check_resolver_A) Ctor() {}
//line :292:1
func (t *A_arbace_go_check_resolver_A) Invoke_O_O_O_O__O(self, s__0, src__1, chain__2 any) any { var deps__4 any = jrt.HashMap_New(); var tmp1 any = A_arbace_go_check_resolver_fn__1685000247_A_New_O_O_O(src__1, s__0, chain__2); var tmp2 *jrt.Class; var fncls__2233 *jrt.Class = A_arbace_go_check_resolver_fn__1685000247_A_fn_class; _ = deps__4; if



	fncls__2233 == nil { var fncls__2233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_resolver_fn__1685000247_A_fn_class = fncls__2233d; tmp2 = fncls__2233d } else { tmp2 = fncls__2233 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :296:1
func A_arbace_go_check_resolver_fn__1685000247_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_resolver_fn__1685000247_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_resolver_fn__1685000247_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :296:1
func (t *A_arbace_go_check_resolver_fn__1685000247_A) Ctor_O_O_O(c__src, c__s, c__chain any) { t.F_src = c__src; t.F_s = c__s; t.F_chain = c__chain }
//line :296:1
func (t *A_arbace_go_check_resolver_fn__1685000247_A) Invoke_O_O_O__O(self, path__1, fi__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_120, path__1) { return A_arbace_go_check_A_const_220.GetRawRoot__O() } else { var lp__3 any; var root_2195 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2197 lang.IFn

		if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = t.F_src; var arg_2199 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_A_const_81, A_arbace_go_check_A_const_221, path__1); var arg_2200 any = path__1; if linked_2196 == nil { lp__3 = ifn_2197.Invoke_O_O_O__O(arg_2198, arg_2199, arg_2200) } else { lp__3 = linked_2196.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_2195, arg_2198, arg_2199, arg_2200) }
//line :297:1
		var p__4 any; var or__1927000174__auto____4 any; var root_2201 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2203 lang.IFn



		if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = t.F_s; var arg_2205 any = lp__3; var arg_2206 any = t.F_src; var arg_2207 any = t.F_chain; if linked_2202 == nil { or__1927000174__auto____4 = ifn_2203.Invoke_O_O_O_O__O(arg_2204, arg_2205, arg_2206, arg_2207) } else { or__1927000174__auto____4 = linked_2202.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2201, arg_2204, arg_2205, arg_2206, arg_2207) }; if jrt.J2g_Truth(or__1927000174__auto____4) { p__4 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp1 any; var and__1927000168__auto____5 any; var root_2208 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2210 lang.IFn
			if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any; var root_2212 any = A_arbace_go_check_A_const_223.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any; var root_2217 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any; var root_2221 any = A_arbace_go_check_A_const_224.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = lp__3; var arg_2225 any = A_arbace_go_check_A_const_225; if linked_2222 == nil { arg_2220 = ifn_2223.Invoke_O_O__O(arg_2224, arg_2225) } else { arg_2220 = linked_2222.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2221, arg_2224, arg_2225) }; if linked_2218 == nil { arg_2215 = ifn_2219.Invoke_O__O(arg_2220) } else { arg_2215 = linked_2218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2217, arg_2220) }; var arg_2216 any = Lit_121; if linked_2213 == nil { arg_2211 = ifn_2214.Invoke_O_O__O(arg_2215, arg_2216) } else { arg_2211 = linked_2213.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2212, arg_2215, arg_2216) }; if linked_2209 == nil { and__1927000168__auto____5 = ifn_2210.Invoke_O__O(arg_2211) } else { and__1927000168__auto____5 = linked_2209.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2208, arg_2211) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_FALSE.Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____5 = nil } else { or__1927000174__auto____5 = nil }
//line :301:1
			if jrt.J2g_Truth(or__1927000174__auto____5) { p__4 = or__1927000174__auto____5 } else {

				var root_2226 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = t.F_s; var arg_2230 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_122, nil), jrt.RefArrayOf(jrt.Object_class, nil, lp__3)).Ref(); var arg_2231 any = t.F_src; var arg_2232 any = t.F_chain; if linked_2227 == nil { p__4 = ifn_2228.Invoke_O_O_O_O__O(arg_2229, arg_2230, arg_2231, arg_2232) } else { p__4 = linked_2227.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2226, arg_2229, arg_2230, arg_2231, arg_2232) } } }
//line :297:1
		return p__4
	}
}






func A_arbace_go_check_ensure_package_A_New() *A_arbace_go_check_ensure_package_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_go_check_ensure_package_A) Ctor() {}
//line :306:1
func (t *A_arbace_go_check_ensure_package_A) Invoke_O_O_O_O_O__O(self, s__0, path__1, importer__2, chain__3 any) any {


	var tmp1 any; var root_2288 any = A_arbace_go_check_A_const_137.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, path__1)); var arg_2292 any = chain__3; if linked_2289 == nil { tmp1 = ifn_2290.Invoke_O_O__O(arg_2291, arg_2292) } else { tmp1 = linked_2289.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2288, arg_2291, arg_2292) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2293 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2295 lang.IFn
		if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil); var tmp4 any; var root_2298 any = A_arbace_go_check_A_const_233.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2300 lang.IFn; if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any = Lit_97; var arg_2302 any; var root_2303 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = chain__3; var arg_2307 any = path__1; if linked_2304 == nil { arg_2302 = ifn_2305.Invoke_O_O__O(arg_2306, arg_2307) } else { arg_2302 = linked_2304.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2303, arg_2306, arg_2307) }; if linked_2299 == nil { tmp4 = ifn_2300.Invoke_O_O__O(arg_2301, arg_2302) } else { tmp4 = linked_2299.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2298, arg_2301, arg_2302) }; arg_2296 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); var arg_2297 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104, path__1)); if linked_2294 == nil { tmp2 = ifn_2295.Invoke_O_O__O(arg_2296, arg_2297) } else { tmp2 = linked_2294.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2293, arg_2296, arg_2297) }
//line :309:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :306:1
	var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = A_arbace_go_check_A_const_226.Invoke_O__O(s__0)




	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2234 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = lang.IFn_Cast(A_arbace_go_check_A_const_227.Invoke_O__O(s__0)).Invoke_O__O(path__1); if linked_2235 == nil { and__1927000168__auto____6 = ifn_2236.Invoke_O__O(arg_2237) } else { and__1927000168__auto____6 = linked_2235.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2234, arg_2237) }; if jrt.J2g_Truth(and__1927000168__auto____6) { temp__1927000408__auto____5 = A_arbace_go_check_A_const_226.Invoke_O__O(s__0) } else { temp__1927000408__auto____5 = and__1927000168__auto____6 } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var d__6 any = temp__1927000408__auto____5; var root_2238 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2240 lang.IFn

		if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = d__6; var arg_2242 any = path__1; var arg_2243 any = importer__2; var arg_2244 any = chain__3; if linked_2239 == nil { return ifn_2240.Invoke_O_O_O_O__O(arg_2241, arg_2242, arg_2243, arg_2244) } else { return linked_2239.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2238, arg_2241, arg_2242, arg_2243, arg_2244) } } else {
//line :311:1
			var cache__6 any = A_arbace_go_check_A_const_219.Invoke_O__O(s__0); var p__7 any; var root_2245 any = A_arbace_go_check_A_const_228.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_promise_A_fn_class); var ifn_2247 lang.IFn



			if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; if linked_2246 == nil { p__7 = ifn_2247.Invoke__O() } else { p__7 = linked_2246.(*aot_arbace_core.A_arbace_core_promise_A).Invoke_O__O(root_2245) }
//line :311:1
			var prev__8 any = jrt.NN(jrt.ConcurrentHashMap_Cast(cache__6)).PutIfAbsent_O_O__O(path__1, p__7)





			if jrt.J2g_Truth(prev__8) { var root_2248 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = prev__8; if linked_2249 == nil { return ifn_2250.Invoke_O__O(arg_2251) } else { return linked_2249.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2248, arg_2251) } } else { var src__9 any = lang.IFn_Cast(A_arbace_go_check_A_const_218.Invoke_O__O(s__0)).Invoke_O_O__O(path__1, importer__2); var pkg__10 any; var tmp5 any
				var and__1927000168__auto____10 any = src__9

				if jrt.J2g_Truth(and__1927000168__auto____10) { var root_2252 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__9); if linked_2253 == nil { tmp5 = ifn_2254.Invoke_O__O(arg_2255) } else { tmp5 = linked_2253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2252, arg_2255) } } else { tmp5 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp5) {
					var tmp6 any = A_arbace_go_check_ensure_package_fn__1685000250_A_New_O_O_O_O_O(path__1, p__7, s__0, src__9, chain__3); var tmp7 *jrt.Class; var fncls__2287 *jrt.Class = A_arbace_go_check_ensure_package_fn__1685000250_A_fn_class; if fncls__2287 == nil { var fncls__2287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_go_check_ensure_package_fn__1685000250_A_fn_class = fncls__2287d; tmp7 = fncls__2287d } else { tmp7 = fncls__2287 }; pkg__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :320:1
						pkg__10 = nil
					}




				if jrt.J2g_Truth(pkg__10) { var tmp8 *lang.Volatile = lang.Volatile_Cast(pkg__10); var tmp9 any; var root_2308 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2310 lang.IFn; if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = jrt.NN(lang.Volatile_Cast(pkg__10)).Deref__O(); var arg_2312 any = A_arbace_go_check_A_const_234; var arg_2313 any; var root_2314 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2318 any; var tmp10 *lang.Keyword = A_arbace_go_check_A_const_235; var tmp11 any; var root_2319 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = pkg__10; var arg_2323 any = A_arbace_go_check_A_const_71; if linked_2320 == nil { tmp11 = ifn_2321.Invoke_O_O__O(arg_2322, arg_2323) } else { tmp11 = linked_2320.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2319, arg_2322, arg_2323) }; arg_2318 = tmp10.Invoke_O__O(tmp11); if linked_2315 == nil { arg_2313 = ifn_2316.Invoke_O_O__O(arg_2317, arg_2318) } else { arg_2313 = linked_2315.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2314, arg_2317, arg_2318) }; if linked_2309 == nil { tmp9 = ifn_2310.Invoke_O_O_O__O(arg_2311, arg_2312, arg_2313) } else { tmp9 = linked_2309.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2308, arg_2311, arg_2312, arg_2313) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
				var root_2324 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2324, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2326 lang.IFn; if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = p__7; var arg_2328 any = pkg__10; if linked_2325 == nil { ifn_2326.Invoke_O_O__O(arg_2327, arg_2328) } else { linked_2325.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2324, arg_2327, arg_2328) }
//line :317:1
				return pkg__10
			}
		}
}
func A_arbace_go_check_ensure_package_fn__1685000250_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_ensure_package_fn__1685000250_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_ensure_package_fn__1685000250_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :321:1
func (t *A_arbace_go_check_ensure_package_fn__1685000250_A) Ctor_O_O_O_O_O(c__path, c__p, c__s, c__src, c__chain any) { t.F_path = c__path; t.F_p = c__p; t.F_s = c__s; t.F_src = c__src; t.F_chain = c__chain }
//line :321:1
func (t *A_arbace_go_check_ensure_package_fn__1685000250_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_229.GetRawRoot__O()); var tmp3 any = t.F_src; var tmp4 any; var root_2261 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, A_arbace_go_check_resolver_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any; var t_ any = t.F_s; t.F_s = nil; arg_2264 = t_; var arg_2265 any; var t__2 any = t.F_src; t.F_src = nil; arg_2265 = t__2; var arg_2266 any; var root_2267 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_2268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2267, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2269 lang.IFn; if linked_2268 == nil { ifn_2269 = lang.IFn_Cast(root_2267) } else { ifn_2269 = nil }; var arg_2270 any; var root_2272 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any; var t__3 any = t.F_chain; t.F_chain = nil; arg_2275 = t__3; if linked_2273 == nil { arg_2270 = ifn_2274.Invoke_O__O(arg_2275) } else { arg_2270 = linked_2273.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2272, arg_2275) }; var arg_2271 any = t.F_path; if linked_2268 == nil { arg_2266 = ifn_2269.Invoke_O_O__O(arg_2270, arg_2271) } else { arg_2266 = linked_2268.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2267, arg_2270, arg_2271) }; if linked_2262 == nil { tmp4 = ifn_2263.Invoke_O_O_O__O(arg_2264, arg_2265, arg_2266) } else { tmp4 = linked_2262.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2261, arg_2264, arg_2265, arg_2266) }; tmp1 = tmp2.Invoke_O_O__O(tmp3, tmp4) }
//line :321:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_2282 any = A_arbace_go_check_A_const_232.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_deliver_A_fn_class); var ifn_2284 lang.IFn


		if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any; var t__4 any = t.F_p; t.F_p = nil; arg_2285 = t__4; var arg_2286 any; if linked_2283 == nil { ifn_2284.Invoke_O_O__O(arg_2285, arg_2286) } else { linked_2283.(*aot_arbace_core.A_arbace_core_deliver_A).Invoke_O_O_O__O(root_2282, arg_2285, arg_2286) }
//line :321:1
		var tmp6 any; var root_2276 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2278 lang.IFn



		if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var tmp7 any = t.F_path; var arg_2279 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, ex__3.GetMessage__String().Ref())).Ref(); var arg_2280 any; var tmp8 any = A_arbace_go_check_A_const_104; var tmp9 any; var t__5 any = t.F_path; t.F_path = nil; tmp9 = t__5; arg_2280 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)); var arg_2281 any = ex__3; if linked_2277 == nil { tmp6 = ifn_2278.Invoke_O_O_O__O(arg_2279, arg_2280, arg_2281) } else { tmp6 = linked_2277.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_2276, arg_2279, arg_2280, arg_2281) }
//line :321:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) } }; return tmp1 }












func A_arbace_go_check_corpus_config_A_New() *A_arbace_go_check_corpus_config_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_corpus_config_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_go_check_corpus_config_A) Ctor() {}
//line :334:1
func (t *A_arbace_go_check_corpus_config_A) Invoke_O_O__O(self, corpus__0 any) any { var G__1685000253__2_ any = corpus__0; switch
											lang.Util_Hash_O__I_NoInit(G__1685000253__2_) >> 2 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000253__2_, Lit_84) { var tmp1 any = A_arbace_go_check_A_const_236; var tmp2 any = A_arbace_go_check_A_const_238; var tmp3 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref()))); var tmp4 any = A_arbace_go_check_A_const_237; var tmp5 any = A_arbace_go_check_A_const_238; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_86), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_240, Lit_87)), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_241)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000253__2_, Lit_88) { var tmp6 any = A_arbace_go_check_A_const_236; var tmp7 any = A_arbace_go_check_A_const_238; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref()))); var tmp9 any = A_arbace_go_check_A_const_242; var tmp10 any = A_arbace_go_check_A_const_238; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_89), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_240, Lit_87)), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_243)) }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000253__2_, Lit_50) { var tmp11 any = A_arbace_go_check_A_const_236; var tmp12 any = A_arbace_go_check_A_const_238; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref(); var tmp14 any = A_arbace_go_check_A_const_247; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_91), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_244)) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000253__2_, Lit_92) { var tmp15 any = A_arbace_go_check_A_const_236; var tmp16 any = A_arbace_go_check_A_const_238; var tmp17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_90), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref(); var tmp18 any = A_arbace_go_check_A_const_247; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_245)) }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000253__2_, Lit_94) { var tmp19 any = A_arbace_go_check_A_const_236; var tmp20 any = A_arbace_go_check_A_const_238; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref()))), A_arbace_go_check_A_const_105, A_arbace_go_check_A_const_248)) }; default:}; var tmp21 any; var root_2330 any = A_arbace_go_check_A_const_231.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2332 lang.IFn; if












	linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, nil, corpus__0)).Ref(); var arg_2334 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_246, corpus__0)); if linked_2331 == nil { tmp21 = ifn_2332.Invoke_O_O__O(arg_2333, arg_2334) } else { tmp21 = linked_2331.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2330, arg_2333, arg_2334) }; /*line :335:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp21))) }














func A_arbace_go_check_std_session_A_New() *A_arbace_go_check_std_session_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_go_check_std_session_A) Ctor() {}
//line :350:1
func (t *A_arbace_go_check_std_session_A) Invoke_O_O__O(self, p__1685000256__0 any) any { var map__1685000257__2 any = p__1685000256__0; var map__1685000257__3 any; if lang.ISeq_InstanceOf(map__1685000257__2) { var tmp1 any; var root_2335 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = map__1685000257__2; if linked_2336 == nil { tmp1 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp1 = linked_2336.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2335, arg_2338) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2339 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = map__1685000257__2; if linked_2340 == nil { tmp2 = ifn_2341.Invoke_O__O(arg_2342) } else { tmp2 = linked_2340.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2339, arg_2342) }; map__1685000257__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2343 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = map__1685000257__2; if linked_2344 == nil { tmp3 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp3 = linked_2344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2343, arg_2346) }; if jrt.J2g_Truth(tmp3) { var root_2347 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = map__1685000257__2; if linked_2348 == nil { map__1685000257__3 = ifn_2349.Invoke_O__O(arg_2350) } else { map__1685000257__3 = linked_2348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2347, arg_2350) } } else { map__1685000257__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000257__3 = map__1685000257__2 }; var roots__4 any = lang.RT_Get_O_O__O_NoInit(map__1685000257__3, A_arbace_go_check_A_const_236); var config__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000257__3, A_arbace_go_check_A_const_105); var root_2351 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_2352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2351, A_arbace_go_check_session_A_fn_class); var ifn_2353 lang.IFn; if
											linked_2352 == nil { ifn_2353 = lang.IFn_Cast(root_2351) } else { ifn_2353 = nil }; var arg_2354 any; var tmp4 any = A_arbace_go_check_std_session_fn__1685000259_A_New_O_O(roots__4, config__5); var tmp5 *jrt.Class; var fncls__2367 *jrt.Class = A_arbace_go_check_std_session_fn__1685000259_A_fn_class; if fncls__2367 == nil { var fncls__2367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_go_check_std_session_fn__1685000259_A_fn_class = fncls__2367d; tmp5 = fncls__2367d } else { tmp5 = fncls__2367 }; arg_2354 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_2352 == nil { return ifn_2353.Invoke_O__O(arg_2354) } else { return linked_2352.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2351, arg_2354) } }
//line :351:1
func A_arbace_go_check_std_session_fn__1685000259_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000259_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000259_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_go_check_std_session_fn__1685000259_A) Ctor_O_O(c__roots, c__config any) { t.F_roots = c__roots; t.F_config = c__config }
//line :351:1
func (t *A_arbace_go_check_std_session_fn__1685000259_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any {
	var root_2355 any = A_arbace_go_check_A_const_137.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any; var tmp1 any = A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A_New_O_O(path__1, t.F_config); var tmp2 *jrt.Class; var fncls__2366 *jrt.Class = A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A_fn_class; if fncls__2366 == nil { var fncls__2366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A_fn_class = fncls__2366d; tmp2 = fncls__2366d } else { tmp2 = fncls__2366 }; arg_2358 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2359 any = t.F_roots; if linked_2356 == nil { return ifn_2357.Invoke_O_O__O(arg_2358, arg_2359) } else { return linked_2356.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2355, arg_2358, arg_2359) } }
//line :352:1
func A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A_New_O_O(p0, p1 any) *A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A) Ctor_O_O(c__path, c__config any) { t.F_path = c__path; t.F_config = c__config }
//line :352:1
func (t *A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A) Invoke_O_O__O(self, p1__1685000255_SHARP___1 any) any { var root_2360 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2362 lang.IFn; if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any = p1__1685000255_SHARP___1; var arg_2364 any = t.F_path; var arg_2365 any = t.F_config; if linked_2361 == nil { return ifn_2362.Invoke_O_O_O__O(arg_2363, arg_2364, arg_2365) } else { return linked_2361.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O__O(root_2360, arg_2363, arg_2364, arg_2365) } }





func A_arbace_go_check_run_parallel_A_New() *A_arbace_go_check_run_parallel_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_A{}; t.Ctor(); return t }
//line :358:1
func (t *A_arbace_go_check_run_parallel_A) Ctor() {}
//line :358:1
func (t *A_arbace_go_check_run_parallel_A) Invoke_O_O_O_O__O(self, n__0, f__1, xs__2 any) any { var xs__4 any; var root_2368 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2370 lang.IFn; if


	linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = xs__2; if linked_2369 == nil { xs__4 = ifn_2370.Invoke_O__O(arg_2371) } else { xs__4 = linked_2369.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2368, arg_2371) }; var q__5 any = /*line :358:1*/jrt.AtomicLong_New_J(0); var out__6 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(xs__4)).Ref()).Ref(); var workers__7 any; var root_2372 any = A_arbace_go_check_A_const_251.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_2374 lang.IFn; if





	linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A_New_O_O_O_O(f__1, out__6, q__5, xs__4); var tmp2 *jrt.Class; var fncls__2444 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A_fn_class; if fncls__2444 == nil { var fncls__2444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A_fn_class = fncls__2444d; tmp2 = fncls__2444d } else { tmp2 = fncls__2444 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp4 any; var root_2445 any = A_arbace_go_check_A_const_255.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = n__0; if linked_2446 == nil { tmp4 = ifn_2447.Invoke_O__O(arg_2448) } else { tmp4 = linked_2446.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2445, arg_2448) }; arg_2375 = tmp3.Invoke_O__O(tmp4); if linked_2373 == nil { workers__7 = ifn_2374.Invoke_O__O(arg_2375) } else { workers__7 = linked_2373.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_2372, arg_2375) }; var seq_1685000278__8 any; var root_2453 any = /*line :358:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2455 lang.IFn; if















	linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = workers__7; if linked_2454 == nil { seq_1685000278__8 = ifn_2455.Invoke_O__O(arg_2456) } else { seq_1685000278__8 = linked_2454.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2453, arg_2456) }; var chunk_1685000279__9 any; var count_1685000280__10 int64 = 0; var i_1685000281__11 int64 = 0; L1:
//line :358:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000281__11, count_1685000280__10) { var w__12 any = lang.Indexed_Cast(chunk_1685000279__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000281__11)); var root_2473 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2475 lang.IFn; if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = w__12; if linked_2474 == nil { ifn_2475.Invoke_O__O(arg_2476) } else { linked_2474.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2473, arg_2476) }; seq_1685000278__8, chunk_1685000279__9, count_1685000280__10, i_1685000281__11 = seq_1685000278__8, chunk_1685000279__9, count_1685000280__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000281__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_2457 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2459 lang.IFn; if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = seq_1685000278__8; if linked_2458 == nil { temp__1927000414__auto____12 = ifn_2459.Invoke_O__O(arg_2460) } else { temp__1927000414__auto____12 = linked_2458.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2457, arg_2460) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1685000278__13 any = temp__1927000414__auto____12; var tmp5 any; var root_2461 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = seq_1685000278__13; if linked_2462 == nil { tmp5 = ifn_2463.Invoke_O__O(arg_2464) } else { tmp5 = linked_2462.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2461, arg_2464) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____14 any; var root_2465 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2465, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2467 lang.IFn; if linked_2466 == nil { ifn_2467 = lang.IFn_Cast(root_2465) } else { ifn_2467 = nil }; var arg_2468 any = seq_1685000278__13; if linked_2466 == nil { c__1927000678__auto____14 = ifn_2467.Invoke_O__O(arg_2468) } else { c__1927000678__auto____14 = linked_2466.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2465, arg_2468) }; var tmp6 any; var root_2477 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = seq_1685000278__13; if linked_2478 == nil { tmp6 = ifn_2479.Invoke_O__O(arg_2480) } else { tmp6 = linked_2478.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2477, arg_2480) }; seq_1685000278__8, chunk_1685000279__9, count_1685000280__10, i_1685000281__11 = tmp6, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__14 any; var root_2469 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2471 lang.IFn; if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = seq_1685000278__13; if linked_2470 == nil { w__14 = ifn_2471.Invoke_O__O(arg_2472) } else { w__14 = linked_2470.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2469, arg_2472) }; var root_2481 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = w__14; if linked_2482 == nil { ifn_2483.Invoke_O__O(arg_2484) } else { linked_2482.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2481, arg_2484) }; var tmp7 any; var root_2485 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = seq_1685000278__13; if linked_2486 == nil { tmp7 = ifn_2487.Invoke_O__O(arg_2488) } else { tmp7 = linked_2486.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2485, arg_2488) }; seq_1685000278__8, chunk_1685000279__9, count_1685000280__10, i_1685000281__11 = tmp7, nil, 0, 0; continue L1 } } }
//line :358:1
		break L1 }; var root_2449 any =
















	A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2451 lang.IFn; if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = out__6; if linked_2450 == nil { return ifn_2451.Invoke_O__O(arg_2452) } else { return linked_2450.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2449, arg_2452) } }
//line :364:1
func A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :364:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :364:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A) Invoke_O_O__O(self, s__1685000265__1 any) any { var tmp1 any = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A_New_O_O_O_O_O_O(t.F_f, t.F_out, t.F_q, s__1685000265__1, t.F_xs, self); var tmp2 *jrt.Class; var fncls__2443 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A_fn_class; if fncls__2443 == nil { var fncls__2443d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A_fn_class = fncls__2443d; tmp2 = fncls__2443d } else { tmp2 = fncls__2443 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :364:1
func A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :364:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A) Ctor_O_O_O_O_O_O(c__f, c__out, c__q, c__s__1685000265, c__xs, c__iter__1685000264 any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_s__1685000265 = c__s__1685000265; t.F_xs = c__xs; t.F_iter__1685000264 = c__iter__1685000264 }
//line :364:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A) Invoke_O__O(self any) any { { var s__1685000265__1 any; var t_ any = t.F_s__1685000265; t.F_s__1685000265 = nil; s__1685000265__1 = t_; for { var temp__1927000414__auto____2 any; var root_2376 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = s__1685000265__1; if linked_2377 == nil { temp__1927000414__auto____2 = ifn_2378.Invoke_O__O(arg_2379) } else { temp__1927000414__auto____2 = linked_2377.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2376, arg_2379) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000265__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2380 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = s__1685000265__3; if linked_2381 == nil { tmp1 = ifn_2382.Invoke_O__O(arg_2383) } else { tmp1 = linked_2381.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2380, arg_2383) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2384 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2386 lang.IFn; if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = s__1685000265__3; if linked_2385 == nil { c__1927001037__auto____4 = ifn_2386.Invoke_O__O(arg_2387) } else { c__1927001037__auto____4 = linked_2385.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2384, arg_2387) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000267__6 any; var root_2388 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2389 == nil { b__1685000267__6 = ifn_2390.Invoke_O__O(arg_2391) } else { b__1685000267__6 = linked_2389.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2388, arg_2391) }; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A_New_O_O_O_O_O_I_O(b__1685000267__6, t.F_f, t.F_out, t.F_q, t.F_xs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2402 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A_fn_class; if fncls__2402 == nil { var fncls__2402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A_fn_class = fncls__2402d; tmp3 = fncls__2402d } else { tmp3 = fncls__2402 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2403 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any; var root_2408 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any = b__1685000267__6; if linked_2409 == nil { arg_2406 = ifn_2410.Invoke_O__O(arg_2411) } else { arg_2406 = linked_2409.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2408, arg_2411) }; var arg_2407 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000264); var tmp5 any; var root_2412 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = s__1685000265__3; if linked_2413 == nil { tmp5 = ifn_2414.Invoke_O__O(arg_2415) } else { tmp5 = linked_2413.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2412, arg_2415) }; arg_2407 = tmp4.Invoke_O__O(tmp5); if linked_2404 == nil { return ifn_2405.Invoke_O_O__O(arg_2406, arg_2407) } else { return linked_2404.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2403, arg_2406, arg_2407) } } else { var root_2416 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2418 lang.IFn; if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any; var root_2421 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2423 lang.IFn; if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = b__1685000267__6; if linked_2422 == nil { arg_2419 = ifn_2423.Invoke_O__O(arg_2424) } else { arg_2419 = linked_2422.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2421, arg_2424) }; var arg_2420 any; if linked_2417 == nil { return ifn_2418.Invoke_O_O__O(arg_2419, arg_2420) } else { return linked_2417.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2416, arg_2419, arg_2420) } } } else { var ___4 any; var root_2425 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2427 lang.IFn; _ = ___4; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = s__1685000265__3; if linked_2426 == nil { ___4 = ifn_2427.Invoke_O__O(arg_2428) } else { ___4 = linked_2426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2425, arg_2428) }; var root_2429 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any; var root_2434 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_2435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2434, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2436 lang.IFn
															if linked_2435 == nil { ifn_2436 = lang.IFn_Cast(root_2434) } else { ifn_2436 = nil }; var arg_2437 any; var tmp6 any = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp7 *jrt.Class; var fncls__2438 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A_fn_class; if fncls__2438 == nil { var fncls__2438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A_fn_class = fncls__2438d; tmp7 = fncls__2438d } else { tmp7 = fncls__2438 }; arg_2437 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2435 == nil { arg_2432 = ifn_2436.Invoke_O__O(arg_2437) } else { arg_2432 = linked_2435.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2434, arg_2437) }
//line :364:1
	var arg_2433 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000264); var tmp9 any; var root_2439 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = s__1685000265__3; if linked_2440 == nil { tmp9 = ifn_2441.Invoke_O__O(arg_2442) } else { tmp9 = linked_2440.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2439, arg_2442) }; arg_2433 = tmp8.Invoke_O__O(tmp9); if linked_2430 == nil { return ifn_2431.Invoke_O_O__O(arg_2432, arg_2433) } else { return linked_2430.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2429, arg_2432, arg_2433) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :364:1
func A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :364:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A) Ctor_O_O_O_O_O_I_O(c__b__1685000267, c__f, c__out, c__q, c__xs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000267 = c__b__1685000267; t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :364:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A) Invoke_O__O(self any) any { { var i__1685000266__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000266__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000266__1)); var root_2392 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2392, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2394 lang.IFn; _ = ___2; if linked_2393 == nil { ifn_2394 = lang.IFn_Cast(root_2392) } else { ifn_2394 = nil }; var arg_2395 any = t.F_b__1685000267; var arg_2396 any; var root_2397 any = A_arbace_go_check_A_const_252.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2399 lang.IFn
																if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any; var tmp2 any = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A_New_O_O_O_O(t.F_f, t.F_out, t.F_q, t.F_xs); var tmp3 *jrt.Class; var fncls__2401 *jrt.Class = A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A_fn_class; if fncls__2401 == nil { var fncls__2401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A_fn_class = fncls__2401d; tmp3 = fncls__2401d } else { tmp3 = fncls__2401 }; arg_2400 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2398 == nil { arg_2396 = ifn_2399.Invoke_O__O(arg_2400) } else { arg_2396 = linked_2398.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2397, arg_2400) }
//line :364:1
	if linked_2393 == nil { ifn_2394.Invoke_O_O__O(arg_2395, arg_2396) } else { linked_2393.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2392, arg_2395, arg_2396) }; i__1685000266__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000266__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :365:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_253.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_253.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_254) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_253.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_253.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :368:1
			return nil } } }; /*line :365:1*/panic("j2g: unreachable") }
//line :365:1
func A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A) Ctor_O_O_O_O(c__f, c__out, c__q, c__xs any) { t.F_f = c__f; t.F_out = c__out; t.F_q = c__q; t.F_xs = c__xs }
//line :365:1
func (t *A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A) Invoke_O__O(self any) any { for { L2: for { var i__1 int64 = jrt.NN(jrt.AtomicLong_Cast(t.F_q)).GetAndIncrement__J()


	if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_xs))) { var t0__2 int64 = jrt.System_NanoTime__J()

		if jrt.J2g_Truth(A_arbace_go_check_A_const_253.Get__O()) { var tmp1 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_253.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)), A_arbace_go_check_A_const_254) }
		var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_out, jrt.Object_class.ArrayClass()); var tmp3 lang.IFn = lang.IFn_Cast(t.F_f); var tmp4 any = t.F_xs; lang.RT_Aset_O1_I_O__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(i__1), tmp3.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(i__1))))
		if jrt.J2g_Truth(A_arbace_go_check_A_const_253.Get__O()) { var tmp5 any = t.F_xs; lang.IFn_Cast(A_arbace_go_check_A_const_253.Get__O()).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(i__1)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000)).Ref()) }
		continue L2 } else {
//line :368:1
			return nil } } }; /*line :365:1*/panic("j2g: unreachable") }











func A_arbace_go_check_result_of_A_New() *A_arbace_go_check_result_of_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_result_of_A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_go_check_result_of_A) Ctor() {}
//line :377:1
func (t *A_arbace_go_check_result_of_A) Invoke_O_O__O(self, pkg__0 any) any { if jrt.J2g_Truth(pkg__0) { var root_2489 any = A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_2491 lang.IFn; if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = pkg__0; var arg_2493 any = A_arbace_go_check_A_const_201; if linked_2490 == nil { return ifn_2491.Invoke_O_O__O(arg_2492, arg_2493) } else { return linked_2490.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_2489, arg_2492, arg_2493) } } else { return nil } }

func A_arbace_go_check_error_result_A_New() *A_arbace_go_check_error_result_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_error_result_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_go_check_error_result_A) Ctor() {}
//line :379:1
func (t *A_arbace_go_check_error_result_A) Invoke_O_O_O__O(self, what__0, ex__1 any) any { var tmp1 any = A_arbace_go_check_A_const_104; var tmp2 any = A_arbace_go_check_A_const_202; var tmp3 any = A_arbace_go_check_A_const_73; var tmp4 any = A_arbace_go_check_A_const_78; var tmp5 any = A_arbace_go_check_A_const_22; var tmp6 any = A_arbace_go_check_A_const_257; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_101, nil, nil); var tmp8 any = jrt.Throwable_Cast(ex__1).GetMessage__String().Ref(); var tmp9 *jrt.String; var temp__1927000414__auto____6 any = jrt.Throwable_Cast(ex__1).GetCause__Throwable(); if

	jrt.J2g_Truth(temp__1927000414__auto____6) { var c__7 any = temp__1927000414__auto____6; tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(c__7).GetMessage__String().Ref())) } else { tmp9 = nil }; return /*line :379:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, what__0, tmp2, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, what__0, tmp4, tmp5, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Ref())).Ref(), A_arbace_go_check_A_const_258, A_arbace_go_check_A_const_259))), A_arbace_go_check_A_const_150, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_82, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_140, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_142, A_arbace_go_check_A_const_22, A_arbace_go_check_A_const_151, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_127, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_152, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_143, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_133, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_check_A_const_256, jrt.Boolean_TRUE.Ref())) }






func A_arbace_go_check_check_corpus_A_New() *A_arbace_go_check_check_corpus_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_go_check_check_corpus_A) Ctor() {}
//line :386:1
func (t *A_arbace_go_check_check_corpus_A) Invoke_O_O_O__O(self, corpus__0, jobs__1 any) any { var cc__3 any; var root_2494 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, A_arbace_go_check_corpus_config_A_fn_class); var ifn_2496 lang.IFn; if


	linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = corpus__0; if linked_2495 == nil { cc__3 = ifn_2496.Invoke_O__O(arg_2497) } else { cc__3 = linked_2495.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_2494, arg_2497) }; var s__4 any; var root_2498 any = /*line :386:1*/A_arbace_go_check_A_const_261.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, A_arbace_go_check_std_session_A_fn_class); var ifn_2500 lang.IFn; if



	linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = cc__3; if linked_2499 == nil { s__4 = ifn_2500.Invoke_O__O(arg_2501) } else { s__4 = linked_2499.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_2498, arg_2501) }; var std_pkgs__5 any; var tmp1 any; var or__1927000174__auto____5 any = /*line :386:1*/A_arbace_go_check_A_const_242.Invoke_O__O(cc__3); if





	jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = A_arbace_go_check_A_const_237.Invoke_O__O(cc__3) }; if jrt.J2g_Truth(tmp1) { std_pkgs__5 = nil } else { var root__5 any; var root_2502 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2504 lang.IFn
		if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any = A_arbace_go_check_A_const_236.Invoke_O__O(cc__3); if linked_2503 == nil { root__5 = ifn_2504.Invoke_O__O(arg_2505) } else { root__5 = linked_2503.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2502, arg_2505) }
		var root_2506 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any; var iter__1927001039__auto____6 any; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A_New(); var tmp3 *jrt.Class; var fncls__2576 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A_fn_class; if fncls__2576 == nil { var fncls__2576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A_fn_class = fncls__2576d; tmp3 = fncls__2576d } else { tmp3 = fncls__2576 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp5 any; var root_2577 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2577, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2579 lang.IFn; if linked_2578 == nil { ifn_2579 = lang.IFn_Cast(root_2577) } else { ifn_2579 = nil }; var arg_2580 any = root__5; var arg_2581 any = Lit_32; if linked_2578 == nil { tmp5 = ifn_2579.Invoke_O_O__O(arg_2580, arg_2581) } else { tmp5 = linked_2578.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2577, arg_2580, arg_2581) }; arg_2509 = tmp4.Invoke_O__O(tmp5); if linked_2507 == nil { std_pkgs__5 = ifn_2508.Invoke_O__O(arg_2509) } else { std_pkgs__5 = linked_2507.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2506, arg_2509) } }; if

	jrt.J2g_Truth(std_pkgs__5) {

		var root_2582 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2582, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2584 lang.IFn; if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = jobs__1; var arg_2586 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000296_A_New_O(s__4); var tmp7 *jrt.Class; var fncls__2604 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000296_A_fn_class
		if fncls__2604 == nil { var fncls__2604d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_check_corpus_fn__1685000296_A_fn_class = fncls__2604d; tmp7 = fncls__2604d } else { tmp7 = fncls__2604 }; arg_2586 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :398:1
		var arg_2587 any = std_pkgs__5; if linked_2583 == nil { return ifn_2584.Invoke_O_O_O__O(arg_2585, arg_2586, arg_2587) } else { return linked_2583.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2582, arg_2585, arg_2586, arg_2587) } } else {
//line :396:1
			if jrt.J2g_Truth(A_arbace_go_check_A_const_242.Invoke_O__O(cc__3)) { var map__1685000298__6 any = A_arbace_go_check_A_const_242.Invoke_O__O(cc__3); var map__1685000298__7 any








				if lang.ISeq_InstanceOf(map__1685000298__6) { var tmp8 any; var root_2605 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = map__1685000298__6; if linked_2606 == nil { tmp8 = ifn_2607.Invoke_O__O(arg_2608) } else { tmp8 = linked_2606.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2605, arg_2608) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2609 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2609, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2611 lang.IFn; if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = map__1685000298__6; if linked_2610 == nil { tmp9 = ifn_2611.Invoke_O__O(arg_2612) } else { tmp9 = linked_2610.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2609, arg_2612) }; map__1685000298__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp9, jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 any; var root_2613 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = map__1685000298__6; if linked_2614 == nil { tmp10 = ifn_2615.Invoke_O__O(arg_2616) } else { tmp10 = linked_2614.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2613, arg_2616) }; if jrt.J2g_Truth(tmp10) { var root_2617 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2619 lang.IFn; if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = map__1685000298__6; if linked_2618 == nil { map__1685000298__7 = ifn_2619.Invoke_O__O(arg_2620) } else { map__1685000298__7 = linked_2618.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2617, arg_2620) } } else { map__1685000298__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000298__7 = map__1685000298__6 }
//line :396:1
				var dir__8 any = lang.RT_Get_O_O__O_NoInit(map__1685000298__7, A_arbace_go_check_A_const_238); var sub__9 any = lang.RT_Get_O_O__O_NoInit(map__1685000298__7, A_arbace_go_check_A_const_240); var root__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_238, dir__8)); var root_2621 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2623 lang.IFn










				if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = jobs__1; var arg_2625 any; var tmp11 any = A_arbace_go_check_check_corpus_fn__1685000300_A_New_O_O_O_O(dir__8, s__4, root__10, cc__3); var tmp12 *jrt.Class; var fncls__2669 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000300_A_fn_class
				if fncls__2669 == nil { var fncls__2669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_check_corpus_fn__1685000300_A_fn_class = fncls__2669d; tmp12 = fncls__2669d } else { tmp12 = fncls__2669 }; arg_2625 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)
//line :407:1
				var arg_2626 any; var root_2670 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2672 lang.IFn








				if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = root__10; var arg_2674 any = sub__9; if linked_2671 == nil { arg_2626 = ifn_2672.Invoke_O_O__O(arg_2673, arg_2674) } else { arg_2626 = linked_2671.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2670, arg_2673, arg_2674) }
//line :407:1
				if linked_2622 == nil { return ifn_2623.Invoke_O_O_O__O(arg_2624, arg_2625, arg_2626) } else { return linked_2622.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2621, arg_2624, arg_2625, arg_2626) } } else {
//line :396:1
					if jrt.J2g_Truth(A_arbace_go_check_A_const_237.Invoke_O__O(cc__3)) { var map__1685000302__6 any = A_arbace_go_check_A_const_237.Invoke_O__O(cc__3); var map__1685000302__7 any





















						if lang.ISeq_InstanceOf(map__1685000302__6) { var tmp13 any; var root_2675 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any = map__1685000302__6; if linked_2676 == nil { tmp13 = ifn_2677.Invoke_O__O(arg_2678) } else { tmp13 = linked_2676.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2675, arg_2678) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_2679 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any = map__1685000302__6; if linked_2680 == nil { tmp14 = ifn_2681.Invoke_O__O(arg_2682) } else { tmp14 = linked_2680.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2679, arg_2682) }; map__1685000302__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp14, jrt.Object_class.ArrayClass())).Ref() } else { var tmp15 any; var root_2683 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2685 lang.IFn; if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any = map__1685000302__6; if linked_2684 == nil { tmp15 = ifn_2685.Invoke_O__O(arg_2686) } else { tmp15 = linked_2684.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2683, arg_2686) }; if jrt.J2g_Truth(tmp15) { var root_2687 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = map__1685000302__6; if linked_2688 == nil { map__1685000302__7 = ifn_2689.Invoke_O__O(arg_2690) } else { map__1685000302__7 = linked_2688.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2687, arg_2690) } } else { map__1685000302__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000302__7 = map__1685000302__6 }
//line :396:1
						var dir__8_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000302__7, A_arbace_go_check_A_const_238); var sub__9_2 any = lang.RT_Get_O_O__O_NoInit(map__1685000302__7, A_arbace_go_check_A_const_240); var root__10_2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_238, dir__8_2)); var pfs__11 any; var root_2691 any = A_arbace_go_check_A_const_263.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A_fn_class); var ifn_2693 lang.IFn























						if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = root__10_2; var arg_2695 any = sub__9_2; if linked_2692 == nil { pfs__11 = ifn_2693.Invoke_O_O__O(arg_2694, arg_2695) } else { pfs__11 = linked_2692.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A).Invoke_O_O_O__O(root_2691, arg_2694, arg_2695) }
//line :396:1
						var tests__12 any; var root_2696 any = A_arbace_go_check_A_const_270.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2698 lang.IFn

























						if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any; var tmp16 any = A_arbace_go_check_check_corpus_fn__1685000304_A_New(); var tmp17 *jrt.Class; var fncls__2706 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000304_A_fn_class; if fncls__2706 == nil { var fncls__2706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_check_corpus_fn__1685000304_A_fn_class = fncls__2706d; tmp17 = fncls__2706d } else { tmp17 = fncls__2706 }; arg_2699 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_2700 any = pfs__11; if linked_2697 == nil { tests__12 = ifn_2698.Invoke_O_O__O(arg_2699, arg_2700) } else { tests__12 = linked_2697.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2696, arg_2699, arg_2700)
						}


						var root_2707 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any; var root_2711 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var arg_2715 any; var root_2716 any = A_arbace_go_check_A_const_264.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, A_arbace_go_check_run_parallel_A_fn_class); var ifn_2718 lang.IFn
						if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = jobs__1; var arg_2720 any; var tmp18 any = A_arbace_go_check_check_corpus_fn__1685000310_A_New_O_O_O_O(dir__8_2, s__4, root__10_2, cc__3); var tmp19 *jrt.Class; var fncls__2949 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class
						if fncls__2949 == nil { var fncls__2949d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class = fncls__2949d; tmp19 = fncls__2949d } else { tmp19 = fncls__2949 }; arg_2720 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :427:1
						var arg_2721 any; var root_2950 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_2951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2950, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2952 lang.IFn














						if linked_2951 == nil { ifn_2952 = lang.IFn_Cast(root_2950) } else { ifn_2952 = nil }; var arg_2953 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var arg_2954 any = tests__12; if linked_2951 == nil { arg_2721 = ifn_2952.Invoke_O_O__O(arg_2953, arg_2954) } else { arg_2721 = linked_2951.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2950, arg_2953, arg_2954) }
//line :427:1
						if linked_2717 == nil { arg_2715 = ifn_2718.Invoke_O_O_O__O(arg_2719, arg_2720, arg_2721) } else { arg_2715 = linked_2717.(*A_arbace_go_check_run_parallel_A).Invoke_O_O_O_O__O(root_2716, arg_2719, arg_2720, arg_2721) }
//line :426:1
						if linked_2712 == nil { arg_2710 = ifn_2713.Invoke_O_O__O(arg_2714, arg_2715) } else { arg_2710 = linked_2712.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2711, arg_2714, arg_2715) }; if linked_2708 == nil { return ifn_2709.Invoke_O__O(arg_2710) } else { return linked_2708.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2707, arg_2710) } } else {
//line :396:1
							return nil } } } }
//line :394:1
func A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A_New() *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A{}; t.Ctor(); return t }
//line :394:1
func (t *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A) Ctor() {}
//line :394:1
func (t *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A) Invoke_O_O__O(self, s__1685000287__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A_New_O_O(s__1685000287__1, self); var tmp2 *jrt.Class; var fncls__2575 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A_fn_class; if fncls__2575 == nil { var fncls__2575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A_fn_class = fncls__2575d; tmp2 = fncls__2575d } else { tmp2 = fncls__2575 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :394:1
func A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A{}; t.Ctor_O_O(p0, p1); return t }
//line :394:1
func (t *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A) Ctor_O_O(c__s__1685000287, c__iter__1685000286 any) { t.F_s__1685000287 = c__s__1685000287; t.F_iter__1685000286 = c__iter__1685000286 }
//line :394:1
func (t *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A) Invoke_O__O(self any) any { { var s__1685000287__1 any; var t_ any = t.F_s__1685000287; t.F_s__1685000287 = nil; s__1685000287__1 = t_; for { var temp__1927000414__auto____2 any; var root_2510 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2512 lang.IFn; if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = s__1685000287__1; if linked_2511 == nil { temp__1927000414__auto____2 = ifn_2512.Invoke_O__O(arg_2513) } else { temp__1927000414__auto____2 = linked_2511.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2510, arg_2513) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000287__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2514 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = s__1685000287__3; if linked_2515 == nil { tmp1 = ifn_2516.Invoke_O__O(arg_2517) } else { tmp1 = linked_2515.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2514, arg_2517) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2518 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = s__1685000287__3; if linked_2519 == nil { c__1927001037__auto____4 = ifn_2520.Invoke_O__O(arg_2521) } else { c__1927001037__auto____4 = linked_2519.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2518, arg_2521) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000289__6 any; var root_2522 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2522, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2524 lang.IFn; if linked_2523 == nil { ifn_2524 = lang.IFn_Cast(root_2522) } else { ifn_2524 = nil }; var arg_2525 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2523 == nil { b__1685000289__6 = ifn_2524.Invoke_O__O(arg_2525) } else { b__1685000289__6 = linked_2523.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2522, arg_2525) }; var tmp2 any = A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A_New_O_I_O(b__1685000289__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2535 *jrt.Class = A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A_fn_class; if fncls__2535 == nil { var fncls__2535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A_fn_class = fncls__2535d; tmp3 = fncls__2535d } else { tmp3 = fncls__2535 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2536 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any; var root_2541 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any = b__1685000289__6; if linked_2542 == nil { arg_2539 = ifn_2543.Invoke_O__O(arg_2544) } else { arg_2539 = linked_2542.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2541, arg_2544) }; var arg_2540 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000286); var tmp5 any; var root_2545 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = s__1685000287__3; if linked_2546 == nil { tmp5 = ifn_2547.Invoke_O__O(arg_2548) } else { tmp5 = linked_2546.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2545, arg_2548) }; arg_2540 = tmp4.Invoke_O__O(tmp5); if linked_2537 == nil { return ifn_2538.Invoke_O_O__O(arg_2539, arg_2540) } else { return linked_2537.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2536, arg_2539, arg_2540) } } else { var root_2549 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2551 lang.IFn; if linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any; var root_2554 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2554, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2556 lang.IFn; if linked_2555 == nil { ifn_2556 = lang.IFn_Cast(root_2554) } else { ifn_2556 = nil }; var arg_2557 any = b__1685000289__6; if linked_2555 == nil { arg_2552 = ifn_2556.Invoke_O__O(arg_2557) } else { arg_2552 = linked_2555.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2554, arg_2557) }; var arg_2553 any; if linked_2550 == nil { return ifn_2551.Invoke_O_O__O(arg_2552, arg_2553) } else { return linked_2550.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2549, arg_2552, arg_2553) } } } else { var pf__4 any; var root_2558 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2560 lang.IFn; if linked_2559 == nil { ifn_2560 = lang.IFn_Cast(root_2558) } else { ifn_2560 = nil }; var arg_2561 any = s__1685000287__3; if linked_2559 == nil { pf__4 = ifn_2560.Invoke_O__O(arg_2561) } else { pf__4 = linked_2559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2558, arg_2561) }; var root_2562 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2562, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2564 lang.IFn; if linked_2563 == nil { ifn_2564 = lang.IFn_Cast(root_2562) } else { ifn_2564 = nil }; var arg_2565 any; var root_2567 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2569 lang.IFn
															if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = pf__4; if linked_2568 == nil { arg_2565 = ifn_2569.Invoke_O__O(arg_2570) } else { arg_2565 = linked_2568.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2567, arg_2570) }
//line :394:1
	var arg_2566 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000286); var tmp7 any; var root_2571 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = s__1685000287__3; if linked_2572 == nil { tmp7 = ifn_2573.Invoke_O__O(arg_2574) } else { tmp7 = linked_2572.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2571, arg_2574) }; arg_2566 = tmp6.Invoke_O__O(tmp7); if linked_2563 == nil { return ifn_2564.Invoke_O_O__O(arg_2565, arg_2566) } else { return linked_2563.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2562, arg_2565, arg_2566) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :394:1
func A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :394:1
func (t *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A) Ctor_O_I_O(c__b__1685000289 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000289 = c__b__1685000289; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :394:1
func (t *A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A) Invoke_O__O(self any) any { { var i__1685000288__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000288__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000288__1)); var root_2526 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2528 lang.IFn; if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any = t.F_b__1685000289; var arg_2530 any; var root_2531 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2533 lang.IFn
																if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = pf__2; if linked_2532 == nil { arg_2530 = ifn_2533.Invoke_O__O(arg_2534) } else { arg_2530 = linked_2532.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2531, arg_2534) }
//line :394:1
	if linked_2527 == nil { ifn_2528.Invoke_O_O__O(arg_2529, arg_2530) } else { linked_2527.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2526, arg_2529, arg_2530) }; i__1685000288__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000288__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_check_corpus_fn__1685000296_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000296_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000296_A{}; t.Ctor_O(p0); return t }
//line :399:1
func (t *A_arbace_go_check_check_corpus_fn__1685000296_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :399:1
func (t *A_arbace_go_check_check_corpus_fn__1685000296_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____4 any; var root_2588 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, A_arbace_go_check_result_of_A_fn_class); var ifn_2590 lang.IFn
												if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any; var root_2592 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = t.F_s; var arg_2596 any = path__1; var arg_2597 any; var arg_2598 any = lang.PersistentVector_EMPTY.Ref(); if linked_2593 == nil { arg_2591 = ifn_2594.Invoke_O_O_O_O__O(arg_2595, arg_2596, arg_2597, arg_2598) } else { arg_2591 = linked_2593.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2592, arg_2595, arg_2596, arg_2597, arg_2598) }; if linked_2589 == nil { or__1927000174__auto____4 = ifn_2590.Invoke_O__O(arg_2591) } else { or__1927000174__auto____4 = linked_2589.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2588, arg_2591) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104, path__1, A_arbace_go_check_A_const_266, jrt.Boolean_TRUE.Ref())) } }; return nil }(); if /*line :399:1*/ tmp2 != nil { if true { var ex__4 jrt.Throwable_I = tmp2; var root_2599 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, A_arbace_go_check_error_result_A_fn_class); var ifn_2601 lang.IFn


		if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = path__1; var arg_2603 any = ex__4; if linked_2600 == nil { tmp1 = ifn_2601.Invoke_O_O__O(arg_2602, arg_2603) } else { tmp1 = linked_2600.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2599, arg_2602, arg_2603) } } }; return tmp1 }





func A_arbace_go_check_check_corpus_fn__1685000300_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000300_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000300_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :408:1
func (t *A_arbace_go_check_check_corpus_fn__1685000300_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :408:1
func (t *A_arbace_go_check_check_corpus_fn__1685000300_A) Invoke_O_O__O(self, pf__1 any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var src__4 any; var root_2627 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2627, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2629 lang.IFn

	if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any = t.F_root; var arg_2631 any; var arg_2632 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_cc); var arg_2633 any = pf__1; if linked_2628 == nil { src__4 = ifn_2629.Invoke_O_O_O_O__O(arg_2630, arg_2631, arg_2632, arg_2633) } else { src__4 = linked_2628.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2627, arg_2630, arg_2631, arg_2632, arg_2633) }
	var tmp2 any; var root_2634 any = A_arbace_go_check_A_const_268.GetRawRoot__O(); var linked_2635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2634, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2636 lang.IFn; if linked_2635 == nil { ifn_2636 = lang.IFn_Cast(root_2634) } else { ifn_2636 = nil }; var arg_2637 any = A_arbace_go_check_A_const_114.Invoke_O__O(src__4); if linked_2635 == nil { tmp2 = ifn_2636.Invoke_O__O(arg_2637) } else { tmp2 = linked_2635.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2634, arg_2637) }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_go_check_A_const_104; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(), A_arbace_go_check_A_const_266, jrt.Boolean_TRUE.Ref())) } else {

		var root_2638 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_2639 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2638, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2640 lang.IFn; if linked_2639 == nil { ifn_2640 = lang.IFn_Cast(root_2638) } else { ifn_2640 = nil }; var arg_2641 any; var root_2644 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, A_arbace_go_check_result_of_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_229.GetRawRoot__O()); var tmp5 any; var root_2653 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, A_arbace_go_check_resolver_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = t.F_s; var arg_2657 any = src__4; var arg_2658 any = lang.PersistentVector_EMPTY.Ref(); if linked_2654 == nil { tmp5 = ifn_2655.Invoke_O_O_O__O(arg_2656, arg_2657, arg_2658) } else { tmp5 = linked_2654.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_2653, arg_2656, arg_2657, arg_2658) }; arg_2647 = tmp4.Invoke_O_O__O(src__4, tmp5); if linked_2645 == nil { arg_2641 = ifn_2646.Invoke_O__O(arg_2647) } else { arg_2641 = linked_2645.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2644, arg_2647) }; var arg_2642 any = A_arbace_go_check_A_const_104; var arg_2643 any; var root_2659 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2659, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2661 lang.IFn
		if linked_2660 == nil { ifn_2661 = lang.IFn_Cast(root_2659) } else { ifn_2661 = nil }; var arg_2662 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2663 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dir)))).Ref(); if linked_2660 == nil { arg_2643 = ifn_2661.Invoke_O_O__O(arg_2662, arg_2663) } else { arg_2643 = linked_2660.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2659, arg_2662, arg_2663) }
//line :413:1
		if linked_2639 == nil { tmp1 = ifn_2640.Invoke_O_O_O__O(arg_2641, arg_2642, arg_2643) } else { tmp1 = linked_2639.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2638, arg_2641, arg_2642, arg_2643) } } }; return nil }(); if /*line :408:1*/ tmp6 != nil { if true { var ex__4 jrt.Throwable_I = tmp6; var root_2664 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2664, A_arbace_go_check_error_result_A_fn_class); var ifn_2666 lang.IFn






			if linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var arg_2668 any = ex__4; if linked_2665 == nil { tmp1 = ifn_2666.Invoke_O_O__O(arg_2667, arg_2668) } else { tmp1 = linked_2665.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2664, arg_2667, arg_2668) } } }; return tmp1 }






func A_arbace_go_check_check_corpus_fn__1685000304_A_New() *A_arbace_go_check_check_corpus_fn__1685000304_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000304_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_go_check_check_corpus_fn__1685000304_A) Ctor() {}
//line :422:1
func (t *A_arbace_go_check_check_corpus_fn__1685000304_A) Invoke_O_O__O(self, pf__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(pf__1)).GetPath__String().Ref(); var temp__1927000408__auto____3 any; var root_2701 any = A_arbace_go_check_A_const_271.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2703 lang.IFn; if

	linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = A_arbace_go_check_A_const_272; var arg_2705 any = p__2; if linked_2702 == nil { temp__1927000408__auto____3 = ifn_2703.Invoke_O_O__O(arg_2704, arg_2705) } else { temp__1927000408__auto____3 = linked_2702.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2701, arg_2704, arg_2705) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1685000305__4 any = temp__1927000408__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000305__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000305__4, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___5; return t__6 } else { return p__2 } }



func A_arbace_go_check_check_corpus_fn__1685000310_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000310_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :428:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_A) Ctor_O_O_O_O(c__dir, c__s, c__root, c__cc any) { t.F_dir = c__dir; t.F_s = c__s; t.F_root = c__root; t.F_cc = c__cc }
//line :428:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_A) Invoke_O_O__O(self, p__1685000309__1 any) any { var vec__1685000311__2 any = p__1685000309__1; var tdir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000311__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000311__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var by_path__7 any; var root_2722 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_2723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2722, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2724 lang.IFn

	if linked_2723 == nil { ifn_2724 = lang.IFn_Cast(root_2722) } else { ifn_2724 = nil }; var arg_2725 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2726 any; var iter__1927001039__auto____7 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A_New(); var tmp3 *jrt.Class; var fncls__2793 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A_fn_class; if fncls__2793 == nil { var fncls__2793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A_fn_class = fncls__2793d; tmp3 = fncls__2793d } else { tmp3 = fncls__2793 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_2726 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(pfs__4); if linked_2723 == nil { by_path__7 = ifn_2724.Invoke_O_O__O(arg_2725, arg_2726) } else { by_path__7 = linked_2723.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2722, arg_2725, arg_2726) }
//line :428:1
	var ts__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_184.GetRawRoot__O()); var tmp5 any; var root_2802 any = A_arbace_go_check_A_const_249.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, A_arbace_go_check_session_A_fn_class); var ifn_2804 lang.IFn



	if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A_New_O_O_O(by_path__7, t.F_root, t.F_cc); var tmp7 *jrt.Class; var fncls__2813 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A_fn_class; if fncls__2813 == nil { var fncls__2813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A_fn_class = fncls__2813d; tmp7 = fncls__2813d } else { tmp7 = fncls__2813 }; arg_2805 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2803 == nil { tmp5 = ifn_2804.Invoke_O__O(arg_2805) } else { tmp5 = linked_2803.(*A_arbace_go_check_session_A).Invoke_O_O__O(root_2802, arg_2805) }; var tmp8 any = tmp5; var tmp9 any = A_arbace_go_check_A_const_226; var tmp10 any = t.F_s; var tmp11 any = A_arbace_go_check_A_const_227; var tmp12 any = A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A_New_O(by_path__7); var tmp13 *jrt.Class; var fncls__2819 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A_fn_class; if fncls__2819 == nil { var fncls__2819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A_fn_class = fncls__2819d; tmp13 = fncls__2819d } else { tmp13 = fncls__2819 }; ts__8 = tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))



	var root_2820 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2822 lang.IFn; if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any; var iter__1927001039__auto____9 any; var tmp14 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A_New_O_O_O(t.F_dir, tdir__3, ts__8); var tmp15 *jrt.Class; var fncls__2938 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A_fn_class; if fncls__2938 == nil { var fncls__2938d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A_fn_class = fncls__2938d; tmp15 = fncls__2938d } else { tmp15 = fncls__2938 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp17 any; var root_2939 any = A_arbace_go_check_A_const_204.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = A_arbace_go_check_A_const_276.GetRawRoot__O(); var arg_2943 any = by_path__7; if linked_2940 == nil { tmp17 = ifn_2941.Invoke_O_O__O(arg_2942, arg_2943) } else { tmp17 = linked_2940.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2939, arg_2942, arg_2943) }; arg_2823 = tmp16.Invoke_O__O(tmp17); if linked_2821 == nil { tmp1 = ifn_2822.Invoke_O__O(arg_2823) } else { tmp1 = linked_2821.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2820, arg_2823) } }; return nil }(); if /*line :428:1*/ tmp18 != nil { if true { var ex__7 jrt.Throwable_I = tmp18; var tmp19 any; var root_2944 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2944, A_arbace_go_check_error_result_A_fn_class); var ifn_2946 lang.IFn












		if linked_2945 == nil { ifn_2946 = lang.IFn_Cast(root_2944) } else { ifn_2946 = nil }; var arg_2947 any = tdir__3; var arg_2948 any = ex__7; if linked_2945 == nil { tmp19 = ifn_2946.Invoke_O_O__O(arg_2947, arg_2948) } else { tmp19 = linked_2945.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2944, arg_2947, arg_2948) }
//line :428:1
		tmp1 = lang.Tuple_Create_O__IPersistentVector(tmp19) } }; return tmp1 }

func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A_New() *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A) Ctor() {}
//line :430:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A) Invoke_O_O__O(self, s__1685000315__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A_New_O_O(self, s__1685000315__1); var tmp2 *jrt.Class; var fncls__2792 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A_fn_class; if fncls__2792 == nil { var fncls__2792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A_fn_class = fncls__2792d; tmp2 = fncls__2792d } else { tmp2 = fncls__2792 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :430:1
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A_New_O_O(p0, p1 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A{}; t.Ctor_O_O(p0, p1); return t }
//line :430:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A) Ctor_O_O(c__iter__1685000314, c__s__1685000315 any) { t.F_iter__1685000314 = c__iter__1685000314; t.F_s__1685000315 = c__s__1685000315 }
//line :430:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A) Invoke_O__O(self any) any { { var s__1685000315__1 any; var t_ any = t.F_s__1685000315; t.F_s__1685000315 = nil; s__1685000315__1 = t_; for { var temp__1927000414__auto____2 any; var root_2727 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2727, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2729 lang.IFn; if linked_2728 == nil { ifn_2729 = lang.IFn_Cast(root_2727) } else { ifn_2729 = nil }; var arg_2730 any = s__1685000315__1; if linked_2728 == nil { temp__1927000414__auto____2 = ifn_2729.Invoke_O__O(arg_2730) } else { temp__1927000414__auto____2 = linked_2728.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2727, arg_2730) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000315__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2731 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2731, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2733 lang.IFn; if linked_2732 == nil { ifn_2733 = lang.IFn_Cast(root_2731) } else { ifn_2733 = nil }; var arg_2734 any = s__1685000315__3; if linked_2732 == nil { tmp1 = ifn_2733.Invoke_O__O(arg_2734) } else { tmp1 = linked_2732.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2731, arg_2734) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2735 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2735, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2737 lang.IFn; if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any = s__1685000315__3; if linked_2736 == nil { c__1927001037__auto____4 = ifn_2737.Invoke_O__O(arg_2738) } else { c__1927001037__auto____4 = linked_2736.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2735, arg_2738) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000317__6 any; var root_2739 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2741 lang.IFn; if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2740 == nil { b__1685000317__6 = ifn_2741.Invoke_O__O(arg_2742) } else { b__1685000317__6 = linked_2740.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2739, arg_2742) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A_New_O_I_O(b__1685000317__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2752 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A_fn_class; if fncls__2752 == nil { var fncls__2752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A_fn_class = fncls__2752d; tmp3 = fncls__2752d } else { tmp3 = fncls__2752 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2753 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2753, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2755 lang.IFn; if linked_2754 == nil { ifn_2755 = lang.IFn_Cast(root_2753) } else { ifn_2755 = nil }; var arg_2756 any; var root_2758 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2760 lang.IFn; if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any = b__1685000317__6; if linked_2759 == nil { arg_2756 = ifn_2760.Invoke_O__O(arg_2761) } else { arg_2756 = linked_2759.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2758, arg_2761) }; var arg_2757 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000314); var tmp5 any; var root_2762 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = s__1685000315__3; if linked_2763 == nil { tmp5 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp5 = linked_2763.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2762, arg_2765) }; arg_2757 = tmp4.Invoke_O__O(tmp5); if linked_2754 == nil { return ifn_2755.Invoke_O_O__O(arg_2756, arg_2757) } else { return linked_2754.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2753, arg_2756, arg_2757) } } else { var root_2766 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any; var root_2771 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2771, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2773 lang.IFn; if linked_2772 == nil { ifn_2773 = lang.IFn_Cast(root_2771) } else { ifn_2773 = nil }; var arg_2774 any = b__1685000317__6; if linked_2772 == nil { arg_2769 = ifn_2773.Invoke_O__O(arg_2774) } else { arg_2769 = linked_2772.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2771, arg_2774) }; var arg_2770 any; if linked_2767 == nil { return ifn_2768.Invoke_O_O__O(arg_2769, arg_2770) } else { return linked_2767.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2766, arg_2769, arg_2770) } } } else { var pf__4 any; var root_2775 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2777 lang.IFn; if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any = s__1685000315__3; if linked_2776 == nil { pf__4 = ifn_2777.Invoke_O__O(arg_2778) } else { pf__4 = linked_2776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2775, arg_2778) }; var root_2779 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2779, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2781 lang.IFn; if linked_2780 == nil { ifn_2781 = lang.IFn_Cast(root_2779) } else { ifn_2781 = nil }; var arg_2782 any; var tmp6 any; var root_2784 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2784, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2786 lang.IFn; if linked_2785 == nil { ifn_2786 = lang.IFn_Cast(root_2784) } else { ifn_2786 = nil }; var arg_2787 any = pf__4; if linked_2785 == nil { tmp6 = ifn_2786.Invoke_O__O(arg_2787) } else { tmp6 = linked_2785.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2784, arg_2787) }; arg_2782 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, pf__4); var arg_2783 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1685000314); var tmp8 any; var root_2788 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2788, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2790 lang.IFn; if linked_2789 == nil { ifn_2790 = lang.IFn_Cast(root_2788) } else { ifn_2790 = nil }; var arg_2791 any = s__1685000315__3; if linked_2789 == nil { tmp8 = ifn_2790.Invoke_O__O(arg_2791) } else { tmp8 = linked_2789.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2788, arg_2791) }; arg_2783 = tmp7.Invoke_O__O(tmp8); if linked_2780 == nil { return ifn_2781.Invoke_O_O__O(arg_2782, arg_2783) } else { return linked_2780.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2779, arg_2782, arg_2783) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :430:1
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :430:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A) Ctor_O_I_O(c__b__1685000317 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000317 = c__b__1685000317; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :430:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A) Invoke_O__O(self any) any { { var i__1685000316__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000316__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000316__1)); var root_2743 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2745 lang.IFn; if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; var arg_2746 any = t.F_b__1685000317; var arg_2747 any; var tmp2 any; var root_2748 any = A_arbace_go_check_A_const_262.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_2750 lang.IFn; if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = pf__2; if linked_2749 == nil { tmp2 = ifn_2750.Invoke_O__O(arg_2751) } else { tmp2 = linked_2749.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_2748, arg_2751) }; arg_2747 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, pf__2); if linked_2744 == nil { ifn_2745.Invoke_O_O__O(arg_2746, arg_2747) } else { linked_2744.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2743, arg_2746, arg_2747) }; i__1685000316__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000316__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :432:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A) Ctor_O_O_O(c__by_path, c__root, c__cc any) { t.F_by_path = c__by_path; t.F_root = c__root; t.F_cc = c__cc }
//line :432:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A) Invoke_O_O_O__O(self, path__1, importer__2 any) any { var temp__1927000414__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_by_path, path__1); if
																jrt.J2g_Truth(temp__1927000414__auto____3) { var pf__4 any = temp__1927000414__auto____3; var root_2806 any = A_arbace_go_check_A_const_250.GetRawRoot__O(); var linked_2807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2806, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2808 lang.IFn
																	if linked_2807 == nil { ifn_2808 = lang.IFn_Cast(root_2806) } else { ifn_2808 = nil }; var arg_2809 any = t.F_root; var arg_2810 any = path__1; var arg_2811 any = A_arbace_go_check_A_const_105.Invoke_O__O(t.F_cc); var arg_2812 any = pf__4; if linked_2807 == nil { return ifn_2808.Invoke_O_O_O_O__O(arg_2809, arg_2810, arg_2811, arg_2812) } else { return linked_2807.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2806, arg_2809, arg_2810, arg_2811, arg_2812) } } else {
//line :433:1
			return nil } }
//line :432:1
func A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A_New_O(p0 any) *A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A{}; t.Ctor_O(p0); return t }
//line :432:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A) Ctor_O(c__by_path any) { t.F_by_path = c__by_path }
//line :432:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A) Invoke_O_O__O(self, p1__1685000285_SHARP___1 any) any {


	var root_2814 any = A_arbace_go_check_A_const_39.GetRawRoot__O(); var linked_2815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2814, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2816 lang.IFn; if linked_2815 == nil { ifn_2816 = lang.IFn_Cast(root_2814) } else { ifn_2816 = nil }; var arg_2817 any = t.F_by_path; var arg_2818 any = p1__1685000285_SHARP___1; if linked_2815 == nil { return ifn_2816.Invoke_O_O__O(arg_2817, arg_2818) } else { return linked_2815.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2814, arg_2817, arg_2818) } }
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :436:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A) Ctor_O_O_O(c__dir, c__tdir, c__ts any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :436:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A) Invoke_O_O__O(self, s__1685000329__1 any) any { var tmp1 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A_New_O_O_O_O_O(self, t.F_dir, t.F_tdir, t.F_ts, s__1685000329__1); var tmp2 *jrt.Class; var fncls__2937 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A_fn_class; if fncls__2937 == nil { var fncls__2937d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A_fn_class = fncls__2937d; tmp2 = fncls__2937d } else { tmp2 = fncls__2937 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :436:1
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :436:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A) Ctor_O_O_O_O_O(c__iter__1685000328, c__dir, c__tdir, c__ts, c__s__1685000329 any) { t.F_iter__1685000328 = c__iter__1685000328; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_s__1685000329 = c__s__1685000329 }
//line :436:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A) Invoke_O__O(self any) any { { var s__1685000329__1 any; var t_ any = t.F_s__1685000329; t.F_s__1685000329 = nil; s__1685000329__1 = t_; for { var temp__1927000414__auto____2 any; var root_2824 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = s__1685000329__1; if linked_2825 == nil { temp__1927000414__auto____2 = ifn_2826.Invoke_O__O(arg_2827) } else { temp__1927000414__auto____2 = linked_2825.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2824, arg_2827) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000329__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2828 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_2829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2828, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2830 lang.IFn; if linked_2829 == nil { ifn_2830 = lang.IFn_Cast(root_2828) } else { ifn_2830 = nil }; var arg_2831 any = s__1685000329__3; if linked_2829 == nil { tmp1 = ifn_2830.Invoke_O__O(arg_2831) } else { tmp1 = linked_2829.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2828, arg_2831) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2832 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_2833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2832, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2834 lang.IFn; if linked_2833 == nil { ifn_2834 = lang.IFn_Cast(root_2832) } else { ifn_2834 = nil }; var arg_2835 any = s__1685000329__3; if linked_2833 == nil { c__1927001037__auto____4 = ifn_2834.Invoke_O__O(arg_2835) } else { c__1927001037__auto____4 = linked_2833.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2832, arg_2835) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000331__6 any; var root_2836 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_2837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2836, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2838 lang.IFn; if linked_2837 == nil { ifn_2838 = lang.IFn_Cast(root_2836) } else { ifn_2838 = nil }; var arg_2839 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2837 == nil { b__1685000331__6 = ifn_2838.Invoke_O__O(arg_2839) } else { b__1685000331__6 = linked_2837.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2836, arg_2839) }; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A_New_O_O_O_I_O_O(t.F_dir, t.F_tdir, t.F_ts, size__1927001038__auto____5, c__1927001037__auto____4, b__1685000331__6); var tmp3 *jrt.Class; var fncls__2873 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A_fn_class; if fncls__2873 == nil { var fncls__2873d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A_fn_class = fncls__2873d; tmp3 = fncls__2873d } else { tmp3 = fncls__2873 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2874 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any; var root_2879 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2879, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2881 lang.IFn; if linked_2880 == nil { ifn_2881 = lang.IFn_Cast(root_2879) } else { ifn_2881 = nil }; var arg_2882 any = b__1685000331__6; if linked_2880 == nil { arg_2877 = ifn_2881.Invoke_O__O(arg_2882) } else { arg_2877 = linked_2880.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2879, arg_2882) }; var arg_2878 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000328); var tmp5 any; var root_2883 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_2884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2883, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2885 lang.IFn; if linked_2884 == nil { ifn_2885 = lang.IFn_Cast(root_2883) } else { ifn_2885 = nil }; var arg_2886 any = s__1685000329__3; if linked_2884 == nil { tmp5 = ifn_2885.Invoke_O__O(arg_2886) } else { tmp5 = linked_2884.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2883, arg_2886) }; arg_2878 = tmp4.Invoke_O__O(tmp5); if linked_2875 == nil { return ifn_2876.Invoke_O_O__O(arg_2877, arg_2878) } else { return linked_2875.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2874, arg_2877, arg_2878) } } else { var root_2887 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_2888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2887, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2889 lang.IFn; if linked_2888 == nil { ifn_2889 = lang.IFn_Cast(root_2887) } else { ifn_2889 = nil }; var arg_2890 any; var root_2892 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_2893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2892, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2894 lang.IFn; if linked_2893 == nil { ifn_2894 = lang.IFn_Cast(root_2892) } else { ifn_2894 = nil }; var arg_2895 any = b__1685000331__6; if linked_2893 == nil { arg_2890 = ifn_2894.Invoke_O__O(arg_2895) } else { arg_2890 = linked_2893.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2892, arg_2895) }; var arg_2891 any; if linked_2888 == nil { return ifn_2889.Invoke_O_O__O(arg_2890, arg_2891) } else { return linked_2888.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2887, arg_2890, arg_2891) } } } else { var vec__1685000341__4 any; var root_2896 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any = s__1685000329__3; if linked_2897 == nil { vec__1685000341__4 = ifn_2898.Invoke_O__O(arg_2899) } else { vec__1685000341__4 = linked_2897.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2896, arg_2899) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000341__4, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000341__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2900 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2902 lang.IFn; _ = pf__6; if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var arg_2903 any; var tmp6 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A_New_O_O_O_O(path__5, t.F_dir, t.F_tdir, t.F_ts); var tmp7 *jrt.Class; var fncls__2932 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A_fn_class
																if fncls__2932 == nil { var fncls__2932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A_fn_class = fncls__2932d; tmp7 = fncls__2932d } else { tmp7 = fncls__2932 }; arg_2903 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :436:1
	var arg_2904 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1685000328); var tmp9 any; var root_2933 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2933, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2935 lang.IFn; if linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = s__1685000329__3; if linked_2934 == nil { tmp9 = ifn_2935.Invoke_O__O(arg_2936) } else { tmp9 = linked_2934.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2933, arg_2936) }; arg_2904 = tmp8.Invoke_O__O(tmp9); if linked_2901 == nil { return ifn_2902.Invoke_O_O__O(arg_2903, arg_2904) } else { return linked_2901.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2900, arg_2903, arg_2904) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :436:1
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :436:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A) Ctor_O_O_O_I_O_O(c__dir, c__tdir, c__ts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1685000331 any) { t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1685000331 = c__b__1685000331 }
//line :436:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A) Invoke_O__O(self any) any { { var i__1685000330__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000330__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1685000335__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000330__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000335__2, lang.RT_IntCast_J__I_NoInit(0), nil); var pf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1685000335__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2840 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_2841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2840, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2842 lang.IFn; _ = pf__4; if linked_2841 == nil { ifn_2842 = lang.IFn_Cast(root_2840) } else { ifn_2842 = nil }; var arg_2843 any = t.F_b__1685000331; var arg_2844 any; var tmp2 any = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A_New_O_O_O_O(path__3, t.F_dir, t.F_tdir, t.F_ts); var tmp3 *jrt.Class; var fncls__2872 *jrt.Class = A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A_fn_class
																		if fncls__2872 == nil { var fncls__2872d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A_fn_class = fncls__2872d; tmp3 = fncls__2872d } else { tmp3 = fncls__2872 }; arg_2844 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :436:1
	if linked_2841 == nil { ifn_2842.Invoke_O_O__O(arg_2843, arg_2844) } else { linked_2841.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2840, arg_2843, arg_2844) }; i__1685000330__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000330__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :437:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :437:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																				{ var root_2845 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2847 lang.IFn; if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any; var or__1927000174__auto____3 any; var root_2851 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, A_arbace_go_check_result_of_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any; var root_2855 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any; var t_ any = t.F_ts; t.F_ts = nil; arg_2858 = t_; var arg_2859 any = t.F_path; var arg_2860 any; var arg_2861 any = lang.PersistentVector_EMPTY.Ref(); if linked_2856 == nil { arg_2854 = ifn_2857.Invoke_O_O_O_O__O(arg_2858, arg_2859, arg_2860, arg_2861) } else { arg_2854 = linked_2856.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2855, arg_2858, arg_2859, arg_2860, arg_2861) }; if linked_2852 == nil { or__1927000174__auto____3 = ifn_2853.Invoke_O__O(arg_2854) } else { or__1927000174__auto____3 = linked_2852.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2851, arg_2854) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_2848 = or__1927000174__auto____3 } else { arg_2848 = A_arbace_go_check_A_const_274 }; var arg_2849 any = A_arbace_go_check_A_const_104; var arg_2850 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil); var tmp3 any; var root_2862 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2862, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2864 lang.IFn
																					if linked_2863 == nil { ifn_2864 = lang.IFn_Cast(root_2862) } else { ifn_2864 = nil }; var arg_2865 any = t.F_tdir; var arg_2866 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_2866 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_2863 == nil { tmp3 = ifn_2864.Invoke_O_O__O(arg_2865, arg_2866) } else { tmp3 = linked_2863.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2862, arg_2865, arg_2866) }; arg_2850 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :438:1
		if linked_2846 == nil { tmp1 = ifn_2847.Invoke_O_O_O__O(arg_2848, arg_2849, arg_2850) } else { tmp1 = linked_2846.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2845, arg_2848, arg_2849, arg_2850) } }
//line :437:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_2867 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, A_arbace_go_check_error_result_A_fn_class); var ifn_2869 lang.IFn


		if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_2870 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_2871 any = ex__3; if linked_2868 == nil { tmp1 = ifn_2869.Invoke_O_O__O(arg_2870, arg_2871) } else { tmp1 = linked_2868.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2867, arg_2870, arg_2871) } } }; return tmp1 }
//line :437:1
func A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :437:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A) Ctor_O_O_O_O(c__path, c__dir, c__tdir, c__ts any) { t.F_path = c__path; t.F_dir = c__dir; t.F_tdir = c__tdir; t.F_ts = c__ts }
//line :437:1
func (t *A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																		{ var root_2905 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2907 lang.IFn; if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any; var or__1927000174__auto____3 any; var root_2911 any = A_arbace_go_check_A_const_265.GetRawRoot__O(); var linked_2912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2911, A_arbace_go_check_result_of_A_fn_class); var ifn_2913 lang.IFn; if linked_2912 == nil { ifn_2913 = lang.IFn_Cast(root_2911) } else { ifn_2913 = nil }; var arg_2914 any; var root_2915 any = A_arbace_go_check_A_const_222.GetRawRoot__O(); var linked_2916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2915, A_arbace_go_check_ensure_package_A_fn_class); var ifn_2917 lang.IFn; if linked_2916 == nil { ifn_2917 = lang.IFn_Cast(root_2915) } else { ifn_2917 = nil }; var arg_2918 any; var t_ any = t.F_ts; t.F_ts = nil; arg_2918 = t_; var arg_2919 any = t.F_path; var arg_2920 any; var arg_2921 any = lang.PersistentVector_EMPTY.Ref(); if linked_2916 == nil { arg_2914 = ifn_2917.Invoke_O_O_O_O__O(arg_2918, arg_2919, arg_2920, arg_2921) } else { arg_2914 = linked_2916.(*A_arbace_go_check_ensure_package_A).Invoke_O_O_O_O_O__O(root_2915, arg_2918, arg_2919, arg_2920, arg_2921) }; if linked_2912 == nil { or__1927000174__auto____3 = ifn_2913.Invoke_O__O(arg_2914) } else { or__1927000174__auto____3 = linked_2912.(*A_arbace_go_check_result_of_A).Invoke_O_O__O(root_2911, arg_2914) }; if jrt.J2g_Truth(or__1927000174__auto____3) { arg_2908 = or__1927000174__auto____3 } else { arg_2908 = A_arbace_go_check_A_const_275 }; var arg_2909 any = A_arbace_go_check_A_const_104; var arg_2910 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil); var tmp3 any; var root_2922 any = A_arbace_go_check_A_const_269.GetRawRoot__O(); var linked_2923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2922, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2924 lang.IFn
																			if linked_2923 == nil { ifn_2924 = lang.IFn_Cast(root_2922) } else { ifn_2924 = nil }; var arg_2925 any = t.F_tdir; var arg_2926 any; var tmp4 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp4 = t__2; arg_2926 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp4)))).Ref(); if linked_2923 == nil { tmp3 = ifn_2924.Invoke_O_O__O(arg_2925, arg_2926) } else { tmp3 = linked_2923.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2922, arg_2925, arg_2926) }; arg_2910 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, t.F_path)).Ref()
//line :438:1
		if linked_2906 == nil { tmp1 = ifn_2907.Invoke_O_O_O__O(arg_2908, arg_2909, arg_2910) } else { tmp1 = linked_2906.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2905, arg_2908, arg_2909, arg_2910) } }
//line :437:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var root_2927 any = A_arbace_go_check_A_const_267.GetRawRoot__O(); var linked_2928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2927, A_arbace_go_check_error_result_A_fn_class); var ifn_2929 lang.IFn


		if linked_2928 == nil { ifn_2929 = lang.IFn_Cast(root_2927) } else { ifn_2929 = nil }; var arg_2930 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil); var tmp7 any; var t__3 any = t.F_tdir; t.F_tdir = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_path; t.F_path = nil; tmp9 = t__4; arg_2930 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_2931 any = ex__3; if linked_2928 == nil { tmp1 = ifn_2929.Invoke_O_O__O(arg_2930, arg_2931) } else { tmp1 = linked_2928.(*A_arbace_go_check_error_result_A).Invoke_O_O_O__O(root_2927, arg_2930, arg_2931) } } }; return tmp1 }



func A_arbace_go_check_summarize_A_New() *A_arbace_go_check_summarize_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_A{}; t.Ctor(); return t }
//line :444:1
func (t *A_arbace_go_check_summarize_A) Ctor() {}
//line :444:1
func (t *A_arbace_go_check_summarize_A) Invoke_O_O_O__O(self, corpus__0, results__1 any) any { var rs__3 any; var root_2955 any = A_arbace_go_check_A_const_135.GetRawRoot__O(); var linked_2956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2955, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2957 lang.IFn; if


	linked_2956 == nil { ifn_2957 = lang.IFn_Cast(root_2955) } else { ifn_2957 = nil }; var arg_2958 any = A_arbace_go_check_A_const_266; var arg_2959 any = results__1; if linked_2956 == nil { rs__3 = ifn_2957.Invoke_O_O__O(arg_2958, arg_2959) } else { rs__3 = linked_2956.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2955, arg_2958, arg_2959) }; var sum__4 any; var tmp1 any = /*line :444:1*/A_arbace_go_check_summarize_sum__1685000356_A_New_O(rs__3); var tmp2 *jrt.Class; var fncls__2971 *jrt.Class = A_arbace_go_check_summarize_sum__1685000356_A_fn_class; if



	fncls__2971 == nil { var fncls__2971d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_summarize_sum__1685000356_A_fn_class = fncls__2971d; tmp2 = fncls__2971d } else { tmp2 = fncls__2971 }; sum__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var msum__5 any; var tmp3 any = /*line :444:1*/A_arbace_go_check_summarize_msum__1685000358_A_New_O(rs__3); var tmp4 *jrt.Class; var fncls__2984 *jrt.Class = A_arbace_go_check_summarize_msum__1685000358_A_fn_class; if




	fncls__2984 == nil { var fncls__2984d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_summarize_msum__1685000358_A_fn_class = fncls__2984d; tmp4 = fncls__2984d } else { tmp4 = fncls__2984 }; msum__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 any = A_arbace_go_check_A_const_246; var tmp6 any = A_arbace_go_check_A_const_277; var tmp7 any = /*line :444:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__3)).Ref(); var tmp8 any = A_arbace_go_check_A_const_278; var tmp9 any = A_arbace_go_check_A_const_279; var tmp10 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_82); var tmp11 any = A_arbace_go_check_A_const_150; var tmp12 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_150); var tmp13 any = A_arbace_go_check_A_const_132; var tmp14 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_142); var tmp15 any = A_arbace_go_check_A_const_140; var tmp16 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_140))); var tmp17 any = A_arbace_go_check_A_const_202; var tmp18 lang.IFn = lang.IFn_Cast(sum__4); var tmp19 any = A_arbace_go_check_summarize_fn__1685000360_A_New(); var tmp20 *jrt.Class; var fncls__3067 *jrt.Class = A_arbace_go_check_summarize_fn__1685000360_A_fn_class; if









	fncls__3067 == nil { var fncls__3067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_summarize_fn__1685000360_A_fn_class = fncls__3067d; tmp20 = fncls__3067d } else { tmp20 = fncls__3067 }; var tmp21 any = /*line :444:1*/tmp18.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)); var tmp22 any = A_arbace_go_check_A_const_206; var tmp23 any = lang.IFn_Cast(sum__4).Invoke_O__O(A_arbace_go_check_A_const_206); var tmp24 any = A_arbace_go_check_A_const_280; var tmp25 any; var root_2985 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2985, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2987 lang.IFn; if











	linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 any; var tmp26 any = A_arbace_go_check_summarize_fn__1685000362_A_New(); var tmp27 *jrt.Class; var fncls__2990 *jrt.Class = A_arbace_go_check_summarize_fn__1685000362_A_fn_class; if fncls__2990 == nil { var fncls__2990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_summarize_fn__1685000362_A_fn_class = fncls__2990d; tmp27 = fncls__2990d } else { tmp27 = fncls__2990 }; arg_2988 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_2989 any = rs__3; if linked_2986 == nil { tmp25 = ifn_2987.Invoke_O_O__O(arg_2988, arg_2989) } else { tmp25 = linked_2986.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2985, arg_2988, arg_2989) }; var tmp28 any = /*line :444:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp25)).Ref(); var tmp29 any = A_arbace_go_check_A_const_282; var tmp30 any; var root_2991 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2993 lang.IFn; if












	linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any; var root_2995 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any; var tmp31 any = A_arbace_go_check_summarize_fn__1685000364_A_New(); var tmp32 *jrt.Class; var fncls__3000 *jrt.Class = A_arbace_go_check_summarize_fn__1685000364_A_fn_class; if fncls__3000 == nil { var fncls__3000d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_summarize_fn__1685000364_A_fn_class = fncls__3000d; tmp32 = fncls__3000d } else { tmp32 = fncls__3000 }; arg_2998 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var arg_2999 any = rs__3; if linked_2996 == nil { arg_2994 = ifn_2997.Invoke_O_O__O(arg_2998, arg_2999) } else { arg_2994 = linked_2996.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2995, arg_2998, arg_2999) }; if linked_2992 == nil { tmp30 = ifn_2993.Invoke_O__O(arg_2994) } else { tmp30 = linked_2992.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2991, arg_2994) }; var tmp33 any = tmp30; var tmp34 any = A_arbace_go_check_A_const_283; var tmp35 any = A_arbace_go_check_A_const_127; var tmp36 any; var root_3001 any = /*line :444:1*/A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3001, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3003 lang.IFn; if













	linked_3002 == nil { ifn_3003 = lang.IFn_Cast(root_3001) } else { ifn_3003 = nil }; var arg_3004 any = lang.IFn_Cast(A_arbace_go_check_A_const_284.GetRawRoot__O()).Invoke__O(); var arg_3005 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_127); if linked_3002 == nil { tmp36 = ifn_3003.Invoke_O_O__O(arg_3004, arg_3005) } else { tmp36 = linked_3002.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3001, arg_3004, arg_3005) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_A_const_151; var tmp39 any; var root_3009 any = /*line :444:1*/A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3009, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3011 lang.IFn; if














	linked_3010 == nil { ifn_3011 = lang.IFn_Cast(root_3009) } else { ifn_3011 = nil }; var arg_3012 any = lang.IFn_Cast(A_arbace_go_check_A_const_284.GetRawRoot__O()).Invoke__O(); var arg_3013 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_151); if linked_3010 == nil { tmp39 = ifn_3011.Invoke_O_O__O(arg_3012, arg_3013) } else { tmp39 = linked_3010.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3009, arg_3012, arg_3013) }; var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_A_const_152; var tmp42 any; var root_3017 any = /*line :444:1*/A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3017, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3019 lang.IFn; if















	linked_3018 == nil { ifn_3019 = lang.IFn_Cast(root_3017) } else { ifn_3019 = nil }; var arg_3020 any = lang.IFn_Cast(A_arbace_go_check_A_const_284.GetRawRoot__O()).Invoke__O(); var arg_3021 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_152); if linked_3018 == nil { tmp42 = ifn_3019.Invoke_O_O__O(arg_3020, arg_3021) } else { tmp42 = linked_3018.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3017, arg_3020, arg_3021) }; var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_A_const_285; var tmp45 any; var root_3025 any = /*line :444:1*/A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3025, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3027 lang.IFn; if
















	linked_3026 == nil { ifn_3027 = lang.IFn_Cast(root_3025) } else { ifn_3027 = nil }; var arg_3028 any = lang.IFn_Cast(A_arbace_go_check_A_const_284.GetRawRoot__O()).Invoke__O(); var arg_3029 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_143); if linked_3026 == nil { tmp45 = ifn_3027.Invoke_O_O__O(arg_3028, arg_3029) } else { tmp45 = linked_3026.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3025, arg_3028, arg_3029) }; var tmp46 any = tmp45; var tmp47 any = A_arbace_go_check_A_const_207; var tmp48 any = A_arbace_go_check_A_const_277; var tmp49 any; var root_3033 any = /*line :444:1*/A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3035 lang.IFn; if

















	linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any; var tmp50 any = A_arbace_go_check_summarize_fn__1685000366_A_New(); var tmp51 *jrt.Class; var fncls__3043 *jrt.Class = A_arbace_go_check_summarize_fn__1685000366_A_fn_class; if fncls__3043 == nil { var fncls__3043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_summarize_fn__1685000366_A_fn_class = fncls__3043d; tmp51 = fncls__3043d } else { tmp51 = fncls__3043 }; arg_3036 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil); var arg_3037 any = rs__3; if linked_3034 == nil { tmp49 = ifn_3035.Invoke_O_O__O(arg_3036, arg_3037) } else { tmp49 = linked_3034.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3033, arg_3036, arg_3037) }; var tmp52 any = /*line :444:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp49)).Ref(); var tmp53 any = A_arbace_go_check_A_const_287; var tmp54 lang.IFn = lang.IFn_Cast(sum__4); var tmp55 any = A_arbace_go_check_summarize_fn__1685000368_A_New(); var tmp56 *jrt.Class; var fncls__3074 *jrt.Class = A_arbace_go_check_summarize_fn__1685000368_A_fn_class; if


















	fncls__3074 == nil { var fncls__3074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_go_check_summarize_fn__1685000368_A_fn_class = fncls__3074d; tmp56 = fncls__3074d } else { tmp56 = fncls__3074 }; var tmp57 any = /*line :444:1*/tmp54.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil)); var tmp58 any = A_arbace_go_check_A_const_288; var tmp59 any; var root_3044 any = A_arbace_go_check_A_const_281.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3046 lang.IFn; if



















	linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any; var tmp60 any = A_arbace_go_check_summarize_fn__1685000370_A_New(); var tmp61 *jrt.Class; var fncls__3058 *jrt.Class = A_arbace_go_check_summarize_fn__1685000370_A_fn_class; if fncls__3058 == nil { var fncls__3058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_go_check_summarize_fn__1685000370_A_fn_class = fncls__3058d; tmp61 = fncls__3058d } else { tmp61 = fncls__3058 }; arg_3047 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp60, tmp61, nil); var arg_3048 any = rs__3; if linked_3045 == nil { tmp59 = ifn_3046.Invoke_O_O__O(arg_3047, arg_3048) } else { tmp59 = linked_3045.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3044, arg_3047, arg_3048) }; var tmp62 any = /*line :444:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, tmp46, tmp47, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp52, tmp53, tmp57, tmp58, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp59)).Ref())))); var tmp63 any = A_arbace_go_check_A_const_133; var tmp64 any; var root_3059 any = A_arbace_go_check_A_const_144.GetRawRoot__O(); var linked_3060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3059, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3061 lang.IFn; if




















	linked_3060 == nil { ifn_3061 = lang.IFn_Cast(root_3059) } else { ifn_3061 = nil }; var arg_3062 any = lang.IFn_Cast(A_arbace_go_check_A_const_284.GetRawRoot__O()).Invoke__O(); var arg_3063 any = lang.IFn_Cast(msum__5).Invoke_O__O(A_arbace_go_check_A_const_133); if linked_3060 == nil { tmp64 = ifn_3061.Invoke_O_O__O(arg_3062, arg_3063) } else { tmp64 = linked_3060.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3059, arg_3062, arg_3063) }; return /*line :444:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, corpus__0, tmp6, tmp7, tmp8, tmp16, tmp17, tmp21, tmp22, tmp23, tmp24, tmp28, tmp29, tmp33, tmp34, tmp62, tmp63, tmp64)) }



func A_arbace_go_check_summarize_sum__1685000356_A_New_O(p0 any) *A_arbace_go_check_summarize_sum__1685000356_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_sum__1685000356_A{}; t.Ctor_O(p0); return t }
//line :448:1
func (t *A_arbace_go_check_summarize_sum__1685000356_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :448:1
func (t *A_arbace_go_check_summarize_sum__1685000356_A) Invoke_O_O__O(self, k__1 any) any { var root_2960 any = A_arbace_go_check_A_const_136.GetRawRoot__O(); var linked_2961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2960, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2962 lang.IFn; if linked_2961 == nil { ifn_2962 = lang.IFn_Cast(root_2960) } else { ifn_2962 = nil }; var arg_2963 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_2964 any = A_arbace_go_check_A_const_22; var arg_2965 any; var root_2966 any = A_arbace_go_check_A_const_131.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2968 lang.IFn; if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any = k__1; var arg_2970 any = t.F_rs; if linked_2967 == nil { arg_2965 = ifn_2968.Invoke_O_O__O(arg_2969, arg_2970) } else { arg_2965 = linked_2967.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2966, arg_2969, arg_2970) }; if linked_2961 == nil { return ifn_2962.Invoke_O_O_O__O(arg_2963, arg_2964, arg_2965) } else { return linked_2961.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2960, arg_2963, arg_2964, arg_2965) } }
func A_arbace_go_check_summarize_msum__1685000358_A_New_O(p0 any) *A_arbace_go_check_summarize_msum__1685000358_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_msum__1685000358_A{}; t.Ctor_O(p0); return t }
//line :449:1
func (t *A_arbace_go_check_summarize_msum__1685000358_A) Ctor_O(c__rs any) { t.F_rs = c__rs }
//line :449:1
func (t *A_arbace_go_check_summarize_msum__1685000358_A) Invoke_O_O__O(self, k__1 any) any { var root_2972 any = A_arbace_go_check_A_const_121.GetRawRoot__O(); var linked_2973 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2972, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2974 lang.IFn; if linked_2973 == nil { ifn_2974 = lang.IFn_Cast(root_2972) } else { ifn_2974 = nil }; var arg_2975 any = A_arbace_go_check_A_const_139.GetRawRoot__O(); var arg_2976 any = A_arbace_go_check_A_const_21.GetRawRoot__O(); var arg_2977 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2978 any; var root_2979 any = A_arbace_go_check_A_const_116.GetRawRoot__O(); var linked_2980 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2979, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2981 lang.IFn; if linked_2980 == nil { ifn_2981 = lang.IFn_Cast(root_2979) } else { ifn_2981 = nil }; var arg_2982 any = k__1; var arg_2983 any = t.F_rs; if linked_2980 == nil { arg_2978 = ifn_2981.Invoke_O_O__O(arg_2982, arg_2983) } else { arg_2978 = linked_2980.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2979, arg_2982, arg_2983) }; if linked_2973 == nil { return ifn_2974.Invoke_O_O_O_O__O(arg_2975, arg_2976, arg_2977, arg_2978) } else { return linked_2973.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2972, arg_2975, arg_2976, arg_2977, arg_2978) } }




func A_arbace_go_check_summarize_fn__1685000360_A_New() *A_arbace_go_check_summarize_fn__1685000360_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000360_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_go_check_summarize_fn__1685000360_A) Ctor() {}
//line :454:1
func (t *A_arbace_go_check_summarize_fn__1685000360_A) Invoke_O_O__O(self, p1__1685000350_SHARP___1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_go_check_A_const_202.Invoke_O__O(p1__1685000350_SHARP___1))).Ref() }

func A_arbace_go_check_summarize_fn__1685000362_A_New() *A_arbace_go_check_summarize_fn__1685000362_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000362_A{}; t.Ctor(); return t }
//line :456:1
func (t *A_arbace_go_check_summarize_fn__1685000362_A) Ctor() {}
//line :456:1
func (t *A_arbace_go_check_summarize_fn__1685000362_A) Invoke_O_O__O(self, p1__1685000351_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_go_check_A_const_256.Invoke_O__O(p1__1685000351_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000351_SHARP___1), nil)).Ref() } }
func A_arbace_go_check_summarize_fn__1685000364_A_New() *A_arbace_go_check_summarize_fn__1685000364_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000364_A{}; t.Ctor(); return t }
//line :457:1
func (t *A_arbace_go_check_summarize_fn__1685000364_A) Ctor() {}
//line :457:1
func (t *A_arbace_go_check_summarize_fn__1685000364_A) Invoke_O_O__O(self, p1__1685000352_SHARP___1 any) any { var tmp1 any; var or__1927000174__auto____2 any = A_arbace_go_check_A_const_256.Invoke_O__O(p1__1685000352_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_check_A_const_82.Invoke_O__O(p1__1685000352_SHARP___1), nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_go_check_A_const_104.Invoke_O__O(p1__1685000352_SHARP___1) } else { return nil } }




func A_arbace_go_check_summarize_fn__1685000366_A_New() *A_arbace_go_check_summarize_fn__1685000366_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000366_A{}; t.Ctor(); return t }
//line :462:1
func (t *A_arbace_go_check_summarize_fn__1685000366_A) Ctor() {}
//line :462:1
func (t *A_arbace_go_check_summarize_fn__1685000366_A) Invoke_O_O__O(self, p1__1685000353_SHARP___1 any) any { var root_3038 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3038, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3040 lang.IFn; if linked_3039 == nil { ifn_3040 = lang.IFn_Cast(root_3038) } else { ifn_3040 = nil }; var arg_3041 any = p1__1685000353_SHARP___1; var arg_3042 any = A_arbace_go_check_A_const_286; if linked_3039 == nil { return ifn_3040.Invoke_O_O__O(arg_3041, arg_3042) } else { return linked_3039.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3038, arg_3041, arg_3042) } }
func A_arbace_go_check_summarize_fn__1685000368_A_New() *A_arbace_go_check_summarize_fn__1685000368_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000368_A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_go_check_summarize_fn__1685000368_A) Ctor() {}
//line :463:1
func (t *A_arbace_go_check_summarize_fn__1685000368_A) Invoke_O_O__O(self, p1__1685000354_SHARP___1 any) any { var root_3068 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3068, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3070 lang.IFn; if linked_3069 == nil { ifn_3070 = lang.IFn_Cast(root_3068) } else { ifn_3070 = nil }; var arg_3071 any = p1__1685000354_SHARP___1; var arg_3072 any = A_arbace_go_check_A_const_291; var arg_3073 any = A_arbace_go_check_A_const_22; if linked_3069 == nil { return ifn_3070.Invoke_O_O_O__O(arg_3071, arg_3072, arg_3073) } else { return linked_3069.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O_O__O(root_3068, arg_3071, arg_3072, arg_3073) } }
func A_arbace_go_check_summarize_fn__1685000370_A_New() *A_arbace_go_check_summarize_fn__1685000370_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_summarize_fn__1685000370_A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_go_check_summarize_fn__1685000370_A) Ctor() {}
//line :464:1
func (t *A_arbace_go_check_summarize_fn__1685000370_A) Invoke_O_O__O(self, p1__1685000355_SHARP___1 any) any { var root_3049 any = A_arbace_go_check_A_const_289.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_core.A_arbace_core_false_QMARK__A_fn_class); var ifn_3051 lang.IFn; if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any; var root_3053 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3053, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3055 lang.IFn; if linked_3054 == nil { ifn_3055 = lang.IFn_Cast(root_3053) } else { ifn_3055 = nil }; var arg_3056 any = p1__1685000355_SHARP___1; var arg_3057 any = A_arbace_go_check_A_const_290; if linked_3054 == nil { arg_3052 = ifn_3055.Invoke_O_O__O(arg_3056, arg_3057) } else { arg_3052 = linked_3054.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3053, arg_3056, arg_3057) }; if linked_3050 == nil { return ifn_3051.Invoke_O__O(arg_3052) } else { return linked_3050.(*aot_arbace_core.A_arbace_core_false_QMARK__A).Invoke_O_O__O(root_3049, arg_3052) } }


func A_arbace_go_check_report_errors_A_New() *A_arbace_go_check_report_errors_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_go_check_report_errors_A) Ctor() {}
//line :467:1
func (t *A_arbace_go_check_report_errors_A) Invoke_O_O__O(self, results__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000373__1685000379_A_New(); var tmp2 *jrt.Class; var fncls__3160 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000373__1685000379_A_fn_class; if


	fncls__3160 == nil { var fncls__3160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_go_check_report_errors_iter__1685000373__1685000379_A_fn_class = fncls__3160d; tmp2 = fncls__3160d } else { tmp2 = fncls__3160 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(results__0) }
//line :470:1
func A_arbace_go_check_report_errors_iter__1685000373__1685000379_A_New() *A_arbace_go_check_report_errors_iter__1685000373__1685000379_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000373__1685000379_A{}; t.Ctor(); return t }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_A) Ctor() {}
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_A) Invoke_O_O__O(self, s__1685000374__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A_New_O_O(s__1685000374__1, self); var tmp2 *jrt.Class; var fncls__3159 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A_fn_class; if fncls__3159 == nil { var fncls__3159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A_fn_class = fncls__3159d; tmp2 = fncls__3159d } else { tmp2 = fncls__3159 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :470:1
func A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A_New_O_O(p0, p1 any) *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A{}; t.Ctor_O_O(p0, p1); return t }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A) Ctor_O_O(c__s__1685000374, c__iter__1685000373 any) { t.F_s__1685000374 = c__s__1685000374; t.F_iter__1685000373 = c__iter__1685000373 }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A) Invoke_O__O(self any) any { { var s__1685000374__1 any; var t_ any = t.F_s__1685000374; t.F_s__1685000374 = nil; s__1685000374__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3075 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3077 lang.IFn; if linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var arg_3078 any = s__1685000374__1; if linked_3076 == nil { temp__1927000414__auto____2 = ifn_3077.Invoke_O__O(arg_3078) } else { temp__1927000414__auto____2 = linked_3076.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3075, arg_3078) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3079 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3079, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3081 lang.IFn; if linked_3080 == nil { ifn_3081 = lang.IFn_Cast(root_3079) } else { ifn_3081 = nil }; var arg_3082 any = xs__1927001018__auto____3; if linked_3080 == nil { r__4 = ifn_3081.Invoke_O__O(arg_3082) } else { r__4 = linked_3080.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3079, arg_3082) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3141 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A_fn_class; if fncls__3141 == nil { var fncls__3141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A_fn_class = fncls__3141d; tmp2 = fncls__3141d } else { tmp2 = fncls__3141 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3142 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3142, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3144 lang.IFn; if linked_3143 == nil { ifn_3144 = lang.IFn_Cast(root_3142) } else { ifn_3144 = nil }; var arg_3145 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_202.Invoke_O__O(r__4)); if linked_3143 == nil { fs__1927001036__auto____6 = ifn_3144.Invoke_O__O(arg_3145) } else { fs__1927001036__auto____6 = linked_3143.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3142, arg_3145) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3146 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3146, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3148 lang.IFn; if linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; var arg_3149 any = fs__1927001036__auto____6; var arg_3150 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000373); var tmp4 any; var root_3151 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3153 lang.IFn; if linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any = s__1685000374__1; if linked_3152 == nil { tmp4 = ifn_3153.Invoke_O__O(arg_3154) } else { tmp4 = linked_3152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3151, arg_3154) }; arg_3150 = tmp3.Invoke_O__O(tmp4); if linked_3147 == nil { return ifn_3148.Invoke_O_O__O(arg_3149, arg_3150) } else { return linked_3147.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3146, arg_3149, arg_3150) } } else { var tmp5 any; var root_3155 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3155, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3157 lang.IFn; if linked_3156 == nil { ifn_3157 = lang.IFn_Cast(root_3155) } else { ifn_3157 = nil }; var arg_3158 any = s__1685000374__1; if linked_3156 == nil { tmp5 = ifn_3157.Invoke_O__O(arg_3158) } else { tmp5 = linked_3156.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3155, arg_3158) }; s__1685000374__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :470:1
func A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A_New_O(p0 any) *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A{}; t.Ctor_O(p0); return t }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A) Invoke_O_O__O(self, s__1685000376__1 any) any { var tmp1 any = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A_New_O_O_O(t.F_r, s__1685000376__1, self); var tmp2 *jrt.Class; var fncls__3140 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A_fn_class; if fncls__3140 == nil { var fncls__3140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A_fn_class = fncls__3140d; tmp2 = fncls__3140d } else { tmp2 = fncls__3140 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :470:1
func A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A) Ctor_O_O_O(c__r, c__s__1685000376, c__iter__1685000375 any) { t.F_r = c__r; t.F_s__1685000376 = c__s__1685000376; t.F_iter__1685000375 = c__iter__1685000375 }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A) Invoke_O__O(self any) any { { var s__1685000376__1 any; var t_ any = t.F_s__1685000376; t.F_s__1685000376 = nil; s__1685000376__1 = t_; for { var temp__1927000414__auto____2 any; var root_3083 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3083, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3085 lang.IFn; if linked_3084 == nil { ifn_3085 = lang.IFn_Cast(root_3083) } else { ifn_3085 = nil }; var arg_3086 any = s__1685000376__1; if linked_3084 == nil { temp__1927000414__auto____2 = ifn_3085.Invoke_O__O(arg_3086) } else { temp__1927000414__auto____2 = linked_3084.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3083, arg_3086) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000376__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3087 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3087, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3089 lang.IFn; if linked_3088 == nil { ifn_3089 = lang.IFn_Cast(root_3087) } else { ifn_3089 = nil }; var arg_3090 any = s__1685000376__3; if linked_3088 == nil { tmp1 = ifn_3089.Invoke_O__O(arg_3090) } else { tmp1 = linked_3088.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3087, arg_3090) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3091 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3091, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3093 lang.IFn; if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = s__1685000376__3; if linked_3092 == nil { c__1927001037__auto____4 = ifn_3093.Invoke_O__O(arg_3094) } else { c__1927001037__auto____4 = linked_3092.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3091, arg_3094) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000378__6 any; var root_3095 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3097 lang.IFn; if linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3096 == nil { b__1685000378__6 = ifn_3097.Invoke_O__O(arg_3098) } else { b__1685000378__6 = linked_3096.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3095, arg_3098) }; var tmp2 any = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A_New_O_O_I_O(b__1685000378__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3104 *jrt.Class = A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A_fn_class; if fncls__3104 == nil { var fncls__3104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A_fn_class = fncls__3104d; tmp3 = fncls__3104d } else { tmp3 = fncls__3104 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3105 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3105, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3107 lang.IFn; if linked_3106 == nil { ifn_3107 = lang.IFn_Cast(root_3105) } else { ifn_3107 = nil }; var arg_3108 any; var root_3110 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3110, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3112 lang.IFn; if linked_3111 == nil { ifn_3112 = lang.IFn_Cast(root_3110) } else { ifn_3112 = nil }; var arg_3113 any = b__1685000378__6; if linked_3111 == nil { arg_3108 = ifn_3112.Invoke_O__O(arg_3113) } else { arg_3108 = linked_3111.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3110, arg_3113) }; var arg_3109 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000375); var tmp5 any; var root_3114 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3116 lang.IFn; if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any = s__1685000376__3; if linked_3115 == nil { tmp5 = ifn_3116.Invoke_O__O(arg_3117) } else { tmp5 = linked_3115.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3114, arg_3117) }; arg_3109 = tmp4.Invoke_O__O(tmp5); if linked_3106 == nil { return ifn_3107.Invoke_O_O__O(arg_3108, arg_3109) } else { return linked_3106.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3105, arg_3108, arg_3109) } } else { var root_3118 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3118, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3120 lang.IFn; if linked_3119 == nil { ifn_3120 = lang.IFn_Cast(root_3118) } else { ifn_3120 = nil }; var arg_3121 any; var root_3123 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3125 lang.IFn; if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = b__1685000378__6; if linked_3124 == nil { arg_3121 = ifn_3125.Invoke_O__O(arg_3126) } else { arg_3121 = linked_3124.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3123, arg_3126) }; var arg_3122 any; if linked_3119 == nil { return ifn_3120.Invoke_O_O__O(arg_3121, arg_3122) } else { return linked_3119.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3118, arg_3121, arg_3122) } } } else { var e__4 any; var root_3127 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3127, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3129 lang.IFn; if linked_3128 == nil { ifn_3129 = lang.IFn_Cast(root_3127) } else { ifn_3129 = nil }; var arg_3130 any = s__1685000376__3; if linked_3128 == nil { e__4 = ifn_3129.Invoke_O__O(arg_3130) } else { e__4 = linked_3128.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3127, arg_3130) }; var root_3131 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3131, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3133 lang.IFn; if linked_3132 == nil { ifn_3133 = lang.IFn_Cast(root_3131) } else { ifn_3133 = nil }; var arg_3134 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_100, nil, Lit_22, nil, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__4), nil, A_arbace_go_check_A_const_257.Invoke_O__O(e__4))).Ref(); var arg_3135 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000375); var tmp7 any; var root_3136 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3138 lang.IFn; if linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = s__1685000376__3; if linked_3137 == nil { tmp7 = ifn_3138.Invoke_O__O(arg_3139) } else { tmp7 = linked_3137.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3136, arg_3139) }; arg_3135 = tmp6.Invoke_O__O(tmp7); if linked_3132 == nil { return ifn_3133.Invoke_O_O__O(arg_3134, arg_3135) } else { return linked_3132.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3131, arg_3134, arg_3135) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :470:1
func A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A) Ctor_O_O_I_O(c__b__1685000378, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000378 = c__b__1685000378; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :470:1
func (t *A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A) Invoke_O__O(self any) any { { var i__1685000377__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000377__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000377__1)); var root_3099 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = t.F_b__1685000378; var arg_3103 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_100, nil, Lit_22, nil, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), nil, A_arbace_go_check_A_const_73.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_78.Invoke_O__O(e__2), nil, A_arbace_go_check_A_const_257.Invoke_O__O(e__2))).Ref(); if linked_3100 == nil { ifn_3101.Invoke_O_O__O(arg_3102, arg_3103) } else { linked_3100.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3099, arg_3102, arg_3103) }; i__1685000377__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000377__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_forms_source_A_New() *A_arbace_go_check_forms_source_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_A{}; t.Ctor(); return t }
//line :475:1
func (t *A_arbace_go_check_forms_source_A) Ctor() {}
//line :475:1
func (t *A_arbace_go_check_forms_source_A) Invoke_O_O_O__O(self, forms__0, config__1 any) any { var map__1685000391__3 any; var root_3161 any = A_arbace_go_check_A_const_292.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A_fn_class); var ifn_3163 lang.IFn; if



	linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any = forms__0; if linked_3162 == nil { map__1685000391__3 = ifn_3163.Invoke_O__O(arg_3164) } else { map__1685000391__3 = linked_3162.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_forms_A).Invoke_O_O__O(root_3161, arg_3164) }; var map__1685000391__4 any; if lang.ISeq_InstanceOf(map__1685000391__3) { var tmp1 any; var root_3165 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3165, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3167 lang.IFn; if linked_3166 == nil { ifn_3167 = lang.IFn_Cast(root_3165) } else { ifn_3167 = nil }; var arg_3168 any = map__1685000391__3; if linked_3166 == nil { tmp1 = ifn_3167.Invoke_O__O(arg_3168) } else { tmp1 = linked_3166.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3165, arg_3168) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3169 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3169, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3171 lang.IFn; if linked_3170 == nil { ifn_3171 = lang.IFn_Cast(root_3169) } else { ifn_3171 = nil }; var arg_3172 any = map__1685000391__3; if linked_3170 == nil { tmp2 = ifn_3171.Invoke_O__O(arg_3172) } else { tmp2 = linked_3170.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3169, arg_3172) }; map__1685000391__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3173 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3175 lang.IFn; if linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any = map__1685000391__3; if linked_3174 == nil { tmp3 = ifn_3175.Invoke_O__O(arg_3176) } else { tmp3 = linked_3174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3173, arg_3176) }; if jrt.J2g_Truth(tmp3) { var root_3177 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3177, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3179 lang.IFn; if linked_3178 == nil { ifn_3179 = lang.IFn_Cast(root_3177) } else { ifn_3179 = nil }; var arg_3180 any = map__1685000391__3; if linked_3178 == nil { map__1685000391__4 = ifn_3179.Invoke_O__O(arg_3180) } else { map__1685000391__4 = linked_3178.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3177, arg_3180) } } else { map__1685000391__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000391__4 = map__1685000391__3 }; var package__5 any = /*line :475:1*/lang.RT_Get_O_O__O_NoInit(map__1685000391__4, A_arbace_go_check_A_const_103); var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000391__4, A_arbace_go_check_A_const_70); var files__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000391__4, A_arbace_go_check_A_const_114); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_293.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_A_const_294; var config__8 any = tmp4.Invoke_O_O_O__O(tmp5, A_arbace_go_check_A_const_105.Invoke_O__O(package__5), config__1); var tmp6 any = A_arbace_go_check_A_const_104; var tmp7 any; var or__1927000174__auto____9 any = A_arbace_go_check_A_const_104.Invoke_O__O(package__5); if





	jrt.J2g_Truth(or__1927000174__auto____9) { tmp7 = or__1927000174__auto____9 } else { tmp7 = Lit_104 }; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_check_A_const_70; var tmp10 any; var root_3187 any = /*line :475:1*/A_arbace_go_check_A_const_295.GetRawRoot__O(); var linked_3188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3187, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_3189 lang.IFn; if





	linked_3188 == nil { ifn_3189 = lang.IFn_Cast(root_3187) } else { ifn_3189 = nil }; var arg_3190 any = name__6; if linked_3188 == nil { tmp10 = ifn_3189.Invoke_O__O(arg_3190) } else { tmp10 = linked_3188.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_3187, arg_3190) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_check_A_const_105; var tmp13 any = A_arbace_go_check_A_const_81; var tmp14 any = A_arbace_go_check_A_const_197; var tmp15 any; var root_3191 any = /*line :475:1*/A_arbace_go_check_A_const_137.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3193 lang.IFn; if






	linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any; var tmp16 any = A_arbace_go_check_forms_source_fn__1685000393_A_New(); var tmp17 *jrt.Class; var fncls__3208 *jrt.Class = A_arbace_go_check_forms_source_fn__1685000393_A_fn_class; if fncls__3208 == nil { var fncls__3208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_go_check_forms_source_fn__1685000393_A_fn_class = fncls__3208d; tmp17 = fncls__3208d } else { tmp17 = fncls__3208 }; arg_3194 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var arg_3195 any = forms__0; if linked_3192 == nil { tmp15 = ifn_3193.Invoke_O_O__O(arg_3194, arg_3195) } else { tmp15 = linked_3192.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3191, arg_3194, arg_3195) }; var tmp18 any = tmp15; var tmp19 any = A_arbace_go_check_A_const_114; var tmp20 any; var root_3209 any = /*line :475:1*/A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3211 lang.IFn; if







	linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any; var iter__1927001039__auto____9 any; var tmp21 any = A_arbace_go_check_forms_source_iter__1685000395__1685000399_A_New(); var tmp22 *jrt.Class; var fncls__3283 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000395__1685000399_A_fn_class; if fncls__3283 == nil { var fncls__3283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_go_check_forms_source_iter__1685000395__1685000399_A_fn_class = fncls__3283d; tmp22 = fncls__3283d } else { tmp22 = fncls__3283 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_3212 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(files__7); if linked_3210 == nil { tmp20 = ifn_3211.Invoke_O__O(arg_3212) } else { tmp20 = linked_3210.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3209, arg_3212) }; return /*line :475:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, config__8, tmp13, package__5, tmp14, tmp18, tmp19, tmp20)) }






func A_arbace_go_check_forms_source_fn__1685000393_A_New() *A_arbace_go_check_forms_source_fn__1685000393_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_fn__1685000393_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_go_check_forms_source_fn__1685000393_A) Ctor() {}
//line :482:1
func (t *A_arbace_go_check_forms_source_fn__1685000393_A) Invoke_O_O__O(self, p1__1685000390_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_3196 any = A_arbace_go_check_A_const_23.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3198 lang.IFn; if linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; var arg_3199 any = p1__1685000390_SHARP___1; if linked_3197 == nil { and__1927000168__auto____2 = ifn_3198.Invoke_O__O(arg_3199) } else { and__1927000168__auto____2 = linked_3197.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3196, arg_3199) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_A_const_296; var tmp3 any; var root_3200 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3200, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3202 lang.IFn; if linked_3201 == nil { ifn_3202 = lang.IFn_Cast(root_3200) } else { ifn_3202 = nil }; var arg_3203 any = p1__1685000390_SHARP___1; if linked_3201 == nil { tmp3 = ifn_3202.Invoke_O__O(arg_3203) } else { tmp3 = linked_3201.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3200, arg_3203) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_3204 any = A_arbace_go_check_A_const_79.GetRawRoot__O(); var linked_3205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3204, aot_arbace_go_check_code.A_arbace_go_check_code_fline_A_fn_class); var ifn_3206 lang.IFn; if linked_3205 == nil { ifn_3206 = lang.IFn_Cast(root_3204) } else { ifn_3206 = nil }; var arg_3207 any = p1__1685000390_SHARP___1; if linked_3205 == nil { return ifn_3206.Invoke_O__O(arg_3207) } else { return linked_3205.(*aot_arbace_go_check_code.A_arbace_go_check_code_fline_A).Invoke_O_O__O(root_3204, arg_3207) } } else { return nil } }
func A_arbace_go_check_forms_source_iter__1685000395__1685000399_A_New() *A_arbace_go_check_forms_source_iter__1685000395__1685000399_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000395__1685000399_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_go_check_forms_source_iter__1685000395__1685000399_A) Ctor() {}
//line :483:1
func (t *A_arbace_go_check_forms_source_iter__1685000395__1685000399_A) Invoke_O_O__O(self, s__1685000396__1 any) any { var tmp1 any = A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A_New_O_O(s__1685000396__1, self); var tmp2 *jrt.Class; var fncls__3282 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A_fn_class; if fncls__3282 == nil { var fncls__3282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A_fn_class = fncls__3282d; tmp2 = fncls__3282d } else { tmp2 = fncls__3282 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :483:1
func A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A_New_O_O(p0, p1 any) *A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A{}; t.Ctor_O_O(p0, p1); return t }
//line :483:1
func (t *A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A) Ctor_O_O(c__s__1685000396, c__iter__1685000395 any) { t.F_s__1685000396 = c__s__1685000396; t.F_iter__1685000395 = c__iter__1685000395 }
//line :483:1
func (t *A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A) Invoke_O__O(self any) any { { var s__1685000396__1 any; var t_ any = t.F_s__1685000396; t.F_s__1685000396 = nil; s__1685000396__1 = t_; for { var temp__1927000414__auto____2 any; var root_3213 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any = s__1685000396__1; if linked_3214 == nil { temp__1927000414__auto____2 = ifn_3215.Invoke_O__O(arg_3216) } else { temp__1927000414__auto____2 = linked_3214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3213, arg_3216) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000396__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3217 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3219 lang.IFn; if linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any = s__1685000396__3; if linked_3218 == nil { tmp1 = ifn_3219.Invoke_O__O(arg_3220) } else { tmp1 = linked_3218.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3217, arg_3220) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3221 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3223 lang.IFn; if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = s__1685000396__3; if linked_3222 == nil { c__1927001037__auto____4 = ifn_3223.Invoke_O__O(arg_3224) } else { c__1927001037__auto____4 = linked_3222.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3221, arg_3224) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000398__6 any; var root_3225 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3225, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3227 lang.IFn; if linked_3226 == nil { ifn_3227 = lang.IFn_Cast(root_3225) } else { ifn_3227 = nil }; var arg_3228 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3226 == nil { b__1685000398__6 = ifn_3227.Invoke_O__O(arg_3228) } else { b__1685000398__6 = linked_3226.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3225, arg_3228) }; var tmp2 any = A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A_New_O_I_O(b__1685000398__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3240 *jrt.Class = A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A_fn_class; if fncls__3240 == nil { var fncls__3240d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A_fn_class = fncls__3240d; tmp3 = fncls__3240d } else { tmp3 = fncls__3240 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3241 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3243 lang.IFn; if linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any; var root_3246 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3246, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3248 lang.IFn; if linked_3247 == nil { ifn_3248 = lang.IFn_Cast(root_3246) } else { ifn_3248 = nil }; var arg_3249 any = b__1685000398__6; if linked_3247 == nil { arg_3244 = ifn_3248.Invoke_O__O(arg_3249) } else { arg_3244 = linked_3247.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3246, arg_3249) }; var arg_3245 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000395); var tmp5 any; var root_3250 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3250, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3252 lang.IFn; if linked_3251 == nil { ifn_3252 = lang.IFn_Cast(root_3250) } else { ifn_3252 = nil }; var arg_3253 any = s__1685000396__3; if linked_3251 == nil { tmp5 = ifn_3252.Invoke_O__O(arg_3253) } else { tmp5 = linked_3251.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3250, arg_3253) }; arg_3245 = tmp4.Invoke_O__O(tmp5); if linked_3242 == nil { return ifn_3243.Invoke_O_O__O(arg_3244, arg_3245) } else { return linked_3242.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3241, arg_3244, arg_3245) } } else { var root_3254 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3254, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3256 lang.IFn; if linked_3255 == nil { ifn_3256 = lang.IFn_Cast(root_3254) } else { ifn_3256 = nil }; var arg_3257 any; var root_3259 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3261 lang.IFn; if linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; var arg_3262 any = b__1685000398__6; if linked_3260 == nil { arg_3257 = ifn_3261.Invoke_O__O(arg_3262) } else { arg_3257 = linked_3260.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3259, arg_3262) }; var arg_3258 any; if linked_3255 == nil { return ifn_3256.Invoke_O_O__O(arg_3257, arg_3258) } else { return linked_3255.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3254, arg_3257, arg_3258) } } } else { var fi__4 any; var root_3263 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3263, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3265 lang.IFn; if linked_3264 == nil { ifn_3265 = lang.IFn_Cast(root_3263) } else { ifn_3265 = nil }; var arg_3266 any = s__1685000396__3; if linked_3264 == nil { fi__4 = ifn_3265.Invoke_O__O(arg_3266) } else { fi__4 = linked_3264.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3263, arg_3266) }; var root_3267 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3267, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3269 lang.IFn; if linked_3268 == nil { ifn_3269 = lang.IFn_Cast(root_3267) } else { ifn_3269 = nil }; var arg_3270 any; var root_3272 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3272, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = fi__4; var arg_3276 any = A_arbace_go_check_A_const_81; var arg_3277 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__4); if linked_3273 == nil { arg_3270 = ifn_3274.Invoke_O_O_O__O(arg_3275, arg_3276, arg_3277) } else { arg_3270 = linked_3273.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3272, arg_3275, arg_3276, arg_3277) }; var arg_3271 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000395); var tmp7 any; var root_3278 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3278, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3280 lang.IFn; if linked_3279 == nil { ifn_3280 = lang.IFn_Cast(root_3278) } else { ifn_3280 = nil }; var arg_3281 any = s__1685000396__3; if linked_3279 == nil { tmp7 = ifn_3280.Invoke_O__O(arg_3281) } else { tmp7 = linked_3279.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3278, arg_3281) }; arg_3271 = tmp6.Invoke_O__O(tmp7); if linked_3268 == nil { return ifn_3269.Invoke_O_O__O(arg_3270, arg_3271) } else { return linked_3268.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3267, arg_3270, arg_3271) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :483:1
func A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :483:1
func (t *A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A) Ctor_O_I_O(c__b__1685000398 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000398 = c__b__1685000398; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :483:1
func (t *A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A) Invoke_O__O(self any) any { { var i__1685000397__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000397__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000397__1)); var root_3229 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3229, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3231 lang.IFn; if linked_3230 == nil { ifn_3231 = lang.IFn_Cast(root_3229) } else { ifn_3231 = nil }; var arg_3232 any = t.F_b__1685000398; var arg_3233 any; var root_3234 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3234, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3236 lang.IFn; if linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any = fi__2; var arg_3238 any = A_arbace_go_check_A_const_81; var arg_3239 any = A_arbace_go_check_A_const_81.Invoke_O__O(fi__2); if linked_3235 == nil { arg_3233 = ifn_3236.Invoke_O_O_O__O(arg_3237, arg_3238, arg_3239) } else { arg_3233 = linked_3235.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3234, arg_3237, arg_3238, arg_3239) }; if linked_3230 == nil { ifn_3231.Invoke_O_O__O(arg_3232, arg_3233) } else { linked_3230.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3229, arg_3232, arg_3233) }; i__1685000397__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000397__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_read_string_forms_A_New() *A_arbace_go_check_read_string_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_read_string_forms_A{}; t.Ctor(); return t }
//line :485:1
func (t *A_arbace_go_check_read_string_forms_A) Ctor() {}
//line :485:1
func (t *A_arbace_go_check_read_string_forms_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var eof__3 any = jrt.Object_New(); var root_3293 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3293, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3295 lang.IFn; if




	linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_298, jrt.Boolean_FALSE.Ref()); if linked_3294 == nil { ifn_3295.Invoke_O__O(arg_3296) } else { linked_3294.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3293, arg_3296) }; var tmp1 any; tmp3 := /*line :485:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__7 any; var root_3284 any = A_arbace_go_check_A_const_297.GetRawRoot__O(); var linked_3285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3284, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_3286 lang.IFn






		if linked_3285 == nil { ifn_3286 = lang.IFn_Cast(root_3284) } else { ifn_3286 = nil }; var arg_3287 any = r__2; var arg_3288 any = jrt.Boolean_FALSE.Ref(); var arg_3289 any = eof__3; if linked_3285 == nil { f__7 = ifn_3286.Invoke_O_O_O__O(arg_3287, arg_3288, arg_3289) } else { f__7 = linked_3285.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_3284, arg_3287, arg_3288, arg_3289) }
		if lang.Util_Identical_O_O__Z_NoInit(f__7, eof__3) { tmp1 = acc__6 } else { var tmp2 any; var root_3302 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3304 lang.IFn; if linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any = acc__6; var arg_3306 any = f__7; if linked_3303 == nil { tmp2 = ifn_3304.Invoke_O_O__O(arg_3305, arg_3306) } else { tmp2 = linked_3303.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3302, arg_3305, arg_3306) }; acc__6 = tmp2; continue L1 }
//line :485:1
		break L1 } }; return nil }(); var root_3290 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_3291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3290, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3292 lang.IFn; if




	linked_3291 == nil { ifn_3292 = lang.IFn_Cast(root_3290) } else { ifn_3292 = nil }; if linked_3291 == nil { ifn_3292.Invoke__O() } else { linked_3291.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3290) }; if /*line :485:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_go_check_std_A_New() *A_arbace_go_check_std_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_std_A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_go_check_std_A) Ctor() {}
//line :497:1
func (t *A_arbace_go_check_std_A) Invoke_O_O__O(self, corpus__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_3307 any = A_arbace_go_check_A_const_14.GetRawRoot__O(); var linked_3308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3307, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3309 lang.IFn; if


	linked_3308 == nil { ifn_3309 = lang.IFn_Cast(root_3307) } else { ifn_3309 = nil }; var arg_3310 any = A_arbace_go_check_A_const_299.GetRawRoot__O(); if linked_3308 == nil { tmp1 = ifn_3309.Invoke_O__O(arg_3310) } else { tmp1 = linked_3308.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3307, arg_3310) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, corpus__0); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var s__3 any; var root_3311 any = A_arbace_go_check_A_const_261.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, A_arbace_go_check_std_session_A_fn_class); var ifn_3313 lang.IFn
		if linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any; var root_3315 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_3316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3315, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3317 lang.IFn; if linked_3316 == nil { ifn_3317 = lang.IFn_Cast(root_3315) } else { ifn_3317 = nil }; var arg_3318 any = corpus__0; if linked_3316 == nil { arg_3314 = ifn_3317.Invoke_O__O(arg_3318) } else { arg_3314 = linked_3316.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3315, arg_3318) }; if linked_3312 == nil { s__3 = ifn_3313.Invoke_O__O(arg_3314) } else { s__3 = linked_3312.(*A_arbace_go_check_std_session_A).Invoke_O_O__O(root_3311, arg_3314) }
		var root_3319 any = A_arbace_go_check_A_const_300.GetRawRoot__O(); var linked_3320 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3319, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_3321 lang.IFn; if linked_3320 == nil { ifn_3321 = lang.IFn_Cast(root_3319) } else { ifn_3321 = nil }; var arg_3322 any = A_arbace_go_check_A_const_299.GetRawRoot__O(); var arg_3323 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var arg_3324 any = corpus__0; var arg_3325 any = s__3; if linked_3320 == nil { ifn_3321.Invoke_O_O_O_O__O(arg_3322, arg_3323, arg_3324, arg_3325) } else { linked_3320.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_3319, arg_3322, arg_3323, arg_3324, arg_3325) }
//line :500:1
		return s__3 } }




func A_arbace_go_check_check_forms_A_New() *A_arbace_go_check_check_forms_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_check_forms_A{}; t.Ctor(); return t }
//line :505:1
func (t *A_arbace_go_check_check_forms_A) Ctor() {}
//line :505:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O_O_O__O(self, forms__0, corpus__1, opts__2 any) any { var s__4 any; var root_3326 any = A_arbace_go_check_A_const_301.GetRawRoot__O(); var linked_3327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3326, A_arbace_go_check_std_A_fn_class); var ifn_3328 lang.IFn; if




	linked_3327 == nil { ifn_3328 = lang.IFn_Cast(root_3326) } else { ifn_3328 = nil }; var arg_3329 any = corpus__1; if linked_3327 == nil { s__4 = ifn_3328.Invoke_O__O(arg_3329) } else { s__4 = linked_3327.(*A_arbace_go_check_std_A).Invoke_O_O__O(root_3326, arg_3329) }; var src__5 any; var root_3330 any = /*line :505:1*/A_arbace_go_check_A_const_302.GetRawRoot__O(); var linked_3331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3330, A_arbace_go_check_forms_source_A_fn_class); var ifn_3332 lang.IFn; if





	linked_3331 == nil { ifn_3332 = lang.IFn_Cast(root_3330) } else { ifn_3332 = nil }; var arg_3333 any = forms__0; var arg_3334 any; var tmp1 *lang.Keyword = A_arbace_go_check_A_const_105; var tmp2 any; var root_3335 any = A_arbace_go_check_A_const_260.GetRawRoot__O(); var linked_3336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3335, A_arbace_go_check_corpus_config_A_fn_class); var ifn_3337 lang.IFn; if linked_3336 == nil { ifn_3337 = lang.IFn_Cast(root_3335) } else { ifn_3337 = nil }; var arg_3338 any = corpus__1; if linked_3336 == nil { tmp2 = ifn_3337.Invoke_O__O(arg_3338) } else { tmp2 = linked_3336.(*A_arbace_go_check_corpus_config_A).Invoke_O_O__O(root_3335, arg_3338) }; arg_3334 = tmp1.Invoke_O__O(tmp2); if linked_3331 == nil { src__5 = ifn_3332.Invoke_O_O__O(arg_3333, arg_3334) } else { src__5 = linked_3331.(*A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_3330, arg_3333, arg_3334) }; var pkg__6 any; var tmp3 lang.IFn = /*line :505:1*/lang.IFn_Cast(A_arbace_go_check_A_const_229.GetRawRoot__O()); var tmp4 any; var root_3346 any = A_arbace_go_check_A_const_230.GetRawRoot__O(); var linked_3347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3346, A_arbace_go_check_resolver_A_fn_class); var ifn_3348 lang.IFn; if






	linked_3347 == nil { ifn_3348 = lang.IFn_Cast(root_3346) } else { ifn_3348 = nil }; var arg_3349 any = s__4; var arg_3350 any = src__5; var arg_3351 any = lang.PersistentVector_EMPTY.Ref(); if linked_3347 == nil { tmp4 = ifn_3348.Invoke_O_O_O__O(arg_3349, arg_3350, arg_3351) } else { tmp4 = linked_3347.(*A_arbace_go_check_resolver_A).Invoke_O_O_O_O__O(root_3346, arg_3349, arg_3350, arg_3351) }; var tmp5 any = tmp4; var tmp6 any = A_arbace_go_check_A_const_102; pkg__6 = tmp3.Invoke_O_O_O_O__O(src__5, tmp5, tmp6, A_arbace_go_check_A_const_102.Invoke_O__O(opts__2)); var root_3352 any =
	A_arbace_go_check_A_const_92.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3352, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_3354 lang.IFn; if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any = pkg__6; var arg_3356 any = A_arbace_go_check_A_const_201; if linked_3353 == nil { return ifn_3354.Invoke_O_O__O(arg_3355, arg_3356) } else { return linked_3353.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_3352, arg_3355, arg_3356) } }
//line :505:1
func (t *A_arbace_go_check_check_forms_A) Invoke_O_O__O(self, forms__0 any) any {


	var root_3357 any = A_arbace_go_check_A_const_303.GetRawRoot__O(); var linked_3358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3357, A_arbace_go_check_check_forms_A_fn_class); var ifn_3359 lang.IFn; if linked_3358 == nil { ifn_3359 = lang.IFn_Cast(root_3357) } else { ifn_3359 = nil }; var arg_3360 any = forms__0; var arg_3361 any = Lit_50; var arg_3362 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_3358 == nil { return ifn_3359.Invoke_O_O_O__O(arg_3360, arg_3361, arg_3362) } else { return linked_3358.(*A_arbace_go_check_check_forms_A).Invoke_O_O_O_O__O(root_3357, arg_3360, arg_3361, arg_3362)
	}
}










func A_arbace_go_check_write_edn_A_New() *A_arbace_go_check_write_edn_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_go_check_write_edn_A) Ctor() {}
//line :521:1
func (t *A_arbace_go_check_write_edn_A) Invoke_O_O_O__O(self, path__0, x__1 any) any {
	lang.IFn_Cast(A_arbace_go_check_A_const_308.GetRawRoot__O()).Invoke_O__O(path__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_304.GetRawRoot__O()); var tmp2 any; var s__1927001093__auto____3 any = jrt.StringWriter_New(); var root_3380 any = A_arbace_go_check_A_const_155.GetRawRoot__O(); var linked_3381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3380, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3382 lang.IFn; if linked_3381 == nil { ifn_3382 = lang.IFn_Cast(root_3380) } else { ifn_3382 = nil }; var arg_3383 any = lang.IFn_Cast(A_arbace_go_check_A_const_156.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_A_const_307, s__1927001093__auto____3); if linked_3381 == nil { ifn_3382.Invoke_O__O(arg_3383) } else { linked_3381.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3380, arg_3383) }; var tmp3 any = A_arbace_go_check_write_edn_fn__1685000409_A_New_O_O(s__1927001093__auto____3, x__1); var tmp4 *jrt.Class; var fncls__3379 *jrt.Class = A_arbace_go_check_write_edn_fn__1685000409_A_fn_class; if fncls__3379 == nil { var fncls__3379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_check_write_edn_fn__1685000409_A_fn_class = fncls__3379d; tmp4 = fncls__3379d } else { tmp4 = fncls__3379 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); return tmp1.Invoke_O_O__O(path__0, tmp2) }
//line :523:1
func A_arbace_go_check_write_edn_fn__1685000409_A_New_O_O(p0, p1 any) *A_arbace_go_check_write_edn_fn__1685000409_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_write_edn_fn__1685000409_A{}; t.Ctor_O_O(p0, p1); return t }
//line :523:1
func (t *A_arbace_go_check_write_edn_fn__1685000409_A) Ctor_O_O(c__s__1927001093__auto__, c__x any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_x = c__x }
//line :523:1
func (t *A_arbace_go_check_write_edn_fn__1685000409_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3375 any = A_arbace_go_check_A_const_306.GetRawRoot__O(); var linked_3376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3375, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_3377 lang.IFn; if linked_3376 == nil { ifn_3377 = lang.IFn_Cast(root_3375) } else { ifn_3377 = nil }; var arg_3378 any; var t_ any = t.F_x; t.F_x = nil; arg_3378 = t_; if linked_3376 == nil { ifn_3377.Invoke_O__O(arg_3378) } else { linked_3376.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_3375, arg_3378) }; var root_3368 any = A_arbace_go_check_A_const_305.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3368, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_3370 lang.IFn; if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_3371 = t__2; if linked_3369 == nil { tmp1 = ifn_3370.Invoke_O__O(arg_3371) } else { tmp1 = linked_3369.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_3368, arg_3371) } }; return nil }(); var root_3372 any = A_arbace_go_check_A_const_154.GetRawRoot__O(); var linked_3373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3372, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3374 lang.IFn; if linked_3373 == nil { ifn_3374 = lang.IFn_Cast(root_3372) } else { ifn_3374 = nil }; if linked_3373 == nil { ifn_3374.Invoke__O() } else { linked_3373.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3372) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_go_check_reference_path_A_New() *A_arbace_go_check_reference_path_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_reference_path_A{}; t.Ctor(); return t }
//line :525:1
func (t *A_arbace_go_check_reference_path_A) Ctor() {}
//line :525:1
func (t *A_arbace_go_check_reference_path_A) Invoke_O_O__O(self, corpus__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil, corpus__0, nil)).Ref() }

func A_arbace_go_check_annotations_A_New() *A_arbace_go_check_annotations_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_A{}; t.Ctor(); return t }
//line :527:1
func (t *A_arbace_go_check_annotations_A) Ctor() {}
//line :527:1
func (t *A_arbace_go_check_annotations_A) Invoke_O_O_O__O(self, corpus__0, p__1685000413__1 any) any { var map__1685000414__3 any = p__1685000413__1; var map__1685000414__4 any; if lang.ISeq_InstanceOf(map__1685000414__3) { var tmp1 any; var root_3393 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3393, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3395 lang.IFn; if linked_3394 == nil { ifn_3395 = lang.IFn_Cast(root_3393) } else { ifn_3395 = nil }; var arg_3396 any = map__1685000414__3; if linked_3394 == nil { tmp1 = ifn_3395.Invoke_O__O(arg_3396) } else { tmp1 = linked_3394.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3393, arg_3396) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_3397 any = A_arbace_go_check_A_const_101.GetRawRoot__O(); var linked_3398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3397, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3399 lang.IFn; if linked_3398 == nil { ifn_3399 = lang.IFn_Cast(root_3397) } else { ifn_3399 = nil }; var arg_3400 any = map__1685000414__3; if linked_3398 == nil { tmp2 = ifn_3399.Invoke_O__O(arg_3400) } else { tmp2 = linked_3398.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3397, arg_3400) }; map__1685000414__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_3401 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3403 lang.IFn; if linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; var arg_3404 any = map__1685000414__3; if linked_3402 == nil { tmp3 = ifn_3403.Invoke_O__O(arg_3404) } else { tmp3 = linked_3402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3401, arg_3404) }; if jrt.J2g_Truth(tmp3) { var root_3405 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3405, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3407 lang.IFn; if linked_3406 == nil { ifn_3407 = lang.IFn_Cast(root_3405) } else { ifn_3407 = nil }; var arg_3408 any = map__1685000414__3; if linked_3406 == nil { map__1685000414__4 = ifn_3407.Invoke_O__O(arg_3408) } else { map__1685000414__4 = linked_3406.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3405, arg_3408) } } else { map__1685000414__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1685000414__4 = map__1685000414__3 }; var jobs__5 any = lang.RT_Get_O_O__O_NoInit(map__1685000414__4, A_arbace_go_check_A_const_309); var record__6 any = lang.RT_Get_O_O__O_NoInit(map__1685000414__4, A_arbace_go_check_A_const_310); var work__7 any = lang.RT_Get_O_O__O_NoInit(map__1685000414__4, A_arbace_go_check_A_const_311); var t0__8 int64 = jrt.System_NanoTime__J(); var rs__9 any; var root_3409 any = A_arbace_go_check_A_const_312.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, A_arbace_go_check_check_corpus_A_fn_class); var ifn_3411 lang.IFn; if






	linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any = corpus__0; var arg_3413 any = jobs__5; if linked_3410 == nil { rs__9 = ifn_3411.Invoke_O_O__O(arg_3412, arg_3413) } else { rs__9 = linked_3410.(*A_arbace_go_check_check_corpus_A).Invoke_O_O_O__O(root_3409, arg_3412, arg_3413) }; var sm__10 any; var root_3414 any = /*line :527:1*/A_arbace_go_check_A_const_313.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, A_arbace_go_check_summarize_A_fn_class); var ifn_3416 lang.IFn; if







	linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any = corpus__0; var arg_3418 any = rs__9; if linked_3415 == nil { sm__10 = ifn_3416.Invoke_O_O__O(arg_3417, arg_3418) } else { sm__10 = linked_3415.(*A_arbace_go_check_summarize_A).Invoke_O_O_O__O(root_3414, arg_3417, arg_3418) }; var secs__11 float64 = /*line :527:1*/lang.Numbers_Divide_J_D__D_NoInit(jrt.Math_Round_D__J(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__8), 1.0e7)), 100.0); var ref_file__12 any; var tmp4 *jrt.Class = A_arbace_go_check_A_const_314; var tmp5 any; var root_3419 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3419, A_arbace_go_check_reference_path_A_fn_class); var ifn_3421 lang.IFn; if









	linked_3420 == nil { ifn_3421 = lang.IFn_Cast(root_3419) } else { ifn_3421 = nil }; var arg_3422 any = corpus__0; if linked_3420 == nil { tmp5 = ifn_3421.Invoke_O__O(arg_3422) } else { tmp5 = linked_3420.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3419, arg_3422) }; ref_file__12 = /*line :527:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5)); var ref__13 any; if










	jrt.NN(jrt.File_Cast(ref_file__12)).IsFile__Z() { var root_3423 any = A_arbace_go_check_A_const_316.GetRawRoot__O(); var linked_3424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3423, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_3425 lang.IFn; if linked_3424 == nil { ifn_3425 = lang.IFn_Cast(root_3423) } else { ifn_3425 = nil }; var arg_3426 any = lang.IFn_Cast(A_arbace_go_check_A_const_317.GetRawRoot__O()).Invoke_O__O(ref_file__12); if linked_3424 == nil { ref__13 = ifn_3425.Invoke_O__O(arg_3426) } else { ref__13 = linked_3424.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_3423, arg_3426) } } else { ref__13 = nil }; var clean__14 any; var and__1927000168__auto____14 bool; var na_3431 any = /*line :527:1*/A_arbace_go_check_A_const_202.Invoke_O__O(sm__10); if











	jrt.Long_InstanceOf(na_3431) { var n0_3432 int64 = jrt.NN(jrt.Long_Cast(na_3431)).LongValue__J(); and__1927000168__auto____14 = n0_3432 == 0 } else { if jrt.Double_InstanceOf(na_3431) { var n0_3432_2 float64 = jrt.NN(jrt.Double_Cast(na_3431)).DoubleValue__D(); and__1927000168__auto____14 = n0_3432_2 == 0.0 } else { and__1927000168__auto____14 = lang.Numbers_IsZero_O__Z_NoInit(na_3431) } }; if and__1927000168__auto____14 { var and__1927000168__auto____15 bool; var na_3433 any = A_arbace_go_check_A_const_280.Invoke_O__O(sm__10); if jrt.Long_InstanceOf(na_3433) { var n0_3434 int64 = jrt.NN(jrt.Long_Cast(na_3433)).LongValue__J(); and__1927000168__auto____15 = n0_3434 == 0 } else { if jrt.Double_InstanceOf(na_3433) { var n0_3434_2 float64 = jrt.NN(jrt.Double_Cast(na_3433)).DoubleValue__D(); and__1927000168__auto____15 = n0_3434_2 == 0.0 } else { and__1927000168__auto____15 = lang.Numbers_IsZero_O__Z_NoInit(na_3433) } }; if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_3435 any = A_arbace_go_check_A_const_268.GetRawRoot__O(); var linked_3436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3435, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3437 lang.IFn; if linked_3436 == nil { ifn_3437 = lang.IFn_Cast(root_3435) } else { ifn_3437 = nil }; var arg_3438 any; var root_3439 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3439, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3441 lang.IFn; if linked_3440 == nil { ifn_3441 = lang.IFn_Cast(root_3439) } else { ifn_3441 = nil }; var arg_3442 any = sm__10; var arg_3443 any = A_arbace_go_check_A_const_318; if linked_3440 == nil { arg_3438 = ifn_3441.Invoke_O_O__O(arg_3442, arg_3443) } else { arg_3438 = linked_3440.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3439, arg_3442, arg_3443) }; if linked_3436 == nil { and__1927000168__auto____16 = ifn_3437.Invoke_O__O(arg_3438) } else { and__1927000168__auto____16 = linked_3436.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3435, arg_3438) }; if jrt.J2g_Truth(and__1927000168__auto____16) {
		var tmp6 bool; var na_3444 any; var root_3445 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3445, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3447 lang.IFn; if linked_3446 == nil { ifn_3447 = lang.IFn_Cast(root_3445) } else { ifn_3447 = nil }; var arg_3448 any = sm__10; var arg_3449 any = A_arbace_go_check_A_const_319; if linked_3446 == nil { na_3444 = ifn_3447.Invoke_O_O__O(arg_3448, arg_3449) } else { na_3444 = linked_3446.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3445, arg_3448, arg_3449) }; if jrt.Long_InstanceOf(na_3444) { var n0_3450 int64 = jrt.NN(jrt.Long_Cast(na_3444)).LongValue__J(); tmp6 = n0_3450 == 0 } else { if jrt.Double_InstanceOf(na_3444) { var n0_3450_2 float64 = jrt.NN(jrt.Double_Cast(na_3444)).DoubleValue__D(); tmp6 = n0_3450_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_3444) } }; clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else {
//line :539:1
			clean__14 = and__1927000168__auto____16 } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { clean__14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; var same__15 bool; var tmp7 any; var root_3451 any = /*line :527:1*/A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3453 lang.IFn; if













	linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any = ref__13; var arg_3455 any = A_arbace_go_check_A_const_320; if linked_3452 == nil { tmp7 = ifn_3453.Invoke_O_O__O(arg_3454, arg_3455) } else { tmp7 = linked_3452.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3451, arg_3454, arg_3455) }; var tmp8 any = tmp7; var tmp9 any; var root_3456 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_3457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3456, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3458 lang.IFn; if linked_3457 == nil { ifn_3458 = lang.IFn_Cast(root_3456) } else { ifn_3458 = nil }; var arg_3459 any = sm__10; var arg_3460 any = A_arbace_go_check_A_const_282; if linked_3457 == nil { tmp9 = ifn_3458.Invoke_O_O__O(arg_3459, arg_3460) } else { tmp9 = linked_3457.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3456, arg_3459, arg_3460) }; same__15 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); var root_3469 any =
	A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3469, A_arbace_go_check_write_edn_A_fn_class); var ifn_3471 lang.IFn; if linked_3470 == nil { ifn_3471 = lang.IFn_Cast(root_3469) } else { ifn_3471 = nil }; var arg_3472 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, work__7, nil, corpus__0, nil)).Ref(); var arg_3473 any; var tmp10 any = A_arbace_go_check_A_const_322; var tmp11 any = A_arbace_go_check_A_const_323; var tmp12 any = jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref(); var tmp13 any = A_arbace_go_check_A_const_202; var tmp14 any; var root_3474 any = A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3476 lang.IFn; if

	linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any; var root_3478 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3478, A_arbace_go_check_report_errors_A_fn_class); var ifn_3480 lang.IFn; if linked_3479 == nil { ifn_3480 = lang.IFn_Cast(root_3478) } else { ifn_3480 = nil }; var arg_3481 any = rs__9; if linked_3479 == nil { arg_3477 = ifn_3480.Invoke_O__O(arg_3481) } else { arg_3477 = linked_3479.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3478, arg_3481) }; if linked_3475 == nil { tmp14 = ifn_3476.Invoke_O__O(arg_3477) } else { tmp14 = linked_3475.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3474, arg_3477) }; var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_A_const_152; var tmp17 any; var root_3482 any = /*line :542:1*/A_arbace_go_check_A_const_203.GetRawRoot__O(); var linked_3483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3482, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3484 lang.IFn; if


	linked_3483 == nil { ifn_3484 = lang.IFn_Cast(root_3482) } else { ifn_3484 = nil }; var arg_3485 any; var iter__1927001039__auto____16 any; var tmp18 any = A_arbace_go_check_annotations_iter__1685000416__1685000422_A_New(); var tmp19 *jrt.Class; var fncls__3571 *jrt.Class = A_arbace_go_check_annotations_iter__1685000416__1685000422_A_fn_class; if fncls__3571 == nil { var fncls__3571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_annotations_iter__1685000416__1685000422_A_fn_class = fncls__3571d; tmp19 = fncls__3571d } else { tmp19 = fncls__3571 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); arg_3485 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(rs__9); if linked_3483 == nil { tmp17 = ifn_3484.Invoke_O__O(arg_3485) } else { tmp17 = linked_3483.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3482, arg_3485) }; arg_3473 = /*line :542:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, sm__10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp17)); if linked_3470 == nil { ifn_3471.Invoke_O_O__O(arg_3472, arg_3473) } else { linked_3470.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3469, arg_3472, arg_3473) }; var tmp20 lang.IFn =



	lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_199.GetRawRoot__O()); var tmp22 any = A_arbace_go_check_A_const_277.Invoke_O__O(sm__10); var tmp23 any; var root_3589 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3591 lang.IFn; if
	linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var arg_3592 any = sm__10; var arg_3593 any = A_arbace_go_check_A_const_326; if linked_3590 == nil { tmp23 = ifn_3591.Invoke_O_O__O(arg_3592, arg_3593) } else { tmp23 = linked_3590.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3589, arg_3592, arg_3593) }; var tmp24 any = tmp23; var tmp25 any; var root_3594 any = /*line :546:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3594, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3596 lang.IFn; if
	linked_3595 == nil { ifn_3596 = lang.IFn_Cast(root_3594) } else { ifn_3596 = nil }; var arg_3597 any = sm__10; var arg_3598 any = A_arbace_go_check_A_const_327; if linked_3595 == nil { tmp25 = ifn_3596.Invoke_O_O__O(arg_3597, arg_3598) } else { tmp25 = linked_3595.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3594, arg_3597, arg_3598) }; var tmp26 any = tmp25; var tmp27 any = /*line :546:1*/A_arbace_go_check_A_const_202.Invoke_O__O(sm__10); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_200.GetRawRoot__O()); var tmp29 any; var root_3603 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3603, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3605 lang.IFn; if

	linked_3604 == nil { ifn_3605 = lang.IFn_Cast(root_3603) } else { ifn_3605 = nil }; var arg_3606 any = sm__10; var arg_3607 any = A_arbace_go_check_A_const_328; if linked_3604 == nil { tmp29 = ifn_3605.Invoke_O_O__O(arg_3606, arg_3607) } else { tmp29 = linked_3604.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3603, arg_3606, arg_3607) }; var tmp30 any = /*line :546:1*/tmp28.Invoke_O__O(tmp29); var tmp31 any; var root_3608 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3610 lang.IFn; if


	linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = sm__10; var arg_3612 any = A_arbace_go_check_A_const_329; if linked_3609 == nil { tmp31 = ifn_3610.Invoke_O_O__O(arg_3611, arg_3612) } else { tmp31 = linked_3609.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3608, arg_3611, arg_3612) }; var tmp32 any = tmp31; var tmp33 any; var root_3613 any = /*line :546:1*/A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3613, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3615 lang.IFn; if


	linked_3614 == nil { ifn_3615 = lang.IFn_Cast(root_3613) } else { ifn_3615 = nil }; var arg_3616 any = sm__10; var arg_3617 any = A_arbace_go_check_A_const_330; if linked_3614 == nil { tmp33 = ifn_3615.Invoke_O_O__O(arg_3616, arg_3617) } else { tmp33 = linked_3614.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3613, arg_3616, arg_3617) }; /*line :546:1*/tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O_O_O_O__O(Lit_14, corpus__0, tmp22, tmp24, tmp26, tmp27, tmp30, tmp32, tmp33, jrt.Double_ValueOf_D__Double_NoInit(secs__11).Ref())); var seq_1685000432__16 any; var root_3618 any = /*line :527:1*/A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3620 lang.IFn; if






















	linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any; var root_3622 any = A_arbace_go_check_A_const_331.GetRawRoot__O(); var linked_3623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3622, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3624 lang.IFn; if linked_3623 == nil { ifn_3624 = lang.IFn_Cast(root_3622) } else { ifn_3624 = nil }; var arg_3625 any = A_arbace_go_check_A_const_332; var arg_3626 any; var root_3627 any = A_arbace_go_check_A_const_324.GetRawRoot__O(); var linked_3628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3627, A_arbace_go_check_report_errors_A_fn_class); var ifn_3629 lang.IFn; if linked_3628 == nil { ifn_3629 = lang.IFn_Cast(root_3627) } else { ifn_3629 = nil }; var arg_3630 any = rs__9; if linked_3628 == nil { arg_3626 = ifn_3629.Invoke_O__O(arg_3630) } else { arg_3626 = linked_3628.(*A_arbace_go_check_report_errors_A).Invoke_O_O__O(root_3627, arg_3630) }; if linked_3623 == nil { arg_3621 = ifn_3624.Invoke_O_O__O(arg_3625, arg_3626) } else { arg_3621 = linked_3623.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3622, arg_3625, arg_3626) }; if linked_3619 == nil { seq_1685000432__16 = ifn_3620.Invoke_O__O(arg_3621) } else { seq_1685000432__16 = linked_3619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3618, arg_3621) }; var chunk_1685000433__17 any; var count_1685000434__18 int64 = 0; var i_1685000435__19 int64 = 0; L1:
//line :527:1
	for {






















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1685000435__19, count_1685000434__18) { var l__20 any = lang.Indexed_Cast(chunk_1685000433__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1685000435__19)); lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__20); seq_1685000432__16, chunk_1685000433__17, count_1685000434__18, i_1685000435__19 = seq_1685000432__16, chunk_1685000433__17, count_1685000434__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1685000435__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_3631 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3633 lang.IFn; if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any = seq_1685000432__16; if linked_3632 == nil { temp__1927000414__auto____20 = ifn_3633.Invoke_O__O(arg_3634) } else { temp__1927000414__auto____20 = linked_3632.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3631, arg_3634) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1685000432__21 any = temp__1927000414__auto____20; var tmp34 any; var root_3635 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3635, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any = seq_1685000432__21; if linked_3636 == nil { tmp34 = ifn_3637.Invoke_O__O(arg_3638) } else { tmp34 = linked_3636.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3635, arg_3638) }; if jrt.J2g_Truth(tmp34) { var c__1927000678__auto____22 any; var root_3639 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3641 lang.IFn; if linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; var arg_3642 any = seq_1685000432__21; if linked_3640 == nil { c__1927000678__auto____22 = ifn_3641.Invoke_O__O(arg_3642) } else { c__1927000678__auto____22 = linked_3640.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3639, arg_3642) }; var tmp35 any; var root_3675 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3677 lang.IFn; if linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any = seq_1685000432__21; if linked_3676 == nil { tmp35 = ifn_3677.Invoke_O__O(arg_3678) } else { tmp35 = linked_3676.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3675, arg_3678) }; seq_1685000432__16, chunk_1685000433__17, count_1685000434__18, i_1685000435__19 = tmp35, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_3643 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3645 lang.IFn; if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = seq_1685000432__21; if linked_3644 == nil { l__22 = ifn_3645.Invoke_O__O(arg_3646) } else { l__22 = linked_3644.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3643, arg_3646) }; lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()).Invoke_O_O__O(Lit_15, l__22); var tmp36 any; var root_3684 any = A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3684, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3686 lang.IFn; if linked_3685 == nil { ifn_3686 = lang.IFn_Cast(root_3684) } else { ifn_3686 = nil }; var arg_3687 any = seq_1685000432__21; if linked_3685 == nil { tmp36 = ifn_3686.Invoke_O__O(arg_3687) } else { tmp36 = linked_3685.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3684, arg_3687) }; seq_1685000432__16, chunk_1685000433__17, count_1685000434__18, i_1685000435__19 = tmp36, nil, 0, 0; continue L1 } } }
//line :527:1
		break L1 }; var tmp37 any; var root_3647 any =























	A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3649 lang.IFn; if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any; var root_3651 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3651, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3653 lang.IFn; if linked_3652 == nil { ifn_3653 = lang.IFn_Cast(root_3651) } else { ifn_3653 = nil }; var arg_3654 any = sm__10; var arg_3655 any = A_arbace_go_check_A_const_333; if linked_3652 == nil { arg_3650 = ifn_3653.Invoke_O_O__O(arg_3654, arg_3655) } else { arg_3650 = linked_3652.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3651, arg_3654, arg_3655) }; if linked_3648 == nil { tmp37 = ifn_3649.Invoke_O__O(arg_3650) } else { tmp37 = linked_3648.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3647, arg_3650) }; if jrt.J2g_Truth(tmp37) {
		var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_200.GetRawRoot__O()); var tmp40 any; var root_3665 any = A_arbace_go_check_A_const_76.GetRawRoot__O(); var linked_3666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3665, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3667 lang.IFn; if linked_3666 == nil { ifn_3667 = lang.IFn_Cast(root_3665) } else { ifn_3667 = nil }; var arg_3668 any = sm__10; var arg_3669 any = A_arbace_go_check_A_const_334; if linked_3666 == nil { tmp40 = ifn_3667.Invoke_O_O__O(arg_3668, arg_3669) } else { tmp40 = linked_3666.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3665, arg_3668, arg_3669) }; tmp38.Invoke_O_O__O(Lit_16, tmp39.Invoke_O__O(tmp40)) }; if
	jrt.J2g_Truth(record__6) {
		var root_3688 any = A_arbace_go_check_A_const_321.GetRawRoot__O(); var linked_3689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3688, A_arbace_go_check_write_edn_A_fn_class); var ifn_3690 lang.IFn; if linked_3689 == nil { ifn_3690 = lang.IFn_Cast(root_3688) } else { ifn_3690 = nil }; var arg_3691 any; var root_3693 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3693, A_arbace_go_check_reference_path_A_fn_class); var ifn_3695 lang.IFn; if linked_3694 == nil { ifn_3695 = lang.IFn_Cast(root_3693) } else { ifn_3695 = nil }; var arg_3696 any = corpus__0; if linked_3694 == nil { arg_3691 = ifn_3695.Invoke_O__O(arg_3696) } else { arg_3691 = linked_3694.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3693, arg_3696) }; var arg_3692 any; var root_3697 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_3698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3697, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3699 lang.IFn; if linked_3698 == nil { ifn_3699 = lang.IFn_Cast(root_3697) } else { ifn_3699 = nil }; var arg_3700 any; var root_3703 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_3704 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3703, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3705 lang.IFn; if linked_3704 == nil { ifn_3705 = lang.IFn_Cast(root_3703) } else { ifn_3705 = nil }; var arg_3706 any = sm__10; var arg_3707 any = A_arbace_go_check_A_const_282; if linked_3704 == nil { arg_3700 = ifn_3705.Invoke_O_O__O(arg_3706, arg_3707) } else { arg_3700 = linked_3704.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3703, arg_3706, arg_3707) }; var arg_3701 any = A_arbace_go_check_A_const_320; var arg_3702 any = Lit_17; if linked_3698 == nil { arg_3692 = ifn_3699.Invoke_O_O_O__O(arg_3700, arg_3701, arg_3702) } else { arg_3692 = linked_3698.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3697, arg_3700, arg_3701, arg_3702) }; if linked_3689 == nil { ifn_3690.Invoke_O_O__O(arg_3691, arg_3692) } else { linked_3689.(*A_arbace_go_check_write_edn_A).Invoke_O_O_O__O(root_3688, arg_3691, arg_3692) }
		var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp42 any; var root_3713 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3713, A_arbace_go_check_reference_path_A_fn_class); var ifn_3715 lang.IFn; if linked_3714 == nil { ifn_3715 = lang.IFn_Cast(root_3713) } else { ifn_3715 = nil }; var arg_3716 any = corpus__0; if linked_3714 == nil { tmp42 = ifn_3715.Invoke_O__O(arg_3716) } else { tmp42 = linked_3714.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3713, arg_3716) }; tmp41.Invoke_O_O__O(Lit_18, tmp42)
//line :553:1
		return clean__14 } else { var tmp43 any; var root_3461 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3461, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3463 lang.IFn



			if linked_3462 == nil { ifn_3463 = lang.IFn_Cast(root_3461) } else { ifn_3463 = nil }; var arg_3464 any = clean__14; if linked_3462 == nil { tmp43 = ifn_3463.Invoke_O__O(arg_3464) } else { tmp43 = linked_3462.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3461, arg_3464) }
//line :553:1
			if jrt.J2g_Truth(tmp43) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Identical_O_O__Z_NoInit(ref__13, nil) {




				var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp45 any; var root_3723 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3723, A_arbace_go_check_reference_path_A_fn_class); var ifn_3725 lang.IFn; if linked_3724 == nil { ifn_3725 = lang.IFn_Cast(root_3723) } else { ifn_3725 = nil }; var arg_3726 any = corpus__0; if linked_3724 == nil { tmp45 = ifn_3725.Invoke_O__O(arg_3726) } else { tmp45 = linked_3724.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3723, arg_3726) }; tmp44.Invoke_O_O_O__O(Lit_19, tmp45, Lit_20)
//line :553:1
				return jrt.Boolean_FALSE.Ref() } else { var tmp46 any; var root_3465 any = A_arbace_go_check_A_const_35.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3467 lang.IFn





					if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(same__15).Ref(); if linked_3466 == nil { tmp46 = ifn_3467.Invoke_O__O(arg_3468) } else { tmp46 = linked_3466.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3465, arg_3468) }
//line :553:1
					if jrt.J2g_Truth(tmp46) {





						var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp48 any; var root_3733 any = A_arbace_go_check_A_const_315.GetRawRoot__O(); var linked_3734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3733, A_arbace_go_check_reference_path_A_fn_class); var ifn_3735 lang.IFn; if linked_3734 == nil { ifn_3735 = lang.IFn_Cast(root_3733) } else { ifn_3735 = nil }; var arg_3736 any = corpus__0; if linked_3734 == nil { tmp48 = ifn_3735.Invoke_O__O(arg_3736) } else { tmp48 = linked_3734.(*A_arbace_go_check_reference_path_A).Invoke_O_O__O(root_3733, arg_3736) }; tmp47.Invoke_O_O_O__O(Lit_21, tmp48, Lit_22)
						var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_200.GetRawRoot__O()); var tmp51 any; var root_3746 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_3747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3746, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3748 lang.IFn; if linked_3747 == nil { ifn_3748 = lang.IFn_Cast(root_3746) } else { ifn_3748 = nil }; var arg_3749 any = ref__13; var arg_3750 any = A_arbace_go_check_A_const_320; if linked_3747 == nil { tmp51 = ifn_3748.Invoke_O_O__O(arg_3749, arg_3750) } else { tmp51 = linked_3747.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3746, arg_3749, arg_3750) }; tmp49.Invoke_O_O__O(Lit_23, tmp50.Invoke_O__O(tmp51))
						var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_go_check_A_const_200.GetRawRoot__O()); var tmp54 any; var root_3760 any = A_arbace_go_check_A_const_214.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3760, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_3762 lang.IFn; if linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any = sm__10; var arg_3764 any = A_arbace_go_check_A_const_282; if linked_3761 == nil { tmp54 = ifn_3762.Invoke_O_O__O(arg_3763, arg_3764) } else { tmp54 = linked_3761.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_3760, arg_3763, arg_3764) }; tmp52.Invoke_O_O__O(Lit_24, tmp53.Invoke_O__O(tmp54))
//line :553:1
						return jrt.Boolean_FALSE.Ref() } else { if A_arbace_go_check_A_const_28 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } } }
//line :545:1
func A_arbace_go_check_annotations_iter__1685000416__1685000422_A_New() *A_arbace_go_check_annotations_iter__1685000416__1685000422_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000416__1685000422_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_A) Ctor() {}
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_A) Invoke_O_O__O(self, s__1685000417__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A_New_O_O(self, s__1685000417__1); var tmp2 *jrt.Class; var fncls__3570 *jrt.Class = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A_fn_class; if fncls__3570 == nil { var fncls__3570d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A_fn_class = fncls__3570d; tmp2 = fncls__3570d } else { tmp2 = fncls__3570 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :545:1
func A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A_New_O_O(p0, p1 any) *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A{}; t.Ctor_O_O(p0, p1); return t }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A) Ctor_O_O(c__iter__1685000416, c__s__1685000417 any) { t.F_iter__1685000416 = c__iter__1685000416; t.F_s__1685000417 = c__s__1685000417 }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A) Invoke_O__O(self any) any { { var s__1685000417__1 any; var t_ any = t.F_s__1685000417; t.F_s__1685000417 = nil; s__1685000417__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_3486 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3486, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3488 lang.IFn; if linked_3487 == nil { ifn_3488 = lang.IFn_Cast(root_3486) } else { ifn_3488 = nil }; var arg_3489 any = s__1685000417__1; if linked_3487 == nil { temp__1927000414__auto____2 = ifn_3488.Invoke_O__O(arg_3489) } else { temp__1927000414__auto____2 = linked_3487.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3486, arg_3489) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_3490 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3490, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3492 lang.IFn; if linked_3491 == nil { ifn_3492 = lang.IFn_Cast(root_3490) } else { ifn_3492 = nil }; var arg_3493 any = xs__1927001018__auto____3; if linked_3491 == nil { r__4 = ifn_3492.Invoke_O__O(arg_3493) } else { r__4 = linked_3491.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3490, arg_3493) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A_New_O(r__4); var tmp2 *jrt.Class; var fncls__3552 *jrt.Class = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A_fn_class; if fncls__3552 == nil { var fncls__3552d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A_fn_class = fncls__3552d; tmp2 = fncls__3552d } else { tmp2 = fncls__3552 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_3553 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3553, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3555 lang.IFn; if linked_3554 == nil { ifn_3555 = lang.IFn_Cast(root_3553) } else { ifn_3555 = nil }; var arg_3556 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_go_check_A_const_153.Invoke_O__O(r__4)); if linked_3554 == nil { fs__1927001036__auto____6 = ifn_3555.Invoke_O__O(arg_3556) } else { fs__1927001036__auto____6 = linked_3554.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3553, arg_3556) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_3557 any = A_arbace_go_check_A_const_273.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = fs__1927001036__auto____6; var arg_3561 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1685000416); var tmp4 any; var root_3562 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3562, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3564 lang.IFn; if linked_3563 == nil { ifn_3564 = lang.IFn_Cast(root_3562) } else { ifn_3564 = nil }; var arg_3565 any = s__1685000417__1; if linked_3563 == nil { tmp4 = ifn_3564.Invoke_O__O(arg_3565) } else { tmp4 = linked_3563.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3562, arg_3565) }; arg_3561 = tmp3.Invoke_O__O(tmp4); if linked_3558 == nil { return ifn_3559.Invoke_O_O__O(arg_3560, arg_3561) } else { return linked_3558.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3557, arg_3560, arg_3561) } } else { var tmp5 any; var root_3566 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3566, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3568 lang.IFn; if linked_3567 == nil { ifn_3568 = lang.IFn_Cast(root_3566) } else { ifn_3568 = nil }; var arg_3569 any = s__1685000417__1; if linked_3567 == nil { tmp5 = ifn_3568.Invoke_O__O(arg_3569) } else { tmp5 = linked_3567.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3566, arg_3569) }; s__1685000417__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :545:1
func A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A_New_O(p0 any) *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A{}; t.Ctor_O(p0); return t }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A) Invoke_O_O__O(self, s__1685000419__1 any) any { var tmp1 any = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A_New_O_O_O(s__1685000419__1, self, t.F_r); var tmp2 *jrt.Class; var fncls__3551 *jrt.Class = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A_fn_class; if fncls__3551 == nil { var fncls__3551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A_fn_class = fncls__3551d; tmp2 = fncls__3551d } else { tmp2 = fncls__3551 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :545:1
func A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A) Ctor_O_O_O(c__s__1685000419, c__iter__1685000418, c__r any) { t.F_s__1685000419 = c__s__1685000419; t.F_iter__1685000418 = c__iter__1685000418; t.F_r = c__r }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A) Invoke_O__O(self any) any { { var s__1685000419__1 any; var t_ any = t.F_s__1685000419; t.F_s__1685000419 = nil; s__1685000419__1 = t_; for { var temp__1927000414__auto____2 any; var root_3494 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3494, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3496 lang.IFn; if linked_3495 == nil { ifn_3496 = lang.IFn_Cast(root_3494) } else { ifn_3496 = nil }; var arg_3497 any = s__1685000419__1; if linked_3495 == nil { temp__1927000414__auto____2 = ifn_3496.Invoke_O__O(arg_3497) } else { temp__1927000414__auto____2 = linked_3495.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3494, arg_3497) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000419__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3498 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3500 lang.IFn; if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = s__1685000419__3; if linked_3499 == nil { tmp1 = ifn_3500.Invoke_O__O(arg_3501) } else { tmp1 = linked_3499.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3498, arg_3501) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3502 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3502, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3504 lang.IFn; if linked_3503 == nil { ifn_3504 = lang.IFn_Cast(root_3502) } else { ifn_3504 = nil }; var arg_3505 any = s__1685000419__3; if linked_3503 == nil { c__1927001037__auto____4 = ifn_3504.Invoke_O__O(arg_3505) } else { c__1927001037__auto____4 = linked_3503.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3502, arg_3505) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000421__6 any; var root_3506 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3506, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3508 lang.IFn; if linked_3507 == nil { ifn_3508 = lang.IFn_Cast(root_3506) } else { ifn_3508 = nil }; var arg_3509 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3507 == nil { b__1685000421__6 = ifn_3508.Invoke_O__O(arg_3509) } else { b__1685000421__6 = linked_3507.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3506, arg_3509) }; var tmp2 any = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A_New_O_O_I_O(b__1685000421__6, t.F_r, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3515 *jrt.Class = A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A_fn_class; if fncls__3515 == nil { var fncls__3515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A_fn_class = fncls__3515d; tmp3 = fncls__3515d } else { tmp3 = fncls__3515 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3516 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3516, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3518 lang.IFn; if linked_3517 == nil { ifn_3518 = lang.IFn_Cast(root_3516) } else { ifn_3518 = nil }; var arg_3519 any; var root_3521 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3521, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3523 lang.IFn; if linked_3522 == nil { ifn_3523 = lang.IFn_Cast(root_3521) } else { ifn_3523 = nil }; var arg_3524 any = b__1685000421__6; if linked_3522 == nil { arg_3519 = ifn_3523.Invoke_O__O(arg_3524) } else { arg_3519 = linked_3522.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3521, arg_3524) }; var arg_3520 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000418); var tmp5 any; var root_3525 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3527 lang.IFn; if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any = s__1685000419__3; if linked_3526 == nil { tmp5 = ifn_3527.Invoke_O__O(arg_3528) } else { tmp5 = linked_3526.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3525, arg_3528) }; arg_3520 = tmp4.Invoke_O__O(tmp5); if linked_3517 == nil { return ifn_3518.Invoke_O_O__O(arg_3519, arg_3520) } else { return linked_3517.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3516, arg_3519, arg_3520) } } else { var root_3529 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3529, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3531 lang.IFn; if linked_3530 == nil { ifn_3531 = lang.IFn_Cast(root_3529) } else { ifn_3531 = nil }; var arg_3532 any; var root_3534 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any = b__1685000421__6; if linked_3535 == nil { arg_3532 = ifn_3536.Invoke_O__O(arg_3537) } else { arg_3532 = linked_3535.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3534, arg_3537) }; var arg_3533 any; if linked_3530 == nil { return ifn_3531.Invoke_O_O__O(arg_3532, arg_3533) } else { return linked_3530.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3529, arg_3532, arg_3533) } } } else { var u__4 any; var root_3538 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3538, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3540 lang.IFn; if linked_3539 == nil { ifn_3540 = lang.IFn_Cast(root_3538) } else { ifn_3540 = nil }; var arg_3541 any = s__1685000419__3; if linked_3539 == nil { u__4 = ifn_3540.Invoke_O__O(arg_3541) } else { u__4 = linked_3539.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3538, arg_3541) }; var root_3542 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3542, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3544 lang.IFn; if linked_3543 == nil { ifn_3544 = lang.IFn_Cast(root_3542) } else { ifn_3544 = nil }; var arg_3545 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), u__4); var arg_3546 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000418); var tmp7 any; var root_3547 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3547, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3549 lang.IFn; if linked_3548 == nil { ifn_3549 = lang.IFn_Cast(root_3547) } else { ifn_3549 = nil }; var arg_3550 any = s__1685000419__3; if linked_3548 == nil { tmp7 = ifn_3549.Invoke_O__O(arg_3550) } else { tmp7 = linked_3548.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3547, arg_3550) }; arg_3546 = tmp6.Invoke_O__O(tmp7); if linked_3543 == nil { return ifn_3544.Invoke_O_O__O(arg_3545, arg_3546) } else { return linked_3543.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3542, arg_3545, arg_3546) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :545:1
func A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A) Ctor_O_O_I_O(c__b__1685000421, c__r any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000421 = c__b__1685000421; t.F_r = c__r; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :545:1
func (t *A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A) Invoke_O__O(self any) any { { var i__1685000420__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000420__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000420__1)); var root_3510 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3510, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3512 lang.IFn; if linked_3511 == nil { ifn_3512 = lang.IFn_Cast(root_3510) } else { ifn_3512 = nil }; var arg_3513 any = t.F_b__1685000421; var arg_3514 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_A_const_104.Invoke_O__O(t.F_r), u__2); if linked_3511 == nil { ifn_3512.Invoke_O_O__O(arg_3513, arg_3514) } else { linked_3511.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3510, arg_3513, arg_3514) }; i__1685000420__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000420__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



















func A_arbace_go_check__main_A_New() *A_arbace_go_check__main_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_go_check__main_A) Ctor() {}
//line :565:1
func (t *A_arbace_go_check__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1685000437__2 any = args__0; var seq__1685000438__3 any; var root_3765 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3765, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3767 lang.IFn; if


	linked_3766 == nil { ifn_3767 = lang.IFn_Cast(root_3765) } else { ifn_3767 = nil }; var arg_3768 any = vec__1685000437__2; if linked_3766 == nil { seq__1685000438__3 = ifn_3767.Invoke_O__O(arg_3768) } else { seq__1685000438__3 = linked_3766.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3765, arg_3768) }; var first__1685000439__4 any; var root_3769 any = /*line :565:1*/A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3771 lang.IFn; if


	linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any = seq__1685000438__3; if linked_3770 == nil { first__1685000439__4 = ifn_3771.Invoke_O__O(arg_3772) } else { first__1685000439__4 = linked_3770.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3769, arg_3772) }; var seq__1685000438__5 any; var root_3773 any = /*line :565:1*/A_arbace_go_check_A_const_46.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3775 lang.IFn; if


	linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = seq__1685000438__3; if linked_3774 == nil { seq__1685000438__5 = ifn_3775.Invoke_O__O(arg_3776) } else { seq__1685000438__5 = linked_3774.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3773, arg_3776) }; var cmd__6 any = first__1685000439__4; var args__7 any = seq__1685000438__5; var G__1685000440__8_ any = cmd__6; switch
	lang.Util_Hash_O__I_NoInit(G__1685000440__8_) { case -961709276: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000440__8_, Lit_1) { var opts__9 any; var tmp1 any = A_arbace_go_check__main_fn__1685000441_A_New_O(args__7); var tmp2 *jrt.Class
		var fncls__3840 /*line :569:1*/*jrt.Class = A_arbace_go_check__main_fn__1685000441_A_fn_class

		if fncls__3840 == nil { var fncls__3840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check__main_fn__1685000441_A_fn_class = fncls__3840d; tmp2 = fncls__3840d } else { tmp2 = fncls__3840 }; opts__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :569:1
		var cs__10 any; var tmp3 any; var root_3841 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3841, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3843 lang.IFn









		if linked_3842 == nil { ifn_3843 = lang.IFn_Cast(root_3841) } else { ifn_3843 = nil }; var arg_3844 any = A_arbace_go_check_A_const_336.Invoke_O__O(opts__9); if linked_3842 == nil { tmp3 = ifn_3843.Invoke_O__O(arg_3844) } else { tmp3 = linked_3842.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3841, arg_3844) }; if jrt.J2g_Truth(tmp3) { cs__10 = A_arbace_go_check_A_const_336.Invoke_O__O(opts__9) } else { cs__10 = A_arbace_go_check_A_const_339.GetRawRoot__O() }
//line :569:1
		var ok__11 any; var root_3845 any = A_arbace_go_check_A_const_251.GetRawRoot__O(); var linked_3846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3845, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3847 lang.IFn










		if linked_3846 == nil { ifn_3847 = lang.IFn_Cast(root_3845) } else { ifn_3847 = nil }; var arg_3848 any; var iter__1927001039__auto____11 any; var tmp4 any = A_arbace_go_check__main_iter__1685000444__1685000448_A_New_O(opts__9); var tmp5 *jrt.Class; var fncls__3917 *jrt.Class = A_arbace_go_check__main_iter__1685000444__1685000448_A_fn_class; if fncls__3917 == nil { var fncls__3917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check__main_iter__1685000444__1685000448_A_fn_class = fncls__3917d; tmp5 = fncls__3917d } else { tmp5 = fncls__3917 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_3848 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(cs__10); if linked_3846 == nil { ok__11 = ifn_3847.Invoke_O__O(arg_3848) } else { ok__11 = linked_3846.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3845, arg_3848) }
		var root_3923 any = A_arbace_go_check_A_const_343.GetRawRoot__O(); var linked_3924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3923, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_3925 lang.IFn; if linked_3924 == nil { ifn_3925 = lang.IFn_Cast(root_3923) } else { ifn_3925 = nil }; if linked_3924 == nil { ifn_3925.Invoke__O() } else { linked_3924.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_3923) }
		var tmp6 int64; var tmp7 any; var root_3918 any = A_arbace_go_check_A_const_341.GetRawRoot__O(); var linked_3919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3918, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_3920 lang.IFn; if linked_3919 == nil { ifn_3920 = lang.IFn_Cast(root_3918) } else { ifn_3920 = nil }; var arg_3921 any = A_arbace_go_check_A_const_342.GetRawRoot__O(); var arg_3922 any = ok__11; if linked_3919 == nil { tmp7 = ifn_3920.Invoke_O_O__O(arg_3921, arg_3922) } else { tmp7 = linked_3919.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_3918, arg_3921, arg_3922) }; if jrt.J2g_Truth(tmp7) { tmp6 = 0 } else { tmp6 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp6)); return nil }
//line :569:1
	default:};













	lang.IFn_Cast(A_arbace_go_check_A_const_325.GetRawRoot__O()).Invoke_O__O(Lit_4);
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :571:1
func A_arbace_go_check__main_fn__1685000441_A_New_O(p0 any) *A_arbace_go_check__main_fn__1685000441_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_fn__1685000441_A{}; t.Ctor_O(p0); return t }
//line :571:1
func (t *A_arbace_go_check__main_fn__1685000441_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :571:1
func (t *A_arbace_go_check__main_fn__1685000441_A) Invoke_O__O(self any) any { { var as__1 any; var t_ any = t.F_args; t.F_args = nil; as__1 = t_; var tmp1 any = A_arbace_go_check_A_const_309; var tmp2 any = A_arbace_go_check_A_const_335; var tmp3 any = A_arbace_go_check_A_const_311; var o__2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_5), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_A_const_239.Get__O(), nil)).Ref(), A_arbace_go_check_A_const_336, lang.PersistentVector_EMPTY.Ref())); L1: for {
										var tmp4 any; var root_3778 any = A_arbace_go_check_A_const_268.GetRawRoot__O(); var linked_3779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3778, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3780 lang.IFn; if linked_3779 == nil { ifn_3780 = lang.IFn_Cast(root_3778) } else { ifn_3780 = nil }; var arg_3781 any = as__1; if linked_3779 == nil { tmp4 = ifn_3780.Invoke_O__O(arg_3781) } else { tmp4 = linked_3779.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3778, arg_3781) }; if jrt.J2g_Truth(tmp4) { return o__2 } else { var G__1685000442__3_ any; var root_3782 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3782, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3784 lang.IFn

		if linked_3783 == nil { ifn_3784 = lang.IFn_Cast(root_3782) } else { ifn_3784 = nil }; var arg_3785 any = as__1; if linked_3783 == nil { G__1685000442__3_ = ifn_3784.Invoke_O__O(arg_3785) } else { G__1685000442__3_ = linked_3783.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3782, arg_3785) }; switch lang.Util_Hash_O__I_NoInit(G__1685000442__3_) >> 10 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000442__3_, Lit_6) {

			var tmp5 any; var root_3787 any = A_arbace_go_check_A_const_337.GetRawRoot__O(); var linked_3788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3787, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3789 lang.IFn; if linked_3788 == nil { ifn_3789 = lang.IFn_Cast(root_3787) } else { ifn_3789 = nil }; var arg_3790 any = as__1; if linked_3788 == nil { tmp5 = ifn_3789.Invoke_O__O(arg_3790) } else { tmp5 = linked_3788.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3787, arg_3790) }; var tmp6 any = tmp5; var tmp7 any; var root_3791 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_3792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3791, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3793 lang.IFn; if linked_3792 == nil { ifn_3793 = lang.IFn_Cast(root_3791) } else { ifn_3793 = nil }; var arg_3794 any = o__2; var arg_3795 any = A_arbace_go_check_A_const_309; var arg_3796 any; var tmp8 any; var root_3797 any = A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3797, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3799 lang.IFn; if linked_3798 == nil { ifn_3799 = lang.IFn_Cast(root_3797) } else { ifn_3799 = nil }; var arg_3800 any = as__1; if linked_3798 == nil { tmp8 = ifn_3799.Invoke_O__O(arg_3800) } else { tmp8 = linked_3798.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3797, arg_3800) }; arg_3796 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp8))).Ref(); if linked_3792 == nil { tmp7 = ifn_3793.Invoke_O_O_O__O(arg_3794, arg_3795, arg_3796) } else { tmp7 = linked_3792.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3791, arg_3794, arg_3795, arg_3796) }; as__1, o__2 = tmp6, tmp7; continue L1 }
//line :574:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000442__3_, Lit_7) {
			var tmp9 any; var root_3801 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3801, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3803 lang.IFn; if linked_3802 == nil { ifn_3803 = lang.IFn_Cast(root_3801) } else { ifn_3803 = nil }; var arg_3804 any = as__1; if linked_3802 == nil { tmp9 = ifn_3803.Invoke_O__O(arg_3804) } else { tmp9 = linked_3802.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3801, arg_3804) }; var tmp10 any = tmp9; var tmp11 any; var root_3805 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_3806 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3805, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3807 lang.IFn; if linked_3806 == nil { ifn_3807 = lang.IFn_Cast(root_3805) } else { ifn_3807 = nil }; var arg_3808 any = o__2; var arg_3809 any = A_arbace_go_check_A_const_310; var arg_3810 any = jrt.Boolean_TRUE.Ref(); if linked_3806 == nil { tmp11 = ifn_3807.Invoke_O_O_O__O(arg_3808, arg_3809, arg_3810) } else { tmp11 = linked_3806.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3805, arg_3808, arg_3809, arg_3810) }; as__1, o__2 = tmp10, tmp11; continue L1 }
//line :574:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1685000442__3_, Lit_8) {


			var tmp12 any; var root_3811 any = A_arbace_go_check_A_const_337.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = as__1; if linked_3812 == nil { tmp12 = ifn_3813.Invoke_O__O(arg_3814) } else { tmp12 = linked_3812.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3811, arg_3814) }; var tmp13 any = tmp12; var tmp14 any; var root_3815 any = A_arbace_go_check_A_const_184.GetRawRoot__O(); var linked_3816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3815, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3817 lang.IFn; if linked_3816 == nil { ifn_3817 = lang.IFn_Cast(root_3815) } else { ifn_3817 = nil }; var arg_3818 any = o__2; var arg_3819 any = A_arbace_go_check_A_const_311; var arg_3820 any; var root_3821 any = A_arbace_go_check_A_const_338.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3823 lang.IFn; if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any = as__1; if linked_3822 == nil { arg_3820 = ifn_3823.Invoke_O__O(arg_3824) } else { arg_3820 = linked_3822.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3821, arg_3824) }; if linked_3816 == nil { tmp14 = ifn_3817.Invoke_O_O_O__O(arg_3818, arg_3819, arg_3820) } else { tmp14 = linked_3816.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3815, arg_3818, arg_3819, arg_3820) }; as__1, o__2 = tmp13, tmp14; continue L1 }
//line :574:1
		default:
		}


		var tmp15 any; var root_3825 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = as__1; if linked_3826 == nil { tmp15 = ifn_3827.Invoke_O__O(arg_3828) } else { tmp15 = linked_3826.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3825, arg_3828) }; var tmp16 any = tmp15; var tmp17 any; var root_3829 any = A_arbace_go_check_A_const_19.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3829, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3831 lang.IFn; if linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any = o__2; var arg_3833 any = A_arbace_go_check_A_const_336; var arg_3834 any = A_arbace_go_check_A_const_16.GetRawRoot__O(); var arg_3835 any; var root_3836 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3836, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3838 lang.IFn; if linked_3837 == nil { ifn_3838 = lang.IFn_Cast(root_3836) } else { ifn_3838 = nil }; var arg_3839 any = as__1; if linked_3837 == nil { arg_3835 = ifn_3838.Invoke_O__O(arg_3839) } else { arg_3835 = linked_3837.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3836, arg_3839) }; if linked_3830 == nil { tmp17 = ifn_3831.Invoke_O_O_O_O__O(arg_3832, arg_3833, arg_3834, arg_3835) } else { tmp17 = linked_3830.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3829, arg_3832, arg_3833, arg_3834, arg_3835) }; as__1, o__2 = tmp16, tmp17; continue L1 } } }; /*line :571:1*/panic("j2g: unreachable") }








func A_arbace_go_check__main_iter__1685000444__1685000448_A_New_O(p0 any) *A_arbace_go_check__main_iter__1685000444__1685000448_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000444__1685000448_A{}; t.Ctor_O(p0); return t }
//line :580:1
func (t *A_arbace_go_check__main_iter__1685000444__1685000448_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :580:1
func (t *A_arbace_go_check__main_iter__1685000444__1685000448_A) Invoke_O_O__O(self, s__1685000445__1 any) any { var tmp1 any = A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A_New_O_O_O(t.F_opts, s__1685000445__1, self); var tmp2 *jrt.Class; var fncls__3916 *jrt.Class = A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A_fn_class; if fncls__3916 == nil { var fncls__3916d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A_fn_class = fncls__3916d; tmp2 = fncls__3916d } else { tmp2 = fncls__3916 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :580:1
func A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :580:1
func (t *A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A) Ctor_O_O_O(c__opts, c__s__1685000445, c__iter__1685000444 any) { t.F_opts = c__opts; t.F_s__1685000445 = c__s__1685000445; t.F_iter__1685000444 = c__iter__1685000444 }
//line :580:1
func (t *A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A) Invoke_O__O(self any) any { { var s__1685000445__1 any; var t_ any = t.F_s__1685000445; t.F_s__1685000445 = nil; s__1685000445__1 = t_; for { var temp__1927000414__auto____2 any; var root_3849 any = A_arbace_go_check_A_const_32.GetRawRoot__O(); var linked_3850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3849, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3851 lang.IFn; if linked_3850 == nil { ifn_3851 = lang.IFn_Cast(root_3849) } else { ifn_3851 = nil }; var arg_3852 any = s__1685000445__1; if linked_3850 == nil { temp__1927000414__auto____2 = ifn_3851.Invoke_O__O(arg_3852) } else { temp__1927000414__auto____2 = linked_3850.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3849, arg_3852) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1685000445__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3853 any = A_arbace_go_check_A_const_33.GetRawRoot__O(); var linked_3854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3853, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3855 lang.IFn; if linked_3854 == nil { ifn_3855 = lang.IFn_Cast(root_3853) } else { ifn_3855 = nil }; var arg_3856 any = s__1685000445__3; if linked_3854 == nil { tmp1 = ifn_3855.Invoke_O__O(arg_3856) } else { tmp1 = linked_3854.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3853, arg_3856) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3857 any = A_arbace_go_check_A_const_34.GetRawRoot__O(); var linked_3858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3857, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3859 lang.IFn; if linked_3858 == nil { ifn_3859 = lang.IFn_Cast(root_3857) } else { ifn_3859 = nil }; var arg_3860 any = s__1685000445__3; if linked_3858 == nil { c__1927001037__auto____4 = ifn_3859.Invoke_O__O(arg_3860) } else { c__1927001037__auto____4 = linked_3858.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3857, arg_3860) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1685000447__6 any; var root_3861 any = A_arbace_go_check_A_const_145.GetRawRoot__O(); var linked_3862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3861, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3863 lang.IFn; if linked_3862 == nil { ifn_3863 = lang.IFn_Cast(root_3861) } else { ifn_3863 = nil }; var arg_3864 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3862 == nil { b__1685000447__6 = ifn_3863.Invoke_O__O(arg_3864) } else { b__1685000447__6 = linked_3862.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3861, arg_3864) }; var tmp2 any = A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A_New_O_O_I_O(b__1685000447__6, t.F_opts, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3875 *jrt.Class = A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A_fn_class; if fncls__3875 == nil { var fncls__3875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A_fn_class = fncls__3875d; tmp3 = fncls__3875d } else { tmp3 = fncls__3875 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3876 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any; var root_3881 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3881, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3883 lang.IFn; if linked_3882 == nil { ifn_3883 = lang.IFn_Cast(root_3881) } else { ifn_3883 = nil }; var arg_3884 any = b__1685000447__6; if linked_3882 == nil { arg_3879 = ifn_3883.Invoke_O__O(arg_3884) } else { arg_3879 = linked_3882.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3881, arg_3884) }; var arg_3880 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1685000444); var tmp5 any; var root_3885 any = A_arbace_go_check_A_const_45.GetRawRoot__O(); var linked_3886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3885, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3887 lang.IFn; if linked_3886 == nil { ifn_3887 = lang.IFn_Cast(root_3885) } else { ifn_3887 = nil }; var arg_3888 any = s__1685000445__3; if linked_3886 == nil { tmp5 = ifn_3887.Invoke_O__O(arg_3888) } else { tmp5 = linked_3886.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3885, arg_3888) }; arg_3880 = tmp4.Invoke_O__O(tmp5); if linked_3877 == nil { return ifn_3878.Invoke_O_O__O(arg_3879, arg_3880) } else { return linked_3877.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3876, arg_3879, arg_3880) } } else { var root_3889 any = A_arbace_go_check_A_const_147.GetRawRoot__O(); var linked_3890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3889, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3891 lang.IFn; if linked_3890 == nil { ifn_3891 = lang.IFn_Cast(root_3889) } else { ifn_3891 = nil }; var arg_3892 any; var root_3894 any = A_arbace_go_check_A_const_148.GetRawRoot__O(); var linked_3895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3894, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3896 lang.IFn; if linked_3895 == nil { ifn_3896 = lang.IFn_Cast(root_3894) } else { ifn_3896 = nil }; var arg_3897 any = b__1685000447__6; if linked_3895 == nil { arg_3892 = ifn_3896.Invoke_O__O(arg_3897) } else { arg_3892 = linked_3895.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3894, arg_3897) }; var arg_3893 any; if linked_3890 == nil { return ifn_3891.Invoke_O_O__O(arg_3892, arg_3893) } else { return linked_3890.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3889, arg_3892, arg_3893) } } } else { var c__4 any; var root_3898 any = A_arbace_go_check_A_const_31.GetRawRoot__O(); var linked_3899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3898, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3900 lang.IFn; if linked_3899 == nil { ifn_3900 = lang.IFn_Cast(root_3898) } else { ifn_3900 = nil }; var arg_3901 any = s__1685000445__3; if linked_3899 == nil { c__4 = ifn_3900.Invoke_O__O(arg_3901) } else { c__4 = linked_3899.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3898, arg_3901) }; var root_3902 any = A_arbace_go_check_A_const_149.GetRawRoot__O(); var linked_3903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3902, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3904 lang.IFn; if linked_3903 == nil { ifn_3904 = lang.IFn_Cast(root_3902) } else { ifn_3904 = nil }; var arg_3905 any; var root_3907 any = A_arbace_go_check_A_const_340.GetRawRoot__O(); var linked_3908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3907, A_arbace_go_check_annotations_A_fn_class); var ifn_3909 lang.IFn; if linked_3908 == nil { ifn_3909 = lang.IFn_Cast(root_3907) } else { ifn_3909 = nil }; var arg_3910 any = c__4; var arg_3911 any = t.F_opts; if linked_3908 == nil { arg_3905 = ifn_3909.Invoke_O_O__O(arg_3910, arg_3911) } else { arg_3905 = linked_3908.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_3907, arg_3910, arg_3911) }; var arg_3906 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1685000444); var tmp7 any; var root_3912 any = A_arbace_go_check_A_const_125.GetRawRoot__O(); var linked_3913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3912, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3914 lang.IFn; if linked_3913 == nil { ifn_3914 = lang.IFn_Cast(root_3912) } else { ifn_3914 = nil }; var arg_3915 any = s__1685000445__3; if linked_3913 == nil { tmp7 = ifn_3914.Invoke_O__O(arg_3915) } else { tmp7 = linked_3913.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3912, arg_3915) }; arg_3906 = tmp6.Invoke_O__O(tmp7); if linked_3903 == nil { return ifn_3904.Invoke_O_O__O(arg_3905, arg_3906) } else { return linked_3903.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3902, arg_3905, arg_3906) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :580:1
func A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :580:1
func (t *A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A) Ctor_O_O_I_O(c__b__1685000447, c__opts any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1685000447 = c__b__1685000447; t.F_opts = c__opts; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :580:1
func (t *A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A) Invoke_O__O(self any) any { { var i__1685000446__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1685000446__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1685000446__1)); var root_3865 any = A_arbace_go_check_A_const_146.GetRawRoot__O(); var linked_3866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3865, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3867 lang.IFn; if linked_3866 == nil { ifn_3867 = lang.IFn_Cast(root_3865) } else { ifn_3867 = nil }; var arg_3868 any = t.F_b__1685000447; var arg_3869 any; var root_3870 any = A_arbace_go_check_A_const_340.GetRawRoot__O(); var linked_3871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3870, A_arbace_go_check_annotations_A_fn_class); var ifn_3872 lang.IFn; if linked_3871 == nil { ifn_3872 = lang.IFn_Cast(root_3870) } else { ifn_3872 = nil }; var arg_3873 any = c__2; var arg_3874 any = t.F_opts; if linked_3871 == nil { arg_3869 = ifn_3872.Invoke_O_O__O(arg_3873, arg_3874) } else { arg_3869 = linked_3871.(*A_arbace_go_check_annotations_A).Invoke_O_O_O__O(root_3870, arg_3873, arg_3874) }; if linked_3866 == nil { ifn_3867.Invoke_O_O__O(arg_3868, arg_3869) } else { linked_3866.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3865, arg_3868, arg_3869) }; i__1685000446__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1685000446__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }























































































































































































































type A_arbace_go_check_A struct{ jrt.Object }

var A_arbace_go_check_A_const_pool *jrt.RefArray

var A_arbace_go_check_A_const_0 *lang.Var

var A_arbace_go_check_A_const_1 any

var A_arbace_go_check_A_const_2 *lang.Var

var A_arbace_go_check_A_const_3 any

var A_arbace_go_check_A_const_4 any

var A_arbace_go_check_A_const_5 any

var A_arbace_go_check_A_const_6 any

var A_arbace_go_check_A_const_7 any

var A_arbace_go_check_A_const_8 any

var A_arbace_go_check_A_const_9 any

var A_arbace_go_check_A_const_10 any

var A_arbace_go_check_A_const_11 any

var A_arbace_go_check_A_const_12 any

var A_arbace_go_check_A_const_13 *lang.Var

var A_arbace_go_check_A_const_14 *lang.Var

var A_arbace_go_check_A_const_15 *lang.Var

var A_arbace_go_check_A_const_16 *lang.Var

var A_arbace_go_check_A_const_17 any

var A_arbace_go_check_A_const_18 *lang.Var

var A_arbace_go_check_A_const_19 *lang.Var

var A_arbace_go_check_A_const_20 *lang.Var

var A_arbace_go_check_A_const_21 *lang.Var

var A_arbace_go_check_A_const_22 any

var A_arbace_go_check_A_const_23 *lang.Var

var A_arbace_go_check_A_const_24 *lang.Keyword

var A_arbace_go_check_A_const_25 *lang.Var

var A_arbace_go_check_A_const_26 *lang.Var

var A_arbace_go_check_A_const_27 *lang.Var

var A_arbace_go_check_A_const_28 *lang.Keyword

var A_arbace_go_check_A_const_29 *lang.Keyword

var A_arbace_go_check_A_const_30 any

var A_arbace_go_check_A_const_31 *lang.Var

var A_arbace_go_check_A_const_32 *lang.Var

var A_arbace_go_check_A_const_33 *lang.Var

var A_arbace_go_check_A_const_34 *lang.Var

var A_arbace_go_check_A_const_35 *lang.Var

var A_arbace_go_check_A_const_36 *lang.Var

var A_arbace_go_check_A_const_37 any

var A_arbace_go_check_A_const_38 any

var A_arbace_go_check_A_const_39 *lang.Var

var A_arbace_go_check_A_const_40 *lang.Keyword

var A_arbace_go_check_A_const_41 any

var A_arbace_go_check_A_const_42 *lang.Keyword

var A_arbace_go_check_A_const_43 any

var A_arbace_go_check_A_const_44 *lang.Keyword

var A_arbace_go_check_A_const_45 *lang.Var

var A_arbace_go_check_A_const_46 *lang.Var

var A_arbace_go_check_A_const_47 *lang.Keyword

var A_arbace_go_check_A_const_48 any

var A_arbace_go_check_A_const_49 any

var A_arbace_go_check_A_const_50 *lang.Keyword

var A_arbace_go_check_A_const_51 *lang.Var

var A_arbace_go_check_A_const_52 *lang.Keyword

var A_arbace_go_check_A_const_53 *lang.Keyword

var A_arbace_go_check_A_const_54 *lang.Keyword

var A_arbace_go_check_A_const_55 *lang.Var

var A_arbace_go_check_A_const_56 *lang.Var

var A_arbace_go_check_A_const_57 *lang.Var

var A_arbace_go_check_A_const_58 *lang.Var

var A_arbace_go_check_A_const_59 *lang.Var

var A_arbace_go_check_A_const_60 *lang.Keyword

var A_arbace_go_check_A_const_61 *lang.Var

var A_arbace_go_check_A_const_62 *lang.Keyword

var A_arbace_go_check_A_const_63 *lang.Var

var A_arbace_go_check_A_const_64 *lang.Keyword

var A_arbace_go_check_A_const_65 *lang.Keyword

var A_arbace_go_check_A_const_66 *lang.Var

var A_arbace_go_check_A_const_67 *lang.Keyword

var A_arbace_go_check_A_const_68 *lang.Keyword

var A_arbace_go_check_A_const_69 *lang.Keyword

var A_arbace_go_check_A_const_70 *lang.Keyword

var A_arbace_go_check_A_const_71 *lang.Keyword

var A_arbace_go_check_A_const_72 *lang.Var

var A_arbace_go_check_A_const_73 *lang.Keyword

var A_arbace_go_check_A_const_74 *lang.Keyword

var A_arbace_go_check_A_const_75 *lang.Var

var A_arbace_go_check_A_const_76 *lang.Var

var A_arbace_go_check_A_const_77 any

var A_arbace_go_check_A_const_78 *lang.Keyword

var A_arbace_go_check_A_const_79 *lang.Var

var A_arbace_go_check_A_const_80 *lang.Keyword

var A_arbace_go_check_A_const_81 *lang.Keyword

var A_arbace_go_check_A_const_82 *lang.Keyword

var A_arbace_go_check_A_const_83 *lang.Keyword

var A_arbace_go_check_A_const_84 *lang.Keyword

var A_arbace_go_check_A_const_85 *lang.Keyword

var A_arbace_go_check_A_const_86 *lang.Var

var A_arbace_go_check_A_const_87 *lang.Var

var A_arbace_go_check_A_const_88 *lang.Var

var A_arbace_go_check_A_const_89 *lang.Keyword

var A_arbace_go_check_A_const_90 *lang.Var

var A_arbace_go_check_A_const_91 *lang.Keyword

var A_arbace_go_check_A_const_92 *lang.Var

var A_arbace_go_check_A_const_93 *lang.Keyword

var A_arbace_go_check_A_const_94 any

var A_arbace_go_check_A_const_95 *lang.Keyword

var A_arbace_go_check_A_const_96 *lang.Var

var A_arbace_go_check_A_const_97 *lang.Var

var A_arbace_go_check_A_const_98 any

var A_arbace_go_check_A_const_99 *lang.Keyword

var A_arbace_go_check_A_const_100 *lang.Keyword

var A_arbace_go_check_A_const_101 *lang.Var

var A_arbace_go_check_A_const_102 *lang.Keyword

var A_arbace_go_check_A_const_103 *lang.Keyword

var A_arbace_go_check_A_const_104 *lang.Keyword

var A_arbace_go_check_A_const_105 *lang.Keyword

var A_arbace_go_check_A_const_106 *lang.Keyword

var A_arbace_go_check_A_const_107 *lang.Keyword

var A_arbace_go_check_A_const_108 *lang.Keyword

var A_arbace_go_check_A_const_109 *lang.Keyword

var A_arbace_go_check_A_const_110 *lang.Keyword

var A_arbace_go_check_A_const_111 *lang.Keyword

var A_arbace_go_check_A_const_112 *lang.Var

var A_arbace_go_check_A_const_113 *lang.Var

var A_arbace_go_check_A_const_114 *lang.Keyword

var A_arbace_go_check_A_const_115 *lang.Var

var A_arbace_go_check_A_const_116 *lang.Var

var A_arbace_go_check_A_const_117 *lang.Keyword

var A_arbace_go_check_A_const_118 *lang.Var

var A_arbace_go_check_A_const_119 any

var A_arbace_go_check_A_const_120 *lang.Var

var A_arbace_go_check_A_const_121 *lang.Var

var A_arbace_go_check_A_const_122 *lang.Var

var A_arbace_go_check_A_const_123 any

var A_arbace_go_check_A_const_124 any

var A_arbace_go_check_A_const_125 *lang.Var

var A_arbace_go_check_A_const_126 *lang.Var

var A_arbace_go_check_A_const_127 *lang.Keyword

var A_arbace_go_check_A_const_128 *lang.Keyword

var A_arbace_go_check_A_const_129 any

var A_arbace_go_check_A_const_130 *lang.Var

var A_arbace_go_check_A_const_131 *lang.Var

var A_arbace_go_check_A_const_132 *lang.Keyword

var A_arbace_go_check_A_const_133 *lang.Keyword

var A_arbace_go_check_A_const_134 *lang.Keyword

var A_arbace_go_check_A_const_135 *lang.Var

var A_arbace_go_check_A_const_136 *lang.Var

var A_arbace_go_check_A_const_137 *lang.Var

var A_arbace_go_check_A_const_138 *lang.Var

var A_arbace_go_check_A_const_139 *lang.Var

var A_arbace_go_check_A_const_140 *lang.Keyword

var A_arbace_go_check_A_const_141 *lang.Var

var A_arbace_go_check_A_const_142 *lang.Keyword

var A_arbace_go_check_A_const_143 *lang.Keyword

var A_arbace_go_check_A_const_144 *lang.Var

var A_arbace_go_check_A_const_145 *lang.Var

var A_arbace_go_check_A_const_146 *lang.Var

var A_arbace_go_check_A_const_147 *lang.Var

var A_arbace_go_check_A_const_148 *lang.Var

var A_arbace_go_check_A_const_149 *lang.Var

var A_arbace_go_check_A_const_150 *lang.Keyword

var A_arbace_go_check_A_const_151 *lang.Keyword

var A_arbace_go_check_A_const_152 *lang.Keyword

var A_arbace_go_check_A_const_153 *lang.Keyword

var A_arbace_go_check_A_const_154 *lang.Var

var A_arbace_go_check_A_const_155 *lang.Var

var A_arbace_go_check_A_const_156 *lang.Var

var A_arbace_go_check_A_const_157 *lang.Var

var A_arbace_go_check_A_const_158 *lang.Var

var A_arbace_go_check_A_const_159 *lang.Var

var A_arbace_go_check_A_const_160 *lang.Var

var A_arbace_go_check_A_const_161 *lang.Var

var A_arbace_go_check_A_const_162 *lang.Var

var A_arbace_go_check_A_const_163 *lang.Var

var A_arbace_go_check_A_const_164 *lang.Var

var A_arbace_go_check_A_const_165 *lang.Var

var A_arbace_go_check_A_const_166 *lang.Var

var A_arbace_go_check_A_const_167 *lang.Var

var A_arbace_go_check_A_const_168 *lang.Var

var A_arbace_go_check_A_const_169 *lang.Var

var A_arbace_go_check_A_const_170 *lang.Var

var A_arbace_go_check_A_const_171 *lang.Var

var A_arbace_go_check_A_const_172 *lang.Var

var A_arbace_go_check_A_const_173 *lang.Var

var A_arbace_go_check_A_const_174 *lang.Var

var A_arbace_go_check_A_const_175 *lang.Var

var A_arbace_go_check_A_const_176 *lang.Var

var A_arbace_go_check_A_const_177 *lang.Var

var A_arbace_go_check_A_const_178 *lang.Var

var A_arbace_go_check_A_const_179 *lang.Keyword

var A_arbace_go_check_A_const_180 *lang.Keyword

var A_arbace_go_check_A_const_181 *lang.Var

var A_arbace_go_check_A_const_182 *lang.Keyword

var A_arbace_go_check_A_const_183 *lang.Keyword

var A_arbace_go_check_A_const_184 *lang.Var

var A_arbace_go_check_A_const_185 *lang.Var

var A_arbace_go_check_A_const_186 *lang.Keyword

var A_arbace_go_check_A_const_187 *lang.Var

var A_arbace_go_check_A_const_188 *lang.Var

var A_arbace_go_check_A_const_189 *lang.Var

var A_arbace_go_check_A_const_190 *lang.Var

var A_arbace_go_check_A_const_191 *lang.Keyword

var A_arbace_go_check_A_const_192 *lang.Var

var A_arbace_go_check_A_const_193 *lang.Var

var A_arbace_go_check_A_const_194 *lang.Var

var A_arbace_go_check_A_const_195 *lang.Var

var A_arbace_go_check_A_const_196 *lang.Keyword

var A_arbace_go_check_A_const_197 *lang.Keyword

var A_arbace_go_check_A_const_198 *lang.Keyword

var A_arbace_go_check_A_const_199 *lang.Var

var A_arbace_go_check_A_const_200 *lang.Var

var A_arbace_go_check_A_const_201 *lang.Keyword

var A_arbace_go_check_A_const_202 *lang.Keyword

var A_arbace_go_check_A_const_203 *lang.Var

var A_arbace_go_check_A_const_204 *lang.Var

var A_arbace_go_check_A_const_205 *lang.Var

var A_arbace_go_check_A_const_206 *lang.Keyword

var A_arbace_go_check_A_const_207 *lang.Keyword

var A_arbace_go_check_A_const_208 *lang.Keyword

var A_arbace_go_check_A_const_209 *lang.Keyword

var A_arbace_go_check_A_const_210 *lang.Var

var A_arbace_go_check_A_const_211 any

var A_arbace_go_check_A_const_212 any

var A_arbace_go_check_A_const_213 *lang.Keyword

var A_arbace_go_check_A_const_214 *lang.Var

var A_arbace_go_check_A_const_215 *lang.Keyword

var A_arbace_go_check_A_const_216 *lang.Keyword

var A_arbace_go_check_A_const_217 *lang.Keyword

var A_arbace_go_check_A_const_218 *lang.Keyword

var A_arbace_go_check_A_const_219 *lang.Keyword

var A_arbace_go_check_A_const_220 *lang.Var

var A_arbace_go_check_A_const_221 *lang.Keyword

var A_arbace_go_check_A_const_222 *lang.Var

var A_arbace_go_check_A_const_223 *lang.Var

var A_arbace_go_check_A_const_224 *lang.Var

var A_arbace_go_check_A_const_225 any

var A_arbace_go_check_A_const_226 *lang.Keyword

var A_arbace_go_check_A_const_227 *lang.Keyword

var A_arbace_go_check_A_const_228 *lang.Var

var A_arbace_go_check_A_const_229 *lang.Var

var A_arbace_go_check_A_const_230 *lang.Var

var A_arbace_go_check_A_const_231 *lang.Var

var A_arbace_go_check_A_const_232 *lang.Var

var A_arbace_go_check_A_const_233 *lang.Var

var A_arbace_go_check_A_const_234 *lang.Keyword

var A_arbace_go_check_A_const_235 *lang.Keyword

var A_arbace_go_check_A_const_236 *lang.Keyword

var A_arbace_go_check_A_const_237 *lang.Keyword

var A_arbace_go_check_A_const_238 *lang.Keyword

var A_arbace_go_check_A_const_239 *lang.Var

var A_arbace_go_check_A_const_240 *lang.Keyword

var A_arbace_go_check_A_const_241 any

var A_arbace_go_check_A_const_242 *lang.Keyword

var A_arbace_go_check_A_const_243 any

var A_arbace_go_check_A_const_244 any

var A_arbace_go_check_A_const_245 any

var A_arbace_go_check_A_const_246 *lang.Keyword

var A_arbace_go_check_A_const_247 *lang.Keyword

var A_arbace_go_check_A_const_248 any

var A_arbace_go_check_A_const_249 *lang.Var

var A_arbace_go_check_A_const_250 *lang.Var

var A_arbace_go_check_A_const_251 *lang.Var

var A_arbace_go_check_A_const_252 *lang.Var

var A_arbace_go_check_A_const_253 *lang.Var

var A_arbace_go_check_A_const_254 any

var A_arbace_go_check_A_const_255 *lang.Var

var A_arbace_go_check_A_const_256 *lang.Keyword

var A_arbace_go_check_A_const_257 *lang.Keyword

var A_arbace_go_check_A_const_258 *lang.Keyword

var A_arbace_go_check_A_const_259 *lang.Keyword

var A_arbace_go_check_A_const_260 *lang.Var

var A_arbace_go_check_A_const_261 *lang.Var

var A_arbace_go_check_A_const_262 *lang.Var

var A_arbace_go_check_A_const_263 *lang.Var

var A_arbace_go_check_A_const_264 *lang.Var

var A_arbace_go_check_A_const_265 *lang.Var

var A_arbace_go_check_A_const_266 *lang.Keyword

var A_arbace_go_check_A_const_267 *lang.Var

var A_arbace_go_check_A_const_268 *lang.Var

var A_arbace_go_check_A_const_269 *lang.Var

var A_arbace_go_check_A_const_270 *lang.Var

var A_arbace_go_check_A_const_271 *lang.Var

var A_arbace_go_check_A_const_272 any

var A_arbace_go_check_A_const_273 *lang.Var

var A_arbace_go_check_A_const_274 any

var A_arbace_go_check_A_const_275 any

var A_arbace_go_check_A_const_276 *lang.Var

var A_arbace_go_check_A_const_277 *lang.Keyword

var A_arbace_go_check_A_const_278 *lang.Keyword

var A_arbace_go_check_A_const_279 *lang.Keyword

var A_arbace_go_check_A_const_280 *lang.Keyword

var A_arbace_go_check_A_const_281 *lang.Var

var A_arbace_go_check_A_const_282 *lang.Keyword

var A_arbace_go_check_A_const_283 *lang.Keyword

var A_arbace_go_check_A_const_284 *lang.Var

var A_arbace_go_check_A_const_285 *lang.Keyword

var A_arbace_go_check_A_const_286 any

var A_arbace_go_check_A_const_287 *lang.Keyword

var A_arbace_go_check_A_const_288 *lang.Keyword

var A_arbace_go_check_A_const_289 *lang.Var

var A_arbace_go_check_A_const_290 any

var A_arbace_go_check_A_const_291 any

var A_arbace_go_check_A_const_292 *lang.Var

var A_arbace_go_check_A_const_293 *lang.Var

var A_arbace_go_check_A_const_294 any

var A_arbace_go_check_A_const_295 *lang.Var

var A_arbace_go_check_A_const_296 any

var A_arbace_go_check_A_const_297 *lang.Var

var A_arbace_go_check_A_const_298 *lang.Var

var A_arbace_go_check_A_const_299 *lang.Var

var A_arbace_go_check_A_const_300 *lang.Var

var A_arbace_go_check_A_const_301 *lang.Var

var A_arbace_go_check_A_const_302 *lang.Var

var A_arbace_go_check_A_const_303 *lang.Var

var A_arbace_go_check_A_const_304 *lang.Var

var A_arbace_go_check_A_const_305 *lang.Var

var A_arbace_go_check_A_const_306 *lang.Var

var A_arbace_go_check_A_const_307 *lang.Var

var A_arbace_go_check_A_const_308 *lang.Var

var A_arbace_go_check_A_const_309 *lang.Keyword

var A_arbace_go_check_A_const_310 *lang.Keyword

var A_arbace_go_check_A_const_311 *lang.Keyword

var A_arbace_go_check_A_const_312 *lang.Var

var A_arbace_go_check_A_const_313 *lang.Var

var A_arbace_go_check_A_const_314 *jrt.Class

var A_arbace_go_check_A_const_315 *lang.Var

var A_arbace_go_check_A_const_316 *lang.Var

var A_arbace_go_check_A_const_317 *lang.Var

var A_arbace_go_check_A_const_318 any

var A_arbace_go_check_A_const_319 any

var A_arbace_go_check_A_const_320 *lang.Keyword

var A_arbace_go_check_A_const_321 *lang.Var

var A_arbace_go_check_A_const_322 *lang.Keyword

var A_arbace_go_check_A_const_323 *lang.Keyword

var A_arbace_go_check_A_const_324 *lang.Var

var A_arbace_go_check_A_const_325 *lang.Var

var A_arbace_go_check_A_const_326 any

var A_arbace_go_check_A_const_327 any

var A_arbace_go_check_A_const_328 any

var A_arbace_go_check_A_const_329 any

var A_arbace_go_check_A_const_330 any

var A_arbace_go_check_A_const_331 *lang.Var

var A_arbace_go_check_A_const_332 any

var A_arbace_go_check_A_const_333 any

var A_arbace_go_check_A_const_334 any

var A_arbace_go_check_A_const_335 any

var A_arbace_go_check_A_const_336 *lang.Keyword

var A_arbace_go_check_A_const_337 *lang.Var

var A_arbace_go_check_A_const_338 *lang.Var

var A_arbace_go_check_A_const_339 *lang.Var

var A_arbace_go_check_A_const_340 *lang.Var

var A_arbace_go_check_A_const_341 *lang.Var

var A_arbace_go_check_A_const_342 *lang.Var

var A_arbace_go_check_A_const_343 *lang.Var

var A_arbace_go_check_A_init jrt.ClassInit

func A_arbace_go_check_A_Init() { if !A_arbace_go_check_A_init.Done() { A_arbace_go_check_A_init.Run(A_arbace_go_check_A_clinit) } }

func A_arbace_go_check_A_clinit() { A_arbace_go_check_A_clinit_p0(); A_arbace_go_check_A_clinit_p1(); A_arbace_go_check_A_clinit_p2(); A_arbace_go_check_A_clinit_p3(); A_arbace_go_check_A_clinit_p4(); A_arbace_go_check_A_clinit_p5(); A_arbace_go_check_A_clinit_p6(); A_arbace_go_check_A_clinit_p7(); A_arbace_go_check_A_clinit_p8(); A_arbace_go_check_A_clinit_p9(); A_arbace_go_check_A_clinit_p10(); A_arbace_go_check_A_clinit_p11(); A_arbace_go_check_A_clinit_p12(); A_arbace_go_check_A_clinit_p13(); A_arbace_go_check_A_clinit_p14(); A_arbace_go_check_A_clinit_p15(); A_arbace_go_check_A_clinit_p16(); A_arbace_go_check_A_clinit_p17(); A_arbace_go_check_A_clinit_p18(); A_arbace_go_check_A_clinit_p19(); A_arbace_go_check_A_clinit_p20(); A_arbace_go_check_A_clinit_p21(); A_arbace_go_check_A_clinit_p22(); A_arbace_go_check_A_clinit_p23(); A_arbace_go_check_A_clinit_p24(); A_arbace_go_check_A_clinit_p25(); A_arbace_go_check_A_clinit_p26(); A_arbace_go_check_A_clinit_p27(); A_arbace_go_check_A_clinit_p28() }

func A_arbace_go_check_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 505); A_arbace_go_check_A_const_0 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[161]); A_arbace_go_check_A_const_1 = A_arbace_go_check_A_const_pool.A[162]; A_arbace_go_check_A_const_2 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[163]); A_arbace_go_check_A_const_3 = A_arbace_go_check_A_const_pool.A[164]; A_arbace_go_check_A_const_4 = A_arbace_go_check_A_const_pool.A[165]; A_arbace_go_check_A_const_5 = A_arbace_go_check_A_const_pool.A[166]; A_arbace_go_check_A_const_6 = A_arbace_go_check_A_const_pool.A[167]; A_arbace_go_check_A_const_7 = A_arbace_go_check_A_const_pool.A[168]; A_arbace_go_check_A_const_8 = A_arbace_go_check_A_const_pool.A[169]; A_arbace_go_check_A_const_9 = A_arbace_go_check_A_const_pool.A[170]; A_arbace_go_check_A_const_10 = A_arbace_go_check_A_const_pool.A[171]; A_arbace_go_check_A_const_11 = A_arbace_go_check_A_const_pool.A[172]; A_arbace_go_check_A_const_12 = A_arbace_go_check_A_const_pool.A[173]; A_arbace_go_check_A_const_13 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[174]) }

func A_arbace_go_check_A_clinit_p1() { A_arbace_go_check_A_const_14 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[175]); A_arbace_go_check_A_const_15 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[176]); A_arbace_go_check_A_const_16 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[177]); A_arbace_go_check_A_const_17 = A_arbace_go_check_A_const_pool.A[178]; A_arbace_go_check_A_const_18 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[179]); A_arbace_go_check_A_const_19 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[180]); A_arbace_go_check_A_const_20 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[181]); A_arbace_go_check_A_const_21 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[182]); A_arbace_go_check_A_const_22 = A_arbace_go_check_A_const_pool.A[183]; A_arbace_go_check_A_const_23 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[184]); A_arbace_go_check_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[185]); A_arbace_go_check_A_const_25 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[186]) }

func A_arbace_go_check_A_clinit_p2() { A_arbace_go_check_A_const_26 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[187]); A_arbace_go_check_A_const_27 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[188]); A_arbace_go_check_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[189]); A_arbace_go_check_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[190]); A_arbace_go_check_A_const_30 = A_arbace_go_check_A_const_pool.A[191]; A_arbace_go_check_A_const_31 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[192]); A_arbace_go_check_A_const_32 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[193]); A_arbace_go_check_A_const_33 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[194]); A_arbace_go_check_A_const_34 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[195]); A_arbace_go_check_A_const_35 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[196]); A_arbace_go_check_A_const_36 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[197]); A_arbace_go_check_A_const_37 = A_arbace_go_check_A_const_pool.A[198] }

func A_arbace_go_check_A_clinit_p3() { A_arbace_go_check_A_const_38 = A_arbace_go_check_A_const_pool.A[199]; A_arbace_go_check_A_const_39 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[200]); A_arbace_go_check_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[201]); A_arbace_go_check_A_const_41 = A_arbace_go_check_A_const_pool.A[202]; A_arbace_go_check_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[203]); A_arbace_go_check_A_const_43 = A_arbace_go_check_A_const_pool.A[204]; A_arbace_go_check_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[205]); A_arbace_go_check_A_const_45 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[206]); A_arbace_go_check_A_const_46 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[207]); A_arbace_go_check_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[208]); A_arbace_go_check_A_const_48 = A_arbace_go_check_A_const_pool.A[209]; A_arbace_go_check_A_const_49 = A_arbace_go_check_A_const_pool.A[210]; A_arbace_go_check_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[211]) }

func A_arbace_go_check_A_clinit_p4() { A_arbace_go_check_A_const_51 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[212]); A_arbace_go_check_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[213]); A_arbace_go_check_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[214]); A_arbace_go_check_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[215]); A_arbace_go_check_A_const_55 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[216]); A_arbace_go_check_A_const_56 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[217]); A_arbace_go_check_A_const_57 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[218]); A_arbace_go_check_A_const_58 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[219]); A_arbace_go_check_A_const_59 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[220]); A_arbace_go_check_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[221]); A_arbace_go_check_A_const_61 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[222]); A_arbace_go_check_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[223]) }

func A_arbace_go_check_A_clinit_p5() { A_arbace_go_check_A_const_63 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[224]); A_arbace_go_check_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[225]); A_arbace_go_check_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[226]); A_arbace_go_check_A_const_66 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[227]); A_arbace_go_check_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[228]); A_arbace_go_check_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[229]); A_arbace_go_check_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[230]); A_arbace_go_check_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[231]); A_arbace_go_check_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[232]); A_arbace_go_check_A_const_72 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[233]); A_arbace_go_check_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[234]); A_arbace_go_check_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[235]) }

func A_arbace_go_check_A_clinit_p6() { A_arbace_go_check_A_const_75 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[236]); A_arbace_go_check_A_const_76 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[237]); A_arbace_go_check_A_const_77 = A_arbace_go_check_A_const_pool.A[238]; A_arbace_go_check_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[239]); A_arbace_go_check_A_const_79 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[240]); A_arbace_go_check_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[241]); A_arbace_go_check_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[242]); A_arbace_go_check_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[243]); A_arbace_go_check_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[244]); A_arbace_go_check_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[245]); A_arbace_go_check_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[246]); A_arbace_go_check_A_const_86 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[247]) }

func A_arbace_go_check_A_clinit_p7() { A_arbace_go_check_A_const_87 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[248]); A_arbace_go_check_A_const_88 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[249]); A_arbace_go_check_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[250]); A_arbace_go_check_A_const_90 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[251]); A_arbace_go_check_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[252]); A_arbace_go_check_A_const_92 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[253]); A_arbace_go_check_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[254]); A_arbace_go_check_A_const_94 = A_arbace_go_check_A_const_pool.A[255]; A_arbace_go_check_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[256]); A_arbace_go_check_A_const_96 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[257]); A_arbace_go_check_A_const_97 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[258]); A_arbace_go_check_A_const_98 = A_arbace_go_check_A_const_pool.A[259] }

func A_arbace_go_check_A_clinit_p8() { A_arbace_go_check_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[260]); A_arbace_go_check_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[261]); A_arbace_go_check_A_const_101 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[262]); A_arbace_go_check_A_const_102 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[263]); A_arbace_go_check_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[264]); A_arbace_go_check_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[265]); A_arbace_go_check_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[266]); A_arbace_go_check_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[267]); A_arbace_go_check_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[268]); A_arbace_go_check_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[269]); A_arbace_go_check_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[270]); A_arbace_go_check_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[271]) }

func A_arbace_go_check_A_clinit_p9() { A_arbace_go_check_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[272]); A_arbace_go_check_A_const_112 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[273]); A_arbace_go_check_A_const_113 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[274]); A_arbace_go_check_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[275]); A_arbace_go_check_A_const_115 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[276]); A_arbace_go_check_A_const_116 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[277]); A_arbace_go_check_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[278]); A_arbace_go_check_A_const_118 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[279]); A_arbace_go_check_A_const_119 = A_arbace_go_check_A_const_pool.A[280]; A_arbace_go_check_A_const_120 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[281]); A_arbace_go_check_A_const_121 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[282]); A_arbace_go_check_A_const_122 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[283]) }

func A_arbace_go_check_A_clinit_p10() { A_arbace_go_check_A_const_123 = A_arbace_go_check_A_const_pool.A[284]; A_arbace_go_check_A_const_124 = A_arbace_go_check_A_const_pool.A[285]; A_arbace_go_check_A_const_125 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[286]); A_arbace_go_check_A_const_126 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[287]); A_arbace_go_check_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[288]); A_arbace_go_check_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[289]); A_arbace_go_check_A_const_129 = A_arbace_go_check_A_const_pool.A[290]; A_arbace_go_check_A_const_130 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[291]); A_arbace_go_check_A_const_131 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[292]); A_arbace_go_check_A_const_132 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[293]); A_arbace_go_check_A_const_133 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[294]); A_arbace_go_check_A_const_134 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[295]) }

func A_arbace_go_check_A_clinit_p11() { A_arbace_go_check_A_const_135 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[296]); A_arbace_go_check_A_const_136 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[297]); A_arbace_go_check_A_const_137 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[298]); A_arbace_go_check_A_const_138 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[299]); A_arbace_go_check_A_const_139 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[300]); A_arbace_go_check_A_const_140 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[301]); A_arbace_go_check_A_const_141 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[302]); A_arbace_go_check_A_const_142 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[303]); A_arbace_go_check_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[304]); A_arbace_go_check_A_const_144 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[305]); A_arbace_go_check_A_const_145 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[306]); A_arbace_go_check_A_const_146 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[307]) }

func A_arbace_go_check_A_clinit_p12() { A_arbace_go_check_A_const_147 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[308]); A_arbace_go_check_A_const_148 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[309]); A_arbace_go_check_A_const_149 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[310]); A_arbace_go_check_A_const_150 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[311]); A_arbace_go_check_A_const_151 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[312]); A_arbace_go_check_A_const_152 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[313]); A_arbace_go_check_A_const_153 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[314]); A_arbace_go_check_A_const_154 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[315]); A_arbace_go_check_A_const_155 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[316]); A_arbace_go_check_A_const_156 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[317]); A_arbace_go_check_A_const_157 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[318]); A_arbace_go_check_A_const_158 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[319]) }

func A_arbace_go_check_A_clinit_p13() { A_arbace_go_check_A_const_159 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[320]); A_arbace_go_check_A_const_160 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[321]); A_arbace_go_check_A_const_161 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[322]); A_arbace_go_check_A_const_162 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[323]); A_arbace_go_check_A_const_163 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[324]); A_arbace_go_check_A_const_164 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[325]); A_arbace_go_check_A_const_165 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[326]); A_arbace_go_check_A_const_166 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[327]); A_arbace_go_check_A_const_167 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[328]); A_arbace_go_check_A_const_168 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[329]); A_arbace_go_check_A_const_169 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[330]); A_arbace_go_check_A_const_170 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[331]) }

func A_arbace_go_check_A_clinit_p14() { A_arbace_go_check_A_const_171 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[332]); A_arbace_go_check_A_const_172 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[333]); A_arbace_go_check_A_const_173 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[334]); A_arbace_go_check_A_const_174 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[335]); A_arbace_go_check_A_const_175 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[336]); A_arbace_go_check_A_const_176 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[337]); A_arbace_go_check_A_const_177 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[338]); A_arbace_go_check_A_const_178 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[339]); A_arbace_go_check_A_const_179 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[340]); A_arbace_go_check_A_const_180 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[341]); A_arbace_go_check_A_const_181 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[342]); A_arbace_go_check_A_const_182 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[343]) }

func A_arbace_go_check_A_clinit_p15() { A_arbace_go_check_A_const_183 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[344]); A_arbace_go_check_A_const_184 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[345]); A_arbace_go_check_A_const_185 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[346]); A_arbace_go_check_A_const_186 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[347]); A_arbace_go_check_A_const_187 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[348]); A_arbace_go_check_A_const_188 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[349]); A_arbace_go_check_A_const_189 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[350]); A_arbace_go_check_A_const_190 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[351]); A_arbace_go_check_A_const_191 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[352]); A_arbace_go_check_A_const_192 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[353]); A_arbace_go_check_A_const_193 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[354]); A_arbace_go_check_A_const_194 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[355]) }

func A_arbace_go_check_A_clinit_p16() { A_arbace_go_check_A_const_195 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[356]); A_arbace_go_check_A_const_196 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[357]); A_arbace_go_check_A_const_197 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[358]); A_arbace_go_check_A_const_198 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[359]); A_arbace_go_check_A_const_199 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[360]); A_arbace_go_check_A_const_200 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[361]); A_arbace_go_check_A_const_201 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[362]); A_arbace_go_check_A_const_202 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[363]); A_arbace_go_check_A_const_203 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[364]); A_arbace_go_check_A_const_204 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[365]); A_arbace_go_check_A_const_205 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[366]); A_arbace_go_check_A_const_206 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[367]) }

func A_arbace_go_check_A_clinit_p17() { A_arbace_go_check_A_const_207 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[368]); A_arbace_go_check_A_const_208 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[369]); A_arbace_go_check_A_const_209 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[370]); A_arbace_go_check_A_const_210 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[371]); A_arbace_go_check_A_const_211 = A_arbace_go_check_A_const_pool.A[372]; A_arbace_go_check_A_const_212 = A_arbace_go_check_A_const_pool.A[373]; A_arbace_go_check_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[374]); A_arbace_go_check_A_const_214 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[375]); A_arbace_go_check_A_const_215 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[376]); A_arbace_go_check_A_const_216 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[377]); A_arbace_go_check_A_const_217 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[378]); A_arbace_go_check_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[379]) }

func A_arbace_go_check_A_clinit_p18() { A_arbace_go_check_A_const_219 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[380]); A_arbace_go_check_A_const_220 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[381]); A_arbace_go_check_A_const_221 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[382]); A_arbace_go_check_A_const_222 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[383]); A_arbace_go_check_A_const_223 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[384]); A_arbace_go_check_A_const_224 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[385]); A_arbace_go_check_A_const_225 = A_arbace_go_check_A_const_pool.A[386]; A_arbace_go_check_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[387]); A_arbace_go_check_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[388]); A_arbace_go_check_A_const_228 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[389]); A_arbace_go_check_A_const_229 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[390]); A_arbace_go_check_A_const_230 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[391]) }

func A_arbace_go_check_A_clinit_p19() { A_arbace_go_check_A_const_231 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[392]); A_arbace_go_check_A_const_232 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[393]); A_arbace_go_check_A_const_233 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[394]); A_arbace_go_check_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[395]); A_arbace_go_check_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[396]); A_arbace_go_check_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[397]); A_arbace_go_check_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[398]); A_arbace_go_check_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[399]); A_arbace_go_check_A_const_239 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[400]); A_arbace_go_check_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[401]); A_arbace_go_check_A_const_241 = A_arbace_go_check_A_const_pool.A[402]; A_arbace_go_check_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[403]) }

func A_arbace_go_check_A_clinit_p20() { A_arbace_go_check_A_const_243 = A_arbace_go_check_A_const_pool.A[404]; A_arbace_go_check_A_const_244 = A_arbace_go_check_A_const_pool.A[405]; A_arbace_go_check_A_const_245 = A_arbace_go_check_A_const_pool.A[406]; A_arbace_go_check_A_const_246 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[407]); A_arbace_go_check_A_const_247 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[408]); A_arbace_go_check_A_const_248 = A_arbace_go_check_A_const_pool.A[409]; A_arbace_go_check_A_const_249 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[410]); A_arbace_go_check_A_const_250 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[411]); A_arbace_go_check_A_const_251 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[412]); A_arbace_go_check_A_const_252 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[413]); A_arbace_go_check_A_const_253 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[414]); A_arbace_go_check_A_const_254 = A_arbace_go_check_A_const_pool.A[415]; A_arbace_go_check_A_const_255 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[416]) }

func A_arbace_go_check_A_clinit_p21() { A_arbace_go_check_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[417]); A_arbace_go_check_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[418]); A_arbace_go_check_A_const_258 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[419]); A_arbace_go_check_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[420]); A_arbace_go_check_A_const_260 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[421]); A_arbace_go_check_A_const_261 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[422]); A_arbace_go_check_A_const_262 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[423]); A_arbace_go_check_A_const_263 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[424]); A_arbace_go_check_A_const_264 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[425]); A_arbace_go_check_A_const_265 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[426]); A_arbace_go_check_A_const_266 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[427]); A_arbace_go_check_A_const_267 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[428]) }

func A_arbace_go_check_A_clinit_p22() { A_arbace_go_check_A_const_268 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[429]); A_arbace_go_check_A_const_269 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[430]); A_arbace_go_check_A_const_270 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[431]); A_arbace_go_check_A_const_271 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[432]); A_arbace_go_check_A_const_272 = A_arbace_go_check_A_const_pool.A[433]; A_arbace_go_check_A_const_273 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[434]); A_arbace_go_check_A_const_274 = A_arbace_go_check_A_const_pool.A[435]; A_arbace_go_check_A_const_275 = A_arbace_go_check_A_const_pool.A[436]; A_arbace_go_check_A_const_276 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[437]); A_arbace_go_check_A_const_277 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[438]); A_arbace_go_check_A_const_278 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[439]); A_arbace_go_check_A_const_279 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[440]) }

func A_arbace_go_check_A_clinit_p23() { A_arbace_go_check_A_const_280 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[441]); A_arbace_go_check_A_const_281 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[442]); A_arbace_go_check_A_const_282 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[443]); A_arbace_go_check_A_const_283 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[444]); A_arbace_go_check_A_const_284 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[445]); A_arbace_go_check_A_const_285 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[446]); A_arbace_go_check_A_const_286 = A_arbace_go_check_A_const_pool.A[447]; A_arbace_go_check_A_const_287 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[448]); A_arbace_go_check_A_const_288 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[449]); A_arbace_go_check_A_const_289 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[450]); A_arbace_go_check_A_const_290 = A_arbace_go_check_A_const_pool.A[451]; A_arbace_go_check_A_const_291 = A_arbace_go_check_A_const_pool.A[452] }

func A_arbace_go_check_A_clinit_p24() { A_arbace_go_check_A_const_292 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[453]); A_arbace_go_check_A_const_293 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[454]); A_arbace_go_check_A_const_294 = A_arbace_go_check_A_const_pool.A[455]; A_arbace_go_check_A_const_295 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[456]); A_arbace_go_check_A_const_296 = A_arbace_go_check_A_const_pool.A[457]; A_arbace_go_check_A_const_297 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[458]); A_arbace_go_check_A_const_298 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[459]); A_arbace_go_check_A_const_299 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[460]); A_arbace_go_check_A_const_300 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[461]); A_arbace_go_check_A_const_301 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[462]); A_arbace_go_check_A_const_302 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[463]); A_arbace_go_check_A_const_303 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[464]) }

func A_arbace_go_check_A_clinit_p25() { A_arbace_go_check_A_const_304 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[465]); A_arbace_go_check_A_const_305 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[466]); A_arbace_go_check_A_const_306 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[467]); A_arbace_go_check_A_const_307 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[468]); A_arbace_go_check_A_const_308 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[469]); A_arbace_go_check_A_const_309 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[470]); A_arbace_go_check_A_const_310 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[471]); A_arbace_go_check_A_const_311 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[472]); A_arbace_go_check_A_const_312 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[473]); A_arbace_go_check_A_const_313 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[474]); A_arbace_go_check_A_const_314 = jrt.Class_Cast(A_arbace_go_check_A_const_pool.A[475]); A_arbace_go_check_A_const_315 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[476]) }

func A_arbace_go_check_A_clinit_p26() { A_arbace_go_check_A_const_316 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[477]); A_arbace_go_check_A_const_317 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[478]); A_arbace_go_check_A_const_318 = A_arbace_go_check_A_const_pool.A[479]; A_arbace_go_check_A_const_319 = A_arbace_go_check_A_const_pool.A[480]; A_arbace_go_check_A_const_320 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[481]); A_arbace_go_check_A_const_321 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[482]); A_arbace_go_check_A_const_322 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[483]); A_arbace_go_check_A_const_323 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[484]); A_arbace_go_check_A_const_324 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[485]); A_arbace_go_check_A_const_325 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[486]); A_arbace_go_check_A_const_326 = A_arbace_go_check_A_const_pool.A[487]; A_arbace_go_check_A_const_327 = A_arbace_go_check_A_const_pool.A[488]; A_arbace_go_check_A_const_328 = A_arbace_go_check_A_const_pool.A[489] }

func A_arbace_go_check_A_clinit_p27() { A_arbace_go_check_A_const_329 = A_arbace_go_check_A_const_pool.A[490]; A_arbace_go_check_A_const_330 = A_arbace_go_check_A_const_pool.A[491]; A_arbace_go_check_A_const_331 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[492]); A_arbace_go_check_A_const_332 = A_arbace_go_check_A_const_pool.A[493]; A_arbace_go_check_A_const_333 = A_arbace_go_check_A_const_pool.A[494]; A_arbace_go_check_A_const_334 = A_arbace_go_check_A_const_pool.A[495]; A_arbace_go_check_A_const_335 = A_arbace_go_check_A_const_pool.A[496]; A_arbace_go_check_A_const_336 = lang.Keyword_Cast(A_arbace_go_check_A_const_pool.A[497]); A_arbace_go_check_A_const_337 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[498]); A_arbace_go_check_A_const_338 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[499]); A_arbace_go_check_A_const_339 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[500]); A_arbace_go_check_A_const_340 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[501]); A_arbace_go_check_A_const_341 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[502]) }

func A_arbace_go_check_A_clinit_p28() { A_arbace_go_check_A_const_342 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[503]); A_arbace_go_check_A_const_343 = lang.Var_Cast(A_arbace_go_check_A_const_pool.A[504]) }

func A_arbace_go_check_A_New() *A_arbace_go_check_A { A_arbace_go_check_A_Init(); t := &A_arbace_go_check_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_A) Ctor() {}

func (t *A_arbace_go_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_A_class }

func (t *A_arbace_go_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_A); return ok }

func A_arbace_go_check_A_Cast(x any) *A_arbace_go_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_A_class)) }; return v }



type A_arbace_go_check__main_A struct{ j2g_header uint64 }

var A_arbace_go_check__main_A_fn_class *jrt.Class



type A_arbace_go_check__main_fn__1685000441_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_check__main_fn__1685000441_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000444__1685000448_A struct{ j2g_header uint64; F_opts any }

var A_arbace_go_check__main_iter__1685000444__1685000448_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A struct{ j2g_header uint64; F_opts, F_s__1685000445, F_iter__1685000444 any }

var A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_A_fn_class *jrt.Class



type A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A struct{ j2g_header uint64; F_b__1685000447, F_opts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check__main_iter__1685000444__1685000448_fn__1685000449_fn__1685000450_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000416__1685000422_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_iter__1685000416__1685000422_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A struct{ j2g_header uint64; F_iter__1685000416, F_s__1685000417 any }

var A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A struct{ j2g_header uint64; F_s__1685000419, F_iter__1685000418, F_r any }

var A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A struct{ j2g_header uint64; F_b__1685000421, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_annotations_iter__1685000416__1685000422_fn__1685000423_iter__1685000418__1685000424_fn__1685000425_fn__1685000426_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_A struct{ j2g_header uint64 }

var A_arbace_go_check_annotations_present_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_add_BANG___1685000012_A struct{ j2g_header uint64; F_acc any }

var A_arbace_go_check_annotations_present_add_BANG___1685000012_A_fn_class *jrt.Class



type A_arbace_go_check_annotations_present_walk__1685000014_A struct{ j2g_header uint64; F_add_BANG_ any }

var A_arbace_go_check_annotations_present_walk__1685000014_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000296_A struct{ j2g_header uint64; F_s any }

var A_arbace_go_check_check_corpus_fn__1685000296_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000300_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000300_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000304_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000304_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_A struct{ j2g_header uint64; F_dir, F_s, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000310_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A struct{ j2g_header uint64; F_by_path, F_root, F_cc any }

var A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000324_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A struct{ j2g_header uint64; F_by_path any }

var A_arbace_go_check_check_corpus_fn__1685000310_fn__1685000326_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A struct{ j2g_header uint64; F_iter__1685000314, F_s__1685000315 any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A struct{ j2g_header uint64; F_b__1685000317 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000314__1685000318_fn__1685000319_fn__1685000320_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A struct{ j2g_header uint64; F_iter__1685000328, F_dir, F_tdir, F_ts, F_s__1685000329 any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A struct{ j2g_header uint64; F_dir, F_tdir, F_ts any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1685000331 any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000334_fn__1685000338_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A struct{ j2g_header uint64; F_path, F_dir, F_tdir, F_ts any }

var A_arbace_go_check_check_corpus_fn__1685000310_iter__1685000328__1685000332_fn__1685000333_fn__1685000344_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_corpus_iter__1685000286__1685000290_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A struct{ j2g_header uint64; F_s__1685000287, F_iter__1685000286 any }

var A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_A_fn_class *jrt.Class



type A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A struct{ j2g_header uint64; F_b__1685000289 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_corpus_iter__1685000286__1685000290_fn__1685000291_fn__1685000292_A_fn_class *jrt.Class



type A_arbace_go_check_check_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_forms_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000099_A struct{ j2g_header uint64; F_src, F_pkg_scope any }

var A_arbace_go_check_check_package_fn__1685000099_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000135_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000135_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000142_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000142_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000149_A struct{ j2g_header uint64; F_d, F_ls any }

var A_arbace_go_check_check_package_fn__1685000149_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000159_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000159_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000161_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_check_check_package_fn__1685000161_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000179_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000179_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000181_A struct{ j2g_header uint64; F_generic_ids any }

var A_arbace_go_check_check_package_fn__1685000181_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000187_A struct{ j2g_header uint64; F_m any }

var A_arbace_go_check_check_package_fn__1685000187_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000190_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000194_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000196_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000198_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000200_fn__1685000201_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A struct{ j2g_header uint64; F_present any }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000220_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000222_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A struct{ j2g_header uint64; F_unver any }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000224_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A struct{ j2g_header uint64; F_form, F_unver, F_ds any }

var A_arbace_go_check_check_package_fn__1685000190_fn__1685000226_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A struct{ j2g_header uint64; F_verified any }

var A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A struct{ j2g_header uint64; F_iter__1685000204, F_verified, F_s__1685000205 any }

var A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A struct{ j2g_header uint64; F_verified, F_b__1685000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_fn__1685000190_iter__1685000204__1685000208_fn__1685000209_fn__1685000210_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_fn__1685000233_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_fn__1685000233_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000171_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000171_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_init_entry__1685000171_one__1685000172_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000235__1685000239_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_iter__1685000235__1685000239_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A struct{ j2g_header uint64; F_s__1685000236, F_iter__1685000235 any }

var A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A struct{ j2g_header uint64; F_b__1685000238 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_check_package_iter__1685000235__1685000239_fn__1685000240_fn__1685000241_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000175_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000175_A_fn_class *jrt.Class



type A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A struct{ j2g_header uint64 }

var A_arbace_go_check_check_package_norm__1685000175_fn__1685000176_A_fn_class *jrt.Class



type A_arbace_go_check_corpus_config_A struct{ j2g_header uint64 }

var A_arbace_go_check_corpus_config_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_ensure_package_A_fn_class *jrt.Class



type A_arbace_go_check_ensure_package_fn__1685000250_A struct{ j2g_header uint64; F_path, F_p, F_s, F_src, F_chain any }

var A_arbace_go_check_ensure_package_fn__1685000250_A_fn_class *jrt.Class



type A_arbace_go_check_error_result_A struct{ j2g_header uint64 }

var A_arbace_go_check_error_result_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000004_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000004_A_New() *A_arbace_go_check_eval1685000004_A { t := &A_arbace_go_check_eval1685000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000004_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000004_A_class }

func (t *A_arbace_go_check_eval1685000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000004_A); return ok }

func A_arbace_go_check_eval1685000004_A_Cast(x any) *A_arbace_go_check_eval1685000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000004_A_class)) }; return v }



type A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000004_loading__1927001464__auto____1685000005_A_fn_class *jrt.Class



type A_arbace_go_check_eval1685000008_A struct{ jrt.Object }

func A_arbace_go_check_eval1685000008_A_New() *A_arbace_go_check_eval1685000008_A { t := &A_arbace_go_check_eval1685000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_eval1685000008_A) Ctor() {}

func (t *A_arbace_go_check_eval1685000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_eval1685000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_eval1685000008_A_class }

func (t *A_arbace_go_check_eval1685000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_eval1685000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_eval1685000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_eval1685000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_eval1685000008_A); return ok }

func A_arbace_go_check_eval1685000008_A_Cast(x any) *A_arbace_go_check_eval1685000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_eval1685000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_eval1685000008_A_class)) }; return v }



type A_arbace_go_check_eval1685000008_fn__1685000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_eval1685000008_fn__1685000009_A_fn_class *jrt.Class



type A_arbace_go_check_file_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_file_info_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_fn__1685000393_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_fn__1685000393_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000395__1685000399_A struct{ j2g_header uint64 }

var A_arbace_go_check_forms_source_iter__1685000395__1685000399_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A struct{ j2g_header uint64; F_s__1685000396, F_iter__1685000395 any }

var A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_A_fn_class *jrt.Class



type A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A struct{ j2g_header uint64; F_b__1685000398 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_forms_source_iter__1685000395__1685000399_fn__1685000400_fn__1685000401_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_mark_qualifiers_used_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk2__1685000061_A_fn_class *jrt.Class



type A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_check_mark_qualifiers_used_BANG__walk__1685000048_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_A struct{ j2g_header uint64 }

var A_arbace_go_check_nodes_seq_A_fn_class *jrt.Class



type A_arbace_go_check_nodes_seq_walk__1685000025_A struct{ j2g_header uint64; F_seen, F_acc any }

var A_arbace_go_check_nodes_seq_walk__1685000025_A_fn_class *jrt.Class



type A_arbace_go_check_read_string_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_read_string_forms_A_fn_class *jrt.Class



type A_arbace_go_check_reference_path_A struct{ j2g_header uint64 }

var A_arbace_go_check_reference_path_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000373__1685000379_A struct{ j2g_header uint64 }

var A_arbace_go_check_report_errors_iter__1685000373__1685000379_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A struct{ j2g_header uint64; F_s__1685000374, F_iter__1685000373 any }

var A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A struct{ j2g_header uint64; F_r, F_s__1685000376, F_iter__1685000375 any }

var A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_A_fn_class *jrt.Class



type A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A struct{ j2g_header uint64; F_b__1685000378, F_r any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_report_errors_iter__1685000373__1685000379_fn__1685000380_iter__1685000375__1685000381_fn__1685000382_fn__1685000383_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_A struct{ j2g_header uint64 }

var A_arbace_go_check_resolver_A_fn_class *jrt.Class



type A_arbace_go_check_resolver_fn__1685000247_A struct{ j2g_header uint64; F_src, F_s, F_chain any }

var A_arbace_go_check_resolver_fn__1685000247_A_fn_class *jrt.Class



type A_arbace_go_check_result_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_result_of_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_A struct{ j2g_header uint64 }

var A_arbace_go_check_run_parallel_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000264__1685000268_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A struct{ j2g_header uint64; F_f, F_out, F_q, F_s__1685000265, F_xs, F_iter__1685000264 any }

var A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A struct{ j2g_header uint64; F_b__1685000267, F_f, F_out, F_q, F_xs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000270_fn__1685000271_A_fn_class *jrt.Class



type A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A struct{ j2g_header uint64; F_f, F_out, F_q, F_xs any }

var A_arbace_go_check_run_parallel_iter__1685000264__1685000268_fn__1685000269_fn__1685000274_A_fn_class *jrt.Class



type A_arbace_go_check_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_A struct{ j2g_header uint64 }

var A_arbace_go_check_std_session_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000259_A struct{ j2g_header uint64; F_roots, F_config any }

var A_arbace_go_check_std_session_fn__1685000259_A_fn_class *jrt.Class



type A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A struct{ j2g_header uint64; F_path, F_config any }

var A_arbace_go_check_std_session_fn__1685000259_fn__1685000260_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000360_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000360_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000362_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000362_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000364_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000364_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000366_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000366_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000368_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000368_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_fn__1685000370_A struct{ j2g_header uint64 }

var A_arbace_go_check_summarize_fn__1685000370_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_msum__1685000358_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_msum__1685000358_A_fn_class *jrt.Class



type A_arbace_go_check_summarize_sum__1685000356_A struct{ j2g_header uint64; F_rs any }

var A_arbace_go_check_summarize_sum__1685000356_A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_syntactic_deps_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A struct{ j2g_header uint64; F_d, F_pkg_scope any }

var A_arbace_go_check_syntactic_deps_BANG__walk__1685000071_A_fn_class *jrt.Class



type A_arbace_go_check_verify_tags_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_verify_tags_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_A struct{ j2g_header uint64 }

var A_arbace_go_check_write_edn_A_fn_class *jrt.Class



type A_arbace_go_check_write_edn_fn__1685000409_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_x any }

var A_arbace_go_check_write_edn_fn__1685000409_A_fn_class *jrt.Class
