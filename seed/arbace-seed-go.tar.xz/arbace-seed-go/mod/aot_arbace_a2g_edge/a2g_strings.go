//line a2g_strings.ae:1
package aot_arbace_a2g_edge

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_7 *jrt.String = jrt.Intern("io")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_9 *jrt.String = jrt.Intern("t")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_11 *jrt.String = jrt.Intern("env")

var Lit_12 *jrt.String = jrt.Intern("commute")

var Lit_13 *jrt.String = jrt.Intern("deref")

var Lit_14 *jrt.String = jrt.Intern("conj")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.edge")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("a2g's edge (doc/STANDALONE-NOTES.md, S2): what a2g knows of the classes outside the forms\n  (the JDK's classes jrt hand-writes or the world does not hold, the cut classes, Arbace's\n  runtime classes on the JVM), as data instead of the JVM's reflection and ASM. The declaration\n  file (jdk/edge.edn, Clojure-reader data) is written by recording what one a2g run asks the\n  JVM (--record-edge: arbace.classes.env's facets, and a2g's own questions below), and read back\n  by every other run, which then loads no class and reflects on nothing (arbace.classes.env's\n  *declared*). bin/a2g-edge updates and verifies it.\n\n  The file: {:classes {internal-name {:exists true :info class-info facet value ...}}\n  :method-order {internal-name {method-name [[param binary names] ...]}} :cut {internal-name\n  {:methods :fields :ctors}} :exists #{binary-name} :member-types {internal-name\n  [internal-name]} :unexported #{package}}.")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("*edge*")

var Lit_20 *jrt.String = jrt.Intern("get-in")

var Lit_21 *jrt.String = jrt.Intern("*recording*")

var Lit_22 *jrt.String = jrt.Intern("some?")

var Lit_23 *jrt.String = jrt.Intern("swap!")

var Lit_24 *jrt.String = jrt.Intern("assoc-in")

var Lit_25 *jrt.String = jrt.Intern("contains?")

var Lit_26 *jrt.String = jrt.Intern("update")

var Lit_27 *jrt.String = jrt.Intern("fnil")

var Lit_28 *jrt.String = jrt.Intern("<=")

var Lit_29 *jrt.String = jrt.Intern("else")

var Lit_30 *jrt.String = jrt.Intern("format")

var Lit_31 *jrt.String = jrt.Intern("boolean?")

var Lit_32 *jrt.String = jrt.Intern("string?")

var Lit_33 *jrt.String = jrt.Intern("pr-string")

var Lit_34 *jrt.String = jrt.Intern("keyword?")

var Lit_35 *jrt.String = jrt.Intern("symbol?")

var Lit_36 *jrt.String = jrt.Intern("pr-double")

var Lit_37 *jrt.String = jrt.Intern("map?")

var Lit_38 *jrt.String = jrt.Intern("join")

var Lit_39 *jrt.String = jrt.Intern("set?")

var Lit_40 *jrt.String = jrt.Intern("sequential?")

var Lit_41 *jrt.String = jrt.Intern("ex-info")

var Lit_42 *jrt.String = jrt.Intern("seq")

var Lit_43 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_44 *jrt.String = jrt.Intern("chunk-first")

var Lit_45 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_46 *jrt.String = jrt.Intern("chunk-append")

var Lit_47 *jrt.String = jrt.Intern("pr-data")

var Lit_48 *jrt.String = jrt.Intern("chunk-cons")

var Lit_49 *jrt.String = jrt.Intern("first")

var Lit_50 *jrt.String = jrt.Intern("cons")

var Lit_51 *jrt.String = jrt.Intern("chunk")

var Lit_52 *jrt.String = jrt.Intern("chunk-rest")

var Lit_53 *jrt.String = jrt.Intern("rest")

var Lit_54 *jrt.String = jrt.Intern("sort-by")

var Lit_55 *jrt.String = jrt.Intern("comp")

var Lit_56 *jrt.String = jrt.Intern("key")

var Lit_57 *jrt.String = jrt.Intern("sort")

var Lit_58 *jrt.String = jrt.Intern("map")

var Lit_59 *jrt.String = jrt.Intern("pr-str")

var Lit_60 *jrt.String = jrt.Intern("x")

var Lit_61 *jrt.String = jrt.Intern("class")

var Lit_62 *jrt.String = jrt.Intern("update-in")

var Lit_63 *jrt.String = jrt.Intern("into")

var Lit_64 *jrt.String = jrt.Intern("mapv")

var Lit_65 *jrt.String = jrt.Intern("const")

var Lit_66 *jrt.String = jrt.Intern("val")

var Lit_67 *jrt.String = jrt.Intern("const-data")

var Lit_68 *jrt.String = jrt.Intern("ann-data")

var Lit_69 *jrt.String = jrt.Intern("file")

var Lit_70 *jrt.String = jrt.Intern("includes?")

var Lit_71 *jrt.String = jrt.Intern("remove")

var Lit_72 *jrt.String = jrt.Intern("split-lines")

var Lit_73 *jrt.String = jrt.Intern("re-find")

var Lit_74 *jrt.String = jrt.Intern("[\\s@#]")

var Lit_75 *jrt.String = jrt.Intern("slurp")

var Lit_76 *jrt.String = jrt.Intern("println")

var Lit_77 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_78 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_79 *jrt.String = jrt.Intern("hash-map")

var Lit_80 *jrt.String = jrt.Intern("*out*")

var Lit_81 *jrt.String = jrt.Intern("*err*")

var Lit_82 *jrt.String = jrt.Intern("name")

var Lit_83 *jrt.String = jrt.Intern("desc")

var Lit_84 *jrt.String = jrt.Intern("methods")

var Lit_85 *jrt.String = jrt.Intern("dissoc")

var Lit_86 *jrt.String = jrt.Intern("empty?")

var Lit_87 *jrt.String = jrt.Intern("assoc")

var Lit_88 *jrt.String = jrt.Intern("some")

var Lit_89 *jrt.String = jrt.Intern("annotations")

var Lit_90 *jrt.String = jrt.Intern("force")

var Lit_91 *jrt.String = jrt.Intern("param-annotations")

var Lit_92 *jrt.String = jrt.Intern("owner")

var Lit_93 *jrt.String = jrt.Intern("throws")

var Lit_94 *jrt.String = jrt.Intern("fields")

var Lit_95 *jrt.String = jrt.Intern("info")

var Lit_96 *jrt.String = jrt.Intern("subs")

var Lit_97 *jrt.String = jrt.Intern("next")

var Lit_98 *jrt.String = jrt.Intern("to-array")

var Lit_99 *jrt.String = jrt.Intern("classes")

var Lit_100 *jrt.String = jrt.Intern("class-entry-text")

var Lit_101 *jrt.String = jrt.Intern("starts-with?")

var Lit_102 *jrt.String = jrt.Intern("load-class")

var Lit_103 *jrt.String = jrt.Intern("canonical")

var Lit_104 *jrt.String = jrt.Intern("info-data")

var Lit_105 *jrt.String = jrt.Intern("reflect-info")

var Lit_106 *jrt.String = jrt.Intern("merge")

var Lit_107 *jrt.String = jrt.Intern("*recorded*")

var Lit_108 *jrt.String = jrt.Intern("apply")

var Lit_109 *jrt.String = jrt.Intern("merge-with")

var Lit_110 *jrt.String = jrt.Intern("vector?")

var Lit_111 *jrt.String = jrt.Intern("coerce-const")

var Lit_112 *jrt.String = jrt.Intern("type")

var Lit_113 *jrt.String = jrt.Intern("ann-value")

var Lit_114 *jrt.String = jrt.Intern("vec")

var Lit_115 *jrt.String = jrt.Intern("flags")

var Lit_116 *jrt.String = jrt.Intern("int")

var Lit_117 *jrt.String = jrt.Intern("repeat")

var Lit_118 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_119 *jrt.String = jrt.Intern("generics")

var Lit_120 *jrt.String = jrt.Intern("archived-classes")

var Lit_121 *jrt.String = jrt.Intern("method-key")

var Lit_122 *jrt.String = jrt.Intern("read-string")

var Lit_123 *jrt.String = jrt.Intern("*read-eval*")

var Lit_124 *jrt.String = jrt.Intern("info-value")

var Lit_125 *jrt.String = jrt.Intern("generics-value")

var Lit_126 *jrt.String = jrt.Intern("spit")

var Lit_127 *jrt.String = jrt.Intern("make-parents")

var Lit_128 *jrt.String = jrt.Intern("edge-text")

var Lit_129 *jrt.String = jrt.Intern("write-edge!")

var Lit_130 *jrt.String = jrt.Intern("merge-edges")

var Lit_131 *jrt.String = jrt.Intern("read-edge-data")

var Lit_132 *jrt.String = jrt.Intern("arbace.a2g.edge$_main")

var Lit_133 *jrt.String = jrt.Intern("a2g edge: unknown command ")

var Lit_134 *jrt.String = jrt.Intern("arbace.a2g.edge$ann_data")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.edge$ann_data$fn__1280000035")

var Lit_136 *jrt.String = jrt.Intern("arbace.a2g.edge$ann_value")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.edge$ann_value$fn__1280000177")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.edge$ann_value$fn__1280000180")

var Lit_139 *jrt.String = jrt.Intern("arbace.a2g.edge$canonical")

var Lit_140 *jrt.String = jrt.Intern("arbace.a2g.edge$canonical$fn__1280000215")

var Lit_141 *jrt.String = jrt.Intern("arbace.a2g.edge$canonical$fn__1280000217")

var Lit_142 *jrt.String = jrt.Intern("arbace.a2g.edge$class_entry_text")

var Lit_143 *jrt.String = jrt.Intern("\n  ")

var Lit_144 *jrt.String = jrt.Intern("{:info {")

var Lit_145 *jrt.String = jrt.Intern("}")

var Lit_146 *jrt.String = jrt.Intern("\n          ")

var Lit_147 *jrt.String = jrt.Intern("\n   ")

var Lit_148 *jrt.String = jrt.Intern("arbace.a2g.edge$class_entry_text$iter__1280000061__1280000065")

var Lit_149 *jrt.String = jrt.Intern("arbace.a2g.edge$class_entry_text$iter__1280000061__1280000065$fn__1280000066")

var Lit_150 *jrt.String = jrt.Intern(" [")

var Lit_151 *jrt.String = jrt.Intern("]")

var Lit_152 *jrt.String = jrt.Intern("\n            ")

var Lit_153 *jrt.String = jrt.Intern(" ")

var Lit_154 *jrt.String = jrt.Intern("arbace.a2g.edge$class_entry_text$iter__1280000061__1280000065$fn__1280000066$fn__1280000067")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.edge$coerce_const")

var Lit_156 *jrt.String = jrt.Intern("B")

var Lit_157 *jrt.String = jrt.Intern("C")

var Lit_158 *jrt.String = jrt.Intern("D")

var Lit_159 *jrt.String = jrt.Intern("F")

var Lit_160 *jrt.String = jrt.Intern("I")

var Lit_161 *jrt.String = jrt.Intern("J")

var Lit_162 *jrt.String = jrt.Intern("S")

var Lit_163 *jrt.String = jrt.Intern("Z")

var Lit_164 *jrt.String = jrt.Intern("arbace.a2g.edge$const_data")

var Lit_165 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text")

var Lit_166 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000083__1280000087")

var Lit_167 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000083__1280000087$fn__1280000088")

var Lit_168 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000083__1280000087$fn__1280000088$fn__1280000089")

var Lit_169 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103")

var Lit_170 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104")

var Lit_171 *jrt.String = jrt.Intern("\n ")

var Lit_172 *jrt.String = jrt.Intern("\n")

var Lit_173 *jrt.String = jrt.Intern("{")

var Lit_174 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105")

var Lit_175 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105$iter__1280000109__1280000113")

var Lit_176 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105$iter__1280000109__1280000113$fn__1280000114")

var Lit_177 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105$iter__1280000109__1280000113$fn__1280000114$fn__1280000115")

var Lit_178 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$iter__1280000129__1280000133")

var Lit_179 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$iter__1280000129__1280000133$fn__1280000134")

var Lit_180 *jrt.String = jrt.Intern("arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$iter__1280000129__1280000133$fn__1280000134$fn__1280000135")

var Lit_181 *jrt.String = jrt.Intern("arbace.a2g.edge$eval1280000004$loading__1927001464__auto____1280000005")

var Lit_182 *jrt.String = jrt.Intern("arbace.a2g.edge$eval1280000008$fn__1280000009")

var Lit_183 *jrt.String = jrt.Intern("arbace.a2g.edge$fn__1280000042")

var Lit_184 *jrt.String = jrt.Intern("java.home")

var Lit_185 *jrt.String = jrt.Intern("lib")

var Lit_186 *jrt.String = jrt.Intern("classlist")

var Lit_187 *jrt.String = jrt.Intern("java.vm.info")

var Lit_188 *jrt.String = jrt.Intern("sharing")

var Lit_189 *jrt.String = jrt.Intern("arbace.a2g.edge$fn__1280000042$fn__1280000043")

var Lit_190 *jrt.String = jrt.Intern("arbace.a2g.edge$fn__1280000042$fn__1280000045")

var Lit_191 *jrt.String = jrt.Intern("a2g: warning: the JVM does not use the JDK's CDS archive: member tables order")

var Lit_192 *jrt.String = jrt.Intern("every class's overloads by descriptor")

var Lit_193 *jrt.String = jrt.Intern("arbace.a2g.edge$generics_value")

var Lit_194 *jrt.String = jrt.Intern("arbace.a2g.edge$generics_value$fn__1280000207")

var Lit_195 *jrt.String = jrt.Intern("arbace.a2g.edge$generics_value$fn__1280000207$fn__1280000208")

var Lit_196 *jrt.String = jrt.Intern("arbace.a2g.edge$info_data")

var Lit_197 *jrt.String = jrt.Intern("arbace.a2g.edge$info_data$fn__1280000050")

var Lit_198 *jrt.String = jrt.Intern("arbace.a2g.edge$info_data$fn__1280000050$fn__1280000051")

var Lit_199 *jrt.String = jrt.Intern("arbace.a2g.edge$info_data$fn__1280000055")

var Lit_200 *jrt.String = jrt.Intern("arbace.a2g.edge$info_data$fn__1280000055$fn__1280000056")

var Lit_201 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value")

var Lit_202 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000188")

var Lit_203 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000188$fn__1280000189")

var Lit_204 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000192")

var Lit_205 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193")

var Lit_206 *jrt.String = jrt.Intern("<init>")

var Lit_207 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000194")

var Lit_208 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000197")

var Lit_209 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000199")

var Lit_210 *jrt.String = jrt.Intern("arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000199$fn__1280000200")

var Lit_211 *jrt.String = jrt.Intern("arbace.a2g.edge$jvm")

var Lit_212 *jrt.String = jrt.Intern("arbace.a2g.edge$jvm_QMARK_")

var Lit_213 *jrt.String = jrt.Intern("arbace.a2g.edge$merge_edges")

var Lit_214 *jrt.String = jrt.Intern("arbace.a2g.edge$merge_edges$fn__1280000169")

var Lit_215 *jrt.String = jrt.Intern("arbace.a2g.edge$merge_edges$fn__1280000169$fn__1280000170")

var Lit_216 *jrt.String = jrt.Intern("arbace.a2g.edge$method_key")

var Lit_217 *jrt.String = jrt.Intern("arbace.a2g.edge$pr_data")

var Lit_218 *jrt.String = jrt.Intern("nil")

var Lit_219 *jrt.String = jrt.Intern("#{")

var Lit_220 *jrt.String = jrt.Intern("[")

var Lit_221 *jrt.String = jrt.Intern("a2g edge: cannot write ")

var Lit_222 *jrt.String = jrt.Intern("arbace.a2g.edge$pr_data$iter__1280000016__1280000020")

var Lit_223 *jrt.String = jrt.Intern("arbace.a2g.edge$pr_data$iter__1280000016__1280000020$fn__1280000021")

var Lit_224 *jrt.String = jrt.Intern("arbace.a2g.edge$pr_data$iter__1280000016__1280000020$fn__1280000021$fn__1280000022")

var Lit_225 *jrt.String = jrt.Intern("arbace.a2g.edge$pr_double")

var Lit_226 *jrt.String = jrt.Intern("##NaN")

var Lit_227 *jrt.String = jrt.Intern("##Inf")

var Lit_228 *jrt.String = jrt.Intern("##-Inf")

var Lit_229 *jrt.String = jrt.Intern("arbace.a2g.edge$pr_string")

var Lit_230 *jrt.String = jrt.Intern("\"")

var Lit_231 *jrt.String = jrt.Intern("\\\"")

var Lit_232 *jrt.String = jrt.Intern("\\\\")

var Lit_233 *jrt.String = jrt.Intern("\\u%04x")

var Lit_234 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge")

var Lit_235 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge$fn__1280000220")

var Lit_236 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge$fn__1280000222")

var Lit_237 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge$fn__1280000222$iter__1280000223__1280000227")

var Lit_238 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge$fn__1280000222$iter__1280000223__1280000227$fn__1280000228")

var Lit_239 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge$fn__1280000222$iter__1280000223__1280000227$fn__1280000228$fn__1280000229")

var Lit_240 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge_data")

var Lit_241 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge_data$fn__1280000243")

var Lit_242 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge_data$fn__1280000245")

var Lit_243 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge_data$fn__1280000245$iter__1280000246__1280000250")

var Lit_244 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge_data$fn__1280000245$iter__1280000246__1280000250$fn__1280000251")

var Lit_245 *jrt.String = jrt.Intern("arbace.a2g.edge$read_edge_data$fn__1280000245$iter__1280000246__1280000250$fn__1280000251$fn__1280000252")

var Lit_246 *jrt.String = jrt.Intern("arbace.a2g.edge$recorded_edge")

var Lit_247 *jrt.String = jrt.Intern("arbace.a2g.edge$recorded_edge$fn__1280000148")

var Lit_248 *jrt.String = jrt.Intern("arbace.a2g.edge$recorded_edge$fn__1280000148$iter__1280000149__1280000153")

var Lit_249 *jrt.String = jrt.Intern("arbace.a2g.edge$recorded_edge$fn__1280000148$iter__1280000149__1280000153$fn__1280000154")

var Lit_250 *jrt.String = jrt.Intern("arbace.a2g.edge$recorded_edge$fn__1280000148$iter__1280000149__1280000153$fn__1280000154$fn__1280000155")

var Lit_251 *jrt.String = jrt.Intern("arbace.a2g.edge$write_edge_BANG_")

var Lit_252 *jrt.String = jrt.Intern("in-ns")

var Lit_253 *jrt.String = jrt.Intern("declared")

var Lit_254 *jrt.String = jrt.Intern("line")

var Lit_255 *jrt.String = jrt.Intern("column")

var Lit_256 *jrt.String = jrt.Intern("arbace/a2g/edge.ae")

var Lit_257 *jrt.String = jrt.Intern("dynamic")

var Lit_258 *jrt.String = jrt.Intern("The declared edge being used (sealed: no reflection), or nil.")

var Lit_259 *jrt.String = jrt.Intern("nil, or an atom of a2g's own sections being recorded: {section {key value}}.")

var Lit_260 *jrt.String = jrt.Intern("jvm")

var Lit_261 *jrt.String = jrt.Intern("arglists")

var Lit_262 *jrt.String = jrt.Intern("section")

var Lit_263 *jrt.String = jrt.Intern("k")

var Lit_264 *jrt.String = jrt.Intern("f")

var Lit_265 *jrt.String = jrt.Intern("a2g's question k of section about the JVM: with an edge, its declared answer (nil when it has\n  none); else (f) on this JVM, recorded when not nil.")

var Lit_266 *jrt.String = jrt.Intern("jvm?")

var Lit_267 *jrt.String = jrt.Intern("A yes-or-no question k of section (a set in the edge: the keys answered yes).")

var Lit_268 *jrt.String = jrt.Intern("private")

var Lit_269 *jrt.String = jrt.Intern("s")

var Lit_270 *jrt.String = jrt.Intern("tag")

var Lit_271 *jrt.String = jrt.Intern("String")

var Lit_272 *jrt.String = jrt.Intern("d")

var Lit_273 *jrt.String = jrt.Intern("double")

var Lit_274 *jrt.String = jrt.Intern("x as Clojure-reader text: maps with their keys sorted, sets sorted, every sequence a vector.")

var Lit_275 *jrt.String = jrt.Intern("v")

var Lit_276 *jrt.String = jrt.Intern("A constant value as data: a char as its code (read back by its descriptor).")

var Lit_277 *jrt.String = jrt.Intern("Annotation values ({:const {:val v :type d}} ...) with chars as codes.")

var Lit_278 *jrt.String = jrt.Intern("The classes of the running JDK's default CDS archive (its lib/classlist, the archive's\n  input; internal names), when the JVM maps the archive (java.vm.info says sharing), else\n  #{}. HotSpot sorts a class's methods by the address of their name's Symbol, so the order of\n  getDeclaredMethods, a name's overloads included, varies from one JVM process to the next\n  for a class it loads and parses (Arbace's own, the JDK's outside the archive); an archived\n  class keeps the order of the archive, fixed for the JDK build.")

var Lit_279 *jrt.String = jrt.Intern("m")

var Lit_280 *jrt.String = jrt.Intern("The order of the methods of a class outside the JDK's CDS archive in the edge: by name, then\n  descriptor (getDeclaredMethods's order varies from one process to the next for them; an\n  archived class's methods keep the JVM's order, on which a2g's output depends).")

var Lit_281 *jrt.String = jrt.Intern("A class info of reflection (env/reflect-info) as data: no Class, no :owner (the class's\n  name), the delayed annotations forced, the methods in method-key's order; what reflect-info\n  always has left out: a field's nil :const, a method's empty :throws, :annotations and\n  :param-annotations (a constructor has neither).")

var Lit_282 *jrt.String = jrt.Intern("n")

var Lit_283 *jrt.String = jrt.Intern("facets")

var Lit_284 *jrt.String = jrt.Intern("keys")

var Lit_285 *jrt.String = jrt.Intern("edge")

var Lit_286 *jrt.String = jrt.Intern("The edge's file text.")

var Lit_287 *jrt.String = jrt.Intern("recorded-edge")

var Lit_288 *jrt.String = jrt.Intern("env-rec")

var Lit_289 *jrt.String = jrt.Intern("a2g-rec")

var Lit_290 *jrt.String = jrt.Intern("The edge of what this run recorded: env's facets with each class's info (by reflection,\n  now), and a2g's sections.")

var Lit_291 *jrt.String = jrt.Intern("edges")

var Lit_292 *jrt.String = jrt.Intern("The union of edges (the same JVM answers: their entries agree).")

var Lit_293 *jrt.String = jrt.Intern("A declared class info in env's own shape (reflect-info's): owners, int flags, constants of\n  their field's type, annotations delayed, what info-data leaves out restored.")

var Lit_294 *jrt.String = jrt.Intern("g")

var Lit_295 *jrt.String = jrt.Intern("A class's facets with the methods of its info and generics in method-key's order when the\n  class is outside the JDK's CDS archive.")

var Lit_296 *jrt.String = jrt.Intern("read-edge")

var Lit_297 *jrt.String = jrt.Intern("The edge of file f, ready for binding: :classes in env's shape (env/*declared*).")

var Lit_298 *jrt.String = jrt.Intern("The edge of file f as data, as edge-text writes it (its infos in info-data's form).")

var Lit_299 *jrt.String = jrt.Intern("-main")

var Lit_300 *jrt.String = jrt.Intern("cmd")

var Lit_301 *jrt.String = jrt.Intern("&")

var Lit_302 *jrt.String = jrt.Intern("args")

var Lit_303 *jrt.String = jrt.Intern("merge OUT IN...: writes the union of the edges IN to OUT.")
