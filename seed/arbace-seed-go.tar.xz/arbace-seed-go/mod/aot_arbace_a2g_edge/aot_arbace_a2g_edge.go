//line aot_arbace_a2g_edge.ae:1
package aot_arbace_a2g_edge

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_New() *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A { A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_Init(); t := &A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_6; tmp3 = tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, tmp14, tmp15) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :1:1
func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_New() *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A { A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_Init(); t := &A_arbace_a2g_edge_eval1280000008_fn__1280000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }



























func A_arbace_a2g_edge_jvm_A_New() *A_arbace_a2g_edge_jvm_A { A_arbace_a2g_edge_jvm_A_Init(); t := &A_arbace_a2g_edge_jvm_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_a2g_edge_jvm_A) Ctor() {}
//line :29:1
func (t *A_arbace_a2g_edge_jvm_A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {



	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_12; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) {
		var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_13; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_12; return tmp3.Invoke_O_O__O(jrt.NN(tmp4).Get__O(), lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1)) } else {
//line :33:1
			var v__4 any = lang.IFn_Cast(f__2).Invoke__O(); var tmp5 any; var and__1927000168__auto____5 any; var tmp6 *lang.Var


			A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_14; and__1927000168__auto____5 = jrt.NN(tmp6).Get__O(); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_15; tmp5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(v__4) } else { tmp5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp5) { var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_16; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_14; var tmp11 any = jrt.NN(tmp10).Get__O(); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_17; tmp9.Invoke_O_O_O_O__O(tmp11, jrt.NN(tmp12).GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(section__0, k__1), v__4) }
//line :33:1
			return v__4
		}
}



func A_arbace_a2g_edge_jvm_QMARK__A_New() *A_arbace_a2g_edge_jvm_QMARK__A { A_arbace_a2g_edge_jvm_QMARK__A_Init(); t := &A_arbace_a2g_edge_jvm_QMARK__A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_a2g_edge_jvm_QMARK__A) Ctor() {}
//line :39:1
func (t *A_arbace_a2g_edge_jvm_QMARK__A) Invoke_O_O_O_O__O(self, section__0, k__1, f__2 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_12; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) {
		var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_18; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_12; return tmp3.Invoke_O_O__O(lang.RT_Get_O_O__O(jrt.NN(tmp4).Get__O(), section__0), k__1) } else {
//line :42:1
			var v__4 bool = lang.RT_BooleanCast_O__Z(lang.IFn_Cast(f__2).Invoke__O()); var tmp5 any; var and__1927000168__auto____5 any; var tmp6 *lang.Var


			A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_14; and__1927000168__auto____5 = jrt.NN(tmp6).Get__O(); if jrt.A2g_Truth(and__1927000168__auto____5) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(v__4).Ref() } else { tmp5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp5) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_16; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_14; var tmp10 any = jrt.NN(tmp9).Get__O(); var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_19; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_20; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_9; var tmp16 any = jrt.NN(tmp15).GetRawRoot__O(); var tmp17 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp17 = lang.PersistentHashSet_EMPTY; tmp8.Invoke_O_O_O_O_O__O(tmp10, tmp12, section__0, tmp14.Invoke_O_O__O(tmp16, tmp17.Ref()), k__1) }
//line :42:1
			return jrt.Boolean_ValueOf_Z__Boolean(v__4).Ref()
		}
}







func A_arbace_a2g_edge_pr_string_A_New() *A_arbace_a2g_edge_pr_string_A { A_arbace_a2g_edge_pr_string_A_Init(); t := &A_arbace_a2g_edge_pr_string_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_a2g_edge_pr_string_A) Ctor() {}
//line :52:1
func (t *A_arbace_a2g_edge_pr_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_230); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(s__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(i__4, n__1927000701__auto____3) { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(i__4)); var tmp1 any

		A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_22; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp1)).CharValue__C()) { jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_231) } else { var tmp2 any; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_23; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C()) {
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_232) } else {
//line :56:1
				var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_24; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_27; var tmp6 any = tmp5; var tmp7 any = jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(c__5)).Ref(); var tmp8 any; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_28; if jrt.A2g_Truth(tmp4.Invoke_O_O_O__O(tmp6, tmp7, tmp8)) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_C__StringBuilder(c__5) } else {
//line :56:1
						var tmp9 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_25; if tmp9 != nil {


							var tmp10 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_26; jrt.NN(tmp10).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(Lit_233, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(c__5)).Ref()))) } } } }
//line :54:1
		i__4 = lang.Numbers_Unchecked_inc_J__J(i__4); continue L1 }
//line :52:1
	break L1 }; var tmp12 /*line :60:1*/*lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_21; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_230).Ref()) }

func A_arbace_a2g_edge_pr_double_A_New() *A_arbace_a2g_edge_pr_double_A { A_arbace_a2g_edge_pr_double_A_Init(); t := &A_arbace_a2g_edge_pr_double_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_a2g_edge_pr_double_A) Ctor() {}
//line :62:1
func (t *A_arbace_a2g_edge_pr_double_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); if
										jrt.Double_IsNaN_D__Z(d__0) { return Lit_226 } else { if lang.Util_Equiv_D_D__Z(d__0, jrt.PosInf64) { return Lit_227 } else { if lang.Util_Equiv_D_D__Z(d__0, jrt.NegInf64) { return Lit_228 } else { var tmp1 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_25; if tmp1 != nil {


		return jrt.Double_ToString_D__String(d__0).Ref() } else {
//line :63:1
			return nil } } } } }




func A_arbace_a2g_edge_pr_data_A_New() *A_arbace_a2g_edge_pr_data_A { A_arbace_a2g_edge_pr_data_A_Init(); t := &A_arbace_a2g_edge_pr_data_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_a2g_edge_pr_data_A) Ctor() {}
//line :68:1
func (t *A_arbace_a2g_edge_pr_data_A) Invoke_O_O__O(self, x__0 any) any {


	if lang.Util_Identical_O_O__Z(x__0, nil) { return Lit_218 } else { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) {

		var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_21; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
			var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0)) {


				var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_31; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
					var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__0)) {



						var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_21; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
							var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(x__0)) {




								var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_21; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
									var tmp9 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)





									if or__1927000174__auto____2 { tmp9 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp9 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp9 = or__1927000174__auto____4 } else { tmp9 = jrt.Byte_InstanceOf(x__0) } } }
//line :71:1
									if tmp9 {





										var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_21; return lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :71:1
											var tmp11 bool; var or__1927000174__auto____2_2 bool = jrt.Double_InstanceOf(x__0)






											if or__1927000174__auto____2_2 { tmp11 = or__1927000174__auto____2_2 } else { tmp11 = jrt.Float_InstanceOf(x__0) }
//line :71:1
											if tmp11 {






												var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_34; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(jrt.Double_ValueOf_D__Double(lang.RT_DoubleCast_O__D(x__0)).Ref()) } else {
//line :71:1
													if jrt.Character_InstanceOf(x__0) {







														var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_21; return lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_C__I(lang.RT_CharCast_O__C(x__0))).Ref()) } else {
//line :71:1
															var tmp14 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__0)) {








																var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_145); var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_36; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; var iter__1927001039__auto____5 any; var tmp19 any = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_New(); var tmp20 *jrt.Class; A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_Init(); tmp20 = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_fn_class; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var tmp21 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_52; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_53; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_45; var tmp27 any = jrt.NN(tmp26).GetRawRoot__O(); var tmp28 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp28 = A_arbace_a2g_edge_A_const_54; tmp18 = tmp21.Invoke_O__O(tmp23.Invoke_O_O__O(tmp25.Invoke_O_O__O(tmp27, jrt.NN(tmp28).GetRawRoot__O()), x__0)); return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp17.Invoke_O_O__O(Lit_153, tmp18), nil)).Ref() } else {
//line :71:1
																	var tmp29 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(x__0)) {









																		var tmp30 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_219, nil, Lit_145); var tmp31 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp31 = A_arbace_a2g_edge_A_const_36; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp33 = A_arbace_a2g_edge_A_const_55; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp35 = A_arbace_a2g_edge_A_const_56; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp37 = A_arbace_a2g_edge_A_const_45; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp30, jrt.RefArrayOf(jrt.Object_class, nil, tmp32.Invoke_O_O__O(Lit_153, tmp34.Invoke_O__O(tmp36.Invoke_O_O__O(jrt.NN(tmp37).GetRawRoot__O(), x__0))), nil)).Ref() } else {
//line :71:1
																			var tmp38 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp38 = A_arbace_a2g_edge_A_const_38; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(x__0)) {










																				var tmp39 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_220, nil, Lit_151); var tmp40 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp40 = A_arbace_a2g_edge_A_const_36; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp42 = A_arbace_a2g_edge_A_const_56; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp44 = A_arbace_a2g_edge_A_const_45; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp39, jrt.RefArrayOf(jrt.Object_class, nil, tmp41.Invoke_O_O__O(Lit_153, tmp43.Invoke_O_O__O(jrt.NN(tmp44).GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :71:1
																					var tmp45 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp45 = A_arbace_a2g_edge_A_const_25; if tmp45 != nil { var tmp46 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp46 = A_arbace_a2g_edge_A_const_39; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_221, nil); var tmp49 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp49 = A_arbace_a2g_edge_A_const_57; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp51 = A_arbace_a2g_edge_A_const_59; var tmp52 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp48, jrt.RefArrayOf(jrt.Object_class, nil, tmp50.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(x__0)))).Ref(); var tmp53 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp53 = A_arbace_a2g_edge_A_const_58; panic(jrt.Thrown(jrt.Throwable_Cast(tmp47.Invoke_O_O__O(tmp52, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp53.Ref(), x__0)))))) } else { return nil
																					}
																				}
																		}
																}
														}
												}
										}
								} } } } } }
func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_New() *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_Init(); t := &A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) Ctor() {}
//line :80:1
func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) Invoke_O_O__O(self, s__1280000017__1 any) any { var tmp1 any = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_New_O_O(s__1280000017__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_Init(); tmp2 = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :80:1
func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_Init(); t := &A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) Ctor_O_O(c__s__1280000017, c__iter__1280000016 any) { t.F_s__1280000017 = c__s__1280000017; t.F_iter__1280000016 = c__iter__1280000016 }
//line :80:1
func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) Invoke_O__O(self any) any { { var s__1280000017__1 any; var t_ any = t.F_s__1280000017; t.F_s__1280000017 = nil; s__1280000017__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000017__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000017__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000017__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000017__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000019__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000019__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_New_I_O_O(size__1927001038__auto____5, b__1280000019__6, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_Init(); tmp6 = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000019__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000016); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000017__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000019__6), nil) } } else { var vec__1280000027__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000027__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000017__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1280000027__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1280000027__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp20 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_45; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(k__5); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_45; var tmp23 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(v__6))).Ref(); var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__1280000016); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__1280000017__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :80:1
func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_Init(); t := &A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :80:1
func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1280000019, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1280000019 = c__b__1280000019; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :80:1
func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) Invoke_O__O(self any) any { { var i__1280000018__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000018__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000023__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000018__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1280000023__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1280000023__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000019; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_45; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(k__3); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_45; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1280000018__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000018__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_edge_const_data_A_New() *A_arbace_a2g_edge_const_data_A { A_arbace_a2g_edge_const_data_A_Init(); t := &A_arbace_a2g_edge_const_data_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_a2g_edge_const_data_A) Ctor() {}
//line :85:1
func (t *A_arbace_a2g_edge_const_data_A) Invoke_O_O__O(self, v__0 any) any {


	if jrt.Character_InstanceOf(v__0) { return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(lang.RT_IntCast_C__I(lang.RT_CharCast_O__C(v__0)))).Ref() } else { return v__0
	} }
func A_arbace_a2g_edge_ann_data_A_New() *A_arbace_a2g_edge_ann_data_A { A_arbace_a2g_edge_ann_data_A_Init(); t := &A_arbace_a2g_edge_ann_data_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_a2g_edge_ann_data_A) Ctor() {}
//line :90:1
func (t *A_arbace_a2g_edge_ann_data_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_35; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_18; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_63; and__1927000168__auto____3 = tmp4.Invoke_O_O__O(x__0, tmp5.Ref()); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_35; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_63; tmp1 = tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(x__0)) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_60; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_64; var tmp12 any = tmp11; var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_65; return tmp10.Invoke_O_O_O__O(x__0, tmp12, jrt.NN(tmp13).GetRawRoot__O()) } else {
//line :93:1
			var tmp14 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_61; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp17 = lang.PersistentArrayMap_EMPTY; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_56; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = A_arbace_a2g_edge_ann_data_fn__1280000035_A_New(); var tmp22 *jrt.Class; A_arbace_a2g_edge_ann_data_fn__1280000035_A_Init(); tmp22 = A_arbace_a2g_edge_ann_data_fn__1280000035_A_fn_class; return tmp16.Invoke_O_O__O(tmp18, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), x__0)) } else {
//line :93:1
					var tmp23 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_38; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(x__0)) {


						var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_62; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_66; return tmp25.Invoke_O_O__O(jrt.NN(tmp26).GetRawRoot__O(), x__0) } else {
//line :93:1
							var tmp27 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_25; if tmp27 != nil { return x__0 } else { return nil
							} } } } }
func A_arbace_a2g_edge_ann_data_fn__1280000035_A_New() *A_arbace_a2g_edge_ann_data_fn__1280000035_A { A_arbace_a2g_edge_ann_data_fn__1280000035_A_Init(); t := &A_arbace_a2g_edge_ann_data_fn__1280000035_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) Ctor() {}
//line :95:1
func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) Invoke_O_O__O(self, p__1280000034__1 any) any { var vec__1280000036__2 any = p__1280000034__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1280000036__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1280000036__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_66; return lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__4)) }










func A_arbace_a2g_edge_fn__1280000042_A_New() *A_arbace_a2g_edge_fn__1280000042_A { A_arbace_a2g_edge_fn__1280000042_A_Init(); t := &A_arbace_a2g_edge_fn__1280000042_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_a2g_edge_fn__1280000042_A) Ctor() {}
//line :106:1
func (t *A_arbace_a2g_edge_fn__1280000042_A) Invoke_O__O(self any) any { var f__1 any; var tmp1 *lang.Var;
									A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_67; f__1 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.System_GetProperty_String__String(Lit_184).Ref(), Lit_185, Lit_186); var tmp2 any; var and__1927000168__auto____2 bool =
									jrt.NN(jrt.File_Cast(f__1)).IsFile__Z(); if and__1927000168__auto____2 { var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_68; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_21; tmp2 = tmp4.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.System_GetProperty_String__String(Lit_187).Ref()), Lit_188) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.A2g_Truth(tmp2) {
										var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_61; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp8 = lang.PersistentHashSet_EMPTY; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_69; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_New(); var tmp13 *jrt.Class; A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_Init(); tmp13 = A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_fn_class; var tmp14 any = tmp11.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_70; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_73; return tmp7.Invoke_O_O_O__O(tmp9, tmp14, tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(f__1))) } else {
											var tmp18 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp18 = A_arbace_a2g_edge_A_const_76; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_77; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_78; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_79; tmp19.Invoke_O__O(tmp21.Invoke_O_O__O(tmp23, jrt.NN(tmp24).Get__O())); var tmp25 any = A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_New(); var tmp26 *jrt.Class; A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_Init(); tmp26 = A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O()
//line :108:1
			lang.PersistentHashSet_Init(); return lang.PersistentHashSet_EMPTY.Ref() } }
func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_New() *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A { A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_Init(); t := &A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) Ctor() {}
//line :109:1
func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) Invoke_O_O__O(self, p1__1280000041_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_71; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_72; return tmp2.Invoke_O_O__O(tmp3, p1__1280000041_SHARP___1) }
func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_New() *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A { A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_Init(); t := &A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) Ctor() {}
//line :110:1
func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_74; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(Lit_191, Lit_192) }
//line :110:1
	return nil }(); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_75; lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke__O(); if tmp3 != nil { panic(tmp3) }; return tmp1 }




func A_arbace_a2g_edge_method_key_A_New() *A_arbace_a2g_edge_method_key_A { A_arbace_a2g_edge_method_key_A_Init(); t := &A_arbace_a2g_edge_method_key_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_a2g_edge_method_key_A) Ctor() {}
//line :115:1
func (t *A_arbace_a2g_edge_method_key_A) Invoke_O_O__O(self, m__0 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_80; var tmp2 any = jrt.NN(tmp1).Invoke_O__O(m__0); var tmp3 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_81; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, jrt.NN(tmp3).Invoke_O__O(m__0)) }






func A_arbace_a2g_edge_info_data_A_New() *A_arbace_a2g_edge_info_data_A { A_arbace_a2g_edge_info_data_A_Init(); t := &A_arbace_a2g_edge_info_data_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_a2g_edge_info_data_A) Ctor() {}
//line :122:1
func (t *A_arbace_a2g_edge_info_data_A) Invoke_O_O__O(self, info__0 any) any {









	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_83; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_93; var tmp8 any = tmp6.Invoke_O_O__O(info__0, tmp7.Ref()); var tmp9 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_92; var tmp10 any = tmp9.Ref(); var tmp11 any = A_arbace_a2g_edge_info_data_fn__1280000050_A_New(); var tmp12 *jrt.Class; A_arbace_a2g_edge_info_data_fn__1280000050_A_Init(); tmp12 = A_arbace_a2g_edge_info_data_fn__1280000050_A_fn_class; var tmp13 any = tmp4.Invoke_O_O_O__O(tmp8, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)); var tmp14 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_82; var tmp15 any = tmp14.Ref(); var tmp16 any = A_arbace_a2g_edge_info_data_fn__1280000055_A_New(); var tmp17 *jrt.Class; A_arbace_a2g_edge_info_data_fn__1280000055_A_Init(); tmp17 = A_arbace_a2g_edge_info_data_fn__1280000055_A_fn_class; return tmp2.Invoke_O_O_O__O(tmp13, tmp15, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil)) }
//line :129:1
func A_arbace_a2g_edge_info_data_fn__1280000050_A_New() *A_arbace_a2g_edge_info_data_fn__1280000050_A { A_arbace_a2g_edge_info_data_fn__1280000050_A_Init(); t := &A_arbace_a2g_edge_info_data_fn__1280000050_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) Ctor() {}
//line :129:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_Init(); tmp4 = A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), fs__1) }
//line :129:1
func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_New() *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A { A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_Init(); t := &A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) Ctor() {}
//line :129:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) Invoke_O_O__O(self, p1__1280000049_SHARP___1 any) any { var G__1280000052__2_ any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_83; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_90; var tmp6 any = tmp4.Invoke_O_O__O(p1__1280000049_SHARP___1, tmp5.Ref()); var tmp7 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_63; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_65; G__1280000052__2_ = tmp2.Invoke_O_O_O__O(tmp6, tmp8, jrt.NN(tmp9).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_63; if lang.Util_Identical_O_O__Z(jrt.NN(tmp10).Invoke_O__O(p1__1280000049_SHARP___1), nil) {
																var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_83; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_63; return tmp12.Invoke_O_O__O(G__1280000052__2_, tmp13.Ref()) } else {
//line :129:1
		return G__1280000052__2_ } }


func A_arbace_a2g_edge_info_data_fn__1280000055_A_New() *A_arbace_a2g_edge_info_data_fn__1280000055_A { A_arbace_a2g_edge_info_data_fn__1280000055_A_Init(); t := &A_arbace_a2g_edge_info_data_fn__1280000055_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) Ctor() {}
//line :132:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) Invoke_O_O__O(self, ms__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_Init(); tmp4 = A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ms__1) }
//line :133:1
func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_New() *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A { A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_Init(); t := &A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) Ctor() {}
//line :133:1
func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) Invoke_O_O__O(self, m__1 any) any { var a__2 any; var tmp1 *lang.Var;
													A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_87; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(m__1, tmp3.Ref())) { var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_66; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_88; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_87; a__2 = tmp5.Invoke_O__O(tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(m__1))) } else { a__2 = nil }; var pa__3 any; var tmp9 /*line :133:1*/*lang.Var;

	A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_18; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_89; if jrt.A2g_Truth(tmp10.Invoke_O_O__O(m__1, tmp11.Ref())) {
		var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_62; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_53; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_66; var tmp17 any = jrt.NN(tmp16).GetRawRoot__O(); var tmp18 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp18 = A_arbace_a2g_edge_A_const_88; var tmp19 any = tmp15.Invoke_O_O__O(tmp17, jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_89; pa__3 = tmp13.Invoke_O_O__O(tmp19, jrt.NN(tmp20).Invoke_O__O(m__1)) } else {
//line :135:1
			pa__3 = nil }; var G__1280000057__4_ any; var tmp21 /*line :133:1*/*lang.Var;



	A_arbace_a2g_edge_A_Init(); tmp21 = A_arbace_a2g_edge_A_const_83; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_90; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_87; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_89; G__1280000057__4_ = tmp22.Invoke_O_O_O_O__O(m__1, tmp24, tmp26, tmp27.Ref()); var G__1280000057__5_ any; var tmp28 /*line :133:1*/*lang.Var;



	A_arbace_a2g_edge_A_Init(); tmp28 = A_arbace_a2g_edge_A_const_84; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp30 = A_arbace_a2g_edge_A_const_91; if jrt.A2g_Truth(tmp29.Invoke_O__O(jrt.NN(tmp30).Invoke_O__O(m__1))) {
		var tmp31 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp31 = A_arbace_a2g_edge_A_const_83; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp33 = A_arbace_a2g_edge_A_const_91; G__1280000057__5_ = tmp32.Invoke_O_O__O(G__1280000057__4_, tmp33.Ref()) } else {
//line :137:1
			G__1280000057__5_ = G__1280000057__4_ }; var G__1280000057__6_ any; var tmp34 /*line :133:1*/*lang.Var;



	A_arbace_a2g_edge_A_Init(); tmp34 = A_arbace_a2g_edge_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(a__2)) {

		var tmp35 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp35 = A_arbace_a2g_edge_A_const_85; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp37 = A_arbace_a2g_edge_A_const_87; G__1280000057__6_ = tmp36.Invoke_O_O_O__O(G__1280000057__5_, tmp37.Ref(), a__2) } else {
//line :137:1
			G__1280000057__6_ = G__1280000057__5_ }; var tmp38 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp38 = A_arbace_a2g_edge_A_const_86; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp40 = A_arbace_a2g_edge_A_const_40; if jrt.A2g_Truth(tmp39.Invoke_O_O__O(jrt.NN(tmp40).GetRawRoot__O(), pa__3)) {


				var tmp41 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp41 = A_arbace_a2g_edge_A_const_85; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp43 = A_arbace_a2g_edge_A_const_89; return tmp42.Invoke_O_O_O__O(G__1280000057__6_, tmp43.Ref(), pa__3) } else {
//line :137:1
					return G__1280000057__6_ } }





func A_arbace_a2g_edge_class_entry_text_A_New() *A_arbace_a2g_edge_class_entry_text_A { A_arbace_a2g_edge_class_entry_text_A_Init(); t := &A_arbace_a2g_edge_class_entry_text_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_a2g_edge_class_entry_text_A) Ctor() {}
//line :143:1
func (t *A_arbace_a2g_edge_class_entry_text_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any { var info__3 any; var tmp1 *lang.Keyword;
												A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_94; info__3 = jrt.NN(tmp1).Invoke_O__O(facets__1); var rest_text__4 any; var tmp2 /*line :143:1*/*lang.Var;

	A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_45; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_83; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_94; rest_text__4 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(facets__1, tmp6.Ref())); var tmp7 /*line :146:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_143, nil); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_45; var tmp9 any = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__0); var tmp10 any; if
	jrt.A2g_Truth(info__3) {
		var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_144, nil, Lit_145, nil, Lit_145); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_36; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; var iter__1927001039__auto____13 any; var tmp15 any = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_New(); var tmp16 *jrt.Class

		A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_Init(); tmp16 = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_fn_class; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp17 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp18 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp18 = A_arbace_a2g_edge_A_const_52; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_53; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_45; var tmp23 any = jrt.NN(tmp22).GetRawRoot__O(); var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_54; tmp14 = tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(tmp21.Invoke_O_O__O(tmp23, jrt.NN(tmp24).GetRawRoot__O()), info__3))
//line :148:1
		var tmp25 any = tmp13.Invoke_O_O__O(Lit_146, tmp14); var tmp26 *jrt.String; var more__13 any; var tmp27 *lang.Var







		A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_83; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_94; more__13 = tmp28.Invoke_O_O__O(facets__1, tmp29.Ref())
		var tmp30 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp30 = A_arbace_a2g_edge_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(more__13)) { var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_147, nil); var tmp32 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp32 = A_arbace_a2g_edge_A_const_95; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; A_arbace_a2g_edge_A_Init(); tmp34 = A_arbace_a2g_edge_A_const_96; var tmp35 any = tmp34; tmp26 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp33.Invoke_O_O_O__O(rest_text__4, tmp35, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(rest_text__4)))).Ref()))) } else { tmp26 = nil }
//line :148:1
		tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp25, nil, tmp26.Ref(), nil)).Ref() } else {
//line :147:1
			tmp10 = rest_text__4 }; return /*line :146:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref() }



func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_New() *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_Init(); t := &A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) Ctor() {}
//line :150:1
func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) Invoke_O_O__O(self, s__1280000062__1 any) any { var tmp1 any = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_New_O_O(s__1280000062__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_Init(); tmp2 = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_Init(); t := &A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) Ctor_O_O(c__s__1280000062, c__iter__1280000061 any) { t.F_s__1280000062 = c__s__1280000062; t.F_iter__1280000061 = c__iter__1280000061 }
//line :150:1
func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) Invoke_O__O(self any) any { { var s__1280000062__1 any; var t_ any = t.F_s__1280000062; t.F_s__1280000062 = nil; s__1280000062__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000062__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000062__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000062__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000062__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000064__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000064__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_New_O_I_O(b__1280000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_Init(); tmp6 = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000064__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000061); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000062__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000064__6), nil) } } else { var vec__1280000073__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000073__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000062__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1280000073__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1280000073__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.String; var G__1280000076__7_ any = k__5
L2: switch { default: switch lang.Util_Hash_O__I(G__1280000076__7_) >> 0 & 1 { case 0: var tmp20 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_82; if any(G__1280000076__7_) == any(tmp20.Ref()) {

	var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_150, nil, Lit_151); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_45; var tmp23 any = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(k__5); var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_36; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_56; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp28 = A_arbace_a2g_edge_A_const_45; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, tmp23, nil, tmp25.Invoke_O_O__O(Lit_152, tmp27.Invoke_O_O__O(jrt.NN(tmp28).GetRawRoot__O(), v__6)), nil))
//line :151:1
	break L2 }; case 1: var tmp29 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_92; if any(G__1280000076__7_) == any(tmp29.Ref()) {

		var tmp30 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_150, nil, Lit_151); var tmp31 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp31 = A_arbace_a2g_edge_A_const_45; var tmp32 any = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(k__5); var tmp33 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp33 = A_arbace_a2g_edge_A_const_36; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp35 = A_arbace_a2g_edge_A_const_56; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp37 = A_arbace_a2g_edge_A_const_45; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp30, jrt.RefArrayOf(jrt.Object_class, tmp32, nil, tmp34.Invoke_O_O__O(Lit_152, tmp36.Invoke_O_O__O(jrt.NN(tmp37).GetRawRoot__O(), v__6)), nil))
//line :151:1
		break L2 }; default:
}

	var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp39 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp39 = A_arbace_a2g_edge_A_const_45; var tmp40 any = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(k__5); var tmp41 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp41 = A_arbace_a2g_edge_A_const_45; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp38, jrt.RefArrayOf(jrt.Object_class, tmp40, nil, lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(v__6)))}
//line :150:1
	var tmp42 any = tmp19.Ref(); var tmp43 lang.IFn = lang.IFn_Cast(t.F_iter__1280000061); var tmp44 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp44 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp42, tmp43.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(s__1280000062__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :150:1
func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_Init(); t := &A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) Ctor_O_I_O(c__b__1280000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000064 = c__b__1280000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :150:1
func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) Invoke_O__O(self any) any { { var i__1280000063__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000063__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1280000068__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1280000068__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000064; var tmp5 *jrt.String; var G__1280000071__5_ any = k__3
L2: switch { default: switch lang.Util_Hash_O__I(G__1280000071__5_) >> 0 & 1 { case 0: var tmp6 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_82; if any(G__1280000071__5_) == any(tmp6.Ref()) {

	var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_150, nil, Lit_151); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_45; var tmp9 any = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(k__3); var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_36; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_56; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_45; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp11.Invoke_O_O__O(Lit_152, tmp13.Invoke_O_O__O(jrt.NN(tmp14).GetRawRoot__O(), v__4)), nil))
//line :151:1
	break L2 }; case 1: var tmp15 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_92; if any(G__1280000071__5_) == any(tmp15.Ref()) {

		var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_150, nil, Lit_151); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_45; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(k__3); var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_36; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp21 = A_arbace_a2g_edge_A_const_56; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_45; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp18, nil, tmp20.Invoke_O_O__O(Lit_152, tmp22.Invoke_O_O__O(jrt.NN(tmp23).GetRawRoot__O(), v__4)), nil))
//line :151:1
		break L2 }; default:
}

	var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_45; var tmp26 any = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(k__3); var tmp27 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_45; tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp24, jrt.RefArrayOf(jrt.Object_class, tmp26, nil, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(v__4)))}
//line :150:1
	tmp3.Invoke_O_O__O(tmp4, tmp5.Ref()); i__1280000063__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000063__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_a2g_edge_edge_text_A_New() *A_arbace_a2g_edge_edge_text_A { A_arbace_a2g_edge_edge_text_A_Init(); t := &A_arbace_a2g_edge_edge_text_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_a2g_edge_edge_text_A) Ctor() {}
//line :161:1
func (t *A_arbace_a2g_edge_edge_text_A) Invoke_O_O__O(self, p__1280000080__0 any) any { var map__1280000081__2 any = p__1280000080__0; var map__1280000081__3 any; if lang.ISeq_InstanceOf(map__1280000081__2) { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_97; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1280000081__2)) { var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_98; map__1280000081__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1280000081__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1280000081__2)) { var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_47; map__1280000081__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1280000081__2) } else { lang.PersistentArrayMap_Init(); map__1280000081__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1280000081__3 = map__1280000081__2 }; var edge__4 any = map__1280000081__3; var classes__5 any; var tmp5 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_99; classes__5 = lang.RT_Get_O_O__O(map__1280000081__3, tmp5.Ref()); var tmp6 /*line :164:1*/*jrt.RefArray = jrt.ConstRefArray("[0,7,s92:;; a2g's edge (doc/STANDALONE-NOTES.md, S2): the classes outside the forms as a2g sees them\ns84:;; on the JVM, written by bin/a2g-edge update (bin/a2g --record-edge); do not edit.\ns12:{:classes\n {ns2:}\nns2:}\n", []*jrt.Class{jrt.String_class}); var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_36; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____13 any; var tmp10 any = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_New(); var tmp11 *jrt.Class;


	A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_Init(); tmp11 = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_fn_class; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_52; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_54; tmp9 = tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(jrt.NN(tmp15).GetRawRoot__O(), classes__5)); var tmp16 any = /*line :164:1*/tmp8.Invoke_O_O__O(Lit_143, tmp9); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_36; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var iter__1927001039__auto____13_2 any; var tmp20 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_New(); var tmp21 *jrt.Class;




	A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_Init(); tmp21 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_fn_class; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp22 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp23 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_52; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_54; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_83; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_99; tmp19 = tmp22.Invoke_O__O(tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O_O__O(edge__4, tmp29.Ref()))); return /*line :164:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp16, nil, tmp18.Invoke_O__O(tmp19), nil)).Ref() }


func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_New() *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) Ctor() {}
//line :167:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) Invoke_O_O__O(self, s__1280000084__1 any) any { var tmp1 any = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_New_O_O(s__1280000084__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_Init(); tmp2 = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :167:1
func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) Ctor_O_O(c__s__1280000084, c__iter__1280000083 any) { t.F_s__1280000084 = c__s__1280000084; t.F_iter__1280000083 = c__iter__1280000083 }
//line :167:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) Invoke_O__O(self any) any { { var s__1280000084__1 any; var t_ any = t.F_s__1280000084; t.F_s__1280000084 = nil; s__1280000084__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000084__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000084__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000084__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000084__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000086__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000086__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_New_O_I_O(b__1280000086__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_Init(); tmp6 = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000086__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000083); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000084__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000086__6), nil) } } else { var vec__1280000094__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000094__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000084__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1280000094__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__1280000094__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_100; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(n__5, facets__6); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1280000083); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1280000084__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :167:1
func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :167:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) Ctor_O_I_O(c__b__1280000086 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000086 = c__b__1280000086; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :167:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) Invoke_O__O(self any) any { { var i__1280000085__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000085__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000090__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000085__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1280000090__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__1280000090__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000086; var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_100; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(n__3, facets__4)); i__1280000085__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000085__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_New() *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) Ctor() {}
//line :169:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) Invoke_O_O__O(self, s__1280000100__1 any) any { var tmp1 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_New_O_O(s__1280000100__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_Init(); tmp2 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :169:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :169:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) Ctor_O_O(c__s__1280000100, c__iter__1280000099 any) { t.F_s__1280000100 = c__s__1280000100; t.F_iter__1280000099 = c__iter__1280000099 }
//line :169:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) Invoke_O__O(self any) any { { var s__1280000100__1 any; var t_ any = t.F_s__1280000100; t.F_s__1280000100 = nil; s__1280000100__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000100__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000100__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000100__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000100__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000102__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000102__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_New_O_I_O(b__1280000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_Init(); tmp6 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000102__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000099); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000100__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000102__6), nil) } } else { var vec__1280000126__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000126__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000100__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1280000126__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1280000126__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_153, nil, Lit_171, nil, Lit_172); var tmp20 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_45; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(k__5); var tmp22 any; var tmp23 *lang.Var

	A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(v__6)) {
		var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_145); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_36; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; var iter__1927001039__auto____15 any; var tmp28 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_New(); var tmp29 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_Init(); tmp29 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_fn_class; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var tmp30 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____15); var tmp31 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp31 = A_arbace_a2g_edge_A_const_52; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp33 = A_arbace_a2g_edge_A_const_53; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp35 = A_arbace_a2g_edge_A_const_45; var tmp36 any = jrt.NN(tmp35).GetRawRoot__O(); var tmp37 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp37 = A_arbace_a2g_edge_A_const_54; tmp27 = tmp30.Invoke_O__O(tmp32.Invoke_O_O__O(tmp34.Invoke_O_O__O(tmp36, jrt.NN(tmp37).GetRawRoot__O()), v__6)); tmp22 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp26.Invoke_O_O__O(Lit_143, tmp27), nil)).Ref() } else {
			var tmp38 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp38 = A_arbace_a2g_edge_A_const_45; tmp22 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(v__6) }
//line :169:1
	var tmp39 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp21, nil, tmp22, nil)).Ref(); var tmp40 lang.IFn = lang.IFn_Cast(t.F_iter__1280000099); var tmp41 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp41 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp39, tmp40.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(s__1280000100__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :169:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :169:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) Ctor_O_I_O(c__b__1280000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000102 = c__b__1280000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :169:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) Invoke_O__O(self any) any { { var i__1280000101__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1280000106__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1280000106__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000102; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_153, nil, Lit_171, nil, Lit_172); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_45; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(k__3); var tmp8 any; var tmp9 *lang.Var

	A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(v__4)) {
		var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_145); var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_36; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; var iter__1927001039__auto____13 any; var tmp14 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_New(); var tmp15 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_Init(); tmp15 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_fn_class; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_52; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_53; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp21 = A_arbace_a2g_edge_A_const_45; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_54; tmp13 = tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp20.Invoke_O_O__O(tmp22, jrt.NN(tmp23).GetRawRoot__O()), v__4)); tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12.Invoke_O_O__O(Lit_143, tmp13), nil)).Ref() } else {
			var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_45; tmp8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(v__4) }
//line :169:1
	tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8, nil)).Ref()); i__1280000101__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000101__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_New() *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) Ctor() {}
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) Invoke_O_O__O(self, s__1280000110__1 any) any { var tmp1 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_New_O_O(s__1280000110__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_Init(); tmp2 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) Ctor_O_O(c__s__1280000110, c__iter__1280000109 any) { t.F_s__1280000110 = c__s__1280000110; t.F_iter__1280000109 = c__iter__1280000109 }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) Invoke_O__O(self any) any { { var s__1280000110__1 any; var t_ any = t.F_s__1280000110; t.F_s__1280000110 = nil; s__1280000110__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000110__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000110__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000110__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000110__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000112__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000112__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_New_O_I_O(b__1280000112__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_Init(); tmp6 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000112__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000109); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000110__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000112__6), nil) } } else { var vec__1280000120__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000120__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000110__3); var kk__5 any = lang.RT_Nth_O_I_O__O(vec__1280000120__4, lang.RT_IntCast_J__I(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O(vec__1280000120__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp20 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_45; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(kk__5); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_45; var tmp23 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(vv__6))).Ref(); var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__1280000109); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__1280000110__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :172:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) Ctor_O_I_O(c__b__1280000112 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000112 = c__b__1280000112; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) Invoke_O__O(self any) any { { var i__1280000111__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000116__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000111__1)); var kk__3 any = lang.RT_Nth_O_I_O__O(vec__1280000116__2, lang.RT_IntCast_J__I(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O(vec__1280000116__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000112; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_45; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(kk__3); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_45; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(vv__4))).Ref()); i__1280000111__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000111__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :172:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_New() *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) Ctor() {}
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) Invoke_O_O__O(self, s__1280000130__1 any) any { var tmp1 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_New_O_O(s__1280000130__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_Init(); tmp2 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) Ctor_O_O(c__s__1280000130, c__iter__1280000129 any) { t.F_s__1280000130 = c__s__1280000130; t.F_iter__1280000129 = c__iter__1280000129 }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) Invoke_O__O(self any) any { { var s__1280000130__1 any; var t_ any = t.F_s__1280000130; t.F_s__1280000130 = nil; s__1280000130__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000130__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000130__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000130__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000130__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000132__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000132__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_New_O_I_O(b__1280000132__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_Init(); tmp6 = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000132__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000129); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000130__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000132__6), nil) } } else { var vec__1280000140__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000140__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000130__3); var kk__5 any = lang.RT_Nth_O_I_O__O(vec__1280000140__4, lang.RT_IntCast_J__I(0), nil); var vv__6 any = lang.RT_Nth_O_I_O__O(vec__1280000140__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp20 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_45; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(kk__5); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_45; var tmp23 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(vv__6))).Ref(); var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__1280000129); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__1280000130__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :172:1
func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_Init(); t := &A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) Ctor_O_I_O(c__b__1280000132 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000132 = c__b__1280000132; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :172:1
func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) Invoke_O__O(self any) any { { var i__1280000131__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000136__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000131__1)); var kk__3 any = lang.RT_Nth_O_I_O__O(vec__1280000136__2, lang.RT_IntCast_J__I(0), nil); var vv__4 any = lang.RT_Nth_O_I_O__O(vec__1280000136__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000132; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_153, nil); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_45; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(kk__3); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_45; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(vv__4))).Ref()); i__1280000131__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000131__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_edge_recorded_edge_A_New() *A_arbace_a2g_edge_recorded_edge_A { A_arbace_a2g_edge_recorded_edge_A_Init(); t := &A_arbace_a2g_edge_recorded_edge_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_a2g_edge_recorded_edge_A) Ctor() {}
//line :177:1
func (t *A_arbace_a2g_edge_recorded_edge_A) Invoke_O_O_O__O(self, env_rec__0, a2g_rec__1_ any) any { var classes__3 any; var tmp1 *lang.Var;



	A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_77; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_107; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), nil)); var tmp6 any = A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_New_O(env_rec__0); var tmp7 *jrt.Class; A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_Init(); tmp7 = A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_fn_class; classes__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O(); var tmp8 /*line :186:1*/*lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_106; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_99; return tmp9.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10.Ref(), classes__3)), a2g_rec__1_) }
//line :181:1
func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_New_O(p0 any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A { A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_Init(); t := &A_arbace_a2g_edge_recorded_edge_fn__1280000148_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) Ctor_O(c__env_rec any) { t.F_env_rec = c__env_rec }
//line :181:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_61; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 any; var iter__1927001039__auto____3 any; var tmp7 any = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_New(); var tmp8 *jrt.Class; A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_Init(); tmp8 = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp10 any; var t_ any = t.F_env_rec; t.F_env_rec = nil; tmp10 = t_; tmp6 = tmp9.Invoke_O__O(tmp10); tmp1 = tmp3.Invoke_O_O__O(tmp5, tmp6) }
//line :181:1
	return nil }(); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_75; lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }
func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_New() *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_Init(); t := &A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) Ctor() {}
//line :182:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) Invoke_O_O__O(self, s__1280000150__1 any) any { var tmp1 any = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_New_O_O(s__1280000150__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_Init(); tmp2 = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_Init(); t := &A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) Ctor_O_O(c__s__1280000150, c__iter__1280000149 any) { t.F_s__1280000150 = c__s__1280000150; t.F_iter__1280000149 = c__iter__1280000149 }
//line :182:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) Invoke_O__O(self any) any { { var s__1280000150__1 any; var t_ any = t.F_s__1280000150; t.F_s__1280000150 = nil; s__1280000150__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000150__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000150__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000150__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000150__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000152__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000152__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_New_O_I_O(b__1280000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_Init(); tmp6 = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000152__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000149); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000150__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000152__6), nil) } } else { var vec__1280000161__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000161__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000150__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1280000161__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__1280000161__4, lang.RT_IntCast_J__I(1), nil); var c__7 any; var tmp17 *lang.Var
																	A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_101; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(n__5, Lit_220)) { c__7 = nil } else { var tmp18 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp18 = A_arbace_a2g_edge_A_const_102; c__7 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(n__5) }
//line :182:1
	var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_48; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp21 = A_arbace_a2g_edge_A_const_103; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any
	var G__1280000164__8_ any = facets__6
	if jrt.A2g_Truth(c__7) {
		var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_85; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_94; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp28 = A_arbace_a2g_edge_A_const_104; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp30 = A_arbace_a2g_edge_A_const_105; tmp23 = tmp25.Invoke_O_O_O__O(G__1280000164__8_, tmp27, tmp29.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(c__7))) } else {
//line :184:1
			tmp23 = G__1280000164__8_ }
//line :182:1
	var tmp31 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp22.Invoke_O_O__O(n__5, tmp23)); var tmp32 lang.IFn = lang.IFn_Cast(t.F_iter__1280000149); var tmp33 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp33 = A_arbace_a2g_edge_A_const_51; return tmp20.Invoke_O_O__O(tmp31, tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(s__1280000150__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :182:1
func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_Init(); t := &A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) Ctor_O_I_O(c__b__1280000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000152 = c__b__1280000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :182:1
func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) Invoke_O__O(self any) any { { var i__1280000151__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000156__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000151__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1280000156__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__1280000156__2, lang.RT_IntCast_J__I(1), nil); var c__5 any; var tmp2 *lang.Var
																		A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_101; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(n__3, Lit_220)) { c__5 = nil } else { var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_102; c__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__3) }
//line :182:1
	var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_44; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_b__1280000152; var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_103; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any
	var G__1280000159__6_ any = facets__4
	if jrt.A2g_Truth(c__5) {
		var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_85; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_94; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_104; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_105; tmp9 = tmp11.Invoke_O_O_O__O(G__1280000159__6_, tmp13, tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(c__5))) } else {
//line :184:1
			tmp9 = G__1280000159__6_ }
//line :182:1
	tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp8.Invoke_O_O__O(n__3, tmp9))); i__1280000151__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000151__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_edge_merge_edges_A_New() *A_arbace_a2g_edge_merge_edges_A { A_arbace_a2g_edge_merge_edges_A_Init(); t := &A_arbace_a2g_edge_merge_edges_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_a2g_edge_merge_edges_A) Ctor() {}
//line :188:1
func (t *A_arbace_a2g_edge_merge_edges_A) Invoke_O_O__O(self, edges__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_108; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_109; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 any = A_arbace_a2g_edge_merge_edges_fn__1280000169_A_New(); var tmp6 *jrt.Class; A_arbace_a2g_edge_merge_edges_fn__1280000169_A_Init(); tmp6 = A_arbace_a2g_edge_merge_edges_fn__1280000169_A_fn_class; return tmp2.Invoke_O_O_O__O(tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), edges__0) }
//line :191:1
func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_New() *A_arbace_a2g_edge_merge_edges_fn__1280000169_A { A_arbace_a2g_edge_merge_edges_fn__1280000169_A_Init(); t := &A_arbace_a2g_edge_merge_edges_fn__1280000169_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) Ctor() {}
//line :191:1
func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(a__1)) { var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_61; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(a__1, b__2) } else { var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(a__1)) {
													var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_109; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_New(); var tmp7 *jrt.Class; A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_Init(); tmp7 = A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_fn_class; return tmp5.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), a__1, b__2) } else {
//line :191:1
		var tmp8 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_25; if tmp8 != nil { return b__2 } else { return nil } } } }
func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_New() *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A { A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_Init(); t := &A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) Ctor() {}
//line :192:1
func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) Invoke_O_O_O__O(self, x__1, y__2 any) any { var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_35; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_35; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(y__2) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_106; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(x__1, y__2) } else { return y__2 } }






func A_arbace_a2g_edge_coerce_const_A_New() *A_arbace_a2g_edge_coerce_const_A { A_arbace_a2g_edge_coerce_const_A_Init(); t := &A_arbace_a2g_edge_coerce_const_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_a2g_edge_coerce_const_A) Ctor() {}
//line :199:1
func (t *A_arbace_a2g_edge_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__1)) { var G__1280000174__3_ any = desc__0
		switch lang.Util_Hash_O__I(G__1280000174__3_) { case 66: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_156) {
			return jrt.Byte_ValueOf_B__Byte(lang.RT_ByteCast_O__B(v__1)).Ref() }
//line :201:1
		case 67: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_157) {
			return jrt.Character_ValueOf_C__Character(lang.RT_CharCast_I__C(lang.RT_IntCast_O__I(v__1))).Ref() }
//line :201:1
		case 68: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_158) {

			return jrt.Double_ValueOf_D__Double(lang.RT_DoubleCast_O__D(v__1)).Ref() }
//line :201:1
		case 70: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_159) {

			return jrt.Float_ValueOf_F__Float(lang.RT_FloatCast_O__F(v__1)).Ref() }
//line :201:1
		case 73: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_160) {
			return jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(v__1)).Ref() }
//line :201:1
		case 74: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_161) {
			return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(v__1)).Ref() }
//line :201:1
		case 83: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_162) {
			return jrt.Short_ValueOf_S__Short(lang.RT_ShortCast_O__S(v__1)).Ref() }
//line :201:1
		case 90: if lang.Util_Equiv_O_O__Z(G__1280000174__3_, Lit_163) {

			return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(v__1)).Ref() }
//line :201:1
		default:}; return v__1 } else {
//line :200:1
			return nil
		}
}



func A_arbace_a2g_edge_ann_value_A_New() *A_arbace_a2g_edge_ann_value_A { A_arbace_a2g_edge_ann_value_A_Init(); t := &A_arbace_a2g_edge_ann_value_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_a2g_edge_ann_value_A) Ctor() {}
//line :206:1
func (t *A_arbace_a2g_edge_ann_value_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_35; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_35; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_63; and__1927000168__auto____3 = tmp4.Invoke_O__O(jrt.NN(tmp5).Invoke_O__O(x__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_18; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_63; var tmp9 any = jrt.NN(tmp8).Invoke_O__O(x__0); var tmp10 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_111; tmp1 = tmp7.Invoke_O_O__O(tmp9, tmp10.Ref()) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_60; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_112; var tmp14 any = tmp13; var tmp15 any = A_arbace_a2g_edge_ann_value_fn__1280000177_A_New_O(x__0); var tmp16 *jrt.Class; A_arbace_a2g_edge_ann_value_fn__1280000177_A_Init(); tmp16 = A_arbace_a2g_edge_ann_value_fn__1280000177_A_fn_class; return tmp12.Invoke_O_O_O__O(x__0, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)) } else {
//line :207:1
			var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp18 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp18 = A_arbace_a2g_edge_A_const_61; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp20 = lang.PersistentArrayMap_EMPTY; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_56; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = A_arbace_a2g_edge_ann_value_fn__1280000180_A_New(); var tmp25 *jrt.Class; A_arbace_a2g_edge_ann_value_fn__1280000180_A_Init(); tmp25 = A_arbace_a2g_edge_ann_value_fn__1280000180_A_fn_class; return tmp19.Invoke_O_O__O(tmp21, tmp23.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil), x__0)) } else {
//line :207:1
					var tmp26 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_110; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(x__0)) {


						var tmp27 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_62; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_115; return tmp28.Invoke_O_O__O(jrt.NN(tmp29).GetRawRoot__O(), x__0) } else {
//line :207:1
							var tmp30 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp30 = A_arbace_a2g_edge_A_const_25; if tmp30 != nil { return x__0 } else { return nil } } } } }
func A_arbace_a2g_edge_ann_value_fn__1280000177_A_New_O(p0 any) *A_arbace_a2g_edge_ann_value_fn__1280000177_A { A_arbace_a2g_edge_ann_value_fn__1280000177_A_Init(); t := &A_arbace_a2g_edge_ann_value_fn__1280000177_A{}; t.Ctor_O(p0); return t }
//line :208:1
func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :208:1
func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) Invoke_O_O__O(self, p1__1280000176_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_113; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_x; var tmp6 any; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_114; return tmp2.Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, tmp6), p1__1280000176_SHARP___1) }
func A_arbace_a2g_edge_ann_value_fn__1280000180_A_New() *A_arbace_a2g_edge_ann_value_fn__1280000180_A { A_arbace_a2g_edge_ann_value_fn__1280000180_A_Init(); t := &A_arbace_a2g_edge_ann_value_fn__1280000180_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) Ctor() {}
//line :209:1
func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) Invoke_O_O__O(self, p__1280000179__1 any) any { var vec__1280000181__2 any = p__1280000179__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1280000181__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1280000181__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_115; return lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__4)) }



func A_arbace_a2g_edge_info_value_A_New() *A_arbace_a2g_edge_info_value_A { A_arbace_a2g_edge_info_value_A_Init(); t := &A_arbace_a2g_edge_info_value_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_a2g_edge_info_value_A) Ctor() {}
//line :213:1
func (t *A_arbace_a2g_edge_info_value_A) Invoke_O_O__O(self, info__0 any) any { var n__2 any; var tmp1 *lang.Keyword;



	A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_80; n__2 = jrt.NN(tmp1).Invoke_O__O(info__0); var tmp2 /*line :223:1*/*lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_19; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_19; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_19; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_117; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_118; var tmp11 any = tmp7.Invoke_O_O_O__O(info__0, tmp9, jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_92; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_a2g_edge_info_value_fn__1280000188_A_New_O(n__2); var tmp15 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000188_A_Init(); tmp15 = A_arbace_a2g_edge_info_value_fn__1280000188_A_fn_class; var tmp16 any = tmp5.Invoke_O_O_O__O(tmp11, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)); var tmp17 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_82; var tmp18 any = tmp17.Ref(); var tmp19 any = A_arbace_a2g_edge_info_value_fn__1280000192_A_New_O(n__2); var tmp20 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000192_A_Init(); tmp20 = A_arbace_a2g_edge_info_value_fn__1280000192_A_fn_class; return tmp3.Invoke_O_O_O__O(tmp16, tmp18, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)) }
//line :220:1
func A_arbace_a2g_edge_info_value_fn__1280000188_A_New_O(p0 any) *A_arbace_a2g_edge_info_value_fn__1280000188_A { A_arbace_a2g_edge_info_value_fn__1280000188_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000188_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_New_O(t.F_n); var tmp4 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_Init(); tmp4 = A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), fs__1) }
//line :220:1
func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_New_O(p0 any) *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A { A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :220:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) Invoke_O_O__O(self, p1__1280000186_SHARP___1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_85; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_85; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_90; var tmp8 any = tmp6.Invoke_O_O_O__O(p1__1280000186_SHARP___1, tmp7.Ref(), t.F_n); var tmp9 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_117; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_118; var tmp12 any = tmp4.Invoke_O_O_O__O(tmp8, tmp10, jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_63; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_113; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_81; var tmp18 any = jrt.NN(tmp17).Invoke_O__O(p1__1280000186_SHARP___1); var tmp19 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_63; return tmp2.Invoke_O_O_O__O(tmp12, tmp14, tmp16.Invoke_O_O__O(tmp18, jrt.NN(tmp19).Invoke_O__O(p1__1280000186_SHARP___1)))
}
func A_arbace_a2g_edge_info_value_fn__1280000192_A_New_O(p0 any) *A_arbace_a2g_edge_info_value_fn__1280000192_A { A_arbace_a2g_edge_info_value_fn__1280000192_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000192_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :223:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) Invoke_O_O__O(self, ms__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_62; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_New_O(t.F_n); var tmp4 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_Init(); tmp4 = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ms__1) }
//line :224:1
func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_New_O(p0 any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :224:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) Invoke_O_O__O(self, m__1 any) any { var m__2 any; var tmp1 *lang.Var;
														A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_85; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_90; var tmp8 any = tmp6.Invoke_O_O_O__O(m__1, tmp7.Ref(), t.F_n); var tmp9 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_117; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_118; var tmp12 any = tmp4.Invoke_O_O_O__O(tmp8, tmp10, jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_91; var tmp14 any = tmp13.Ref(); var tmp15 any = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_New(); var tmp16 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_Init(); tmp16 = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_fn_class; m__2 = tmp2.Invoke_O_O_O__O(tmp12, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)); var tmp17 /*line :226:1*/*lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_80; if lang.Util_Equiv_O_O__Z(Lit_206, jrt.NN(tmp17).Invoke_O__O(m__2)) { return m__2 } else { var a__3 any; var tmp18 *lang.Var

		A_arbace_a2g_edge_A_Init(); tmp18 = A_arbace_a2g_edge_A_const_115; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; var or__1927000174__auto____3 any; var tmp21 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp21 = A_arbace_a2g_edge_A_const_87; or__1927000174__auto____3 = jrt.NN(tmp21).Invoke_O__O(m__2); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp20 = or__1927000174__auto____3 } else { lang.PersistentVector_Init(); tmp20 = lang.PersistentVector_EMPTY.Ref() }; a__3 = tmp19.Invoke_O__O(tmp20)
//line :226:1
		var pa__4 any; var or__1927000174__auto____4 any; var G__1280000196__4_ any; var tmp22 *lang.Keyword


		A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_89; G__1280000196__4_ = jrt.NN(tmp22).Invoke_O__O(m__2); if lang.Util_Identical_O_O__Z(G__1280000196__4_, nil) { or__1927000174__auto____4 = nil } else { var tmp23 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_115; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(G__1280000196__4_) }; if jrt.A2g_Truth(or__1927000174__auto____4) { pa__4 = or__1927000174__auto____4 } else {
			var tmp24 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp24 = A_arbace_a2g_edge_A_const_116; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_119; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp28 = A_arbace_a2g_edge_A_const_47; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp30 = A_arbace_a2g_edge_A_const_120; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp32 = A_arbace_a2g_edge_A_const_81; var tmp33 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp29.Invoke_O__O(tmp31.Invoke_O__O(jrt.NN(tmp32).Invoke_O__O(m__2))))).Ref(); var tmp34 *lang.PersistentVector; lang.PersistentVector_Init(); tmp34 = lang.PersistentVector_EMPTY; pa__4 = tmp25.Invoke_O__O(tmp27.Invoke_O_O__O(tmp33, tmp34.Ref())) }
		var tmp35 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp35 = A_arbace_a2g_edge_A_const_85; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp37 = A_arbace_a2g_edge_A_const_87; var tmp38 any = tmp37.Ref(); var tmp39 any = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_New_O(a__3); var tmp40 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_Init(); tmp40 = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_fn_class; var tmp41 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil)); var tmp42 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp42 = A_arbace_a2g_edge_A_const_89; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp44 = A_arbace_a2g_edge_A_const_56; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 any = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_New(); var tmp47 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_Init(); tmp47 = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_fn_class; return tmp36.Invoke_O_O_O_O_O__O(m__2, tmp38, tmp41, tmp43, tmp45.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil), pa__4)) } }
//line :225:1
func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_New() *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) Ctor() {}
//line :225:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) Invoke_O_O__O(self, p1__1280000187_SHARP___1 any) any { var or__1927000174__auto____2 any = p1__1280000187_SHARP___1; if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { lang.PersistentVector_Init(); return lang.PersistentVector_EMPTY.Ref() } }






func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_New_O(p0 any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :232:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) Invoke_O__O(self any) any { var t_ any = t.F_a; t.F_a = nil; return t_ }
func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_New() *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) Ctor() {}
//line :233:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_New_O(x__1); var tmp2 *jrt.Class; A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_Init(); tmp2 = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_fn_class; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_New_O(p0 any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_Init(); t := &A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :233:1
func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) Invoke_O__O(self any) any { var t_ any = t.F_x; t.F_x = nil; return t_ }


func A_arbace_a2g_edge_generics_value_A_New() *A_arbace_a2g_edge_generics_value_A { A_arbace_a2g_edge_generics_value_A_Init(); t := &A_arbace_a2g_edge_generics_value_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_a2g_edge_generics_value_A) Ctor() {}
//line :236:1
func (t *A_arbace_a2g_edge_generics_value_A) Invoke_O_O__O(self, g__0 any) any {
	if jrt.A2g_Truth(g__0) {
		var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_82; var tmp4 any = tmp3.Ref(); var tmp5 any = A_arbace_a2g_edge_generics_value_fn__1280000207_A_New(); var tmp6 *jrt.Class; A_arbace_a2g_edge_generics_value_fn__1280000207_A_Init(); tmp6 = A_arbace_a2g_edge_generics_value_fn__1280000207_A_fn_class; return tmp2.Invoke_O_O_O__O(g__0, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) } else {
//line :237:1
			return nil } }
func A_arbace_a2g_edge_generics_value_fn__1280000207_A_New() *A_arbace_a2g_edge_generics_value_fn__1280000207_A { A_arbace_a2g_edge_generics_value_fn__1280000207_A_Init(); t := &A_arbace_a2g_edge_generics_value_fn__1280000207_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) Ctor() {}
//line :238:1
func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) Invoke_O_O__O(self, ms__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_56; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_Init(); tmp4 = A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ms__1) }
//line :238:1
func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_New() *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A { A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_Init(); t := &A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) Ctor() {}
//line :238:1
func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) Invoke_O_O__O(self, p1__1280000206_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_117; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_118; return tmp2.Invoke_O_O_O__O(p1__1280000206_SHARP___1, tmp4, jrt.NN(tmp5).GetRawRoot__O()) }

func A_arbace_a2g_edge_canonical_A_New() *A_arbace_a2g_edge_canonical_A { A_arbace_a2g_edge_canonical_A_Init(); t := &A_arbace_a2g_edge_canonical_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_a2g_edge_canonical_A) Ctor() {}
//line :240:1
func (t *A_arbace_a2g_edge_canonical_A) Invoke_O_O_O__O(self, n__0, facets__1 any) any {



	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_122; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), n__0)) { return facets__1 } else { var G__1280000214__3_ any = facets__1; var G__1280000214__4_ any; var tmp6 *lang.Keyword

		A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_94; if jrt.A2g_Truth(jrt.NN(tmp6).Invoke_O__O(facets__1)) {
			var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_60; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_123; var tmp10 any = tmp9; var tmp11 any = A_arbace_a2g_edge_canonical_fn__1280000215_A_New(); var tmp12 *jrt.Class; A_arbace_a2g_edge_canonical_fn__1280000215_A_Init(); tmp12 = A_arbace_a2g_edge_canonical_fn__1280000215_A_fn_class; G__1280000214__4_ = tmp8.Invoke_O_O_O__O(G__1280000214__3_, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)) } else {
//line :246:1
				G__1280000214__4_ = G__1280000214__3_ }; var tmp13 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_121; if jrt.A2g_Truth(jrt.NN(tmp13).Invoke_O__O(facets__1)) {

					var tmp14 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_60; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_125; var tmp17 any = tmp16; var tmp18 any = A_arbace_a2g_edge_canonical_fn__1280000217_A_New(); var tmp19 *jrt.Class; A_arbace_a2g_edge_canonical_fn__1280000217_A_Init(); tmp19 = A_arbace_a2g_edge_canonical_fn__1280000217_A_fn_class; return tmp15.Invoke_O_O_O__O(G__1280000214__4_, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)) } else {
//line :246:1
						return G__1280000214__4_ } } }
func A_arbace_a2g_edge_canonical_fn__1280000215_A_New() *A_arbace_a2g_edge_canonical_fn__1280000215_A { A_arbace_a2g_edge_canonical_fn__1280000215_A_Init(); t := &A_arbace_a2g_edge_canonical_fn__1280000215_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) Ctor() {}
//line :247:1
func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) Invoke_O_O__O(self, p1__1280000212_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_116; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_52; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_124; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), p1__1280000212_SHARP___1)) }
func A_arbace_a2g_edge_canonical_fn__1280000217_A_New() *A_arbace_a2g_edge_canonical_fn__1280000217_A { A_arbace_a2g_edge_canonical_fn__1280000217_A_Init(); t := &A_arbace_a2g_edge_canonical_fn__1280000217_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) Ctor() {}
//line :248:1
func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) Invoke_O_O__O(self, p1__1280000213_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_116; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_52; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_124; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), p1__1280000213_SHARP___1)) }

func A_arbace_a2g_edge_read_edge_A_New() *A_arbace_a2g_edge_read_edge_A { A_arbace_a2g_edge_read_edge_A_Init(); t := &A_arbace_a2g_edge_read_edge_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_a2g_edge_read_edge_A) Ctor() {}
//line :250:1
func (t *A_arbace_a2g_edge_read_edge_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_77; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_127; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7.Ref())); var tmp8 any = A_arbace_a2g_edge_read_edge_fn__1280000220_A_New_O(f__0); var tmp9 *jrt.Class; A_arbace_a2g_edge_read_edge_fn__1280000220_A_Init(); tmp9 = A_arbace_a2g_edge_read_edge_fn__1280000220_A_fn_class; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O(); var tmp10 /*line :254:1*/*lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_19; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_99; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_a2g_edge_read_edge_fn__1280000222_A_New(); var tmp15 *jrt.Class; A_arbace_a2g_edge_read_edge_fn__1280000222_A_Init(); tmp15 = A_arbace_a2g_edge_read_edge_fn__1280000222_A_fn_class; return tmp11.Invoke_O_O_O__O(e__2, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) }
//line :253:1
func A_arbace_a2g_edge_read_edge_fn__1280000220_A_New_O(p0 any) *A_arbace_a2g_edge_read_edge_fn__1280000220_A { A_arbace_a2g_edge_read_edge_fn__1280000220_A_Init(); t := &A_arbace_a2g_edge_read_edge_fn__1280000220_A{}; t.Ctor_O(p0); return t }
//line :253:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :253:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_126; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_73; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_f; t.F_f = nil; tmp6 = t_; tmp1 = tmp3.Invoke_O__O(tmp5.Invoke_O__O(tmp6)) }; return nil }(); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_75; lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_New() *A_arbace_a2g_edge_read_edge_fn__1280000222_A { A_arbace_a2g_edge_read_edge_fn__1280000222_A_Init(); t := &A_arbace_a2g_edge_read_edge_fn__1280000222_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) Ctor() {}
//line :255:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) Invoke_O_O__O(self, cs__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_61; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_New(); var tmp7 *jrt.Class; A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_Init(); tmp7 = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); return tmp2.Invoke_O_O__O(tmp4, tmp5) }
//line :256:1
func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_New() *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_Init(); t := &A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) Ctor() {}
//line :256:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) Invoke_O_O__O(self, s__1280000224__1 any) any { var tmp1 any = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_New_O_O(s__1280000224__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_Init(); tmp2 = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :256:1
func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_Init(); t := &A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :256:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) Ctor_O_O(c__s__1280000224, c__iter__1280000223 any) { t.F_s__1280000224 = c__s__1280000224; t.F_iter__1280000223 = c__iter__1280000223 }
//line :256:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) Invoke_O__O(self any) any { { var s__1280000224__1 any; var t_ any = t.F_s__1280000224; t.F_s__1280000224 = nil; s__1280000224__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000224__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000224__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000224__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000224__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000226__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000226__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_New_O_I_O(b__1280000226__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_Init(); tmp6 = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000226__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000223); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000224__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000226__6), nil) } } else { var vec__1280000235__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000235__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000224__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1280000235__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__1280000235__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var G__1280000238__7_ any = facets__6; var G__1280000238__8_ any; var tmp20 *lang.Keyword
																A_arbace_a2g_edge_A_Init(); tmp20 = A_arbace_a2g_edge_A_const_94; if jrt.A2g_Truth(jrt.NN(tmp20).Invoke_O__O(facets__6)) {
																	var tmp21 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp21 = A_arbace_a2g_edge_A_const_19; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_94; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_128; G__1280000238__8_ = tmp22.Invoke_O_O_O__O(G__1280000238__7_, tmp24, jrt.NN(tmp25).GetRawRoot__O()) } else {
//line :257:1
			G__1280000238__8_ = G__1280000238__7_ }; var tmp26 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp26 = A_arbace_a2g_edge_A_const_18; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp28 = A_arbace_a2g_edge_A_const_121; if jrt.A2g_Truth(tmp27.Invoke_O_O__O(facets__6, tmp28.Ref())) {

				var tmp29 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_19; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp31 = A_arbace_a2g_edge_A_const_121; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp33 = A_arbace_a2g_edge_A_const_129; tmp19 = tmp30.Invoke_O_O_O__O(G__1280000238__8_, tmp32, jrt.NN(tmp33).GetRawRoot__O()) } else {
//line :257:1
					tmp19 = G__1280000238__8_ }
//line :256:1
	var tmp34 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp19); var tmp35 lang.IFn = lang.IFn_Cast(t.F_iter__1280000223); var tmp36 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp36 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp34, tmp35.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(s__1280000224__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :256:1
func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_Init(); t := &A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :256:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) Ctor_O_I_O(c__b__1280000226 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000226 = c__b__1280000226; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :256:1
func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) Invoke_O__O(self any) any { { var i__1280000225__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000225__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000230__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000225__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1280000230__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__1280000230__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000226; var tmp5 any; var G__1280000233__5_ any = facets__4; var G__1280000233__6_ any; var tmp6 *lang.Keyword
																		A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_94; if jrt.A2g_Truth(jrt.NN(tmp6).Invoke_O__O(facets__4)) {
																			var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_19; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_94; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_128; G__1280000233__6_ = tmp8.Invoke_O_O_O__O(G__1280000233__5_, tmp10, jrt.NN(tmp11).GetRawRoot__O()) } else {
//line :257:1
			G__1280000233__6_ = G__1280000233__5_ }; var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_18; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp14 = A_arbace_a2g_edge_A_const_121; if jrt.A2g_Truth(tmp13.Invoke_O_O__O(facets__4, tmp14.Ref())) {

				var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_19; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_121; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_129; tmp5 = tmp16.Invoke_O_O_O__O(G__1280000233__6_, tmp18, jrt.NN(tmp19).GetRawRoot__O()) } else {
//line :257:1
					tmp5 = G__1280000233__6_ }
//line :256:1
	tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp5)); i__1280000225__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000225__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_edge_read_edge_data_A_New() *A_arbace_a2g_edge_read_edge_data_A { A_arbace_a2g_edge_read_edge_data_A_Init(); t := &A_arbace_a2g_edge_read_edge_data_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_a2g_edge_read_edge_data_A) Ctor() {}
//line :261:1
func (t *A_arbace_a2g_edge_read_edge_data_A) Invoke_O_O__O(self, f__0 any) any { var e__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_77; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_127; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7.Ref())); var tmp8 any = A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_New_O(f__0); var tmp9 *jrt.Class; A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_Init(); tmp9 = A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_fn_class; e__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O(); var tmp10 /*line :265:1*/*lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_19; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_99; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_New(); var tmp15 *jrt.Class; A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_Init(); tmp15 = A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_fn_class; return tmp11.Invoke_O_O_O__O(e__2, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) }
//line :264:1
func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_New_O(p0 any) *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A { A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_Init(); t := &A_arbace_a2g_edge_read_edge_data_fn__1280000243_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :264:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_126; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_73; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_f; t.F_f = nil; tmp6 = t_; tmp1 = tmp3.Invoke_O__O(tmp5.Invoke_O__O(tmp6)) }; return nil }(); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_75; lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_New() *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A { A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_Init(); t := &A_arbace_a2g_edge_read_edge_data_fn__1280000245_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) Ctor() {}
//line :266:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) Invoke_O_O__O(self, cs__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_61; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_New(); var tmp7 *jrt.Class; A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_Init(); tmp7 = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(cs__1); return tmp2.Invoke_O_O__O(tmp4, tmp5) }
//line :267:1
func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_New() *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_Init(); t := &A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) Ctor() {}
//line :267:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) Invoke_O_O__O(self, s__1280000247__1 any) any { var tmp1 any = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_New_O_O(s__1280000247__1, self); var tmp2 *jrt.Class; A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_Init(); tmp2 = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :267:1
func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_New_O_O(p0, p1 any) *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_Init(); t := &A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :267:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) Ctor_O_O(c__s__1280000247, c__iter__1280000246 any) { t.F_s__1280000247 = c__s__1280000247; t.F_iter__1280000246 = c__iter__1280000246 }
//line :267:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) Invoke_O__O(self any) any { { var s__1280000247__1 any; var t_ any = t.F_s__1280000247; t.F_s__1280000247 = nil; s__1280000247__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1280000247__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1280000247__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1280000247__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_42; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1280000247__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1280000249__6 any; var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_43; b__1280000249__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_New_O_I_O(b__1280000249__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_Init(); tmp6 = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp7 = A_arbace_a2g_edge_A_const_46; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_49; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1280000249__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1280000246); var tmp12 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp12 = A_arbace_a2g_edge_A_const_50; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1280000247__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_46; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_49; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1280000249__6), nil) } } else { var vec__1280000258__4 any; var tmp16 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp16 = A_arbace_a2g_edge_A_const_47; vec__1280000258__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1280000247__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1280000258__4, lang.RT_IntCast_J__I(0), nil); var facets__6 any = lang.RT_Nth_O_I_O__O(vec__1280000258__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_48; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp19 = A_arbace_a2g_edge_A_const_103; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; var G__1280000261__7_ any = facets__6; var tmp22 *lang.Keyword
																	A_arbace_a2g_edge_A_Init(); tmp22 = A_arbace_a2g_edge_A_const_94; if jrt.A2g_Truth(jrt.NN(tmp22).Invoke_O__O(facets__6)) {
																		var tmp23 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp23 = A_arbace_a2g_edge_A_const_19; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp25 = A_arbace_a2g_edge_A_const_94; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp27 = A_arbace_a2g_edge_A_const_53; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp29 = A_arbace_a2g_edge_A_const_104; var tmp30 any = jrt.NN(tmp29).GetRawRoot__O(); var tmp31 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp31 = A_arbace_a2g_edge_A_const_128; tmp21 = tmp24.Invoke_O_O_O__O(G__1280000261__7_, tmp26, tmp28.Invoke_O_O__O(tmp30, jrt.NN(tmp31).GetRawRoot__O())) } else {
//line :268:1
			tmp21 = G__1280000261__7_ }
//line :267:1
	var tmp32 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp20.Invoke_O_O__O(n__5, tmp21)); var tmp33 lang.IFn = lang.IFn_Cast(t.F_iter__1280000246); var tmp34 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp34 = A_arbace_a2g_edge_A_const_51; return tmp18.Invoke_O_O__O(tmp32, tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(s__1280000247__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :267:1
func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_Init(); t := &A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :267:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) Ctor_O_I_O(c__b__1280000249 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1280000249 = c__b__1280000249; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :267:1
func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) Invoke_O__O(self any) any { { var i__1280000248__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1280000248__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1280000253__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1280000248__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1280000253__2, lang.RT_IntCast_J__I(0), nil); var facets__4 any = lang.RT_Nth_O_I_O__O(vec__1280000253__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_44; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1280000249; var tmp5 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp5 = A_arbace_a2g_edge_A_const_103; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; var G__1280000256__5_ any = facets__4; var tmp8 *lang.Keyword
																			A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_94; if jrt.A2g_Truth(jrt.NN(tmp8).Invoke_O__O(facets__4)) {
																				var tmp9 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp9 = A_arbace_a2g_edge_A_const_19; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_94; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp13 = A_arbace_a2g_edge_A_const_53; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp15 = A_arbace_a2g_edge_A_const_104; var tmp16 any = jrt.NN(tmp15).GetRawRoot__O(); var tmp17 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp17 = A_arbace_a2g_edge_A_const_128; tmp7 = tmp10.Invoke_O_O_O__O(G__1280000256__5_, tmp12, tmp14.Invoke_O_O__O(tmp16, jrt.NN(tmp17).GetRawRoot__O())) } else {
//line :268:1
			tmp7 = G__1280000256__5_ }
//line :267:1
	tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp6.Invoke_O_O__O(n__3, tmp7))); i__1280000248__1 = lang.Numbers_Unchecked_inc_J__J(i__1280000248__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_edge_write_edge_BANG__A_New() *A_arbace_a2g_edge_write_edge_BANG__A { A_arbace_a2g_edge_write_edge_BANG__A_Init(); t := &A_arbace_a2g_edge_write_edge_BANG__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_a2g_edge_write_edge_BANG__A) Ctor() {}
//line :271:1
func (t *A_arbace_a2g_edge_write_edge_BANG__A) Invoke_O_O_O__O(self, f__0, edge__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_131; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0)
	var tmp2 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_130; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_132; return tmp3.Invoke_O_O__O(f__0, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(edge__1))
}
func A_arbace_a2g_edge__main_A_New() *A_arbace_a2g_edge__main_A { A_arbace_a2g_edge__main_A_Init(); t := &A_arbace_a2g_edge__main_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_a2g_edge__main_A) Ctor() {}
//line :275:1
func (t *A_arbace_a2g_edge__main_A) DoInvoke_O_O_O__O(self, cmd__0, args__1 any) any { var G__1280000267__3_ any = cmd__0; switch


	lang.Util_Hash_O__I(G__1280000267__3_) { case 103785528: if lang.Util_Equiv_O_O__Z(G__1280000267__3_, Lit_106) { var vec__1280000268__4 any = args__1; var seq__1280000269__5 any; var tmp1 *lang.Var
		A_arbace_a2g_edge_A_Init(); tmp1 = A_arbace_a2g_edge_A_const_40; seq__1280000269__5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1280000268__4)
//line :278:1
		var first__1280000270__6 any; var tmp2 *lang.Var
		A_arbace_a2g_edge_A_Init(); tmp2 = A_arbace_a2g_edge_A_const_47; first__1280000270__6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1280000269__5)
//line :278:1
		var seq__1280000269__7 any; var tmp3 *lang.Var
		A_arbace_a2g_edge_A_Init(); tmp3 = A_arbace_a2g_edge_A_const_97; seq__1280000269__7 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1280000269__5)
//line :278:1
		var out__8 any = first__1280000270__6; var ins__9 any = seq__1280000269__7; var tmp4 *lang.Var

		A_arbace_a2g_edge_A_Init(); tmp4 = A_arbace_a2g_edge_A_const_133; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp6 = A_arbace_a2g_edge_A_const_134; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp8 = A_arbace_a2g_edge_A_const_56; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp10 = A_arbace_a2g_edge_A_const_135; return tmp5.Invoke_O_O__O(out__8, tmp7.Invoke_O__O(tmp9.Invoke_O_O__O(jrt.NN(tmp10).GetRawRoot__O(), ins__9))) }
//line :278:1
	default:}; var tmp11 *lang.Var; A_arbace_a2g_edge_A_Init(); tmp11 = A_arbace_a2g_edge_A_const_39; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_133, nil), jrt.RefArrayOf(jrt.Object_class, nil, cmd__0)).Ref(); var tmp14 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp14 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp12.Invoke_O_O__O(tmp13, tmp14.Ref())))) }

















































































































































































































































type A_arbace_a2g_edge_A struct{ jrt.Object }

var A_arbace_a2g_edge_A_const_0 *lang.Var

var A_arbace_a2g_edge_A_const_1 *lang.Var

var A_arbace_a2g_edge_A_const_2 any

var A_arbace_a2g_edge_A_const_3 any

var A_arbace_a2g_edge_A_const_4 any

var A_arbace_a2g_edge_A_const_5 any

var A_arbace_a2g_edge_A_const_6 any

var A_arbace_a2g_edge_A_const_7 *lang.Var

var A_arbace_a2g_edge_A_const_8 *lang.Var

var A_arbace_a2g_edge_A_const_9 *lang.Var

var A_arbace_a2g_edge_A_const_10 any

var A_arbace_a2g_edge_A_const_11 *lang.Var

var A_arbace_a2g_edge_A_const_12 *lang.Var

var A_arbace_a2g_edge_A_const_13 *lang.Var

var A_arbace_a2g_edge_A_const_14 *lang.Var

var A_arbace_a2g_edge_A_const_15 *lang.Var

var A_arbace_a2g_edge_A_const_16 *lang.Var

var A_arbace_a2g_edge_A_const_17 *lang.Var

var A_arbace_a2g_edge_A_const_18 *lang.Var

var A_arbace_a2g_edge_A_const_19 *lang.Var

var A_arbace_a2g_edge_A_const_20 *lang.Var

var A_arbace_a2g_edge_A_const_21 *lang.Var

var A_arbace_a2g_edge_A_const_22 any

var A_arbace_a2g_edge_A_const_23 any

var A_arbace_a2g_edge_A_const_24 *lang.Var

var A_arbace_a2g_edge_A_const_25 *lang.Keyword

var A_arbace_a2g_edge_A_const_26 *lang.Var

var A_arbace_a2g_edge_A_const_27 any

var A_arbace_a2g_edge_A_const_28 any

var A_arbace_a2g_edge_A_const_29 *lang.Var

var A_arbace_a2g_edge_A_const_30 *lang.Var

var A_arbace_a2g_edge_A_const_31 *lang.Var

var A_arbace_a2g_edge_A_const_32 *lang.Var

var A_arbace_a2g_edge_A_const_33 *lang.Var

var A_arbace_a2g_edge_A_const_34 *lang.Var

var A_arbace_a2g_edge_A_const_35 *lang.Var

var A_arbace_a2g_edge_A_const_36 *lang.Var

var A_arbace_a2g_edge_A_const_37 *lang.Var

var A_arbace_a2g_edge_A_const_38 *lang.Var

var A_arbace_a2g_edge_A_const_39 *lang.Var

var A_arbace_a2g_edge_A_const_40 *lang.Var

var A_arbace_a2g_edge_A_const_41 *lang.Var

var A_arbace_a2g_edge_A_const_42 *lang.Var

var A_arbace_a2g_edge_A_const_43 *lang.Var

var A_arbace_a2g_edge_A_const_44 *lang.Var

var A_arbace_a2g_edge_A_const_45 *lang.Var

var A_arbace_a2g_edge_A_const_46 *lang.Var

var A_arbace_a2g_edge_A_const_47 *lang.Var

var A_arbace_a2g_edge_A_const_48 *lang.Var

var A_arbace_a2g_edge_A_const_49 *lang.Var

var A_arbace_a2g_edge_A_const_50 *lang.Var

var A_arbace_a2g_edge_A_const_51 *lang.Var

var A_arbace_a2g_edge_A_const_52 *lang.Var

var A_arbace_a2g_edge_A_const_53 *lang.Var

var A_arbace_a2g_edge_A_const_54 *lang.Var

var A_arbace_a2g_edge_A_const_55 *lang.Var

var A_arbace_a2g_edge_A_const_56 *lang.Var

var A_arbace_a2g_edge_A_const_57 *lang.Var

var A_arbace_a2g_edge_A_const_58 *lang.Keyword

var A_arbace_a2g_edge_A_const_59 *lang.Var

var A_arbace_a2g_edge_A_const_60 *lang.Var

var A_arbace_a2g_edge_A_const_61 *lang.Var

var A_arbace_a2g_edge_A_const_62 *lang.Var

var A_arbace_a2g_edge_A_const_63 *lang.Keyword

var A_arbace_a2g_edge_A_const_64 any

var A_arbace_a2g_edge_A_const_65 *lang.Var

var A_arbace_a2g_edge_A_const_66 *lang.Var

var A_arbace_a2g_edge_A_const_67 *lang.Var

var A_arbace_a2g_edge_A_const_68 *lang.Var

var A_arbace_a2g_edge_A_const_69 *lang.Var

var A_arbace_a2g_edge_A_const_70 *lang.Var

var A_arbace_a2g_edge_A_const_71 *lang.Var

var A_arbace_a2g_edge_A_const_72 any

var A_arbace_a2g_edge_A_const_73 *lang.Var

var A_arbace_a2g_edge_A_const_74 *lang.Var

var A_arbace_a2g_edge_A_const_75 *lang.Var

var A_arbace_a2g_edge_A_const_76 *lang.Var

var A_arbace_a2g_edge_A_const_77 *lang.Var

var A_arbace_a2g_edge_A_const_78 *lang.Var

var A_arbace_a2g_edge_A_const_79 *lang.Var

var A_arbace_a2g_edge_A_const_80 *lang.Keyword

var A_arbace_a2g_edge_A_const_81 *lang.Keyword

var A_arbace_a2g_edge_A_const_82 *lang.Keyword

var A_arbace_a2g_edge_A_const_83 *lang.Var

var A_arbace_a2g_edge_A_const_84 *lang.Var

var A_arbace_a2g_edge_A_const_85 *lang.Var

var A_arbace_a2g_edge_A_const_86 *lang.Var

var A_arbace_a2g_edge_A_const_87 *lang.Keyword

var A_arbace_a2g_edge_A_const_88 *lang.Var

var A_arbace_a2g_edge_A_const_89 *lang.Keyword

var A_arbace_a2g_edge_A_const_90 *lang.Keyword

var A_arbace_a2g_edge_A_const_91 *lang.Keyword

var A_arbace_a2g_edge_A_const_92 *lang.Keyword

var A_arbace_a2g_edge_A_const_93 *lang.Keyword

var A_arbace_a2g_edge_A_const_94 *lang.Keyword

var A_arbace_a2g_edge_A_const_95 *lang.Var

var A_arbace_a2g_edge_A_const_96 any

var A_arbace_a2g_edge_A_const_97 *lang.Var

var A_arbace_a2g_edge_A_const_98 *lang.Var

var A_arbace_a2g_edge_A_const_99 *lang.Keyword

var A_arbace_a2g_edge_A_const_100 *lang.Var

var A_arbace_a2g_edge_A_const_101 *lang.Var

var A_arbace_a2g_edge_A_const_102 *lang.Var

var A_arbace_a2g_edge_A_const_103 *lang.Var

var A_arbace_a2g_edge_A_const_104 *lang.Var

var A_arbace_a2g_edge_A_const_105 *lang.Var

var A_arbace_a2g_edge_A_const_106 *lang.Var

var A_arbace_a2g_edge_A_const_107 *lang.Var

var A_arbace_a2g_edge_A_const_108 *lang.Var

var A_arbace_a2g_edge_A_const_109 *lang.Var

var A_arbace_a2g_edge_A_const_110 *lang.Var

var A_arbace_a2g_edge_A_const_111 *lang.Keyword

var A_arbace_a2g_edge_A_const_112 any

var A_arbace_a2g_edge_A_const_113 *lang.Var

var A_arbace_a2g_edge_A_const_114 any

var A_arbace_a2g_edge_A_const_115 *lang.Var

var A_arbace_a2g_edge_A_const_116 *lang.Var

var A_arbace_a2g_edge_A_const_117 *lang.Keyword

var A_arbace_a2g_edge_A_const_118 *lang.Var

var A_arbace_a2g_edge_A_const_119 *lang.Var

var A_arbace_a2g_edge_A_const_120 *lang.Var

var A_arbace_a2g_edge_A_const_121 *lang.Keyword

var A_arbace_a2g_edge_A_const_122 *lang.Var

var A_arbace_a2g_edge_A_const_123 any

var A_arbace_a2g_edge_A_const_124 *lang.Var

var A_arbace_a2g_edge_A_const_125 any

var A_arbace_a2g_edge_A_const_126 *lang.Var

var A_arbace_a2g_edge_A_const_127 *lang.Var

var A_arbace_a2g_edge_A_const_128 *lang.Var

var A_arbace_a2g_edge_A_const_129 *lang.Var

var A_arbace_a2g_edge_A_const_130 *lang.Var

var A_arbace_a2g_edge_A_const_131 *lang.Var

var A_arbace_a2g_edge_A_const_132 *lang.Var

var A_arbace_a2g_edge_A_const_133 *lang.Var

var A_arbace_a2g_edge_A_const_134 *lang.Var

var A_arbace_a2g_edge_A_const_135 *lang.Var

var A_arbace_a2g_edge_A_init jrt.ClassInit

func A_arbace_a2g_edge_A_Init() { if !A_arbace_a2g_edge_A_init.Done() { A_arbace_a2g_edge_A_init.Run(A_arbace_a2g_edge_A_clinit) } }

func A_arbace_a2g_edge_A_clinit() { A_arbace_a2g_edge_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_edge_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_edge_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_edge_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_edge_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_edge_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_edge_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_edge_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_a2g_edge_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_a2g_edge_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_a2g_edge_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_a2g_edge_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_edge_A_const_12 = lang.RT_Var_String_String__Var(Lit_15, Lit_19); A_arbace_a2g_edge_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_edge_A_const_14 = lang.RT_Var_String_String__Var(Lit_15, Lit_21); A_arbace_a2g_edge_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_a2g_edge_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_a2g_edge_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_a2g_edge_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_a2g_edge_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_a2g_edge_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_a2g_edge_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_a2g_edge_A_const_22 = jrt.Character_ValueOf_C__Character(34).Ref(); A_arbace_a2g_edge_A_const_23 = jrt.Character_ValueOf_C__Character(92).Ref(); A_arbace_a2g_edge_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_edge_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_a2g_edge_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_edge_A_const_27 = jrt.Long_ValueOf_J__Long(32).Ref(); A_arbace_a2g_edge_A_const_28 = jrt.Long_ValueOf_J__Long(126).Ref(); A_arbace_a2g_edge_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_edge_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_edge_A_const_31 = lang.RT_Var_String_String__Var(Lit_15, Lit_33); A_arbace_a2g_edge_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_edge_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_edge_A_const_34 = lang.RT_Var_String_String__Var(Lit_15, Lit_36); A_arbace_a2g_edge_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_a2g_edge_A_const_36 = lang.RT_Var_String_String__Var(Lit_3, Lit_38); A_arbace_a2g_edge_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_a2g_edge_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_edge_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_a2g_edge_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_a2g_edge_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_a2g_edge_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_a2g_edge_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_a2g_edge_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_a2g_edge_A_const_45 = lang.RT_Var_String_String__Var(Lit_15, Lit_47); A_arbace_a2g_edge_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_a2g_edge_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_a2g_edge_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_a2g_edge_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_a2g_edge_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_a2g_edge_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_a2g_edge_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_a2g_edge_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_a2g_edge_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_a2g_edge_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_a2g_edge_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_a2g_edge_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_a2g_edge_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_a2g_edge_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_a2g_edge_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_a2g_edge_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_a2g_edge_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_a2g_edge_A_const_63 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_a2g_edge_A_const_64 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_66).Ref()); A_arbace_a2g_edge_A_const_65 = lang.RT_Var_String_String__Var(Lit_15, Lit_67); A_arbace_a2g_edge_A_const_66 = lang.RT_Var_String_String__Var(Lit_15, Lit_68); A_arbace_a2g_edge_A_const_67 = lang.RT_Var_String_String__Var(Lit_6, Lit_69); A_arbace_a2g_edge_A_const_68 = lang.RT_Var_String_String__Var(Lit_3, Lit_70); A_arbace_a2g_edge_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_a2g_edge_A_const_70 = lang.RT_Var_String_String__Var(Lit_3, Lit_72); A_arbace_a2g_edge_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_a2g_edge_A_const_72 = jrt.Pattern_Compile_String__Pattern(Lit_74).Ref(); A_arbace_a2g_edge_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_a2g_edge_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_a2g_edge_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_a2g_edge_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_a2g_edge_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_a2g_edge_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_a2g_edge_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_a2g_edge_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_82); A_arbace_a2g_edge_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); A_arbace_a2g_edge_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_a2g_edge_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_85); A_arbace_a2g_edge_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_a2g_edge_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_a2g_edge_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_a2g_edge_A_const_87 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_a2g_edge_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_a2g_edge_A_const_89 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_a2g_edge_A_const_90 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_a2g_edge_A_const_91 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_a2g_edge_A_const_92 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_a2g_edge_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_a2g_edge_A_const_94 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_a2g_edge_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_a2g_edge_A_const_96 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_a2g_edge_A_const_97 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_a2g_edge_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_a2g_edge_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_99); A_arbace_a2g_edge_A_const_100 = lang.RT_Var_String_String__Var(Lit_15, Lit_100); A_arbace_a2g_edge_A_const_101 = lang.RT_Var_String_String__Var(Lit_3, Lit_101); A_arbace_a2g_edge_A_const_102 = lang.RT_Var_String_String__Var(Lit_10, Lit_102); A_arbace_a2g_edge_A_const_103 = lang.RT_Var_String_String__Var(Lit_15, Lit_103); A_arbace_a2g_edge_A_const_104 = lang.RT_Var_String_String__Var(Lit_15, Lit_104); A_arbace_a2g_edge_A_const_105 = lang.RT_Var_String_String__Var(Lit_10, Lit_105); A_arbace_a2g_edge_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_a2g_edge_A_const_107 = lang.RT_Var_String_String__Var(Lit_10, Lit_107); A_arbace_a2g_edge_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_108); A_arbace_a2g_edge_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_a2g_edge_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_a2g_edge_A_const_111 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_a2g_edge_A_const_112 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_66).Ref()); A_arbace_a2g_edge_A_const_113 = lang.RT_Var_String_String__Var(Lit_15, Lit_111); A_arbace_a2g_edge_A_const_114 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_112).Ref()); A_arbace_a2g_edge_A_const_115 = lang.RT_Var_String_String__Var(Lit_15, Lit_113); A_arbace_a2g_edge_A_const_116 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_a2g_edge_A_const_117 = lang.RT_Keyword_String_String__Keyword(nil, Lit_115); A_arbace_a2g_edge_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_a2g_edge_A_const_119 = lang.RT_Var_String_String__Var(Lit_0, Lit_117); A_arbace_a2g_edge_A_const_120 = lang.RT_Var_String_String__Var(Lit_8, Lit_118); A_arbace_a2g_edge_A_const_121 = lang.RT_Keyword_String_String__Keyword(nil, Lit_119); A_arbace_a2g_edge_A_const_122 = lang.RT_Var_String_String__Var(Lit_15, Lit_120); A_arbace_a2g_edge_A_const_123 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref()); A_arbace_a2g_edge_A_const_124 = lang.RT_Var_String_String__Var(Lit_15, Lit_121); A_arbace_a2g_edge_A_const_125 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref()); A_arbace_a2g_edge_A_const_126 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_a2g_edge_A_const_127 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_a2g_edge_A_const_128 = lang.RT_Var_String_String__Var(Lit_15, Lit_124); A_arbace_a2g_edge_A_const_129 = lang.RT_Var_String_String__Var(Lit_15, Lit_125); A_arbace_a2g_edge_A_const_130 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_a2g_edge_A_const_131 = lang.RT_Var_String_String__Var(Lit_6, Lit_127); A_arbace_a2g_edge_A_const_132 = lang.RT_Var_String_String__Var(Lit_15, Lit_128); A_arbace_a2g_edge_A_const_133 = lang.RT_Var_String_String__Var(Lit_15, Lit_129); A_arbace_a2g_edge_A_const_134 = lang.RT_Var_String_String__Var(Lit_15, Lit_130); A_arbace_a2g_edge_A_const_135 = lang.RT_Var_String_String__Var(Lit_15, Lit_131) }

func A_arbace_a2g_edge_A_New() *A_arbace_a2g_edge_A { A_arbace_a2g_edge_A_Init(); t := &A_arbace_a2g_edge_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_edge_A) Ctor() {}

func (t *A_arbace_a2g_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_A_class }

func (t *A_arbace_a2g_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_A); return ok }

func A_arbace_a2g_edge_A_Cast(x any) *A_arbace_a2g_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_A_class)) }; return v }



type A_arbace_a2g_edge__main_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge__main_A) Is_Compiler_AOTR1() {}

var A_arbace_a2g_edge__main_A_fn_class *jrt.Class

var A_arbace_a2g_edge__main_A_init jrt.ClassInit

func A_arbace_a2g_edge__main_A_Init() { if !A_arbace_a2g_edge__main_A_init.Done() { A_arbace_a2g_edge__main_A_init.Run(A_arbace_a2g_edge__main_A_clinit) } }

func A_arbace_a2g_edge__main_A_clinit() { A_arbace_a2g_edge__main_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_a2g_edge__main_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge__main_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge__main_A_class }

func (t *A_arbace_a2g_edge__main_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge__main_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge__main_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge__main_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge__main_A); return ok }

func A_arbace_a2g_edge__main_A_Cast(x any) *A_arbace_a2g_edge__main_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge__main_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge__main_A_class)) }; return v }



type A_arbace_a2g_edge_ann_data_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_ann_data_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_ann_data_A_fn_class *jrt.Class

var A_arbace_a2g_edge_ann_data_A_init jrt.ClassInit

func A_arbace_a2g_edge_ann_data_A_Init() { if !A_arbace_a2g_edge_ann_data_A_init.Done() { A_arbace_a2g_edge_ann_data_A_init.Run(A_arbace_a2g_edge_ann_data_A_clinit) } }

func A_arbace_a2g_edge_ann_data_A_clinit() { A_arbace_a2g_edge_ann_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_ann_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_ann_data_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_ann_data_A_class }

func (t *A_arbace_a2g_edge_ann_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_ann_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_ann_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_ann_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_ann_data_A); return ok }

func A_arbace_a2g_edge_ann_data_A_Cast(x any) *A_arbace_a2g_edge_ann_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_ann_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_ann_data_A_class)) }; return v }



type A_arbace_a2g_edge_ann_data_fn__1280000035_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_ann_data_fn__1280000035_A_fn_class *jrt.Class

var A_arbace_a2g_edge_ann_data_fn__1280000035_A_init jrt.ClassInit

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_Init() { if !A_arbace_a2g_edge_ann_data_fn__1280000035_A_init.Done() { A_arbace_a2g_edge_ann_data_fn__1280000035_A_init.Run(A_arbace_a2g_edge_ann_data_fn__1280000035_A_clinit) } }

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_clinit() { A_arbace_a2g_edge_ann_data_fn__1280000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_ann_data_fn__1280000035_A_class }

func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_ann_data_fn__1280000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_ann_data_fn__1280000035_A); return ok }

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_Cast(x any) *A_arbace_a2g_edge_ann_data_fn__1280000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_ann_data_fn__1280000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_ann_data_fn__1280000035_A_class)) }; return v }



type A_arbace_a2g_edge_ann_value_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_ann_value_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_ann_value_A_fn_class *jrt.Class

var A_arbace_a2g_edge_ann_value_A_init jrt.ClassInit

func A_arbace_a2g_edge_ann_value_A_Init() { if !A_arbace_a2g_edge_ann_value_A_init.Done() { A_arbace_a2g_edge_ann_value_A_init.Run(A_arbace_a2g_edge_ann_value_A_clinit) } }

func A_arbace_a2g_edge_ann_value_A_clinit() { A_arbace_a2g_edge_ann_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_ann_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_ann_value_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_ann_value_A_class }

func (t *A_arbace_a2g_edge_ann_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_ann_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_ann_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_ann_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_ann_value_A); return ok }

func A_arbace_a2g_edge_ann_value_A_Cast(x any) *A_arbace_a2g_edge_ann_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_ann_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_ann_value_A_class)) }; return v }



type A_arbace_a2g_edge_ann_value_fn__1280000177_A struct{ jrt.Object; F_x any }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_ann_value_fn__1280000177_A_fn_class *jrt.Class

var A_arbace_a2g_edge_ann_value_fn__1280000177_A_init jrt.ClassInit

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_Init() { if !A_arbace_a2g_edge_ann_value_fn__1280000177_A_init.Done() { A_arbace_a2g_edge_ann_value_fn__1280000177_A_init.Run(A_arbace_a2g_edge_ann_value_fn__1280000177_A_clinit) } }

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_clinit() { A_arbace_a2g_edge_ann_value_fn__1280000177_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_ann_value_fn__1280000177_A_class }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000177_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_ann_value_fn__1280000177_A); return ok }

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_Cast(x any) *A_arbace_a2g_edge_ann_value_fn__1280000177_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_ann_value_fn__1280000177_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_ann_value_fn__1280000177_A_class)) }; return v }



type A_arbace_a2g_edge_ann_value_fn__1280000180_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_ann_value_fn__1280000180_A_fn_class *jrt.Class

var A_arbace_a2g_edge_ann_value_fn__1280000180_A_init jrt.ClassInit

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_Init() { if !A_arbace_a2g_edge_ann_value_fn__1280000180_A_init.Done() { A_arbace_a2g_edge_ann_value_fn__1280000180_A_init.Run(A_arbace_a2g_edge_ann_value_fn__1280000180_A_clinit) } }

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_clinit() { A_arbace_a2g_edge_ann_value_fn__1280000180_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_ann_value_fn__1280000180_A_class }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_ann_value_fn__1280000180_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_ann_value_fn__1280000180_A); return ok }

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_Cast(x any) *A_arbace_a2g_edge_ann_value_fn__1280000180_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_ann_value_fn__1280000180_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_ann_value_fn__1280000180_A_class)) }; return v }



type A_arbace_a2g_edge_canonical_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_canonical_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_canonical_A_fn_class *jrt.Class

var A_arbace_a2g_edge_canonical_A_init jrt.ClassInit

func A_arbace_a2g_edge_canonical_A_Init() { if !A_arbace_a2g_edge_canonical_A_init.Done() { A_arbace_a2g_edge_canonical_A_init.Run(A_arbace_a2g_edge_canonical_A_clinit) } }

func A_arbace_a2g_edge_canonical_A_clinit() { A_arbace_a2g_edge_canonical_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_canonical_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_canonical_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_canonical_A_class }

func (t *A_arbace_a2g_edge_canonical_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_canonical_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_canonical_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_canonical_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_canonical_A); return ok }

func A_arbace_a2g_edge_canonical_A_Cast(x any) *A_arbace_a2g_edge_canonical_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_canonical_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_canonical_A_class)) }; return v }



type A_arbace_a2g_edge_canonical_fn__1280000215_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_canonical_fn__1280000215_A_fn_class *jrt.Class

var A_arbace_a2g_edge_canonical_fn__1280000215_A_init jrt.ClassInit

func A_arbace_a2g_edge_canonical_fn__1280000215_A_Init() { if !A_arbace_a2g_edge_canonical_fn__1280000215_A_init.Done() { A_arbace_a2g_edge_canonical_fn__1280000215_A_init.Run(A_arbace_a2g_edge_canonical_fn__1280000215_A_clinit) } }

func A_arbace_a2g_edge_canonical_fn__1280000215_A_clinit() { A_arbace_a2g_edge_canonical_fn__1280000215_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_canonical_fn__1280000215_A_class }

func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_canonical_fn__1280000215_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_canonical_fn__1280000215_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_canonical_fn__1280000215_A); return ok }

func A_arbace_a2g_edge_canonical_fn__1280000215_A_Cast(x any) *A_arbace_a2g_edge_canonical_fn__1280000215_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_canonical_fn__1280000215_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_canonical_fn__1280000215_A_class)) }; return v }



type A_arbace_a2g_edge_canonical_fn__1280000217_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_canonical_fn__1280000217_A_fn_class *jrt.Class

var A_arbace_a2g_edge_canonical_fn__1280000217_A_init jrt.ClassInit

func A_arbace_a2g_edge_canonical_fn__1280000217_A_Init() { if !A_arbace_a2g_edge_canonical_fn__1280000217_A_init.Done() { A_arbace_a2g_edge_canonical_fn__1280000217_A_init.Run(A_arbace_a2g_edge_canonical_fn__1280000217_A_clinit) } }

func A_arbace_a2g_edge_canonical_fn__1280000217_A_clinit() { A_arbace_a2g_edge_canonical_fn__1280000217_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_canonical_fn__1280000217_A_class }

func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_canonical_fn__1280000217_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_canonical_fn__1280000217_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_canonical_fn__1280000217_A); return ok }

func A_arbace_a2g_edge_canonical_fn__1280000217_A_Cast(x any) *A_arbace_a2g_edge_canonical_fn__1280000217_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_canonical_fn__1280000217_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_canonical_fn__1280000217_A_class)) }; return v }



type A_arbace_a2g_edge_class_entry_text_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_class_entry_text_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_class_entry_text_A_fn_class *jrt.Class

var A_arbace_a2g_edge_class_entry_text_A_init jrt.ClassInit

func A_arbace_a2g_edge_class_entry_text_A_Init() { if !A_arbace_a2g_edge_class_entry_text_A_init.Done() { A_arbace_a2g_edge_class_entry_text_A_init.Run(A_arbace_a2g_edge_class_entry_text_A_clinit) } }

func A_arbace_a2g_edge_class_entry_text_A_clinit() { A_arbace_a2g_edge_class_entry_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_class_entry_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_class_entry_text_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_class_entry_text_A_class }

func (t *A_arbace_a2g_edge_class_entry_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_class_entry_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_class_entry_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_class_entry_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_class_entry_text_A); return ok }

func A_arbace_a2g_edge_class_entry_text_A_Cast(x any) *A_arbace_a2g_edge_class_entry_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_class_entry_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_class_entry_text_A_class)) }; return v }



type A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_fn_class *jrt.Class

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_init jrt.ClassInit

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_Init() { if !A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_init.Done() { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_init.Run(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_clinit) } }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_clinit() { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_class }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A); return ok }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_Cast(x any) *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_class)) }; return v }



type A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A struct{ jrt.Object; F_s__1280000062, F_iter__1280000061 any }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_fn_class *jrt.Class

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_init jrt.ClassInit

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_Init() { if !A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_init.Done() { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_init.Run(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_clinit) } }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_clinit() { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_class }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A); return ok }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_Cast(x any) *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_class)) }; return v }



type A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A struct{ jrt.Object; F_b__1280000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_fn_class *jrt.Class

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_init jrt.ClassInit

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_Init() { if !A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_init.Done() { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_init.Run(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_clinit) } }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_clinit() { A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_class }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A); return ok }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_Cast(x any) *A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_class)) }; return v }



type A_arbace_a2g_edge_coerce_const_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_coerce_const_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_coerce_const_A_fn_class *jrt.Class

var A_arbace_a2g_edge_coerce_const_A_init jrt.ClassInit

func A_arbace_a2g_edge_coerce_const_A_Init() { if !A_arbace_a2g_edge_coerce_const_A_init.Done() { A_arbace_a2g_edge_coerce_const_A_init.Run(A_arbace_a2g_edge_coerce_const_A_clinit) } }

func A_arbace_a2g_edge_coerce_const_A_clinit() { A_arbace_a2g_edge_coerce_const_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_coerce_const_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_coerce_const_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_coerce_const_A_class }

func (t *A_arbace_a2g_edge_coerce_const_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_coerce_const_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_coerce_const_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_coerce_const_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_coerce_const_A); return ok }

func A_arbace_a2g_edge_coerce_const_A_Cast(x any) *A_arbace_a2g_edge_coerce_const_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_coerce_const_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_coerce_const_A_class)) }; return v }



type A_arbace_a2g_edge_const_data_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_const_data_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_const_data_A_fn_class *jrt.Class

var A_arbace_a2g_edge_const_data_A_init jrt.ClassInit

func A_arbace_a2g_edge_const_data_A_Init() { if !A_arbace_a2g_edge_const_data_A_init.Done() { A_arbace_a2g_edge_const_data_A_init.Run(A_arbace_a2g_edge_const_data_A_clinit) } }

func A_arbace_a2g_edge_const_data_A_clinit() { A_arbace_a2g_edge_const_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_const_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_const_data_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_const_data_A_class }

func (t *A_arbace_a2g_edge_const_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_const_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_const_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_const_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_const_data_A); return ok }

func A_arbace_a2g_edge_const_data_A_Cast(x any) *A_arbace_a2g_edge_const_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_const_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_const_data_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_edge_text_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_edge_text_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_A_Init() { if !A_arbace_a2g_edge_edge_text_A_init.Done() { A_arbace_a2g_edge_edge_text_A_init.Run(A_arbace_a2g_edge_edge_text_A_clinit) } }

func A_arbace_a2g_edge_edge_text_A_clinit() { A_arbace_a2g_edge_edge_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_A_class }

func (t *A_arbace_a2g_edge_edge_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_A); return ok }

func A_arbace_a2g_edge_edge_text_A_Cast(x any) *A_arbace_a2g_edge_edge_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A struct{ jrt.Object; F_s__1280000084, F_iter__1280000083 any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A struct{ jrt.Object; F_b__1280000086 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A struct{ jrt.Object; F_s__1280000100, F_iter__1280000099 any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A struct{ jrt.Object; F_b__1280000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_175, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A struct{ jrt.Object; F_s__1280000110, F_iter__1280000109 any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_176, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A struct{ jrt.Object; F_b__1280000112 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_177, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A struct{ jrt.Object; F_s__1280000130, F_iter__1280000129 any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_class)) }; return v }



type A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A struct{ jrt.Object; F_b__1280000132 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_fn_class *jrt.Class

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_init jrt.ClassInit

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_Init() { if !A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_init.Done() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_init.Run(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_clinit) } }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_clinit() { A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_class }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A); return ok }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_Cast(x any) *A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_class)) }; return v }



type A_arbace_a2g_edge_eval1280000004_A struct{ jrt.Object }

func A_arbace_a2g_edge_eval1280000004_A_New() *A_arbace_a2g_edge_eval1280000004_A { t := &A_arbace_a2g_edge_eval1280000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_edge_eval1280000004_A) Ctor() {}

func (t *A_arbace_a2g_edge_eval1280000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_eval1280000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_eval1280000004_A_class }

func (t *A_arbace_a2g_edge_eval1280000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_eval1280000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_eval1280000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_eval1280000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_eval1280000004_A); return ok }

func A_arbace_a2g_edge_eval1280000004_A_Cast(x any) *A_arbace_a2g_edge_eval1280000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_eval1280000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_eval1280000004_A_class)) }; return v }



type A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_fn_class *jrt.Class

var A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_init jrt.ClassInit

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_Init() { if !A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_init.Done() { A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_init.Run(A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_clinit) } }

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_clinit() { A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_class }

func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A); return ok }

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_Cast(x any) *A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_class)) }; return v }



type A_arbace_a2g_edge_eval1280000008_A struct{ jrt.Object }

func A_arbace_a2g_edge_eval1280000008_A_New() *A_arbace_a2g_edge_eval1280000008_A { t := &A_arbace_a2g_edge_eval1280000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_edge_eval1280000008_A) Ctor() {}

func (t *A_arbace_a2g_edge_eval1280000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_eval1280000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_eval1280000008_A_class }

func (t *A_arbace_a2g_edge_eval1280000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_eval1280000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_eval1280000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_eval1280000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_eval1280000008_A); return ok }

func A_arbace_a2g_edge_eval1280000008_A_Cast(x any) *A_arbace_a2g_edge_eval1280000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_eval1280000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_eval1280000008_A_class)) }; return v }



type A_arbace_a2g_edge_eval1280000008_fn__1280000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_fn_class *jrt.Class

var A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_init jrt.ClassInit

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_Init() { if !A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_init.Done() { A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_init.Run(A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_clinit) } }

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_clinit() { A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_class }

func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_eval1280000008_fn__1280000009_A); return ok }

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_Cast(x any) *A_arbace_a2g_edge_eval1280000008_fn__1280000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_eval1280000008_fn__1280000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_class)) }; return v }



type A_arbace_a2g_edge_fn__1280000042_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_fn__1280000042_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_fn__1280000042_A_fn_class *jrt.Class

var A_arbace_a2g_edge_fn__1280000042_A_init jrt.ClassInit

func A_arbace_a2g_edge_fn__1280000042_A_Init() { if !A_arbace_a2g_edge_fn__1280000042_A_init.Done() { A_arbace_a2g_edge_fn__1280000042_A_init.Run(A_arbace_a2g_edge_fn__1280000042_A_clinit) } }

func A_arbace_a2g_edge_fn__1280000042_A_clinit() { A_arbace_a2g_edge_fn__1280000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_183, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_fn__1280000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_fn__1280000042_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_fn__1280000042_A_class }

func (t *A_arbace_a2g_edge_fn__1280000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_fn__1280000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_fn__1280000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_fn__1280000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_fn__1280000042_A); return ok }

func A_arbace_a2g_edge_fn__1280000042_A_Cast(x any) *A_arbace_a2g_edge_fn__1280000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_fn__1280000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_fn__1280000042_A_class)) }; return v }



type A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_fn_class *jrt.Class

var A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_init jrt.ClassInit

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_Init() { if !A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_init.Done() { A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_init.Run(A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_clinit) } }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_clinit() { A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_189, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_class }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A); return ok }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_Cast(x any) *A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_class)) }; return v }



type A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_fn_class *jrt.Class

var A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_init jrt.ClassInit

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_Init() { if !A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_init.Done() { A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_init.Run(A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_clinit) } }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_clinit() { A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_190, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_class }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A); return ok }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_Cast(x any) *A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_class)) }; return v }



type A_arbace_a2g_edge_generics_value_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_generics_value_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_generics_value_A_fn_class *jrt.Class

var A_arbace_a2g_edge_generics_value_A_init jrt.ClassInit

func A_arbace_a2g_edge_generics_value_A_Init() { if !A_arbace_a2g_edge_generics_value_A_init.Done() { A_arbace_a2g_edge_generics_value_A_init.Run(A_arbace_a2g_edge_generics_value_A_clinit) } }

func A_arbace_a2g_edge_generics_value_A_clinit() { A_arbace_a2g_edge_generics_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_generics_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_generics_value_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_generics_value_A_class }

func (t *A_arbace_a2g_edge_generics_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_generics_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_generics_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_generics_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_generics_value_A); return ok }

func A_arbace_a2g_edge_generics_value_A_Cast(x any) *A_arbace_a2g_edge_generics_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_generics_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_generics_value_A_class)) }; return v }



type A_arbace_a2g_edge_generics_value_fn__1280000207_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_generics_value_fn__1280000207_A_fn_class *jrt.Class

var A_arbace_a2g_edge_generics_value_fn__1280000207_A_init jrt.ClassInit

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_Init() { if !A_arbace_a2g_edge_generics_value_fn__1280000207_A_init.Done() { A_arbace_a2g_edge_generics_value_fn__1280000207_A_init.Run(A_arbace_a2g_edge_generics_value_fn__1280000207_A_clinit) } }

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_clinit() { A_arbace_a2g_edge_generics_value_fn__1280000207_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_generics_value_fn__1280000207_A_class }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_generics_value_fn__1280000207_A); return ok }

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_Cast(x any) *A_arbace_a2g_edge_generics_value_fn__1280000207_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_generics_value_fn__1280000207_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_generics_value_fn__1280000207_A_class)) }; return v }



type A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_fn_class *jrt.Class

var A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_init jrt.ClassInit

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_Init() { if !A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_init.Done() { A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_init.Run(A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_clinit) } }

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_clinit() { A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_class }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A); return ok }

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_Cast(x any) *A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_class)) }; return v }



type A_arbace_a2g_edge_info_data_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_data_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_data_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_data_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_data_A_Init() { if !A_arbace_a2g_edge_info_data_A_init.Done() { A_arbace_a2g_edge_info_data_A_init.Run(A_arbace_a2g_edge_info_data_A_clinit) } }

func A_arbace_a2g_edge_info_data_A_clinit() { A_arbace_a2g_edge_info_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_data_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_data_A_class }

func (t *A_arbace_a2g_edge_info_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_data_A); return ok }

func A_arbace_a2g_edge_info_data_A_Cast(x any) *A_arbace_a2g_edge_info_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_data_A_class)) }; return v }



type A_arbace_a2g_edge_info_data_fn__1280000050_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_data_fn__1280000050_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_data_fn__1280000050_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_data_fn__1280000050_A_Init() { if !A_arbace_a2g_edge_info_data_fn__1280000050_A_init.Done() { A_arbace_a2g_edge_info_data_fn__1280000050_A_init.Run(A_arbace_a2g_edge_info_data_fn__1280000050_A_clinit) } }

func A_arbace_a2g_edge_info_data_fn__1280000050_A_clinit() { A_arbace_a2g_edge_info_data_fn__1280000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_data_fn__1280000050_A_class }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_data_fn__1280000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000050_A); return ok }

func A_arbace_a2g_edge_info_data_fn__1280000050_A_Cast(x any) *A_arbace_a2g_edge_info_data_fn__1280000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_data_fn__1280000050_A_class)) }; return v }



type A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_Init() { if !A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_init.Done() { A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_init.Run(A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_clinit) } }

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_clinit() { A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_class }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A); return ok }

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_Cast(x any) *A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_class)) }; return v }



type A_arbace_a2g_edge_info_data_fn__1280000055_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_data_fn__1280000055_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_data_fn__1280000055_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_data_fn__1280000055_A_Init() { if !A_arbace_a2g_edge_info_data_fn__1280000055_A_init.Done() { A_arbace_a2g_edge_info_data_fn__1280000055_A_init.Run(A_arbace_a2g_edge_info_data_fn__1280000055_A_clinit) } }

func A_arbace_a2g_edge_info_data_fn__1280000055_A_clinit() { A_arbace_a2g_edge_info_data_fn__1280000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_data_fn__1280000055_A_class }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_data_fn__1280000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000055_A); return ok }

func A_arbace_a2g_edge_info_data_fn__1280000055_A_Cast(x any) *A_arbace_a2g_edge_info_data_fn__1280000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_data_fn__1280000055_A_class)) }; return v }



type A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_Init() { if !A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_init.Done() { A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_init.Run(A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_clinit) } }

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_clinit() { A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_class }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A); return ok }

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_Cast(x any) *A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_value_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_A_Init() { if !A_arbace_a2g_edge_info_value_A_init.Done() { A_arbace_a2g_edge_info_value_A_init.Run(A_arbace_a2g_edge_info_value_A_clinit) } }

func A_arbace_a2g_edge_info_value_A_clinit() { A_arbace_a2g_edge_info_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_A_class }

func (t *A_arbace_a2g_edge_info_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_A); return ok }

func A_arbace_a2g_edge_info_value_A_Cast(x any) *A_arbace_a2g_edge_info_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000188_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_fn__1280000188_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000188_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000188_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000188_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000188_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000188_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000188_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000188_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000188_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000188_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000188_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000188_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000188_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000188_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000188_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000192_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_fn__1280000192_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000192_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000192_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000192_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000192_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000192_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000192_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000192_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000192_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000192_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000192_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A struct{ jrt.Object; F_a any }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_class)) }; return v }



type A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A struct{ jrt.Object; F_x any }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_fn_class *jrt.Class

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_init jrt.ClassInit

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_Init() { if !A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_init.Done() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_init.Run(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_clinit) } }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_clinit() { A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_class }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A); return ok }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_Cast(x any) *A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_class)) }; return v }



type A_arbace_a2g_edge_jvm_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_jvm_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_edge_jvm_A_fn_class *jrt.Class

var A_arbace_a2g_edge_jvm_A_init jrt.ClassInit

func A_arbace_a2g_edge_jvm_A_Init() { if !A_arbace_a2g_edge_jvm_A_init.Done() { A_arbace_a2g_edge_jvm_A_init.Run(A_arbace_a2g_edge_jvm_A_clinit) } }

func A_arbace_a2g_edge_jvm_A_clinit() { A_arbace_a2g_edge_jvm_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_jvm_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_jvm_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_jvm_A_class }

func (t *A_arbace_a2g_edge_jvm_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_jvm_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_jvm_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_jvm_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_jvm_A); return ok }

func A_arbace_a2g_edge_jvm_A_Cast(x any) *A_arbace_a2g_edge_jvm_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_jvm_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_jvm_A_class)) }; return v }



type A_arbace_a2g_edge_jvm_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_jvm_QMARK__A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_edge_jvm_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_edge_jvm_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_edge_jvm_QMARK__A_Init() { if !A_arbace_a2g_edge_jvm_QMARK__A_init.Done() { A_arbace_a2g_edge_jvm_QMARK__A_init.Run(A_arbace_a2g_edge_jvm_QMARK__A_clinit) } }

func A_arbace_a2g_edge_jvm_QMARK__A_clinit() { A_arbace_a2g_edge_jvm_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_jvm_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_jvm_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_jvm_QMARK__A_class }

func (t *A_arbace_a2g_edge_jvm_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_jvm_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_jvm_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_jvm_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_jvm_QMARK__A); return ok }

func A_arbace_a2g_edge_jvm_QMARK__A_Cast(x any) *A_arbace_a2g_edge_jvm_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_jvm_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_jvm_QMARK__A_class)) }; return v }



type A_arbace_a2g_edge_merge_edges_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_merge_edges_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_merge_edges_A_fn_class *jrt.Class

var A_arbace_a2g_edge_merge_edges_A_init jrt.ClassInit

func A_arbace_a2g_edge_merge_edges_A_Init() { if !A_arbace_a2g_edge_merge_edges_A_init.Done() { A_arbace_a2g_edge_merge_edges_A_init.Run(A_arbace_a2g_edge_merge_edges_A_clinit) } }

func A_arbace_a2g_edge_merge_edges_A_clinit() { A_arbace_a2g_edge_merge_edges_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_merge_edges_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_merge_edges_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_merge_edges_A_class }

func (t *A_arbace_a2g_edge_merge_edges_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_merge_edges_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_merge_edges_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_merge_edges_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_merge_edges_A); return ok }

func A_arbace_a2g_edge_merge_edges_A_Cast(x any) *A_arbace_a2g_edge_merge_edges_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_merge_edges_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_merge_edges_A_class)) }; return v }



type A_arbace_a2g_edge_merge_edges_fn__1280000169_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_merge_edges_fn__1280000169_A_fn_class *jrt.Class

var A_arbace_a2g_edge_merge_edges_fn__1280000169_A_init jrt.ClassInit

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_Init() { if !A_arbace_a2g_edge_merge_edges_fn__1280000169_A_init.Done() { A_arbace_a2g_edge_merge_edges_fn__1280000169_A_init.Run(A_arbace_a2g_edge_merge_edges_fn__1280000169_A_clinit) } }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_clinit() { A_arbace_a2g_edge_merge_edges_fn__1280000169_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_merge_edges_fn__1280000169_A_class }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_merge_edges_fn__1280000169_A); return ok }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_Cast(x any) *A_arbace_a2g_edge_merge_edges_fn__1280000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_merge_edges_fn__1280000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_merge_edges_fn__1280000169_A_class)) }; return v }



type A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_fn_class *jrt.Class

var A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_init jrt.ClassInit

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_Init() { if !A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_init.Done() { A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_init.Run(A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_clinit) } }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_clinit() { A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_class }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A); return ok }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_Cast(x any) *A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_class)) }; return v }



type A_arbace_a2g_edge_method_key_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_method_key_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_method_key_A_fn_class *jrt.Class

var A_arbace_a2g_edge_method_key_A_init jrt.ClassInit

func A_arbace_a2g_edge_method_key_A_Init() { if !A_arbace_a2g_edge_method_key_A_init.Done() { A_arbace_a2g_edge_method_key_A_init.Run(A_arbace_a2g_edge_method_key_A_clinit) } }

func A_arbace_a2g_edge_method_key_A_clinit() { A_arbace_a2g_edge_method_key_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_method_key_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_method_key_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_method_key_A_class }

func (t *A_arbace_a2g_edge_method_key_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_method_key_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_method_key_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_method_key_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_method_key_A); return ok }

func A_arbace_a2g_edge_method_key_A_Cast(x any) *A_arbace_a2g_edge_method_key_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_method_key_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_method_key_A_class)) }; return v }



type A_arbace_a2g_edge_pr_data_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_pr_data_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_pr_data_A_fn_class *jrt.Class

var A_arbace_a2g_edge_pr_data_A_init jrt.ClassInit

func A_arbace_a2g_edge_pr_data_A_Init() { if !A_arbace_a2g_edge_pr_data_A_init.Done() { A_arbace_a2g_edge_pr_data_A_init.Run(A_arbace_a2g_edge_pr_data_A_clinit) } }

func A_arbace_a2g_edge_pr_data_A_clinit() { A_arbace_a2g_edge_pr_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_pr_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_pr_data_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_pr_data_A_class }

func (t *A_arbace_a2g_edge_pr_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_pr_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_pr_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_pr_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_pr_data_A); return ok }

func A_arbace_a2g_edge_pr_data_A_Cast(x any) *A_arbace_a2g_edge_pr_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_pr_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_pr_data_A_class)) }; return v }



type A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_fn_class *jrt.Class

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_init jrt.ClassInit

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_Init() { if !A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_init.Done() { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_init.Run(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_clinit) } }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_clinit() { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_class }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A); return ok }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_Cast(x any) *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_class)) }; return v }



type A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A struct{ jrt.Object; F_s__1280000017, F_iter__1280000016 any }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_fn_class *jrt.Class

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_init jrt.ClassInit

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_Init() { if !A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_init.Done() { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_init.Run(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_clinit) } }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_clinit() { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_class }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A); return ok }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_Cast(x any) *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_class)) }; return v }



type A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A struct{ jrt.Object; F_size__1927001038__auto__ int32; F_b__1280000019, F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_fn_class *jrt.Class

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_init jrt.ClassInit

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_Init() { if !A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_init.Done() { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_init.Run(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_clinit) } }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_clinit() { A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_class }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A); return ok }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_Cast(x any) *A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_class)) }; return v }



type A_arbace_a2g_edge_pr_double_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_pr_double_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_pr_double_A_fn_class *jrt.Class

var A_arbace_a2g_edge_pr_double_A_init jrt.ClassInit

func A_arbace_a2g_edge_pr_double_A_Init() { if !A_arbace_a2g_edge_pr_double_A_init.Done() { A_arbace_a2g_edge_pr_double_A_init.Run(A_arbace_a2g_edge_pr_double_A_clinit) } }

func A_arbace_a2g_edge_pr_double_A_clinit() { A_arbace_a2g_edge_pr_double_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_pr_double_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_pr_double_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_pr_double_A_class }

func (t *A_arbace_a2g_edge_pr_double_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_pr_double_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_pr_double_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_pr_double_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_pr_double_A); return ok }

func A_arbace_a2g_edge_pr_double_A_Cast(x any) *A_arbace_a2g_edge_pr_double_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_pr_double_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_pr_double_A_class)) }; return v }



type A_arbace_a2g_edge_pr_string_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_pr_string_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_pr_string_A_fn_class *jrt.Class

var A_arbace_a2g_edge_pr_string_A_init jrt.ClassInit

func A_arbace_a2g_edge_pr_string_A_Init() { if !A_arbace_a2g_edge_pr_string_A_init.Done() { A_arbace_a2g_edge_pr_string_A_init.Run(A_arbace_a2g_edge_pr_string_A_clinit) } }

func A_arbace_a2g_edge_pr_string_A_clinit() { A_arbace_a2g_edge_pr_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_229, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_pr_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_pr_string_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_pr_string_A_class }

func (t *A_arbace_a2g_edge_pr_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_pr_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_pr_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_pr_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_pr_string_A); return ok }

func A_arbace_a2g_edge_pr_string_A_Cast(x any) *A_arbace_a2g_edge_pr_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_pr_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_pr_string_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_read_edge_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_read_edge_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_A_Init() { if !A_arbace_a2g_edge_read_edge_A_init.Done() { A_arbace_a2g_edge_read_edge_A_init.Run(A_arbace_a2g_edge_read_edge_A_clinit) } }

func A_arbace_a2g_edge_read_edge_A_clinit() { A_arbace_a2g_edge_read_edge_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_A_class }

func (t *A_arbace_a2g_edge_read_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_A); return ok }

func A_arbace_a2g_edge_read_edge_A_Cast(x any) *A_arbace_a2g_edge_read_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_fn__1280000220_A struct{ jrt.Object; F_f any }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_read_edge_fn__1280000220_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_fn__1280000220_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_Init() { if !A_arbace_a2g_edge_read_edge_fn__1280000220_A_init.Done() { A_arbace_a2g_edge_read_edge_fn__1280000220_A_init.Run(A_arbace_a2g_edge_read_edge_fn__1280000220_A_clinit) } }

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_clinit() { A_arbace_a2g_edge_read_edge_fn__1280000220_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_fn__1280000220_A_class }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000220_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000220_A); return ok }

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_Cast(x any) *A_arbace_a2g_edge_read_edge_fn__1280000220_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000220_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_fn__1280000220_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_fn__1280000222_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_read_edge_fn__1280000222_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_fn__1280000222_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_Init() { if !A_arbace_a2g_edge_read_edge_fn__1280000222_A_init.Done() { A_arbace_a2g_edge_read_edge_fn__1280000222_A_init.Run(A_arbace_a2g_edge_read_edge_fn__1280000222_A_clinit) } }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_clinit() { A_arbace_a2g_edge_read_edge_fn__1280000222_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_fn__1280000222_A_class }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_A); return ok }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_Cast(x any) *A_arbace_a2g_edge_read_edge_fn__1280000222_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_fn__1280000222_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_Init() { if !A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_init.Done() { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_init.Run(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_clinit) } }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_clinit() { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_class }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A); return ok }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_Cast(x any) *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A struct{ jrt.Object; F_s__1280000224, F_iter__1280000223 any }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_Init() { if !A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_init.Done() { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_init.Run(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_clinit) } }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_clinit() { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_class }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A); return ok }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_Cast(x any) *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A struct{ jrt.Object; F_b__1280000226 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_Init() { if !A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_init.Done() { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_init.Run(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_clinit) } }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_clinit() { A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_class }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A); return ok }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_Cast(x any) *A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_data_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_read_edge_data_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_read_edge_data_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_data_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_data_A_Init() { if !A_arbace_a2g_edge_read_edge_data_A_init.Done() { A_arbace_a2g_edge_read_edge_data_A_init.Run(A_arbace_a2g_edge_read_edge_data_A_clinit) } }

func A_arbace_a2g_edge_read_edge_data_A_clinit() { A_arbace_a2g_edge_read_edge_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_data_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_data_A_class }

func (t *A_arbace_a2g_edge_read_edge_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_data_A); return ok }

func A_arbace_a2g_edge_read_edge_data_A_Cast(x any) *A_arbace_a2g_edge_read_edge_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_data_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_data_fn__1280000243_A struct{ jrt.Object; F_f any }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_Init() { if !A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_init.Done() { A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_init.Run(A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_clinit) } }

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_clinit() { A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_class }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000243_A); return ok }

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_Cast(x any) *A_arbace_a2g_edge_read_edge_data_fn__1280000243_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000243_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_data_fn__1280000245_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_Init() { if !A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_init.Done() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_init.Run(A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_clinit) } }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_clinit() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_class }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_A); return ok }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_Cast(x any) *A_arbace_a2g_edge_read_edge_data_fn__1280000245_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_Init() { if !A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_init.Done() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_init.Run(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_clinit) } }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_clinit() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_class }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A); return ok }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_Cast(x any) *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A struct{ jrt.Object; F_s__1280000247, F_iter__1280000246 any }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_Init() { if !A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_init.Done() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_init.Run(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_clinit) } }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_clinit() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_244, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_class }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A); return ok }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_Cast(x any) *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_class)) }; return v }



type A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A struct{ jrt.Object; F_b__1280000249 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_fn_class *jrt.Class

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_init jrt.ClassInit

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_Init() { if !A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_init.Done() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_init.Run(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_clinit) } }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_clinit() { A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_class }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A); return ok }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_Cast(x any) *A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_class)) }; return v }



type A_arbace_a2g_edge_recorded_edge_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_recorded_edge_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_recorded_edge_A_fn_class *jrt.Class

var A_arbace_a2g_edge_recorded_edge_A_init jrt.ClassInit

func A_arbace_a2g_edge_recorded_edge_A_Init() { if !A_arbace_a2g_edge_recorded_edge_A_init.Done() { A_arbace_a2g_edge_recorded_edge_A_init.Run(A_arbace_a2g_edge_recorded_edge_A_clinit) } }

func A_arbace_a2g_edge_recorded_edge_A_clinit() { A_arbace_a2g_edge_recorded_edge_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_recorded_edge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_recorded_edge_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_recorded_edge_A_class }

func (t *A_arbace_a2g_edge_recorded_edge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_recorded_edge_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_recorded_edge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_recorded_edge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_recorded_edge_A); return ok }

func A_arbace_a2g_edge_recorded_edge_A_Cast(x any) *A_arbace_a2g_edge_recorded_edge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_recorded_edge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_recorded_edge_A_class)) }; return v }



type A_arbace_a2g_edge_recorded_edge_fn__1280000148_A struct{ jrt.Object; F_env_rec any }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_fn_class *jrt.Class

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_init jrt.ClassInit

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_Init() { if !A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_init.Done() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_init.Run(A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_clinit) } }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_clinit() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_247, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_class }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_A); return ok }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_Cast(x any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_class)) }; return v }



type A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_fn_class *jrt.Class

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_init jrt.ClassInit

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_Init() { if !A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_init.Done() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_init.Run(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_clinit) } }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_clinit() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_248, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_class }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A); return ok }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_Cast(x any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_class)) }; return v }



type A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A struct{ jrt.Object; F_s__1280000150, F_iter__1280000149 any }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_fn_class *jrt.Class

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_init jrt.ClassInit

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_Init() { if !A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_init.Done() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_init.Run(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_clinit) } }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_clinit() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_class }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A); return ok }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_Cast(x any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_class)) }; return v }



type A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A struct{ jrt.Object; F_b__1280000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_fn_class *jrt.Class

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_init jrt.ClassInit

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_Init() { if !A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_init.Done() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_init.Run(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_clinit) } }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_clinit() { A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_class }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A); return ok }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_Cast(x any) *A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_class)) }; return v }



type A_arbace_a2g_edge_write_edge_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_edge_write_edge_BANG__A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_edge_write_edge_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_edge_write_edge_BANG__A_init jrt.ClassInit

func A_arbace_a2g_edge_write_edge_BANG__A_Init() { if !A_arbace_a2g_edge_write_edge_BANG__A_init.Done() { A_arbace_a2g_edge_write_edge_BANG__A_init.Run(A_arbace_a2g_edge_write_edge_BANG__A_clinit) } }

func A_arbace_a2g_edge_write_edge_BANG__A_clinit() { A_arbace_a2g_edge_write_edge_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_edge_write_edge_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge_write_edge_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge_write_edge_BANG__A_class }

func (t *A_arbace_a2g_edge_write_edge_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge_write_edge_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge_write_edge_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge_write_edge_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge_write_edge_BANG__A); return ok }

func A_arbace_a2g_edge_write_edge_BANG__A_Cast(x any) *A_arbace_a2g_edge_write_edge_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge_write_edge_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge_write_edge_BANG__A_class)) }; return v }
