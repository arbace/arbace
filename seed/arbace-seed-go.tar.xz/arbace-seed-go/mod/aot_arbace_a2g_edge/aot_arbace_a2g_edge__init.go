//line aot_arbace_a2g_edge__init.ae:1
package aot_arbace_a2g_edge

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_edge__init_A_Unit0__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_edge__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_edge__init_A_const_1) }
//line :1:1
func A_arbace_a2g_edge__init_A_Unit1__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_edge__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_edge__init_A_Unit2__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_Init(); tmp2 = A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_edge__init_A_Unit3__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_edge__init_A_const_1)).Equals_O__Z(A_arbace_a2g_edge__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_Init(); tmp2 = A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_edge__init_A_Load__O() any { A_arbace_a2g_edge__init_A_Init(); A_arbace_a2g_edge__init_A_Unit0__O(); A_arbace_a2g_edge__init_A_Unit1__O(); A_arbace_a2g_edge__init_A_Unit2__O(); A_arbace_a2g_edge__init_A_Unit3__O(); A_arbace_a2g_edge__init_A_Unit4__O(); A_arbace_a2g_edge__init_A_Unit5__O(); A_arbace_a2g_edge__init_A_Unit6__O(); A_arbace_a2g_edge__init_A_Unit7__O(); A_arbace_a2g_edge__init_A_Unit8__O(); A_arbace_a2g_edge__init_A_Unit9__O(); A_arbace_a2g_edge__init_A_Unit10__O(); A_arbace_a2g_edge__init_A_Unit11__O(); A_arbace_a2g_edge__init_A_Unit12__O(); A_arbace_a2g_edge__init_A_Unit13__O(); A_arbace_a2g_edge__init_A_Unit14__O(); A_arbace_a2g_edge__init_A_Unit15__O(); A_arbace_a2g_edge__init_A_Unit16__O(); A_arbace_a2g_edge__init_A_Unit17__O(); A_arbace_a2g_edge__init_A_Unit18__O(); A_arbace_a2g_edge__init_A_Unit19__O(); A_arbace_a2g_edge__init_A_Unit20__O(); A_arbace_a2g_edge__init_A_Unit21__O(); A_arbace_a2g_edge__init_A_Unit22__O(); A_arbace_a2g_edge__init_A_Unit23__O(); A_arbace_a2g_edge__init_A_Unit24__O(); A_arbace_a2g_edge__init_A_Unit25__O(); A_arbace_a2g_edge__init_A_Unit26__O(); A_arbace_a2g_edge__init_A_Unit27__O(); A_arbace_a2g_edge__init_A_Unit28__O(); A_arbace_a2g_edge__init_A_Unit29__O(); A_arbace_a2g_edge__init_A_Unit30__O(); return nil }













func A_arbace_a2g_edge__init_A_Unit4__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_5)); return A_arbace_a2g_edge__init_A_const_4.Ref() }
//line :19:1
func A_arbace_a2g_edge__init_A_Unit5__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_7)); return A_arbace_a2g_edge__init_A_const_6.Ref() }

func A_arbace_a2g_edge__init_A_Unit6__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); jrt.NN(A_arbace_a2g_edge__init_A_const_8).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_8; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_9)); return jrt.NN(A_arbace_a2g_edge__init_A_const_8).SetDynamic_Z__Var(true).Ref() }



func A_arbace_a2g_edge__init_A_Unit7__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); jrt.NN(A_arbace_a2g_edge__init_A_const_10).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_10; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_11)); return jrt.NN(A_arbace_a2g_edge__init_A_const_10).SetDynamic_Z__Var(true).Ref() }



func A_arbace_a2g_edge__init_A_Unit8__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_12; var tmp2 any = A_arbace_a2g_edge_jvm_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_jvm_A_Init(); tmp3 = A_arbace_a2g_edge_jvm_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_13)); return A_arbace_a2g_edge__init_A_const_12.Ref() }









func A_arbace_a2g_edge__init_A_Unit9__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_14; var tmp2 any = A_arbace_a2g_edge_jvm_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_jvm_QMARK__A_Init(); tmp3 = A_arbace_a2g_edge_jvm_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_15)); return A_arbace_a2g_edge__init_A_const_14.Ref() }












func A_arbace_a2g_edge__init_A_Unit10__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_16; var tmp2 any = A_arbace_a2g_edge_pr_string_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_pr_string_A_Init(); tmp3 = A_arbace_a2g_edge_pr_string_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_17)); return A_arbace_a2g_edge__init_A_const_16.Ref() }









func A_arbace_a2g_edge__init_A_Unit11__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_18; var tmp2 any = A_arbace_a2g_edge_pr_double_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_pr_double_A_Init(); tmp3 = A_arbace_a2g_edge_pr_double_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_19)); return A_arbace_a2g_edge__init_A_const_18.Ref() }





func A_arbace_a2g_edge__init_A_Unit12__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_20; var tmp2 any = A_arbace_a2g_edge_pr_data_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_pr_data_A_Init(); tmp3 = A_arbace_a2g_edge_pr_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_21)); return A_arbace_a2g_edge__init_A_const_20.Ref() }
















func A_arbace_a2g_edge__init_A_Unit13__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_22; var tmp2 any = A_arbace_a2g_edge_const_data_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_const_data_A_Init(); tmp3 = A_arbace_a2g_edge_const_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_23)); return A_arbace_a2g_edge__init_A_const_22.Ref() }




func A_arbace_a2g_edge__init_A_Unit14__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_24; var tmp2 any = A_arbace_a2g_edge_ann_data_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_ann_data_A_Init(); tmp3 = A_arbace_a2g_edge_ann_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_25)); return A_arbace_a2g_edge__init_A_const_24.Ref() }








func A_arbace_a2g_edge__init_A_Unit15__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_26; var tmp2 any = A_arbace_a2g_edge_fn__1280000042_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_fn__1280000042_A_Init(); tmp3 = A_arbace_a2g_edge_fn__1280000042_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_27)); return A_arbace_a2g_edge__init_A_const_26.Ref() }















func A_arbace_a2g_edge__init_A_Unit16__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_28; var tmp2 any = A_arbace_a2g_edge_method_key_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_method_key_A_Init(); tmp3 = A_arbace_a2g_edge_method_key_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_29)); return A_arbace_a2g_edge__init_A_const_28.Ref() }






func A_arbace_a2g_edge__init_A_Unit17__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_30; var tmp2 any = A_arbace_a2g_edge_info_data_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_info_data_A_Init(); tmp3 = A_arbace_a2g_edge_info_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_31)); return A_arbace_a2g_edge__init_A_const_30.Ref() }




















func A_arbace_a2g_edge__init_A_Unit18__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(143, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_32; var tmp2 any = A_arbace_a2g_edge_class_entry_text_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_class_entry_text_A_Init(); tmp3 = A_arbace_a2g_edge_class_entry_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_33)); return A_arbace_a2g_edge__init_A_const_32.Ref() }

















func A_arbace_a2g_edge__init_A_Unit19__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_34; var tmp2 any = A_arbace_a2g_edge_edge_text_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_edge_text_A_Init(); tmp3 = A_arbace_a2g_edge_edge_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_35)); return A_arbace_a2g_edge__init_A_const_34.Ref() }















func A_arbace_a2g_edge__init_A_Unit20__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(177, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_36; var tmp2 any = A_arbace_a2g_edge_recorded_edge_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_recorded_edge_A_Init(); tmp3 = A_arbace_a2g_edge_recorded_edge_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_37)); return A_arbace_a2g_edge__init_A_const_36.Ref() }










func A_arbace_a2g_edge__init_A_Unit21__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(188, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_38; var tmp2 any = A_arbace_a2g_edge_merge_edges_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_merge_edges_A_Init(); tmp3 = A_arbace_a2g_edge_merge_edges_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_39)); return A_arbace_a2g_edge__init_A_const_38.Ref() }










func A_arbace_a2g_edge__init_A_Unit22__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(199, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_40; var tmp2 any = A_arbace_a2g_edge_coerce_const_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_coerce_const_A_Init(); tmp3 = A_arbace_a2g_edge_coerce_const_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_41)); return A_arbace_a2g_edge__init_A_const_40.Ref() }






func A_arbace_a2g_edge__init_A_Unit23__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(206, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_42; var tmp2 any = A_arbace_a2g_edge_ann_value_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_ann_value_A_Init(); tmp3 = A_arbace_a2g_edge_ann_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_43)); return A_arbace_a2g_edge__init_A_const_42.Ref() }






func A_arbace_a2g_edge__init_A_Unit24__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(213, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_4; var tmp2 any = A_arbace_a2g_edge_info_value_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_info_value_A_Init(); tmp3 = A_arbace_a2g_edge_info_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_44)); return A_arbace_a2g_edge__init_A_const_4.Ref() }






















func A_arbace_a2g_edge__init_A_Unit25__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(236, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_45; var tmp2 any = A_arbace_a2g_edge_generics_value_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_generics_value_A_Init(); tmp3 = A_arbace_a2g_edge_generics_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_46)); return A_arbace_a2g_edge__init_A_const_45.Ref() }



func A_arbace_a2g_edge__init_A_Unit26__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(240, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_6; var tmp2 any = A_arbace_a2g_edge_canonical_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_canonical_A_Init(); tmp3 = A_arbace_a2g_edge_canonical_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_47)); return A_arbace_a2g_edge__init_A_const_6.Ref() }









func A_arbace_a2g_edge__init_A_Unit27__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(250, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_48; var tmp2 any = A_arbace_a2g_edge_read_edge_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_read_edge_A_Init(); tmp3 = A_arbace_a2g_edge_read_edge_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_49)); return A_arbace_a2g_edge__init_A_const_48.Ref() }










func A_arbace_a2g_edge__init_A_Unit28__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(261, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_50; var tmp2 any = A_arbace_a2g_edge_read_edge_data_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_read_edge_data_A_Init(); tmp3 = A_arbace_a2g_edge_read_edge_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_51)); return A_arbace_a2g_edge__init_A_const_50.Ref() }









func A_arbace_a2g_edge__init_A_Unit29__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(271, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_52; var tmp2 any = A_arbace_a2g_edge_write_edge_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge_write_edge_BANG__A_Init(); tmp3 = A_arbace_a2g_edge_write_edge_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_53)); return A_arbace_a2g_edge__init_A_const_52.Ref() }



func A_arbace_a2g_edge__init_A_Unit30__O() any { A_arbace_a2g_edge__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.Var = A_arbace_a2g_edge__init_A_const_54; var tmp2 any = A_arbace_a2g_edge__main_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_edge__main_A_Init(); tmp3 = A_arbace_a2g_edge__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_a2g_edge__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_edge__init_A_const_55)); return A_arbace_a2g_edge__init_A_const_54.Ref() }



type A_arbace_a2g_edge__init_A struct{ jrt.Object }

var A_arbace_a2g_edge__init_A_const_0 *lang.Var

var A_arbace_a2g_edge__init_A_const_1 any

var A_arbace_a2g_edge__init_A_const_2 any

var A_arbace_a2g_edge__init_A_const_3 any

var A_arbace_a2g_edge__init_A_const_4 *lang.Var

var A_arbace_a2g_edge__init_A_const_5 any

var A_arbace_a2g_edge__init_A_const_6 *lang.Var

var A_arbace_a2g_edge__init_A_const_7 any

var A_arbace_a2g_edge__init_A_const_8 *lang.Var

var A_arbace_a2g_edge__init_A_const_9 any

var A_arbace_a2g_edge__init_A_const_10 *lang.Var

var A_arbace_a2g_edge__init_A_const_11 any

var A_arbace_a2g_edge__init_A_const_12 *lang.Var

var A_arbace_a2g_edge__init_A_const_13 any

var A_arbace_a2g_edge__init_A_const_14 *lang.Var

var A_arbace_a2g_edge__init_A_const_15 any

var A_arbace_a2g_edge__init_A_const_16 *lang.Var

var A_arbace_a2g_edge__init_A_const_17 any

var A_arbace_a2g_edge__init_A_const_18 *lang.Var

var A_arbace_a2g_edge__init_A_const_19 any

var A_arbace_a2g_edge__init_A_const_20 *lang.Var

var A_arbace_a2g_edge__init_A_const_21 any

var A_arbace_a2g_edge__init_A_const_22 *lang.Var

var A_arbace_a2g_edge__init_A_const_23 any

var A_arbace_a2g_edge__init_A_const_24 *lang.Var

var A_arbace_a2g_edge__init_A_const_25 any

var A_arbace_a2g_edge__init_A_const_26 *lang.Var

var A_arbace_a2g_edge__init_A_const_27 any

var A_arbace_a2g_edge__init_A_const_28 *lang.Var

var A_arbace_a2g_edge__init_A_const_29 any

var A_arbace_a2g_edge__init_A_const_30 *lang.Var

var A_arbace_a2g_edge__init_A_const_31 any

var A_arbace_a2g_edge__init_A_const_32 *lang.Var

var A_arbace_a2g_edge__init_A_const_33 any

var A_arbace_a2g_edge__init_A_const_34 *lang.Var

var A_arbace_a2g_edge__init_A_const_35 any

var A_arbace_a2g_edge__init_A_const_36 *lang.Var

var A_arbace_a2g_edge__init_A_const_37 any

var A_arbace_a2g_edge__init_A_const_38 *lang.Var

var A_arbace_a2g_edge__init_A_const_39 any

var A_arbace_a2g_edge__init_A_const_40 *lang.Var

var A_arbace_a2g_edge__init_A_const_41 any

var A_arbace_a2g_edge__init_A_const_42 *lang.Var

var A_arbace_a2g_edge__init_A_const_43 any

var A_arbace_a2g_edge__init_A_const_44 any

var A_arbace_a2g_edge__init_A_const_45 *lang.Var

var A_arbace_a2g_edge__init_A_const_46 any

var A_arbace_a2g_edge__init_A_const_47 any

var A_arbace_a2g_edge__init_A_const_48 *lang.Var

var A_arbace_a2g_edge__init_A_const_49 any

var A_arbace_a2g_edge__init_A_const_50 *lang.Var

var A_arbace_a2g_edge__init_A_const_51 any

var A_arbace_a2g_edge__init_A_const_52 *lang.Var

var A_arbace_a2g_edge__init_A_const_53 any

var A_arbace_a2g_edge__init_A_const_54 *lang.Var

var A_arbace_a2g_edge__init_A_const_55 any

var A_arbace_a2g_edge__init_A_init jrt.ClassInit

func A_arbace_a2g_edge__init_A_Init() { if !A_arbace_a2g_edge__init_A_init.Done() { A_arbace_a2g_edge__init_A_init.Run(A_arbace_a2g_edge__init_A_clinit) } }

func A_arbace_a2g_edge__init_A_clinit() { A_arbace_a2g_edge__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_252); A_arbace_a2g_edge__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_a2g_edge__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_a2g_edge__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_edge__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_15, Lit_124); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_253).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_edge__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_15, Lit_103); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_253).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_edge__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_15, Lit_19); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_edge__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_258)); A_arbace_a2g_edge__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_15, Lit_21); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_edge__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_259)); A_arbace_a2g_edge__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_15, Lit_260); A_arbace_a2g_edge__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_265, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_15, Lit_266); A_arbace_a2g_edge__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_15, Lit_33); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_edge__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_269)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_270).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_271).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_15, Lit_36); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_edge__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_272)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_270).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_273).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_15, Lit_47); A_arbace_a2g_edge__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_274, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(68).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_15, Lit_67); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_edge__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_275).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_276, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_15, Lit_68); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_edge__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_277, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_15, Lit_120); A_arbace_a2g_edge__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_278)); A_arbace_a2g_edge__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_15, Lit_121); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_a2g_edge__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_279).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_280, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_15, Lit_104); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_a2g_edge__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_281, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_15, Lit_100); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_a2g_edge__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_282).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(143).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_15, Lit_128); A_arbace_a2g_edge__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_284).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_286, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(161).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_15, Lit_287); A_arbace_a2g_edge__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_290, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(177).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_15, Lit_130); A_arbace_a2g_edge__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_291).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_292, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(188).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_15, Lit_111); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_a2g_edge__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_275).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(199).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_15, Lit_113); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_a2g_edge__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(206).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_a2g_edge__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_293, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(213).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_15, Lit_125); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_a2g_edge__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_294).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(236).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_a2g_edge__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_282).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_283).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_295, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(240).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_15, Lit_296); A_arbace_a2g_edge__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_297, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(250).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_15, Lit_131); A_arbace_a2g_edge__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_298, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(261).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_15, Lit_129); A_arbace_a2g_edge__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_285).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(271).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)); A_arbace_a2g_edge__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_15, Lit_299); A_arbace_a2g_edge__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_300).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_301).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_303, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), jrt.Integer_ValueOf_I__Integer(275).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_255).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), Lit_256)) }

func A_arbace_a2g_edge__init_A_New() *A_arbace_a2g_edge__init_A { A_arbace_a2g_edge__init_A_Init(); t := &A_arbace_a2g_edge__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_edge__init_A) Ctor() {}

func (t *A_arbace_a2g_edge__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_edge__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_edge__init_A_class }

func (t *A_arbace_a2g_edge__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_edge__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_edge__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_edge__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_edge__init_A); return ok }

func A_arbace_a2g_edge__init_A_Cast(x any) *A_arbace_a2g_edge__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_edge__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_edge__init_A_class)) }; return v }
