//line a2g_classes.ae:1
package aot_arbace_a2g_edge

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_edge_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_A_New()}; return nil }

var A_arbace_a2g_edge_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_edge_A_new}

var A_arbace_a2g_edge_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_A"})

func init() { i := A_arbace_a2g_edge_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_A_InstanceOf; i.Init = A_arbace_a2g_edge_A_Init; i.Table = A_arbace_a2g_edge_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_A_class, reflect.TypeFor[A_arbace_a2g_edge_A]()) }

func A_arbace_a2g_edge__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge__main_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge__main_A_New()}; return nil }

func A_arbace_a2g_edge__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge__main_A_fn_class)}; return nil }

var A_arbace_a2g_edge__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge__main_A_invoke, New: A_arbace_a2g_edge__main_A_new, Get: A_arbace_a2g_edge__main_A_get}

var A_arbace_a2g_edge__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "_main", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge__main_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge__main_A_class.Info(); i.IsInstance = A_arbace_a2g_edge__main_A_InstanceOf; i.Init = A_arbace_a2g_edge__main_A_Init; i.Table = A_arbace_a2g_edge__main_A_members; jrt.RegisterGoType(A_arbace_a2g_edge__main_A_class, reflect.TypeFor[A_arbace_a2g_edge__main_A]()) }

func A_arbace_a2g_edge_ann_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_ann_data_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_ann_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_ann_data_A_New()}; return nil }

func A_arbace_a2g_edge_ann_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_ann_data_A_fn_class)}; return nil }

var A_arbace_a2g_edge_ann_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_ann_data_A_invoke, New: A_arbace_a2g_edge_ann_data_A_new, Get: A_arbace_a2g_edge_ann_data_A_get}

var A_arbace_a2g_edge_ann_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$ann_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "ann_data", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_ann_data_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_ann_data_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_ann_data_A_InstanceOf; i.Init = A_arbace_a2g_edge_ann_data_A_Init; i.Table = A_arbace_a2g_edge_ann_data_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_ann_data_A_class, reflect.TypeFor[A_arbace_a2g_edge_ann_data_A]()) }

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_ann_data_fn__1280000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_ann_data_fn__1280000035_A_New()}; return nil }

func A_arbace_a2g_edge_ann_data_fn__1280000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_ann_data_fn__1280000035_A_fn_class)}; return nil }

var A_arbace_a2g_edge_ann_data_fn__1280000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_ann_data_fn__1280000035_A_invoke, New: A_arbace_a2g_edge_ann_data_fn__1280000035_A_new, Get: A_arbace_a2g_edge_ann_data_fn__1280000035_A_get}

var A_arbace_a2g_edge_ann_data_fn__1280000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$ann_data$fn__1280000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_ann_data_A_class, Simple: "fn__1280000035", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_ann_data_fn__1280000035_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_ann_data_fn__1280000035_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_ann_data_fn__1280000035_A_InstanceOf; i.Init = A_arbace_a2g_edge_ann_data_fn__1280000035_A_Init; i.Table = A_arbace_a2g_edge_ann_data_fn__1280000035_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_ann_data_fn__1280000035_A_class, reflect.TypeFor[A_arbace_a2g_edge_ann_data_fn__1280000035_A]()) }

func A_arbace_a2g_edge_ann_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_ann_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_ann_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_ann_value_A_New()}; return nil }

func A_arbace_a2g_edge_ann_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_ann_value_A_fn_class)}; return nil }

var A_arbace_a2g_edge_ann_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_ann_value_A_invoke, New: A_arbace_a2g_edge_ann_value_A_new, Get: A_arbace_a2g_edge_ann_value_A_get}

var A_arbace_a2g_edge_ann_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$ann_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "ann_value", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_ann_value_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_ann_value_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_ann_value_A_InstanceOf; i.Init = A_arbace_a2g_edge_ann_value_A_Init; i.Table = A_arbace_a2g_edge_ann_value_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_ann_value_A_class, reflect.TypeFor[A_arbace_a2g_edge_ann_value_A]()) }

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_ann_value_fn__1280000177_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_ann_value_fn__1280000177_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_ann_value_fn__1280000177_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_ann_value_fn__1280000177_A_fn_class)}; return nil }

var A_arbace_a2g_edge_ann_value_fn__1280000177_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_ann_value_fn__1280000177_A_invoke, New: A_arbace_a2g_edge_ann_value_fn__1280000177_A_new, Get: A_arbace_a2g_edge_ann_value_fn__1280000177_A_get}

var A_arbace_a2g_edge_ann_value_fn__1280000177_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$ann_value$fn__1280000177", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_ann_value_A_class, Simple: "fn__1280000177", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_ann_value_fn__1280000177_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_ann_value_fn__1280000177_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_ann_value_fn__1280000177_A_InstanceOf; i.Init = A_arbace_a2g_edge_ann_value_fn__1280000177_A_Init; i.Table = A_arbace_a2g_edge_ann_value_fn__1280000177_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_ann_value_fn__1280000177_A_class, reflect.TypeFor[A_arbace_a2g_edge_ann_value_fn__1280000177_A]()) }

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_ann_value_fn__1280000180_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_ann_value_fn__1280000180_A_New()}; return nil }

func A_arbace_a2g_edge_ann_value_fn__1280000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_ann_value_fn__1280000180_A_fn_class)}; return nil }

var A_arbace_a2g_edge_ann_value_fn__1280000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_ann_value_fn__1280000180_A_invoke, New: A_arbace_a2g_edge_ann_value_fn__1280000180_A_new, Get: A_arbace_a2g_edge_ann_value_fn__1280000180_A_get}

var A_arbace_a2g_edge_ann_value_fn__1280000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$ann_value$fn__1280000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_ann_value_A_class, Simple: "fn__1280000180", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_ann_value_fn__1280000180_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_ann_value_fn__1280000180_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_ann_value_fn__1280000180_A_InstanceOf; i.Init = A_arbace_a2g_edge_ann_value_fn__1280000180_A_Init; i.Table = A_arbace_a2g_edge_ann_value_fn__1280000180_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_ann_value_fn__1280000180_A_class, reflect.TypeFor[A_arbace_a2g_edge_ann_value_fn__1280000180_A]()) }

func A_arbace_a2g_edge_canonical_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_canonical_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_canonical_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_canonical_A_New()}; return nil }

func A_arbace_a2g_edge_canonical_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_canonical_A_fn_class)}; return nil }

var A_arbace_a2g_edge_canonical_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_canonical_A_invoke, New: A_arbace_a2g_edge_canonical_A_new, Get: A_arbace_a2g_edge_canonical_A_get}

var A_arbace_a2g_edge_canonical_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$canonical", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "canonical", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_canonical_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_canonical_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_canonical_A_InstanceOf; i.Init = A_arbace_a2g_edge_canonical_A_Init; i.Table = A_arbace_a2g_edge_canonical_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_canonical_A_class, reflect.TypeFor[A_arbace_a2g_edge_canonical_A]()) }

func A_arbace_a2g_edge_canonical_fn__1280000215_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_canonical_fn__1280000215_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_canonical_fn__1280000215_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_canonical_fn__1280000215_A_New()}; return nil }

func A_arbace_a2g_edge_canonical_fn__1280000215_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_canonical_fn__1280000215_A_fn_class)}; return nil }

var A_arbace_a2g_edge_canonical_fn__1280000215_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_canonical_fn__1280000215_A_invoke, New: A_arbace_a2g_edge_canonical_fn__1280000215_A_new, Get: A_arbace_a2g_edge_canonical_fn__1280000215_A_get}

var A_arbace_a2g_edge_canonical_fn__1280000215_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$canonical$fn__1280000215", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_canonical_A_class, Simple: "fn__1280000215", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_canonical_fn__1280000215_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_canonical_fn__1280000215_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_canonical_fn__1280000215_A_InstanceOf; i.Init = A_arbace_a2g_edge_canonical_fn__1280000215_A_Init; i.Table = A_arbace_a2g_edge_canonical_fn__1280000215_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_canonical_fn__1280000215_A_class, reflect.TypeFor[A_arbace_a2g_edge_canonical_fn__1280000215_A]()) }

func A_arbace_a2g_edge_canonical_fn__1280000217_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_canonical_fn__1280000217_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_canonical_fn__1280000217_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_canonical_fn__1280000217_A_New()}; return nil }

func A_arbace_a2g_edge_canonical_fn__1280000217_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_canonical_fn__1280000217_A_fn_class)}; return nil }

var A_arbace_a2g_edge_canonical_fn__1280000217_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_canonical_fn__1280000217_A_invoke, New: A_arbace_a2g_edge_canonical_fn__1280000217_A_new, Get: A_arbace_a2g_edge_canonical_fn__1280000217_A_get}

var A_arbace_a2g_edge_canonical_fn__1280000217_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$canonical$fn__1280000217", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_canonical_A_class, Simple: "fn__1280000217", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_canonical_fn__1280000217_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_canonical_fn__1280000217_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_canonical_fn__1280000217_A_InstanceOf; i.Init = A_arbace_a2g_edge_canonical_fn__1280000217_A_Init; i.Table = A_arbace_a2g_edge_canonical_fn__1280000217_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_canonical_fn__1280000217_A_class, reflect.TypeFor[A_arbace_a2g_edge_canonical_fn__1280000217_A]()) }

func A_arbace_a2g_edge_class_entry_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_class_entry_text_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_class_entry_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_class_entry_text_A_New()}; return nil }

func A_arbace_a2g_edge_class_entry_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_class_entry_text_A_fn_class)}; return nil }

var A_arbace_a2g_edge_class_entry_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_class_entry_text_A_invoke, New: A_arbace_a2g_edge_class_entry_text_A_new, Get: A_arbace_a2g_edge_class_entry_text_A_get}

var A_arbace_a2g_edge_class_entry_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$class_entry_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "class_entry_text", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_class_entry_text_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_class_entry_text_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_class_entry_text_A_InstanceOf; i.Init = A_arbace_a2g_edge_class_entry_text_A_Init; i.Table = A_arbace_a2g_edge_class_entry_text_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_class_entry_text_A_class, reflect.TypeFor[A_arbace_a2g_edge_class_entry_text_A]()) }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_New()}; return nil }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_fn_class)}; return nil }

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_invoke, New: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_new, Get: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_get}

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$class_entry_text$iter__1280000061__1280000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_class_entry_text_A_class, Simple: "iter__1280000061__1280000065", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_InstanceOf; i.Init = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_Init; i.Table = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_class, reflect.TypeFor[A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A]()) }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_fn_class)}; return nil }

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_invoke, New: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_new, Get: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_get}

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$class_entry_text$iter__1280000061__1280000065$fn__1280000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_A_class, Simple: "fn__1280000066", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_InstanceOf; i.Init = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_Init; i.Table = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_class, reflect.TypeFor[A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A]()) }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_fn_class)}; return nil }

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_invoke, New: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_new, Get: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_get}

var A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$class_entry_text$iter__1280000061__1280000065$fn__1280000066$fn__1280000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_A_class, Simple: "fn__1280000067", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_InstanceOf; i.Init = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_Init; i.Table = A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A_class, reflect.TypeFor[A_arbace_a2g_edge_class_entry_text_iter__1280000061__1280000065_fn__1280000066_fn__1280000067_A]()) }

func A_arbace_a2g_edge_coerce_const_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_coerce_const_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_coerce_const_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_coerce_const_A_New()}; return nil }

func A_arbace_a2g_edge_coerce_const_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_coerce_const_A_fn_class)}; return nil }

var A_arbace_a2g_edge_coerce_const_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_coerce_const_A_invoke, New: A_arbace_a2g_edge_coerce_const_A_new, Get: A_arbace_a2g_edge_coerce_const_A_get}

var A_arbace_a2g_edge_coerce_const_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$coerce_const", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "coerce_const", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_coerce_const_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_coerce_const_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_coerce_const_A_InstanceOf; i.Init = A_arbace_a2g_edge_coerce_const_A_Init; i.Table = A_arbace_a2g_edge_coerce_const_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_coerce_const_A_class, reflect.TypeFor[A_arbace_a2g_edge_coerce_const_A]()) }

func A_arbace_a2g_edge_const_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_const_data_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_const_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_const_data_A_New()}; return nil }

func A_arbace_a2g_edge_const_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_const_data_A_fn_class)}; return nil }

var A_arbace_a2g_edge_const_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_const_data_A_invoke, New: A_arbace_a2g_edge_const_data_A_new, Get: A_arbace_a2g_edge_const_data_A_get}

var A_arbace_a2g_edge_const_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$const_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "const_data", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_const_data_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_const_data_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_const_data_A_InstanceOf; i.Init = A_arbace_a2g_edge_const_data_A_Init; i.Table = A_arbace_a2g_edge_const_data_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_const_data_A_class, reflect.TypeFor[A_arbace_a2g_edge_const_data_A]()) }

func A_arbace_a2g_edge_edge_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_A_New()}; return nil }

func A_arbace_a2g_edge_edge_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_A_invoke, New: A_arbace_a2g_edge_edge_text_A_new, Get: A_arbace_a2g_edge_edge_text_A_get}

var A_arbace_a2g_edge_edge_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "edge_text", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_A_Init; i.Table = A_arbace_a2g_edge_edge_text_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_New()}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000083__1280000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_edge_text_A_class, Simple: "iter__1280000083__1280000087", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000083__1280000087$fn__1280000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_A_class, Simple: "fn__1280000088", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000083__1280000087$fn__1280000088$fn__1280000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_A_class, Simple: "fn__1280000089", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000083__1280000087_fn__1280000088_fn__1280000089_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_New()}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_edge_text_A_class, Simple: "iter__1280000099__1280000103", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_A_class, Simple: "fn__1280000104", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class, Simple: "fn__1280000105", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_New()}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105$iter__1280000109__1280000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_A_class, Simple: "iter__1280000109__1280000113", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105$iter__1280000109__1280000113$fn__1280000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_A_class, Simple: "fn__1280000114", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$fn__1280000105$iter__1280000109__1280000113$fn__1280000114$fn__1280000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_A_class, Simple: "fn__1280000115", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_fn__1280000105_iter__1280000109__1280000113_fn__1280000114_fn__1280000115_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_New()}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$iter__1280000129__1280000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_A_class, Simple: "iter__1280000129__1280000133", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$iter__1280000129__1280000133$fn__1280000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_A_class, Simple: "fn__1280000134", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A]()) }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_fn_class)}; return nil }

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_invoke, New: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_new, Get: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_get}

var A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$edge_text$iter__1280000099__1280000103$fn__1280000104$iter__1280000129__1280000133$fn__1280000134$fn__1280000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_A_class, Simple: "fn__1280000135", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_InstanceOf; i.Init = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_Init; i.Table = A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A_class, reflect.TypeFor[A_arbace_a2g_edge_edge_text_iter__1280000099__1280000103_fn__1280000104_iter__1280000129__1280000133_fn__1280000134_fn__1280000135_A]()) }

func A_arbace_a2g_edge_eval1280000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_eval1280000004_A_New()}; return nil }

var A_arbace_a2g_edge_eval1280000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_edge_eval1280000004_A_new}

var A_arbace_a2g_edge_eval1280000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$eval1280000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_edge_A_class, Simple: "eval1280000004", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_eval1280000004_A"})

func init() { i := A_arbace_a2g_edge_eval1280000004_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_eval1280000004_A_InstanceOf; i.Table = A_arbace_a2g_edge_eval1280000004_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_eval1280000004_A_class, reflect.TypeFor[A_arbace_a2g_edge_eval1280000004_A]()) }

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_New()}; return nil }

func A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_fn_class)}; return nil }

var A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_invoke, New: A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_new, Get: A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_get}

var A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$eval1280000004$loading__1927001464__auto____1280000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_eval1280000004_A_class, Simple: "loading__1927001464__auto____1280000005", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_InstanceOf; i.Init = A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_Init; i.Table = A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A_class, reflect.TypeFor[A_arbace_a2g_edge_eval1280000004_loading__1927001464__auto____1280000005_A]()) }

func A_arbace_a2g_edge_eval1280000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_eval1280000008_A_New()}; return nil }

var A_arbace_a2g_edge_eval1280000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_edge_eval1280000008_A_new}

var A_arbace_a2g_edge_eval1280000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$eval1280000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_edge_A_class, Simple: "eval1280000008", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_eval1280000008_A"})

func init() { i := A_arbace_a2g_edge_eval1280000008_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_eval1280000008_A_InstanceOf; i.Table = A_arbace_a2g_edge_eval1280000008_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_eval1280000008_A_class, reflect.TypeFor[A_arbace_a2g_edge_eval1280000008_A]()) }

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_eval1280000008_fn__1280000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_New()}; return nil }

func A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_fn_class)}; return nil }

var A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_invoke, New: A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_new, Get: A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_get}

var A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$eval1280000008$fn__1280000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_eval1280000008_A_class, Simple: "fn__1280000009", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_eval1280000008_fn__1280000009_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_InstanceOf; i.Init = A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_Init; i.Table = A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_eval1280000008_fn__1280000009_A_class, reflect.TypeFor[A_arbace_a2g_edge_eval1280000008_fn__1280000009_A]()) }

func A_arbace_a2g_edge_fn__1280000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_fn__1280000042_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_fn__1280000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_fn__1280000042_A_New()}; return nil }

func A_arbace_a2g_edge_fn__1280000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_fn__1280000042_A_fn_class)}; return nil }

var A_arbace_a2g_edge_fn__1280000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_fn__1280000042_A_invoke, New: A_arbace_a2g_edge_fn__1280000042_A_new, Get: A_arbace_a2g_edge_fn__1280000042_A_get}

var A_arbace_a2g_edge_fn__1280000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$fn__1280000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "fn__1280000042", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_fn__1280000042_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_fn__1280000042_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_fn__1280000042_A_InstanceOf; i.Init = A_arbace_a2g_edge_fn__1280000042_A_Init; i.Table = A_arbace_a2g_edge_fn__1280000042_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_fn__1280000042_A_class, reflect.TypeFor[A_arbace_a2g_edge_fn__1280000042_A]()) }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_New()}; return nil }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_fn_class)}; return nil }

var A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_invoke, New: A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_new, Get: A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_get}

var A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$fn__1280000042$fn__1280000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_fn__1280000042_A_class, Simple: "fn__1280000043", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_InstanceOf; i.Init = A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_Init; i.Table = A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A_class, reflect.TypeFor[A_arbace_a2g_edge_fn__1280000042_fn__1280000043_A]()) }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_New()}; return nil }

func A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_fn_class)}; return nil }

var A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_invoke, New: A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_new, Get: A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_get}

var A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$fn__1280000042$fn__1280000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_fn__1280000042_A_class, Simple: "fn__1280000045", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_InstanceOf; i.Init = A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_Init; i.Table = A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A_class, reflect.TypeFor[A_arbace_a2g_edge_fn__1280000042_fn__1280000045_A]()) }

func A_arbace_a2g_edge_generics_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_generics_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_generics_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_generics_value_A_New()}; return nil }

func A_arbace_a2g_edge_generics_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_generics_value_A_fn_class)}; return nil }

var A_arbace_a2g_edge_generics_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_generics_value_A_invoke, New: A_arbace_a2g_edge_generics_value_A_new, Get: A_arbace_a2g_edge_generics_value_A_get}

var A_arbace_a2g_edge_generics_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$generics_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "generics_value", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_generics_value_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_generics_value_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_generics_value_A_InstanceOf; i.Init = A_arbace_a2g_edge_generics_value_A_Init; i.Table = A_arbace_a2g_edge_generics_value_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_generics_value_A_class, reflect.TypeFor[A_arbace_a2g_edge_generics_value_A]()) }

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_generics_value_fn__1280000207_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_generics_value_fn__1280000207_A_New()}; return nil }

func A_arbace_a2g_edge_generics_value_fn__1280000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_generics_value_fn__1280000207_A_fn_class)}; return nil }

var A_arbace_a2g_edge_generics_value_fn__1280000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_generics_value_fn__1280000207_A_invoke, New: A_arbace_a2g_edge_generics_value_fn__1280000207_A_new, Get: A_arbace_a2g_edge_generics_value_fn__1280000207_A_get}

var A_arbace_a2g_edge_generics_value_fn__1280000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$generics_value$fn__1280000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_generics_value_A_class, Simple: "fn__1280000207", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_generics_value_fn__1280000207_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_generics_value_fn__1280000207_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_generics_value_fn__1280000207_A_InstanceOf; i.Init = A_arbace_a2g_edge_generics_value_fn__1280000207_A_Init; i.Table = A_arbace_a2g_edge_generics_value_fn__1280000207_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_generics_value_fn__1280000207_A_class, reflect.TypeFor[A_arbace_a2g_edge_generics_value_fn__1280000207_A]()) }

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_New()}; return nil }

func A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_fn_class)}; return nil }

var A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_invoke, New: A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_new, Get: A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_get}

var A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$generics_value$fn__1280000207$fn__1280000208", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_generics_value_fn__1280000207_A_class, Simple: "fn__1280000208", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_InstanceOf; i.Init = A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_Init; i.Table = A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A_class, reflect.TypeFor[A_arbace_a2g_edge_generics_value_fn__1280000207_fn__1280000208_A]()) }

func A_arbace_a2g_edge_info_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_data_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_data_A_New()}; return nil }

func A_arbace_a2g_edge_info_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_data_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_data_A_invoke, New: A_arbace_a2g_edge_info_data_A_new, Get: A_arbace_a2g_edge_info_data_A_get}

var A_arbace_a2g_edge_info_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "info_data", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_data_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_data_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_data_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_data_A_Init; i.Table = A_arbace_a2g_edge_info_data_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_data_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_data_A]()) }

func A_arbace_a2g_edge_info_data_fn__1280000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_data_fn__1280000050_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_data_fn__1280000050_A_New()}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_data_fn__1280000050_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_data_fn__1280000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_data_fn__1280000050_A_invoke, New: A_arbace_a2g_edge_info_data_fn__1280000050_A_new, Get: A_arbace_a2g_edge_info_data_fn__1280000050_A_get}

var A_arbace_a2g_edge_info_data_fn__1280000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_data$fn__1280000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_data_A_class, Simple: "fn__1280000050", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_data_fn__1280000050_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_data_fn__1280000050_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_data_fn__1280000050_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_data_fn__1280000050_A_Init; i.Table = A_arbace_a2g_edge_info_data_fn__1280000050_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_data_fn__1280000050_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_data_fn__1280000050_A]()) }

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_New()}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_invoke, New: A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_new, Get: A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_get}

var A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_data$fn__1280000050$fn__1280000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_data_fn__1280000050_A_class, Simple: "fn__1280000051", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_Init; i.Table = A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_data_fn__1280000050_fn__1280000051_A]()) }

func A_arbace_a2g_edge_info_data_fn__1280000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_data_fn__1280000055_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_data_fn__1280000055_A_New()}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_data_fn__1280000055_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_data_fn__1280000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_data_fn__1280000055_A_invoke, New: A_arbace_a2g_edge_info_data_fn__1280000055_A_new, Get: A_arbace_a2g_edge_info_data_fn__1280000055_A_get}

var A_arbace_a2g_edge_info_data_fn__1280000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_data$fn__1280000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_data_A_class, Simple: "fn__1280000055", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_data_fn__1280000055_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_data_fn__1280000055_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_data_fn__1280000055_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_data_fn__1280000055_A_Init; i.Table = A_arbace_a2g_edge_info_data_fn__1280000055_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_data_fn__1280000055_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_data_fn__1280000055_A]()) }

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_New()}; return nil }

func A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_invoke, New: A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_new, Get: A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_get}

var A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_data$fn__1280000055$fn__1280000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_data_fn__1280000055_A_class, Simple: "fn__1280000056", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_Init; i.Table = A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_data_fn__1280000055_fn__1280000056_A]()) }

func A_arbace_a2g_edge_info_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_A_New()}; return nil }

func A_arbace_a2g_edge_info_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_A_invoke, New: A_arbace_a2g_edge_info_value_A_new, Get: A_arbace_a2g_edge_info_value_A_get}

var A_arbace_a2g_edge_info_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "info_value", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_A_Init; i.Table = A_arbace_a2g_edge_info_value_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000188_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000188_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000188_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000188_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000188_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000188_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000188_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000188_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000188_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000188_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000188_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000188", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_value_A_class, Simple: "fn__1280000188", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000188_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000188_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000188_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000188_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000188_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000188_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000188_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000188$fn__1280000189", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_value_fn__1280000188_A_class, Simple: "fn__1280000189", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000188_fn__1280000189_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000192_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000192_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000192_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000192_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000192_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000192_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000192_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_value_A_class, Simple: "fn__1280000192", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000192_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000192_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000192_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000192_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000192_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000192_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000192_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_value_fn__1280000192_A_class, Simple: "fn__1280000193", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_New()}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000194", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class, Simple: "fn__1280000194", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000194_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000197", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class, Simple: "fn__1280000197", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000197_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_New()}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000199", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_A_class, Simple: "fn__1280000199", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A]()) }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_fn_class)}; return nil }

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_invoke, New: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_new, Get: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_get}

var A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$info_value$fn__1280000192$fn__1280000193$fn__1280000199$fn__1280000200", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_A_class, Simple: "fn__1280000200", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_InstanceOf; i.Init = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_Init; i.Table = A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A_class, reflect.TypeFor[A_arbace_a2g_edge_info_value_fn__1280000192_fn__1280000193_fn__1280000199_fn__1280000200_A]()) }

func A_arbace_a2g_edge_jvm_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_jvm_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_edge_jvm_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_jvm_A_New()}; return nil }

func A_arbace_a2g_edge_jvm_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_jvm_A_fn_class)}; return nil }

var A_arbace_a2g_edge_jvm_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_jvm_A_invoke, New: A_arbace_a2g_edge_jvm_A_new, Get: A_arbace_a2g_edge_jvm_A_get}

var A_arbace_a2g_edge_jvm_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$jvm", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "jvm", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_jvm_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_jvm_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_jvm_A_InstanceOf; i.Init = A_arbace_a2g_edge_jvm_A_Init; i.Table = A_arbace_a2g_edge_jvm_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_jvm_A_class, reflect.TypeFor[A_arbace_a2g_edge_jvm_A]()) }

func A_arbace_a2g_edge_jvm_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_jvm_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_edge_jvm_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_jvm_QMARK__A_New()}; return nil }

func A_arbace_a2g_edge_jvm_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_jvm_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_edge_jvm_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_jvm_QMARK__A_invoke, New: A_arbace_a2g_edge_jvm_QMARK__A_new, Get: A_arbace_a2g_edge_jvm_QMARK__A_get}

var A_arbace_a2g_edge_jvm_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$jvm_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "jvm_QMARK_", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_jvm_QMARK__A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_jvm_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_edge_jvm_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_edge_jvm_QMARK__A_Init; i.Table = A_arbace_a2g_edge_jvm_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_edge_jvm_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_edge_jvm_QMARK__A]()) }

func A_arbace_a2g_edge_merge_edges_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_merge_edges_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_merge_edges_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_merge_edges_A_New()}; return nil }

func A_arbace_a2g_edge_merge_edges_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_merge_edges_A_fn_class)}; return nil }

var A_arbace_a2g_edge_merge_edges_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_merge_edges_A_invoke, New: A_arbace_a2g_edge_merge_edges_A_new, Get: A_arbace_a2g_edge_merge_edges_A_get}

var A_arbace_a2g_edge_merge_edges_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$merge_edges", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "merge_edges", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_merge_edges_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_merge_edges_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_merge_edges_A_InstanceOf; i.Init = A_arbace_a2g_edge_merge_edges_A_Init; i.Table = A_arbace_a2g_edge_merge_edges_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_merge_edges_A_class, reflect.TypeFor[A_arbace_a2g_edge_merge_edges_A]()) }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_merge_edges_fn__1280000169_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_merge_edges_fn__1280000169_A_New()}; return nil }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_merge_edges_fn__1280000169_A_fn_class)}; return nil }

var A_arbace_a2g_edge_merge_edges_fn__1280000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_merge_edges_fn__1280000169_A_invoke, New: A_arbace_a2g_edge_merge_edges_fn__1280000169_A_new, Get: A_arbace_a2g_edge_merge_edges_fn__1280000169_A_get}

var A_arbace_a2g_edge_merge_edges_fn__1280000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$merge_edges$fn__1280000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_merge_edges_A_class, Simple: "fn__1280000169", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_merge_edges_fn__1280000169_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_merge_edges_fn__1280000169_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_merge_edges_fn__1280000169_A_InstanceOf; i.Init = A_arbace_a2g_edge_merge_edges_fn__1280000169_A_Init; i.Table = A_arbace_a2g_edge_merge_edges_fn__1280000169_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_merge_edges_fn__1280000169_A_class, reflect.TypeFor[A_arbace_a2g_edge_merge_edges_fn__1280000169_A]()) }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_New()}; return nil }

func A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_fn_class)}; return nil }

var A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_invoke, New: A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_new, Get: A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_get}

var A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$merge_edges$fn__1280000169$fn__1280000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_merge_edges_fn__1280000169_A_class, Simple: "fn__1280000170", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_InstanceOf; i.Init = A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_Init; i.Table = A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A_class, reflect.TypeFor[A_arbace_a2g_edge_merge_edges_fn__1280000169_fn__1280000170_A]()) }

func A_arbace_a2g_edge_method_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_method_key_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_method_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_method_key_A_New()}; return nil }

func A_arbace_a2g_edge_method_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_method_key_A_fn_class)}; return nil }

var A_arbace_a2g_edge_method_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_method_key_A_invoke, New: A_arbace_a2g_edge_method_key_A_new, Get: A_arbace_a2g_edge_method_key_A_get}

var A_arbace_a2g_edge_method_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$method_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "method_key", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_method_key_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_method_key_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_method_key_A_InstanceOf; i.Init = A_arbace_a2g_edge_method_key_A_Init; i.Table = A_arbace_a2g_edge_method_key_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_method_key_A_class, reflect.TypeFor[A_arbace_a2g_edge_method_key_A]()) }

func A_arbace_a2g_edge_pr_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_pr_data_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_pr_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_pr_data_A_New()}; return nil }

func A_arbace_a2g_edge_pr_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_pr_data_A_fn_class)}; return nil }

var A_arbace_a2g_edge_pr_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_pr_data_A_invoke, New: A_arbace_a2g_edge_pr_data_A_new, Get: A_arbace_a2g_edge_pr_data_A_get}

var A_arbace_a2g_edge_pr_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$pr_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "pr_data", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_pr_data_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_pr_data_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_pr_data_A_InstanceOf; i.Init = A_arbace_a2g_edge_pr_data_A_Init; i.Table = A_arbace_a2g_edge_pr_data_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_pr_data_A_class, reflect.TypeFor[A_arbace_a2g_edge_pr_data_A]()) }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_New()}; return nil }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_fn_class)}; return nil }

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_invoke, New: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_new, Get: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_get}

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$pr_data$iter__1280000016__1280000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_pr_data_A_class, Simple: "iter__1280000016__1280000020", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_InstanceOf; i.Init = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_Init; i.Table = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_class, reflect.TypeFor[A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A]()) }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_fn_class)}; return nil }

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_invoke, New: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_new, Get: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_get}

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$pr_data$iter__1280000016__1280000020$fn__1280000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_A_class, Simple: "fn__1280000021", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_InstanceOf; i.Init = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_Init; i.Table = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_class, reflect.TypeFor[A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A]()) }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_fn_class)}; return nil }

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_invoke, New: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_new, Get: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_get}

var A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$pr_data$iter__1280000016__1280000020$fn__1280000021$fn__1280000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_A_class, Simple: "fn__1280000022", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_InstanceOf; i.Init = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_Init; i.Table = A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A_class, reflect.TypeFor[A_arbace_a2g_edge_pr_data_iter__1280000016__1280000020_fn__1280000021_fn__1280000022_A]()) }

func A_arbace_a2g_edge_pr_double_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_pr_double_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_pr_double_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_pr_double_A_New()}; return nil }

func A_arbace_a2g_edge_pr_double_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_pr_double_A_fn_class)}; return nil }

var A_arbace_a2g_edge_pr_double_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_pr_double_A_invoke, New: A_arbace_a2g_edge_pr_double_A_new, Get: A_arbace_a2g_edge_pr_double_A_get}

var A_arbace_a2g_edge_pr_double_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$pr_double", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "pr_double", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_pr_double_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_pr_double_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_pr_double_A_InstanceOf; i.Init = A_arbace_a2g_edge_pr_double_A_Init; i.Table = A_arbace_a2g_edge_pr_double_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_pr_double_A_class, reflect.TypeFor[A_arbace_a2g_edge_pr_double_A]()) }

func A_arbace_a2g_edge_pr_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_pr_string_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_pr_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_pr_string_A_New()}; return nil }

func A_arbace_a2g_edge_pr_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_pr_string_A_fn_class)}; return nil }

var A_arbace_a2g_edge_pr_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_pr_string_A_invoke, New: A_arbace_a2g_edge_pr_string_A_new, Get: A_arbace_a2g_edge_pr_string_A_get}

var A_arbace_a2g_edge_pr_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$pr_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "pr_string", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_pr_string_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_pr_string_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_pr_string_A_InstanceOf; i.Init = A_arbace_a2g_edge_pr_string_A_Init; i.Table = A_arbace_a2g_edge_pr_string_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_pr_string_A_class, reflect.TypeFor[A_arbace_a2g_edge_pr_string_A]()) }

func A_arbace_a2g_edge_read_edge_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_A_New()}; return nil }

func A_arbace_a2g_edge_read_edge_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_A_invoke, New: A_arbace_a2g_edge_read_edge_A_new, Get: A_arbace_a2g_edge_read_edge_A_get}

var A_arbace_a2g_edge_read_edge_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "read_edge", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_A_Init; i.Table = A_arbace_a2g_edge_read_edge_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_A]()) }

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_fn__1280000220_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_fn__1280000220_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000220_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_fn__1280000220_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_fn__1280000220_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_fn__1280000220_A_invoke, New: A_arbace_a2g_edge_read_edge_fn__1280000220_A_new, Get: A_arbace_a2g_edge_read_edge_fn__1280000220_A_get}

var A_arbace_a2g_edge_read_edge_fn__1280000220_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge$fn__1280000220", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_read_edge_A_class, Simple: "fn__1280000220", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_fn__1280000220_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_fn__1280000220_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_fn__1280000220_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_fn__1280000220_A_Init; i.Table = A_arbace_a2g_edge_read_edge_fn__1280000220_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_fn__1280000220_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_fn__1280000220_A]()) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_fn__1280000222_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_fn__1280000222_A_New()}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_fn__1280000222_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_fn__1280000222_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_fn__1280000222_A_invoke, New: A_arbace_a2g_edge_read_edge_fn__1280000222_A_new, Get: A_arbace_a2g_edge_read_edge_fn__1280000222_A_get}

var A_arbace_a2g_edge_read_edge_fn__1280000222_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge$fn__1280000222", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_read_edge_A_class, Simple: "fn__1280000222", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_fn__1280000222_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_fn__1280000222_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_fn__1280000222_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_fn__1280000222_A_Init; i.Table = A_arbace_a2g_edge_read_edge_fn__1280000222_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_fn__1280000222_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_fn__1280000222_A]()) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_New()}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_invoke, New: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_new, Get: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_get}

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge$fn__1280000222$iter__1280000223__1280000227", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_read_edge_fn__1280000222_A_class, Simple: "iter__1280000223__1280000227", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_Init; i.Table = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A]()) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_invoke, New: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_new, Get: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_get}

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge$fn__1280000222$iter__1280000223__1280000227$fn__1280000228", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_A_class, Simple: "fn__1280000228", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_Init; i.Table = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A]()) }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_invoke, New: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_new, Get: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_get}

var A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge$fn__1280000222$iter__1280000223__1280000227$fn__1280000228$fn__1280000229", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_A_class, Simple: "fn__1280000229", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_Init; i.Table = A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_fn__1280000222_iter__1280000223__1280000227_fn__1280000228_fn__1280000229_A]()) }

func A_arbace_a2g_edge_read_edge_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_data_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_data_A_New()}; return nil }

func A_arbace_a2g_edge_read_edge_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_data_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_data_A_invoke, New: A_arbace_a2g_edge_read_edge_data_A_new, Get: A_arbace_a2g_edge_read_edge_data_A_get}

var A_arbace_a2g_edge_read_edge_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "read_edge_data", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_data_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_data_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_data_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_data_A_Init; i.Table = A_arbace_a2g_edge_read_edge_data_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_data_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_data_A]()) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_data_fn__1280000243_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_invoke, New: A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_new, Get: A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_get}

var A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge_data$fn__1280000243", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_read_edge_data_A_class, Simple: "fn__1280000243", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_data_fn__1280000243_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_Init; i.Table = A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_data_fn__1280000243_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_data_fn__1280000243_A]()) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_New()}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_invoke, New: A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_new, Get: A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_get}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge_data$fn__1280000245", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_read_edge_data_A_class, Simple: "fn__1280000245", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_data_fn__1280000245_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_Init; i.Table = A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_data_fn__1280000245_A]()) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_New()}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_invoke, New: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_new, Get: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_get}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge_data$fn__1280000245$iter__1280000246__1280000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_read_edge_data_fn__1280000245_A_class, Simple: "iter__1280000246__1280000250", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_Init; i.Table = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A]()) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_invoke, New: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_new, Get: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_get}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge_data$fn__1280000245$iter__1280000246__1280000250$fn__1280000251", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_A_class, Simple: "fn__1280000251", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_Init; i.Table = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A]()) }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_fn_class)}; return nil }

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_invoke, New: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_new, Get: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_get}

var A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$read_edge_data$fn__1280000245$iter__1280000246__1280000250$fn__1280000251$fn__1280000252", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_A_class, Simple: "fn__1280000252", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_InstanceOf; i.Init = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_Init; i.Table = A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A_class, reflect.TypeFor[A_arbace_a2g_edge_read_edge_data_fn__1280000245_iter__1280000246__1280000250_fn__1280000251_fn__1280000252_A]()) }

func A_arbace_a2g_edge_recorded_edge_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_recorded_edge_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_recorded_edge_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_recorded_edge_A_New()}; return nil }

func A_arbace_a2g_edge_recorded_edge_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_recorded_edge_A_fn_class)}; return nil }

var A_arbace_a2g_edge_recorded_edge_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_recorded_edge_A_invoke, New: A_arbace_a2g_edge_recorded_edge_A_new, Get: A_arbace_a2g_edge_recorded_edge_A_get}

var A_arbace_a2g_edge_recorded_edge_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$recorded_edge", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "recorded_edge", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_recorded_edge_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_recorded_edge_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_recorded_edge_A_InstanceOf; i.Init = A_arbace_a2g_edge_recorded_edge_A_Init; i.Table = A_arbace_a2g_edge_recorded_edge_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_recorded_edge_A_class, reflect.TypeFor[A_arbace_a2g_edge_recorded_edge_A]()) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_New_O(args[0])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_fn_class)}; return nil }

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_invoke, New: A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_new, Get: A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_get}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$recorded_edge$fn__1280000148", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_recorded_edge_A_class, Simple: "fn__1280000148", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_recorded_edge_fn__1280000148_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_InstanceOf; i.Init = A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_Init; i.Table = A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_class, reflect.TypeFor[A_arbace_a2g_edge_recorded_edge_fn__1280000148_A]()) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_New()}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_fn_class)}; return nil }

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_invoke, New: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_new, Get: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_get}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$recorded_edge$fn__1280000148$iter__1280000149__1280000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_edge_recorded_edge_fn__1280000148_A_class, Simple: "iter__1280000149__1280000153", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_InstanceOf; i.Init = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_Init; i.Table = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_class, reflect.TypeFor[A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A]()) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_fn_class)}; return nil }

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_invoke, New: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_new, Get: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_get}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$recorded_edge$fn__1280000148$iter__1280000149__1280000153$fn__1280000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_A_class, Simple: "fn__1280000154", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_InstanceOf; i.Init = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_Init; i.Table = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_class, reflect.TypeFor[A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A]()) }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_fn_class)}; return nil }

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_invoke, New: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_new, Get: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_get}

var A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$recorded_edge$fn__1280000148$iter__1280000149__1280000153$fn__1280000154$fn__1280000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_A_class, Simple: "fn__1280000155", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_class.Info(); i.IsInstance = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_InstanceOf; i.Init = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_Init; i.Table = A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_members; jrt.RegisterGoType(A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A_class, reflect.TypeFor[A_arbace_a2g_edge_recorded_edge_fn__1280000148_iter__1280000149__1280000153_fn__1280000154_fn__1280000155_A]()) }

func A_arbace_a2g_edge_write_edge_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_edge_write_edge_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_edge_write_edge_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge_write_edge_BANG__A_New()}; return nil }

func A_arbace_a2g_edge_write_edge_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_edge_write_edge_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_edge_write_edge_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_edge_write_edge_BANG__A_invoke, New: A_arbace_a2g_edge_write_edge_BANG__A_new, Get: A_arbace_a2g_edge_write_edge_BANG__A_get}

var A_arbace_a2g_edge_write_edge_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge$write_edge_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_edge_A_class, Simple: "write_edge_BANG_", Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge_write_edge_BANG__A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge_write_edge_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_edge_write_edge_BANG__A_InstanceOf; i.Init = A_arbace_a2g_edge_write_edge_BANG__A_Init; i.Table = A_arbace_a2g_edge_write_edge_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_edge_write_edge_BANG__A_class, reflect.TypeFor[A_arbace_a2g_edge_write_edge_BANG__A]()) }

func A_arbace_a2g_edge__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_edge__init_A_Load__O(); case 1: return A_arbace_a2g_edge__init_A_Unit0__O(); case 2: return A_arbace_a2g_edge__init_A_Unit1__O(); case 3: return A_arbace_a2g_edge__init_A_Unit10__O(); case 4: return A_arbace_a2g_edge__init_A_Unit11__O(); case 5: return A_arbace_a2g_edge__init_A_Unit12__O(); case 6: return A_arbace_a2g_edge__init_A_Unit13__O(); case 7: return A_arbace_a2g_edge__init_A_Unit14__O(); case 8: return A_arbace_a2g_edge__init_A_Unit15__O(); case 9: return A_arbace_a2g_edge__init_A_Unit16__O(); case 10: return A_arbace_a2g_edge__init_A_Unit17__O(); case 11: return A_arbace_a2g_edge__init_A_Unit18__O(); case 12: return A_arbace_a2g_edge__init_A_Unit19__O(); case 13: return A_arbace_a2g_edge__init_A_Unit2__O(); case 14: return A_arbace_a2g_edge__init_A_Unit20__O(); case 15: return A_arbace_a2g_edge__init_A_Unit21__O(); case 16: return A_arbace_a2g_edge__init_A_Unit22__O(); case 17: return A_arbace_a2g_edge__init_A_Unit23__O(); case 18: return A_arbace_a2g_edge__init_A_Unit24__O(); case 19: return A_arbace_a2g_edge__init_A_Unit25__O(); case 20: return A_arbace_a2g_edge__init_A_Unit26__O(); case 21: return A_arbace_a2g_edge__init_A_Unit27__O(); case 22: return A_arbace_a2g_edge__init_A_Unit28__O(); case 23: return A_arbace_a2g_edge__init_A_Unit29__O(); case 24: return A_arbace_a2g_edge__init_A_Unit3__O(); case 25: return A_arbace_a2g_edge__init_A_Unit30__O(); case 26: return A_arbace_a2g_edge__init_A_Unit4__O(); case 27: return A_arbace_a2g_edge__init_A_Unit5__O(); case 28: return A_arbace_a2g_edge__init_A_Unit6__O(); case 29: return A_arbace_a2g_edge__init_A_Unit7__O(); case 30: return A_arbace_a2g_edge__init_A_Unit8__O(); case 31: return A_arbace_a2g_edge__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_edge__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_edge__init_A_New()}; return nil }

var A_arbace_a2g_edge__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_edge__init_A_invoke, New: A_arbace_a2g_edge__init_A_new}

var A_arbace_a2g_edge__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.edge__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_edge.A_arbace_a2g_edge__init_A", Source: "edge.ae"})

func init() { i := A_arbace_a2g_edge__init_A_class.Info(); i.IsInstance = A_arbace_a2g_edge__init_A_InstanceOf; i.Init = A_arbace_a2g_edge__init_A_Init; i.Table = A_arbace_a2g_edge__init_A_members; jrt.RegisterGoType(A_arbace_a2g_edge__init_A_class, reflect.TypeFor[A_arbace_a2g_edge__init_A]()) }
