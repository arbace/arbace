//line j2g_strings.ae:1
package aot_arbace_repr_go_read

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn4,pathkn10,type-tablekn4,argskn9,embeddedskn4,elemkn3,keykn6,originkn6,actualkn1,tkn6,paramskn7,resultskn6,fieldskn7,methodskn5,termskn4,varskn11,type-paramskn10,constraintkn4,kindkn2,idkn3,refkn7,packagekn5,fileskn5,nodeskn9,annotatedkn6,errorskn5,typeskn10,directiveskn12,type-entrieskn3,astkn2,mskn5,byteskn4,failkn4,jobskn5,quietkn3,tagv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn19,arbace.repr.go.readm2,R4,s534,Reads the dumps of repr/go's front end helper (tools/godump, doc/go/HELPER-NOTES.md) with\n  Arbace's reader into data.\n\n  bin/repr-go read --dump [--jobs N] [--quiet] FILE|DIR...\n    Reads each dump (DIRs: every .edn below them) with arbace.core/read and *read-eval*\n    false, and prints per dump the time and a summary: files, nodes, annotated nodes, type\n    errors, named types, directives and type table entries. Exits 1 if a dump does not read\n    as one form, or if its type table is not in dependency order (check-type-table).v11,arbace.core13,*loaded-libs*v11,arbace.core3,strv11,arbace.core4,readv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core7,ex-infoR5,v11,arbace.core4,seq?v11,arbace.core8,keyword?v11,arbace.core4,map?v11,arbace.core5,nnextv11,arbace.core5,firstv11,arbace.core6,secondv11,arbace.core6,filterv19,arbace.repr.go.read5,node?v11,arbace.core8,tree-seqv11,arbace.core5,coll?v11,arbace.core4,valsv11,arbace.core3,seqR6,v11,arbace.core6,concatv11,arbace.core4,keepR7,R8,v11,arbace.core3,mapv11,arbace.core6,mapcatV4,R9,R10,R11,R12,R13,R14,R15,R16,R17,R18,R19,v11,arbace.core4,juxtR20,R21,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core11,map-indexedv11,arbace.core6,vectorR22,v11,arbace.core6,pr-strR23,v19,arbace.repr.go.read9,type-refsv11,arbace.core4,int?R24,v11,arbace.core10,chunk-restv11,arbace.core4,nextR25,R26,R27,R28,R29,R30,R31,R32,v11,arbace.core4,compv19,arbace.repr.go.read5,nodesR33,v11,arbace.core4,metav11,arbace.core4,sortv11,arbace.core12,chunk-bufferv13,arbace.string10,ends-with?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restv11,arbace.core8,file-seqv19,arbace.repr.go.read16,check-type-tablev11,arbace.core5,assocv19,arbace.repr.go.read9,read-dumpv19,arbace.repr.go.read7,summaryR34,R35,R36,v11,arbace.core5,classm2,R37,l1,R38,R37,v11,arbace.core10,parse-longv19,arbace.repr.go.read10,dump-filesv11,arbace.core4,mapvv11,arbace.core6,removev19,arbace.repr.go.read5,checkm2,R39,C29,java.util.concurrent.Callablev11,arbace.core7,printlnv11,arbace.core15,shutdown-agentsv11,arbace.core3,notv11,arbace.core6,formatv11,arbace.core6,reducev11,arbace.core1,+")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.read$_main$fn__1652000068")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.read$_main$fn__1652000074")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go.read$_main$fn__1652000078")

var Lit_4 *jrt.String = jrt.Intern("FAIL")

var Lit_5 *jrt.String = jrt.Intern("%s: %s, %d files, %d nodes (%d annotated), %d errors, %d types, %d directives, %d type entries, %.1f MB, read in %.0f ms")

var Lit_6 *jrt.String = jrt.Intern("read %d of %d dumps (%.1f MB, %d nodes, %d type entries, %d type errors) in %.1f s with %d threads; %d failed")

var Lit_7 *jrt.String = jrt.Intern("--quiet")

var Lit_8 *jrt.String = jrt.Intern("--jobs")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.read$_main$fn__1652000074$fn__1652000075")

var Lit_10 *jrt.String = jrt.Intern(": ")

var Lit_11 *jrt.String = jrt.Intern("type ")

var Lit_12 *jrt.String = jrt.Intern(": not an entry: ")

var Lit_13 *jrt.String = jrt.Intern(" refers to ")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.read$dump_files$iter__1652000039__1652000045")

var Lit_15 *jrt.String = jrt.Intern("arbace.repr.go.read$dump_files$iter__1652000039__1652000045$fn__1652000046")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go.read$dump_files$iter__1652000039__1652000045$fn__1652000046$iter__1652000041__1652000047")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.read$dump_files$iter__1652000039__1652000045$fn__1652000046$iter__1652000041__1652000047$fn__1652000048")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.read$dump_files$iter__1652000039__1652000045$fn__1652000046$iter__1652000041__1652000047$fn__1652000048$fn__1652000049")

var Lit_19 *jrt.String = jrt.Intern(".edn")

var Lit_20 *jrt.String = jrt.Intern("java.io.File")

var Lit_21 *jrt.String = jrt.Intern("java.io.FileInputStream")

var Lit_22 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_23 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_24 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_25 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_26 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.go.read$nodes$fn__1652000014")

var Lit_28 *jrt.String = jrt.Intern(": empty dump")

var Lit_29 *jrt.String = jrt.Intern(": more than one form")

var Lit_30 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn4,pathkn4,linekn6,columnkn4,fileyn1,xyn4,treeyn1,dyn2,idkn7,privateyn1,eyn5,pathsyn1,&yn4,argsv11,arbace.core5,in-nsMyn19,arbace.repr.go.readm2,R0,s534,Reads the dumps of repr/go's front end helper (tools/godump, doc/go/HELPER-NOTES.md) with\n  Arbace's reader into data.\n\n  bin/repr-go read --dump [--jobs N] [--quiet] FILE|DIR...\n    Reads each dump (DIRs: every .edn below them) with arbace.core/read and *read-eval*\n    false, and prints per dump the time and a summary: files, nodes, annotated nodes, type\n    errors, named types, directives and type table entries. Exits 1 if a dump does not read\n    as one form, or if its type table is not in dependency order (check-type-table).m2,R0,s534,Reads the dumps of repr/go's front end helper (tools/godump, doc/go/HELPER-NOTES.md) with\n  Arbace's reader into data.\n\n  bin/repr-go read --dump [--jobs N] [--quiet] FILE|DIR...\n    Reads each dump (DIRs: every .edn below them) with arbace.core/read and *read-eval*\n    false, and prints per dump the time and a summary: files, nodes, annotated nodes, type\n    errors, named types, directives and type table entries. Exits 1 if a dump does not read\n    as one form, or if its type table is not in dependency order (check-type-table).R1,v19,arbace.repr.go.read9,read-dumpm10,R2,L1,V1,R3,R0,s124,Reads the dump at path (one form) with *read-eval* false. Throws if anything but\n  whitespace and comments follows the form.R4,i15,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read5,node?m10,R2,L1,V1,R7,R0,s36,A node form: (:kebab-type {fields}).R4,i31,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read5,nodesm10,R2,L1,V1,R8,R0,s54,The node forms of a tree, depth first in source order.R4,i36,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read10,type-entrym10,R2,L1,V2,R9,R10,R0,s81,The entry of type id in the dump's :type-table (doc/go/HELPER-NOTES.md, \"Types\").R4,i41,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read9,type-refsm12,R11,TR2,L1,V1,R12,R0,s45,The ids an entry of the type table refers to.R4,i46,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read16,check-type-tablem10,R2,L1,V1,R9,R0,s169,Throws unless every entry of the dump's type table is a map with a :kind and refers only to\n  earlier entries (the table is in dependency order; named types are leaves).R4,i54,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read7,summarym10,R2,L1,V1,R9,R0,s17,Counts of a dump.R4,i66,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read10,dump-filesm10,R2,L1,V1,R13,R0,s81,The .edn files of the paths (files, or directories searched recursively), sorted.R4,i79,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read5,checkm10,R11,TR2,L1,V1,R3,R4,i87,R5,i1,R6,s22,arbace/repr/go/read.aev19,arbace.repr.go.read5,-mainm8,R2,L1,V2,R14,R15,R4,i96,R5,i1,R6,s22,arbace/repr/go/read.ae")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.read$eval1652000004$loading__1927001464__auto____1652000005")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.go.read$eval1652000008$fn__1652000009")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.read$read_dump")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.read$node_QMARK_")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.read$nodes")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.read$type_entry")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.read$type_refs")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.read$check_type_table")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.read$summary")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.read$dump_files")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.read$check")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.read$_main")
