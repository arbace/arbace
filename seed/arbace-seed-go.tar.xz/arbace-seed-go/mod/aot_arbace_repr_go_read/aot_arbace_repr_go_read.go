//line aot_arbace_repr_go_read.ae:1
package aot_arbace_repr_go_read

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A_New() *A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_read_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_2); lang.IFn_Cast(A_arbace_repr_go_read_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_25)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_26)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_read_eval1652000008_fn__1652000009_A_New() *A_arbace_repr_go_read_eval1652000008_fn__1652000009_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_eval1652000008_fn__1652000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000008_fn__1652000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000008_fn__1652000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_read_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_8), A_arbace_repr_go_read_A_const_6.GetRawRoot__O(), A_arbace_repr_go_read_A_const_7) }













func A_arbace_repr_go_read_read_dump_A_New() *A_arbace_repr_go_read_read_dump_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_read_dump_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_repr_go_read_read_dump_A) Ctor() {}
//line :15:1
func (t *A_arbace_repr_go_read_read_dump_A) Invoke_O_O__O(self, path__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader_I(jrt.InputStreamReader_New_InputStream_Charset(jrt.FileInputStream_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_9.GetRawRoot__O()).Invoke_O__O(path__0))), jrt.StandardCharsets_UTF_8), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1, 1024), 1024))); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	lang.IFn_Cast(A_arbace_repr_go_read_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_14, jrt.Boolean_FALSE.Ref()))
//line :15:1
	{ tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var eof__7 any = jrt.Object_New(); var d__8 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(r__2, jrt.Boolean_FALSE.Ref(), eof__7)









		if lang.Util_Identical_O_O__Z_NoInit(d__8, eof__7) { var tmp2 any = A_arbace_repr_go_read_A_const_16; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, path__0, nil)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.IFn_Cast(A_arbace_repr_go_read_A_const_9.GetRawRoot__O()).Invoke_O__O(path__0)))))))
		}
		if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_read_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(r__2, jrt.Boolean_FALSE.Ref(), eof__7), eof__7) { } else { var tmp3 any = A_arbace_repr_go_read_A_const_16; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, path__0, nil)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.IFn_Cast(A_arbace_repr_go_read_A_const_9.GetRawRoot__O()).Invoke_O__O(path__0))))))) }
//line :15:1
		tmp1 = d__8 }; return nil }()






		lang.IFn_Cast(A_arbace_repr_go_read_A_const_11.GetRawRoot__O()).Invoke__O()
//line :15:1
		if tmp4 != nil { panic(tmp4) } }; return nil }();



	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :15:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }















func A_arbace_repr_go_read_node_QMARK__A_New() *A_arbace_repr_go_read_node_QMARK__A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_node_QMARK__A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_go_read_node_QMARK__A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_go_read_node_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_17.GetRawRoot__O()).Invoke_O__O(x__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_22.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.J2g_Truth(and__1927000168__auto____4) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_repr_go_read_A_const_20.GetRawRoot__O()).Invoke_O__O(x__0), nil)).Ref() } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_read_nodes_A_New() *A_arbace_repr_go_read_nodes_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_nodes_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_repr_go_read_nodes_A) Ctor() {}
//line :36:1
func (t *A_arbace_repr_go_read_nodes_A) Invoke_O_O__O(self, tree__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_read_A_const_24.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_read_A_const_26.GetRawRoot__O(); var tmp5 any = A_arbace_repr_go_read_nodes_fn__1652000014_A_New(); var tmp6 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_read_nodes_fn__1652000014_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_go_read_nodes_fn__1652000014_A_fn_class = fncls__1d; tmp6 = fncls__1d } else { tmp6 = fncls__1 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), tree__0)) }
//line :39:1
func A_arbace_repr_go_read_nodes_fn__1652000014_A_New() *A_arbace_repr_go_read_nodes_fn__1652000014_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_nodes_fn__1652000014_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_go_read_nodes_fn__1652000014_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_go_read_nodes_fn__1652000014_A) Invoke_O_O__O(self, x__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_19.GetRawRoot__O()).Invoke_O__O(x__1)) { return lang.IFn_Cast(A_arbace_repr_go_read_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1) } else { return lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(x__1) } }

func A_arbace_repr_go_read_type_entry_A_New() *A_arbace_repr_go_read_type_entry_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_type_entry_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_read_type_entry_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_read_type_entry_A) Invoke_O_O_O__O(self, d__0, id__1 any) any {


	return lang.RT_Nth_O_I__O_NoInit(A_arbace_repr_go_read_A_const_29.Invoke_O__O(d__0), lang.RT_IntCast_O__I_NoInit(id__1))
}
func A_arbace_repr_go_read_type_refs_A_New() *A_arbace_repr_go_read_type_refs_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_type_refs_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_repr_go_read_type_refs_A) Ctor() {}
//line :46:1
func (t *A_arbace_repr_go_read_type_refs_A) Invoke_O_O__O(self, e__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_34.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_read_A_const_37; return lang.IFn_Cast(A_arbace_repr_go_read_A_const_30.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_31.GetRawRoot__O()).Invoke_O_O__O(e__0, A_arbace_repr_go_read_A_const_36), A_arbace_repr_go_read_A_const_32.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_33.Invoke_O__O(e__0), tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_repr_go_read_A_const_30.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_read_A_const_38.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_39.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_40.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_41.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_42.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_43.Invoke_O__O(e__0))), lang.IFn_Cast(A_arbace_repr_go_read_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_37, A_arbace_repr_go_read_A_const_46), A_arbace_repr_go_read_A_const_45.Invoke_O__O(e__0)))
}



func A_arbace_repr_go_read_check_type_table_A_New() *A_arbace_repr_go_read_check_type_table_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_check_type_table_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_repr_go_read_check_type_table_A) Ctor() {}
//line :54:1
func (t *A_arbace_repr_go_read_check_type_table_A) Invoke_O_O__O(self, d__0 any) any { var seq_1652000019__2 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_50.GetRawRoot__O(), A_arbace_repr_go_read_A_const_29.Invoke_O__O(d__0))); var chunk_1652000020__3 any; var count_1652000021__4 int64 = 0; var i_1652000022__5 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000022__5, count_1652000021__4) { var vec__1652000023__6 any = lang.Indexed_Cast(chunk_1652000020__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000022__5)); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000023__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000023__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_19.GetRawRoot__O()).Invoke_O__O(e__8)
		if jrt.J2g_Truth(and__1927000168__auto____9) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_51.Invoke_O__O(e__8)) } else { tmp1 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__7, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_52.GetRawRoot__O()).Invoke_O__O(e__8))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_53, i__7)))))) }
//line :58:1
		var seq_1652000026__9 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_54.GetRawRoot__O()).Invoke_O__O(e__8)); var chunk_1652000027__10 any; var count_1652000028__11 int64 = 0; var i_1652000029__12 int64 = 0; L2: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000029__12, count_1652000028__11) { var r__13 any = lang.Indexed_Cast(chunk_1652000027__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000029__12)); var tmp2 any; var and__1927000168__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_55.GetRawRoot__O()).Invoke_O__O(r__13)
				if jrt.J2g_Truth(and__1927000168__auto____14) { var and__1927000168__auto____15 bool; var na_2 int64 = 0; var na_3 any = r__13; if jrt.Long_InstanceOf(na_3) { var n0_4 int64 = na_2; var n1_5 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); and__1927000168__auto____15 = n0_4 <= n1_5 } else { and__1927000168__auto____15 = lang.Numbers_Lte_J_O__Z_NoInit(na_2, na_3) }; if and__1927000168__auto____15 { var tmp3 bool; var na_7 any = r__13; var na_8 any = i__7; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_7); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_8) }; tmp4 = tmp5; if tmp4 { var n0_9 int64 = jrt.NN(jrt.Long_Cast(na_7)).LongValue__J(); var n1_10 int64 = jrt.NN(jrt.Long_Cast(na_8)).LongValue__J(); tmp3 = n0_9 < n1_10 } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_7); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_8) }; tmp6 = tmp7; if tmp6 { var n0_9_2 float64 = jrt.NN(jrt.Double_Cast(na_7)).DoubleValue__D(); var n1_10_2 float64 = jrt.NN(jrt.Double_Cast(na_8)).DoubleValue__D(); tmp3 = n0_9_2 < n1_10_2 } else { tmp3 = lang.Numbers_Lt_O_O__Z_NoInit(na_7, na_8) } }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { tmp2 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp2) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__7, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_52.GetRawRoot__O()).Invoke_O__O(r__13))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_53, i__7, A_arbace_repr_go_read_A_const_56, r__13)))))) }
//line :61:1
				seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, i_1652000029__12 = seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000029__12); continue L2 } else { var temp__1927000414__auto____13 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1652000026__9); if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1652000026__14 any = temp__1927000414__auto____13; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1652000026__14)) { var c__1927000678__auto____15 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1652000026__14); seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, i_1652000029__12 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_57.GetRawRoot__O()).Invoke_O__O(seq_1652000026__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var r__15 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_1652000026__14); var tmp8 any; var and__1927000168__auto____16 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_55.GetRawRoot__O()).Invoke_O__O(r__15)
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_12 int64 = 0; var na_13 any = r__15; if jrt.Long_InstanceOf(na_13) { var n0_14 int64 = na_12; var n1_15 int64 = jrt.NN(jrt.Long_Cast(na_13)).LongValue__J(); and__1927000168__auto____17 = n0_14 <= n1_15 } else { and__1927000168__auto____17 = lang.Numbers_Lte_J_O__Z_NoInit(na_12, na_13) }; if and__1927000168__auto____17 { var tmp9 bool; var na_17 any = r__15; var na_18 any = i__7; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_17); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_18) }; tmp10 = tmp11; if tmp10 { var n0_19 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); var n1_20 int64 = jrt.NN(jrt.Long_Cast(na_18)).LongValue__J(); tmp9 = n0_19 < n1_20 } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_17); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_18) }; tmp12 = tmp13; if tmp12 { var n0_19_2 float64 = jrt.NN(jrt.Double_Cast(na_17)).DoubleValue__D(); var n1_20_2 float64 = jrt.NN(jrt.Double_Cast(na_18)).DoubleValue__D(); tmp9 = n0_19_2 < n1_20_2 } else { tmp9 = lang.Numbers_Lt_O_O__Z_NoInit(na_17, na_18) } }; tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp9).Ref() } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { tmp8 = and__1927000168__auto____16 }; if jrt.J2g_Truth(tmp8) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__7, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_52.GetRawRoot__O()).Invoke_O__O(r__15))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_53, i__7, A_arbace_repr_go_read_A_const_56, r__15)))))) }
//line :61:1
					seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, i_1652000029__12 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_58.GetRawRoot__O()).Invoke_O__O(seq_1652000026__14), nil, 0, 0; continue L2 } } }
//line :58:1
			break L2 }; seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, i_1652000022__5 = seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000022__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1652000019__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1652000019__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1652000019__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1652000019__7); seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, i_1652000022__5 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_57.GetRawRoot__O()).Invoke_O__O(seq_1652000019__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1652000030__8 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_1652000019__7); var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000030__8, lang.RT_IntCast_J__I_NoInit(0), nil); var e__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000030__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp14 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_19.GetRawRoot__O()).Invoke_O__O(e__10)
				if jrt.J2g_Truth(and__1927000168__auto____11) { tmp14 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_51.Invoke_O__O(e__10)) } else { tmp14 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp14) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__9, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_52.GetRawRoot__O()).Invoke_O__O(e__10))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_53, i__9)))))) }
//line :58:1
				var seq_1652000033__11 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_54.GetRawRoot__O()).Invoke_O__O(e__10)); var chunk_1652000034__12 any; var count_1652000035__13 int64 = 0; var i_1652000036__14 int64 = 0; L3: for {


					if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000036__14, count_1652000035__13) { var r__15_2 any = lang.Indexed_Cast(chunk_1652000034__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000036__14)); var tmp15 any; var and__1927000168__auto____16_2 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_55.GetRawRoot__O()).Invoke_O__O(r__15_2)
						if jrt.J2g_Truth(and__1927000168__auto____16_2) { var and__1927000168__auto____17_2 bool; var na_22 int64 = 0; var na_23 any = r__15_2; if jrt.Long_InstanceOf(na_23) { var n0_24 int64 = na_22; var n1_25 int64 = jrt.NN(jrt.Long_Cast(na_23)).LongValue__J(); and__1927000168__auto____17_2 = n0_24 <= n1_25 } else { and__1927000168__auto____17_2 = lang.Numbers_Lte_J_O__Z_NoInit(na_22, na_23) }; if and__1927000168__auto____17_2 { var tmp16 bool; var na_27 any = r__15_2; var na_28 any = i__9; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_27); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_28) }; tmp17 = tmp18; if tmp17 { var n0_29 int64 = jrt.NN(jrt.Long_Cast(na_27)).LongValue__J(); var n1_30 int64 = jrt.NN(jrt.Long_Cast(na_28)).LongValue__J(); tmp16 = n0_29 < n1_30 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_27); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_28) }; tmp19 = tmp20; if tmp19 { var n0_29_2 float64 = jrt.NN(jrt.Double_Cast(na_27)).DoubleValue__D(); var n1_30_2 float64 = jrt.NN(jrt.Double_Cast(na_28)).DoubleValue__D(); tmp16 = n0_29_2 < n1_30_2 } else { tmp16 = lang.Numbers_Lt_O_O__Z_NoInit(na_27, na_28) } }; tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp16).Ref() } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17_2).Ref() } } else { tmp15 = and__1927000168__auto____16_2 }; if jrt.J2g_Truth(tmp15) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__9, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_52.GetRawRoot__O()).Invoke_O__O(r__15_2))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_53, i__9, A_arbace_repr_go_read_A_const_56, r__15_2)))))) }
//line :61:1
						seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, i_1652000036__14 = seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000036__14); continue L3 } else { var temp__1927000414__auto____15 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1652000033__11); if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1652000033__16 any = temp__1927000414__auto____15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1652000033__16)) { var c__1927000678__auto____17 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1652000033__16); seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, i_1652000036__14 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_57.GetRawRoot__O()).Invoke_O__O(seq_1652000033__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var r__17 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_1652000033__16); var tmp21 any; var and__1927000168__auto____18 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_55.GetRawRoot__O()).Invoke_O__O(r__17)
							if jrt.J2g_Truth(and__1927000168__auto____18) { var and__1927000168__auto____19 bool; var na_32 int64 = 0; var na_33 any = r__17; if jrt.Long_InstanceOf(na_33) { var n0_34 int64 = na_32; var n1_35 int64 = jrt.NN(jrt.Long_Cast(na_33)).LongValue__J(); and__1927000168__auto____19 = n0_34 <= n1_35 } else { and__1927000168__auto____19 = lang.Numbers_Lte_J_O__Z_NoInit(na_32, na_33) }; if and__1927000168__auto____19 { var tmp22 bool; var na_37 any = r__17; var na_38 any = i__9; var tmp23 bool; var tmp24 bool; tmp24 = jrt.Long_InstanceOf(na_37); if tmp24 { tmp24 = jrt.Long_InstanceOf(na_38) }; tmp23 = tmp24; if tmp23 { var n0_39 int64 = jrt.NN(jrt.Long_Cast(na_37)).LongValue__J(); var n1_40 int64 = jrt.NN(jrt.Long_Cast(na_38)).LongValue__J(); tmp22 = n0_39 < n1_40 } else { var tmp25 bool; var tmp26 bool; tmp26 = jrt.Double_InstanceOf(na_37); if tmp26 { tmp26 = jrt.Double_InstanceOf(na_38) }; tmp25 = tmp26; if tmp25 { var n0_39_2 float64 = jrt.NN(jrt.Double_Cast(na_37)).DoubleValue__D(); var n1_40_2 float64 = jrt.NN(jrt.Double_Cast(na_38)).DoubleValue__D(); tmp22 = n0_39_2 < n1_40_2 } else { tmp22 = lang.Numbers_Lt_O_O__Z_NoInit(na_37, na_38) } }; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp22).Ref() } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() } } else { tmp21 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp21) { } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__9, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_52.GetRawRoot__O()).Invoke_O__O(r__17))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_53, i__9, A_arbace_repr_go_read_A_const_56, r__17)))))) }
//line :61:1
							seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, i_1652000036__14 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_58.GetRawRoot__O()).Invoke_O__O(seq_1652000033__16), nil, 0, 0; continue L3 } } }
//line :58:1
					break L3 }; seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, i_1652000022__5 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_58.GetRawRoot__O()).Invoke_O__O(seq_1652000019__7), nil, 0, 0; continue L1 } } }
//line :54:1
	break L1 }; return d__0 }











func A_arbace_repr_go_read_summary_A_New() *A_arbace_repr_go_read_summary_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_summary_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_repr_go_read_summary_A) Ctor() {}
//line :66:1
func (t *A_arbace_repr_go_read_summary_A) Invoke_O_O__O(self, d__0 any) any { var ns__2 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_67.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_68.GetRawRoot__O(), A_arbace_repr_go_read_A_const_69), A_arbace_repr_go_read_A_const_60.Invoke_O__O(d__0)); var tmp1 any = A_arbace_repr_go_read_A_const_59; var tmp2 any = A_arbace_repr_go_read_A_const_59.Invoke_O__O(d__0); var tmp3 any = A_arbace_repr_go_read_A_const_60; var tmp4 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_60.Invoke_O__O(d__0))).Ref(); var tmp5 any = A_arbace_repr_go_read_A_const_61; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ns__2)).Ref(); var tmp7 any = A_arbace_repr_go_read_A_const_62; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lang.IFn_Cast(A_arbace_repr_go_read_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_70.GetRawRoot__O(), ns__2))).Ref(); var tmp9 any = A_arbace_repr_go_read_A_const_63; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_63.Invoke_O__O(d__0))).Ref(); var tmp11 any = A_arbace_repr_go_read_A_const_64; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_64.Invoke_O__O(d__0))).Ref(); var tmp13 any = A_arbace_repr_go_read_A_const_65; var tmp14 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_65.Invoke_O__O(d__0))).Ref(); var tmp15 any = A_arbace_repr_go_read_A_const_66; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_29.Invoke_O__O(d__0))).Ref())) }












func A_arbace_repr_go_read_dump_files_A_New() *A_arbace_repr_go_read_dump_files_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_read_dump_files_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_read_dump_files_A) Invoke_O_O__O(self, paths__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_71.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_New(); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(paths__0); return tmp1.Invoke_O__O(tmp2) }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_New() *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A) Ctor() {}
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A) Invoke_O_O__O(self, s__1652000040__1 any) any { var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_New_O_O(self, s__1652000040__1); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_New_O_O(p0, p1 any) *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A) Ctor_O_O(c__iter__1652000039, c__s__1652000040 any) { t.F_iter__1652000039 = c__iter__1652000039; t.F_s__1652000040 = c__s__1652000040 }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A) Invoke_O__O(self any) any { { var s__1652000040__1 any; var t_ any = t.F_s__1652000040; t.F_s__1652000040 = nil; s__1652000040__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1652000040__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var p__4 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_New(); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_79.GetRawRoot__O()).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(p__4))))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1652000039); return lang.IFn_Cast(A_arbace_repr_go_read_A_const_30.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1652000040__1))) } else { s__1652000040__1 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1652000040__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_New() *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A) Ctor() {}
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A) Invoke_O_O__O(self, s__1652000042__1 any) any { var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_New_O_O(s__1652000042__1, self); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_New_O_O(p0, p1 any) *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A) Ctor_O_O(c__s__1652000042, c__iter__1652000041 any) { t.F_s__1652000042 = c__s__1652000042; t.F_iter__1652000041 = c__iter__1652000041 }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A) Invoke_O__O(self any) any { { var s__1652000042__1 any; var t_ any = t.F_s__1652000042; t.F_s__1652000042 = nil; s__1652000042__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1652000042__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1652000042__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_47.GetRawRoot__O()).Invoke_O__O(s__1652000042__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_48.GetRawRoot__O()).Invoke_O__O(s__1652000042__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1652000044__6 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_72.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1652000044__6); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1652000041); return lang.IFn_Cast(A_arbace_repr_go_read_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1652000044__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_57.GetRawRoot__O()).Invoke_O__O(s__1652000042__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_read_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1652000044__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(s__1652000042__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()

	if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_73.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_19) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :82:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1652000041); return lang.IFn_Cast(A_arbace_repr_go_read_A_const_76.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref(), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1652000042__3))) } else { s__1652000042__1 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1652000042__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1652000044 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1652000044 = c__b__1652000044 }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A) Invoke_O__O(self any) any { { var i__1652000043__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1652000043__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1652000043__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()

	if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_73.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_19) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :82:1
	if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_74.GetRawRoot__O()); var tmp4 any = t.F_b__1652000044; tmp3.Invoke_O_O__O(tmp4, jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref()); i__1652000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1652000043__1); continue L1 } else { i__1652000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1652000043__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_read_check_A_New() *A_arbace_repr_go_read_check_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_check_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_repr_go_read_check_A) Ctor() {}
//line :87:1
func (t *A_arbace_repr_go_read_check_A) Invoke_O_O__O(self, path__0 any) any { var t0__2 int64 = jrt.System_NanoTime__J(); var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var d__5 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_80.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_82.GetRawRoot__O()).Invoke_O__O(path__0)); var ms__6 float64 = lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000.0); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_81.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_83.GetRawRoot__O()).Invoke_O__O(d__5); var tmp4 any = A_arbace_repr_go_read_A_const_16; var tmp5 any = A_arbace_repr_go_read_A_const_84; var tmp6 any = jrt.Double_ValueOf_D__Double_NoInit(ms__6).Ref()
										var tmp7 any = A_arbace_repr_go_read_A_const_85



	tmp1 = tmp2.Invoke_O_O_O_O_O_O_O__O(tmp3, tmp4, path__0, tmp5, tmp6, tmp7, jrt.Long_ValueOf_J__Long_NoInit(jrt.File_New_String(jrt.String_Cast(path__0)).Length__J()).Ref()) }; return nil }(); if /*line :87:1*/ tmp8 != nil { if true { var e__5 jrt.Throwable_I = tmp8; var tmp9 any = A_arbace_repr_go_read_A_const_16; var tmp10 any = A_arbace_repr_go_read_A_const_86; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, path__0, tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_repr_go_read_A_const_87.GetRawRoot__O()).Invoke_O__O(e__5))).GetName__String().Ref(), nil, e__5.GetMessage__String().Ref())).Ref())) } }; return tmp1 }








func A_arbace_repr_go_read__main_A_New() *A_arbace_repr_go_read__main_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_read__main_A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_read__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1652000058__2 any; var opts__2 any = A_arbace_repr_go_read_A_const_88; var G__1652000064__3_ any = args__0; var vec__1652000065__4 any = G__1652000064__3_; var seq__1652000066__5 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(vec__1652000065__4); var first__1652000067__6 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(seq__1652000066__5); var seq__1652000066__7 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_58.GetRawRoot__O()).Invoke_O__O(seq__1652000066__5); var a__8 any = first__1652000067__6; var more__9 any = seq__1652000066__7; var args__10 any = vec__1652000065__4; var tmp1 any = A_arbace_repr_go_read__main_fn__1652000068_A_New_O_O(G__1652000064__3_, opts__2); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000068_A_fn_class; _ = a__8; _ = more__9; _ = args__10; if
										fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_read__main_fn__1652000068_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; vec__1652000058__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var opts__3 any = /*line :96:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1652000058__2, lang.RT_IntCast_J__I_NoInit(0), nil); var paths__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000058__2, lang.RT_IntCast_J__I_NoInit(1), nil); var files__5 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_92.GetRawRoot__O()).Invoke_O__O(paths__4); var t0__6 int64 = jrt.System_NanoTime__J(); var pool__7 any = jrt.Executors_NewFixedThreadPool_I__ExecutorService(lang.RT_IntCast_O__I_NoInit(A_arbace_repr_go_read_A_const_90.Invoke_O__O(opts__3))); var futs__8 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_93.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_read__main_fn__1652000074_A_New_O(pool__7); var tmp5 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000074_A_fn_class; if








	fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_go_read__main_fn__1652000074_A_fn_class = fncls__50d; tmp5 = fncls__50d } else { tmp5 = fncls__50 }; futs__8 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), files__5); var rs__9 any; var tmp6 lang.IFn = /*line :96:1*/lang.IFn_Cast(A_arbace_repr_go_read_A_const_93.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_read__main_fn__1652000078_A_New(); var tmp8 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000078_A_fn_class; if









	fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_read__main_fn__1652000078_A_fn_class = fncls__51d; tmp8 = fncls__51d } else { tmp8 = fncls__51 }; rs__9 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), futs__8); var wall__10 float64 = /*line :96:1*/lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__6), 1.0e9); var fails__11 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_86, rs__9); var ok__12 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_94.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_86, rs__9);













	jrt.ExecutorService_Cast(pool__7).Shutdown__V();
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ExecutorService_Cast(pool__7).AwaitTermination_J_TimeUnit__Z(1, jrt.TimeUnit_MINUTES)); var seq_1652000080__13 any = /*line :96:1*/lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(rs__9); var chunk_1652000081__14 any; var count_1652000082__15 int64 = 0; var i_1652000083__16 int64 = 0; L1: for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000083__16, count_1652000082__15) { var r__17 any = lang.Indexed_Cast(chunk_1652000081__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000083__16))
			if jrt.J2g_Truth(A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__17)) {
				lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(Lit_4, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__17)) } else {
//line :113:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_99.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_89.Invoke_O__O(opts__3))) {


						lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_100.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(Lit_5, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_59.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_60.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_61.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_62.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_63.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_64.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_65.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_66.Invoke_O__O(r__17), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(A_arbace_repr_go_read_A_const_85.Invoke_O__O(r__17), 1000000.0)).Ref(), A_arbace_repr_go_read_A_const_84.Invoke_O__O(r__17))) } }
//line :112:1
			seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, i_1652000083__16 = seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000083__16); continue L1 } else { var temp__1927000414__auto____17 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1652000080__13); if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_1652000080__18 any = temp__1927000414__auto____17; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_47.GetRawRoot__O()).Invoke_O__O(seq_1652000080__18)) { var c__1927000678__auto____19 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_48.GetRawRoot__O()).Invoke_O__O(seq_1652000080__18); seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, i_1652000083__16 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_57.GetRawRoot__O()).Invoke_O__O(seq_1652000080__18), c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__19 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_1652000080__18)
				if jrt.J2g_Truth(A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__19)) {
					lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(Lit_4, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__19)) } else {
//line :113:1
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_99.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_89.Invoke_O__O(opts__3))) {


							lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_100.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(Lit_5, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_59.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_60.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_61.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_62.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_63.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_64.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_65.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_66.Invoke_O__O(r__19), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(A_arbace_repr_go_read_A_const_85.Invoke_O__O(r__19), 1000000.0)).Ref(), A_arbace_repr_go_read_A_const_84.Invoke_O__O(r__19))) } }
//line :112:1
				seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, i_1652000083__16 = lang.IFn_Cast(A_arbace_repr_go_read_A_const_58.GetRawRoot__O()).Invoke_O__O(seq_1652000080__18), nil, 0, 0; continue L1 } } }
//line :96:1
		break L1 };






















	lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_100.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(Lit_6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ok__12)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__9)).Ref(), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(A_arbace_repr_go_read_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_102.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_read_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_85, ok__12)), 1000000.0)).Ref(), lang.IFn_Cast(A_arbace_repr_go_read_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_102.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_read_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_61, ok__12)), lang.IFn_Cast(A_arbace_repr_go_read_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_102.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_read_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_66, ok__12)), lang.IFn_Cast(A_arbace_repr_go_read_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_102.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_read_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_63, ok__12)), jrt.Double_ValueOf_D__Double_NoInit(wall__10).Ref(), A_arbace_repr_go_read_A_const_90.Invoke_O__O(opts__3), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fails__11)).Ref()));




	lang.IFn_Cast(A_arbace_repr_go_read_A_const_98.GetRawRoot__O()).Invoke__O(); var tmp9 int64; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(fails__11)) { tmp9 = 1 } else { tmp9 = 0 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp9)); return nil }
//line :97:1
func A_arbace_repr_go_read__main_fn__1652000068_A_New_O_O(p0, p1 any) *A_arbace_repr_go_read__main_fn__1652000068_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000068_A{}; t.Ctor_O_O(p0, p1); return t }
//line :97:1
func (t *A_arbace_repr_go_read__main_fn__1652000068_A) Ctor_O_O(c__G__1652000064, c__opts any) { t.F_G__1652000064 = c__G__1652000064; t.F_opts = c__opts }
//line :97:1
func (t *A_arbace_repr_go_read__main_fn__1652000068_A) Invoke_O__O(self any) any { { var opts__1 any; var t_ any = t.F_opts; t.F_opts = nil; opts__1 = t_; var G__1652000064__2_ any; var t__2 any = t.F_G__1652000064; t.F_G__1652000064 = nil; G__1652000064__2_ = t__2; L1: for { var opts__3 any = opts__1; var vec__1652000069__4 any = G__1652000064__2_; var seq__1652000070__5 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_28.GetRawRoot__O()).Invoke_O__O(vec__1652000069__4); var first__1652000071__6 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(seq__1652000070__5); var seq__1652000070__7 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_58.GetRawRoot__O()).Invoke_O__O(seq__1652000070__5); var a__8 any = first__1652000071__6; var more__9 any = seq__1652000070__7; var args__10 any = vec__1652000069__4; var G__1652000072__11_ any = a__8
											switch lang.Util_Hash_O__I_NoInit(G__1652000072__11_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1652000072__11_, Lit_7) {

		opts__1, G__1652000064__2_ = lang.IFn_Cast(A_arbace_repr_go_read_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(opts__3, A_arbace_repr_go_read_A_const_89, jrt.Boolean_TRUE.Ref()), more__9; continue L1 }
//line :98:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1652000072__11_, Lit_8) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_read_A_const_90; opts__1, G__1652000064__2_ = tmp1.Invoke_O_O_O__O(opts__3, tmp2, lang.IFn_Cast(A_arbace_repr_go_read_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_21.GetRawRoot__O()).Invoke_O__O(more__9))), lang.IFn_Cast(A_arbace_repr_go_read_A_const_78.GetRawRoot__O()).Invoke_O__O(more__9); continue L1 }
//line :98:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__3, args__10) } }; /*line :97:1*/panic("j2g: unreachable") }







func A_arbace_repr_go_read__main_fn__1652000074_A_New_O(p0 any) *A_arbace_repr_go_read__main_fn__1652000074_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000074_A{}; t.Ctor_O(p0); return t }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_A) Ctor_O(c__pool any) { t.F_pool = c__pool }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 jrt.ExecutorService = jrt.ExecutorService_Cast(t.F_pool); var tmp2 any = A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_New_O(f__1); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; return tmp1.Submit_Callable__Future(jrt.Callable_Cast(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).WithMeta_IPersistentMap__IObj(lang.IPersistentMap_Cast(A_arbace_repr_go_read_A_const_96)))) }
//line :105:1
func A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_New_O(p0 any) *A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A{}; t.Ctor_O(p0); return t }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_read_A_const_95.GetRawRoot__O()).Invoke_O__O(t.F_f) }
func A_arbace_repr_go_read__main_fn__1652000078_A_New() *A_arbace_repr_go_read__main_fn__1652000078_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000078_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_repr_go_read__main_fn__1652000078_A) Ctor() {}
//line :106:1
func (t *A_arbace_repr_go_read__main_fn__1652000078_A) Invoke_O_O__O(self, p1__1652000057_SHARP___1 any) any { return jrt.Future_Cast(p1__1652000057_SHARP___1).Get__O() }














































type A_arbace_repr_go_read_A struct{ jrt.Object }

var A_arbace_repr_go_read_A_const_pool *jrt.RefArray

var A_arbace_repr_go_read_A_const_0 *lang.Var

var A_arbace_repr_go_read_A_const_1 *lang.Var

var A_arbace_repr_go_read_A_const_2 any

var A_arbace_repr_go_read_A_const_3 any

var A_arbace_repr_go_read_A_const_4 *lang.Var

var A_arbace_repr_go_read_A_const_5 *lang.Var

var A_arbace_repr_go_read_A_const_6 *lang.Var

var A_arbace_repr_go_read_A_const_7 any

var A_arbace_repr_go_read_A_const_8 *lang.Var

var A_arbace_repr_go_read_A_const_9 *lang.Var

var A_arbace_repr_go_read_A_const_10 *lang.Var

var A_arbace_repr_go_read_A_const_11 *lang.Var

var A_arbace_repr_go_read_A_const_12 *lang.Var

var A_arbace_repr_go_read_A_const_13 *lang.Var

var A_arbace_repr_go_read_A_const_14 *lang.Var

var A_arbace_repr_go_read_A_const_15 *lang.Var

var A_arbace_repr_go_read_A_const_16 *lang.Keyword

var A_arbace_repr_go_read_A_const_17 *lang.Var

var A_arbace_repr_go_read_A_const_18 *lang.Var

var A_arbace_repr_go_read_A_const_19 *lang.Var

var A_arbace_repr_go_read_A_const_20 *lang.Var

var A_arbace_repr_go_read_A_const_21 *lang.Var

var A_arbace_repr_go_read_A_const_22 *lang.Var

var A_arbace_repr_go_read_A_const_23 *lang.Var

var A_arbace_repr_go_read_A_const_24 *lang.Var

var A_arbace_repr_go_read_A_const_25 *lang.Var

var A_arbace_repr_go_read_A_const_26 *lang.Var

var A_arbace_repr_go_read_A_const_27 *lang.Var

var A_arbace_repr_go_read_A_const_28 *lang.Var

var A_arbace_repr_go_read_A_const_29 *lang.Keyword

var A_arbace_repr_go_read_A_const_30 *lang.Var

var A_arbace_repr_go_read_A_const_31 *lang.Var

var A_arbace_repr_go_read_A_const_32 *lang.Keyword

var A_arbace_repr_go_read_A_const_33 *lang.Keyword

var A_arbace_repr_go_read_A_const_34 *lang.Var

var A_arbace_repr_go_read_A_const_35 *lang.Var

var A_arbace_repr_go_read_A_const_36 any

var A_arbace_repr_go_read_A_const_37 *lang.Keyword

var A_arbace_repr_go_read_A_const_38 *lang.Keyword

var A_arbace_repr_go_read_A_const_39 *lang.Keyword

var A_arbace_repr_go_read_A_const_40 *lang.Keyword

var A_arbace_repr_go_read_A_const_41 *lang.Keyword

var A_arbace_repr_go_read_A_const_42 *lang.Keyword

var A_arbace_repr_go_read_A_const_43 *lang.Keyword

var A_arbace_repr_go_read_A_const_44 *lang.Var

var A_arbace_repr_go_read_A_const_45 *lang.Keyword

var A_arbace_repr_go_read_A_const_46 *lang.Keyword

var A_arbace_repr_go_read_A_const_47 *lang.Var

var A_arbace_repr_go_read_A_const_48 *lang.Var

var A_arbace_repr_go_read_A_const_49 *lang.Var

var A_arbace_repr_go_read_A_const_50 *lang.Var

var A_arbace_repr_go_read_A_const_51 *lang.Keyword

var A_arbace_repr_go_read_A_const_52 *lang.Var

var A_arbace_repr_go_read_A_const_53 *lang.Keyword

var A_arbace_repr_go_read_A_const_54 *lang.Var

var A_arbace_repr_go_read_A_const_55 *lang.Var

var A_arbace_repr_go_read_A_const_56 *lang.Keyword

var A_arbace_repr_go_read_A_const_57 *lang.Var

var A_arbace_repr_go_read_A_const_58 *lang.Var

var A_arbace_repr_go_read_A_const_59 *lang.Keyword

var A_arbace_repr_go_read_A_const_60 *lang.Keyword

var A_arbace_repr_go_read_A_const_61 *lang.Keyword

var A_arbace_repr_go_read_A_const_62 *lang.Keyword

var A_arbace_repr_go_read_A_const_63 *lang.Keyword

var A_arbace_repr_go_read_A_const_64 *lang.Keyword

var A_arbace_repr_go_read_A_const_65 *lang.Keyword

var A_arbace_repr_go_read_A_const_66 *lang.Keyword

var A_arbace_repr_go_read_A_const_67 *lang.Var

var A_arbace_repr_go_read_A_const_68 *lang.Var

var A_arbace_repr_go_read_A_const_69 *lang.Keyword

var A_arbace_repr_go_read_A_const_70 *lang.Var

var A_arbace_repr_go_read_A_const_71 *lang.Var

var A_arbace_repr_go_read_A_const_72 *lang.Var

var A_arbace_repr_go_read_A_const_73 *lang.Var

var A_arbace_repr_go_read_A_const_74 *lang.Var

var A_arbace_repr_go_read_A_const_75 *lang.Var

var A_arbace_repr_go_read_A_const_76 *lang.Var

var A_arbace_repr_go_read_A_const_77 *lang.Var

var A_arbace_repr_go_read_A_const_78 *lang.Var

var A_arbace_repr_go_read_A_const_79 *lang.Var

var A_arbace_repr_go_read_A_const_80 *lang.Var

var A_arbace_repr_go_read_A_const_81 *lang.Var

var A_arbace_repr_go_read_A_const_82 *lang.Var

var A_arbace_repr_go_read_A_const_83 *lang.Var

var A_arbace_repr_go_read_A_const_84 *lang.Keyword

var A_arbace_repr_go_read_A_const_85 *lang.Keyword

var A_arbace_repr_go_read_A_const_86 *lang.Keyword

var A_arbace_repr_go_read_A_const_87 *lang.Var

var A_arbace_repr_go_read_A_const_88 any

var A_arbace_repr_go_read_A_const_89 *lang.Keyword

var A_arbace_repr_go_read_A_const_90 *lang.Keyword

var A_arbace_repr_go_read_A_const_91 *lang.Var

var A_arbace_repr_go_read_A_const_92 *lang.Var

var A_arbace_repr_go_read_A_const_93 *lang.Var

var A_arbace_repr_go_read_A_const_94 *lang.Var

var A_arbace_repr_go_read_A_const_95 *lang.Var

var A_arbace_repr_go_read_A_const_96 any

var A_arbace_repr_go_read_A_const_97 *lang.Var

var A_arbace_repr_go_read_A_const_98 *lang.Var

var A_arbace_repr_go_read_A_const_99 *lang.Var

var A_arbace_repr_go_read_A_const_100 *lang.Var

var A_arbace_repr_go_read_A_const_101 *lang.Var

var A_arbace_repr_go_read_A_const_102 *lang.Var

var A_arbace_repr_go_read_A_init jrt.ClassInit

func A_arbace_repr_go_read_A_Init() { if !A_arbace_repr_go_read_A_init.Done() { A_arbace_repr_go_read_A_init.Run(A_arbace_repr_go_read_A_clinit) } }

func A_arbace_repr_go_read_A_clinit() { A_arbace_repr_go_read_A_clinit_p0(); A_arbace_repr_go_read_A_clinit_p1(); A_arbace_repr_go_read_A_clinit_p2(); A_arbace_repr_go_read_A_clinit_p3(); A_arbace_repr_go_read_A_clinit_p4(); A_arbace_repr_go_read_A_clinit_p5(); A_arbace_repr_go_read_A_clinit_p6(); A_arbace_repr_go_read_A_clinit_p7(); A_arbace_repr_go_read_A_clinit_p8() }

func A_arbace_repr_go_read_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_read_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 143); A_arbace_repr_go_read_A_const_0 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[40]); A_arbace_repr_go_read_A_const_1 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[41]); A_arbace_repr_go_read_A_const_2 = A_arbace_repr_go_read_A_const_pool.A[42]; A_arbace_repr_go_read_A_const_3 = A_arbace_repr_go_read_A_const_pool.A[43]; A_arbace_repr_go_read_A_const_4 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[44]); A_arbace_repr_go_read_A_const_5 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[45]); A_arbace_repr_go_read_A_const_6 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[46]); A_arbace_repr_go_read_A_const_7 = A_arbace_repr_go_read_A_const_pool.A[47]; A_arbace_repr_go_read_A_const_8 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[48]); A_arbace_repr_go_read_A_const_9 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[49]); A_arbace_repr_go_read_A_const_10 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[50]); A_arbace_repr_go_read_A_const_11 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[51]) }

func A_arbace_repr_go_read_A_clinit_p1() { A_arbace_repr_go_read_A_const_12 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[52]); A_arbace_repr_go_read_A_const_13 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[53]); A_arbace_repr_go_read_A_const_14 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[54]); A_arbace_repr_go_read_A_const_15 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[55]); A_arbace_repr_go_read_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[56]); A_arbace_repr_go_read_A_const_17 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[57]); A_arbace_repr_go_read_A_const_18 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[58]); A_arbace_repr_go_read_A_const_19 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[59]); A_arbace_repr_go_read_A_const_20 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[60]); A_arbace_repr_go_read_A_const_21 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[61]); A_arbace_repr_go_read_A_const_22 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[62]); A_arbace_repr_go_read_A_const_23 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[63]) }

func A_arbace_repr_go_read_A_clinit_p2() { A_arbace_repr_go_read_A_const_24 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[64]); A_arbace_repr_go_read_A_const_25 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[65]); A_arbace_repr_go_read_A_const_26 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[66]); A_arbace_repr_go_read_A_const_27 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[67]); A_arbace_repr_go_read_A_const_28 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[68]); A_arbace_repr_go_read_A_const_29 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[69]); A_arbace_repr_go_read_A_const_30 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[70]); A_arbace_repr_go_read_A_const_31 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[71]); A_arbace_repr_go_read_A_const_32 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[72]); A_arbace_repr_go_read_A_const_33 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[73]); A_arbace_repr_go_read_A_const_34 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[74]); A_arbace_repr_go_read_A_const_35 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[75]) }

func A_arbace_repr_go_read_A_clinit_p3() { A_arbace_repr_go_read_A_const_36 = A_arbace_repr_go_read_A_const_pool.A[76]; A_arbace_repr_go_read_A_const_37 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[77]); A_arbace_repr_go_read_A_const_38 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[78]); A_arbace_repr_go_read_A_const_39 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[79]); A_arbace_repr_go_read_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[80]); A_arbace_repr_go_read_A_const_41 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[81]); A_arbace_repr_go_read_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[82]); A_arbace_repr_go_read_A_const_43 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[83]); A_arbace_repr_go_read_A_const_44 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[84]); A_arbace_repr_go_read_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[85]); A_arbace_repr_go_read_A_const_46 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[86]); A_arbace_repr_go_read_A_const_47 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[87]) }

func A_arbace_repr_go_read_A_clinit_p4() { A_arbace_repr_go_read_A_const_48 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[88]); A_arbace_repr_go_read_A_const_49 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[89]); A_arbace_repr_go_read_A_const_50 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[90]); A_arbace_repr_go_read_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[91]); A_arbace_repr_go_read_A_const_52 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[92]); A_arbace_repr_go_read_A_const_53 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[93]); A_arbace_repr_go_read_A_const_54 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[94]); A_arbace_repr_go_read_A_const_55 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[95]); A_arbace_repr_go_read_A_const_56 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[96]); A_arbace_repr_go_read_A_const_57 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[97]); A_arbace_repr_go_read_A_const_58 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[98]); A_arbace_repr_go_read_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[99]) }

func A_arbace_repr_go_read_A_clinit_p5() { A_arbace_repr_go_read_A_const_60 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[100]); A_arbace_repr_go_read_A_const_61 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[101]); A_arbace_repr_go_read_A_const_62 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[102]); A_arbace_repr_go_read_A_const_63 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[103]); A_arbace_repr_go_read_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[104]); A_arbace_repr_go_read_A_const_65 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[105]); A_arbace_repr_go_read_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[106]); A_arbace_repr_go_read_A_const_67 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[107]); A_arbace_repr_go_read_A_const_68 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[108]); A_arbace_repr_go_read_A_const_69 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[109]); A_arbace_repr_go_read_A_const_70 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[110]); A_arbace_repr_go_read_A_const_71 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[111]) }

func A_arbace_repr_go_read_A_clinit_p6() { A_arbace_repr_go_read_A_const_72 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[112]); A_arbace_repr_go_read_A_const_73 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[113]); A_arbace_repr_go_read_A_const_74 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[114]); A_arbace_repr_go_read_A_const_75 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[115]); A_arbace_repr_go_read_A_const_76 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[116]); A_arbace_repr_go_read_A_const_77 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[117]); A_arbace_repr_go_read_A_const_78 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[118]); A_arbace_repr_go_read_A_const_79 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[119]); A_arbace_repr_go_read_A_const_80 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[120]); A_arbace_repr_go_read_A_const_81 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[121]); A_arbace_repr_go_read_A_const_82 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[122]); A_arbace_repr_go_read_A_const_83 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[123]) }

func A_arbace_repr_go_read_A_clinit_p7() { A_arbace_repr_go_read_A_const_84 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[124]); A_arbace_repr_go_read_A_const_85 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[125]); A_arbace_repr_go_read_A_const_86 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[126]); A_arbace_repr_go_read_A_const_87 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[127]); A_arbace_repr_go_read_A_const_88 = A_arbace_repr_go_read_A_const_pool.A[128]; A_arbace_repr_go_read_A_const_89 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[129]); A_arbace_repr_go_read_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[130]); A_arbace_repr_go_read_A_const_91 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[131]); A_arbace_repr_go_read_A_const_92 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[132]); A_arbace_repr_go_read_A_const_93 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[133]); A_arbace_repr_go_read_A_const_94 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[134]); A_arbace_repr_go_read_A_const_95 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[135]) }

func A_arbace_repr_go_read_A_clinit_p8() { A_arbace_repr_go_read_A_const_96 = A_arbace_repr_go_read_A_const_pool.A[136]; A_arbace_repr_go_read_A_const_97 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[137]); A_arbace_repr_go_read_A_const_98 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[138]); A_arbace_repr_go_read_A_const_99 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[139]); A_arbace_repr_go_read_A_const_100 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[140]); A_arbace_repr_go_read_A_const_101 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[141]); A_arbace_repr_go_read_A_const_102 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[142]) }

func A_arbace_repr_go_read_A_New() *A_arbace_repr_go_read_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_read_A) Ctor() {}

func (t *A_arbace_repr_go_read_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_read_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_read_A_class }

func (t *A_arbace_repr_go_read_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_read_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_read_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_read_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_read_A); return ok }

func A_arbace_repr_go_read_A_Cast(x any) *A_arbace_repr_go_read_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_read_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_read_A_class)) }; return v }



type A_arbace_repr_go_read__main_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read__main_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000068_A struct{ j2g_header uint64; F_G__1652000064, F_opts any }

var A_arbace_repr_go_read__main_fn__1652000068_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000074_A struct{ j2g_header uint64; F_pool any }

var A_arbace_repr_go_read__main_fn__1652000074_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000078_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read__main_fn__1652000078_A_fn_class *jrt.Class



type A_arbace_repr_go_read_check_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_check_A_fn_class *jrt.Class



type A_arbace_repr_go_read_check_type_table_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_check_type_table_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_dump_files_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A struct{ j2g_header uint64; F_iter__1652000039, F_s__1652000040 any }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A struct{ j2g_header uint64; F_s__1652000042, F_iter__1652000041 any }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1652000044 any }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_fn_class *jrt.Class



type A_arbace_repr_go_read_eval1652000004_A struct{ jrt.Object }

func A_arbace_repr_go_read_eval1652000004_A_New() *A_arbace_repr_go_read_eval1652000004_A { t := &A_arbace_repr_go_read_eval1652000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_read_eval1652000004_A) Ctor() {}

func (t *A_arbace_repr_go_read_eval1652000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_read_eval1652000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_read_eval1652000004_A_class }

func (t *A_arbace_repr_go_read_eval1652000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_read_eval1652000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_read_eval1652000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_read_eval1652000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_read_eval1652000004_A); return ok }

func A_arbace_repr_go_read_eval1652000004_A_Cast(x any) *A_arbace_repr_go_read_eval1652000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_read_eval1652000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_read_eval1652000004_A_class)) }; return v }



type A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A_fn_class *jrt.Class



type A_arbace_repr_go_read_eval1652000008_A struct{ jrt.Object }

func A_arbace_repr_go_read_eval1652000008_A_New() *A_arbace_repr_go_read_eval1652000008_A { t := &A_arbace_repr_go_read_eval1652000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_read_eval1652000008_A) Ctor() {}

func (t *A_arbace_repr_go_read_eval1652000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_read_eval1652000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_read_eval1652000008_A_class }

func (t *A_arbace_repr_go_read_eval1652000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_read_eval1652000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_read_eval1652000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_read_eval1652000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_read_eval1652000008_A); return ok }

func A_arbace_repr_go_read_eval1652000008_A_Cast(x any) *A_arbace_repr_go_read_eval1652000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_read_eval1652000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_read_eval1652000008_A_class)) }; return v }



type A_arbace_repr_go_read_eval1652000008_fn__1652000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_eval1652000008_fn__1652000009_A_fn_class *jrt.Class



type A_arbace_repr_go_read_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_node_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_read_nodes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_nodes_A_fn_class *jrt.Class



type A_arbace_repr_go_read_nodes_fn__1652000014_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_nodes_fn__1652000014_A_fn_class *jrt.Class



type A_arbace_repr_go_read_read_dump_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_read_dump_A_fn_class *jrt.Class



type A_arbace_repr_go_read_summary_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_summary_A_fn_class *jrt.Class



type A_arbace_repr_go_read_type_entry_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_type_entry_A_fn_class *jrt.Class



type A_arbace_repr_go_read_type_refs_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_type_refs_A_fn_class *jrt.Class
