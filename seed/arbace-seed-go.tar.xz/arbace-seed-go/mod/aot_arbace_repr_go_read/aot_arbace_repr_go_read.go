//line aot_arbace_repr_go_read.ae:1
package aot_arbace_repr_go_read

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A_New() *A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_read_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_1); lang.IFn_Cast(A_arbace_repr_go_read_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_read_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_25)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_26)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_read_eval1652000008_fn__1652000009_A_New() *A_arbace_repr_go_read_eval1652000008_fn__1652000009_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_eval1652000008_fn__1652000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000008_fn__1652000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_read_eval1652000008_fn__1652000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_go_read_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_go_read_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_read_A_const_7.GetRawRoot__O(), A_arbace_repr_go_read_A_const_8) }













func A_arbace_repr_go_read_read_dump_A_New() *A_arbace_repr_go_read_read_dump_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_read_dump_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_repr_go_read_read_dump_A) Ctor() {}
//line :15:1
func (t *A_arbace_repr_go_read_read_dump_A) Invoke_O_O__O(self, path__0 any) any { var r__2 any; var tmp1 any; var root_19 any = A_arbace_repr_go_read_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_21 lang.IFn; if




	linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = path__0; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_19, arg_22) }; r__2 = /*line :15:1*/jrt.PushbackReader_New_Reader_I(jrt.InputStreamReader_New_InputStream_Charset(jrt.FileInputStream_New_String(jrt.String_Cast(tmp1)), jrt.StandardCharsets_UTF_8), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1, 1024), 1024))); var tmp2 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		{ var root_32 any = A_arbace_repr_go_read_A_const_12.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_read_A_const_14, jrt.Boolean_FALSE.Ref()); if linked_33 == nil { ifn_34.Invoke_O__O(arg_35) } else { linked_33.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_32, arg_35) }; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :15:1
			{ var eof__7 any = jrt.Object_New(); var d__8 any; var root_23 any = A_arbace_repr_go_read_A_const_10.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_25 lang.IFn








				if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = r__2; var arg_27 any = jrt.Boolean_FALSE.Ref(); var arg_28 any = eof__7; if linked_24 == nil { d__8 = ifn_25.Invoke_O_O_O__O(arg_26, arg_27, arg_28) } else { d__8 = linked_24.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_23, arg_26, arg_27, arg_28) }
				if lang.Util_Identical_O_O__Z_NoInit(d__8, eof__7) { var tmp3 any; var root_41 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_43 lang.IFn
					if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, path__0, nil)).Ref(); var arg_45 any; var tmp4 any = A_arbace_repr_go_read_A_const_16; var tmp5 any; var root_46 any = A_arbace_repr_go_read_A_const_9.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = path__0; if linked_47 == nil { tmp5 = ifn_48.Invoke_O__O(arg_49) } else { tmp5 = linked_47.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_46, arg_49) }; arg_45 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)); if linked_42 == nil { tmp3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp3 = linked_42.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }
//line :25:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp3)))
				}
				var tmp6 any; var root_50 any = A_arbace_repr_go_read_A_const_10.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = r__2; var arg_54 any = jrt.Boolean_FALSE.Ref(); var arg_55 any = eof__7; if linked_51 == nil { tmp6 = ifn_52.Invoke_O_O_O__O(arg_53, arg_54, arg_55) } else { tmp6 = linked_51.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_50, arg_53, arg_54, arg_55) }; if lang.Util_Identical_O_O__Z_NoInit(tmp6, eof__7) { } else { var tmp7 any; var root_56 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_58 lang.IFn
					if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, path__0, nil)).Ref(); var arg_60 any; var tmp8 any = A_arbace_repr_go_read_A_const_16; var tmp9 any; var root_61 any = A_arbace_repr_go_read_A_const_9.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = path__0; if linked_62 == nil { tmp9 = ifn_63.Invoke_O__O(arg_64) } else { tmp9 = linked_62.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_61, arg_64) }; arg_60 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)); if linked_57 == nil { tmp7 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { tmp7 = linked_57.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }
//line :27:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))) }
//line :15:1
				tmp2 = d__8
			}





			return nil }(); var root_29 any = A_arbace_repr_go_read_A_const_11.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; if linked_30 == nil { ifn_31.Invoke__O() } else { linked_30.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_29) }
//line :15:1
			if tmp10 != nil { panic(tmp10) } }; return nil }();



	jrt.PushbackReader_Cast(r__2).Close__V(); if /*line :15:1*/ tmp11 != nil { panic(tmp11) }; return tmp2 }















func A_arbace_repr_go_read_node_QMARK__A_New() *A_arbace_repr_go_read_node_QMARK__A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_node_QMARK__A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_go_read_node_QMARK__A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_go_read_node_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_65 any = A_arbace_repr_go_read_A_const_17.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_67 lang.IFn; if


	linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = x__0; if linked_66 == nil { and__1927000168__auto____2 = ifn_67.Invoke_O__O(arg_68) } else { and__1927000168__auto____2 = linked_66.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_65, arg_68) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_69 any = A_arbace_repr_go_read_A_const_18.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = x__0; if linked_74 == nil { arg_72 = ifn_75.Invoke_O__O(arg_76) } else { arg_72 = linked_74.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_73, arg_76) }; if linked_70 == nil { and__1927000168__auto____3 = ifn_71.Invoke_O__O(arg_72) } else { and__1927000168__auto____3 = linked_70.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_77 any = A_arbace_repr_go_read_A_const_20.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var root_81 any = A_arbace_repr_go_read_A_const_21.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = x__0; if linked_82 == nil { arg_80 = ifn_83.Invoke_O__O(arg_84) } else { arg_80 = linked_82.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_81, arg_84) }; if linked_78 == nil { and__1927000168__auto____4 = ifn_79.Invoke_O__O(arg_80) } else { and__1927000168__auto____4 = linked_78.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp1 any; var root_85 any = A_arbace_repr_go_read_A_const_22.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = x__0; if linked_86 == nil { tmp1 = ifn_87.Invoke_O__O(arg_88) } else { tmp1 = linked_86.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_85, arg_88) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, nil)).Ref() } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_read_nodes_A_New() *A_arbace_repr_go_read_nodes_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_nodes_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_repr_go_read_nodes_A) Ctor() {}
//line :36:1
func (t *A_arbace_repr_go_read_nodes_A) Invoke_O_O__O(self, tree__0 any) any {


	var root_89 any = A_arbace_repr_go_read_A_const_23.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = A_arbace_repr_go_read_A_const_24.GetRawRoot__O(); var arg_93 any; var root_94 any = A_arbace_repr_go_read_A_const_25.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_repr_go_read_A_const_26.GetRawRoot__O(); var arg_98 any; var tmp1 any = A_arbace_repr_go_read_nodes_fn__1652000014_A_New(); var tmp2 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_repr_go_read_nodes_fn__1652000014_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_go_read_nodes_fn__1652000014_A_fn_class = fncls__112d; tmp2 = fncls__112d } else { tmp2 = fncls__112 }; arg_98 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_99 any = tree__0; if linked_95 == nil { arg_93 = ifn_96.Invoke_O_O_O__O(arg_97, arg_98, arg_99) } else { arg_93 = linked_95.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_94, arg_97, arg_98, arg_99) }; if linked_90 == nil { return ifn_91.Invoke_O_O__O(arg_92, arg_93) } else { return linked_90.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_89, arg_92, arg_93) } }
//line :39:1
func A_arbace_repr_go_read_nodes_fn__1652000014_A_New() *A_arbace_repr_go_read_nodes_fn__1652000014_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_nodes_fn__1652000014_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_go_read_nodes_fn__1652000014_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_go_read_nodes_fn__1652000014_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_100 any = A_arbace_repr_go_read_A_const_20.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = x__1; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(tmp1) { var root_104 any = A_arbace_repr_go_read_A_const_27.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = x__1; if linked_105 == nil { return ifn_106.Invoke_O__O(arg_107) } else { return linked_105.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_104, arg_107) } } else { var root_108 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = x__1; if linked_109 == nil { return ifn_110.Invoke_O__O(arg_111) } else { return linked_109.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_108, arg_111) } } }

func A_arbace_repr_go_read_type_entry_A_New() *A_arbace_repr_go_read_type_entry_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_type_entry_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_read_type_entry_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_read_type_entry_A) Invoke_O_O_O__O(self, d__0, id__1 any) any {


	return lang.RT_Nth_O_I__O_NoInit(A_arbace_repr_go_read_A_const_29.Invoke_O__O(d__0), lang.RT_IntCast_O__I_NoInit(id__1))
}
func A_arbace_repr_go_read_type_refs_A_New() *A_arbace_repr_go_read_type_refs_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_type_refs_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_repr_go_read_type_refs_A) Ctor() {}
//line :46:1
func (t *A_arbace_repr_go_read_type_refs_A) Invoke_O_O__O(self, e__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_30.GetRawRoot__O()); var tmp2 any; var root_121 any = A_arbace_repr_go_read_A_const_31.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = e__0; var arg_125 any = A_arbace_repr_go_read_A_const_32; if linked_122 == nil { tmp2 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp2 = linked_122.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_repr_go_read_A_const_33.Invoke_O__O(e__0); var tmp5 any = A_arbace_repr_go_read_A_const_34.Invoke_O__O(e__0); var tmp6 any; var root_126 any = A_arbace_repr_go_read_A_const_35.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_128 lang.IFn

	if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = A_arbace_repr_go_read_A_const_36; var arg_130 any = lang.IFn_Cast(A_arbace_repr_go_read_A_const_30.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_read_A_const_37.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_38.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_39.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_40.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_41.Invoke_O__O(e__0), A_arbace_repr_go_read_A_const_42.Invoke_O__O(e__0)); if linked_127 == nil { tmp6 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { tmp6 = linked_127.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_126, arg_129, arg_130) }
//line :49:1
	var tmp7 any = tmp6; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_43.GetRawRoot__O()); var tmp9 any; var root_145 any = A_arbace_repr_go_read_A_const_44.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_147 lang.IFn


	if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = A_arbace_repr_go_read_A_const_36; var arg_149 any = A_arbace_repr_go_read_A_const_45; if linked_146 == nil { tmp9 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { tmp9 = linked_146.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }
//line :49:1
	return tmp1.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp7, tmp8.Invoke_O_O__O(tmp9, A_arbace_repr_go_read_A_const_46.Invoke_O__O(e__0)))
}



func A_arbace_repr_go_read_check_type_table_A_New() *A_arbace_repr_go_read_check_type_table_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_check_type_table_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_repr_go_read_check_type_table_A) Ctor() {}
//line :54:1
func (t *A_arbace_repr_go_read_check_type_table_A) Invoke_O_O__O(self, d__0 any) any { var seq_1652000019__2 any; var root_150 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_152 lang.IFn; if



	linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_154 any = A_arbace_repr_go_read_A_const_47.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = A_arbace_repr_go_read_A_const_48.GetRawRoot__O(); var arg_158 any = A_arbace_repr_go_read_A_const_29.Invoke_O__O(d__0); if linked_155 == nil { arg_153 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { arg_153 = linked_155.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }; if linked_151 == nil { seq_1652000019__2 = ifn_152.Invoke_O__O(arg_153) } else { seq_1652000019__2 = linked_151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_150, arg_153) }; var chunk_1652000020__3 any; var count_1652000021__4 int64 = 0; var i_1652000022__5 int64 = 0; L1:
//line :54:1
	for {



		if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000022__5, count_1652000021__4) { var vec__1652000023__6 any = lang.Indexed_Cast(chunk_1652000020__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000022__5)); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000023__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000023__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____9 any; var root_199 any = A_arbace_repr_go_read_A_const_20.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_201 lang.IFn
			if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = e__8; if linked_200 == nil { and__1927000168__auto____9 = ifn_201.Invoke_O__O(arg_202) } else { and__1927000168__auto____9 = linked_200.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_199, arg_202) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_203 any = A_arbace_repr_go_read_A_const_18.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = A_arbace_repr_go_read_A_const_52.Invoke_O__O(e__8); if linked_204 == nil { tmp1 = ifn_205.Invoke_O__O(arg_206) } else { tmp1 = linked_204.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_203, arg_206) } } else { tmp1 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp1) { } else { var tmp2 any; var root_207 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_209 lang.IFn
				if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__7, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_53.GetRawRoot__O()).Invoke_O__O(e__8))).Ref(); var arg_211 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_54, i__7)); if linked_208 == nil { tmp2 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { tmp2 = linked_208.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }
//line :59:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }
//line :58:1
			var seq_1652000026__9 any; var root_175 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_177 lang.IFn


			if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any; var root_179 any = A_arbace_repr_go_read_A_const_51.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_repr_go_read_type_refs_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = e__8; if linked_180 == nil { arg_178 = ifn_181.Invoke_O__O(arg_182) } else { arg_178 = linked_180.(*A_arbace_repr_go_read_type_refs_A).Invoke_O_O__O(root_179, arg_182) }; if linked_176 == nil { seq_1652000026__9 = ifn_177.Invoke_O__O(arg_178) } else { seq_1652000026__9 = linked_176.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_175, arg_178) }
//line :58:1
			var chunk_1652000027__10 any; var count_1652000028__11 int64 = 0; var i_1652000029__12 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000029__12, count_1652000028__11) { var r__13 any = lang.Indexed_Cast(chunk_1652000027__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000029__12)); var tmp3 any; var and__1927000168__auto____14 any; var root_216 any = A_arbace_repr_go_read_A_const_55.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_int_QMARK__A_fn_class); var ifn_218 lang.IFn
					if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = r__13; if linked_217 == nil { and__1927000168__auto____14 = ifn_218.Invoke_O__O(arg_219) } else { and__1927000168__auto____14 = linked_217.(*aot_arbace_core.A_arbace_core_int_QMARK__A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(and__1927000168__auto____14) { var and__1927000168__auto____15 bool; var na_220 int64 = 0; var na_221 any = r__13; if jrt.Long_InstanceOf(na_221) { var n0_222 int64 = na_220; var n1_223 int64 = jrt.NN(jrt.Long_Cast(na_221)).LongValue__J(); and__1927000168__auto____15 = n0_222 <= n1_223 } else { and__1927000168__auto____15 = lang.Numbers_Lte_J_O__Z_NoInit(na_220, na_221) }; if and__1927000168__auto____15 { var tmp4 bool; var na_225 any = r__13; var na_226 any = i__7; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_225); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_226) }; tmp5 = tmp6; if tmp5 { var n0_227 int64 = jrt.NN(jrt.Long_Cast(na_225)).LongValue__J(); var n1_228 int64 = jrt.NN(jrt.Long_Cast(na_226)).LongValue__J(); tmp4 = n0_227 < n1_228 } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_225); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_226) }; tmp7 = tmp8; if tmp7 { var n0_227_2 float64 = jrt.NN(jrt.Double_Cast(na_225)).DoubleValue__D(); var n1_228_2 float64 = jrt.NN(jrt.Double_Cast(na_226)).DoubleValue__D(); tmp4 = n0_227_2 < n1_228_2 } else { tmp4 = lang.Numbers_Lt_O_O__Z_NoInit(na_225, na_226) } }; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp4).Ref() } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() } } else { tmp3 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp3) { } else { var tmp9 any; var root_230 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_232 lang.IFn
						if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__7, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_53.GetRawRoot__O()).Invoke_O__O(r__13))).Ref(); var arg_234 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_54, i__7, A_arbace_repr_go_read_A_const_56, r__13)); if linked_231 == nil { tmp9 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { tmp9 = linked_231.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) }
//line :62:1
						panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) }
//line :61:1
					seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, i_1652000029__12 = seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000029__12); continue L2 } else { var temp__1927000414__auto____13 any; var root_183 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = seq_1652000026__9; if linked_184 == nil { temp__1927000414__auto____13 = ifn_185.Invoke_O__O(arg_186) } else { temp__1927000414__auto____13 = linked_184.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_183, arg_186) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1652000026__14 any = temp__1927000414__auto____13; var tmp10 any; var root_187 any = A_arbace_repr_go_read_A_const_49.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = seq_1652000026__14; if linked_188 == nil { tmp10 = ifn_189.Invoke_O__O(arg_190) } else { tmp10 = linked_188.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____15 any; var root_191 any = A_arbace_repr_go_read_A_const_50.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = seq_1652000026__14; if linked_192 == nil { c__1927000678__auto____15 = ifn_193.Invoke_O__O(arg_194) } else { c__1927000678__auto____15 = linked_192.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_191, arg_194) }; var tmp11 any; var root_239 any = A_arbace_repr_go_read_A_const_57.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = seq_1652000026__14; if linked_240 == nil { tmp11 = ifn_241.Invoke_O__O(arg_242) } else { tmp11 = linked_240.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_239, arg_242) }; seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, i_1652000029__12 = tmp11, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var r__15 any; var root_195 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = seq_1652000026__14; if linked_196 == nil { r__15 = ifn_197.Invoke_O__O(arg_198) } else { r__15 = linked_196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_195, arg_198) }
						var tmp12 any; var and__1927000168__auto____16 any; var root_243 any = A_arbace_repr_go_read_A_const_55.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_int_QMARK__A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = r__15; if linked_244 == nil { and__1927000168__auto____16 = ifn_245.Invoke_O__O(arg_246) } else { and__1927000168__auto____16 = linked_244.(*aot_arbace_core.A_arbace_core_int_QMARK__A).Invoke_O_O__O(root_243, arg_246) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 bool; var na_247 int64 = 0; var na_248 any = r__15; if jrt.Long_InstanceOf(na_248) { var n0_249 int64 = na_247; var n1_250 int64 = jrt.NN(jrt.Long_Cast(na_248)).LongValue__J(); and__1927000168__auto____17 = n0_249 <= n1_250 } else { and__1927000168__auto____17 = lang.Numbers_Lte_J_O__Z_NoInit(na_247, na_248) }; if and__1927000168__auto____17 { var tmp13 bool; var na_252 any = r__15; var na_253 any = i__7; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_252); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_253) }; tmp14 = tmp15; if tmp14 { var n0_254 int64 = jrt.NN(jrt.Long_Cast(na_252)).LongValue__J(); var n1_255 int64 = jrt.NN(jrt.Long_Cast(na_253)).LongValue__J(); tmp13 = n0_254 < n1_255 } else { var tmp16 bool; var tmp17 bool; tmp17 = jrt.Double_InstanceOf(na_252); if tmp17 { tmp17 = jrt.Double_InstanceOf(na_253) }; tmp16 = tmp17; if tmp16 { var n0_254_2 float64 = jrt.NN(jrt.Double_Cast(na_252)).DoubleValue__D(); var n1_255_2 float64 = jrt.NN(jrt.Double_Cast(na_253)).DoubleValue__D(); tmp13 = n0_254_2 < n1_255_2 } else { tmp13 = lang.Numbers_Lt_O_O__Z_NoInit(na_252, na_253) } }; tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp13).Ref() } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { tmp12 = and__1927000168__auto____16 }; if jrt.J2g_Truth(tmp12) { } else { var tmp18 any; var root_257 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_259 lang.IFn
							if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__7, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_53.GetRawRoot__O()).Invoke_O__O(r__15))).Ref(); var arg_261 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_54, i__7, A_arbace_repr_go_read_A_const_56, r__15)); if linked_258 == nil { tmp18 = ifn_259.Invoke_O_O__O(arg_260, arg_261) } else { tmp18 = linked_258.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_257, arg_260, arg_261) }
//line :62:1
							panic(jrt.Thrown(jrt.Throwable_Cast(tmp18))) }
//line :61:1
						var tmp19 any; var root_266 any = A_arbace_repr_go_read_A_const_58.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1652000026__14; if linked_267 == nil { tmp19 = ifn_268.Invoke_O__O(arg_269) } else { tmp19 = linked_267.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_266, arg_269) }; seq_1652000026__9, chunk_1652000027__10, count_1652000028__11, i_1652000029__12 = tmp19, nil, 0, 0; continue L2 } } }
//line :58:1
				break L2 }; seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, i_1652000022__5 = seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000022__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_159 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = seq_1652000019__2; if linked_160 == nil { temp__1927000414__auto____6 = ifn_161.Invoke_O__O(arg_162) } else { temp__1927000414__auto____6 = linked_160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_159, arg_162) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1652000019__7 any = temp__1927000414__auto____6; var tmp20 any; var root_163 any = A_arbace_repr_go_read_A_const_49.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = seq_1652000019__7; if linked_164 == nil { tmp20 = ifn_165.Invoke_O__O(arg_166) } else { tmp20 = linked_164.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_163, arg_166) }; if jrt.J2g_Truth(tmp20) { var c__1927000678__auto____8 any; var root_167 any = A_arbace_repr_go_read_A_const_50.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = seq_1652000019__7; if linked_168 == nil { c__1927000678__auto____8 = ifn_169.Invoke_O__O(arg_170) } else { c__1927000678__auto____8 = linked_168.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_167, arg_170) }; var tmp21 any; var root_270 any = A_arbace_repr_go_read_A_const_57.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = seq_1652000019__7; if linked_271 == nil { tmp21 = ifn_272.Invoke_O__O(arg_273) } else { tmp21 = linked_271.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_270, arg_273) }; seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, i_1652000022__5 = tmp21, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1652000030__8 any; var root_171 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = seq_1652000019__7; if linked_172 == nil { vec__1652000030__8 = ifn_173.Invoke_O__O(arg_174) } else { vec__1652000030__8 = linked_172.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_171, arg_174) }; var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000030__8, lang.RT_IntCast_J__I_NoInit(0), nil); var e__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000030__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp22 any; var and__1927000168__auto____11 any; var root_298 any = A_arbace_repr_go_read_A_const_20.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_300 lang.IFn
					if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = e__10; if linked_299 == nil { and__1927000168__auto____11 = ifn_300.Invoke_O__O(arg_301) } else { and__1927000168__auto____11 = linked_299.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_298, arg_301) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_302 any = A_arbace_repr_go_read_A_const_18.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_repr_go_read_A_const_52.Invoke_O__O(e__10); if linked_303 == nil { tmp22 = ifn_304.Invoke_O__O(arg_305) } else { tmp22 = linked_303.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_302, arg_305) } } else { tmp22 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp22) { } else { var tmp23 any; var root_306 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_308 lang.IFn
						if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__9, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_53.GetRawRoot__O()).Invoke_O__O(e__10))).Ref(); var arg_310 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_54, i__9)); if linked_307 == nil { tmp23 = ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { tmp23 = linked_307.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) }
//line :59:1
						panic(jrt.Thrown(jrt.Throwable_Cast(tmp23))) }
//line :58:1
					var seq_1652000033__11 any; var root_274 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_276 lang.IFn


					if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any; var root_278 any = A_arbace_repr_go_read_A_const_51.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_repr_go_read_type_refs_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = e__10; if linked_279 == nil { arg_277 = ifn_280.Invoke_O__O(arg_281) } else { arg_277 = linked_279.(*A_arbace_repr_go_read_type_refs_A).Invoke_O_O__O(root_278, arg_281) }; if linked_275 == nil { seq_1652000033__11 = ifn_276.Invoke_O__O(arg_277) } else { seq_1652000033__11 = linked_275.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_274, arg_277) }
//line :58:1
					var chunk_1652000034__12 any; var count_1652000035__13 int64 = 0; var i_1652000036__14 int64 = 0; L3: for {


						if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000036__14, count_1652000035__13) { var r__15_2 any = lang.Indexed_Cast(chunk_1652000034__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000036__14)); var tmp24 any; var and__1927000168__auto____16_2 any; var root_315 any = A_arbace_repr_go_read_A_const_55.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_int_QMARK__A_fn_class); var ifn_317 lang.IFn
							if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = r__15_2; if linked_316 == nil { and__1927000168__auto____16_2 = ifn_317.Invoke_O__O(arg_318) } else { and__1927000168__auto____16_2 = linked_316.(*aot_arbace_core.A_arbace_core_int_QMARK__A).Invoke_O_O__O(root_315, arg_318) }; if jrt.J2g_Truth(and__1927000168__auto____16_2) { var and__1927000168__auto____17_2 bool; var na_319 int64 = 0; var na_320 any = r__15_2; if jrt.Long_InstanceOf(na_320) { var n0_321 int64 = na_319; var n1_322 int64 = jrt.NN(jrt.Long_Cast(na_320)).LongValue__J(); and__1927000168__auto____17_2 = n0_321 <= n1_322 } else { and__1927000168__auto____17_2 = lang.Numbers_Lte_J_O__Z_NoInit(na_319, na_320) }; if and__1927000168__auto____17_2 { var tmp25 bool; var na_324 any = r__15_2; var na_325 any = i__9; var tmp26 bool; var tmp27 bool; tmp27 = jrt.Long_InstanceOf(na_324); if tmp27 { tmp27 = jrt.Long_InstanceOf(na_325) }; tmp26 = tmp27; if tmp26 { var n0_326 int64 = jrt.NN(jrt.Long_Cast(na_324)).LongValue__J(); var n1_327 int64 = jrt.NN(jrt.Long_Cast(na_325)).LongValue__J(); tmp25 = n0_326 < n1_327 } else { var tmp28 bool; var tmp29 bool; tmp29 = jrt.Double_InstanceOf(na_324); if tmp29 { tmp29 = jrt.Double_InstanceOf(na_325) }; tmp28 = tmp29; if tmp28 { var n0_326_2 float64 = jrt.NN(jrt.Double_Cast(na_324)).DoubleValue__D(); var n1_327_2 float64 = jrt.NN(jrt.Double_Cast(na_325)).DoubleValue__D(); tmp25 = n0_326_2 < n1_327_2 } else { tmp25 = lang.Numbers_Lt_O_O__Z_NoInit(na_324, na_325) } }; tmp24 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp25).Ref() } else { tmp24 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17_2).Ref() } } else { tmp24 = and__1927000168__auto____16_2 }; if jrt.J2g_Truth(tmp24) { } else { var tmp30 any; var root_329 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_331 lang.IFn
								if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__9, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_53.GetRawRoot__O()).Invoke_O__O(r__15_2))).Ref(); var arg_333 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_54, i__9, A_arbace_repr_go_read_A_const_56, r__15_2)); if linked_330 == nil { tmp30 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { tmp30 = linked_330.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }
//line :62:1
								panic(jrt.Thrown(jrt.Throwable_Cast(tmp30))) }
//line :61:1
							seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, i_1652000036__14 = seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000036__14); continue L3 } else { var temp__1927000414__auto____15 any; var root_282 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = seq_1652000033__11; if linked_283 == nil { temp__1927000414__auto____15 = ifn_284.Invoke_O__O(arg_285) } else { temp__1927000414__auto____15 = linked_283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_282, arg_285) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1652000033__16 any = temp__1927000414__auto____15; var tmp31 any; var root_286 any = A_arbace_repr_go_read_A_const_49.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = seq_1652000033__16; if linked_287 == nil { tmp31 = ifn_288.Invoke_O__O(arg_289) } else { tmp31 = linked_287.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(tmp31) { var c__1927000678__auto____17 any; var root_290 any = A_arbace_repr_go_read_A_const_50.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = seq_1652000033__16; if linked_291 == nil { c__1927000678__auto____17 = ifn_292.Invoke_O__O(arg_293) } else { c__1927000678__auto____17 = linked_291.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_290, arg_293) }; var tmp32 any; var root_338 any = A_arbace_repr_go_read_A_const_57.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = seq_1652000033__16; if linked_339 == nil { tmp32 = ifn_340.Invoke_O__O(arg_341) } else { tmp32 = linked_339.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_338, arg_341) }; seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, i_1652000036__14 = tmp32, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var r__17 any; var root_294 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = seq_1652000033__16; if linked_295 == nil { r__17 = ifn_296.Invoke_O__O(arg_297) } else { r__17 = linked_295.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_294, arg_297) }
								var tmp33 any; var and__1927000168__auto____18 any; var root_342 any = A_arbace_repr_go_read_A_const_55.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_int_QMARK__A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = r__17; if linked_343 == nil { and__1927000168__auto____18 = ifn_344.Invoke_O__O(arg_345) } else { and__1927000168__auto____18 = linked_343.(*aot_arbace_core.A_arbace_core_int_QMARK__A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var and__1927000168__auto____19 bool; var na_346 int64 = 0; var na_347 any = r__17; if jrt.Long_InstanceOf(na_347) { var n0_348 int64 = na_346; var n1_349 int64 = jrt.NN(jrt.Long_Cast(na_347)).LongValue__J(); and__1927000168__auto____19 = n0_348 <= n1_349 } else { and__1927000168__auto____19 = lang.Numbers_Lte_J_O__Z_NoInit(na_346, na_347) }; if and__1927000168__auto____19 { var tmp34 bool; var na_351 any = r__17; var na_352 any = i__9; var tmp35 bool; var tmp36 bool; tmp36 = jrt.Long_InstanceOf(na_351); if tmp36 { tmp36 = jrt.Long_InstanceOf(na_352) }; tmp35 = tmp36; if tmp35 { var n0_353 int64 = jrt.NN(jrt.Long_Cast(na_351)).LongValue__J(); var n1_354 int64 = jrt.NN(jrt.Long_Cast(na_352)).LongValue__J(); tmp34 = n0_353 < n1_354 } else { var tmp37 bool; var tmp38 bool; tmp38 = jrt.Double_InstanceOf(na_351); if tmp38 { tmp38 = jrt.Double_InstanceOf(na_352) }; tmp37 = tmp38; if tmp37 { var n0_353_2 float64 = jrt.NN(jrt.Double_Cast(na_351)).DoubleValue__D(); var n1_354_2 float64 = jrt.NN(jrt.Double_Cast(na_352)).DoubleValue__D(); tmp34 = n0_353_2 < n1_354_2 } else { tmp34 = lang.Numbers_Lt_O_O__Z_NoInit(na_351, na_352) } }; tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp34).Ref() } else { tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() } } else { tmp33 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp33) { } else { var tmp39 any; var root_356 any = A_arbace_repr_go_read_A_const_15.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_358 lang.IFn
									if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__9, nil, lang.IFn_Cast(A_arbace_repr_go_read_A_const_53.GetRawRoot__O()).Invoke_O__O(r__17))).Ref(); var arg_360 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_read_A_const_54, i__9, A_arbace_repr_go_read_A_const_56, r__17)); if linked_357 == nil { tmp39 = ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { tmp39 = linked_357.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_356, arg_359, arg_360) }
//line :62:1
									panic(jrt.Thrown(jrt.Throwable_Cast(tmp39))) }
//line :61:1
								var tmp40 any; var root_365 any = A_arbace_repr_go_read_A_const_58.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = seq_1652000033__16; if linked_366 == nil { tmp40 = ifn_367.Invoke_O__O(arg_368) } else { tmp40 = linked_366.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_365, arg_368) }; seq_1652000033__11, chunk_1652000034__12, count_1652000035__13, i_1652000036__14 = tmp40, nil, 0, 0; continue L3 } } }
//line :58:1
						break L3 }; var tmp41 any; var root_369 any = A_arbace_repr_go_read_A_const_58.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = seq_1652000019__7; if linked_370 == nil { tmp41 = ifn_371.Invoke_O__O(arg_372) } else { tmp41 = linked_370.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_369, arg_372) }; seq_1652000019__2, chunk_1652000020__3, count_1652000021__4, i_1652000022__5 = tmp41, nil, 0, 0; continue L1 } } }
//line :54:1
		break L1 }; return d__0 }











func A_arbace_repr_go_read_summary_A_New() *A_arbace_repr_go_read_summary_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_summary_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_repr_go_read_summary_A) Ctor() {}
//line :66:1
func (t *A_arbace_repr_go_read_summary_A) Invoke_O_O__O(self, d__0 any) any { var ns__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_43.GetRawRoot__O()); var tmp2 any; var root_378 any = A_arbace_repr_go_read_A_const_59.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_380 lang.IFn; if


	linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = A_arbace_repr_go_read_A_const_60.GetRawRoot__O(); var arg_382 any = A_arbace_repr_go_read_A_const_61; if linked_379 == nil { tmp2 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { tmp2 = linked_379.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) }; ns__2 = tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_go_read_A_const_62.Invoke_O__O(d__0)); var tmp3 any = A_arbace_repr_go_read_A_const_63; var tmp4 any = /*line :66:1*/A_arbace_repr_go_read_A_const_63.Invoke_O__O(d__0); var tmp5 any = A_arbace_repr_go_read_A_const_62; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_62.Invoke_O__O(d__0))).Ref(); var tmp7 any = A_arbace_repr_go_read_A_const_64; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ns__2)).Ref(); var tmp9 any = A_arbace_repr_go_read_A_const_65; var tmp10 any; var root_383 any = A_arbace_repr_go_read_A_const_23.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_385 lang.IFn; if






	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = A_arbace_repr_go_read_A_const_66.GetRawRoot__O(); var arg_387 any = ns__2; if linked_384 == nil { tmp10 = ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { tmp10 = linked_384.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_383, arg_386, arg_387) }; var tmp11 any = /*line :66:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp10)).Ref(); var tmp12 any = A_arbace_repr_go_read_A_const_67; var tmp13 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_67.Invoke_O__O(d__0))).Ref(); var tmp14 any = A_arbace_repr_go_read_A_const_68; var tmp15 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_68.Invoke_O__O(d__0))).Ref(); var tmp16 any = A_arbace_repr_go_read_A_const_69; var tmp17 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_69.Invoke_O__O(d__0))).Ref(); var tmp18 any = A_arbace_repr_go_read_A_const_70; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_read_A_const_29.Invoke_O__O(d__0))).Ref())) }












func A_arbace_repr_go_read_dump_files_A_New() *A_arbace_repr_go_read_dump_files_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_read_dump_files_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_read_dump_files_A) Invoke_O_O__O(self, paths__0 any) any {


	var root_388 any = A_arbace_repr_go_read_A_const_71.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_New(); var tmp2 *jrt.Class; var fncls__495 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_fn_class; if fncls__495 == nil { var fncls__495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_fn_class = fncls__495d; tmp2 = fncls__495d } else { tmp2 = fncls__495 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_391 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(paths__0); if linked_389 == nil { return ifn_390.Invoke_O__O(arg_391) } else { return linked_389.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_388, arg_391) } }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_New() *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A) Ctor() {}
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A) Invoke_O_O__O(self, s__1652000040__1 any) any { var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_New_O_O(self, s__1652000040__1); var tmp2 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_fn_class = fncls__494d; tmp2 = fncls__494d } else { tmp2 = fncls__494 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_New_O_O(p0, p1 any) *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A) Ctor_O_O(c__iter__1652000039, c__s__1652000040 any) { t.F_iter__1652000039 = c__iter__1652000039; t.F_s__1652000040 = c__s__1652000040 }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A) Invoke_O__O(self any) any { { var s__1652000040__1 any; var t_ any = t.F_s__1652000040; t.F_s__1652000040 = nil; s__1652000040__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_392 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = s__1652000040__1; if linked_393 == nil { temp__1927000414__auto____2 = ifn_394.Invoke_O__O(arg_395) } else { temp__1927000414__auto____2 = linked_393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var p__4 any; var root_396 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = xs__1927001018__auto____3; if linked_397 == nil { p__4 = ifn_398.Invoke_O__O(arg_399) } else { p__4 = linked_397.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_396, arg_399) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_New(); var tmp2 *jrt.Class; var fncls__472 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_fn_class; if fncls__472 == nil { var fncls__472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_fn_class = fncls__472d; tmp2 = fncls__472d } else { tmp2 = fncls__472 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_473 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_477 any = A_arbace_repr_go_read_A_const_79.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_479 lang.IFn
															if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = jrt.File_New_String(jrt.String_Cast(p__4)); if linked_478 == nil { tmp4 = ifn_479.Invoke_O__O(arg_480) } else { tmp4 = linked_478.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_477, arg_480) }
//line :82:1
	arg_476 = tmp3.Invoke_O__O(tmp4); if linked_474 == nil { fs__1927001036__auto____6 = ifn_475.Invoke_O__O(arg_476) } else { fs__1927001036__auto____6 = linked_474.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_473, arg_476) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_481 any = A_arbace_repr_go_read_A_const_30.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = fs__1927001036__auto____6; var arg_485 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1652000039); var tmp6 any; var root_486 any = A_arbace_repr_go_read_A_const_78.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = s__1652000040__1; if linked_487 == nil { tmp6 = ifn_488.Invoke_O__O(arg_489) } else { tmp6 = linked_487.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_486, arg_489) }; arg_485 = tmp5.Invoke_O__O(tmp6); if linked_482 == nil { return ifn_483.Invoke_O_O__O(arg_484, arg_485) } else { return linked_482.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_481, arg_484, arg_485) } } else { var tmp7 any; var root_490 any = A_arbace_repr_go_read_A_const_78.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = s__1652000040__1; if linked_491 == nil { tmp7 = ifn_492.Invoke_O__O(arg_493) } else { tmp7 = linked_491.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_490, arg_493) }; s__1652000040__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_New() *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A) Ctor() {}
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A) Invoke_O_O__O(self, s__1652000042__1 any) any { var tmp1 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_New_O_O(s__1652000042__1, self); var tmp2 *jrt.Class; var fncls__471 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_fn_class; if fncls__471 == nil { var fncls__471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_fn_class = fncls__471d; tmp2 = fncls__471d } else { tmp2 = fncls__471 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_New_O_O(p0, p1 any) *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A) Ctor_O_O(c__s__1652000042, c__iter__1652000041 any) { t.F_s__1652000042 = c__s__1652000042; t.F_iter__1652000041 = c__iter__1652000041 }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A) Invoke_O__O(self any) any { { var s__1652000042__1 any; var t_ any = t.F_s__1652000042; t.F_s__1652000042 = nil; s__1652000042__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_400 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = s__1652000042__1; if linked_401 == nil { temp__1927000414__auto____2 = ifn_402.Invoke_O__O(arg_403) } else { temp__1927000414__auto____2 = linked_401.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_400, arg_403) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1652000042__3 any = temp__1927000414__auto____2; var tmp1 any; var root_404 any = A_arbace_repr_go_read_A_const_49.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = s__1652000042__3; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_404, arg_407) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_408 any = A_arbace_repr_go_read_A_const_50.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = s__1652000042__3; if linked_409 == nil { c__1927001037__auto____4 = ifn_410.Invoke_O__O(arg_411) } else { c__1927001037__auto____4 = linked_409.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_408, arg_411) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1652000044__6 any; var root_412 any = A_arbace_repr_go_read_A_const_72.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_413 == nil { b__1652000044__6 = ifn_414.Invoke_O__O(arg_415) } else { b__1652000044__6 = linked_413.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_412, arg_415) }; var tmp2 any = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1652000044__6); var tmp3 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_fn_class = fncls__426d; tmp3 = fncls__426d } else { tmp3 = fncls__426 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_427 any = A_arbace_repr_go_read_A_const_75.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var root_432 any = A_arbace_repr_go_read_A_const_76.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = b__1652000044__6; if linked_433 == nil { arg_430 = ifn_434.Invoke_O__O(arg_435) } else { arg_430 = linked_433.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_432, arg_435) }; var arg_431 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1652000041); var tmp5 any; var root_436 any = A_arbace_repr_go_read_A_const_57.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = s__1652000042__3; if linked_437 == nil { tmp5 = ifn_438.Invoke_O__O(arg_439) } else { tmp5 = linked_437.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_436, arg_439) }; arg_431 = tmp4.Invoke_O__O(tmp5); if linked_428 == nil { return ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { return linked_428.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) } } else { var root_440 any = A_arbace_repr_go_read_A_const_75.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any; var root_445 any = A_arbace_repr_go_read_A_const_76.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = b__1652000044__6; if linked_446 == nil { arg_443 = ifn_447.Invoke_O__O(arg_448) } else { arg_443 = linked_446.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_445, arg_448) }; var arg_444 any; if linked_441 == nil { return ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { return linked_441.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) } } } else { var f__4 any; var root_449 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = s__1652000042__3; if linked_450 == nil { f__4 = ifn_451.Invoke_O__O(arg_452) } else { f__4 = linked_450.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_449, arg_452) }; var tmp6 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()

	if and__1927000168__auto____5 { var root_453 any = A_arbace_repr_go_read_A_const_73.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_457 any = Lit_19; if linked_454 == nil { tmp6 = ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { tmp6 = linked_454.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_453, arg_456, arg_457) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :82:1
	if jrt.J2g_Truth(tmp6) { var root_458 any = A_arbace_repr_go_read_A_const_77.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref(); var arg_462 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1652000041); var tmp8 any; var root_463 any = A_arbace_repr_go_read_A_const_78.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = s__1652000042__3; if linked_464 == nil { tmp8 = ifn_465.Invoke_O__O(arg_466) } else { tmp8 = linked_464.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_463, arg_466) }; arg_462 = tmp7.Invoke_O__O(tmp8); if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else { var tmp9 any; var root_467 any = A_arbace_repr_go_read_A_const_78.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = s__1652000042__3; if linked_468 == nil { tmp9 = ifn_469.Invoke_O__O(arg_470) } else { tmp9 = linked_468.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_467, arg_470) }; s__1652000042__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :82:1
func A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1652000044 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1652000044 = c__b__1652000044 }
//line :82:1
func (t *A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A) Invoke_O__O(self any) any { { var i__1652000043__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1652000043__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1652000043__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()

	if and__1927000168__auto____3 { var root_416 any = A_arbace_repr_go_read_A_const_73.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_420 any = Lit_19; if linked_417 == nil { tmp2 = ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { tmp2 = linked_417.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :82:1
	if jrt.J2g_Truth(tmp2) { var root_421 any = A_arbace_repr_go_read_A_const_74.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = t.F_b__1652000044; var arg_425 any = jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref(); if linked_422 == nil { ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { linked_422.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) }; i__1652000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1652000043__1); continue L1 } else { i__1652000043__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1652000043__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_read_check_A_New() *A_arbace_repr_go_read_check_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_check_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_repr_go_read_check_A) Ctor() {}
//line :87:1
func (t *A_arbace_repr_go_read_check_A) Invoke_O_O__O(self, path__0 any) any { var t0__2 int64 = jrt.System_NanoTime__J(); var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var d__5 any; var root_496 any = A_arbace_repr_go_read_A_const_80.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, A_arbace_repr_go_read_check_type_table_A_fn_class); var ifn_498 lang.IFn


	if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any; var root_500 any = A_arbace_repr_go_read_A_const_81.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_repr_go_read_read_dump_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = path__0; if linked_501 == nil { arg_499 = ifn_502.Invoke_O__O(arg_503) } else { arg_499 = linked_501.(*A_arbace_repr_go_read_read_dump_A).Invoke_O_O__O(root_500, arg_503) }; if linked_497 == nil { d__5 = ifn_498.Invoke_O__O(arg_499) } else { d__5 = linked_497.(*A_arbace_repr_go_read_check_type_table_A).Invoke_O_O__O(root_496, arg_499) }
//line :87:1
	var ms__6 float64 = lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000.0); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_82.GetRawRoot__O()); var tmp3 any; var root_514 any = A_arbace_repr_go_read_A_const_83.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, A_arbace_repr_go_read_summary_A_fn_class); var ifn_516 lang.IFn




	if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = d__5; if linked_515 == nil { tmp3 = ifn_516.Invoke_O__O(arg_517) } else { tmp3 = linked_515.(*A_arbace_repr_go_read_summary_A).Invoke_O_O__O(root_514, arg_517) }; var tmp4 any = tmp3; var tmp5 any = A_arbace_repr_go_read_A_const_16; var tmp6 any = A_arbace_repr_go_read_A_const_84; var tmp7 any = jrt.Double_ValueOf_D__Double_NoInit(ms__6).Ref(); var tmp8 any = A_arbace_repr_go_read_A_const_85; tmp1 = tmp2.Invoke_O_O_O_O_O_O_O__O(tmp4, tmp5, path__0, tmp6, tmp7, tmp8, jrt.Long_ValueOf_J__Long_NoInit(jrt.File_New_String(jrt.String_Cast(path__0)).Length__J()).Ref()) }; return nil }(); if /*line :87:1*/ tmp9 != nil { if true { var e__5 jrt.Throwable_I = tmp9; var tmp10 any = A_arbace_repr_go_read_A_const_16; var tmp11 any = A_arbace_repr_go_read_A_const_86; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil); var tmp13 any; var root_518 any = A_arbace_repr_go_read_A_const_87.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_520 lang.IFn






		if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = e__5; if linked_519 == nil { tmp13 = ifn_520.Invoke_O__O(arg_521) } else { tmp13 = linked_519.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_518, arg_521) }
//line :87:1
		tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, path__0, tmp11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp13)).GetName__String().Ref(), nil, e__5.GetMessage__String().Ref())).Ref())) } }; return tmp1 }








func A_arbace_repr_go_read__main_A_New() *A_arbace_repr_go_read__main_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_repr_go_read__main_A) Ctor() {}
//line :96:1
func (t *A_arbace_repr_go_read__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1652000058__2 any; var opts__2 any = A_arbace_repr_go_read_A_const_88; var G__1652000064__3_ any = args__0; var vec__1652000065__4 any = G__1652000064__3_; var seq__1652000066__5 any; var root_522 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_524 lang.IFn; if
										linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = vec__1652000065__4; if linked_523 == nil { seq__1652000066__5 = ifn_524.Invoke_O__O(arg_525) } else { seq__1652000066__5 = linked_523.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_522, arg_525) }; var first__1652000067__6 any; var root_526 any = /*line :96:1*/A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_528 lang.IFn; if
										linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = seq__1652000066__5; if linked_527 == nil { first__1652000067__6 = ifn_528.Invoke_O__O(arg_529) } else { first__1652000067__6 = linked_527.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_526, arg_529) }; var seq__1652000066__7 any; var root_530 any = /*line :96:1*/A_arbace_repr_go_read_A_const_58.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_532 lang.IFn; if
										linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = seq__1652000066__5; if linked_531 == nil { seq__1652000066__7 = ifn_532.Invoke_O__O(arg_533) } else { seq__1652000066__7 = linked_531.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_530, arg_533) }; var a__8 any = first__1652000067__6; var more__9 any = seq__1652000066__7; var args__10 any = vec__1652000065__4; var tmp1 any = /*line :96:1*/A_arbace_repr_go_read__main_fn__1652000068_A_New_O_O(G__1652000064__3_, opts__2); var tmp2 *jrt.Class; var fncls__571 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000068_A_fn_class; _ = a__8; _ = more__9; _ = args__10; if
										fncls__571 == nil { var fncls__571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_read__main_fn__1652000068_A_fn_class = fncls__571d; tmp2 = fncls__571d } else { tmp2 = fncls__571 }; vec__1652000058__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var opts__3 any = /*line :96:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1652000058__2, lang.RT_IntCast_J__I_NoInit(0), nil); var paths__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1652000058__2, lang.RT_IntCast_J__I_NoInit(1), nil); var files__5 any; var root_572 any = A_arbace_repr_go_read_A_const_92.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_repr_go_read_dump_files_A_fn_class); var ifn_574 lang.IFn; if





	linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = paths__4; if linked_573 == nil { files__5 = ifn_574.Invoke_O__O(arg_575) } else { files__5 = linked_573.(*A_arbace_repr_go_read_dump_files_A).Invoke_O_O__O(root_572, arg_575) }; var t0__6 int64 = /*line :96:1*/jrt.System_NanoTime__J(); var pool__7 any = jrt.Executors_NewFixedThreadPool_I__ExecutorService(lang.RT_IntCast_O__I_NoInit(A_arbace_repr_go_read_A_const_90.Invoke_O__O(opts__3))); var futs__8 any; var root_576 any = A_arbace_repr_go_read_A_const_93.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_578 lang.IFn; if








	linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any; var tmp3 any = A_arbace_repr_go_read__main_fn__1652000074_A_New_O(pool__7); var tmp4 *jrt.Class; var fncls__586 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000074_A_fn_class; if fncls__586 == nil { var fncls__586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_go_read__main_fn__1652000074_A_fn_class = fncls__586d; tmp4 = fncls__586d } else { tmp4 = fncls__586 }; arg_579 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_580 any = files__5; if linked_577 == nil { futs__8 = ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { futs__8 = linked_577.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_576, arg_579, arg_580) }; var rs__9 any; var root_587 any = /*line :96:1*/A_arbace_repr_go_read_A_const_93.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_589 lang.IFn; if









	linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var tmp5 any = A_arbace_repr_go_read__main_fn__1652000078_A_New(); var tmp6 *jrt.Class; var fncls__592 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000078_A_fn_class; if fncls__592 == nil { var fncls__592d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_read__main_fn__1652000078_A_fn_class = fncls__592d; tmp6 = fncls__592d } else { tmp6 = fncls__592 }; arg_590 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_591 any = futs__8; if linked_588 == nil { rs__9 = ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { rs__9 = linked_588.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; var wall__10 float64 = /*line :96:1*/lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__6), 1.0e9); var fails__11 any; var root_593 any = A_arbace_repr_go_read_A_const_23.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_595 lang.IFn; if











	linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = A_arbace_repr_go_read_A_const_86; var arg_597 any = rs__9; if linked_594 == nil { fails__11 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { fails__11 = linked_594.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; var ok__12 any; var root_598 any = /*line :96:1*/A_arbace_repr_go_read_A_const_96.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_600 lang.IFn; if












	linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = A_arbace_repr_go_read_A_const_86; var arg_602 any = rs__9; if linked_599 == nil { ok__12 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { ok__12 = linked_599.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_598, arg_601, arg_602) };
	jrt.ExecutorService_Cast(pool__7).Shutdown__V();
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ExecutorService_Cast(pool__7).AwaitTermination_J_TimeUnit__Z(1, jrt.TimeUnit_MINUTES)); var seq_1652000080__13 any; var root_607 any = /*line :96:1*/A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_609 lang.IFn; if















	linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = rs__9; if linked_608 == nil { seq_1652000080__13 = ifn_609.Invoke_O__O(arg_610) } else { seq_1652000080__13 = linked_608.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_607, arg_610) }; var chunk_1652000081__14 any; var count_1652000082__15 int64 = 0; var i_1652000083__16 int64 = 0; L1:
//line :96:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1652000083__16, count_1652000082__15) { var r__17 any = lang.Indexed_Cast(chunk_1652000081__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1652000083__16))
			if jrt.J2g_Truth(A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__17)) {
				lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(Lit_4, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__17)) } else {
//line :113:1
					var tmp7 any; var root_693 any = A_arbace_repr_go_read_A_const_102.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_695 lang.IFn

					if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = A_arbace_repr_go_read_A_const_89.Invoke_O__O(opts__3); if linked_694 == nil { tmp7 = ifn_695.Invoke_O__O(arg_696) } else { tmp7 = linked_694.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_693, arg_696) }
//line :113:1
					if jrt.J2g_Truth(tmp7) {


						lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_98.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(Lit_5, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_63.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_62.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_64.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_65.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_67.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_68.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_69.Invoke_O__O(r__17), A_arbace_repr_go_read_A_const_70.Invoke_O__O(r__17), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(A_arbace_repr_go_read_A_const_85.Invoke_O__O(r__17), 1000000.0)).Ref(), A_arbace_repr_go_read_A_const_84.Invoke_O__O(r__17))) } }
//line :112:1
			seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, i_1652000083__16 = seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1652000083__16); continue L1 } else { var temp__1927000414__auto____17 any; var root_611 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = seq_1652000080__13; if linked_612 == nil { temp__1927000414__auto____17 = ifn_613.Invoke_O__O(arg_614) } else { temp__1927000414__auto____17 = linked_612.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_611, arg_614) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_1652000080__18 any = temp__1927000414__auto____17; var tmp8 any; var root_615 any = A_arbace_repr_go_read_A_const_49.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = seq_1652000080__18; if linked_616 == nil { tmp8 = ifn_617.Invoke_O__O(arg_618) } else { tmp8 = linked_616.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_615, arg_618) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____19 any; var root_619 any = A_arbace_repr_go_read_A_const_50.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = seq_1652000080__18; if linked_620 == nil { c__1927000678__auto____19 = ifn_621.Invoke_O__O(arg_622) } else { c__1927000678__auto____19 = linked_620.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_619, arg_622) }; var tmp9 any; var root_716 any = A_arbace_repr_go_read_A_const_57.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = seq_1652000080__18; if linked_717 == nil { tmp9 = ifn_718.Invoke_O__O(arg_719) } else { tmp9 = linked_717.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_716, arg_719) }; seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, i_1652000083__16 = tmp9, c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__19 any; var root_623 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = seq_1652000080__18; if linked_624 == nil { r__19 = ifn_625.Invoke_O__O(arg_626) } else { r__19 = linked_624.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_623, arg_626) }
				if jrt.J2g_Truth(A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__19)) {
					lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O_O_O__O(Lit_4, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_86.Invoke_O__O(r__19)) } else {
//line :113:1
						var tmp10 any; var root_726 any = A_arbace_repr_go_read_A_const_102.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_728 lang.IFn

						if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = A_arbace_repr_go_read_A_const_89.Invoke_O__O(opts__3); if linked_727 == nil { tmp10 = ifn_728.Invoke_O__O(arg_729) } else { tmp10 = linked_727.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_726, arg_729) }
//line :113:1
						if jrt.J2g_Truth(tmp10) {


							lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_read_A_const_98.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(Lit_5, A_arbace_repr_go_read_A_const_16.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_63.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_62.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_64.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_65.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_67.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_68.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_69.Invoke_O__O(r__19), A_arbace_repr_go_read_A_const_70.Invoke_O__O(r__19), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(A_arbace_repr_go_read_A_const_85.Invoke_O__O(r__19), 1000000.0)).Ref(), A_arbace_repr_go_read_A_const_84.Invoke_O__O(r__19))) } }
//line :112:1
				var tmp11 any; var root_749 any = A_arbace_repr_go_read_A_const_58.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = seq_1652000080__18; if linked_750 == nil { tmp11 = ifn_751.Invoke_O__O(arg_752) } else { tmp11 = linked_750.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_749, arg_752) }; seq_1652000080__13, chunk_1652000081__14, count_1652000082__15, i_1652000083__16 = tmp11, nil, 0, 0; continue L1 } } }
//line :96:1
		break L1 }; var tmp12 lang.IFn =






















	lang.IFn_Cast(A_arbace_repr_go_read_A_const_97.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_read_A_const_98.GetRawRoot__O()); var tmp14 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ok__12)).Ref(); var tmp15 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rs__9)).Ref(); var tmp16 any; var root_644 any = A_arbace_repr_go_read_A_const_99.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_646 lang.IFn; if
	linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = A_arbace_repr_go_read_A_const_100.GetRawRoot__O(); var arg_648 any; var root_649 any = A_arbace_repr_go_read_A_const_35.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = A_arbace_repr_go_read_A_const_85; var arg_653 any = ok__12; if linked_650 == nil { arg_648 = ifn_651.Invoke_O_O__O(arg_652, arg_653) } else { arg_648 = linked_650.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_649, arg_652, arg_653) }; if linked_645 == nil { tmp16 = ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { tmp16 = linked_645.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) }; var tmp17 any = /*line :119:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(tmp16, 1000000.0)).Ref(); var tmp18 any; var root_654 any = A_arbace_repr_go_read_A_const_99.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_656 lang.IFn; if

	linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = A_arbace_repr_go_read_A_const_100.GetRawRoot__O(); var arg_658 any; var root_659 any = A_arbace_repr_go_read_A_const_35.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = A_arbace_repr_go_read_A_const_64; var arg_663 any = ok__12; if linked_660 == nil { arg_658 = ifn_661.Invoke_O_O__O(arg_662, arg_663) } else { arg_658 = linked_660.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_659, arg_662, arg_663) }; if linked_655 == nil { tmp18 = ifn_656.Invoke_O_O__O(arg_657, arg_658) } else { tmp18 = linked_655.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_654, arg_657, arg_658) }; var tmp19 any = tmp18; var tmp20 any; var root_664 any = /*line :119:1*/A_arbace_repr_go_read_A_const_99.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_666 lang.IFn; if

	linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = A_arbace_repr_go_read_A_const_100.GetRawRoot__O(); var arg_668 any; var root_669 any = A_arbace_repr_go_read_A_const_35.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = A_arbace_repr_go_read_A_const_70; var arg_673 any = ok__12; if linked_670 == nil { arg_668 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { arg_668 = linked_670.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; if linked_665 == nil { tmp20 = ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { tmp20 = linked_665.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_664, arg_667, arg_668) }; var tmp21 any = tmp20; var tmp22 any; var root_674 any = /*line :119:1*/A_arbace_repr_go_read_A_const_99.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_676 lang.IFn; if


	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = A_arbace_repr_go_read_A_const_100.GetRawRoot__O(); var arg_678 any; var root_679 any = A_arbace_repr_go_read_A_const_35.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = A_arbace_repr_go_read_A_const_67; var arg_683 any = ok__12; if linked_680 == nil { arg_678 = ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { arg_678 = linked_680.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }; if linked_675 == nil { tmp22 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { tmp22 = linked_675.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; /*line :119:1*/tmp12.Invoke_O__O(tmp13.Invoke_O_O_O_O_O_O_O_O_O_O__O(Lit_6, tmp14, tmp15, tmp17, tmp19, tmp21, tmp22, jrt.Double_ValueOf_D__Double_NoInit(wall__10).Ref(), A_arbace_repr_go_read_A_const_90.Invoke_O__O(opts__3), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fails__11)).Ref())); var root_684 any =




	A_arbace_repr_go_read_A_const_101.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; if linked_685 == nil { ifn_686.Invoke__O() } else { linked_685.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_684) }; var tmp23 int64; var tmp24 any; var root_603 any =
	A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = fails__11; if linked_604 == nil { tmp24 = ifn_605.Invoke_O__O(arg_606) } else { tmp24 = linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) }; if jrt.J2g_Truth(tmp24) { tmp23 = 1 } else { tmp23 = 0 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp23)); return nil }
//line :97:1
func A_arbace_repr_go_read__main_fn__1652000068_A_New_O_O(p0, p1 any) *A_arbace_repr_go_read__main_fn__1652000068_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000068_A{}; t.Ctor_O_O(p0, p1); return t }
//line :97:1
func (t *A_arbace_repr_go_read__main_fn__1652000068_A) Ctor_O_O(c__G__1652000064, c__opts any) { t.F_G__1652000064 = c__G__1652000064; t.F_opts = c__opts }
//line :97:1
func (t *A_arbace_repr_go_read__main_fn__1652000068_A) Invoke_O__O(self any) any { { var opts__1 any; var t_ any = t.F_opts; t.F_opts = nil; opts__1 = t_; var G__1652000064__2_ any; var t__2 any = t.F_G__1652000064; t.F_G__1652000064 = nil; G__1652000064__2_ = t__2; L1: for { var opts__3 any = opts__1; var vec__1652000069__4 any = G__1652000064__2_; var seq__1652000070__5 any; var root_534 any = A_arbace_repr_go_read_A_const_28.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = vec__1652000069__4; if linked_535 == nil { seq__1652000070__5 = ifn_536.Invoke_O__O(arg_537) } else { seq__1652000070__5 = linked_535.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_534, arg_537) }; var first__1652000071__6 any; var root_538 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = seq__1652000070__5; if linked_539 == nil { first__1652000071__6 = ifn_540.Invoke_O__O(arg_541) } else { first__1652000071__6 = linked_539.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_538, arg_541) }; var seq__1652000070__7 any; var root_542 any = A_arbace_repr_go_read_A_const_58.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = seq__1652000070__5; if linked_543 == nil { seq__1652000070__7 = ifn_544.Invoke_O__O(arg_545) } else { seq__1652000070__7 = linked_543.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_542, arg_545) }; var a__8 any = first__1652000071__6; var more__9 any = seq__1652000070__7; var args__10 any = vec__1652000069__4; var G__1652000072__11_ any = a__8
											switch lang.Util_Hash_O__I_NoInit(G__1652000072__11_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1652000072__11_, Lit_7) {

		var tmp1 any; var root_547 any = A_arbace_repr_go_read_A_const_82.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = opts__3; var arg_551 any = A_arbace_repr_go_read_A_const_89; var arg_552 any = jrt.Boolean_TRUE.Ref(); if linked_548 == nil { tmp1 = ifn_549.Invoke_O_O_O__O(arg_550, arg_551, arg_552) } else { tmp1 = linked_548.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_547, arg_550, arg_551, arg_552) }; opts__1, G__1652000064__2_ = tmp1, more__9; continue L1 }
//line :98:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1652000072__11_, Lit_8) {
		var tmp2 any; var root_553 any = A_arbace_repr_go_read_A_const_82.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = opts__3; var arg_557 any = A_arbace_repr_go_read_A_const_90; var arg_558 any; var root_559 any = A_arbace_repr_go_read_A_const_91.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_parse_long_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any; var root_563 any = A_arbace_repr_go_read_A_const_19.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = more__9; if linked_564 == nil { arg_562 = ifn_565.Invoke_O__O(arg_566) } else { arg_562 = linked_564.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_563, arg_566) }; if linked_560 == nil { arg_558 = ifn_561.Invoke_O__O(arg_562) } else { arg_558 = linked_560.(*aot_arbace_core.A_arbace_core_parse_long_A).Invoke_O_O__O(root_559, arg_562) }; if linked_554 == nil { tmp2 = ifn_555.Invoke_O_O_O__O(arg_556, arg_557, arg_558) } else { tmp2 = linked_554.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_553, arg_556, arg_557, arg_558) }; var tmp3 any = tmp2; var tmp4 any; var root_567 any = A_arbace_repr_go_read_A_const_78.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = more__9; if linked_568 == nil { tmp4 = ifn_569.Invoke_O__O(arg_570) } else { tmp4 = linked_568.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_567, arg_570) }; opts__1, G__1652000064__2_ = tmp3, tmp4; continue L1 }
//line :98:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__3, args__10) } }; /*line :97:1*/panic("j2g: unreachable") }







func A_arbace_repr_go_read__main_fn__1652000074_A_New_O(p0 any) *A_arbace_repr_go_read__main_fn__1652000074_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000074_A{}; t.Ctor_O(p0); return t }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_A) Ctor_O(c__pool any) { t.F_pool = c__pool }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 jrt.ExecutorService = jrt.ExecutorService_Cast(t.F_pool); var tmp2 any = A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_New_O(f__1); var tmp3 *jrt.Class; var fncls__585 *jrt.Class = A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_fn_class; if fncls__585 == nil { var fncls__585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_fn_class = fncls__585d; tmp3 = fncls__585d } else { tmp3 = fncls__585 }; return tmp1.Submit_Callable__Future(jrt.Callable_Cast(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).WithMeta_IPersistentMap__IObj(lang.IPersistentMap_Cast(A_arbace_repr_go_read_A_const_95)))) }
//line :105:1
func A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_New_O(p0 any) *A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A{}; t.Ctor_O(p0); return t }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :105:1
func (t *A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A) Invoke_O__O(self any) any { var root_581 any = A_arbace_repr_go_read_A_const_94.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_repr_go_read_check_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = t.F_f; if linked_582 == nil { return ifn_583.Invoke_O__O(arg_584) } else { return linked_582.(*A_arbace_repr_go_read_check_A).Invoke_O_O__O(root_581, arg_584) } }
func A_arbace_repr_go_read__main_fn__1652000078_A_New() *A_arbace_repr_go_read__main_fn__1652000078_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read__main_fn__1652000078_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_repr_go_read__main_fn__1652000078_A) Ctor() {}
//line :106:1
func (t *A_arbace_repr_go_read__main_fn__1652000078_A) Invoke_O_O__O(self, p1__1652000057_SHARP___1 any) any { return jrt.Future_Cast(p1__1652000057_SHARP___1).Get__O() }














































type A_arbace_repr_go_read_A struct{ jrt.Object }

var A_arbace_repr_go_read_A_const_pool *jrt.RefArray

var A_arbace_repr_go_read_A_const_0 *lang.Var

var A_arbace_repr_go_read_A_const_1 any

var A_arbace_repr_go_read_A_const_2 *lang.Var

var A_arbace_repr_go_read_A_const_3 any

var A_arbace_repr_go_read_A_const_4 *lang.Var

var A_arbace_repr_go_read_A_const_5 *lang.Var

var A_arbace_repr_go_read_A_const_6 *lang.Var

var A_arbace_repr_go_read_A_const_7 *lang.Var

var A_arbace_repr_go_read_A_const_8 any

var A_arbace_repr_go_read_A_const_9 *lang.Var

var A_arbace_repr_go_read_A_const_10 *lang.Var

var A_arbace_repr_go_read_A_const_11 *lang.Var

var A_arbace_repr_go_read_A_const_12 *lang.Var

var A_arbace_repr_go_read_A_const_13 *lang.Var

var A_arbace_repr_go_read_A_const_14 *lang.Var

var A_arbace_repr_go_read_A_const_15 *lang.Var

var A_arbace_repr_go_read_A_const_16 *lang.Keyword

var A_arbace_repr_go_read_A_const_17 *lang.Var

var A_arbace_repr_go_read_A_const_18 *lang.Var

var A_arbace_repr_go_read_A_const_19 *lang.Var

var A_arbace_repr_go_read_A_const_20 *lang.Var

var A_arbace_repr_go_read_A_const_21 *lang.Var

var A_arbace_repr_go_read_A_const_22 *lang.Var

var A_arbace_repr_go_read_A_const_23 *lang.Var

var A_arbace_repr_go_read_A_const_24 *lang.Var

var A_arbace_repr_go_read_A_const_25 *lang.Var

var A_arbace_repr_go_read_A_const_26 *lang.Var

var A_arbace_repr_go_read_A_const_27 *lang.Var

var A_arbace_repr_go_read_A_const_28 *lang.Var

var A_arbace_repr_go_read_A_const_29 *lang.Keyword

var A_arbace_repr_go_read_A_const_30 *lang.Var

var A_arbace_repr_go_read_A_const_31 *lang.Var

var A_arbace_repr_go_read_A_const_32 any

var A_arbace_repr_go_read_A_const_33 *lang.Keyword

var A_arbace_repr_go_read_A_const_34 *lang.Keyword

var A_arbace_repr_go_read_A_const_35 *lang.Var

var A_arbace_repr_go_read_A_const_36 *lang.Keyword

var A_arbace_repr_go_read_A_const_37 *lang.Keyword

var A_arbace_repr_go_read_A_const_38 *lang.Keyword

var A_arbace_repr_go_read_A_const_39 *lang.Keyword

var A_arbace_repr_go_read_A_const_40 *lang.Keyword

var A_arbace_repr_go_read_A_const_41 *lang.Keyword

var A_arbace_repr_go_read_A_const_42 *lang.Keyword

var A_arbace_repr_go_read_A_const_43 *lang.Var

var A_arbace_repr_go_read_A_const_44 *lang.Var

var A_arbace_repr_go_read_A_const_45 *lang.Keyword

var A_arbace_repr_go_read_A_const_46 *lang.Keyword

var A_arbace_repr_go_read_A_const_47 *lang.Var

var A_arbace_repr_go_read_A_const_48 *lang.Var

var A_arbace_repr_go_read_A_const_49 *lang.Var

var A_arbace_repr_go_read_A_const_50 *lang.Var

var A_arbace_repr_go_read_A_const_51 *lang.Var

var A_arbace_repr_go_read_A_const_52 *lang.Keyword

var A_arbace_repr_go_read_A_const_53 *lang.Var

var A_arbace_repr_go_read_A_const_54 *lang.Keyword

var A_arbace_repr_go_read_A_const_55 *lang.Var

var A_arbace_repr_go_read_A_const_56 *lang.Keyword

var A_arbace_repr_go_read_A_const_57 *lang.Var

var A_arbace_repr_go_read_A_const_58 *lang.Var

var A_arbace_repr_go_read_A_const_59 *lang.Var

var A_arbace_repr_go_read_A_const_60 *lang.Var

var A_arbace_repr_go_read_A_const_61 *lang.Keyword

var A_arbace_repr_go_read_A_const_62 *lang.Keyword

var A_arbace_repr_go_read_A_const_63 *lang.Keyword

var A_arbace_repr_go_read_A_const_64 *lang.Keyword

var A_arbace_repr_go_read_A_const_65 *lang.Keyword

var A_arbace_repr_go_read_A_const_66 *lang.Var

var A_arbace_repr_go_read_A_const_67 *lang.Keyword

var A_arbace_repr_go_read_A_const_68 *lang.Keyword

var A_arbace_repr_go_read_A_const_69 *lang.Keyword

var A_arbace_repr_go_read_A_const_70 *lang.Keyword

var A_arbace_repr_go_read_A_const_71 *lang.Var

var A_arbace_repr_go_read_A_const_72 *lang.Var

var A_arbace_repr_go_read_A_const_73 *lang.Var

var A_arbace_repr_go_read_A_const_74 *lang.Var

var A_arbace_repr_go_read_A_const_75 *lang.Var

var A_arbace_repr_go_read_A_const_76 *lang.Var

var A_arbace_repr_go_read_A_const_77 *lang.Var

var A_arbace_repr_go_read_A_const_78 *lang.Var

var A_arbace_repr_go_read_A_const_79 *lang.Var

var A_arbace_repr_go_read_A_const_80 *lang.Var

var A_arbace_repr_go_read_A_const_81 *lang.Var

var A_arbace_repr_go_read_A_const_82 *lang.Var

var A_arbace_repr_go_read_A_const_83 *lang.Var

var A_arbace_repr_go_read_A_const_84 *lang.Keyword

var A_arbace_repr_go_read_A_const_85 *lang.Keyword

var A_arbace_repr_go_read_A_const_86 *lang.Keyword

var A_arbace_repr_go_read_A_const_87 *lang.Var

var A_arbace_repr_go_read_A_const_88 any

var A_arbace_repr_go_read_A_const_89 *lang.Keyword

var A_arbace_repr_go_read_A_const_90 *lang.Keyword

var A_arbace_repr_go_read_A_const_91 *lang.Var

var A_arbace_repr_go_read_A_const_92 *lang.Var

var A_arbace_repr_go_read_A_const_93 *lang.Var

var A_arbace_repr_go_read_A_const_94 *lang.Var

var A_arbace_repr_go_read_A_const_95 any

var A_arbace_repr_go_read_A_const_96 *lang.Var

var A_arbace_repr_go_read_A_const_97 *lang.Var

var A_arbace_repr_go_read_A_const_98 *lang.Var

var A_arbace_repr_go_read_A_const_99 *lang.Var

var A_arbace_repr_go_read_A_const_100 *lang.Var

var A_arbace_repr_go_read_A_const_101 *lang.Var

var A_arbace_repr_go_read_A_const_102 *lang.Var

var A_arbace_repr_go_read_A_init jrt.ClassInit

func A_arbace_repr_go_read_A_Init() { if !A_arbace_repr_go_read_A_init.Done() { A_arbace_repr_go_read_A_init.Run(A_arbace_repr_go_read_A_clinit) } }

func A_arbace_repr_go_read_A_clinit() { A_arbace_repr_go_read_A_clinit_p0(); A_arbace_repr_go_read_A_clinit_p1(); A_arbace_repr_go_read_A_clinit_p2(); A_arbace_repr_go_read_A_clinit_p3(); A_arbace_repr_go_read_A_clinit_p4(); A_arbace_repr_go_read_A_clinit_p5(); A_arbace_repr_go_read_A_clinit_p6(); A_arbace_repr_go_read_A_clinit_p7(); A_arbace_repr_go_read_A_clinit_p8() }

func A_arbace_repr_go_read_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_read_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 143); A_arbace_repr_go_read_A_const_0 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[40]); A_arbace_repr_go_read_A_const_1 = A_arbace_repr_go_read_A_const_pool.A[41]; A_arbace_repr_go_read_A_const_2 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[42]); A_arbace_repr_go_read_A_const_3 = A_arbace_repr_go_read_A_const_pool.A[43]; A_arbace_repr_go_read_A_const_4 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[44]); A_arbace_repr_go_read_A_const_5 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[45]); A_arbace_repr_go_read_A_const_6 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[46]); A_arbace_repr_go_read_A_const_7 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[47]); A_arbace_repr_go_read_A_const_8 = A_arbace_repr_go_read_A_const_pool.A[48]; A_arbace_repr_go_read_A_const_9 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[49]); A_arbace_repr_go_read_A_const_10 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[50]); A_arbace_repr_go_read_A_const_11 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[51]) }

func A_arbace_repr_go_read_A_clinit_p1() { A_arbace_repr_go_read_A_const_12 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[52]); A_arbace_repr_go_read_A_const_13 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[53]); A_arbace_repr_go_read_A_const_14 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[54]); A_arbace_repr_go_read_A_const_15 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[55]); A_arbace_repr_go_read_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[56]); A_arbace_repr_go_read_A_const_17 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[57]); A_arbace_repr_go_read_A_const_18 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[58]); A_arbace_repr_go_read_A_const_19 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[59]); A_arbace_repr_go_read_A_const_20 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[60]); A_arbace_repr_go_read_A_const_21 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[61]); A_arbace_repr_go_read_A_const_22 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[62]); A_arbace_repr_go_read_A_const_23 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[63]) }

func A_arbace_repr_go_read_A_clinit_p2() { A_arbace_repr_go_read_A_const_24 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[64]); A_arbace_repr_go_read_A_const_25 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[65]); A_arbace_repr_go_read_A_const_26 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[66]); A_arbace_repr_go_read_A_const_27 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[67]); A_arbace_repr_go_read_A_const_28 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[68]); A_arbace_repr_go_read_A_const_29 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[69]); A_arbace_repr_go_read_A_const_30 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[70]); A_arbace_repr_go_read_A_const_31 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[71]); A_arbace_repr_go_read_A_const_32 = A_arbace_repr_go_read_A_const_pool.A[72]; A_arbace_repr_go_read_A_const_33 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[73]); A_arbace_repr_go_read_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[74]); A_arbace_repr_go_read_A_const_35 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[75]) }

func A_arbace_repr_go_read_A_clinit_p3() { A_arbace_repr_go_read_A_const_36 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[76]); A_arbace_repr_go_read_A_const_37 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[77]); A_arbace_repr_go_read_A_const_38 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[78]); A_arbace_repr_go_read_A_const_39 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[79]); A_arbace_repr_go_read_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[80]); A_arbace_repr_go_read_A_const_41 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[81]); A_arbace_repr_go_read_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[82]); A_arbace_repr_go_read_A_const_43 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[83]); A_arbace_repr_go_read_A_const_44 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[84]); A_arbace_repr_go_read_A_const_45 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[85]); A_arbace_repr_go_read_A_const_46 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[86]); A_arbace_repr_go_read_A_const_47 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[87]) }

func A_arbace_repr_go_read_A_clinit_p4() { A_arbace_repr_go_read_A_const_48 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[88]); A_arbace_repr_go_read_A_const_49 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[89]); A_arbace_repr_go_read_A_const_50 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[90]); A_arbace_repr_go_read_A_const_51 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[91]); A_arbace_repr_go_read_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[92]); A_arbace_repr_go_read_A_const_53 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[93]); A_arbace_repr_go_read_A_const_54 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[94]); A_arbace_repr_go_read_A_const_55 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[95]); A_arbace_repr_go_read_A_const_56 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[96]); A_arbace_repr_go_read_A_const_57 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[97]); A_arbace_repr_go_read_A_const_58 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[98]); A_arbace_repr_go_read_A_const_59 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[99]) }

func A_arbace_repr_go_read_A_clinit_p5() { A_arbace_repr_go_read_A_const_60 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[100]); A_arbace_repr_go_read_A_const_61 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[101]); A_arbace_repr_go_read_A_const_62 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[102]); A_arbace_repr_go_read_A_const_63 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[103]); A_arbace_repr_go_read_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[104]); A_arbace_repr_go_read_A_const_65 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[105]); A_arbace_repr_go_read_A_const_66 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[106]); A_arbace_repr_go_read_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[107]); A_arbace_repr_go_read_A_const_68 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[108]); A_arbace_repr_go_read_A_const_69 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[109]); A_arbace_repr_go_read_A_const_70 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[110]); A_arbace_repr_go_read_A_const_71 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[111]) }

func A_arbace_repr_go_read_A_clinit_p6() { A_arbace_repr_go_read_A_const_72 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[112]); A_arbace_repr_go_read_A_const_73 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[113]); A_arbace_repr_go_read_A_const_74 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[114]); A_arbace_repr_go_read_A_const_75 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[115]); A_arbace_repr_go_read_A_const_76 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[116]); A_arbace_repr_go_read_A_const_77 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[117]); A_arbace_repr_go_read_A_const_78 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[118]); A_arbace_repr_go_read_A_const_79 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[119]); A_arbace_repr_go_read_A_const_80 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[120]); A_arbace_repr_go_read_A_const_81 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[121]); A_arbace_repr_go_read_A_const_82 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[122]); A_arbace_repr_go_read_A_const_83 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[123]) }

func A_arbace_repr_go_read_A_clinit_p7() { A_arbace_repr_go_read_A_const_84 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[124]); A_arbace_repr_go_read_A_const_85 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[125]); A_arbace_repr_go_read_A_const_86 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[126]); A_arbace_repr_go_read_A_const_87 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[127]); A_arbace_repr_go_read_A_const_88 = A_arbace_repr_go_read_A_const_pool.A[128]; A_arbace_repr_go_read_A_const_89 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[129]); A_arbace_repr_go_read_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_read_A_const_pool.A[130]); A_arbace_repr_go_read_A_const_91 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[131]); A_arbace_repr_go_read_A_const_92 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[132]); A_arbace_repr_go_read_A_const_93 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[133]); A_arbace_repr_go_read_A_const_94 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[134]); A_arbace_repr_go_read_A_const_95 = A_arbace_repr_go_read_A_const_pool.A[135] }

func A_arbace_repr_go_read_A_clinit_p8() { A_arbace_repr_go_read_A_const_96 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[136]); A_arbace_repr_go_read_A_const_97 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[137]); A_arbace_repr_go_read_A_const_98 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[138]); A_arbace_repr_go_read_A_const_99 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[139]); A_arbace_repr_go_read_A_const_100 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[140]); A_arbace_repr_go_read_A_const_101 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[141]); A_arbace_repr_go_read_A_const_102 = lang.Var_Cast(A_arbace_repr_go_read_A_const_pool.A[142]) }

func A_arbace_repr_go_read_A_New() *A_arbace_repr_go_read_A { A_arbace_repr_go_read_A_Init(); t := &A_arbace_repr_go_read_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_read_A) Ctor() {}

func (t *A_arbace_repr_go_read_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_read_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_read_A_class }

func (t *A_arbace_repr_go_read_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_read_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_read_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_read_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_read_A); return ok }

func A_arbace_repr_go_read_A_Cast(x any) *A_arbace_repr_go_read_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_read_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_read_A_class)) }; return v }



type A_arbace_repr_go_read__main_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read__main_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000068_A struct{ j2g_header uint64; F_G__1652000064, F_opts any }

var A_arbace_repr_go_read__main_fn__1652000068_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000074_A struct{ j2g_header uint64; F_pool any }

var A_arbace_repr_go_read__main_fn__1652000074_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A struct{ j2g_header uint64; F_f any }

var A_arbace_repr_go_read__main_fn__1652000074_fn__1652000075_A_fn_class *jrt.Class



type A_arbace_repr_go_read__main_fn__1652000078_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read__main_fn__1652000078_A_fn_class *jrt.Class



type A_arbace_repr_go_read_check_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_check_A_fn_class *jrt.Class



type A_arbace_repr_go_read_check_type_table_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_check_type_table_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_dump_files_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A struct{ j2g_header uint64; F_iter__1652000039, F_s__1652000040 any }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A struct{ j2g_header uint64; F_s__1652000042, F_iter__1652000041 any }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_A_fn_class *jrt.Class



type A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1652000044 any }

var A_arbace_repr_go_read_dump_files_iter__1652000039__1652000045_fn__1652000046_iter__1652000041__1652000047_fn__1652000048_fn__1652000049_A_fn_class *jrt.Class



type A_arbace_repr_go_read_eval1652000004_A struct{ jrt.Object }

func A_arbace_repr_go_read_eval1652000004_A_New() *A_arbace_repr_go_read_eval1652000004_A { t := &A_arbace_repr_go_read_eval1652000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_read_eval1652000004_A) Ctor() {}

func (t *A_arbace_repr_go_read_eval1652000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_read_eval1652000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_read_eval1652000004_A_class }

func (t *A_arbace_repr_go_read_eval1652000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_read_eval1652000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_read_eval1652000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_read_eval1652000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_read_eval1652000004_A); return ok }

func A_arbace_repr_go_read_eval1652000004_A_Cast(x any) *A_arbace_repr_go_read_eval1652000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_read_eval1652000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_read_eval1652000004_A_class)) }; return v }



type A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_eval1652000004_loading__1927001464__auto____1652000005_A_fn_class *jrt.Class



type A_arbace_repr_go_read_eval1652000008_A struct{ jrt.Object }

func A_arbace_repr_go_read_eval1652000008_A_New() *A_arbace_repr_go_read_eval1652000008_A { t := &A_arbace_repr_go_read_eval1652000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_read_eval1652000008_A) Ctor() {}

func (t *A_arbace_repr_go_read_eval1652000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_read_eval1652000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_read_eval1652000008_A_class }

func (t *A_arbace_repr_go_read_eval1652000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_read_eval1652000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_read_eval1652000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_read_eval1652000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_read_eval1652000008_A); return ok }

func A_arbace_repr_go_read_eval1652000008_A_Cast(x any) *A_arbace_repr_go_read_eval1652000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_read_eval1652000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_read_eval1652000008_A_class)) }; return v }



type A_arbace_repr_go_read_eval1652000008_fn__1652000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_eval1652000008_fn__1652000009_A_fn_class *jrt.Class



type A_arbace_repr_go_read_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_node_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_read_nodes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_nodes_A_fn_class *jrt.Class



type A_arbace_repr_go_read_nodes_fn__1652000014_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_nodes_fn__1652000014_A_fn_class *jrt.Class



type A_arbace_repr_go_read_read_dump_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_read_dump_A_fn_class *jrt.Class



type A_arbace_repr_go_read_summary_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_summary_A_fn_class *jrt.Class



type A_arbace_repr_go_read_type_entry_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_type_entry_A_fn_class *jrt.Class



type A_arbace_repr_go_read_type_refs_A struct{ j2g_header uint64 }

var A_arbace_repr_go_read_type_refs_A_fn_class *jrt.Class
