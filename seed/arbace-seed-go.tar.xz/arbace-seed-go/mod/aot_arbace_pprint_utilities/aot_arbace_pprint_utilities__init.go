//line aot_arbace_pprint_utilities__init.ae:1
package aot_arbace_pprint_utilities

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_utilities__init_A_Load__O() any { A_arbace_pprint_utilities__init_A_Init(); A_arbace_pprint_utilities__init_A_Unit0__O(); A_arbace_pprint_utilities__init_A_Unit1__O(); A_arbace_pprint_utilities__init_A_Unit2__O(); A_arbace_pprint_utilities__init_A_Unit3__O(); A_arbace_pprint_utilities__init_A_Unit4__O(); A_arbace_pprint_utilities__init_A_Unit5__O(); A_arbace_pprint_utilities__init_A_Unit6__O(); A_arbace_pprint_utilities__init_A_Unit7__O(); A_arbace_pprint_utilities__init_A_Unit8__O(); A_arbace_pprint_utilities__init_A_Unit9__O(); A_arbace_pprint_utilities__init_A_Unit10__O(); A_arbace_pprint_utilities__init_A_Unit11__O(); A_arbace_pprint_utilities__init_A_Unit12__O(); A_arbace_pprint_utilities__init_A_Unit13__O(); return nil }












func A_arbace_pprint_utilities__init_A_Unit0__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_utilities__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_utilities__init_A_const_1) }







func A_arbace_pprint_utilities__init_A_Unit1__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_map_passing_context_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_map_passing_context_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_map_passing_context_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_3)); return A_arbace_pprint_utilities__init_A_const_2.Ref() }










func A_arbace_pprint_utilities__init_A_Unit2__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_4; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_consume_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_consume_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_consume_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_5)); return A_arbace_pprint_utilities__init_A_const_4.Ref() }







func A_arbace_pprint_utilities__init_A_Unit3__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_consume_while_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_consume_while_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_consume_while_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_7)); return A_arbace_pprint_utilities__init_A_const_6.Ref() }







func A_arbace_pprint_utilities__init_A_Unit4__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_unzip_map_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_unzip_map_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_unzip_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_9)); return A_arbace_pprint_utilities__init_A_const_8.Ref() }







func A_arbace_pprint_utilities__init_A_Unit5__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(61, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_10; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_tuple_map_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_tuple_map_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_tuple_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_11)); return A_arbace_pprint_utilities__init_A_const_10.Ref() }




func A_arbace_pprint_utilities__init_A_Unit6__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_12; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_rtrim_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_rtrim_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_rtrim_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_13)); return A_arbace_pprint_utilities__init_A_const_12.Ref() }











func A_arbace_pprint_utilities__init_A_Unit7__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_14; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_ltrim_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_ltrim_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_ltrim_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_15)); return A_arbace_pprint_utilities__init_A_const_14.Ref() }










func A_arbace_pprint_utilities__init_A_Unit8__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_16; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_prefix_count_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_prefix_count_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_prefix_count_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_17)); return A_arbace_pprint_utilities__init_A_const_16.Ref() }










func A_arbace_pprint_utilities__init_A_Unit9__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_18; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_prerr_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_prerr_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_prerr_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_19)); return A_arbace_pprint_utilities__init_A_const_18.Ref() }





func A_arbace_pprint_utilities__init_A_Unit10__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_20; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_prlabel_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_prlabel_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_prlabel_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_21)); return A_arbace_pprint_utilities__init_A_const_20.Ref() }
//line :106:1
func A_arbace_pprint_utilities__init_A_Unit11__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); jrt.NN(A_arbace_pprint_utilities__init_A_const_20).SetMacro__V(); return nil }
//line :106:1
func A_arbace_pprint_utilities__init_A_Unit12__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); return A_arbace_pprint_utilities__init_A_const_20.Ref() }






func A_arbace_pprint_utilities__init_A_Unit13__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_41)); return nil }



type A_arbace_pprint_utilities__init_A struct{ jrt.Object }

var A_arbace_pprint_utilities__init_A_const_0 *lang.Var

var A_arbace_pprint_utilities__init_A_const_1 any

var A_arbace_pprint_utilities__init_A_const_2 *lang.Var

var A_arbace_pprint_utilities__init_A_const_3 any

var A_arbace_pprint_utilities__init_A_const_4 *lang.Var

var A_arbace_pprint_utilities__init_A_const_5 any

var A_arbace_pprint_utilities__init_A_const_6 *lang.Var

var A_arbace_pprint_utilities__init_A_const_7 any

var A_arbace_pprint_utilities__init_A_const_8 *lang.Var

var A_arbace_pprint_utilities__init_A_const_9 any

var A_arbace_pprint_utilities__init_A_const_10 *lang.Var

var A_arbace_pprint_utilities__init_A_const_11 any

var A_arbace_pprint_utilities__init_A_const_12 *lang.Var

var A_arbace_pprint_utilities__init_A_const_13 any

var A_arbace_pprint_utilities__init_A_const_14 *lang.Var

var A_arbace_pprint_utilities__init_A_const_15 any

var A_arbace_pprint_utilities__init_A_const_16 *lang.Var

var A_arbace_pprint_utilities__init_A_const_17 any

var A_arbace_pprint_utilities__init_A_const_18 *lang.Var

var A_arbace_pprint_utilities__init_A_const_19 any

var A_arbace_pprint_utilities__init_A_const_20 *lang.Var

var A_arbace_pprint_utilities__init_A_const_21 any

var A_arbace_pprint_utilities__init_A_const_22 *jrt.Class

var A_arbace_pprint_utilities__init_A_init jrt.ClassInit

func A_arbace_pprint_utilities__init_A_Init() { if !A_arbace_pprint_utilities__init_A_init.Done() { A_arbace_pprint_utilities__init_A_init.Run(A_arbace_pprint_utilities__init_A_clinit) } }

func A_arbace_pprint_utilities__init_A_clinit() { A_arbace_pprint_utilities__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_pprint_utilities__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_pprint_utilities__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_2, Lit_3); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_pprint_utilities__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_2, Lit_13); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_pprint_utilities__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_2, Lit_14); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_pprint_utilities__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_2, Lit_15); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_pprint_utilities__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_18, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_2, Lit_19); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_pprint_utilities__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_21, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(61).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_2, Lit_22); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_pprint_utilities__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_25, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_2, Lit_26); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_pprint_utilities__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_27, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_2, Lit_28); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_pprint_utilities__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_31, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(89).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_2, Lit_32); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_pprint_utilities__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_35, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_2, Lit_36); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_pprint_utilities__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(106).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_pprint_utilities__init_A_const_22 = lang.RT_ClassForNameNonLoading_String__Class(Lit_41) }

func A_arbace_pprint_utilities__init_A_New() *A_arbace_pprint_utilities__init_A { A_arbace_pprint_utilities__init_A_Init(); t := &A_arbace_pprint_utilities__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_utilities__init_A) Ctor() {}

func (t *A_arbace_pprint_utilities__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_utilities__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_utilities__init_A_class }

func (t *A_arbace_pprint_utilities__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_utilities__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_utilities__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_utilities__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_utilities__init_A); return ok }

func A_arbace_pprint_utilities__init_A_Cast(x any) *A_arbace_pprint_utilities__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_utilities__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_utilities__init_A_class)) }; return v }
