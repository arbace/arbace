//line aot_arbace_pprint_utilities__init.ae:1
package aot_arbace_pprint_utilities

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_utilities__init_A_Load__O() any { A_arbace_pprint_utilities__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_utilities__init_A_Unit0__O(); A_arbace_pprint_utilities__init_A_Unit1__O(); A_arbace_pprint_utilities__init_A_Unit2__O(); A_arbace_pprint_utilities__init_A_Unit3__O(); A_arbace_pprint_utilities__init_A_Unit4__O(); A_arbace_pprint_utilities__init_A_Unit5__O(); A_arbace_pprint_utilities__init_A_Unit6__O(); A_arbace_pprint_utilities__init_A_Unit7__O(); A_arbace_pprint_utilities__init_A_Unit8__O(); A_arbace_pprint_utilities__init_A_Unit9__O(); A_arbace_pprint_utilities__init_A_Unit10__O(); A_arbace_pprint_utilities__init_A_Unit11__O(); A_arbace_pprint_utilities__init_A_Unit12__O(); A_arbace_pprint_utilities__init_A_Unit13__O(); return nil }












func A_arbace_pprint_utilities__init_A_Unit0__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return lang.IFn_Cast(A_arbace_pprint_utilities__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_utilities__init_A_const_1) }







func A_arbace_pprint_utilities__init_A_Unit1__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_map_passing_context_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_map_passing_context_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); aot_arbace_pprint.A_arbace_pprint_map_passing_context_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_3)); return A_arbace_pprint_utilities__init_A_const_2 }










func A_arbace_pprint_utilities__init_A_Unit2__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_4; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_consume_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_consume_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); aot_arbace_pprint.A_arbace_pprint_consume_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_5)); return A_arbace_pprint_utilities__init_A_const_4 }







func A_arbace_pprint_utilities__init_A_Unit3__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_consume_while_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_consume_while_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_consume_while_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_7)); return A_arbace_pprint_utilities__init_A_const_6 }







func A_arbace_pprint_utilities__init_A_Unit4__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_unzip_map_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_unzip_map_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_unzip_map_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_9)); return A_arbace_pprint_utilities__init_A_const_8 }







func A_arbace_pprint_utilities__init_A_Unit5__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_10; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_tuple_map_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_tuple_map_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_pprint.A_arbace_pprint_tuple_map_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_11)); return A_arbace_pprint_utilities__init_A_const_10 }




func A_arbace_pprint_utilities__init_A_Unit6__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_12; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_rtrim_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_rtrim_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_pprint.A_arbace_pprint_rtrim_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_13)); return A_arbace_pprint_utilities__init_A_const_12 }











func A_arbace_pprint_utilities__init_A_Unit7__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_14; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_ltrim_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_ltrim_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_ltrim_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_15)); return A_arbace_pprint_utilities__init_A_const_14 }










func A_arbace_pprint_utilities__init_A_Unit8__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_16; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_prefix_count_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_prefix_count_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_prefix_count_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_17)); return A_arbace_pprint_utilities__init_A_const_16 }










func A_arbace_pprint_utilities__init_A_Unit9__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_18; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_prerr_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_prerr_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, true); aot_arbace_pprint.A_arbace_pprint_prerr_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_19)); return A_arbace_pprint_utilities__init_A_const_18 }





func A_arbace_pprint_utilities__init_A_Unit10__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_pprint_utilities__init_A_const_20; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_prlabel_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_prlabel_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, true); aot_arbace_pprint.A_arbace_pprint_prlabel_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_pprint_utilities__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_utilities__init_A_const_21)); return A_arbace_pprint_utilities__init_A_const_20 }
//line :106:1
func A_arbace_pprint_utilities__init_A_Unit11__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); A_arbace_pprint_utilities__init_A_const_20.SetMacro__V(); return nil }
//line :106:1
func A_arbace_pprint_utilities__init_A_Unit12__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); return A_arbace_pprint_utilities__init_A_const_20 }






func A_arbace_pprint_utilities__init_A_Unit13__O() any { A_arbace_pprint_utilities__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)).Ref() }



type A_arbace_pprint_utilities__init_A struct{ jrt.Object }

var A_arbace_pprint_utilities__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_utilities__init_A_const_0 *lang.Var

var A_arbace_pprint_utilities__init_A_const_1 any

var A_arbace_pprint_utilities__init_A_const_2 *lang.Var

var A_arbace_pprint_utilities__init_A_const_3 any

var A_arbace_pprint_utilities__init_A_const_4 *lang.Var

var A_arbace_pprint_utilities__init_A_const_5 any

var A_arbace_pprint_utilities__init_A_const_6 *lang.Var

var A_arbace_pprint_utilities__init_A_const_7 any

var A_arbace_pprint_utilities__init_A_const_8 *lang.Var

var A_arbace_pprint_utilities__init_A_const_9 any

var A_arbace_pprint_utilities__init_A_const_10 *lang.Var

var A_arbace_pprint_utilities__init_A_const_11 any

var A_arbace_pprint_utilities__init_A_const_12 *lang.Var

var A_arbace_pprint_utilities__init_A_const_13 any

var A_arbace_pprint_utilities__init_A_const_14 *lang.Var

var A_arbace_pprint_utilities__init_A_const_15 any

var A_arbace_pprint_utilities__init_A_const_16 *lang.Var

var A_arbace_pprint_utilities__init_A_const_17 any

var A_arbace_pprint_utilities__init_A_const_18 *lang.Var

var A_arbace_pprint_utilities__init_A_const_19 any

var A_arbace_pprint_utilities__init_A_const_20 *lang.Var

var A_arbace_pprint_utilities__init_A_const_21 any

var A_arbace_pprint_utilities__init_A_const_22 *jrt.Class

var A_arbace_pprint_utilities__init_A_init jrt.ClassInit

func A_arbace_pprint_utilities__init_A_Init() { if !A_arbace_pprint_utilities__init_A_init.Done() { A_arbace_pprint_utilities__init_A_init.Run(A_arbace_pprint_utilities__init_A_clinit) } }

func A_arbace_pprint_utilities__init_A_clinit() { jrt.StartCheck(); A_arbace_pprint_utilities__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 44); A_arbace_pprint_utilities__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[21]); A_arbace_pprint_utilities__init_A_const_1 = A_arbace_pprint_utilities__init_A_const_pool.A[22]; A_arbace_pprint_utilities__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[23]); A_arbace_pprint_utilities__init_A_const_3 = A_arbace_pprint_utilities__init_A_const_pool.A[24]; A_arbace_pprint_utilities__init_A_const_4 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[25]); A_arbace_pprint_utilities__init_A_const_5 = A_arbace_pprint_utilities__init_A_const_pool.A[26]; A_arbace_pprint_utilities__init_A_const_6 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[27]); A_arbace_pprint_utilities__init_A_const_7 = A_arbace_pprint_utilities__init_A_const_pool.A[28]; A_arbace_pprint_utilities__init_A_const_8 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[29]); A_arbace_pprint_utilities__init_A_const_9 = A_arbace_pprint_utilities__init_A_const_pool.A[30]; A_arbace_pprint_utilities__init_A_const_10 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[31]); A_arbace_pprint_utilities__init_A_const_11 = A_arbace_pprint_utilities__init_A_const_pool.A[32]; A_arbace_pprint_utilities__init_A_const_12 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[33]); A_arbace_pprint_utilities__init_A_const_13 = A_arbace_pprint_utilities__init_A_const_pool.A[34]; A_arbace_pprint_utilities__init_A_const_14 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[35]); A_arbace_pprint_utilities__init_A_const_15 = A_arbace_pprint_utilities__init_A_const_pool.A[36]; A_arbace_pprint_utilities__init_A_const_16 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[37]); A_arbace_pprint_utilities__init_A_const_17 = A_arbace_pprint_utilities__init_A_const_pool.A[38]; A_arbace_pprint_utilities__init_A_const_18 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[39]); A_arbace_pprint_utilities__init_A_const_19 = A_arbace_pprint_utilities__init_A_const_pool.A[40]; A_arbace_pprint_utilities__init_A_const_20 = lang.Var_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[41]); A_arbace_pprint_utilities__init_A_const_21 = A_arbace_pprint_utilities__init_A_const_pool.A[42]; A_arbace_pprint_utilities__init_A_const_22 = jrt.Class_Cast(A_arbace_pprint_utilities__init_A_const_pool.A[43]) }

func A_arbace_pprint_utilities__init_A_New() *A_arbace_pprint_utilities__init_A { A_arbace_pprint_utilities__init_A_Init(); t := &A_arbace_pprint_utilities__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_utilities__init_A) Ctor() {}

func (t *A_arbace_pprint_utilities__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_utilities__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_utilities__init_A_class }

func (t *A_arbace_pprint_utilities__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_utilities__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_utilities__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_utilities__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_utilities__init_A); return ok }

func A_arbace_pprint_utilities__init_A_Cast(x any) *A_arbace_pprint_utilities__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_utilities__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_utilities__init_A_class)) }; return v }
