//line a2g_strings.ae:1
package aot_arbace_pprint_utilities

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.pprintkn7,privatekn8,arglistsyn4,funcyn15,initial-contextyn3,liskn4,linekn6,columnkn4,fileyn1,mkn3,docyn2,v1yn1,syn1,cyn4,aseqyn3,valyn1,&yn4,argsyn6,prefixyn3,argyn9,more-argsv11,arbace.core5,in-nsR0,v13,arbace.pprint19,map-passing-contextm10,R1,TR2,L1,V3,R3,R4,R5,R6,i26,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint7,consumem10,R1,TR2,L1,V2,R3,R4,R6,i37,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint13,consume-whilem10,R1,TR2,L1,V2,R3,R4,R6,i45,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint9,unzip-mapm12,R1,TR2,L1,V1,R9,R10,s181,Take a map that has pairs in the value slots and produce a pair of\n  maps, the first having all the first elements of the pairs and the\n  second all the second elements of the pairsR6,i53,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint9,tuple-mapm12,R1,TR2,L1,V2,R9,R11,R10,s59,For all the values, v, in the map, replace them with [v v1]R6,i61,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint5,rtrimm12,R1,TR2,L1,V2,R12,R13,R10,s50,Trim all instances of c from the end of sequence sR6,i66,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint5,ltrimm12,R1,TR2,L1,V2,R12,R13,R10,s56,Trim all instances of c from the beginning of sequence sR6,i78,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint12,prefix-countm12,R1,TR2,L1,V2,R14,R15,R10,s178,Return the number of times that val occurs at the start of sequence aseq,\n  if val is a seq itself, count the number of times any element of val\n  occurs at the beginning of aseqR6,i89,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint5,prerrm12,R1,TR2,L1,V2,R16,R17,R10,s16,Println to *err*R6,i100,R7,i1,R8,s26,arbace/pprint/utilities.aev13,arbace.pprint7,prlabelm12,R1,TR2,L1,V4,R18,R19,R16,R20,R10,s42,Print args to *err* in name = value formatR6,i106,R7,i1,R8,s26,arbace/pprint/utilities.aeC25,arbace.pprint.PrettyFlush")

var Lit_1 *jrt.String = jrt.Intern("arbace.pprint$map_passing_context")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint$consume")

var Lit_3 *jrt.String = jrt.Intern("arbace.pprint$consume_while")

var Lit_4 *jrt.String = jrt.Intern("arbace.pprint$unzip_map")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint$tuple_map")

var Lit_6 *jrt.String = jrt.Intern("arbace.pprint$rtrim")

var Lit_7 *jrt.String = jrt.Intern("arbace.pprint$ltrim")

var Lit_8 *jrt.String = jrt.Intern("arbace.pprint$prefix_count")

var Lit_9 *jrt.String = jrt.Intern("arbace.pprint$prerr")

var Lit_10 *jrt.String = jrt.Intern("arbace.pprint$prlabel")

var Lit_11 *jrt.String = jrt.Intern("arbace.pprint.PrettyFlush")
