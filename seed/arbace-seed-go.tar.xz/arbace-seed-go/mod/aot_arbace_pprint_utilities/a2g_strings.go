//line a2g_strings.ae:1
package aot_arbace_pprint_utilities

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("map-passing-context")

var Lit_4 *jrt.String = jrt.Intern("private")

var Lit_5 *jrt.String = jrt.Intern("arglists")

var Lit_6 *jrt.String = jrt.Intern("func")

var Lit_7 *jrt.String = jrt.Intern("initial-context")

var Lit_8 *jrt.String = jrt.Intern("lis")

var Lit_9 *jrt.String = jrt.Intern("line")

var Lit_10 *jrt.String = jrt.Intern("column")

var Lit_11 *jrt.String = jrt.Intern("file")

var Lit_12 *jrt.String = jrt.Intern("arbace/pprint/utilities.ae")

var Lit_13 *jrt.String = jrt.Intern("consume")

var Lit_14 *jrt.String = jrt.Intern("consume-while")

var Lit_15 *jrt.String = jrt.Intern("unzip-map")

var Lit_16 *jrt.String = jrt.Intern("m")

var Lit_17 *jrt.String = jrt.Intern("doc")

var Lit_18 *jrt.String = jrt.Intern("Take a map that has pairs in the value slots and produce a pair of\n  maps, the first having all the first elements of the pairs and the\n  second all the second elements of the pairs")

var Lit_19 *jrt.String = jrt.Intern("tuple-map")

var Lit_20 *jrt.String = jrt.Intern("v1")

var Lit_21 *jrt.String = jrt.Intern("For all the values, v, in the map, replace them with [v v1]")

var Lit_22 *jrt.String = jrt.Intern("rtrim")

var Lit_23 *jrt.String = jrt.Intern("s")

var Lit_24 *jrt.String = jrt.Intern("c")

var Lit_25 *jrt.String = jrt.Intern("Trim all instances of c from the end of sequence s")

var Lit_26 *jrt.String = jrt.Intern("ltrim")

var Lit_27 *jrt.String = jrt.Intern("Trim all instances of c from the beginning of sequence s")

var Lit_28 *jrt.String = jrt.Intern("prefix-count")

var Lit_29 *jrt.String = jrt.Intern("aseq")

var Lit_30 *jrt.String = jrt.Intern("val")

var Lit_31 *jrt.String = jrt.Intern("Return the number of times that val occurs at the start of sequence aseq,\n  if val is a seq itself, count the number of times any element of val\n  occurs at the beginning of aseq")

var Lit_32 *jrt.String = jrt.Intern("prerr")

var Lit_33 *jrt.String = jrt.Intern("&")

var Lit_34 *jrt.String = jrt.Intern("args")

var Lit_35 *jrt.String = jrt.Intern("Println to *err*")

var Lit_36 *jrt.String = jrt.Intern("prlabel")

var Lit_37 *jrt.String = jrt.Intern("prefix")

var Lit_38 *jrt.String = jrt.Intern("arg")

var Lit_39 *jrt.String = jrt.Intern("more-args")

var Lit_40 *jrt.String = jrt.Intern("Print args to *err* in name = value format")

var Lit_41 *jrt.String = jrt.Intern("arbace.pprint.PrettyFlush")
