//line a2g_strings.ae:1
package aot_arbace_core_deftype

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("namespace-munge")

var Lit_3 *jrt.String = jrt.Intern("arglists")

var Lit_4 *jrt.String = jrt.Intern("ns")

var Lit_5 *jrt.String = jrt.Intern("doc")

var Lit_6 *jrt.String = jrt.Intern("Convert a Clojure namespace name to a legal Java package name.")

var Lit_7 *jrt.String = jrt.Intern("added")

var Lit_8 *jrt.String = jrt.Intern("1.2")

var Lit_9 *jrt.String = jrt.Intern("line")

var Lit_10 *jrt.String = jrt.Intern("column")

var Lit_11 *jrt.String = jrt.Intern("file")

var Lit_12 *jrt.String = jrt.Intern("arbace/core_deftype.ae")

var Lit_13 *jrt.String = jrt.Intern("resolve-unqualified-class-tag")

var Lit_14 *jrt.String = jrt.Intern("private")

var Lit_15 *jrt.String = jrt.Intern("tag")

var Lit_16 *jrt.String = jrt.Intern("Resolves unqualified class tag symbol to fully qualified class tag symbol.\n  Returns all other tags unmodified.")

var Lit_17 *jrt.String = jrt.Intern("definterface")

var Lit_18 *jrt.String = jrt.Intern("name")

var Lit_19 *jrt.String = jrt.Intern("&")

var Lit_20 *jrt.String = jrt.Intern("sigs")

var Lit_21 *jrt.String = jrt.Intern("Creates a new Java interface with the given name and method sigs.\n  The method return types and parameter types may be specified with type hints,\n  defaulting to Object if omitted.\n\n  (definterface MyInterface\n    (^int method1 [x])\n    (^Bar method2 [^Baz b ^Quux q]))")

var Lit_22 *jrt.String = jrt.Intern("parse-opts")

var Lit_23 *jrt.String = jrt.Intern("s")

var Lit_24 *jrt.String = jrt.Intern("parse-impls")

var Lit_25 *jrt.String = jrt.Intern("specs")

var Lit_26 *jrt.String = jrt.Intern("parse-opts+specs")

var Lit_27 *jrt.String = jrt.Intern("opts+specs")

var Lit_28 *jrt.String = jrt.Intern("reify")

var Lit_29 *jrt.String = jrt.Intern("reify creates an object implementing a protocol or interface.\n  reify is a macro with the following structure:\n\n (reify options* specs*)\n\n  Currently there are no options.\n\n  Each spec consists of the protocol or interface name followed by zero\n  or more method bodies:\n\n  protocol-or-interface-or-Object\n  (methodName [args+] body)*\n\n  Methods should be supplied for all methods of the desired\n  protocol(s) and interface(s). You can also define overrides for\n  methods of Object. Note that the first parameter must be supplied to\n  correspond to the target object ('this' in Java parlance). Thus\n  methods for interfaces will take one more argument than do the\n  interface declarations.  Note also that recur calls to the method\n  head should *not* pass the target object, it will be supplied\n  automatically and can not be substituted.\n\n  The return type can be indicated by a type hint on the method name,\n  and arg types can be indicated by a type hint on arg names. If you\n  leave out all hints, reify will try to match on same name/arity\n  method in the protocol(s)/interface(s) - this is preferred. If you\n  supply any hints at all, no inference is done, so all hints (or\n  default of Object) must be correct, for both arguments and return\n  type. If a method is overloaded in a protocol/interface, multiple\n  independent method definitions must be supplied.  If overloaded with\n  same arity in an interface you must specify complete hints to\n  disambiguate - a missing hint implies Object.\n\n  Method heads are recursion points for recur, as in a fn. The method\n  bodies of reify are lexical closures, and can refer to the surrounding\n  local scope:\n\n  (str (let [f \"foo\"]\n         (reify Object\n           (toString [this] f))))\n  == \"foo\"\n\n  (seq (let [f \"foo\"]\n         (reify arbace.lang.Seqable\n           (seq [this] (seq f)))))\n  == (\\f \\o \\o)\n\n  reify always implements arbace.lang.IObj and transfers meta\n  data of the form to the created object.\n\n  (meta ^{:k :v} (reify Object (toString [this] \"foo\")))\n  == {:k :v}")

var Lit_30 *jrt.String = jrt.Intern("hash-combine")

var Lit_31 *jrt.String = jrt.Intern("x")

var Lit_32 *jrt.String = jrt.Intern("y")

var Lit_33 *jrt.String = jrt.Intern("munge")

var Lit_34 *jrt.String = jrt.Intern("imap-cons")

var Lit_35 *jrt.String = jrt.Intern("this")

var Lit_36 *jrt.String = jrt.Intern("IPersistentMap")

var Lit_37 *jrt.String = jrt.Intern("o")

var Lit_38 *jrt.String = jrt.Intern("emit-defrecord")

var Lit_39 *jrt.String = jrt.Intern("tagname")

var Lit_40 *jrt.String = jrt.Intern("cname")

var Lit_41 *jrt.String = jrt.Intern("fields")

var Lit_42 *jrt.String = jrt.Intern("interfaces")

var Lit_43 *jrt.String = jrt.Intern("methods")

var Lit_44 *jrt.String = jrt.Intern("opts")

var Lit_45 *jrt.String = jrt.Intern("Do not use this directly - use defrecord")

var Lit_46 *jrt.String = jrt.Intern("build-positional-factory")

var Lit_47 *jrt.String = jrt.Intern("nom")

var Lit_48 *jrt.String = jrt.Intern("classname")

var Lit_49 *jrt.String = jrt.Intern("Used to build a positional factory for a given type/record.  Because of the\n  limitation of 20 arguments to Clojure functions, this factory needs to be\n  constructed to deal with more arguments.  It does this by building a straight\n  forward type/record ctor call in the <=20 case, and a call to the same\n  ctor pulling the extra args out of the & overage parameter.  Finally, the\n  arity is constrained to the number of expected fields and an ArityException\n  will be thrown at runtime if the actual arg count does not match.")

var Lit_50 *jrt.String = jrt.Intern("validate-fields")

var Lit_51 *jrt.String = jrt.Intern("")

var Lit_52 *jrt.String = jrt.Intern("defrecord")

var Lit_53 *jrt.String = jrt.Intern("(defrecord name [fields*]  options* specs*)\n\n  Options are expressed as sequential keywords and arguments (in any order).\n\n  Supported options:\n  :load-ns - if true, importing the record class will cause the\n             namespace in which the record was defined to be loaded.\n             Defaults to false.\n\n  Each spec consists of a protocol or interface name followed by zero\n  or more method bodies:\n\n  protocol-or-interface-or-Object\n  (methodName [args*] body)*\n\n  Dynamically generates compiled bytecode for class with the given\n  name, in a package with the same name as the current namespace, the\n  given fields, and, optionally, methods for protocols and/or\n  interfaces.\n\n  The class will have the (immutable) fields named by\n  fields, which can have type hints. Protocols/interfaces and methods\n  are optional. The only methods that can be supplied are those\n  declared in the protocols/interfaces.  Note that method bodies are\n  not closures, the local environment includes only the named fields,\n  and those fields can be accessed directly.\n\n  Method definitions take the form:\n\n  (methodname [args*] body)\n\n  The argument and return types can be hinted on the arg and\n  methodname symbols. If not supplied, they will be inferred, so type\n  hints should be reserved for disambiguation.\n\n  Methods should be supplied for all methods of the desired\n  protocol(s) and interface(s). You can also define overrides for\n  methods of Object. Note that a parameter must be supplied to\n  correspond to the target object ('this' in Java parlance). Thus\n  methods for interfaces will take one more argument than do the\n  interface declarations. Note also that recur calls to the method\n  head should *not* pass the target object, it will be supplied\n  automatically and can not be substituted.\n\n  In the method bodies, the (unqualified) name can be used to name the\n  class (for calls to new, instance? etc).\n\n  The class will have implementations of several (arbace.lang)\n  interfaces generated automatically: IObj (metadata support) and\n  IPersistentMap, and all of their superinterfaces.\n\n  In addition, defrecord will define type-and-value-based =,\n  and will defined Java .hashCode and .equals consistent with the\n  contract for java.util.Map.\n\n  When AOT compiling, generates compiled bytecode for a class with the\n  given name (a symbol), prepends the current ns as the package, and\n  writes the .class file to the *compile-path* directory.\n\n  Two constructors will be defined, one taking the designated fields\n  followed by a metadata map (nil for none) and an extension field\n  map (nil for none), and one taking only the fields (using nil for\n  meta and extension fields). Note that the field names __meta,\n  __extmap, __hash and __hasheq are currently reserved and should not\n  be used when defining your own records.\n\n  Given (defrecord TypeName ...), two factory functions will be\n  defined: ->TypeName, taking positional parameters for the fields,\n  and map->TypeName, taking a map of keywords to field values.")

var Lit_54 *jrt.String = jrt.Intern("record?")

var Lit_55 *jrt.String = jrt.Intern("Returns true if x is a record")

var Lit_56 *jrt.String = jrt.Intern("1.6")

var Lit_57 *jrt.String = jrt.Intern("static")

var Lit_58 *jrt.String = jrt.Intern("emit-deftype*")

var Lit_59 *jrt.String = jrt.Intern("Do not use this directly - use deftype")

var Lit_60 *jrt.String = jrt.Intern("deftype")

var Lit_61 *jrt.String = jrt.Intern("(deftype name [fields*]  options* specs*)\n\n  Options are expressed as sequential keywords and arguments (in any order).\n\n  Supported options:\n  :load-ns - if true, importing the type class will cause the\n             namespace in which the type was defined to be loaded.\n             Defaults to false.\n\n  Each spec consists of a protocol or interface name followed by zero\n  or more method bodies:\n\n  protocol-or-interface-or-Object\n  (methodName [args*] body)*\n\n  Dynamically generates compiled bytecode for class with the given\n  name, in a package with the same name as the current namespace, the\n  given fields, and, optionally, methods for protocols and/or\n  interfaces.\n\n  The class will have the (by default, immutable) fields named by\n  fields, which can have type hints. Protocols/interfaces and methods\n  are optional. The only methods that can be supplied are those\n  declared in the protocols/interfaces.  Note that method bodies are\n  not closures, the local environment includes only the named fields,\n  and those fields can be accessed directly. Fields can be qualified\n  with the metadata :volatile-mutable true or :unsynchronized-mutable\n  true, at which point (set! afield aval) will be supported in method\n  bodies. Note well that mutable fields are extremely difficult to use\n  correctly, and are present only to facilitate the building of higher\n  level constructs, such as Clojure's reference types, in Clojure\n  itself. They are for experts only - if the semantics and\n  implications of :volatile-mutable or :unsynchronized-mutable are not\n  immediately apparent to you, you should not be using them.\n\n  Method definitions take the form:\n\n  (methodname [args*] body)\n\n  The argument and return types can be hinted on the arg and\n  methodname symbols. If not supplied, they will be inferred, so type\n  hints should be reserved for disambiguation.\n\n  Methods should be supplied for all methods of the desired\n  protocol(s) and interface(s). You can also define overrides for\n  methods of Object. Note that a parameter must be supplied to\n  correspond to the target object ('this' in Java parlance). Thus\n  methods for interfaces will take one more argument than do the\n  interface declarations. Note also that recur calls to the method\n  head should *not* pass the target object, it will be supplied\n  automatically and can not be substituted.\n\n  In the method bodies, the (unqualified) name can be used to name the\n  class (for calls to new, instance? etc).\n\n  When AOT compiling, generates compiled bytecode for a class with the\n  given name (a symbol), prepends the current ns as the package, and\n  writes the .class file to the *compile-path* directory.\n\n  One constructor will be defined, taking the designated fields.  Note\n  that the field names __meta, __extmap, __hash and __hasheq are currently\n  reserved and should not be used when defining your own types.\n\n  Given (deftype TypeName ...), a factory function called ->TypeName\n  will be defined, taking positional parameters for the fields")

var Lit_62 *jrt.String = jrt.Intern("expand-method-impl-cache")

var Lit_63 *jrt.String = jrt.Intern("cache")

var Lit_64 *jrt.String = jrt.Intern("arbace.lang.MethodImplCache")

var Lit_65 *jrt.String = jrt.Intern("c")

var Lit_66 *jrt.String = jrt.Intern("f")

var Lit_67 *jrt.String = jrt.Intern("super-chain")

var Lit_68 *jrt.String = jrt.Intern("Class")

var Lit_69 *jrt.String = jrt.Intern("pref")

var Lit_70 *jrt.String = jrt.Intern("a")

var Lit_71 *jrt.String = jrt.Intern("b")

var Lit_72 *jrt.String = jrt.Intern("find-protocol-impl")

var Lit_73 *jrt.String = jrt.Intern("protocol")

var Lit_74 *jrt.String = jrt.Intern("find-protocol-method")

var Lit_75 *jrt.String = jrt.Intern("methodk")

var Lit_76 *jrt.String = jrt.Intern("protocol?")

var Lit_77 *jrt.String = jrt.Intern("maybe-p")

var Lit_78 *jrt.String = jrt.Intern("implements?")

var Lit_79 *jrt.String = jrt.Intern("atype")

var Lit_80 *jrt.String = jrt.Intern("extends?")

var Lit_81 *jrt.String = jrt.Intern("Returns true if atype extends protocol")

var Lit_82 *jrt.String = jrt.Intern("extenders")

var Lit_83 *jrt.String = jrt.Intern("Returns a collection of the types explicitly extending protocol")

var Lit_84 *jrt.String = jrt.Intern("satisfies?")

var Lit_85 *jrt.String = jrt.Intern("Returns true if x satisfies the protocol")

var Lit_86 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_87 *jrt.String = jrt.Intern("pf")

var Lit_88 *jrt.String = jrt.Intern("arbace.lang.AFunction")

var Lit_89 *jrt.String = jrt.Intern("interf")

var Lit_90 *jrt.String = jrt.Intern("arbace.lang.IFn")

var Lit_91 *jrt.String = jrt.Intern("emit-method-builder")

var Lit_92 *jrt.String = jrt.Intern("on-interface")

var Lit_93 *jrt.String = jrt.Intern("method")

var Lit_94 *jrt.String = jrt.Intern("on-method")

var Lit_95 *jrt.String = jrt.Intern("extend-via-meta")

var Lit_96 *jrt.String = jrt.Intern("-reset-methods")

var Lit_97 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_98 *jrt.String = jrt.Intern("protocol-var")

var Lit_99 *jrt.String = jrt.Intern("method-syms")

var Lit_100 *jrt.String = jrt.Intern("emit-protocol")

var Lit_101 *jrt.String = jrt.Intern("opts+sigs")

var Lit_102 *jrt.String = jrt.Intern("defprotocol")

var Lit_103 *jrt.String = jrt.Intern("A protocol is a named set of named methods and their signatures:\n  (defprotocol AProtocolName\n\n    ;optional doc string\n    \"A doc string for AProtocol abstraction\"\n\n   ;options\n   :extend-via-metadata true\n\n  ;method signatures\n    (bar [this a b] \"bar docs\")\n    (baz [this a] [this a b] [this a b c] \"baz docs\"))\n\n  No implementations are provided. Docs can be specified for the\n  protocol overall and for each method. The above yields a set of\n  polymorphic functions and a protocol object. All are\n  namespace-qualified by the ns enclosing the definition The resulting\n  functions dispatch on the type of their first argument, which is\n  required and corresponds to the implicit target object ('this' in\n  Java parlance). defprotocol is dynamic, has no special compile-time\n  effect, and defines no new types or classes. Implementations of\n  the protocol methods can be provided using extend.\n\n  When :extend-via-metadata is true, values can extend protocols by\n  adding metadata where keys are fully-qualified protocol function\n  symbols and values are function implementations. Protocol\n  implementations are checked first for direct definitions (defrecord,\n  deftype, reify), then metadata definitions, then external\n  extensions (extend, extend-type, extend-protocol)\n\n  defprotocol will automatically generate a corresponding interface,\n  with the same name as the protocol, i.e. given a protocol:\n  my.ns/Protocol, an interface: my.ns.Protocol. The interface will\n  have methods corresponding to the protocol functions, and the\n  protocol will automatically work with instances of the interface.\n\n  Note that you should not use this interface with deftype or\n  reify, as they support the protocol directly:\n\n  (defprotocol P\n    (foo [this])\n    (bar-me [this] [this y]))\n\n  (deftype Foo [a b c]\n   P\n    (foo [this] a)\n    (bar-me [this] b)\n    (bar-me [this y] (+ c y)))\n\n  (bar-me (Foo. 1 2 3) 42)\n  => 45\n\n  (foo\n    (let [x 42]\n      (reify P\n        (foo [this] 17)\n        (bar-me [this] x)\n        (bar-me [this y] x))))\n  => 17")

var Lit_104 *jrt.String = jrt.Intern("extend")

var Lit_105 *jrt.String = jrt.Intern("proto+mmaps")

var Lit_106 *jrt.String = jrt.Intern("Implementations of protocol methods can be provided using the extend construct:\n\n  (extend AType\n    AProtocol\n     {:foo an-existing-fn\n      :bar (fn [a b] ...)\n      :baz (fn ([a]...) ([a b] ...)...)}\n    BProtocol\n      {...}\n    ...)\n\n  extend takes a type/class (or interface, see below), and one or more\n  protocol + method map pairs. It will extend the polymorphism of the\n  protocol's methods to call the supplied methods when an AType is\n  provided as the first argument.\n\n  Method maps are maps of the keyword-ized method names to ordinary\n  fns. This facilitates easy reuse of existing fns and fn maps, for\n  code reuse/mixins without derivation or composition. You can extend\n  an interface to a protocol. This is primarily to facilitate interop\n  with the host (e.g. Java) but opens the door to incidental multiple\n  inheritance of implementation since a class can inherit from more\n  than one interface, both of which extend the protocol. It is TBD how\n  to specify which impl to use. You can extend a protocol on nil.\n\n  If you are supplying the definitions explicitly (i.e. not reusing\n  exsting functions or mixin maps), you may find it more convenient to\n  use the extend-type or extend-protocol macros.\n\n  Note that multiple independent extend clauses can exist for the same\n  type, not all protocols need be defined in a single extend call.\n\n  See also:\n  extends?, satisfies?, extenders")

var Lit_107 *jrt.String = jrt.Intern("emit-impl")

var Lit_108 *jrt.String = jrt.Intern("p")

var Lit_109 *jrt.String = jrt.Intern("fs")

var Lit_110 *jrt.String = jrt.Intern("emit-hinted-impl")

var Lit_111 *jrt.String = jrt.Intern("emit-extend-type")

var Lit_112 *jrt.String = jrt.Intern("extend-type")

var Lit_113 *jrt.String = jrt.Intern("t")

var Lit_114 *jrt.String = jrt.Intern("A macro that expands into an extend call. Useful when you are\n  supplying the definitions explicitly inline, extend-type\n  automatically creates the maps required by extend.  Propagates the\n  class as a type hint on the first argument of all fns.\n\n  (extend-type MyType\n    Countable\n      (cnt [c] ...)\n    Foo\n      (bar [x y] ...)\n      (baz ([x] ...) ([x y & zs] ...)))\n\n  expands into:\n\n  (extend MyType\n   Countable\n     {:cnt (fn [c] ...)}\n   Foo\n     {:baz (fn ([x] ...) ([x y & zs] ...))\n      :bar (fn [x y] ...)})")

var Lit_115 *jrt.String = jrt.Intern("emit-extend-protocol")

var Lit_116 *jrt.String = jrt.Intern("extend-protocol")

var Lit_117 *jrt.String = jrt.Intern("Useful when you want to provide several implementations of the same\n  protocol all at once. Takes a single protocol and the implementation\n  of that protocol for one or more types. Expands into calls to\n  extend-type:\n\n  (extend-protocol Protocol\n    AType\n      (foo [x] ...)\n      (bar [x y] ...)\n    BType\n      (foo [x] ...)\n      (bar [x y] ...)\n    AClass\n      (foo [x] ...)\n      (bar [x y] ...)\n    nil\n      (foo [x] ...)\n      (bar [x y] ...))\n\n  expands into:\n\n  (do\n   (arbace.core/extend-type AType Protocol\n     (foo [x] ...)\n     (bar [x y] ...))\n   (arbace.core/extend-type BType Protocol\n     (foo [x] ...)\n     (bar [x y] ...))\n   (arbace.core/extend-type AClass Protocol\n     (foo [x] ...)\n     (bar [x y] ...))\n   (arbace.core/extend-type nil Protocol\n     (foo [x] ...)\n     (bar [x y] ...)))")
