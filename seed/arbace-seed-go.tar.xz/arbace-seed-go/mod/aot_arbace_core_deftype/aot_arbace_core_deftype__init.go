//line aot_arbace_core_deftype__init.ae:1
package aot_arbace_core_deftype

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_deftype__init_A_Load__O() any { A_arbace_core_deftype__init_A_Init(); A_arbace_core_deftype__init_A_Unit0__O(); A_arbace_core_deftype__init_A_Unit1__O(); A_arbace_core_deftype__init_A_Unit2__O(); A_arbace_core_deftype__init_A_Unit3__O(); A_arbace_core_deftype__init_A_Unit4__O(); A_arbace_core_deftype__init_A_Unit5__O(); A_arbace_core_deftype__init_A_Unit6__O(); A_arbace_core_deftype__init_A_Unit7__O(); A_arbace_core_deftype__init_A_Unit8__O(); A_arbace_core_deftype__init_A_Unit9__O(); A_arbace_core_deftype__init_A_Unit10__O(); A_arbace_core_deftype__init_A_Unit11__O(); A_arbace_core_deftype__init_A_Unit12__O(); A_arbace_core_deftype__init_A_Unit13__O(); A_arbace_core_deftype__init_A_Unit14__O(); A_arbace_core_deftype__init_A_Unit15__O(); A_arbace_core_deftype__init_A_Unit16__O(); A_arbace_core_deftype__init_A_Unit17__O(); A_arbace_core_deftype__init_A_Unit18__O(); A_arbace_core_deftype__init_A_Unit19__O(); A_arbace_core_deftype__init_A_Unit20__O(); A_arbace_core_deftype__init_A_Unit21__O(); A_arbace_core_deftype__init_A_Unit22__O(); A_arbace_core_deftype__init_A_Unit23__O(); A_arbace_core_deftype__init_A_Unit24__O(); A_arbace_core_deftype__init_A_Unit25__O(); A_arbace_core_deftype__init_A_Unit26__O(); A_arbace_core_deftype__init_A_Unit27__O(); A_arbace_core_deftype__init_A_Unit28__O(); A_arbace_core_deftype__init_A_Unit29__O(); A_arbace_core_deftype__init_A_Unit30__O(); A_arbace_core_deftype__init_A_Unit31__O(); A_arbace_core_deftype__init_A_Unit32__O(); A_arbace_core_deftype__init_A_Unit33__O(); A_arbace_core_deftype__init_A_Unit34__O(); A_arbace_core_deftype__init_A_Unit35__O(); A_arbace_core_deftype__init_A_Unit36__O(); A_arbace_core_deftype__init_A_Unit37__O(); A_arbace_core_deftype__init_A_Unit38__O(); A_arbace_core_deftype__init_A_Unit39__O(); A_arbace_core_deftype__init_A_Unit40__O(); A_arbace_core_deftype__init_A_Unit41__O(); A_arbace_core_deftype__init_A_Unit42__O(); A_arbace_core_deftype__init_A_Unit43__O(); A_arbace_core_deftype__init_A_Unit44__O(); A_arbace_core_deftype__init_A_Unit45__O(); A_arbace_core_deftype__init_A_Unit46__O(); A_arbace_core_deftype__init_A_Unit47__O(); A_arbace_core_deftype__init_A_Unit48__O(); A_arbace_core_deftype__init_A_Unit49__O(); A_arbace_core_deftype__init_A_Unit50__O(); A_arbace_core_deftype__init_A_Unit51__O(); A_arbace_core_deftype__init_A_Unit52__O(); A_arbace_core_deftype__init_A_Unit53__O(); A_arbace_core_deftype__init_A_Unit54__O(); return nil }



func A_arbace_core_deftype__init_A_Unit0__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_deftype__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_deftype__init_A_const_1) }



func A_arbace_core_deftype__init_A_Unit1__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_2; var tmp2 any = aot_arbace_core.A_arbace_core_namespace_munge_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_namespace_munge_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_namespace_munge_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_3)); return A_arbace_core_deftype__init_A_const_2.Ref() }





func A_arbace_core_deftype__init_A_Unit2__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_4; var tmp2 any = aot_arbace_core.A_arbace_core_resolve_unqualified_class_tag_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_resolve_unqualified_class_tag_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_resolve_unqualified_class_tag_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_5)); return A_arbace_core_deftype__init_A_const_4.Ref() }













func A_arbace_core_deftype__init_A_Unit3__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_6; var tmp2 any = aot_arbace_core.A_arbace_core_definterface_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_definterface_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_definterface_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_7)); return A_arbace_core_deftype__init_A_const_6.Ref() }
//line :33:1
func A_arbace_core_deftype__init_A_Unit4__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); jrt.NN(A_arbace_core_deftype__init_A_const_6).SetMacro__V(); return nil }
//line :33:1
func A_arbace_core_deftype__init_A_Unit5__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); return A_arbace_core_deftype__init_A_const_6.Ref() }



















func A_arbace_core_deftype__init_A_Unit6__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_8; var tmp2 any = aot_arbace_core.A_arbace_core_parse_opts_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_parse_opts_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_parse_opts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_9)); return A_arbace_core_deftype__init_A_const_8.Ref() }





func A_arbace_core_deftype__init_A_Unit7__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_10; var tmp2 any = aot_arbace_core.A_arbace_core_parse_impls_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_parse_impls_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_parse_impls_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_11)); return A_arbace_core_deftype__init_A_const_10.Ref() }






func A_arbace_core_deftype__init_A_Unit8__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_12; var tmp2 any = aot_arbace_core.A_arbace_core_parse_opts_PLUS_specs_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_parse_opts_PLUS_specs_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_parse_opts_PLUS_specs_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_13)); return A_arbace_core_deftype__init_A_const_12.Ref() }
















func A_arbace_core_deftype__init_A_Unit9__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_14; var tmp2 any = aot_arbace_core.A_arbace_core_reify_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_reify_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_reify_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_15)); return A_arbace_core_deftype__init_A_const_14.Ref() }
//line :83:1
func A_arbace_core_deftype__init_A_Unit10__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); jrt.NN(A_arbace_core_deftype__init_A_const_14).SetMacro__V(); return nil }
//line :83:1
func A_arbace_core_deftype__init_A_Unit11__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); return A_arbace_core_deftype__init_A_const_14.Ref() }

























































func A_arbace_core_deftype__init_A_Unit12__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(141, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_16; var tmp2 any = aot_arbace_core.A_arbace_core_hash_combine_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_hash_combine_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_hash_combine_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_17)); return A_arbace_core_deftype__init_A_const_16.Ref() }


func A_arbace_core_deftype__init_A_Unit13__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_18; var tmp2 any = aot_arbace_core.A_arbace_core_munge_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_munge_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_munge_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_19)); return A_arbace_core_deftype__init_A_const_18.Ref() }


func A_arbace_core_deftype__init_A_Unit14__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_imap_cons_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_imap_cons_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_imap_cons_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_21)); return A_arbace_core_deftype__init_A_const_20.Ref() }















func A_arbace_core_deftype__init_A_Unit15__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_emit_defrecord_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_defrecord_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_defrecord_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_23)); return A_arbace_core_deftype__init_A_const_22.Ref() }





















































































































func A_arbace_core_deftype__init_A_Unit16__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(281, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_build_positional_factory_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_build_positional_factory_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_build_positional_factory_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_25)); return A_arbace_core_deftype__init_A_const_24.Ref() }


























func A_arbace_core_deftype__init_A_Unit17__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(308, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_26; var tmp2 any = aot_arbace_core.A_arbace_core_validate_fields_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_validate_fields_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_validate_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_27)); return A_arbace_core_deftype__init_A_const_26.Ref() }


















func A_arbace_core_deftype__init_A_Unit18__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(327, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_28; var tmp2 any = aot_arbace_core.A_arbace_core_defrecord_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defrecord_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defrecord_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_29)); return A_arbace_core_deftype__init_A_const_28.Ref() }
//line :327:1
func A_arbace_core_deftype__init_A_Unit19__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(327, 1); jrt.NN(A_arbace_core_deftype__init_A_const_28).SetMacro__V(); return nil }
//line :327:1
func A_arbace_core_deftype__init_A_Unit20__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(327, 1); return A_arbace_core_deftype__init_A_const_28.Ref() }




























































































func A_arbace_core_deftype__init_A_Unit21__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(420, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_30; var tmp2 any = aot_arbace_core.A_arbace_core_record_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_record_QMARK__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_record_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_31)); return A_arbace_core_deftype__init_A_const_30.Ref() }






func A_arbace_core_deftype__init_A_Unit22__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_32; var tmp2 any = aot_arbace_core.A_arbace_core_emit_deftype_STAR__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_deftype_STAR__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_deftype_STAR__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_33)); return A_arbace_core_deftype__init_A_const_32.Ref() }









func A_arbace_core_deftype__init_A_Unit23__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(437, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_34; var tmp2 any = aot_arbace_core.A_arbace_core_deftype_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_deftype_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_deftype_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_35)); return A_arbace_core_deftype__init_A_const_34.Ref() }
//line :437:1
func A_arbace_core_deftype__init_A_Unit24__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(437, 1); jrt.NN(A_arbace_core_deftype__init_A_const_34).SetMacro__V(); return nil }
//line :437:1
func A_arbace_core_deftype__init_A_Unit25__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(437, 1); return A_arbace_core_deftype__init_A_const_34.Ref() }





















































































func A_arbace_core_deftype__init_A_Unit26__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(523, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_36; var tmp2 any = aot_arbace_core.A_arbace_core_expand_method_impl_cache_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_expand_method_impl_cache_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_expand_method_impl_cache_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_37)); return A_arbace_core_deftype__init_A_const_36.Ref() }
















func A_arbace_core_deftype__init_A_Unit27__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(540, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_38; var tmp2 any = aot_arbace_core.A_arbace_core_super_chain_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_super_chain_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_super_chain_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_39)); return A_arbace_core_deftype__init_A_const_38.Ref() }



func A_arbace_core_deftype__init_A_Unit28__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(544, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_40; var tmp2 any = aot_arbace_core.A_arbace_core_pref_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_pref_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_pref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_41)); return A_arbace_core_deftype__init_A_const_40.Ref() }





func A_arbace_core_deftype__init_A_Unit29__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(550, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_42; var tmp2 any = aot_arbace_core.A_arbace_core_find_protocol_impl_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_find_protocol_impl_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_find_protocol_impl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_43)); return A_arbace_core_deftype__init_A_const_42.Ref() }










func A_arbace_core_deftype__init_A_Unit30__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(561, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_44; var tmp2 any = aot_arbace_core.A_arbace_core_find_protocol_method_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_find_protocol_method_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_find_protocol_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_45)); return A_arbace_core_deftype__init_A_const_44.Ref() }


func A_arbace_core_deftype__init_A_Unit31__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(564, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_46; var tmp2 any = aot_arbace_core.A_arbace_core_protocol_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_protocol_QMARK__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_protocol_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_47)); return A_arbace_core_deftype__init_A_const_46.Ref() }



func A_arbace_core_deftype__init_A_Unit32__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(568, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_48; var tmp2 any = aot_arbace_core.A_arbace_core_implements_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_implements_QMARK__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_implements_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_49)); return A_arbace_core_deftype__init_A_const_48.Ref() }


func A_arbace_core_deftype__init_A_Unit33__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(571, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_50; var tmp2 any = aot_arbace_core.A_arbace_core_extends_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_extends_QMARK__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_extends_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_51)); return A_arbace_core_deftype__init_A_const_50.Ref() }






func A_arbace_core_deftype__init_A_Unit34__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(578, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_52; var tmp2 any = aot_arbace_core.A_arbace_core_extenders_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_extenders_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_extenders_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_53)); return A_arbace_core_deftype__init_A_const_52.Ref() }





func A_arbace_core_deftype__init_A_Unit35__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(584, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_54; var tmp2 any = aot_arbace_core.A_arbace_core_satisfies_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_satisfies_QMARK__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_satisfies_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_55)); return A_arbace_core_deftype__init_A_const_54.Ref() }





func A_arbace_core_deftype__init_A_Unit36__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(590, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_56; var tmp2 any = aot_arbace_core.A_arbace_core__cache_protocol_fn_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core__cache_protocol_fn_A_Init(); tmp3 = aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_57)); return A_arbace_core_deftype__init_A_const_56.Ref() }











func A_arbace_core_deftype__init_A_Unit37__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(602, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_58; var tmp2 any = aot_arbace_core.A_arbace_core_emit_method_builder_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_method_builder_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_method_builder_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_59)); return A_arbace_core_deftype__init_A_const_58.Ref() }








































func A_arbace_core_deftype__init_A_Unit38__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(643, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_60; var tmp2 any = aot_arbace_core.A_arbace_core__reset_methods_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core__reset_methods_A_Init(); tmp3 = aot_arbace_core.A_arbace_core__reset_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_61)); return A_arbace_core_deftype__init_A_const_60.Ref() }




func A_arbace_core_deftype__init_A_Unit39__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(648, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_62; var tmp2 any = aot_arbace_core.A_arbace_core_assert_same_protocol_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_assert_same_protocol_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_assert_same_protocol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_63)); return A_arbace_core_deftype__init_A_const_62.Ref() }










func A_arbace_core_deftype__init_A_Unit40__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(659, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_64; var tmp2 any = aot_arbace_core.A_arbace_core_emit_protocol_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_protocol_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_protocol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_65)); return A_arbace_core_deftype__init_A_const_64.Ref() }































































func A_arbace_core_deftype__init_A_Unit41__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(723, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_66; var tmp2 any = aot_arbace_core.A_arbace_core_defprotocol_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defprotocol_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defprotocol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_67)); return A_arbace_core_deftype__init_A_const_66.Ref() }
//line :723:1
func A_arbace_core_deftype__init_A_Unit42__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(723, 1); jrt.NN(A_arbace_core_deftype__init_A_const_66).SetMacro__V(); return nil }
//line :723:1
func A_arbace_core_deftype__init_A_Unit43__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(723, 1); return A_arbace_core_deftype__init_A_const_66.Ref() }































































func A_arbace_core_deftype__init_A_Unit44__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(787, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_68; var tmp2 any = aot_arbace_core.A_arbace_core_extend_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_extend_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_extend_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_69)); return A_arbace_core_deftype__init_A_const_68.Ref() }














































func A_arbace_core_deftype__init_A_Unit45__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(834, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_70; var tmp2 any = aot_arbace_core.A_arbace_core_emit_impl_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_impl_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_impl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_71)); return A_arbace_core_deftype__init_A_const_70.Ref() }



func A_arbace_core_deftype__init_A_Unit46__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(838, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_72; var tmp2 any = aot_arbace_core.A_arbace_core_emit_hinted_impl_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_hinted_impl_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_hinted_impl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_73)); return A_arbace_core_deftype__init_A_const_72.Ref() }











func A_arbace_core_deftype__init_A_Unit47__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(850, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_74; var tmp2 any = aot_arbace_core.A_arbace_core_emit_extend_type_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_extend_type_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_extend_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_75)); return A_arbace_core_deftype__init_A_const_74.Ref() }




func A_arbace_core_deftype__init_A_Unit48__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(855, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_76; var tmp2 any = aot_arbace_core.A_arbace_core_extend_type_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_extend_type_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_extend_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_77)); return A_arbace_core_deftype__init_A_const_76.Ref() }
//line :855:1
func A_arbace_core_deftype__init_A_Unit49__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(855, 1); jrt.NN(A_arbace_core_deftype__init_A_const_76).SetMacro__V(); return nil }
//line :855:1
func A_arbace_core_deftype__init_A_Unit50__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(855, 1); return A_arbace_core_deftype__init_A_const_76.Ref() }
























func A_arbace_core_deftype__init_A_Unit51__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(880, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_78; var tmp2 any = aot_arbace_core.A_arbace_core_emit_extend_protocol_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_emit_extend_protocol_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_emit_extend_protocol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_79)); return A_arbace_core_deftype__init_A_const_78.Ref() }






func A_arbace_core_deftype__init_A_Unit52__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(887, 1); var tmp1 *lang.Var = A_arbace_core_deftype__init_A_const_80; var tmp2 any = aot_arbace_core.A_arbace_core_extend_protocol_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_extend_protocol_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_extend_protocol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_deftype__init_A_const_80; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_deftype__init_A_const_81)); return A_arbace_core_deftype__init_A_const_80.Ref() }
//line :887:1
func A_arbace_core_deftype__init_A_Unit53__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(887, 1); jrt.NN(A_arbace_core_deftype__init_A_const_80).SetMacro__V(); return nil }
//line :887:1
func A_arbace_core_deftype__init_A_Unit54__O() any { A_arbace_core_deftype__init_A_Init(); lang.Compiler_AOT_At_I_I__V(887, 1); return A_arbace_core_deftype__init_A_const_80.Ref() }







type A_arbace_core_deftype__init_A struct{ jrt.Object }

var A_arbace_core_deftype__init_A_const_0 *lang.Var

var A_arbace_core_deftype__init_A_const_1 any

var A_arbace_core_deftype__init_A_const_2 *lang.Var

var A_arbace_core_deftype__init_A_const_3 any

var A_arbace_core_deftype__init_A_const_4 *lang.Var

var A_arbace_core_deftype__init_A_const_5 any

var A_arbace_core_deftype__init_A_const_6 *lang.Var

var A_arbace_core_deftype__init_A_const_7 any

var A_arbace_core_deftype__init_A_const_8 *lang.Var

var A_arbace_core_deftype__init_A_const_9 any

var A_arbace_core_deftype__init_A_const_10 *lang.Var

var A_arbace_core_deftype__init_A_const_11 any

var A_arbace_core_deftype__init_A_const_12 *lang.Var

var A_arbace_core_deftype__init_A_const_13 any

var A_arbace_core_deftype__init_A_const_14 *lang.Var

var A_arbace_core_deftype__init_A_const_15 any

var A_arbace_core_deftype__init_A_const_16 *lang.Var

var A_arbace_core_deftype__init_A_const_17 any

var A_arbace_core_deftype__init_A_const_18 *lang.Var

var A_arbace_core_deftype__init_A_const_19 any

var A_arbace_core_deftype__init_A_const_20 *lang.Var

var A_arbace_core_deftype__init_A_const_21 any

var A_arbace_core_deftype__init_A_const_22 *lang.Var

var A_arbace_core_deftype__init_A_const_23 any

var A_arbace_core_deftype__init_A_const_24 *lang.Var

var A_arbace_core_deftype__init_A_const_25 any

var A_arbace_core_deftype__init_A_const_26 *lang.Var

var A_arbace_core_deftype__init_A_const_27 any

var A_arbace_core_deftype__init_A_const_28 *lang.Var

var A_arbace_core_deftype__init_A_const_29 any

var A_arbace_core_deftype__init_A_const_30 *lang.Var

var A_arbace_core_deftype__init_A_const_31 any

var A_arbace_core_deftype__init_A_const_32 *lang.Var

var A_arbace_core_deftype__init_A_const_33 any

var A_arbace_core_deftype__init_A_const_34 *lang.Var

var A_arbace_core_deftype__init_A_const_35 any

var A_arbace_core_deftype__init_A_const_36 *lang.Var

var A_arbace_core_deftype__init_A_const_37 any

var A_arbace_core_deftype__init_A_const_38 *lang.Var

var A_arbace_core_deftype__init_A_const_39 any

var A_arbace_core_deftype__init_A_const_40 *lang.Var

var A_arbace_core_deftype__init_A_const_41 any

var A_arbace_core_deftype__init_A_const_42 *lang.Var

var A_arbace_core_deftype__init_A_const_43 any

var A_arbace_core_deftype__init_A_const_44 *lang.Var

var A_arbace_core_deftype__init_A_const_45 any

var A_arbace_core_deftype__init_A_const_46 *lang.Var

var A_arbace_core_deftype__init_A_const_47 any

var A_arbace_core_deftype__init_A_const_48 *lang.Var

var A_arbace_core_deftype__init_A_const_49 any

var A_arbace_core_deftype__init_A_const_50 *lang.Var

var A_arbace_core_deftype__init_A_const_51 any

var A_arbace_core_deftype__init_A_const_52 *lang.Var

var A_arbace_core_deftype__init_A_const_53 any

var A_arbace_core_deftype__init_A_const_54 *lang.Var

var A_arbace_core_deftype__init_A_const_55 any

var A_arbace_core_deftype__init_A_const_56 *lang.Var

var A_arbace_core_deftype__init_A_const_57 any

var A_arbace_core_deftype__init_A_const_58 *lang.Var

var A_arbace_core_deftype__init_A_const_59 any

var A_arbace_core_deftype__init_A_const_60 *lang.Var

var A_arbace_core_deftype__init_A_const_61 any

var A_arbace_core_deftype__init_A_const_62 *lang.Var

var A_arbace_core_deftype__init_A_const_63 any

var A_arbace_core_deftype__init_A_const_64 *lang.Var

var A_arbace_core_deftype__init_A_const_65 any

var A_arbace_core_deftype__init_A_const_66 *lang.Var

var A_arbace_core_deftype__init_A_const_67 any

var A_arbace_core_deftype__init_A_const_68 *lang.Var

var A_arbace_core_deftype__init_A_const_69 any

var A_arbace_core_deftype__init_A_const_70 *lang.Var

var A_arbace_core_deftype__init_A_const_71 any

var A_arbace_core_deftype__init_A_const_72 *lang.Var

var A_arbace_core_deftype__init_A_const_73 any

var A_arbace_core_deftype__init_A_const_74 *lang.Var

var A_arbace_core_deftype__init_A_const_75 any

var A_arbace_core_deftype__init_A_const_76 *lang.Var

var A_arbace_core_deftype__init_A_const_77 any

var A_arbace_core_deftype__init_A_const_78 *lang.Var

var A_arbace_core_deftype__init_A_const_79 any

var A_arbace_core_deftype__init_A_const_80 *lang.Var

var A_arbace_core_deftype__init_A_const_81 any

var A_arbace_core_deftype__init_A_init jrt.ClassInit

func A_arbace_core_deftype__init_A_Init() { if !A_arbace_core_deftype__init_A_init.Done() { A_arbace_core_deftype__init_A_init.Run(A_arbace_core_deftype__init_A_clinit) } }

func A_arbace_core_deftype__init_A_clinit() { A_arbace_core_deftype__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_deftype__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_deftype__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_deftype__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_6, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_deftype__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_16, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_core_deftype__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_21, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_core_deftype__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_core_deftype__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_core_deftype__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_core_deftype__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_29, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(83).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_core_deftype__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_core_deftype__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(144).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_core_deftype__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_35)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(147).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_core_deftype__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_45, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(163).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_core_deftype__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_48).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_49, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(281).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_core_deftype__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_51, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(308).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_core_deftype__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(398).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_53, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(327).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp26 any = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))); var tmp27 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(); var tmp29 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(); var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_TRUE; var tmp31 any = tmp30.Ref(); A_arbace_core_deftype__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp26, tmp27, Lit_55, tmp28, Lit_56, tmp29, tmp31, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(420).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); var tmp32 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp33 *jrt.Boolean; jrt.Boolean_Init(); tmp33 = jrt.Boolean_TRUE; var tmp34 any = tmp33.Ref(); A_arbace_core_deftype__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp32, tmp34, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_59, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(427).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_core_deftype__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(504).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_61, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(437).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); var tmp35 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_TRUE; var tmp37 any = tmp36.Ref(); A_arbace_core_deftype__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, tmp37, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_63)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(523).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); var tmp38 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp39 *jrt.Boolean; jrt.Boolean_Init(); tmp39 = jrt.Boolean_TRUE; var tmp40 any = tmp39.Ref(); A_arbace_core_deftype__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp38, tmp40, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(540).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); var tmp41 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp42 *jrt.Boolean; jrt.Boolean_Init(); tmp42 = jrt.Boolean_TRUE; var tmp43 any = tmp42.Ref(); A_arbace_core_deftype__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp41, tmp43, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_70).Ref()), lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_70)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_71)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(544).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_core_deftype__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(550).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_core_deftype__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_75).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(561).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); var tmp44 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; var tmp46 any = tmp45.Ref(); A_arbace_core_deftype__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp44, tmp46, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(564).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); var tmp47 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp48 *jrt.Boolean; jrt.Boolean_Init(); tmp48 = jrt.Boolean_TRUE; var tmp49 any = tmp48.Ref(); A_arbace_core_deftype__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp47, tmp49, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(568).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_core_deftype__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_81, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(571).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_core_deftype__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_83, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(578).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_core_deftype__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(584).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_core_deftype__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_87)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(590).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); var tmp50 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp51 *jrt.Boolean; jrt.Boolean_Init(); tmp51 = jrt.Boolean_TRUE; var tmp52 any = tmp51.Ref(); A_arbace_core_deftype__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp52, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(602).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_core_deftype__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(643).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); var tmp53 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp54 *jrt.Boolean; jrt.Boolean_Init(); tmp54 = jrt.Boolean_TRUE; var tmp55 any = tmp54.Ref(); A_arbace_core_deftype__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp53, tmp55, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(648).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); var tmp56 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp57 *jrt.Boolean; jrt.Boolean_Init(); tmp57 = jrt.Boolean_TRUE; var tmp58 any = tmp57.Ref(); A_arbace_core_deftype__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp56, tmp58, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(659).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_102); A_arbace_core_deftype__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_103, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(723).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_core_deftype__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_106, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(787).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); var tmp59 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp60 *jrt.Boolean; jrt.Boolean_Init(); tmp60 = jrt.Boolean_TRUE; var tmp61 any = tmp60.Ref(); A_arbace_core_deftype__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp59, tmp61, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(834).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); var tmp62 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp63 *jrt.Boolean; jrt.Boolean_Init(); tmp63 = jrt.Boolean_TRUE; var tmp64 any = tmp63.Ref(); A_arbace_core_deftype__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp62, tmp64, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(838).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); var tmp65 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp66 *jrt.Boolean; jrt.Boolean_Init(); tmp66 = jrt.Boolean_TRUE; var tmp67 any = tmp66.Ref(); A_arbace_core_deftype__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp65, tmp67, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(850).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_core_deftype__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_114, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(855).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_115); var tmp68 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(); var tmp69 *jrt.Boolean; jrt.Boolean_Init(); tmp69 = jrt.Boolean_TRUE; var tmp70 any = tmp69.Ref(); A_arbace_core_deftype__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp68, tmp70, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(880).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_deftype__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_core_deftype__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), Lit_117, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), Lit_8, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(887).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)) }

func A_arbace_core_deftype__init_A_New() *A_arbace_core_deftype__init_A { A_arbace_core_deftype__init_A_Init(); t := &A_arbace_core_deftype__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_deftype__init_A) Ctor() {}

func (t *A_arbace_core_deftype__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_deftype__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_deftype__init_A_class }

func (t *A_arbace_core_deftype__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_deftype__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_deftype__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_deftype__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_deftype__init_A); return ok }

func A_arbace_core_deftype__init_A_Cast(x any) *A_arbace_core_deftype__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_deftype__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_deftype__init_A_class)) }; return v }
