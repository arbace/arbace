//line a2g_up.ae:1
package aot_arbace_core_protocols

import "arbace/lang"


func Up_Symbol_IFn(p *lang.Symbol) lang.IFn { if p == nil { return nil }; return p }

func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }

func Up_Var_IFn(p *lang.Var) lang.IFn { if p == nil { return nil }; return p }
