//line a2g_strings.ae:1
package aot_arbace_core_protocols

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.core.protocols")

var Lit_6 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_7 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_8 *jrt.String = jrt.Intern("arbace.core.protocols.CollReduce")

var Lit_9 *jrt.String = jrt.Intern("arbace.core.protocols.InternalReduce")

var Lit_10 *jrt.String = jrt.Intern("seq")

var Lit_11 *jrt.String = jrt.Intern("internal-reduce")

var Lit_12 *jrt.String = jrt.Intern("next")

var Lit_13 *jrt.String = jrt.Intern("first")

var Lit_14 *jrt.String = jrt.Intern("iterator-reduce!")

var Lit_15 *jrt.String = jrt.Intern("naive-seq-reduce")

var Lit_16 *jrt.String = jrt.Intern("seq-reduce")

var Lit_17 *jrt.String = jrt.Intern("iter-reduce")

var Lit_18 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_19 *jrt.String = jrt.Intern("chunk-first")

var Lit_20 *jrt.String = jrt.Intern("interface-or-naive-reduce")

var Lit_21 *jrt.String = jrt.Intern("chunk-next")

var Lit_22 *jrt.String = jrt.Intern("class")

var Lit_23 *jrt.String = jrt.Intern("arbace.core.protocols.IKVReduce")

var Lit_24 *jrt.String = jrt.Intern("arbace.core.protocols.Datafiable")

var Lit_25 *jrt.String = jrt.Intern("arbace.core.protocols.Navigable")

var Lit_26 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000002$loading__1927001464__auto____619000003")

var Lit_27 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000006$fn__619000007")

var Lit_28 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000020$fn__619000021")

var Lit_29 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000020$fn__619000021$G__619000012__619000034")

var Lit_30 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000020$fn__619000021$G__619000013__619000027")

var Lit_31 *jrt.String = jrt.Intern("coll_reduce")

var Lit_32 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000050$fn__619000051")

var Lit_33 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000050$fn__619000051$G__619000042__619000060")

var Lit_34 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000050$fn__619000051$G__619000043__619000055")

var Lit_35 *jrt.String = jrt.Intern("internal_reduce")

var Lit_36 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000073$fn__619000074")

var Lit_37 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000077$fn__619000078")

var Lit_38 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000081$fn__619000082")

var Lit_39 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000085$fn__619000086")

var Lit_40 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000089$fn__619000090")

var Lit_41 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000093$fn__619000094")

var Lit_42 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000093$fn__619000094$fn__619000095")

var Lit_43 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000099$fn__619000100")

var Lit_44 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000103$fn__619000104")

var Lit_45 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000107$fn__619000108")

var Lit_46 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000111$fn__619000112")

var Lit_47 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000115$fn__619000116")

var Lit_48 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000119$fn__619000120")

var Lit_49 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000123$fn__619000124")

var Lit_50 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000135$fn__619000136")

var Lit_51 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000135$fn__619000136$G__619000127__619000145")

var Lit_52 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000135$fn__619000136$G__619000128__619000140")

var Lit_53 *jrt.String = jrt.Intern("kv_reduce")

var Lit_54 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000161$fn__619000162")

var Lit_55 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000161$fn__619000162$G__619000153__619000167")

var Lit_56 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000161$fn__619000162$G__619000154__619000164")

var Lit_57 *jrt.String = jrt.Intern("datafy")

var Lit_58 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000175$fn__619000176")

var Lit_59 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000179$fn__619000180")

var Lit_60 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000191$fn__619000192")

var Lit_61 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000191$fn__619000192$G__619000183__619000201")

var Lit_62 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000191$fn__619000192$G__619000184__619000196")

var Lit_63 *jrt.String = jrt.Intern("nav")

var Lit_64 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000209$fn__619000210")

var Lit_65 *jrt.String = jrt.Intern("arbace.core.protocols$interface_or_naive_reduce")

var Lit_66 *jrt.String = jrt.Intern("arbace.core.protocols$iter_reduce")

var Lit_67 *jrt.String = jrt.Intern("arbace.core.protocols$iterator_reduce_BANG_")

var Lit_68 *jrt.String = jrt.Intern("arbace.core.protocols$naive_seq_reduce")

var Lit_69 *jrt.String = jrt.Intern("arbace.core.protocols$seq_reduce")

var Lit_70 *jrt.String = jrt.Intern("in-ns")

var Lit_71 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_72 *jrt.String = jrt.Intern("CollReduce")

var Lit_73 *jrt.String = jrt.Intern("line")

var Lit_74 *jrt.String = jrt.Intern("column")

var Lit_75 *jrt.String = jrt.Intern("file")

var Lit_76 *jrt.String = jrt.Intern("arbace/core/protocols.ae")

var Lit_77 *jrt.String = jrt.Intern("alter-meta!")

var Lit_78 *jrt.String = jrt.Intern("assoc")

var Lit_79 *jrt.String = jrt.Intern("doc")

var Lit_80 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_81 *jrt.String = jrt.Intern("coll-reduce")

var Lit_82 *jrt.String = jrt.Intern("arglists")

var Lit_83 *jrt.String = jrt.Intern("coll")

var Lit_84 *jrt.String = jrt.Intern("f")

var Lit_85 *jrt.String = jrt.Intern("val")

var Lit_86 *jrt.String = jrt.Intern("alter-var-root")

var Lit_87 *jrt.String = jrt.Intern("merge")

var Lit_88 *jrt.String = jrt.Intern("on")

var Lit_89 *jrt.String = jrt.Intern("on-interface")

var Lit_90 *jrt.String = jrt.Intern("Protocol for collection types that can implement reduce faster than\n  first/next recursion. Called by arbace.core/reduce. Baseline\n  implementation defined in terms of Iterable.")

var Lit_91 *jrt.String = jrt.Intern("sigs")

var Lit_92 *jrt.String = jrt.Intern("tag")

var Lit_93 *jrt.String = jrt.Intern("name")

var Lit_94 *jrt.String = jrt.Intern("var")

var Lit_95 *jrt.String = jrt.Intern("method-map")

var Lit_96 *jrt.String = jrt.Intern("method-builders")

var Lit_97 *jrt.String = jrt.Intern("intern")

var Lit_98 *jrt.String = jrt.Intern("*ns*")

var Lit_99 *jrt.String = jrt.Intern("with-meta")

var Lit_100 *jrt.String = jrt.Intern("protocol")

var Lit_101 *jrt.String = jrt.Intern("-reset-methods")

var Lit_102 *jrt.String = jrt.Intern("InternalReduce")

var Lit_103 *jrt.String = jrt.Intern("start")

var Lit_104 *jrt.String = jrt.Intern("Protocol for concrete seq types that can reduce themselves\n   faster than first/next recursion. Called by arbace.core/reduce.")

var Lit_105 *jrt.String = jrt.Intern("private")

var Lit_106 *jrt.String = jrt.Intern("iter")

var Lit_107 *jrt.String = jrt.Intern("java.util.Iterator")

var Lit_108 *jrt.String = jrt.Intern("Iterable")

var Lit_109 *jrt.String = jrt.Intern("s")

var Lit_110 *jrt.String = jrt.Intern("Reduces a seq, ignoring any opportunities to switch to a more\n  specialized implementation.")

var Lit_111 *jrt.String = jrt.Intern("Reduces via IReduceInit if possible, else naively.")

var Lit_112 *jrt.String = jrt.Intern("extend")

var Lit_113 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_114 *jrt.String = jrt.Intern("arbace.lang.PersistentVector")

var Lit_115 *jrt.String = jrt.Intern("java.lang.Iterable")

var Lit_116 *jrt.String = jrt.Intern("arbace.lang.ASeq")

var Lit_117 *jrt.String = jrt.Intern("arbace.lang.IReduceInit")

var Lit_118 *jrt.String = jrt.Intern("arbace.lang.LazySeq")

var Lit_119 *jrt.String = jrt.Intern("arbace.lang.APersistentMap$KeySeq")

var Lit_120 *jrt.String = jrt.Intern("arbace.lang.APersistentMap$ValSeq")

var Lit_121 *jrt.String = jrt.Intern("arbace.lang.IChunkedSeq")

var Lit_122 *jrt.String = jrt.Intern("arbace.lang.StringSeq")

var Lit_123 *jrt.String = jrt.Intern("IKVReduce")

var Lit_124 *jrt.String = jrt.Intern("kv-reduce")

var Lit_125 *jrt.String = jrt.Intern("amap")

var Lit_126 *jrt.String = jrt.Intern("init")

var Lit_127 *jrt.String = jrt.Intern("Protocol for concrete associative types that can reduce themselves\n   via a function of key and val faster than first/next recursion over map\n   entries. Called by arbace.core/reduce-kv, and has same\n   semantics (just different arg order).")

var Lit_128 *jrt.String = jrt.Intern("Datafiable")

var Lit_129 *jrt.String = jrt.Intern("return a representation of o as data (default identity)")

var Lit_130 *jrt.String = jrt.Intern("o")

var Lit_131 *jrt.String = jrt.Intern("extend-via-metadata")

var Lit_132 *jrt.String = jrt.Intern("Navigable")

var Lit_133 *jrt.String = jrt.Intern("return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.")

var Lit_134 *jrt.String = jrt.Intern("k")

var Lit_135 *jrt.String = jrt.Intern("v")
