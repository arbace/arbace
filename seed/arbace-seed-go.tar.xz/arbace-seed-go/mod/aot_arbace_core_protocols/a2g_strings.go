//line a2g_strings.ae:1
package aot_arbace_core_protocols

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn21,arbace.core.protocolsv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjR1,v11,arbace.core13,*loaded-libs*v11,arbace.core18,-cache-protocol-fnC32,arbace.core.protocols.CollReduceC36,arbace.core.protocols.InternalReducev11,arbace.core3,seqv21,arbace.core.protocols15,internal-reducev11,arbace.core4,nextv11,arbace.core5,firstv21,arbace.core.protocols16,iterator-reduce!v21,arbace.core.protocols16,naive-seq-reducev21,arbace.core.protocols10,seq-reducev21,arbace.core.protocols11,iter-reducev11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv21,arbace.core.protocols25,interface-or-naive-reducev11,arbace.core10,chunk-nextv11,arbace.core5,classC31,arbace.core.protocols.IKVReduceC32,arbace.core.protocols.DatafiableC31,arbace.core.protocols.Navigable")

var Lit_1 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000020$fn__619000021$G__619000013__619000027")

var Lit_2 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000020$fn__619000021$G__619000012__619000034")

var Lit_3 *jrt.String = jrt.Intern("coll_reduce")

var Lit_4 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000050$fn__619000051$G__619000043__619000055")

var Lit_5 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000050$fn__619000051$G__619000042__619000060")

var Lit_6 *jrt.String = jrt.Intern("internal_reduce")

var Lit_7 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000093$fn__619000094$fn__619000095")

var Lit_8 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000135$fn__619000136$G__619000128__619000140")

var Lit_9 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000135$fn__619000136$G__619000127__619000145")

var Lit_10 *jrt.String = jrt.Intern("kv_reduce")

var Lit_11 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000161$fn__619000162$G__619000154__619000164")

var Lit_12 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000161$fn__619000162$G__619000153__619000167")

var Lit_13 *jrt.String = jrt.Intern("datafy")

var Lit_14 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000191$fn__619000192$G__619000184__619000196")

var Lit_15 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000191$fn__619000192$G__619000183__619000201")

var Lit_16 *jrt.String = jrt.Intern("nav")

var Lit_17 *jrt.String = jrt.Intern("yn21,arbace.core.protocolsyn11,arbace.corekn4,linekn6,columnkn4,filekn3,dockn8,arglistsyn4,collyn1,fyn3,valkn2,onyn32,arbace.core.protocols.CollReducekn12,on-interfacekn4,sigskn11,coll-reducekn3,tagkn4,namekn3,varkn10,method-mapkn15,method-builderskn8,protocolyn10,CollReduceyn3,seqyn5,startyn36,arbace.core.protocols.InternalReducekn15,internal-reduceyn14,InternalReducekn7,privateyn18,java.util.Iteratoryn8,Iterableyn1,syn4,amapyn4,inityn31,arbace.core.protocols.IKVReducekn9,kv-reduceyn9,IKVReduceyn1,oyn32,arbace.core.protocols.Datafiablekn19,extend-via-metadatakn6,datafyyn10,Datafiableyn1,kyn1,vyn31,arbace.core.protocols.Navigablekn3,navyn9,Navigablev11,arbace.core5,in-nsR0,R1,v11,arbace.core20,*warn-on-reflection*v21,arbace.core.protocols10,CollReducem6,R2,i13,R3,i1,R4,s24,arbace/core/protocols.aem6,R2,i13,R3,i1,R4,s24,arbace/core/protocols.aeC32,arbace.core.protocols.CollReducev11,arbace.core11,alter-meta!v11,arbace.core5,assocR5,v11,arbace.core20,assert-same-protocolL1,Myn11,coll-reducem4,R5,nR6,L2,V2,R7,R8,V3,R7,R8,R9,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem6,R10,R11,R12,C32,arbace.core.protocols.CollReduceR5,s177,Protocol for collection types that can implement reduce faster than\n  first/next recursion. Called by arbace.core/reduce. Baseline\n  implementation defined in terms of Iterable.R13,m2,R14,m8,R15,nR16,Myn11,coll-reducem4,R5,nR6,L2,V2,R7,R8,V3,R7,R8,R9,R6,L2,V2,R7,R8,V3,R7,R8,R9,R5,nR17,R18,m2,R14,R14,R19,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn11,coll-reducem4,R5,nR6,L2,V2,R7,R8,V3,R7,R8,R9,m8,R15,nR16,Myn11,coll-reducem4,R5,nR6,L2,V2,R7,R8,V3,R7,R8,R9,R6,L2,V2,R7,R8,V3,R7,R8,R9,R5,nR20,v11,arbace.core14,-reset-methodsR21,v21,arbace.core.protocols14,InternalReducem6,R2,i19,R3,i1,R4,s24,arbace/core/protocols.aem6,R2,i19,R3,i1,R4,s24,arbace/core/protocols.aeC36,arbace.core.protocols.InternalReduceL1,Myn15,internal-reducem4,R5,nR6,L1,V3,R22,R8,R23,m6,R10,R24,R12,C36,arbace.core.protocols.InternalReduceR5,s125,Protocol for concrete seq types that can reduce themselves\n   faster than first/next recursion. Called by arbace.core/reduce.m2,R25,m8,R15,nR16,Myn15,internal-reducem4,R5,nR6,L1,V3,R22,R8,R23,R6,L1,V3,R22,R8,R23,R5,nm2,R25,R25,Myn15,internal-reducem4,R5,nR6,L1,V3,R22,R8,R23,m8,R15,nR16,Myn15,internal-reducem4,R5,nR6,L1,V3,R22,R8,R23,R6,L1,V3,R22,R8,R23,R5,nR26,v21,arbace.core.protocols10,seq-reducem10,R27,TR6,L2,V2,R7,R8,V3,R7,R8,R9,R2,i24,R3,i1,R4,s24,arbace/core/protocols.aev21,arbace.core.protocols16,iterator-reduce!m8,R6,L2,V2,Myn4,iterm2,R15,R28,R8,V3,Myn4,iterm2,R15,R28,R8,R9,R2,i34,R3,i1,R4,s24,arbace/core/protocols.aev21,arbace.core.protocols11,iter-reducem10,R27,TR6,L2,V2,Myn4,collm2,R15,R29,R8,V3,Myn4,collm2,R15,R29,R8,R9,R2,i48,R3,i1,R4,s24,arbace/core/protocols.aev21,arbace.core.protocols16,naive-seq-reducem12,R27,TR6,L1,V3,R30,R8,R9,R5,s91,Reduces a seq, ignoring any opportunities to switch to a more\n  specialized implementation.R2,i54,R3,i1,R4,s24,arbace/core/protocols.aev21,arbace.core.protocols25,interface-or-naive-reducem12,R27,TR6,L1,V3,R7,R8,R9,R5,s50,Reduces via IReduceInit if possible, else naively.R2,i67,R3,i1,R4,s24,arbace/core/protocols.aev11,arbace.core6,extendR14,C16,java.lang.ObjectC28,arbace.lang.PersistentVectorC18,java.lang.IterableC16,arbace.lang.ASeqC23,arbace.lang.IReduceInitC19,arbace.lang.LazySeqC33,arbace.lang.APersistentMap$KeySeqC33,arbace.lang.APersistentMap$ValSeqR25,C23,arbace.lang.IChunkedSeqC21,arbace.lang.StringSeqv21,arbace.core.protocols9,IKVReducem6,R2,i183,R3,i1,R4,s24,arbace/core/protocols.aem6,R2,i183,R3,i1,R4,s24,arbace/core/protocols.aeC31,arbace.core.protocols.IKVReduceL1,Myn9,kv-reducem4,R5,nR6,L1,V3,R31,R8,R32,m6,R10,R33,R12,C31,arbace.core.protocols.IKVReduceR5,s240,Protocol for concrete associative types that can reduce themselves\n   via a function of key and val faster than first/next recursion over map\n   entries. Called by arbace.core/reduce-kv, and has same\n   semantics (just different arg order).m2,R34,m8,R15,nR16,Myn9,kv-reducem4,R5,nR6,L1,V3,R31,R8,R32,R6,L1,V3,R31,R8,R32,R5,nm2,R34,R34,Myn9,kv-reducem4,R5,nR6,L1,V3,R31,R8,R32,m8,R15,nR16,Myn9,kv-reducem4,R5,nR6,L1,V3,R31,R8,R32,R6,L1,V3,R31,R8,R32,R5,nR35,v21,arbace.core.protocols10,Datafiablem6,R2,i190,R3,i1,R4,s24,arbace/core/protocols.aem6,R2,i190,R3,i1,R4,s24,arbace/core/protocols.aeC32,arbace.core.protocols.DatafiableL1,Myn6,datafym4,R5,s55,return a representation of o as data (default identity)R6,L1,V1,R36,m6,R10,R37,R12,C32,arbace.core.protocols.DatafiableR38,Tm2,R39,m8,R15,nR16,Myn6,datafym4,R5,s55,return a representation of o as data (default identity)R6,L1,V1,R36,R6,L1,V1,R36,R5,s55,return a representation of o as data (default identity)m2,R39,R39,Myn6,datafym4,R5,s55,return a representation of o as data (default identity)R6,L1,V1,R36,m8,R15,nR16,Myn6,datafym4,R5,s55,return a representation of o as data (default identity)R6,L1,V1,R36,R6,L1,V1,R36,R5,s55,return a representation of o as data (default identity)R40,R39,v21,arbace.core.protocols9,Navigablem6,R2,i202,R3,i1,R4,s24,arbace/core/protocols.aem6,R2,i202,R3,i1,R4,s24,arbace/core/protocols.aeC31,arbace.core.protocols.NavigableL1,Myn3,navm4,R5,s107,return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.R6,L1,V3,R7,R41,R42,m6,R10,R43,R12,C31,arbace.core.protocols.NavigableR38,Tm2,R44,m8,R15,nR16,Myn3,navm4,R5,s107,return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.R6,L1,V3,R7,R41,R42,R6,L1,V3,R7,R41,R42,R5,s107,return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.m2,R44,R44,Myn3,navm4,R5,s107,return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.R6,L1,V3,R7,R41,R42,m8,R15,nR16,Myn3,navm4,R5,s107,return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.R6,L1,V3,R7,R41,R42,R6,L1,V3,R7,R41,R42,R5,s107,return (possibly transformed) v in the context of coll and k (a key/index or nil),\ndefaults to returning v.R45,R44,")

var Lit_18 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000002$loading__1927001464__auto____619000003")

var Lit_19 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000006$fn__619000007")

var Lit_20 *jrt.String = jrt.Intern("Protocol for collection types that can implement reduce faster than\n  first/next recursion. Called by arbace.core/reduce. Baseline\n  implementation defined in terms of Iterable.")

var Lit_21 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000020$fn__619000021")

var Lit_22 *jrt.String = jrt.Intern("Protocol for concrete seq types that can reduce themselves\n   faster than first/next recursion. Called by arbace.core/reduce.")

var Lit_23 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000050$fn__619000051")

var Lit_24 *jrt.String = jrt.Intern("arbace.core.protocols$seq_reduce")

var Lit_25 *jrt.String = jrt.Intern("arbace.core.protocols$iterator_reduce_BANG_")

var Lit_26 *jrt.String = jrt.Intern("arbace.core.protocols$iter_reduce")

var Lit_27 *jrt.String = jrt.Intern("arbace.core.protocols$naive_seq_reduce")

var Lit_28 *jrt.String = jrt.Intern("arbace.core.protocols$interface_or_naive_reduce")

var Lit_29 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000073$fn__619000074")

var Lit_30 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000077$fn__619000078")

var Lit_31 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000081$fn__619000082")

var Lit_32 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000085$fn__619000086")

var Lit_33 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000089$fn__619000090")

var Lit_34 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000093$fn__619000094")

var Lit_35 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000099$fn__619000100")

var Lit_36 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000103$fn__619000104")

var Lit_37 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000107$fn__619000108")

var Lit_38 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000111$fn__619000112")

var Lit_39 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000115$fn__619000116")

var Lit_40 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000119$fn__619000120")

var Lit_41 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000123$fn__619000124")

var Lit_42 *jrt.String = jrt.Intern("Protocol for concrete associative types that can reduce themselves\n   via a function of key and val faster than first/next recursion over map\n   entries. Called by arbace.core/reduce-kv, and has same\n   semantics (just different arg order).")

var Lit_43 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000135$fn__619000136")

var Lit_44 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000161$fn__619000162")

var Lit_45 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000175$fn__619000176")

var Lit_46 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000179$fn__619000180")

var Lit_47 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000191$fn__619000192")

var Lit_48 *jrt.String = jrt.Intern("arbace.core.protocols$eval619000209$fn__619000210")
