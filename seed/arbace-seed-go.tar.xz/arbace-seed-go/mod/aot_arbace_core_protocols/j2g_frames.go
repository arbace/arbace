//line j2g_frames.ae:1
package aot_arbace_core_protocols

import "arbace/jrt"


func init() { jrt.RegisterFrames([]jrt.FrameInfo{{"arbace/aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Coll_reduce_O__O", "arbace.core.protocols.CollReduce", "coll_reduce", 0}, {"arbace/aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A_Coll_reduce_O_O__O", "arbace.core.protocols.CollReduce", "coll_reduce", 0}, {"arbace/aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A_Kv_reduce_O_O__O", "arbace.core.protocols.IKVReduce", "kv_reduce", 0}, {"arbace/aot_arbace_core_protocols.A_arbace_core_protocols_InternalReduce_A_Internal_reduce_O_O__O", "arbace.core.protocols.InternalReduce", "internal_reduce", 0}}) }
