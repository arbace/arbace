//line j2g_up.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_Compiler_AOTFn_IFn(p *lang.Compiler_AOTFn) lang.IFn { if p == nil { return nil }; return p }

func Up_Compiler_AOTFn_Callable(p *lang.Compiler_AOTFn) jrt.Callable { if p == nil { return nil }; return p }

func Up_Symbol_IFn(p *lang.Symbol) lang.IFn { if p == nil { return nil }; return p }
